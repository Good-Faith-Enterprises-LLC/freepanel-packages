#!/usr/bin/env bash
# freePanel: turns on login protection (modules/security/README.md) on a
# server freePanel is already installed on. The panel's "Turn on login
# protection" button runs it as root, in a unit of its own (the root agent's
# protect job), and the installer puts it at
# /usr/local/freepanel/libexec/freepanel-protect. The installer's own --protect
# does the same steps on a new install.
#
#   freepanel-protect [ADDRESS]
#
# ADDRESS, if given, is one IP address put on the allow list first (the panel
# gives the address the admin is signed in from).
#
# AlmaLinux, Rocky, RHEL, CloudLinux: where firewalld is off, it is installed
# and turned on, with every port sshd listens on, the panels' ports and the
# installed services' ports written to its configuration before it starts; it
# then checks SSH's ports are open and stops otherwise. Where firewalld already
# runs, its rules are left as they are. fail2ban comes from EPEL.
# Ubuntu, Debian: fail2ban and nftables from the distribution, and the deny
# list's boot unit; no firewall needs to run.
#
# Last, it writes /etc/freepanel/security.json, which turns the module on, and
# restarts the root agent and the panel, which read it as they start.
set -euo pipefail

# The places, which test/installer/protect_test.go moves into a folder of its own.
ETC="${FP_TEST_ETC:-/etc/freepanel}"
UNIT_DIR="${FP_TEST_UNIT_DIR:-/etc/systemd/system}"
F2B_DIR="${FP_TEST_F2B_DIR:-/etc/fail2ban}"
OS_RELEASE="${FP_TEST_OS_RELEASE:-/etc/os-release}"
F2B_STOCK_OFF="$F2B_DIR/jail.d/zz-freepanel-stock-sshd.conf"

say() { printf '==> %s\n' "$*"; }
die() { printf 'freepanel-protect: %s\n' "$*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || [ -n "${FP_TEST_ETC:-}" ] || die "run this as root"
[ -f "$ETC/freepanel.json" ] || die "freePanel is not installed on this server ($ETC/freepanel.json is missing)"
if [ -f "$ETC/security.json" ]; then
  say "Login protection is already on"
  exit 0
fi
ALLOW="${1:-}"
if [ -n "$ALLOW" ] && ! [[ "$ALLOW" =~ ^[0-9A-Fa-f.:]{2,45}$ ]]; then
  die "not an IP address: $ALLOW"
fi

# shellcheck disable=SC1090
. "$OS_RELEASE"
FAMILY=""
case "${ID:-}" in
  almalinux | rocky | rhel | cloudlinux) FAMILY=el ;;
  ubuntu | debian) FAMILY=deb ;;
esac
[ -n "$FAMILY" ] || die "this system (${PRETTY_NAME:-unknown}) is not one freePanel installs on"

# port_of KEY FILE: the port at the end of a "KEY": "...:PORT" line.
port_of() { sed -n "s/.*\"$1\"[[:space:]]*:[[:space:]]*\"[^\"]*:\([0-9]\{1,5\}\)\".*/\1/p" "$2" | head -n 1; }
# url_port FILE: the port of {"url":"https://NAME:PORT"}.
url_port() { sed -n 's/.*"url"[[:space:]]*:[[:space:]]*"https:\/\/[^"]*:\([0-9]\{1,5\}\)".*/\1/p' "$1" | head -n 1; }

PORT="$(port_of listen "$ETC/freepanel.json")"
USER_PORT="$(port_of user_listen "$ETC/freepanel.json")"
[ -n "$PORT" ] || PORT=7443
[ -n "$USER_PORT" ] || USER_PORT=7444
SSH_PORTS="$(sshd -T 2>/dev/null | awk '$1 == "port" { print $2 }' | sort -un || true)"
[ -n "$SSH_PORTS" ] || SSH_PORTS=22
for p in $SSH_PORTS; do [[ "$p" =~ ^[0-9]+$ ]] || die "could not read sshd's ports ($SSH_PORTS)"; done

# What the server serves: the panels, and each service the installer set up.
FW_SERVICES=("$PORT/tcp" "$USER_PORT/tcp")
[ ! -f "$ETC/web.json" ] || FW_SERVICES+=(http https)
[ ! -f "$ETC/mail.json" ] || FW_SERVICES+=(smtp smtp-submission imap imaps)
[ ! -f "$ETC/dns.json" ] || FW_SERVICES+=(dns)
if [ -f "$ETC/ftp.json" ]; then
  range="$(awk '$1 == "PassivePortRange" && $2 ~ /^[0-9]+$/ && $3 ~ /^[0-9]+$/ { print $2 "-" $3; exit }' "$ETC/pure-ftpd.conf" 2>/dev/null || true)"
  FW_SERVICES+=(21/tcp "${range:-30000-30999}/tcp")
fi
WEBMAIL_PORT=""
for f in dbadmin webmail; do
  [ -f "$ETC/$f.json" ] || continue
  p="$(url_port "$ETC/$f.json")"
  [ -z "$p" ] || FW_SERVICES+=("$p/tcp")
  [ "$f" != webmail ] || WEBMAIL_PORT="$p"
done

if [ "$FAMILY" = el ]; then
  if ! { command -v firewall-cmd >/dev/null && firewall-cmd --state >/dev/null 2>&1; }; then
    say "Turning on the firewall (firewalld): it was off, and login protection needs it"
    dnf -y -q install firewalld
    command -v firewall-offline-cmd >/dev/null || die "firewall-offline-cmd is missing; the firewall was not turned on"
    for p in $SSH_PORTS; do
      firewall-offline-cmd --add-port="$p/tcp" >/dev/null || die "could not allow SSH port $p in firewalld's configuration; the firewall was not turned on"
    done
    for s in "${FW_SERVICES[@]}"; do
      if [[ "$s" == */* ]]; then
        firewall-offline-cmd --add-port="$s" >/dev/null || die "could not open $s in firewalld's configuration; the firewall was not turned on"
      else
        firewall-offline-cmd --add-service="$s" >/dev/null || die "could not open $s in firewalld's configuration; the firewall was not turned on"
      fi
    done
    say "Opened: SSH ($(echo "$SSH_PORTS" | paste -sd, -)) ${FW_SERVICES[*]}"
    systemctl enable --now firewalld || die "firewalld did not start; see: journalctl -u firewalld"
    for _ in $(seq 1 20); do
      firewall-cmd --state >/dev/null 2>&1 && break
      sleep 0.5
    done
    firewall-cmd --state >/dev/null 2>&1 || die "firewalld did not start; see: journalctl -u firewalld"
    for p in $SSH_PORTS; do
      firewall-cmd --query-port="$p/tcp" >/dev/null || die "firewalld runs without SSH's port $p; allow it now (firewall-cmd --permanent --add-port=PORT/tcp, then --reload)"
    done
  else
    say "firewalld already runs; its rules are left as they are"
  fi
  say "Installing fail2ban"
  if ! rpm -q epel-release >/dev/null 2>&1; then
    dnf -y -q install epel-release || die "fail2ban comes from EPEL, which is not set up here; run the freePanel installer again with --protect"
  fi
  dnf -y -q install fail2ban fail2ban-firewalld python3-systemd
else
  say "Installing fail2ban and nftables"
  F2B_NEW=0
  dpkg-query -W -f='${Status}' fail2ban 2>/dev/null | grep -q 'install ok installed' || F2B_NEW=1
  export DEBIAN_FRONTEND=noninteractive NEEDRESTART_MODE=l
  apt-get -q -o DPkg::Lock::Timeout=600 update
  apt-get -y -q -o DPkg::Lock::Timeout=600 install nftables fail2ban python3-systemd
  # Ubuntu's package turns on its own sshd jail, with the stock filter
  # (finding 229-2) and without the allow list; where this run installed
  # fail2ban it is turned off, as the installer does. freepanel-ssh covers SSH.
  if [ "$F2B_NEW" -eq 1 ]; then
    install -d -m 0755 "$F2B_DIR/jail.d"
    printf '# Written by the freePanel installer: Ubuntu'"'"'s own sshd jail is off; freepanel-ssh covers SSH.\n[sshd]\nenabled = false\n' >"$F2B_STOCK_OFF.new"
    chmod 0644 "$F2B_STOCK_OFF.new"
    mv -f "$F2B_STOCK_OFF.new" "$F2B_STOCK_OFF"
  fi
  # The deny list's boot unit, the same as installer/systemd/freepanel-firewall.service
  # (test/installer/protect_test.go holds them equal).
  cat >"$UNIT_DIR/freepanel-firewall.service.new" <<'UNIT'
# BEGIN freepanel-firewall.service
# The deny list of freePanel's login protection on Ubuntu (install.sh
# --protect): loads the root agent's own nftables table, inet freepanel, from
# the ruleset the agent last put in force, at boot before the network is up.
# It touches no other table (ufw's, fail2ban's and the server's own stay as
# they are). The agent puts the table back itself too when it starts.
[Unit]
Description=freePanel deny list (nftables table inet freepanel)
Documentation=https://github.com/caddyboy0103/freepanel
DefaultDependencies=no
Wants=network-pre.target
Before=network-pre.target shutdown.target
Conflicts=shutdown.target
# Nothing was ever denied: there is no table to load.
ConditionPathExists=/etc/freepanel/security.nft

[Service]
Type=oneshot
RemainAfterExit=yes
StandardInput=null
ExecStart=/usr/sbin/nft -f /etc/freepanel/security.nft
# Stopping it (the uninstaller does) takes the table out; nothing else.
ExecStop=-/usr/sbin/nft delete table inet freepanel

[Install]
WantedBy=sysinit.target
# END freepanel-firewall.service
UNIT
  chmod 0644 "$UNIT_DIR/freepanel-firewall.service.new"
  mv -f "$UNIT_DIR/freepanel-firewall.service.new" "$UNIT_DIR/freepanel-firewall.service"
  systemctl daemon-reload
  systemctl enable --quiet freepanel-firewall
fi
# The root agent starts it once its jails are written.
systemctl enable --quiet fail2ban

say "Writing $ETC/security.json"
ssh_csv="$(echo "$SSH_PORTS" | paste -sd, -)"
seed=""
[ -z "$ALLOW" ] || seed="\"$ALLOW\""
dav=""
if [ -f "$ETC/dav.json" ] && [ -n "$WEBMAIL_PORT" ]; then dav="\"dav_ports\":[$WEBMAIL_PORT],"; fi
printf '{"ssh_ports":[%s],"panel_ports":[%s,%s],%s"seed_allow":[%s]}\n' "$ssh_csv" "$PORT" "$USER_PORT" "$dav" "$seed" >"$ETC/security.json.new"
[ -n "${FP_TEST_ETC:-}" ] || chown root:root "$ETC/security.json.new"
chmod 0644 "$ETC/security.json.new"
mv -f "$ETC/security.json.new" "$ETC/security.json"
if command -v restorecon >/dev/null; then restorecon "$ETC/security.json" || true; fi

# Both read security.json as they start: the agent writes the jails and starts
# fail2ban, the panel shows the Login protection page.
say "Restarting the root agent and the panel"
systemctl restart freepanel-privd
systemctl restart freepanel-api
say "Login protection is on"

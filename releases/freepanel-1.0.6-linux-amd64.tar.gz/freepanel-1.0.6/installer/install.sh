#!/usr/bin/env bash
# freePanel installer for AlmaLinux / Rocky / RHEL / CloudLinux 9 and 10, and Ubuntu 24.04.
#
# Run as root from an unpacked release (bin/, installer/, ui/):
#   ./installer/install.sh [--hostname NAME] [--port 7443] [--user-port 7444]
#                          [--open-firewall | --no-firewall]
#                          [--web [--php 8.3] [--no-php-ppa] [--no-waf] [--no-virus-scan]] [--mysql] [--postgres] [--dns [--nameservers NS1,NS2] [--ip ADDR]]
#                          [--mail [--spam]] [--dbadmin [--dbadmin-port 7445]] [--ftp] [--redis] [--memcached] [--webmail [--webmail-port 7446] [--pgp] [--dav]] [--apps] [--nginx] [--varnish]
#                          [--protect [--protect-allow ADDR[,ADDR...]]]
#                          [--license-key KEY] [--no-quotas]
#
# The admin and reseller panel listens on --port, the customer panel on
# --user-port. They are separate origins on purpose. --web also sets up
# website hosting: Apache with mod_ssl and PHP-FPM, PHP --php for new sites;
# on AlmaLinux, Rocky and RHEL 9 PHP comes from Remi's repository, on Ubuntu
# 24.04 from Ondřej Surý's PPA and on Debian 12 from his Debian repository,
# their keys pinned (8.2 to 8.5), or with --no-php-ppa from the distribution
# (8.3 on Ubuntu, 8.2 on Debian). With the web stack come the web application
# firewall, ModSecurity with the OWASP Core Rule Set, on in block mode, and the
# virus scanner, ClamAV, on where the server has 4 GB of memory; --no-waf and
# --no-virus-scan leave them out, and the closing lines say so. --mysql sets up
# MariaDB for customers' MySQL databases, --postgres PostgreSQL for their
# PostgreSQL databases. --dbadmin (with --web) adds the web database admin
# tool, phpMyAdmin and Adminer, on its own port. --dns sets up
# PowerDNS to serve each account's zone: --nameservers are the zones' name
# servers (default ns1 and ns2 of the hostname's domain) and --ip the
# address new zones point at (default the address of the default route).
# --mail (with the web stack) sets up email: Postfix for SMTP, Dovecot for
# IMAP with Sieve filters, and OpenDKIM to sign outgoing mail. --spam (with
# --mail) also installs rspamd from rspamd.com's repository, stopped and not
# enabled until spam filtering is turned on (modules/mail/README.md). --webmail
# (with --mail) adds webmail, Roundcube, on its own port; customers open it
# signed in from the panel, or sign in there with a mailbox's password. --pgp
# (with --webmail) adds PGP to webmail: GnuPG from the distribution and
# Roundcube's Enigma plugin, so a mailbox makes and keeps its keys there and
# signs, encrypts and decrypts mail. --dav (with --webmail) adds calendars
# and contacts (CalDAV and CardDAV): Radicale from freePanel's own package
# repository (EPEL 9 has none, Ubuntu 24.04's is too old), run as its own user on 127.0.0.1 only,
# reached through webmail's host and port at /dav/; a mailbox signs in
# with its own address and password, and nothing else listens. --ftp
# (with the web stack) sets up FTP: Pure-FTPd, encrypted sessions only, for
# the FTP logins customers add in the panel. --redis installs Redis from the
# distribution and lets each account turn on a Redis of its own, run as the
# account and listening on a Unix socket in a folder only the account can
# enter, never on a port (modules/redis); the package's own shared server stays
# off. --memcached does the same with Memcached, which has no passwords: each
# account's runs as the account and listens on a Unix socket in a folder only
# the account can enter, never on a port (modules/memcached).
# --apps (with the web stack) installs the system's own Node.js, Python and Ruby
# so an account can run an application of its own as itself, behind one of its
# sites (docs/api.md, "App hosting"). Nothing is fetched from anywhere but the
# distribution's repositories, and nothing runs until an account adds an app.
# Apache reaches an app over a socket of its account (/run/freepanel-apps), not
# a loopback port; the admin can allow ports in the panel, with the risk said.
# --nginx (with the web stack) installs nginx from the
# distribution's own repositories and leaves it stopped and disabled: nothing
# else changes, and Apache keeps ports 80 and 443. The admin turns the nginx
# front on in the panel (docs/api.md, "Web server"), which puts nginx on 80 and
# 443 and Apache on two loopback ports; turning it off puts every file back.
# --varnish (with the web stack) installs Varnish from the distribution's own
# repositories (AppStream on AlmaLinux, Rocky and RHEL; the archive on Ubuntu
# and Debian, so the OS's automatic security updates cover it) and leaves it
# stopped and disabled: nothing else changes. The admin turns the cache on in the
# panel (docs/api.md, "Web server"); it then listens on 127.0.0.1 only, behind
# the nginx front if that is on and behind Apache if not, and turning it off puts
# every file back.
# --protect installs fail2ban and turns on login protection and the deny list
# (modules/security/README.md). On AlmaLinux, Rocky and RHEL it bans through
# firewalld: where firewalld is off, it is installed and turned on, with
# sshd's ports, the panels' and the chosen options' ports opened in its
# configuration before it starts. On Ubuntu and Debian the deny list is an
# nftables table of its own. The one-line installer (packaging/bootstrap)
# always adds --protect unless --no-firewall is given. The address you
# are signed in from, and each --protect-allow address, go on the allow list
# before anything is turned on.
#
# The installer opens no port in the firewall unless --open-firewall is given,
# whatever the other options are: with it, the panel's two ports and each
# service option's ports are opened in firewalld or ufw (--web 80 and 443,
# --dns 53, --mail 25, 587, 143 and 993, --webmail 7446, --ftp 21 and
# 30000-30999, --dbadmin 7445). Without it nothing is opened and the closing
# lines list the ports to open yourself. --no-firewall says the same in so
# many words (and cannot go with --open-firewall or --protect).
#
# Disk quotas: packages' disk space is enforced as user quotas on the
# filesystem holding /home, and the installer turns them on (docs/disk-quotas.md).
# On ext4 they are on when it finishes. On XFS they turn on at the next restart
# (rootflags=uquota for /, uquota in /etc/fstab for a /home of its own); the
# installer never restarts the server. /etc/fstab and /etc/default/grub are
# copied to NAME.freepanel-orig before the first change. Inside a container
# the host decides quotas, and nothing is changed. --no-quotas leaves quotas
# as they are.
#
# --license-key stores the server's licence key once the panel is up (or set
# FREEPANEL_LICENSE_KEY, which keeps the key out of the process list). The
# panel then asks the licence service for a lease over outbound HTTPS, port
# 443. Without a key the panel opens on its Licence page; sites and mail work
# either way. A build that does not check a licence ignores the key.
#
# Safe to re-run: it upgrades binaries and restarts services, keeps the
# config, database and certificate, and never deletes anything.
set -euo pipefail

PREFIX=/usr/local/freepanel
ETC=/etc/freepanel
STATE=/var/lib/freepanel
PARK=/home/.freepanel-parked
PREINSTALL=/var/lib/freepanel-preinstall
SVC_USER=freepanel
PORT=7443
USER_PORT=7444
HOSTNAME_FQDN="$(hostname -f 2>/dev/null || hostname)"
OPEN_FIREWALL=0
NO_FIREWALL=0
NO_WAF=0
NO_SCAN=0
WEB=0
MAIL=0
SPAM=0
MYSQL=0
POSTGRES=0
DBADMIN=0
DBADMIN_PORT=7445
PROTECT=0
PROTECT_ALLOW=""
LICENSE_KEY="${FREEPANEL_LICENSE_KEY:-}"
# The database admin tool's downloads, pinned by checksum. Bump them together.
PMA_VERSION=5.2.3
PMA_URL=https://files.phpmyadmin.net/phpMyAdmin/$PMA_VERSION/phpMyAdmin-$PMA_VERSION-all-languages.tar.xz
PMA_SHA256=57881348297c4412f86c410547cf76b4d8a236574dd2c6b7d6a2beebe7fc44e3
ADMINER_VERSION=6.3.0
ADMINER_URL=https://github.com/vrana/adminer/releases/download/v$ADMINER_VERSION/adminer-$ADMINER_VERSION.php
ADMINER_SHA256=641e1a31e8cc333a309e202ef9446e1fd38c2069ed5f9ee509b80d70089d0503
# Adminer's MongoDB driver (a plugin since Adminer 5), the same release, in
# adminer.org's build made for the compiled adminer.php (the source plugin in
# git does not load beside it): kept beside Adminer so an update of it keeps
# the panel's MongoDB page working where an admin installed MongoDB
# (modules/mongodb).
ADMINER_MONGO_URL=https://www.adminer.org/static/download/$ADMINER_VERSION/drivers/mongo.php
ADMINER_MONGO_SHA256=3fd35c562d3f80e2e7846a8c6f93b83105670b8d3bc879002351c3c7f188a85f
WEBMAIL=0
WEBMAIL_PORT=7446
REDIS=0
MEMCACHED=0
PGP=0
DAV=0
# Webmail's download (the "complete" release, with its libraries), pinned by
# checksum.
RC_VERSION=1.7.6
RC_URL=https://github.com/roundcube/roundcubemail/releases/download/$RC_VERSION/roundcubemail-$RC_VERSION-complete.tar.gz
RC_SHA256=0168085bf0bfeeb5d4eca3b9730effbe610dbdb380a68567d292fec51f09db36
PHP=8.3
PHP_GIVEN=0
DNS=0
FTP=0
APPS=0
NGINX=0
VARNISH=0
# Disk quotas on the filesystem holding /home ("Disk quotas" below); --no-quotas
# leaves them as they are.
QUOTAS=1
# Pure-FTPd's passive data ports: below the kernel's own range for outgoing
# connections (32768 up), so opening them reaches nothing else.
FTP_PASV_MIN=30000
FTP_PASV_MAX=30999
FTP_GROUP=freepanel-ftpauth
NAMESERVERS=""
DNS_IP=""
REMI_KEY_FPR=B1ABF71E14C9D74897E198A8B19527F1478F8947 # installer/keys/RPM-GPG-KEY-remi.el9.asc
REMI_RELEASE_URL=https://rpms.remirepo.net/enterprise/remi-release-9.rpm
# EL10's: Remi's release package for 10 and the key it is signed with
# (installer/keys/RPM-GPG-KEY-remi.el10.asc). The fingerprint is empty until
# the key is pinned, and EL10's web stack stops with a message until then.
# shellcheck disable=SC2034 # read by name in install_remi ("${!fpr}", "${!url}")
REMI10_KEY_FPR=CF1DF0057CE85DFF5B2F2A37C2FD3B2C2A0948E4
# shellcheck disable=SC2034 # as above
REMI10_RELEASE_URL=https://rpms.remirepo.net/enterprise/remi-release-10.rpm
# rspamd (--spam) comes from rspamd.com's own stable repository. Its signing
# key is fetched at install time and imported only if it has this
# fingerprint (the Rspamd packages key), so none of it ships in the release.
# EPEL on RHEL: RHEL's own repositories have no epel-release, so it comes
# from EPEL's site and is installed only if signed by EPEL's key for that
# release, which ships with the installer (installer/keys/RPM-GPG-KEY-EPEL-N)
# and is checked by this fingerprint first. An empty fingerprint is one not
# pinned yet: that release's EPEL is then taken only if the admin installed
# epel-release already. AlmaLinux, Rocky and CloudLinux carry epel-release.
# shellcheck disable=SC2034 # read by name in install_epel_rhel ("${!fpr}")
EPEL9_KEY_FPR=FF8AD1344597106ECE813B918A3872BF3228467C
# shellcheck disable=SC2034 # as above
EPEL10_KEY_FPR=7D8D15CBFC4E62688591FB2633D98517E37ED158
EPEL_RELEASE_URL_PREFIX=https://dl.fedoraproject.org/pub/epel/epel-release-latest-
RSPAMD_KEY_FPR=3FA347D5E599BE4595CA2576FFA232EDBF21E25E
RSPAMD_KEY_URL=https://rspamd.com/rpm/rspamd.asc
# shellcheck disable=SC2016 # $basearch is dnf's own variable
# @EL@ becomes the EL major release (9 or 10); rspamd.com keeps one tree per release.
RSPAMD_REPO_URL='https://rspamd.com/rpm-stable/centos-@EL@/$basearch/'
RSPAMD_PKG=rspamd
RSPAMD_REPO_FILE=/etc/yum.repos.d/freepanel-rspamd.repo
# PHP 8.2 to 8.5 on Ubuntu 24.04 (--web) come from Ondřej Surý's PPA. Its
# signing key ships with the installer (installer/keys/ondrej-php.asc) and is
# trusted only if it is that one key with this fingerprint (Launchpad's
# signing_key_fingerprint for ~ondrej/+archive/ubuntu/php), and only for the
# PPA (Signed-By). Nothing is fetched to trust it. --no-php-ppa leaves the PPA
# out: the distribution's PHP 8.3 alone.
ONDREJ_KEY_FPR=B8DC7E53946656EFBCE4C1DD71DAEAAB4AD4CAB6
ONDREJ_URL=https://ppa.launchpadcontent.net/ondrej/php/ubuntu
ONDREJ_KEYRING=/etc/apt/keyrings/freepanel-ondrej-php.asc
ONDREJ_SOURCES=/etc/apt/sources.list.d/freepanel-ondrej-php.sources
ONDREJ_KEYFILE=installer/keys/ondrej-php.asc
# On Debian 12 the same versions come from Ondřej Surý's Debian repository
# (packages.sury.org), set up the same way and under the same file names (the
# panel looks for ONDREJ_SOURCES), with its own key, pinned the same way: two
# independent sources gave this fingerprint (packages.sury.org over HTTPS and
# keyserver.ubuntu.com), and bookworm's signed index verifies with it.
SURY_URL=https://packages.sury.org/php
SURY_KEY_FPR=15058500A0235D97F5D10063B188E2B695BD4743
SURY_KEYFILE=installer/keys/sury-php.asc
PHP_PPA=1
# On Ubuntu rspamd comes from rspamd.com's apt repository for noble, which
# the same key signs. That key ships in the release (RSPAMD_APT_KEYFILE,
# from keyserver.ubuntu.com) and is used only if it is the key with
# RSPAMD_KEY_FPR alone: nothing is fetched to trust it.
RSPAMD_APT_URL=https://rspamd.com/apt-stable/
RSPAMD_APT_KEYFILE=installer/keys/rspamd.asc
RSPAMD_APT_KEY=/etc/apt/keyrings/freepanel-rspamd.asc
RSPAMD_APT_SOURCES=/etc/apt/sources.list.d/freepanel-rspamd.sources
RSPAMD_APT_PIN=/etc/apt/preferences.d/freepanel-rspamd
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

say() { printf '\033[1m==> %s\033[0m\n' "$*"; }
die() { printf 'install: %s\n' "$*" >&2; exit 1; }

while [ $# -gt 0 ]; do
  case "$1" in
    --hostname) HOSTNAME_FQDN="${2:?}"; shift 2 ;;
    --port) PORT="${2:?}"; shift 2 ;;
    --user-port) USER_PORT="${2:?}"; shift 2 ;;
    --open-firewall) OPEN_FIREWALL=1; shift ;;
    --no-firewall) NO_FIREWALL=1; shift ;;
    --web) WEB=1; shift ;;
    --mail) MAIL=1; shift ;;
    --spam) SPAM=1; shift ;;
    --mysql) MYSQL=1; shift ;;
    --postgres) POSTGRES=1; shift ;;
    --dbadmin) DBADMIN=1; shift ;;
    --dbadmin-port) DBADMIN_PORT="${2:?}"; shift 2 ;;
    --webmail) WEBMAIL=1; shift ;;
    --redis) REDIS=1; shift ;;
    --memcached) MEMCACHED=1; shift ;;
    --webmail-port) WEBMAIL_PORT="${2:?}"; shift 2 ;;
    --pgp) PGP=1; shift ;;
    --dav) DAV=1; shift ;;
    --protect) PROTECT=1; shift ;;
    --protect-allow) PROTECT_ALLOW="${2:?}"; shift 2 ;;
    --php) PHP="${2:?}"; PHP_GIVEN=1; shift 2 ;;
    --no-php-ppa) PHP_PPA=0; shift ;;
    --license-key) LICENSE_KEY="${2:?}"; shift 2 ;;
    --dns) DNS=1; shift ;;
    --nameservers) NAMESERVERS="${2:?}"; shift 2 ;;
    --ip) DNS_IP="${2:?}"; shift 2 ;;
    --ftp) FTP=1; shift ;;
    --apps) APPS=1; shift ;;
    --nginx) NGINX=1; shift ;;
    --varnish) VARNISH=1; shift ;;
    --no-quotas) QUOTAS=0; shift ;;
    --no-waf) NO_WAF=1; shift ;;
    --no-virus-scan) NO_SCAN=1; shift ;;
    -h|--help) sed -n '2,101p' "$0"; exit 0 ;;
    *) die "unknown option $1" ;;
  esac
done

[ "$(id -u)" -eq 0 ] || die "run as root"
[ "$OPEN_FIREWALL" -eq 1 ] && [ "$NO_FIREWALL" -eq 1 ] && die "--open-firewall and --no-firewall contradict each other"
for p in "$PORT" "$USER_PORT" "$DBADMIN_PORT" "$WEBMAIL_PORT"; do
  if ! [[ "$p" =~ ^[0-9]+$ ]] || [ "$p" -lt 1 ] || [ "$p" -gt 65535 ]; then
    die "bad port $p"
  fi
done
[ "$PORT" != "$USER_PORT" ] || die "--port and --user-port must differ"
[ "$SPAM" -eq 0 ] || [ "$MAIL" -eq 1 ] || die "--spam needs --mail"
[ "$PGP" -eq 0 ] || [ "$WEBMAIL" -eq 1 ] || die "--pgp needs --webmail"
# Devices reach calendars on webmail's host and port, whose site this run writes.
[ "$DAV" -eq 0 ] || [ "$WEBMAIL" -eq 1 ] || die "--dav needs --webmail (calendars and contacts are served on webmail's host and port)"
[ "$PROTECT" -eq 0 ] || [ "$NO_FIREWALL" -eq 0 ] || die "--protect and --no-firewall contradict each other"
if [ -n "$PROTECT_ALLOW" ]; then
  [ "$PROTECT" -eq 1 ] || die "--protect-allow needs --protect"
  # Addresses and ranges only: what goes in security.json is not quoted.
  [[ "$PROTECT_ALLOW" =~ ^[0-9A-Fa-f.:/]+(,[0-9A-Fa-f.:/]+)*$ ]] || die "bad --protect-allow $PROTECT_ALLOW; give IP addresses or ranges, comma separated"
fi
if [ "$DBADMIN" -eq 1 ]; then
  [ "$WEB" -eq 1 ] || die "--dbadmin needs --web (it is served by Apache with PHP)"
  [ "$MYSQL" -eq 1 ] || [ "$POSTGRES" -eq 1 ] || die "--dbadmin needs --mysql or --postgres"
  if [ "$DBADMIN_PORT" = "$PORT" ] || [ "$DBADMIN_PORT" = "$USER_PORT" ]; then
    die "--dbadmin-port must differ from the panels' ports"
  fi
  [[ "$PMA_SHA256" =~ ^[0-9a-f]{64}$ && "$ADMINER_SHA256" =~ ^[0-9a-f]{64}$ ]] ||
    die "this release has no pinned checksum for the database admin tool's downloads"
fi
if [ "$WEBMAIL" -eq 1 ]; then
  [ "$WEB" -eq 1 ] || die "--webmail needs --web (it is served by Apache with PHP)"
  [ "$MAIL" -eq 1 ] || [ -f /etc/freepanel/mail.json ] || die "--webmail needs --mail"
  if [ "$WEBMAIL_PORT" = "$PORT" ] || [ "$WEBMAIL_PORT" = "$USER_PORT" ] ||
    { [ "$DBADMIN" -eq 1 ] && [ "$WEBMAIL_PORT" = "$DBADMIN_PORT" ]; }; then
    die "--webmail-port must differ from the panels' and the database admin tool's ports"
  fi
  [[ "$RC_SHA256" =~ ^[0-9a-f]{64}$ ]] || die "this release has no pinned checksum for webmail's download"
fi
[[ "$HOSTNAME_FQDN" =~ ^[A-Za-z0-9.-]+$ ]] || die "bad --hostname"
# A key is letters, digits, dots, dashes and underscores (and = if padded).
[[ -z "$LICENSE_KEY" || "$LICENSE_KEY" =~ ^[A-Za-z0-9._=-]{1,4096}$ ]] || die "bad --license-key"
# The versions the web module offers (modules/web/phpfpm).
case "$PHP" in
  7.4|8.0|8.1|8.2|8.3|8.4|8.5) PHP_PKG="php${PHP/./}" ;;
  *) die "bad --php $PHP; choose one of 7.4 8.0 8.1 8.2 8.3 8.4 8.5" ;;
esac
if [ "$WEBMAIL" -eq 1 ]; then
  case "$PHP" in
    7.4|8.0) die "--webmail needs --php 8.1 or later" ;;
  esac
fi
if [ "$DNS" -eq 1 ]; then
  if [ -z "$NAMESERVERS" ]; then
    # ns1 and ns2 of the hostname's domain: server.host.example gives
    # ns1.host.example; a two-label hostname is its own domain.
    NS_DOMAIN="$HOSTNAME_FQDN"
    [[ "$HOSTNAME_FQDN" == *.*.* ]] && NS_DOMAIN="${HOSTNAME_FQDN#*.}"
    NAMESERVERS="ns1.$NS_DOMAIN,ns2.$NS_DOMAIN"
  fi
  [[ "$NAMESERVERS" =~ ^[A-Za-z0-9.-]+(,[A-Za-z0-9.-]+)*$ ]] || die "bad --nameservers $NAMESERVERS"
  if [ -z "$DNS_IP" ]; then
    DNS_IP="$(ip -o -4 route get 192.0.2.1 2>/dev/null | sed -n 's/.* src \([0-9.]*\).*/\1/p')"
    [ -n "$DNS_IP" ] || die "could not find this server's IPv4 address; give it with --ip"
  fi
  [[ "$DNS_IP" =~ ^[0-9]{1,3}(\.[0-9]{1,3}){3}$ ]] || die "bad --ip $DNS_IP"
fi
for b in freepanel-api freepanel-privd freepanelctl freepanel-milter freepanel-files freepanel-ftpauth freepanel-maillist; do
  [ -x "$SRC/bin/$b" ] || die "missing $SRC/bin/$b (build with 'make release' first)"
done

# ---- Operating system ------------------------------------------------------
# detect_os sets FAMILY (el or ubuntu), OS_ID (os-release's ID) and, on EL,
# EL_MAJOR (9 or 10), from OS_RELEASE. AlmaLinux 9 and 10, Rocky Linux 9 and
# 10, RHEL 9, Ubuntu 24.04 and 26.04 and Debian 12 are proven by the VM runs;
# RHEL 10 and CloudLinux 9 and 10 are taken but warned about until a run
# proves them (issue #726).
# CloudLinux is an EL rebuild with its own repository names (see enable_crb).
OS_RELEASE=/etc/os-release
unproven() {
  echo "  Warning: freePanel has not yet been proven on a real $1 server." >&2
}
detect_os() {
  # shellcheck source=/dev/null
  . "$OS_RELEASE"
  OS_ID="${ID:-}"
  EL_MAJOR=""
  case "${ID:-}:${VERSION_ID:-}" in
    almalinux:9*|almalinux:10*|rocky:9*|rocky:10*|rhel:9*) FAMILY=el EL_MAJOR="${VERSION_ID%%.*}" ;;
    rhel:10*) FAMILY=el EL_MAJOR=10
      unproven "RHEL 10" ;;
    cloudlinux:9*|cloudlinux:10*) FAMILY=el EL_MAJOR="${VERSION_ID%%.*}"
      unproven "CloudLinux $EL_MAJOR" ;;
    ubuntu:24.04) FAMILY=ubuntu ;;
    # Ubuntu 26.04 (resolute): the same family; its own PHP is 8.5.
    ubuntu:26.04) FAMILY=ubuntu ;;
    # Debian 12 takes the Ubuntu (apt) family's names and paths, which are
    # Debian's own; DEB_DISTRO says where the two differ (#716).
    debian:12*) FAMILY=ubuntu ;;
    *) die "unsupported OS ${PRETTY_NAME:-unknown}; need AlmaLinux/Rocky/RHEL/CloudLinux 9 or 10, Ubuntu 24.04 or 26.04, or Debian 12" ;;
  esac
  case "$EL_MAJOR" in ""|9|10) ;; *) die "unsupported OS ${PRETTY_NAME:-unknown} (version ${VERSION_ID:-unknown})" ;; esac
}
# require_rhel_registered: RHEL's repositories (and so every package) come
# through the system's Red Hat registration. The installer never asks for,
# takes or keeps a Red Hat login: an unregistered system stops here.
require_rhel_registered() {
  [ "$OS_ID" = rhel ] || return 0
  command -v subscription-manager >/dev/null ||
    die "this RHEL system has no subscription-manager, so its Red Hat registration cannot be checked; install subscription-manager, register the system, and run the installer again"
  subscription-manager status >/dev/null 2>&1 ||
    die "this RHEL system is not registered with Red Hat, so it has no repositories to install from. Register it yourself (subscription-manager register) and run the installer again; the installer never asks for or keeps your Red Hat login"
}
detect_os
require_rhel_registered
# DEB_DISTRO is ubuntu or debian on the apt family; CODENAME its release
# (noble, resolute, bookworm), the suite of the third-party apt repositories.
DEB_DISTRO=""
CODENAME=""
if [ "$FAMILY" = ubuntu ]; then
  DEB_DISTRO=$ID
  CODENAME=${VERSION_CODENAME:-}
  [ -n "$CODENAME" ] || die "/etc/os-release names no VERSION_CODENAME"
fi
# Debian 12 has PHP 8.2 in its own archive. 8.3 to 8.5 come from Ondřej
# Surý's Debian repository, the PPA's Debian equivalent (SURY_URL), which the
# web stack sets up as it does the PPA on Ubuntu; --no-php-ppa leaves it out,
# and 8.2 alone. Set before the names below use it.
if [ "$DEB_DISTRO" = debian ]; then
  [ "$PHP_GIVEN" -eq 1 ] || PHP=8.2
  case "$PHP" in
    8.2) ;;
    8.3|8.4|8.5) [ "$PHP_PPA" -eq 1 ] || die "--php $PHP needs Ondřej Surý's PHP repository; leave out --no-php-ppa, or give --php 8.2 (the distribution's)" ;;
    *) die "--php $PHP is not offered on Debian 12; choose one of 8.2 8.3 8.4 8.5" ;;
  esac
  ONDREJ_URL=$SURY_URL
  ONDREJ_KEY_FPR=$SURY_KEY_FPR
  ONDREJ_KEYFILE=$SURY_KEYFILE
fi
# Ubuntu 26.04 likewise: the PPA has no resolute suite (its Release is a 404,
# Nov 2026), but Surý's own repository (SURY_URL) does, with the same key; the
# other versions come from there, set up the same way.
if [ "$DEB_DISTRO" = ubuntu ] && [ "${VERSION_ID:-}" = 26.04 ]; then
  ONDREJ_URL=$SURY_URL
  ONDREJ_KEY_FPR=$SURY_KEY_FPR
  ONDREJ_KEYFILE=$SURY_KEYFILE
fi
command -v systemctl >/dev/null || die "systemd is required"

# ---- Memory -----------------------------------------------------------------
# A rough guide, not a limit: what the panel and each chosen part take when the
# server is idle and lightly used, in MB. Everything together is about 2.5 GB;
# the VM checks install everything on 3 GB (test/vm/alma-boot.sh). On less,
# the install goes on but the kernel may stop services when memory runs out,
# so the installer warns before it starts (the one-line installer repeats its
# warnings at the end). MEMINFO is the file read, so tests can point it
# elsewhere.
MEMINFO=${MEMINFO:-/proc/meminfo}
MEM_LOW=""
# memory_need prints the MB the chosen options need, then each chosen option
# that takes 192 MB or more, as "--name MB", largest first.
memory_need() {
  local need=384 big=()
  [ "$WEB" -eq 0 ] || need=$((need + 256))
  [ "$MAIL" -eq 0 ] || need=$((need + 192))
  [ "$SPAM" -eq 0 ] || { need=$((need + 512)); big+=("--spam 512"); }
  [ "$MYSQL" -eq 0 ] || { need=$((need + 384)); big+=("--mysql 384"); }
  [ "$POSTGRES" -eq 0 ] || { need=$((need + 192)); big+=("--postgres 192"); }
  [ "$APPS" -eq 0 ] || { need=$((need + 192)); big+=("--apps 192"); }
  [ "$DNS" -eq 0 ] || need=$((need + 96))
  [ "$WEBMAIL" -eq 0 ] || need=$((need + 96))
  [ "$DBADMIN" -eq 0 ] || need=$((need + 32))
  [ "$DAV" -eq 0 ] || need=$((need + 32))
  [ "$REDIS" -eq 0 ] || need=$((need + 32))
  [ "$MEMCACHED" -eq 0 ] || need=$((need + 32))
  [ "$NGINX" -eq 0 ] || need=$((need + 32))
  [ "$VARNISH" -eq 0 ] || { need=$((need + 288)); big+=("--varnish 288"); }
  [ "$FTP" -eq 0 ] || need=$((need + 16))
  [ "$PROTECT" -eq 0 ] || need=$((need + 48))
  echo "$need"
  printf '%s\n' "${big[@]}"
}
# memory_check sets MEM_LOW to a one-line note when the server has less memory
# than memory_need, and prints it as a warning. It never stops the install.
memory_check() {
  local total need list
  total="$(awk '$1 == "MemTotal:" { print int($2 / 1024) }' "$MEMINFO" 2>/dev/null || true)"
  [[ "$total" =~ ^[0-9]+$ ]] || return 0
  { read -r need; list="$(paste -sd, - | sed 's/,/, /g; s/ \([0-9]*\)\(,\|$\)/ (about \1 MB)\2/g')"; } < <(memory_need)
  [ "$total" -lt "$need" ] || return 0
  MEM_LOW="This server has ${total} MB of memory; the options chosen need about ${need} MB."
  [ -z "$list" ] || MEM_LOW="$MEM_LOW To use less, leave out some of: $list."
  echo "  Warning: $MEM_LOW" >&2
}
memory_check

# ---- Operating system layer ------------------------------------------------
# Every name that differs between the families is set here, once, so the rest
# of the installer has one line for both (internal/platform keeps the same
# names for the panel; its TestInstallerMatchesLayout holds the two together).
# PHP_TAG is --php as the family writes it in names (83 on EL, 8.3 on Ubuntu).
if [ "$FAMILY" = el ]; then
  NOLOGIN=/sbin/nologin
  CRON_UNIT=crond
  WEB_UNIT=httpd
  WEB_CTL=httpd
  WEB_USER=apache
  WEB_GROUP=apache
  WEB_CONF=/etc/httpd/conf.d
  WEB_SITES=/etc/httpd/conf.d
  WEB_LOG=/var/log/httpd
  WEB_ACCESS_LOG=logs/access_log
  WEB_ACCESS_FORMAT=combined
  PHP_TAG=${PHP/./}
  PHP_UNIT=php${PHP_TAG}-php-fpm
  PHP_POOL_DIR=/etc/opt/remi/php${PHP_TAG}/php-fpm.d
  PHP_SOCK_DIR=/var/opt/remi/php${PHP_TAG}/run/php-fpm
  PHP_FPM_BIN=/opt/remi/php${PHP_TAG}/root/usr/sbin/php-fpm
  PHP_CLI=/opt/remi/php${PHP_TAG}/root/usr/bin/php
  POSTFIX_UNIT=postfix
  # No AppArmor profile for the jail shell: EL leaves user namespaces open.
  JAIL_APPARMOR=
  # The names EL10 changes (internal/platform, ForRelease).
  if [ "$EL_MAJOR" -ge 10 ]; then
    # Valkey in place of Redis: the same protocol and configuration.
    REDIS_PKG=valkey
    REDIS_UNIT=valkey.service
    REDIS_SERVER=valkey-server
  else
    REDIS_PKG=redis
    REDIS_UNIT=redis.service
    REDIS_SERVER=redis-server
  fi
else
  NOLOGIN=/usr/sbin/nologin
  CRON_UNIT=cron
  WEB_UNIT=apache2
  WEB_CTL=apache2ctl
  WEB_USER=www-data
  WEB_GROUP=www-data
  WEB_CONF=/etc/apache2/conf-enabled
  WEB_SITES=/etc/apache2/sites-enabled
  WEB_LOG=/var/log/apache2
  WEB_ACCESS_LOG=/var/log/apache2/other_vhosts_access.log
  WEB_ACCESS_FORMAT=vhost_combined
  PHP_TAG=$PHP
  PHP_UNIT=php${PHP_TAG}-fpm
  PHP_POOL_DIR=/etc/php/${PHP_TAG}/fpm/pool.d
  PHP_SOCK_DIR=/run/freepanel-php/${PHP_TAG}
  PHP_FPM_BIN=/usr/sbin/php-fpm${PHP_TAG}
  PHP_CLI=/usr/bin/php${PHP_TAG}
  # postfix.service only starts the instances; the default one is this.
  POSTFIX_UNIT=postfix@-
  # Ubuntu 26.04's Postfix (3.10) runs the default instance in postfix.service
  # itself, which conflicts with postfix@-.service (platform.Here).
  [ "${VERSION_ID:-}" != 26.04 ] || POSTFIX_UNIT=postfix
  JAIL_APPARMOR=/etc/apparmor.d/freepanel-jailshell
  REDIS_PKG=redis-server
  REDIS_UNIT=redis-server.service
  REDIS_SERVER=redis-server
  # Debian 12 does not restrict user namespaces, and its AppArmor (3.0) cannot
  # read the profile's abi 4.0: no profile, as on EL.
  [ "$DEB_DISTRO" != debian ] || JAIL_APPARMOR=
fi
# pkg_update refreshes the package lists (apt only: dnf does it itself).
pkg_update() {
  [ "$FAMILY" = el ] || DEBIAN_FRONTEND=noninteractive apt-get -o DPkg::Lock::Timeout=600 -y -q update
}
# pkg_install installs packages by the family's own names.
pkg_install() {
  if [ "$FAMILY" = el ]; then
    dnf -y -q install "$@"
  else
    DEBIAN_FRONTEND=noninteractive apt-get -o DPkg::Lock::Timeout=600 -y -q install "$@"
  fi
}
# Ubuntu 24.04 has PHP 8.3 in its own archive, and only that; Ubuntu 26.04
# has 8.5. The others of 8.2 to 8.5 come from the PPA, on 26.04 from Surý's
# own repository (modules/web/phpfpm, UbuntuSupported). Without --php, a server gets its distribution's own.
# DISTRO_PHP is that version.
if [ "$FAMILY" = ubuntu ] && [ "$DEB_DISTRO" = ubuntu ]; then
  DISTRO_PHP=8.3
  [ "$VERSION_ID" != 26.04 ] || DISTRO_PHP=8.5
  [ "$PHP_GIVEN" -eq 1 ] || PHP=$DISTRO_PHP
  case "$PHP" in
    "$DISTRO_PHP") ;;
    8.2|8.3|8.4|8.5) [ "$PHP_PPA" -eq 1 ] || die "--php $PHP needs the PHP PPA; leave out --no-php-ppa, or give --php $DISTRO_PHP (the distribution's)" ;;
    *) die "--php $PHP is not offered on Ubuntu $VERSION_ID; choose one of 8.2 8.3 8.4 8.5" ;;
  esac
elif [ "$FAMILY" = el ]; then
  [ "$PHP_PPA" -eq 1 ] || die "--no-php-ppa is for Ubuntu"
fi
# pkg_install_held UNIT... -- PACKAGE...: pkg_install, with none of the
# UNITs started by the install. Ubuntu's packages start their services as
# they install, on the package's stock settings (Dovecot's and Pure-FTPd's
# let system users sign in, rspamd's asks third parties about mail), before
# freePanel's are written; dnf starts nothing. So on Ubuntu each UNIT is
# masked for the install alone, under /run, which a reboot clears whatever
# becomes of this run: the packages' scripts skip a masked unit (invoke-rc.d
# and deb-systemd-invoke both look), and still enable it as they would.
pkg_install_held() {
  local units=() rc=0
  while [ $# -gt 0 ] && [ "$1" != -- ]; do
    units+=("$1")
    shift
  done
  [ "${1:-}" = -- ] || die "pkg_install_held: no -- before the packages"
  shift
  if [ "$FAMILY" = el ]; then
    pkg_install "$@"
    return
  fi
  systemctl mask --runtime --quiet -- "${units[@]}"
  pkg_install "$@" || rc=$?
  systemctl unmask --runtime --quiet -- "${units[@]}" || true
  [ "$rc" -eq 0 ] || die "could not install $*"
}
# Mail is for the names an account's sites answer on, which the web module keeps.
[ "$MAIL" -eq 0 ] || [ "$WEB" -eq 1 ] || [ -f "$ETC/web.json" ] || die "--mail needs the web stack: add --web"
# FTP logins are name@domain for the names the web module keeps, and use the
# server's certificate, which it makes.
[ "$FTP" -eq 0 ] || [ "$WEB" -eq 1 ] || [ -f "$ETC/web.json" ] || die "--ftp needs the web stack: add --web"
# App hosting passes a site to the account's own program through Apache.
[ "$APPS" -eq 0 ] || [ "$WEB" -eq 1 ] || [ -f "$ETC/web.json" ] || die "--apps needs the web stack: add --web"
# The nginx front sits in front of the web stack's Apache.
[ "$NGINX" -eq 0 ] || [ "$WEB" -eq 1 ] || [ -f "$ETC/web.json" ] || die "--nginx needs the web stack: add --web"
# So does the Varnish cache, between the front and Apache's sites.
[ "$VARNISH" -eq 0 ] || [ "$WEB" -eq 1 ] || [ -f "$ETC/web.json" ] || die "--varnish needs the web stack: add --web"

say "Installing packages"
if [ "$FAMILY" = el ]; then
  pkg_install openssl shadow-utils util-linux procps-ng cronie quota bubblewrap git-core tar nftables
  # The panel's log viewer reads /var/log/secure, messages and maillog
  # (internal/privd/serverlogs.go); an EL10 cloud image keeps only the journal
  # (Rocky 10, run 42414535415: check 196 found no sign-in log), so rsyslog
  # writes them, as on EL9.
  if ! rpm -q rsyslog >/dev/null 2>&1; then
    pkg_install rsyslog
    systemctl enable --now rsyslog
  fi
else
  pkg_update
  pkg_install openssl passwd util-linux procps cron quota bubblewrap git tar nftables
  # Server updates (modules/updates): unattended-upgrades runs the security
  # updates and the daily run; update-notifier-common writes
  # /run/reboot-required and apt's update stamp, which the page reads.
  pkg_install unattended-upgrades
  pkg_install update-notifier-common ||
    echo "  Warning: update-notifier-common is not available; the server updates page cannot tell when a reboot is needed." >&2
  # Ubuntu has no app hosting here yet, so no Ruby: only cpanm (Perl code
  # alone) for customers' Perl modules (modules/libraries), run by the panel as
  # the account. php-pear comes with the web stack (--web), with the PHP the
  # panel serves.
  pkg_install cpanminus
fi

# ---- Kernel guard for CVE-2026-98432 -----------------------------------------
# A remote use-after-free in the kernel's IPv4 TCP connection setup (Critical;
# exploited through MPTCP listeners, reached with the Record Route or Timestamp
# IP options). Until the server runs a fixed kernel, and after, as no hosting
# service needs either: Multipath TCP is turned off (installer/kernel/mptcp.conf;
# a kernel without MPTCP has no such setting, which is fine), and inbound IPv4
# TCP packets that carry IP options are dropped by a table of their own
# (installer/kernel/ipopts.nft, freepanel-ipopts.service). --no-firewall
# leaves the packet rule out, and says so.
say "Guarding the kernel against CVE-2026-98432 (MPTCP off, IPv4 TCP packets with IP options dropped)"
install -m 0644 -o root -g root "$SRC/installer/kernel/mptcp.conf" /etc/sysctl.d/90-freepanel-mptcp.conf
sysctl -e -q -p /etc/sysctl.d/90-freepanel-mptcp.conf ||
  echo "  Warning: could not turn Multipath TCP off now; it is turned off at the next boot (/etc/sysctl.d/90-freepanel-mptcp.conf)." >&2
if [ "$NO_FIREWALL" -eq 1 ]; then
  echo "  WARNING: --no-firewall was given, so IPv4 TCP packets with IP options are NOT dropped. Keep the kernel updated (CVE-2026-98432)." >&2
else
  install -d -m 0755 "$ETC"
  install -m 0644 -o root -g root "$SRC/installer/kernel/ipopts.nft" "$ETC/ipopts.nft"
  install -m 0644 -o root -g root "$SRC/installer/systemd/freepanel-ipopts.service" /etc/systemd/system/
  systemctl daemon-reload
  systemctl enable --quiet freepanel-ipopts
  # restart, not start: a re-run loads the file again (nft -f replaces the table).
  systemctl restart freepanel-ipopts ||
    die "could not load the rule that drops IPv4 TCP packets with IP options (systemctl status freepanel-ipopts); give --no-firewall to go without it"
fi

# ---- freePanel's package repository ----------------------------------------
# enable-repo.sh (packaging/repo, shipped in installer/repo) writes
# /etc/yum.repos.d/freepanel.repo (EL9, setup-repo.sh) or
# /etc/apt/sources.list.d/freepanel.sources (Ubuntu 24.04 and Debian 12, each
# its own suite, setup-apt.sh) from
# repo.conf when that says enabled=yes, trusting only the project's key
# (installer/keys, whose fingerprint repo.conf names); while it says no, dnf
# and apt are left as they are. It runs on every run, so a new address or
# key, or a withdrawal, reaches each server at its next run. A checkout that
# has no installer/repo (not a release) skips it.
if [ -x "$SRC/installer/repo/enable-repo.sh" ]; then
  say "Setting up freePanel's package repository"
  "$SRC/installer/repo/enable-repo.sh" "$SRC/installer/repo/repo.conf" "$SRC/installer/keys/RPM-GPG-KEY-freepanel" ||
    die "could not set up freePanel's package repository (installer/repo/repo.conf)"
  # apt reads a new or changed source only after an update.
  pkg_update
fi

# ---- Service user and directories ------------------------------------------
say "Creating the $SVC_USER service user"
if ! getent passwd "$SVC_USER" >/dev/null; then
  useradd --system --user-group --home-dir "$STATE" --no-create-home --shell "$NOLOGIN" \
    --comment "freePanel API" "$SVC_USER"
fi

# Database clients that read dumps from another server (account imports)
# run as this user, which owns nothing and can open nothing of the agent's.
if ! getent passwd fploader >/dev/null; then
  useradd --system --user-group --home-dir / --no-create-home --shell "$NOLOGIN" \
    --comment "freePanel import loader" fploader
fi

install -d -m 0755 -o root -g root "$PREFIX" "$PREFIX/bin" "$PREFIX/ui"
install -d -m 0750 -o root -g "$SVC_USER" "$ETC" "$ETC/tls"
install -d -m 0750 -o "$SVC_USER" -g "$SVC_USER" "$STATE"
install -d -m 0700 -o root -g root "$PARK"

# The system's own files the installer and the root agent change are kept
# in $PREINSTALL as they were before freePanel's first change, for a later
# uninstall to put back: each once, never overwritten, with postconf's view
# of Postfix. Only regular files are copied, never through a link and with
# none above them, as root's own; the owner and mode they had are in
# $PREINSTALL/state/files. A link is listed in $PREINSTALL/links with its
# target; anything else that is neither, a link whose target a line can't
# hold (a newline or a tab in it) and a file with a link above it are in
# $PREINSTALL/other, and a file that wasn't there in $PREINSTALL/absent. The
# changes that aren't files (firewall, group members, SELinux, services)
# are kept as text in $PREINSTALL/state, each once before the first change
# to it; a tool that isn't installed is kept as absent, and one that fails
# as failed, then what it said. On a server first installed before this was
# kept, those are already changed, so nothing is kept there
# ($PREINSTALL/legacy says so).
# Root only, outside $STATE, which the service user owns.
if [ ! -d "$PREINSTALL" ]; then
  install -d -m 0700 -o root -g root "$PREINSTALL"
  if [ -f "$ETC/freepanel.json" ]; then
    printf 'Installed before the system files were kept: nothing here to put back.\n' >"$PREINSTALL/legacy"
  fi
fi
chown root:root "$PREINSTALL"
chmod 0700 "$PREINSTALL"
# shellcheck source=/dev/null
. "$(dirname "${BASH_SOURCE[0]}")/keep.sh"

# ---- Binaries and front end ------------------------------------------------
say "Installing binaries"
for b in freepanel-api freepanel-privd freepanelctl freepanel-milter freepanel-files freepanel-jailshell freepanel-ftpauth; do
  install -m 0755 -o root -g root "$SRC/bin/$b" "$PREFIX/bin/$b.new"
  mv -f "$PREFIX/bin/$b.new" "$PREFIX/bin/$b"
done
ln -sfn "$PREFIX/bin/freepanelctl" /usr/local/sbin/freepanelctl
# What the panel's "Turn on login protection" button runs, as root, on a server
# installed without --protect (installer/protect.sh; the root agent's
# protect job).
install -d -m 0755 -o root -g root "$PREFIX/libexec"
install -m 0755 -o root -g root "$SRC/installer/protect.sh" "$PREFIX/libexec/freepanel-protect.new"
mv -f "$PREFIX/libexec/freepanel-protect.new" "$PREFIX/libexec/freepanel-protect"
# Mailing lists (modules/mail/lists.go): Dovecot runs freepanel-maillist at
# delivery, as the list's account, from this folder, which holds nothing else.
install -d -m 0755 -o root -g root "$PREFIX/bin/maillist"
install -m 0755 -o root -g root "$SRC/bin/freepanel-maillist" "$PREFIX/bin/maillist/freepanel-maillist.new"
mv -f "$PREFIX/bin/maillist/freepanel-maillist.new" "$PREFIX/bin/maillist/freepanel-maillist"
if command -v restorecon >/dev/null; then restorecon -R "$PREFIX/bin/maillist" || true; fi
# freePanel's terms and the third-party notices (LICENSE, THIRD_PARTY_NOTICES),
# when the release carries them: a tree run from a checkout without them
# installs the rest as before.
install -d -m 0755 -o root -g root "$PREFIX/share" "$PREFIX/share/doc"
for d in LICENSE THIRD_PARTY_NOTICES; do
  if [ -f "$SRC/$d" ]; then
    install -m 0644 -o root -g root "$SRC/$d" "$PREFIX/share/doc/$d.new"
    mv -f "$PREFIX/share/doc/$d.new" "$PREFIX/share/doc/$d"
  fi
done
# Jailed accounts' login shell: bash inside bubblewrap, as the account.
grep -qx "$PREFIX/bin/freepanel-jailshell" /etc/shells || echo "$PREFIX/bin/freepanel-jailshell" >> /etc/shells
# Ubuntu lets a process make a user namespace only when its AppArmor profile
# allows it (kernel.apparmor_restrict_unprivileged_userns), and bwrap needs
# one: installer/apparmor/freepanel-jailshell gives the jail shell that one
# permission, and the bwrap it starts keeps it. The jail is started with
# --disable-userns there, so nothing inside it can make another.
if [ -n "$JAIL_APPARMOR" ]; then
  keep_original "$JAIL_APPARMOR"
  install -d -m 0755 -o root -g root "$(dirname "$JAIL_APPARMOR")"
  install -m 0644 -o root -g root "$SRC/installer/apparmor/freepanel-jailshell" "$JAIL_APPARMOR.new"
  mv -f "$JAIL_APPARMOR.new" "$JAIL_APPARMOR"
  if [ -d /sys/kernel/security/apparmor ] && command -v apparmor_parser >/dev/null; then
    apparmor_parser -r -W "$JAIL_APPARMOR" || die "could not load the jail shell's AppArmor profile ($JAIL_APPARMOR)"
  else
    echo "  AppArmor is not running here, so the jail shell's profile is not loaded (nothing restricts its namespaces)." >&2
  fi
fi
if [ -d "$SRC/ui" ] && [ -n "$(ls -A "$SRC/ui" 2>/dev/null)" ]; then
  # The release's pages replace the old ones whole, so a page or script a
  # newer release dropped is no longer served (15-1); the old folder is
  # parked in $PREFIX/parked. Never keep the tarball's owners: whatever UID
  # built the release may be a hosting customer here, and the pages must be
  # root's.
  UI_STAMP="$(date -u +%Y%m%dT%H%M%S.%NZ)"
  install -d -m 0700 -o root -g root "$PREFIX/parked"
  if [ -e "$PREFIX/ui.new" ]; then mv -T "$PREFIX/ui.new" "$PREFIX/parked/ui.new.parked-$UI_STAMP"; fi
  install -d -m 0755 -o root -g root "$PREFIX/ui.new"
  cp -R --no-preserve=ownership,mode "$SRC/ui/." "$PREFIX/ui.new/"
  chown -R root:root "$PREFIX/ui.new"
  chmod -R u=rwX,go=rX "$PREFIX/ui.new"
  if [ -n "$(ls -A "$PREFIX/ui")" ]; then
    mv -T "$PREFIX/ui" "$PREFIX/parked/ui.parked-$UI_STAMP"
  else
    rmdir "$PREFIX/ui"
  fi
  mv -T "$PREFIX/ui.new" "$PREFIX/ui"
fi
chown -R root:root "$PREFIX"
chmod -R u=rwX,go=rX "$PREFIX/ui"
if command -v restorecon >/dev/null; then restorecon -R "$PREFIX" || true; fi

# The program of a plugin that has the run permission is started by systemd from a folder the root agent makes under
# /var/lib/freepanel-plugins, where a file is var_lib_t and the service manager may not execute it. The module gives that one
# file the type of the programs services start from; the agent labels the file when it unpacks it (installer/selinux/freepanel-plugins.cil).
if command -v semodule >/dev/null && [ -f /etc/selinux/config ]; then
  if ! semodule -i "$SRC/installer/selinux/freepanel-plugins.cil"; then
    if command -v selinuxenabled >/dev/null && selinuxenabled; then die "could not load the SELinux policy for plugin programs"; fi
    echo "  Warning: could not load the SELinux policy for plugin programs (SELinux is off); re-run the installer to try again." >&2
  fi
fi

# freepanel-api, pure-authd and rspamd run in SELinux types of their own (installer/selinux/freepanel-services.cil), which
# the modules for Apache's, Pure-FTPd's and smtpd's sockets name: each of those may connect to its one service and to none
# that runs as unconfined_service_t, the root agent among them. A machine with the earlier modules loaded and not this one
# also gets freepanel-bridge.cil, in the same transaction, which keeps the earlier rules until each service has been
# restarted in its new type; "The SELinux bridge" near the end of the run removes it.
if command -v semodule >/dev/null && [ -f /etc/selinux/config ]; then
  fp_modules="$(semodule -l 2>/dev/null || true)"
  fp_cil=("$SRC/installer/selinux/freepanel-services.cil")
  if ! grep -qx freepanel-services <<<"$fp_modules" && grep -qxE 'freepanel-(panelproxy|ftp|milter)' <<<"$fp_modules"; then
    fp_cil+=("$SRC/installer/selinux/freepanel-bridge.cil")
  fi
  if ! semodule -i "${fp_cil[@]}"; then
    if command -v selinuxenabled >/dev/null && selinuxenabled; then die "could not load the SELinux policy for freePanel's services"; fi
    echo "  Warning: could not load the SELinux policy for freePanel's services (SELinux is off); re-run the installer to try again." >&2
  fi
  # A running service keeps its type until it is restarted; the binaries take theirs now.
  for f in "$PREFIX/bin/freepanel-api" /usr/sbin/pure-authd /usr/bin/rspamd; do
    if [ -e "$f" ]; then restorecon "$f" || true; fi
  done
  unset fp_modules fp_cil
fi

# The SELinux type a unit's main process runs in, or nothing (not running, or no SELinux).
unit_selinux_type() {
  local pid
  pid="$(systemctl show -p MainPID --value "$1" 2>/dev/null || true)"
  case "$pid" in '' | 0) return 0 ;; esac
  { tr -d '\0' <"/proc/$pid/attr/current" 2>/dev/null || true; } | cut -d: -f3
}

# ---- SSH for accounts without a shell ---------------------------------------
# An account whose login shell is none can't sign in over SSH: sshd denies the
# group the root agent keeps those accounts in. Without this sshd takes their
# keys and forwards ports for `ssh -N`, which never starts the shell (review
# 96-2). The agent adds and removes the accounts; this is the group and the
# line that names it. Where the server has no sshd there is nothing to deny.
NOSHELL_GROUP=freepanel-noshell
keep_group "$NOSHELL_GROUP"
getent group "$NOSHELL_GROUP" >/dev/null || groupadd --system "$NOSHELL_GROUP"
if command -v sshd >/dev/null; then
  say "Telling sshd to refuse accounts without a shell"
  SSHD_DROPIN=/etc/ssh/sshd_config.d/50-freepanel-noshell.conf
  keep_original "$SSHD_DROPIN"
  install -d -m 0755 -o root -g root /etc/ssh/sshd_config.d
  printf '# Written by the freePanel installer; re-running it rewrites this file.\n# The accounts without a shell are kept in this group by freepanel-privd.\nDenyGroups %s\n' \
    "$NOSHELL_GROUP" >"$SSHD_DROPIN.new"
  chmod 0644 "$SSHD_DROPIN.new"
  mv -f "$SSHD_DROPIN.new" "$SSHD_DROPIN"
  if command -v restorecon >/dev/null; then restorecon "$SSHD_DROPIN" || true; fi
  # AlmaLinux, Rocky, RHEL 9 and Ubuntu 24.04 read sshd_config.d, but a
  # sshd_config that doesn't include it, or includes it after a Match block
  # (which then swallows the file), leaves the door open. Ask sshd what it
  # will use, not whether the line is there.
  if SSHD_USES="$(sshd -T 2>/dev/null)"; then
    grep -qE "^denygroups (.* )?$NOSHELL_GROUP( .*)?$" <<<"$SSHD_USES" ||
      die "sshd does not use $SSHD_DROPIN (sshd -T shows no DenyGroups line naming $NOSHELL_GROUP), so accounts without a shell could still sign in; make sshd_config include /etc/ssh/sshd_config.d/*.conf before any Match line"
  else
    printf 'install: warning: could not run sshd -T to check that sshd uses %s; accounts without a shell may still sign in until it does\n' "$SSHD_DROPIN" >&2
  fi
  for u in sshd.service ssh.service; do
    if [ "$(systemctl show -p LoadState --value "$u" 2>/dev/null)" = loaded ]; then
      systemctl try-reload-or-restart "$u" ||
        printf 'install: warning: %s did not reload; accounts without a shell can still sign in until it does (see: sshd -t)\n' "$u" >&2
      break
    fi
  done
fi

# ---- Config ----------------------------------------------------------------
if [ ! -f "$ETC/freepanel.json" ]; then
  say "Writing $ETC/freepanel.json"
  UI_DIR=""
  [ -f "$PREFIX/ui/index.html" ] && UI_DIR="$PREFIX/ui"
  umask 027
  cat >"$ETC/freepanel.json" <<JSON
{
  "hostname": "$HOSTNAME_FQDN",
  "listen": ":$PORT",
  "user_listen": ":$USER_PORT",
  "secret_key_file": "$ETC/secret.key",
  "tls_cert": "$ETC/tls/panel.crt",
  "tls_key": "$ETC/tls/panel.key",
  "db_path": "$STATE/freepanel.db",
  "ui_dir": "$UI_DIR",
  "privd_socket": "/run/freepanel/privd.sock",
  "api_user": "$SVC_USER",
  "home_base": "/home",
  "park_dir": "$PARK",
  "privd_state_dir": "/var/lib/freepanel-privd",
  "session_idle": "1h",
  "session_max": "12h",
  "files_max_upload": 2147483648,
  "files_long_ops": 0,
  "allow_reboot": false
}
JSON
  chown root:"$SVC_USER" "$ETC/freepanel.json"
  chmod 0640 "$ETC/freepanel.json"
else
  say "Keeping existing $ETC/freepanel.json"
  # Releases before the panels were packaged wrote an empty ui_dir. Point
  # it at the panels now that they ship; any other value is the admin's.
  if [ -f "$PREFIX/ui/index.html" ] && grep -qx '  "ui_dir": "",' "$ETC/freepanel.json"; then
    say "Serving the panels from $PREFIX/ui"
    sed -i "s|^  \"ui_dir\": \"\",\$|  \"ui_dir\": \"$PREFIX/ui\",|" "$ETC/freepanel.json"
    chown root:"$SVC_USER" "$ETC/freepanel.json"
    chmod 0640 "$ETC/freepanel.json"
    if command -v restorecon >/dev/null; then restorecon "$ETC/freepanel.json" || true; fi
  fi
fi

# ---- TLS -------------------------------------------------------------------
if [ ! -f "$ETC/tls/panel.crt" ]; then
  say "Creating a self-signed certificate for $HOSTNAME_FQDN"
  openssl req -x509 -newkey rsa:3072 -sha256 -days 825 -nodes \
    -keyout "$ETC/tls/panel.key" -out "$ETC/tls/panel.crt" \
    -subj "/CN=$HOSTNAME_FQDN" -addext "subjectAltName=DNS:$HOSTNAME_FQDN" 2>/dev/null
  chown root:"$SVC_USER" "$ETC/tls/panel.key" "$ETC/tls/panel.crt"
  chmod 0640 "$ETC/tls/panel.key"
  chmod 0644 "$ETC/tls/panel.crt"
fi

# ---- Two-factor secret key -------------------------------------------------
# Encrypts two-factor secrets in the database, so a copy of the database
# alone does not carry them. Kept outside the database and never replaced.
if [ ! -f "$ETC/secret.key" ]; then
  say "Creating the two-factor encryption key"
  (umask 077 && openssl rand -hex 32 >"$ETC/secret.key")
  chown root:"$SVC_USER" "$ETC/secret.key"
  chmod 0640 "$ETC/secret.key"
fi

# ---- Web hosting (--web) ---------------------------------------------------
# enable_crb: turn on CRB (CodeReady Builder), which EPEL and Remi packages
# build on. On RHEL it is codeready-builder-for-rhel-N-ARCH-rpms, turned on
# through the system's registration. Elsewhere epel-release's crb helper knows
# the names AlmaLinux and Rocky give it; CloudLinux names its own, so failing
# that, any repository whose id is crb or ends in -crb is turned on.
enable_crb() {
  local id
  if [ "$OS_ID" = rhel ]; then
    subscription-manager repos --enable "codeready-builder-for-rhel-$EL_MAJOR-$(uname -m)-rpms" >/dev/null ||
      die "could not turn on codeready-builder-for-rhel-$EL_MAJOR-$(uname -m)-rpms; check this system's Red Hat subscription includes it and run the installer again"
    return 0
  fi
  crb enable >/dev/null 2>&1 && return 0
  id="$(dnf -q repolist --all 2>/dev/null | awk '{print $1}' | grep -E '(^|-)crb$' | head -n 1 || true)"
  [ -n "$id" ] || die "could not find this system's CRB (CodeReady Builder) repository; turn it on and run the installer again"
  dnf -y -q config-manager --set-enabled "$id"
}

# pinned_key_ok FILE FPR: FILE holds exactly one primary key, and its
# fingerprint is FPR (rpm --import trusts every key in a file).
pinned_key_ok() {
  [ -n "$2" ] && [ -f "$1" ] || return 1
  gpg --batch --show-keys --with-colons "$1" 2>/dev/null |
    awk -F: -v fpr="$2" '
      $1 == "pub" {n++; primary = 1; next}
      $1 == "fpr" && primary {if ($10 == fpr) ok = 1; primary = 0}
      $1 == "sub" {primary = 0}
      END {exit !(ok && n == 1)}'
}

# install_epel_rhel: EPEL's release package on RHEL, which has none in its
# own repositories. Downloaded over HTTPS from EPEL and installed only if
# signed by EPEL's key for this release, shipped with the installer and
# checked by fingerprint first; an epel-release already there is kept. Not
# for AlmaLinux, Rocky or CloudLinux, whose repositories carry epel-release.
install_epel_rhel() {
  local tmp sig fpr keyid keyfile rpmfile
  [ "$OS_ID" = rhel ] || return 0
  rpm -q epel-release >/dev/null 2>&1 && return 0
  fpr="EPEL${EL_MAJOR}_KEY_FPR"
  fpr="${!fpr:-}"
  keyfile="$SRC/installer/keys/RPM-GPG-KEY-EPEL-$EL_MAJOR"
  rpmfile="epel-release-latest-$EL_MAJOR.noarch.rpm"
  pinned_key_ok "$keyfile" "$fpr" ||
    die "EPEL's key for RHEL $EL_MAJOR is not pinned in this release (installer/keys/RPM-GPG-KEY-EPEL-$EL_MAJOR), so epel-release cannot be checked; install epel-release yourself and run the installer again"
  tmp="$(mktemp -d)"
  rpm --import "$keyfile"
  curl -fsS --proto '=https' --tlsv1.2 -o "$tmp/$rpmfile" "$EPEL_RELEASE_URL_PREFIX$EL_MAJOR.noarch.rpm" ||
    die "could not download $EPEL_RELEASE_URL_PREFIX$EL_MAJOR.noarch.rpm"
  rpmkeys --checksig "$tmp/$rpmfile" | grep -q ': digests signatures OK$' ||
    die "$rpmfile is not signed by a trusted key"
  # Signed, and by EPEL's key: not just any key the system trusts.
  sig="$(rpm -qp --qf '%|RSAHEADER?{%{RSAHEADER:pgpsig}}:{%{SIGPGP:pgpsig}}|' "$tmp/$rpmfile" 2>/dev/null)"
  keyid="${fpr: -16}"
  [[ "${sig,,}" == *"key id ${keyid,,}"* ]] ||
    die "$rpmfile is not signed by EPEL's key for RHEL $EL_MAJOR ($sig)"
  dnf -y -q install "$tmp/$rpmfile"
  rm -f "$tmp/$rpmfile"
  rmdir "$tmp"
}

# Apache with mod_ssl and PHP-FPM from Remi's repository, the layout the web
# module expects (modules/web/README.md). Remi's release package is
# downloaded over HTTPS and installed only if it is signed by Remi's EL9
# key, which ships with the installer and is checked by fingerprint first.
install_remi() {
  local tmp sig keyid fpr url key rpmfile
  # This release's key and release package: EL9's, or EL10's once pinned.
  fpr=$REMI_KEY_FPR url=$REMI_RELEASE_URL
  if [ "$EL_MAJOR" != 9 ]; then
    fpr="REMI${EL_MAJOR}_KEY_FPR" url="REMI${EL_MAJOR}_RELEASE_URL"
    fpr="${!fpr:-}" url="${!url:-}"
    if [ -z "$fpr" ] || [ -z "$url" ]; then
      die "Remi's key for EL$EL_MAJOR is not pinned in this installer yet (installer/keys/RPM-GPG-KEY-remi.el$EL_MAJOR.asc); leave out --web, or use an EL9 system"
    fi
  fi
  key="installer/keys/RPM-GPG-KEY-remi.el$EL_MAJOR.asc"
  rpmfile="remi-release-$EL_MAJOR.rpm"
  tmp="$(mktemp -d)"
  # rpm --import trusts every key in the file, so it must hold exactly one
  # primary key, the pinned one (19-1).
  if ! gpg --batch --show-keys --with-colons "$SRC/$key" 2>/dev/null |
      awk -F: -v fpr="$fpr" '
        $1 == "pub" {n++; primary = 1; next}
        $1 == "fpr" && primary {if ($10 == fpr) ok = 1; primary = 0}
        $1 == "sub" {primary = 0}
        END {exit !(ok && n == 1)}'; then
    die "$key is not Remi's EL$EL_MAJOR key alone"
  fi
  rpm --import "$SRC/$key"
  curl -fsS --proto '=https' --tlsv1.2 -o "$tmp/$rpmfile" "$url" ||
    die "could not download $url"
  rpmkeys --checksig "$tmp/$rpmfile" | grep -q ': digests signatures OK$' ||
    die "$rpmfile is not signed by a trusted key"
  # Signed, and by Remi's key: not just any key the system trusts.
  keyid="${fpr: -16}"
  # RPM 4.16+ packages carry a header-only signature (RSAHEADER); older
  # ones the full-package one (SIGPGP).
  sig="$(rpm -qp --qf '%|RSAHEADER?{%{RSAHEADER:pgpsig}}:{%{SIGPGP:pgpsig}}|' "$tmp/$rpmfile" 2>/dev/null)"
  [[ "${sig,,}" == *"key id ${keyid,,}"* ]] || die "$rpmfile is not signed by Remi's EL$EL_MAJOR key ($sig)"
  dnf -y -q install "$tmp/$rpmfile"
  rm -f "$tmp/$rpmfile"
  rmdir "$tmp"
}

# Apache. Its own step so it can switch to freePanel's patched httpd
# package (packaging/httpd) once that ships with a release.
install_httpd() {
  dnf -y -q install httpd mod_ssl
  # freePanel's repository is above the system's (priority=10, setup-repo.sh):
  # where it holds Apache, distro-sync puts its build in place of a system
  # build installed earlier, even a later release.
  if [ -f /etc/yum.repos.d/freepanel.repo ]; then
    local have
    have="$(rpm -qa --qf '%{NAME}\n' 'httpd*' 'mod_ssl' 'mod_ldap' 'mod_lua' 'mod_proxy_html' 'mod_session' | sort -u | tr '\n' ' ')"
    # shellcheck disable=SC2086
    [ -z "$have" ] || dnf -y -q distro-sync $have || echo "  Warning: could not put freePanel's Apache build in place; the security check will say so." >&2
  fi
}

# The oldest Apache freePanel runs on: AlmaLinux, Rocky and RHEL 9.8's
# release with the fix for CVE-2026-44119, which keeps an .htaccess from
# reading files with file() and filesize(). freePanel's own build
# (packaging/httpd) is this release plus .fpN, so it passes. A minimum, not
# a lock: updates keep installing.
HTTPD_MIN="2.4.62-13.el9_8.6"

# require_httpd updates an older Apache, and refuses to go on if that does
# not bring it to HTTPD_MIN, or if the versions cannot be compared.
require_httpd() {
  local have rc
  have="$(rpm -qf --qf '%{EPOCH}:%{VERSION}-%{RELEASE}\n' /usr/sbin/httpd | sed 's/^(none)://' | head -n 1)"
  rc=0
  httpd_older "$have" || rc=$?
  if [ "$rc" -eq 0 ]; then
    say "Updating Apache $have to at least $HTTPD_MIN"
    dnf -y -q upgrade httpd httpd-core httpd-tools mod_ssl || true
    have="$(rpm -qf --qf '%{EPOCH}:%{VERSION}-%{RELEASE}\n' /usr/sbin/httpd | sed 's/^(none)://' | head -n 1)"
    rc=0
    httpd_older "$have" || rc=$?
    if [ "$rc" -eq 0 ]; then
      die "Apache $have is older than $HTTPD_MIN (the CVE-2026-44119 fix); update httpd and run the installer again"
    fi
  fi
  if [ "$rc" -ne 1 ]; then
    die "cannot compare Apache's version \"$have\" with $HTTPD_MIN"
  fi
}

# httpd_older exits 0 when the EPOCH:VERSION-RELEASE given is older than
# HTTPD_MIN by rpm's own ordering, 1 when it is not, and 2 on any error.
# Isolated mode (-I): nothing from the working folder or the environment
# reaches Python.
httpd_older() {
  python3 -I -c 'import sys
try:
    import rpm
    def evr(s):
        e, _, vr = s.rpartition(":")
        v, _, r = vr.partition("-")
        if not v or not r:
            raise ValueError(s)
        return (e or "0", v, r)
    older = rpm.labelCompare(evr(sys.argv[1]), evr(sys.argv[2])) < 0
except Exception:
    sys.exit(2)
sys.exit(0 if older else 1)' "$1" "$HTTPD_MIN"
}

# Modules no site needs, which only widen what a customer's .htaccess or a
# stray handler can reach: mod_lua (scripts in Apache itself), mod_status
# and mod_info (the server's state and configuration). Their LoadModule
# lines in the packaged files are turned off on every run; the packages
# keep a file someone changed when they update, so an update does not bring
# them back. The first time, the file as packaged is parked beside it.
HTTPD_OFF_MODULES="lua_module status_module info_module"
disable_httpd_modules() {
  local f m out undo changed=0
  undo="$(mktemp -d)"
  for f in /etc/httpd/conf.modules.d/*.conf; do
    [ -f "$f" ] || continue
    for m in $HTTPD_OFF_MODULES; do
      if grep -Eiq "^[[:space:]]*LoadModule[[:space:]]+${m}[[:space:]]" "$f"; then
        # This run's own copy, to put back if Apache rejects the change.
        [ -e "$undo/$(basename "$f")" ] || cp -p "$f" "$undo/$(basename "$f")"
        if ! grep -q '^# Changed by the freePanel installer' "$f"; then
          keep_original "$f"
          cp -p "$f" "$f.parked-$(date -u +%Y%m%dT%H%M%SZ)"
          sed -i "1i # Changed by the freePanel installer: modules no site needs are off, on every run." "$f"
        fi
        sed -Ei "s/^([[:space:]]*LoadModule[[:space:]]+${m}[[:space:]].*)$/# \\1/I" "$f"
        changed=1
      fi
    done
    chown root:root "$f"
    chmod 0644 "$f"
  done
  if [ "$changed" -eq 1 ]; then
    # Before Apache's first start mod_ssl's own certificate does not exist
    # yet; httpd-init makes it, as Apache's own start would.
    if systemctl cat httpd-init.service >/dev/null 2>&1; then
      keep_units httpd-init.service
      systemctl start httpd-init.service || true
    fi
    if ! out="$(apachectl -t 2>&1)"; then
      for f in "$undo"/*; do cp -p "$f" "/etc/httpd/conf.modules.d/$(basename "$f")"; done
      rm -rf "$undo"
      die "Apache's configuration does not pass apachectl -t after turning off $HTTPD_OFF_MODULES, so the files are back as they were: $out"
    fi
    if systemctl is-active --quiet "$WEB_UNIT"; then systemctl reload "$WEB_UNIT"; fi
  fi
  rm -rf "$undo"
}

# check_httpd_modules stops the run if Apache still loads one of
# HTTPD_OFF_MODULES, from wherever it comes: a LoadModule line outside the
# packaged files, or a module package installed since the last run.
check_httpd_modules() {
  local m loaded
  loaded="$("$WEB_CTL" -M 2>/dev/null)" || die "$WEB_CTL -M failed; Apache's configuration does not load"
  for m in $HTTPD_OFF_MODULES; do
    if printf '%s\n' "$loaded" | grep -Eq "^[[:space:]]*${m}[[:space:]]"; then
      die "Apache still loads $m; remove its LoadModule line and run the installer again"
    fi
  done
}

# ---- Web hosting on Ubuntu 24.04 -------------------------------------------
# Apache is the distribution's apache2, or freePanel's rebuild of it
# (packaging/httpd/build-deb.sh, version +fpN) where freePanel's package
# repository publishes it: apt takes the higher version, so ours wins over the
# stock release it was built from, and a newer Ubuntu security release wins
# over ours until ours is rebuilt from it. PHP-FPM is the distribution's.
#
# The oldest Ubuntu apache2 freePanel runs on: noble's release with the fix for
# CVE-2026-44119 (debian/patches/CVE-2026-44119.patch, in its changelog), the
# same fix HTTPD_MIN asks for on EL. Ubuntu numbers its releases
# 2.4.58-1ubuntu8.N, which dpkg --compare-versions orders. A minimum, not a
# lock: updates keep installing.
APACHE2_MIN="2.4.58-1ubuntu8.15"
# apache2-bin holds /usr/sbin/apache2 and the modules; apache2 needs the same
# version of it, of apache2-data and of apache2-utils, so all four are named and
# move together.
APACHE2_PKGS="apache2 apache2-bin apache2-data apache2-utils"

# apache2_version prints the installed apache2-bin's version, or nothing.
apache2_version() {
  dpkg-query -W -f '${db:Status-Abbrev} ${Version}\n' apache2-bin 2>/dev/null | awk '$1 == "ii" { print $2 }'
}

# apache2_older exits 0 when the version given is older than APACHE2_MIN by
# dpkg's own ordering, 1 when it is not, and 2 when it cannot be compared
# (empty, or not a Debian version).
apache2_older() {
  local rc=0
  [ -n "$1" ] || return 2
  dpkg --compare-versions "$1" lt "$APACHE2_MIN" 2>/dev/null || rc=$?
  return "$rc"
}

# require_apache2 updates an older apache2, and refuses to go on if that does
# not bring it to APACHE2_MIN, or if the versions cannot be compared.
require_apache2() {
  local have rc
  have="$(apache2_version)"
  rc=0
  apache2_older "$have" || rc=$?
  if [ "$rc" -eq 0 ]; then
    say "Updating Apache $have to at least $APACHE2_MIN"
    # shellcheck disable=SC2086 # the package names are words
    DEBIAN_FRONTEND=noninteractive apt-get -o DPkg::Lock::Timeout=600 -y -q install --only-upgrade $APACHE2_PKGS || true
    have="$(apache2_version)"
    rc=0
    apache2_older "$have" || rc=$?
    if [ "$rc" -eq 0 ]; then
      die "Apache $have is older than $APACHE2_MIN (the CVE-2026-44119 fix); update apache2 and run the installer again"
    fi
  fi
  if [ "$rc" -ne 1 ]; then
    die "cannot compare Apache's version \"$have\" with $APACHE2_MIN"
  fi
}

# The modules the panel's sites and a customer's .htaccess need
# (modules/web/apache, FeatureModules and OverrideModules) that Ubuntu's apache2
# does not turn on by itself; a2enmod also turns on what each needs
# (socache_shmcb for ssl, proxy for proxy_fcgi and proxy_http). proxy_http is
# the resellers' own panel names (apache.RenderPanelHosts). A test holds this
# list to the panel's.
APACHE2_MODULES="ssl proxy_fcgi proxy_http rewrite headers expires authz_groupfile authz_owner"

# apache2_link_files prints the mods-enabled (or sites-enabled, conf-enabled)
# links that turning a module, site or configuration on or off makes or
# removes, for the record of what was there before.
apache2_link_files() {
  local dir="$1" name f
  shift
  for name in "$@"; do
    for f in "/etc/apache2/$dir/$name.load" "/etc/apache2/$dir/$name.conf"; do
      printf '%s\n' "$f"
    done
  done
}

# enable_apache2_modules turns APACHE2_MODULES on, with what they need.
enable_apache2_modules() {
  local m need=()
  for m in $APACHE2_MODULES; do
    a2query -q -m "$m" || need+=("$m")
  done
  [ "${#need[@]}" -gt 0 ] || return 0
  # What a2enmod adds for each, and for what it needs, is kept as absent.
  # shellcheck disable=SC2046 # one file per line, no spaces
  keep_original $(apache2_link_files mods-enabled "${need[@]}" socache_shmcb proxy)
  a2enmod -q "${need[@]}" >/dev/null
}

# disable_apache2_modules is disable_httpd_modules on Ubuntu: a2dismod turns
# HTTPD_OFF_MODULES off (status is on in the package's own setup), and records
# that the admin turned them off, so a package update does not turn them on
# again. The links are kept for an uninstall to put back.
disable_apache2_modules() {
  local m mod on=() out
  for m in $HTTPD_OFF_MODULES; do
    mod="${m%_module}"
    a2query -q -m "$mod" && on+=("$mod")
  done
  [ "${#on[@]}" -gt 0 ] || return 0
  # shellcheck disable=SC2046 # one file per line, no spaces
  keep_original $(apache2_link_files mods-enabled "${on[@]}")
  a2dismod -q -f "${on[@]}" >/dev/null
  if ! out="$(apachectl -t 2>&1)"; then
    a2enmod -q "${on[@]}" >/dev/null || true
    die "Apache's configuration does not pass apachectl -t after turning off ${on[*]}, so they are on again: $out"
  fi
  if systemctl is-active --quiet "$WEB_UNIT"; then systemctl reload "$WEB_UNIT"; fi
}

# disable_apache2_default_site turns off the package's own sites: 000-default
# serves /var/www/html for every name no site of the panel's has, where the
# panel's catch-all host belongs, and default-ssl the package's snakeoil
# certificate. The links are kept for an uninstall to put back; the files stay
# in sites-available.
disable_apache2_default_site() {
  local site on=()
  for site in 000-default default-ssl; do
    a2query -q -s "$site" && on+=("$site")
  done
  [ "${#on[@]}" -gt 0 ] || return 0
  local f
  for site in "${on[@]}"; do
    f="/etc/apache2/sites-enabled/$site.conf"
    keep_original "$f"
  done
  a2dissite -q "${on[@]}" >/dev/null
}

# ondrej_key_ok FILE: whether FILE is an armored key that holds exactly one
# primary key, the one with ONDREJ_KEY_FPR, and gpg calls it neither revoked
# nor expired. apt trusts every key in a Signed-By file, so a second key in it
# would be trusted for the PPA too.
ondrej_key_ok() {
  local gh keys rc=0
  grep -q -- '-----BEGIN PGP PUBLIC KEY BLOCK-----' "$1" || return 1
  gh="$(mktemp -d)"
  keys="$(GNUPGHOME="$gh" gpg --batch --with-colons --import-options show-only --import "$1" 2>/dev/null |
    awk -F: '$1 == "pub" { p = 1; if ($2 == "r" || $2 == "e") print "unusable" }
      $1 == "fpr" && p { print $10; p = 0 } $1 == "sub" { p = 0 }')" || rc=$?
  rm -rf "$gh"
  [ "$rc" -eq 0 ] && [ "$keys" = "$ONDREJ_KEY_FPR" ]
}

# setup_ondrej_ppa points apt at the PHP PPA, trusting only the pinned key and
# only for it, and refreshes the lists. It stops if the shipped key is not the
# pinned one. Every run writes both files again, so a new key or address
# reaches the server with the next release.
setup_ondrej_ppa() {
  local key="$SRC/$ONDREJ_KEYFILE"
  ondrej_key_ok "$key" ||
    die "$ONDREJ_KEYFILE is not the PHP repository's key $ONDREJ_KEY_FPR alone; the release is damaged, nothing was trusted"
  keep_original "$ONDREJ_KEYRING" "$ONDREJ_SOURCES"
  install -d -m 0755 "$(dirname "$ONDREJ_KEYRING")"
  install -m 0644 -o root -g root "$key" "$ONDREJ_KEYRING.new"
  mv -f "$ONDREJ_KEYRING.new" "$ONDREJ_KEYRING"
  cat >"$ONDREJ_SOURCES.new" <<SOURCES
# Written by the freePanel installer: PHP 8.2 to 8.5 from Ondřej Surý's
# repository ($ONDREJ_URL), trusted by its key alone ($ONDREJ_KEY_FPR).
Types: deb
URIs: $ONDREJ_URL
Suites: $CODENAME
Components: main
Signed-By: $ONDREJ_KEYRING
SOURCES
  chmod 0644 "$ONDREJ_SOURCES.new"
  mv -f "$ONDREJ_SOURCES.new" "$ONDREJ_SOURCES"
  pkg_update
}

# AppArmor on Ubuntu 24.04. Neither apache2 nor PHP-FPM ships a profile, so
# neither is confined and nothing needs changing for them. apparmor-profiles,
# which an admin may add, ships an enforced php-fpm profile that allows only the
# packages' own sockets and no home folder, so every site's PHP would fail.
# Where that profile is there, freePanel's file in its php-fpm.d folder (which
# it includes) allows what the pools need: their sockets, the accounts' homes
# (@{HOMEDIRS}, /home/ unless tunables/home.d adds more) and sendmail for
# mail(). It is not SELinux's policy (docs: modules/web/README.md, "AppArmor").
APPARMOR_PHP_PROFILE=/etc/apparmor.d/php-fpm
APPARMOR_PHP_RULES=/etc/apparmor.d/php-fpm.d/freepanel
apparmor_php_fpm() {
  [ -f "$APPARMOR_PHP_PROFILE" ] || return 0
  say "Allowing freePanel's PHP pools in AppArmor's php-fpm profile ($APPARMOR_PHP_RULES)"
  keep_original "$APPARMOR_PHP_RULES"
  install -d -m 0755 "$(dirname "$APPARMOR_PHP_RULES")"
  cat >"$APPARMOR_PHP_RULES.new" <<'RULES'
# Written by the freePanel installer (--web): what freePanel's PHP-FPM pools
# need beside the php-fpm profile of apparmor-profiles, which includes this
# folder. Rewritten on every run; put your own rules in local/php-fpm.

  # Each version's pool sockets (modules/web/phpfpm, UbuntuSocketBase).
  @{run}/freepanel-php/ r,
  @{run}/freepanel-php/*/ r,
  @{run}/freepanel-php/*/*.sock rwlk,
  # Each account's sites, uploads, sessions (~/tmp) and PHP error log
  # (~/logs): PHP runs as the account, in its own home.
  @{HOMEDIRS}/*/ r,
  @{HOMEDIRS}/*/** rwlk,
  # The sites' databases, on the servers' own sockets.
  @{run}/mysqld/mysqld.sock rw,
  @{run}/postgresql/.s.PGSQL.* rw,
  # The database admin tool (--dbadmin) and webmail (--webmail): their code,
  # read, and their state, which their pools write. Webmail's PGP runs GnuPG.
  /usr/local/freepanel/dbadmin/** r,
  /usr/local/freepanel/webmail/** r,
  /var/lib/freepanel-dbadmin/** rwk,
  /var/lib/freepanel-webmail/** rwlk,
  /usr/bin/gpg{,-agent,conf} Ux,
  # mail() hands the message to the system's sendmail, as it does without
  # this profile.
  /usr/sbin/sendmail Ux,
RULES
  chmod 0644 "$APPARMOR_PHP_RULES.new"
  mv -f "$APPARMOR_PHP_RULES.new" "$APPARMOR_PHP_RULES"
  # Loaded now where AppArmor is on; otherwise at its next start.
  if command -v aa-enabled >/dev/null && aa-enabled --quiet 2>/dev/null; then
    apparmor_parser -r "$APPARMOR_PHP_PROFILE" ||
      die "AppArmor does not take $APPARMOR_PHP_PROFILE with $APPARMOR_PHP_RULES; see: apparmor_parser -r $APPARMOR_PHP_PROFILE"
  fi
}

# apparmor_web puts Apache and every version's PHP-FPM in freePanel's AppArmor
# profiles (installer/apparmor/freepanel-apache2, freepanel-php-fpm), in
# enforce mode, on Ubuntu and Debian: they allow what a web server and a
# site's PHP do and deny the panel's secrets and state, root's home, the
# password files, the system's files, cron and the accounts' SSH keys
# (modules/web/README.md, "AppArmor"). A process is confined from its next
# start, so the ones already running are restarted. Where AppArmor is not
# running, or another profile already attaches to the same program, the
# closing lines say so (APPARMOR_OFF_WHY) and the Security check fails it.
APPARMOR_WEB_PROFILES="freepanel-apache2 freepanel-php-fpm"
APPARMOR_OFF_WHY=
apparmor_web() {
  local p f other units u pid
  if [ "$DEB_DISTRO" = debian ] && ! command -v apparmor_parser >/dev/null; then pkg_install apparmor; fi
  if [ ! -d /sys/kernel/security/apparmor ] || ! command -v apparmor_parser >/dev/null ||
    ! { command -v aa-enabled >/dev/null && aa-enabled --quiet 2>/dev/null; }; then
    APPARMOR_OFF_WHY="AppArmor is not running on this server, so Apache and PHP are not confined; turn it on (apparmor=1 security=apparmor on the kernel's command line, then systemctl enable --now apparmor) and run the installer again"
    return 0
  fi
  for p in $APPARMOR_WEB_PROFILES; do
    f=/etc/apparmor.d/$p
    case $p in
      freepanel-apache2) other=$(grep -lE '^[[:space:]]*(profile[[:space:]]+[^[:space:]]+[[:space:]]+)?/usr/sbin/apache2[[:space:]{]' /etc/apparmor.d/* 2>/dev/null | grep -vx "$f" | head -n 1) || true ;;
      *) other=; [ ! -f "$APPARMOR_PHP_PROFILE" ] || other=$APPARMOR_PHP_PROFILE ;;
    esac
    if [ -n "$other" ]; then
      # The php-fpm one is apparmor-profiles' own enforced profile, which
      # apparmor_php_fpm extends; another Apache one is the admin's.
      [ "$p" = freepanel-php-fpm ] || APPARMOR_OFF_WHY="$other already confines Apache, so freePanel's profile ($p) was not added; check that it is in enforce mode (aa-status)"
      continue
    fi
    say "Confining $p with AppArmor (enforce mode, $f)"
    keep_original "$f"
    install -m 0644 -o root -g root "$SRC/installer/apparmor/$p" "$f.new"
    mv -f "$f.new" "$f"
    apparmor_parser -r -W "$f" || die "AppArmor does not take $f; see: apparmor_parser -r $f"
  done
  # Already running unconfined: restarted, so each starts in its profile.
  units=$(systemctl list-units --type=service --state=running --no-legend --plain "$WEB_UNIT" 'php*-fpm.service' 'freepanel-php*-fpm@*.service' 2>/dev/null | awk '{print $1}')
  for u in $units; do
    pid=$(systemctl show -p MainPID --value "$u" 2>/dev/null) || continue
    if [ -z "$pid" ] || [ "$pid" = 0 ]; then continue; fi
    case $(cat "/proc/$pid/attr/current" 2>/dev/null) in
      unconfined*) systemctl restart "$u" ;;
    esac
  done
}

# check_apache2_php stops the run if Apache would run PHP itself, as the web
# server's user, rather than in each account's own pool: mod_php (a php*_module
# from libapache2-mod-php) or the PHP-FPM package's own phpX.Y-fpm
# configuration, which sends every .php file to its www pool.
# install_composer: Composer, for the customers' Composer page
# (modules/composer), from the distribution's own signed packages, so the
# system's updates keep it current (dnf-automatic or unattended-upgrades, the
# Server updates page): EPEL's composer on EL (EPEL's key is pinned above),
# Debian's and Ubuntu's own composer on the apt family. Each brings the
# distribution's command line PHP and the PHP libraries Composer is made of;
# no site uses that PHP: the panel runs Composer as the account, with the PHP
# version of the site it runs for, and never as root. No download outside the
# package managers. A server where the package can't be had goes on without
# it, and the page says Composer is not installed.
install_composer() {
  say "Installing Composer (the distribution's composer package)"
  if [ "$FAMILY" = el ]; then
    dnf -y -q --setopt=install_weak_deps=False install composer && return 0
  else
    DEBIAN_FRONTEND=noninteractive apt-get -o DPkg::Lock::Timeout=600 -y -q --no-install-recommends install composer && return 0
  fi
  echo "  Warning: the composer package could not be installed; the panel's Composer page says Composer is not installed until it is." >&2
}
check_apache2_php() {
  local c
  if "$WEB_CTL" -M 2>/dev/null | grep -Eq '^[[:space:]]*php[0-9._]*_module[[:space:]]'; then
    die "Apache loads mod_php, which runs every site's PHP as $WEB_USER; remove libapache2-mod-php (apt-get remove 'libapache2-mod-php*') and run the installer again"
  fi
  for c in /etc/apache2/conf-enabled/php*-fpm.conf; do
    [ -e "$c" ] || continue
    die "Apache has $(basename "$c" .conf) on (a2enconf), which sends every site's PHP to the package's own pool as $WEB_USER; turn it off with a2disconf $(basename "$c" .conf) and run the installer again"
  done
}

if [ "$WEB" -eq 1 ] && [ "$FAMILY" = el ]; then
  say "Installing the web stack (Apache, mod_ssl, PHP $PHP from Remi)"
  install_epel_rhel
  dnf -y -q install epel-release dnf-plugins-core
  enable_crb
  rpm -q remi-release >/dev/null || install_remi
  install_httpd
  require_httpd
  disable_httpd_modules
  # PHP-FPM and the extensions the panel's own PHP install puts on every
  # version (modules/web/phpfpm, remiExtensions; a test keeps the two lists the
  # same), so a site behaves the same on any version and the app installer can
  # run an app's own install with the command line. The version's PEAR command
  # (php-pear, PHP code only) installs a customer's PEAR packages in their own
  # home (modules/libraries); the panel runs it as the account, never as root.
  dnf -y -q install "$PHP_PKG-php-fpm" "$PHP_PKG-php-cli" "$PHP_PKG-php-mysqlnd" "$PHP_PKG-php-pdo" \
    "$PHP_PKG-php-mbstring" "$PHP_PKG-php-xml" "$PHP_PKG-php-gd" "$PHP_PKG-php-intl" "$PHP_PKG-php-opcache" \
    "$PHP_PKG-php-soap" "$PHP_PKG-php-bcmath" "$PHP_PKG-php-sodium" "$PHP_PKG-php-pecl-zip" "$PHP_PKG-php-pear"
  install_composer
elif [ "$WEB" -eq 1 ]; then
  if [ "$PHP_PPA" -eq 1 ]; then
    say "Installing the web stack (Apache, mod_ssl, PHP $PHP from Ondřej Surý's PHP repository)"
    pkg_install gnupg
    setup_ondrej_ppa
  else
    say "Installing the web stack (Apache, mod_ssl, PHP $PHP from ${PRETTY_NAME:-the distribution})"
  fi
  # shellcheck disable=SC2086 # the package names are words
  pkg_install $APACHE2_PKGS
  # freePanel's Apache build is pinned above the system's (setup-apt.sh); this
  # puts it in place of a system build installed earlier, even a later one.
  if [ -f /etc/apt/preferences.d/freepanel-apache2 ]; then
    # shellcheck disable=SC2086
    DEBIAN_FRONTEND=noninteractive apt-get -o DPkg::Lock::Timeout=600 -y -q install --allow-downgrades $APACHE2_PKGS ||
      echo "  Warning: could not put freePanel's Apache build in place; the security check will say so." >&2
  fi
  require_apache2
  enable_apache2_modules
  disable_apache2_default_site
  disable_apache2_modules
  out="$(apachectl -t 2>&1)" || die "Apache's configuration does not pass apachectl -t after turning on $APACHE2_MODULES and off the default site: $out"
  if systemctl is-active --quiet "$WEB_UNIT"; then systemctl reload "$WEB_UNIT"; fi
  # The same extensions as on EL, by Debian's names (modules/web/phpfpm,
  # debExtensions; a test keeps the two lists the same). pdo and sodium are
  # built into Ubuntu's PHP (php8.3-common, php8.3-cli), mysqlnd comes with
  # php8.3-mysql and zip is php8.3-zip. OPcache is part of PHP itself from 8.5
  # (php8.5-common), with no package of its own. php-pear is PHP code only, run
  # with the version's command line PHP, which it needs.
  opcache_pkg="php$PHP_TAG-opcache"
  [ "$PHP" != 8.5 ] || opcache_pkg=
  # shellcheck disable=SC2086 # opcache_pkg is one word or none
  pkg_install "php$PHP_TAG-fpm" "php$PHP_TAG-cli" "php$PHP_TAG-mysql" "php$PHP_TAG-mbstring" \
    "php$PHP_TAG-xml" "php$PHP_TAG-gd" "php$PHP_TAG-intl" $opcache_pkg "php$PHP_TAG-soap" \
    "php$PHP_TAG-bcmath" "php$PHP_TAG-zip" php-pear
  install_composer
  # Each version's pool sockets are in a folder of root's (modules/web/phpfpm,
  # UbuntuSocketBase), not in the packages' /run/php, which Apache's own user
  # owns. /run is emptied at boot, so systemd-tmpfiles makes the folders before
  # PHP-FPM starts; the list is every version the panel offers on Ubuntu (a test
  # holds it to phpfpm.UbuntuSupported).
  apparmor_php_fpm
  PHP_SOCK_BASE=/run/freepanel-php
  PHP_SOCK_VERSIONS="8.2 8.3 8.4 8.5"
  {
    printf '# Written by the freePanel installer: the folders of the PHP pools'"'"' sockets.\n'
    printf 'd %s 0755 root root -\n' "$PHP_SOCK_BASE"
    for v in $PHP_SOCK_VERSIONS; do printf 'd %s/%s 0755 root root -\n' "$PHP_SOCK_BASE" "$v"; done
  } >/etc/tmpfiles.d/freepanel-php.conf.new
  chmod 0644 /etc/tmpfiles.d/freepanel-php.conf.new
  mv -f /etc/tmpfiles.d/freepanel-php.conf.new /etc/tmpfiles.d/freepanel-php.conf
  systemd-tmpfiles --create /etc/tmpfiles.d/freepanel-php.conf
fi
if [ "$WEB" -eq 1 ]; then
  # Served by Apache itself (validation files, the catch-all and suspended
  # pages), so outside the panel's own 0750 state; parked web files are
  # root's alone.
  install -d -m 0755 -o root -g root /var/www/freepanel
  install -d -m 0700 -o root -g root /var/lib/freepanel-web /var/lib/freepanel-web/parked
  if command -v restorecon >/dev/null; then restorecon -R /var/www/freepanel /var/lib/freepanel-web || true; fi

  # SELinux (the web module's list, modules/web): Apache and PHP-FPM enter
  # the 0711 homes, PHP may connect out, to databases and to the local
  # mailer, and a pool's open-file limit can be set; site logs, certificates, each home's tmp/ and the password
  # files of protected folders (~/.htpasswds, read-only to Apache) and each home's
  # logs/ (PHP's error log, written by the pool's workers) get
  # their types.
  # Site folders are labelled by the web module as it creates them.
  if command -v selinuxenabled >/dev/null && selinuxenabled; then
    say "Setting SELinux booleans and file types for websites"
    dnf -y -q install policycoreutils-python-utils
    keep_sebools httpd_enable_homedirs httpd_can_network_connect httpd_can_network_connect_db httpd_can_sendmail httpd_setrlimit
    keep_selinux_local
    setsebool -P httpd_enable_homedirs=on httpd_can_network_connect=on \
      httpd_can_network_connect_db=on httpd_can_sendmail=on
    # PHP-FPM (httpd_t) sets each pool's rlimit_files (the PHP tuning's open-file
    # limit) with setrlimit, which SELinux allows only with httpd_setrlimit; off,
    # the worker keeps the master's limit and php-fpm logs the failure.
    if getsebool httpd_setrlimit >/dev/null 2>&1; then
      setsebool -P httpd_setrlimit=on
    fi
    while read -r type spec; do
      semanage fcontext -a -t "$type" "$spec" 2>/dev/null || semanage fcontext -m -t "$type" "$spec"
    done <<'FCONTEXT'
httpd_log_t /var/log/freepanel/domlogs(/.*)?
cert_t /etc/freepanel/ssl(/.*)?
httpd_user_rw_content_t /home/[^/]+/tmp(/.*)?
httpd_user_rw_content_t /home/[^/]+/logs(/.*)?
httpd_user_content_t /home/[^/]+/\.htpasswds(/.*)?
FCONTEXT
    # The sites' log folder is made here, before the root agent would make it: a folder the
    # agent makes takes /var/log's type (var_log_t) and keeps it, Apache can still make its
    # own logs there (the policy's rule for files it creates) but rotatelogs, which the piped
    # access log runs as httpd_rotatelogs_t, cannot, and the log never gets a line (check 389,
    # first fresh install of main with the includes). The agent keeps the folder as it finds it.
    install -d -m 0755 /var/log/freepanel
    install -d -m 0750 /var/log/freepanel/domlogs
    for d in /var/log/freepanel/domlogs /etc/freepanel/ssl; do
      if [ -e "$d" ]; then restorecon -R "$d"; fi
    done
  fi

  if [ ! -f "$ETC/web.json" ]; then
    say "Writing $ETC/web.json (new sites get PHP $PHP)"
    printf '{"default_php":"%s"}\n' "$PHP" >"$ETC/web.json"
    chown root:root "$ETC/web.json"
    chmod 0644 "$ETC/web.json"
    if command -v restorecon >/dev/null; then restorecon "$ETC/web.json" || true; fi
  else
    say "Keeping existing $ETC/web.json"
  fi
  keep_units "$WEB_UNIT" "$PHP_UNIT"
  systemctl enable --quiet --now "$WEB_UNIT" "$PHP_UNIT"
  check_httpd_modules
  [ "$FAMILY" = el ] || check_apache2_php
  [ "$FAMILY" = el ] || apparmor_web
elif [ "$FAMILY" = el ] && [ -f "$ETC/web.json" ] && [ -x /usr/sbin/httpd ]; then
  # A re-run without --web still keeps Apache's minimum and its modules off.
  require_httpd
  disable_httpd_modules
  check_httpd_modules
elif [ -f "$ETC/web.json" ] && [ -x /usr/sbin/apache2 ]; then
  require_apache2
  disable_apache2_modules
  check_httpd_modules
  check_apache2_php
fi

# ---- Web application firewall and virus scanner (--web) -------------------
# Both come with the web stack, from the system's own package sources with
# their signatures checked, unless --no-waf or --no-virus-scan says otherwise
# (and the closing lines say so in capitals). The root agent turns them on at
# its first start, once, where the admin never set them: the firewall
# (ModSecurity with the OWASP Core Rule Set) in block mode, the scanner
# (ClamAV) where the server has the memory it needs (modules/web/webd,
# wafdefault.go and clamdefault.go). Until then the panel's own files keep the
# engine off and the scanner's services stopped. A package that cannot be
# installed stops the install: nothing is skipped quietly.
WAF_OFF_WHY=""
SCAN_OFF_WHY=""
if [ "$WEB" -eq 1 ]; then
  if [ "$NO_WAF" -eq 1 ]; then
    WAF_OFF_WHY="--no-waf was given"
  else
    say "Installing the web application firewall (ModSecurity with the OWASP Core Rule Set)"
    if [ "$FAMILY" = el ]; then
      pkg_install mod_security mod_security_crs \
        || die "the web application firewall's packages (mod_security, mod_security_crs) could not be installed; fix the package sources and run the installer again, or give --no-waf to go without it"
    else
      pkg_install libapache2-mod-security2 modsecurity-crs \
        || die "the web application firewall's packages (libapache2-mod-security2, modsecurity-crs) could not be installed; fix the package sources and run the installer again, or give --no-waf to go without it"
    fi
  fi
  if [ "$NO_SCAN" -eq 1 ]; then
    SCAN_OFF_WHY="--no-virus-scan was given"
  else
    say "Installing the virus scanner (ClamAV)"
    if [ "$FAMILY" = el ]; then
      pkg_install clamd clamav clamav-update \
        || die "the virus scanner's packages (clamd, clamav, clamav-update) could not be installed; fix the package sources and run the installer again, or give --no-virus-scan to go without it"
    else
      # Debian's packages start their services on the packages' own settings,
      # with the socket open to every account: held for the install, then
      # left stopped until the root agent writes the panel's and starts them.
      pkg_install_held clamav-daemon.socket clamav-daemon.service clamav-freshclam.service -- clamav-daemon clamav-freshclam \
        || die "the virus scanner's packages (clamav-daemon, clamav-freshclam) could not be installed; fix the package sources and run the installer again, or give --no-virus-scan to go without it"
      if [ ! -f /var/lib/freepanel-privd/web/clamav.json ]; then
        systemctl disable --now --quiet clamav-daemon.socket clamav-daemon.service clamav-freshclam.service 2>/dev/null || true
      fi
    fi
    mem_kb="$(awk '$1 == "MemTotal:" { print $2 }' /proc/meminfo)"
    # The agent's threshold (webd.ScanDefaultMinKB): the daemon keeps about
    # 1.5 GB, too much to take by default from a server under 4 GB.
    if [ "${mem_kb:-0}" -lt 3670016 ]; then
      SCAN_OFF_WHY="this server has $((mem_kb / 1024)) MB of memory; the scanner keeps about 1.5 GB of it, so it is turned on by default only from 4 GB (it can be turned on from 2 GB)"
    fi
  fi
fi

# ---- MySQL databases (--mysql) ---------------------------------------------
# MariaDB from the distribution, reached by the root agent as root over its
# socket (modules/mysql). Customers' database users connect from this server
# only, so MariaDB listens on 127.0.0.1.
if [ "$MYSQL" -eq 1 ]; then
  say "Installing MariaDB"
  if [ "$FAMILY" = el ]; then
    pkg_install mariadb-server
    MYSQL_SOCKET=/var/lib/mysql/mysql.sock
    # Read after the packaged mariadb-server.cnf, so these settings win.
    MYSQL_CNF=/etc/my.cnf.d/zz-freepanel.cnf
    if [ -f /etc/my.cnf.d/freepanel.cnf ] && grep -q '^# Written by the freePanel installer' /etc/my.cnf.d/freepanel.cnf; then
      mv /etc/my.cnf.d/freepanel.cnf "/etc/my.cnf.d/freepanel.cnf.parked-$(date -u +%Y%m%dT%H%M%SZ)"
    fi
  else
    pkg_install mariadb-server mariadb-client
    MYSQL_SOCKET=/run/mysqld/mysqld.sock
    MYSQL_CNF=/etc/mysql/mariadb.conf.d/90-freepanel.cnf
  fi
  cat >"$MYSQL_CNF" <<'CNF'
# Written by the freePanel installer; re-running it rewrites this file.
[mysqld]
bind-address = 127.0.0.1
# Table files stay in the data folder (DATA DIRECTORY is ignored).
symbolic-links = 0
# No one database user can take every connection on the server.
max_user_connections = 25
CNF
  chmod 0644 "$MYSQL_CNF"
  if command -v restorecon >/dev/null; then restorecon "$MYSQL_CNF" || true; fi
  keep_units mariadb
  systemctl enable --quiet mariadb
  systemctl restart mariadb
  for _ in $(seq 1 30); do
    [ -S "$MYSQL_SOCKET" ] && break
    sleep 1
  done
  [ -S "$MYSQL_SOCKET" ] || die "MariaDB did not start; see: journalctl -u mariadb"
  # No sign-in without a name: drop any anonymous users and the open grant
  # on test databases that some packages ship. Nothing is stored in either.
  mariadb --protocol=socket --socket="$MYSQL_SOCKET" --user=root <<'SQL'
DROP USER IF EXISTS ''@'localhost';
DROP USER IF EXISTS ''@'%';
DELETE FROM mysql.db WHERE Db IN ('test', 'test\_%');
FLUSH PRIVILEGES;
SQL
  install -d -m 0700 -o root -g root /var/lib/freepanel-mysql /var/lib/freepanel-mysql/parked
  if command -v restorecon >/dev/null; then restorecon -R /var/lib/freepanel-mysql || true; fi
  if [ ! -f "$ETC/mysql.json" ]; then
    say "Writing $ETC/mysql.json"
    printf '{"socket":"%s"}\n' "$MYSQL_SOCKET" >"$ETC/mysql.json"
    chown root:root "$ETC/mysql.json"
    chmod 0644 "$ETC/mysql.json"
    if command -v restorecon >/dev/null; then restorecon "$ETC/mysql.json" || true; fi
  else
    say "Keeping existing $ETC/mysql.json"
  fi
fi

# ---- DNS (--dns) -----------------------------------------------------------
# PowerDNS with its bind backend reading the zone list the DNS module
# writes (modules/dns/README.md). Our settings go in their own file in
# PowerDNS's include folder, so the packaged pdns.conf stays as shipped
# apart from turning that folder on where the package leaves it off.
if [ "$DNS" -eq 1 ]; then
  say "Installing PowerDNS"
  if [ "$FAMILY" = el ]; then
    install_epel_rhel
    dnf -y -q install epel-release
    dnf -y -q install pdns
    PDNS_ETC=/etc/pdns
  else
    pkg_install pdns-server pdns-backend-bind
    PDNS_ETC=/etc/powerdns
  fi
  getent group pdns >/dev/null || die "the PowerDNS package did not create the pdns group"

  # Zone files and the zone list are read by PowerDNS (group pdns); parked
  # zones are root's alone. The DNS module keeps these modes as it writes.
  install -d -m 0750 -o root -g pdns /var/lib/freepanel-dns /var/lib/freepanel-dns/zones
  install -d -m 0700 -o root -g root /var/lib/freepanel-dns/parked
  # Zones this server takes from a primary (the DNS cluster): PowerDNS writes
  # them itself, so the folder is its own.
  install -d -m 0700 -o pdns -g pdns /var/lib/freepanel-dns/secondary
  if [ ! -f /var/lib/freepanel-dns/named.conf ]; then
    install -m 0640 -o root -g pdns /dev/null /var/lib/freepanel-dns/named.conf
  fi
  # PowerDNS's SELinux domain reads only its own types, so our folder gets
  # the type of its packaged /var/lib/pdns; files the DNS module creates in
  # it inherit the type.
  if command -v selinuxenabled >/dev/null && selinuxenabled; then
    dnf -y -q install policycoreutils-python-utils
    keep_selinux_local
    semanage fcontext -a -t pdns_var_lib_t '/var/lib/freepanel-dns(/.*)?' 2>/dev/null ||
      semanage fcontext -m -t pdns_var_lib_t '/var/lib/freepanel-dns(/.*)?'
  fi
  if command -v restorecon >/dev/null; then restorecon -R /var/lib/freepanel-dns || true; fi

  # DNSSEC keys live in the bind backend's own sqlite database (the zone files
  # never hold one). The folder is PowerDNS's alone: sqlite writes its journal
  # beside the file. A PowerDNS built without sqlite cannot make the database;
  # the panel then says DNSSEC is unavailable and everything else is as before.
  DNSSEC_DB=/var/lib/freepanel-dns/dnssec/bind-dnssec.db
  install -d -m 0700 -o pdns -g pdns /var/lib/freepanel-dns/dnssec
  # (An empty file is what a create-bind-db that died half-way leaves.)
  if [ -e "$DNSSEC_DB" ] && [ ! -s "$DNSSEC_DB" ]; then rm -f "$DNSSEC_DB"; fi
  if [ ! -s "$DNSSEC_DB" ]; then
    runuser -u pdns -- pdnsutil create-bind-db "$DNSSEC_DB" >/dev/null 2>&1 ||
      printf 'install: PowerDNS could not make its DNSSEC database; DNSSEC stays off\n' >&2
  fi
  if command -v restorecon >/dev/null; then restorecon -R /var/lib/freepanel-dns/dnssec || true; fi

  # Zone transfers (the DNS cluster) go on only while no zone allows them to
  # an address without a key: ALLOW-AXFR-FROM, set by hand and inert while
  # transfers were off, would hand those zones to that address unsigned. The
  # panel's key helper, run as PowerDNS's user, lists such zones; anything but
  # a plain "none" (an unreadable database too) keeps transfers off.
  DISABLE_AXFR=no
  if [ -s "$DNSSEC_DB" ]; then
    XFR_ROWS="$(printf '{"db":"%s","op":"axfr-from"}' "$DNSSEC_DB" |
      runuser -u pdns -- "$PREFIX/bin/freepanel-privd" dns-xfr-db 2>/dev/null || true)"
    if [ "$XFR_ROWS" != "{}" ]; then
      DISABLE_AXFR=yes
      printf 'install: zone transfers stay off (the DNS cluster page says why): %s\n' "${XFR_ROWS:-the transfer settings could not be read}" >&2
      printf 'install: remove ALLOW-AXFR-FROM from those zones (runuser -u pdns -- pdnsutil set-meta ZONE ALLOW-AXFR-FROM), then re-run the installer\n' >&2
    fi
  fi

  install -d -m 0755 "$PDNS_ETC/pdns.d"
  if ! grep -q '^include-dir=' "$PDNS_ETC/pdns.conf"; then
    keep_original "$PDNS_ETC/pdns.conf"
    printf '\n# Added by the freePanel installer: settings in pdns.d/\ninclude-dir=%s/pdns.d\n' \
      "$PDNS_ETC" >>"$PDNS_ETC/pdns.conf"
  fi
  # PowerDNS answers on loopback and this server's own addresses, not on
  # every address, so it sits beside a local resolver's stub (such as
  # systemd-resolved's on 127.0.0.53) without touching it. An address added
  # later is served after re-running the installer.
  LISTEN="127.0.0.1"
  [ -e /proc/sys/net/ipv6/conf/lo ] && LISTEN="$LISTEN, ::1"
  while read -r addr; do
    LISTEN="$LISTEN, $addr"
  done < <(ip -o addr show scope global | awk '{ split($4, a, "/"); print a[1] }')
  # launch= replaces any backend list set before it, such as Ubuntu's
  # pdns.d/bind.conf; this file sorts after it.
  cat >"$PDNS_ETC/pdns.d/freepanel.conf" <<CONF
# Written by the freePanel installer; re-running it rewrites this file.
launch=bind
bind-config=/var/lib/freepanel-dns/named.conf
version-string=anonymous
# Zone transfers (the admin's DNS cluster page, modules/dns/README.md): only
# to a request signed with a TSIG key the zone lists, never by address;
# NOTIFY only to the secondaries a zone lists (also-notify), never to the
# addresses of its NS records. With no secondary set, no zone lists a key.
# A zone taken from another server is at most 10 MB.
disable-axfr=$DISABLE_AXFR
allow-axfr-ips=
only-notify=
primary=yes
secondary=yes
xfr-max-received-mbytes=10
local-address=$LISTEN
local-address-nonexist-fail=no
CONF
  if [ -s "$DNSSEC_DB" ]; then
    printf 'bind-dnssec-db=%s\n' "$DNSSEC_DB" >>"$PDNS_ETC/pdns.d/freepanel.conf"
  fi
  chmod 0644 "$PDNS_ETC/pdns.d/freepanel.conf"

  if [ ! -f "$ETC/dns.json" ]; then
    say "Writing $ETC/dns.json (name servers $NAMESERVERS, new zones point at $DNS_IP)"
    IFS=, read -ra NS_LIST <<<"${NAMESERVERS,,}"
    NS_JSON="$(printf '"%s",' "${NS_LIST[@]}")"
    printf '{"nameservers":[%s],"ipv4":"%s","hostmaster":"hostmaster@%s"}\n' \
      "${NS_JSON%,}" "$DNS_IP" "${HOSTNAME_FQDN,,}" >"$ETC/dns.json"
    chown root:root "$ETC/dns.json"
    chmod 0644 "$ETC/dns.json"
    if command -v restorecon >/dev/null; then restorecon "$ETC/dns.json" || true; fi
  else
    say "Keeping existing $ETC/dns.json"
  fi
  keep_units pdns
  systemctl enable --quiet pdns
  if ! systemctl restart pdns; then
    ss -lnupt 'sport = :53' >&2 || true
    die "PowerDNS did not start (what holds port 53 is listed above); see: journalctl -u pdns"
  fi
fi

# rspamd (--spam), from rspamd.com's stable repository, stopped and not
# enabled: its stock configuration looks names up on third-party lists and
# fetches rules from rspamd.com, so nothing runs until an administrator
# turns spam filtering on and the mail module writes a configuration of its
# own (modules/mail/README.md). A server that has rspamd already keeps its
# repository, its version and its state: only the group below is added.
#
# The repository file is written here, not downloaded: includepkgs limits it
# to rspamd's own packages, so it can never supply an update of anything
# else, and skip_if_unavailable keeps an outage of rspamd.com from stopping
# the system's other updates. Its signing key is fetched over HTTPS and
# imported only if it is the key with RSPAMD_KEY_FPR: the export below holds
# that key alone, whatever else the downloaded file has in it.

# rspamd_key_ok GNUPGHOME FILE says whether FILE holds exactly one primary
# key, that it is the one with RSPAMD_KEY_FPR (not a subkey of another key
# that has the same fingerprint), and that gpg does not call it revoked,
# expired, invalid or disabled: rpm --import ignores a revocation, so this is
# the only place that refuses a key its owner has withdrawn. GNUPGHOME is a
# throwaway folder, so reading the file leaves nothing in root's own.
rspamd_key_ok() {
  GNUPGHOME="$1" gpg --batch --show-keys --with-colons "$2" 2>/dev/null |
    awk -F: -v fpr="$RSPAMD_KEY_FPR" '
      $1 == "pub" {n++; primary = 1; if ($2 ~ /^[reid]$/) bad = 1; next}
      $1 == "fpr" && primary {if ($10 == fpr) ok = 1; primary = 0}
      $1 == "sub" {primary = 0}
      END {exit !(ok && n == 1 && !bad)}'
}

install_rspamd() {
  local tmp gnupg keyid
  if [ "$FAMILY" != el ]; then
    install_rspamd_apt
    return
  fi
  # Before the first change: the unit and the group are absent on a server
  # that has no rspamd, and the repository file is too.
  keep_units rspamd
  keep_group _rspamd
  keep_original "$RSPAMD_REPO_FILE"
  if rpm -q "$RSPAMD_PKG" >/dev/null 2>&1; then
    say "rspamd is installed: keeping its repository and its state"
    return 0
  fi
  say "Installing rspamd (rspamd.com's repository)"
  dnf -y -q install gnupg2
  tmp="$(mktemp -d)"
  gnupg="$tmp/gnupg"
  install -d -m 0700 "$gnupg"
  curl -fsS --proto '=https' --tlsv1.2 --max-time 60 -o "$tmp/key.asc" "$RSPAMD_KEY_URL" ||
    die "could not download $RSPAMD_KEY_URL"
  if GNUPGHOME="$gnupg" gpg --batch --quiet --import "$tmp/key.asc" 2>/dev/null; then
    GNUPGHOME="$gnupg" gpg --batch --armor --export --export-options export-minimal "$RSPAMD_KEY_FPR" >"$tmp/rspamd.asc" 2>/dev/null || true
  fi
  # Exactly one primary key in the export, and it is the pinned one and not
  # withdrawn; a download that is no key, or has no such key, leaves nothing
  # to check.
  rspamd_key_ok "$gnupg" "$tmp/rspamd.asc" || {
    GNUPGHOME="$gnupg" gpgconf --kill gpg-agent 2>/dev/null || true
    rm -rf "$tmp"
    die "$RSPAMD_KEY_URL does not have the Rspamd packages key ($RSPAMD_KEY_FPR), or it is revoked, expired or invalid"
  }
  # gpg started an agent for the throwaway home; it would outlive its folder.
  GNUPGHOME="$gnupg" gpgconf --kill gpg-agent 2>/dev/null || true
  rpm --import "$tmp/rspamd.asc"
  keyid="${RSPAMD_KEY_FPR: -8}"
  rpm -q "gpg-pubkey-${keyid,,}" >/dev/null 2>&1 || die "the Rspamd packages key was not imported"
  rm -rf "$tmp"
  cat >"$RSPAMD_REPO_FILE" <<REPO
# Written by the freePanel installer (--spam): rspamd's own packages from rspamd.com.
[freepanel-rspamd]
name=rspamd stable repository (rspamd.com)
baseurl=${RSPAMD_REPO_URL//@EL@/${EL_MAJOR:-9}}
enabled=1
gpgcheck=1
includepkgs=rspamd*
skip_if_unavailable=1
REPO
  chown root:root "$RSPAMD_REPO_FILE"
  chmod 0644 "$RSPAMD_REPO_FILE"
  if command -v restorecon >/dev/null; then restorecon "$RSPAMD_REPO_FILE" || true; fi
  dnf -y -q install "$RSPAMD_PKG"
  # The package leaves its service off; this makes sure of it for a build
  # that does not.
  systemctl disable --now rspamd >/dev/null 2>&1 || true
}

# install_rspamd_apt is install_rspamd on Ubuntu. The key is the release's
# own file, checked as above (the only check of a revocation, since apt
# reads none), and apt trusts it for rspamd.com's repository alone
# (Signed-By). A pin keeps every package of that repository but rspamd's
# own from ever being installed or upgraded from it (apt's includepkgs).
# apt itself refuses the repository if its index is not signed by that key.
install_rspamd_apt() {
  local tmp key="$SRC/$RSPAMD_APT_KEYFILE"
  keep_units rspamd
  keep_group _rspamd
  keep_original "$RSPAMD_APT_SOURCES" "$RSPAMD_APT_PIN" "$RSPAMD_APT_KEY"
  if [ "$(dpkg-query -W -f '${db:Status-Status}' "$RSPAMD_PKG" 2>/dev/null || true)" = installed ]; then
    say "rspamd is installed: keeping its repository and its state"
    return 0
  fi
  say "Installing rspamd (rspamd.com's repository)"
  pkg_install gpg
  tmp="$(mktemp -d)"
  install -d -m 0700 "$tmp/gnupg"
  # The file is one armored key (apt reads a Signed-By file ending in .asc
  # as armored only), the pinned one; and imported, with whatever else the
  # file holds merged into it (a revocation), it is still not withdrawn.
  if GNUPGHOME="$tmp/gnupg" gpg --batch --quiet --import -- "$key" 2>/dev/null; then
    GNUPGHOME="$tmp/gnupg" gpg --batch --armor --export --export-options export-minimal "$RSPAMD_KEY_FPR" >"$tmp/merged.asc" 2>/dev/null || true
  fi
  if ! head -n 1 -- "$key" 2>/dev/null | grep -qx -- '-----BEGIN PGP PUBLIC KEY BLOCK-----' ||
    ! rspamd_key_ok "$tmp/gnupg" "$key" || ! rspamd_key_ok "$tmp/gnupg" "$tmp/merged.asc"; then
    GNUPGHOME="$tmp/gnupg" gpgconf --kill gpg-agent 2>/dev/null || true
    rm -rf "$tmp"
    die "$RSPAMD_APT_KEYFILE is not the Rspamd packages key ($RSPAMD_KEY_FPR) alone, or it is revoked, expired or invalid"
  fi
  GNUPGHOME="$tmp/gnupg" gpgconf --kill gpg-agent 2>/dev/null || true
  rm -rf "$tmp"
  install -d -m 0755 -o root -g root "$(dirname -- "$RSPAMD_APT_KEY")"
  install -m 0644 -o root -g root -- "$key" "$RSPAMD_APT_KEY.new"
  mv -f -- "$RSPAMD_APT_KEY.new" "$RSPAMD_APT_KEY"
  cat >"$RSPAMD_APT_PIN.new" <<'PIN'
# Written by the freePanel installer (--spam): from rspamd.com, rspamd's own
# packages only.
Package: rspamd rspamd-*
Pin: origin "rspamd.com"
Pin-Priority: 500

Package: *
Pin: origin "rspamd.com"
Pin-Priority: -1
PIN
  chmod 0644 "$RSPAMD_APT_PIN.new"
  mv -f -- "$RSPAMD_APT_PIN.new" "$RSPAMD_APT_PIN"
  cat >"$RSPAMD_APT_SOURCES.new" <<SOURCES
# Written by the freePanel installer (--spam): rspamd's own packages from
# rspamd.com, trusted by the key in $RSPAMD_APT_KEY alone.
Types: deb
URIs: $RSPAMD_APT_URL
Suites: $CODENAME
Components: main
Signed-By: $RSPAMD_APT_KEY
SOURCES
  chmod 0644 "$RSPAMD_APT_SOURCES.new"
  mv -f -- "$RSPAMD_APT_SOURCES.new" "$RSPAMD_APT_SOURCES"
  pkg_update
  pkg_install_held rspamd.service -- "$RSPAMD_PKG"
  # As on EL: off until spam filtering is turned on.
  systemctl disable --now rspamd >/dev/null 2>&1 || true
}

# The mail agent's Postfix tables (modules/mail) live in a folder only root
# writes and Postfix reads. The agent checks it and writes no table while it
# is anything else; this line puts it back at every boot.
mail_tables_folder() {
  printf '# Written by the freePanel installer.\nd /etc/postfix/freepanel 0750 root postfix -\n' \
    >/etc/tmpfiles.d/freepanel-mail.conf
  chmod 0644 /etc/tmpfiles.d/freepanel-mail.conf
  systemd-tmpfiles --create /etc/tmpfiles.d/freepanel-mail.conf
  if command -v restorecon >/dev/null; then restorecon /etc/postfix/freepanel || true; fi
}

# ---- Email (--mail) --------------------------------------------------------
# Postfix receives and sends, Dovecot serves IMAP and checks mailbox
# passwords; the mail module writes their freePanel settings
# (modules/mail/README.md). Mail is kept in each home's mail/ folder.
# Filters and autoresponders run in Dovecot's Sieve plugin
# (dovecot-pigeonhole); without it their endpoints answer 503. Only the
# plugin is used: freePanel's dovecot.conf includes none of the package's
# conf.d files, so ManageSieve stays off.
if [ "$MAIL" -eq 1 ]; then
  say "Installing the mail stack (Postfix, Dovecot, Sieve)"
  POSTFIX_NEW=0
  if [ "$FAMILY" = el ]; then
    pkg_install postfix dovecot dovecot-pigeonhole
  else
    # Ubuntu splits Dovecot by protocol (freePanel's config serves IMAP,
    # LMTP for delivery and POP3, as EL's one package does) and calls
    # Pigeonhole dovecot-sieve. Postfix asks on its first install how it is
    # to be used: as a mail server, named as this one.
    if [ "$(dpkg-query -W -f '${db:Status-Status}' postfix 2>/dev/null || true)" != installed ]; then
      POSTFIX_NEW=1
      printf 'postfix postfix/main_mailer_type select Internet Site\npostfix postfix/mailname string %s\n' "$HOSTNAME_FQDN" |
        debconf-set-selections
    fi
    pkg_install_held postfix.service postfix@-.service dovecot.service dovecot.socket -- \
      postfix dovecot-imapd dovecot-lmtpd dovecot-pop3d dovecot-sieve
  fi
  # Before the installer's own postconf -e, and before freepanel-privd
  # first writes Postfix's settings and Dovecot's config.
  keep_original /etc/postfix/main.cf /etc/postfix/master.cf /etc/dovecot/dovecot.conf
  keep_postconf
  # Postfix ships listening on localhost only; a mail server takes mail
  # from the internet.
  postconf -e inet_interfaces=all
  if [ "$FAMILY" != el ]; then
    # Ubuntu's master.cf runs most services chrooted in the spool, where the
    # milters' sockets (/run/opendkim, /run/freepanel-milter, /run/rspamd)
    # are not: none is, as on EL, on every run.
    postconf -F '*/*/chroot = n'
    # Postfix's first install wrote this server's name at the time into
    # main.cf; without them Postfix takes the system's hostname, as on EL,
    # and follows it when the panel changes it. It also wrote mynetworks
    # as the whole of 127.0.0.0/8 (and its IPv4-mapped form): every
    # loopback address could then relay without a login, a mail server the
    # admin trusts (modules/mail/blocks.go) on one too. Without it Postfix
    # trusts this machine's own addresses only (mynetworks_style host), as
    # on EL.
    [ "$POSTFIX_NEW" -eq 0 ] || postconf -X myhostname mydestination myorigin mynetworks
  fi
  mail_tables_folder
  if command -v selinuxenabled >/dev/null && selinuxenabled; then
    say "Setting the SELinux file type for mail folders"
    dnf -y -q install policycoreutils-python-utils
    spec='/home/[^/]+/mail(/.*)?'
    keep_selinux_local
    semanage fcontext -a -t mail_home_rw_t "$spec" 2>/dev/null || semanage fcontext -m -t mail_home_rw_t "$spec"
    for d in /home/*/mail; do
      if [ -d "$d" ]; then restorecon -R "$d"; fi
    done
  fi
  if [ ! -f "$ETC/mail.json" ]; then
    say "Writing $ETC/mail.json"
    printf '{}\n' >"$ETC/mail.json"
    chown root:root "$ETC/mail.json"
    chmod 0644 "$ETC/mail.json"
    if command -v restorecon >/dev/null; then restorecon "$ETC/mail.json" || true; fi
  else
    say "Keeping existing $ETC/mail.json"
  fi

  # OpenDKIM signs the mail the server sends with each domain's key. The
  # root agent keeps the keys and the two tables (modules/mail/dkim); the
  # files sit where the package puts its own, so SELinux lets it read them.
  # It picks the key by the header freepanel-milter gives every message
  # (SenderHeaders), which names a domain only when the account that sent
  # the message holds it (modules/mail/milter); the agent lists keys in
  # SigningTable only while that milter runs first on every path OpenDKIM
  # signs.
  say "Setting up DKIM signing (OpenDKIM)"
  if [ "$FAMILY" = el ]; then
    install_epel_rhel
    pkg_install epel-release
    pkg_install opendkim
  else
    pkg_install_held opendkim.service -- opendkim
  fi
  install -d -m 0750 -o root -g opendkim /etc/opendkim
  install -d -m 0750 -o root -g opendkim /etc/opendkim/keys
  # The package ships example tables owned by opendkim; they are parked and
  # replaced by empty ones the agent rewrites. Ours (with the agent's
  # header) are kept, and get root:opendkim 0640 either way.
  # No host counts as internal: OpenDKIM's default (127.0.0.1) would sign
  # by From for any local SMTP client, such as a site's script on port 25.
  keep_original /etc/opendkim/InternalHosts /etc/opendkim/KeyTable /etc/opendkim/SigningTable /etc/opendkim.conf
  printf '# Written by the freePanel installer: no host is internal; OpenDKIM signs only\n# what Postfix marks ORIGINATING (MacroList in /etc/opendkim.conf).\n' >/etc/opendkim/InternalHosts
  chown root:opendkim /etc/opendkim/InternalHosts
  chmod 0640 /etc/opendkim/InternalHosts
  for t in KeyTable SigningTable; do
    f="/etc/opendkim/$t"
    if [ -f "$f" ] && ! grep -q '^# Written by freePanel' "$f"; then
      mv "$f" "$f.parked-$(date -u +%Y%m%dT%H%M%SZ)"
    fi
    if [ ! -f "$f" ]; then
      printf '# Written by freePanel from the keys in /etc/opendkim/keys; edits here are replaced.\n' >"$f"
    fi
    chown root:opendkim "$f"
    chmod 0640 "$f"
  done
  if [ -f /etc/opendkim.conf ] && ! grep -q '^# Written by the freePanel installer' /etc/opendkim.conf; then
    cp -p /etc/opendkim.conf "/etc/opendkim.conf.parked-$(date -u +%Y%m%dT%H%M%SZ)"
  fi
  cat >/etc/opendkim.conf <<'CONF'
# Written by the freePanel installer; re-running it rewrites this file.
# Signs what Postfix marks as sent from here (the submission port after a
# login, and the sendmail command's mail), where freepanel-milter runs
# first, for the domain its header names (never by the From address);
# checks the rest.
Mode sv
SenderHeaders X-Freepanel-Sign
MacroList daemon_name=ORIGINATING
InternalHosts /etc/opendkim/InternalHosts
PidFile /run/opendkim/opendkim.pid
Syslog yes
UserID opendkim:opendkim
Socket local:/run/opendkim/opendkim.sock
Umask 007
Canonicalization relaxed/relaxed
OversignHeaders From
KeyTable /etc/opendkim/KeyTable
SigningTable refile:/etc/opendkim/SigningTable
CONF
  chmod 0644 /etc/opendkim.conf
  if command -v restorecon >/dev/null; then restorecon -R /etc/opendkim.conf /etc/opendkim || true; fi
  # Postfix reaches the signer's socket through its group.
  keep_group opendkim
  usermod -aG opendkim postfix
  # Port 25 runs OpenDKIM alone, to check incoming mail; the root agent
  # puts freepanel-milter before it on the submission port and pickup's own
  # cleanup service, which are the paths OpenDKIM signs, on every start.
  # Outgoing mail waits while our milter is down (it starts under
  # Services); incoming mail keeps flowing, and mail goes out unsigned
  # while OpenDKIM is down.
  # shellcheck disable=SC2016 # $smtpd_milters is Postfix's own reference
  postconf -e 'smtpd_milters=local:/run/opendkim/opendkim.sock' \
    'non_smtpd_milters=$smtpd_milters' milter_default_action=accept smtpd_sasl_auth_enable=no
  if [ ! -f "$ETC/dkim.json" ]; then
    printf '{}\n' >"$ETC/dkim.json"
    chown root:root "$ETC/dkim.json"
    chmod 0644 "$ETC/dkim.json"
    if command -v restorecon >/dev/null; then restorecon "$ETC/dkim.json" || true; fi
  fi
  keep_units opendkim postfix dovecot
  systemctl enable --quiet opendkim
  systemctl restart opendkim

  if [ "$SPAM" -eq 1 ]; then
    install_rspamd
    getent group _rspamd >/dev/null || die "rspamd's package did not make the _rspamd group"
    # The milter socket is _rspamd's, 0660: Postfix reaches it as a member.
    # The restart below makes Postfix's processes take the group.
    usermod -aG _rspamd postfix
  fi

  systemctl enable --quiet postfix dovecot
  # A restart, not a start: inet_interfaces only changes on one. Dovecot
  # starts under Services, once freepanel-privd has written its settings.
  systemctl restart postfix
  systemctl is-active --quiet "$POSTFIX_UNIT" || die "Postfix did not start; see: journalctl -u $POSTFIX_UNIT"
elif [ -f "$ETC/mail.json" ] && [ -d /etc/postfix/freepanel ]; then
  # Mail set up by an earlier run (or an older installer), installed again
  # without --mail: the line is written all the same, so a drift is still
  # put back at boot.
  mail_tables_folder
fi

# ---- PostgreSQL databases (--postgres) -------------------------------------
# PostgreSQL from the distribution (version 16 on AlmaLinux, Rocky and RHEL 9),
# reached by the root agent as the postgres role over its socket
# (modules/postgres). It listens on localhost only. Our pg_hba.conf lets root
# and postgres in as postgres by peer, and everyone else only by password
# (SCRAM-SHA-256), so a system user never signs in as a role by name.
if [ "$POSTGRES" -eq 1 ]; then
  say "Installing PostgreSQL"
  if [ "$FAMILY" = el ]; then
    # EL10 has no module streams: its PostgreSQL is the default one.
    if [ "$EL_MAJOR" = 9 ] && ! rpm -q postgresql-server >/dev/null 2>&1; then
      dnf -y -q module reset postgresql
      dnf -y -q module enable postgresql:16
    fi
    dnf -y -q install postgresql-server postgresql
    if [ ! -f /var/lib/pgsql/data/PG_VERSION ]; then
      PGSETUP_INITDB_OPTIONS="--auth-local=peer --auth-host=scram-sha-256" postgresql-setup --initdb
    fi
    PG_DATA=/var/lib/pgsql/data
    PG_HBA="$PG_DATA/pg_hba.conf"
    PG_IDENT="$PG_DATA/pg_ident.conf"
    PG_CONF_DIR="$PG_DATA"
  else
    pkg_install postgresql
    PG_VER="$(find /etc/postgresql -mindepth 1 -maxdepth 1 -type d -printf '%f\n' | sort -V | tail -n 1)"
    if [ -z "$PG_VER" ] || [ ! -d "/etc/postgresql/$PG_VER/main" ]; then
      die "no PostgreSQL cluster under /etc/postgresql"
    fi
    PG_HBA="/etc/postgresql/$PG_VER/main/pg_hba.conf"
    PG_IDENT="/etc/postgresql/$PG_VER/main/pg_ident.conf"
    PG_CONF_DIR="/etc/postgresql/$PG_VER/main"
  fi
  keep_original "$PG_HBA" "$PG_IDENT" "$PG_CONF_DIR/postgresql.conf"
  # Our access rules replace the packaged ones, which are parked once.
  for f in "$PG_HBA" "$PG_IDENT"; do
    if [ -f "$f" ] && ! grep -q '^# Written by freePanel' "$f"; then
      cp -p "$f" "$f.parked-$(date -u +%Y%m%dT%H%M%SZ)"
    fi
  done
  cat >"$PG_HBA.freepanel-new" <<'HBA'
# Written by freePanel; re-running the installer rewrites this file.
# root (the agent) and postgres sign in as postgres by peer; every other role
# by password, over the socket or from this server only.
local   all  postgres                 peer map=freepanel
# Customers' database users (members of fpcustomers) reach only the panel's
# databases, which the root agent lists in freepanel-databases, and postgres;
# a database made outside the panel is never theirs, whatever its grants.
local   postgres,@freepanel-databases  +fpcustomers                 scram-sha-256
host    postgres,@freepanel-databases  +fpcustomers  127.0.0.1/32   scram-sha-256
host    postgres,@freepanel-databases  +fpcustomers  ::1/128        scram-sha-256
local   all  +fpcustomers                 reject
host    all  +fpcustomers  127.0.0.1/32   reject
host    all  +fpcustomers  ::1/128        reject
local   all  all                      scram-sha-256
host    all  all       127.0.0.1/32   scram-sha-256
host    all  all       ::1/128        scram-sha-256
HBA
  cat >"$PG_IDENT.freepanel-new" <<'IDENT'
# Written by freePanel; re-running the installer rewrites this file.
# MAPNAME   SYSTEM-USER  PG-USER
freepanel   root         postgres
freepanel   postgres     postgres
IDENT
  # The root agent rewrites the list; it starts empty.
  PG_DBLIST="$(dirname "$PG_HBA")/freepanel-databases"
  if [ ! -f "$PG_DBLIST" ]; then
    printf '# Written by freePanel: databases the panel made (pg_hba.conf).\n' >"$PG_DBLIST"
  fi
  chown root:postgres "$PG_DBLIST"
  chmod 0640 "$PG_DBLIST"
  if command -v restorecon >/dev/null; then restorecon "$PG_DBLIST" || true; fi
  for f in "$PG_HBA" "$PG_IDENT"; do
    chown postgres:postgres "$f.freepanel-new"
    chmod 0640 "$f.freepanel-new"
    mv -f "$f.freepanel-new" "$f"
    if command -v restorecon >/dev/null; then restorecon "$f" || true; fi
  done
  mkdir -p "$PG_CONF_DIR/conf.d"
  cat >"$PG_CONF_DIR/conf.d/freepanel.conf" <<'PGCONF'
# Written by freePanel; re-running the installer rewrites this file.
listen_addresses = 'localhost'
password_encryption = 'scram-sha-256'
PGCONF
  chown -R postgres:postgres "$PG_CONF_DIR/conf.d"
  chmod 0750 "$PG_CONF_DIR/conf.d"
  chmod 0640 "$PG_CONF_DIR/conf.d/freepanel.conf"
  if ! grep -q "^include_dir = 'conf.d'" "$PG_CONF_DIR/postgresql.conf"; then
    printf "\n# Added by freePanel\ninclude_dir = 'conf.d'\n" >>"$PG_CONF_DIR/postgresql.conf"
  fi
  if command -v restorecon >/dev/null; then restorecon -R "$PG_CONF_DIR" || true; fi
  keep_units postgresql
  systemctl enable --quiet postgresql
  systemctl restart postgresql
  for _ in $(seq 1 30); do
    [ -S /run/postgresql/.s.PGSQL.5432 ] && break
    sleep 1
  done
  [ -S /run/postgresql/.s.PGSQL.5432 ] || die "PostgreSQL did not start; see: journalctl -u postgresql"
  install -d -m 0700 -o root -g root /var/lib/freepanel-postgres /var/lib/freepanel-postgres/parked
  if command -v restorecon >/dev/null; then restorecon -R /var/lib/freepanel-postgres || true; fi
  # Rewritten every run: it names this server's files.
  printf '{"socket_dir":"/run/postgresql","hba_databases":"%s"}\n' "$PG_DBLIST" >"$ETC/postgres.json"
  chown root:root "$ETC/postgres.json"
  chmod 0644 "$ETC/postgres.json"
  if command -v restorecon >/dev/null; then restorecon "$ETC/postgres.json" || true; fi
fi

# fetch URL SHA256 DEST: download over HTTPS and keep it only if the
# checksum matches. A busy host (GitHub's release downloads answer 504 for
# minutes at a time) is tried again, for up to five minutes.
fetch() {
  curl -fsSL --proto '=https' --tlsv1.2 --retry 6 --retry-delay 10 --retry-max-time 300 \
    -o "$3.part" "$1" || die "could not download $1"
  echo "$2  $3.part" | sha256sum -c --quiet - || { rm -f "$3.part"; die "$1 does not match its pinned checksum"; }
  mv -f "$3.part" "$3"
}
# panel_origin PORT: a panel's origin as a browser sends it.
panel_origin() {
  if [ "$1" = 443 ]; then echo "https://$HOSTNAME_FQDN"; else echo "https://$HOSTNAME_FQDN:$1"; fi
}

# ---- Database admin tool (--dbadmin) ---------------------------------------
# phpMyAdmin for MySQL and Adminer for PostgreSQL, served by Apache on their
# own port (--dbadmin-port, 7445) so they are a separate origin from both
# panels, and run by their own PHP-FPM pool as the fpdbadmin system user.
# Customers reach them only through a sign-in the panel makes (an hour-long
# database user for their own databases), posted to signon.php. Both
# downloads are checked against the checksums pinned here.
if [ "$DBADMIN" -eq 1 ]; then
  say "Installing the database admin tool (phpMyAdmin $PMA_VERSION, Adminer $ADMINER_VERSION)"
  DBA=$PREFIX/dbadmin
  DBA_STATE=/var/lib/freepanel-dbadmin
  DBA_SOCK=$PHP_SOCK_DIR/freepanel-dbadmin.sock
  if [ "$FAMILY" = el ]; then
    DBA_PHP_EXT=("$PHP_PKG-php-mbstring" "$PHP_PKG-php-xml" "$PHP_PKG-php-sodium")
    [ "$MYSQL" -eq 0 ] || DBA_PHP_EXT+=("$PHP_PKG-php-mysqlnd")
    [ "$POSTGRES" -eq 0 ] || DBA_PHP_EXT+=("$PHP_PKG-php-pgsql")
    dnf -y -q install "${DBA_PHP_EXT[@]}" xz
  else
    # sodium is built into Ubuntu's PHP; mysqlnd comes with phpX.Y-mysql.
    DBA_PHP_EXT=("php$PHP_TAG-mbstring" "php$PHP_TAG-xml")
    [ "$MYSQL" -eq 0 ] || DBA_PHP_EXT+=("php$PHP_TAG-mysql")
    [ "$POSTGRES" -eq 0 ] || DBA_PHP_EXT+=("php$PHP_TAG-pgsql")
    pkg_install "${DBA_PHP_EXT[@]}" xz-utils
  fi

  if ! id fpdbadmin >/dev/null 2>&1; then
    useradd --system --user-group --home-dir "$DBA_STATE" --no-create-home --shell "$NOLOGIN" fpdbadmin
  fi
  install -d -m 0750 -o root -g fpdbadmin "$DBA_STATE"
  install -d -m 0700 -o fpdbadmin -g fpdbadmin "$DBA_STATE/sessions" "$DBA_STATE/tmp" "$DBA_STATE/ratelimit"
  install -d -m 0755 -o root -g root "$DBA" "$DBA/www" "$DBA/lib" "$DBA/parked"
  # Sign-in counts per address (lib/ratelimit.php) are kept for a day.
  printf '# Written by the freePanel installer.\nd %s/ratelimit 0700 fpdbadmin fpdbadmin 1d\n' "$DBA_STATE" \
    >/etc/tmpfiles.d/freepanel-dbadmin.conf
  chmod 0644 /etc/tmpfiles.d/freepanel-dbadmin.conf

  # place PATH DIR: make DIR the live $DBA/PATH, parking the one it replaces
  # beside it (one filesystem, so the renames cannot fail with EXDEV).
  place() {
    if [ -e "$DBA/$1" ]; then
      mv "$DBA/$1" "$DBA/parked/${1//\//-}.parked-$(date -u +%Y%m%dT%H%M%SZ)"
    fi
    mv "$2" "$DBA/$1"
  }
  DBA_TMP="$(mktemp -d "$DBA/.new-XXXXXX")"
  if [ "$MYSQL" -eq 1 ] && [ "$(cat "$DBA/www/mysql/.freepanel-version" 2>/dev/null)" != "$PMA_VERSION" ]; then
    fetch "$PMA_URL" "$PMA_SHA256" "$DBA_TMP/pma.tar.xz"
    mkdir "$DBA_TMP/mysql"
    tar -C "$DBA_TMP/mysql" --strip-components=1 --no-same-owner -xJf "$DBA_TMP/pma.tar.xz"
    rm -f "$DBA_TMP/pma.tar.xz"
    # The setup pages and the examples are never served.
    rm -rf "$DBA_TMP/mysql/setup" "$DBA_TMP/mysql/examples"
    printf "<?php\nrequire '%s/phpmyadmin.inc.php';\n" "$DBA_STATE" >"$DBA_TMP/mysql/config.inc.php"
    echo "$PMA_VERSION" >"$DBA_TMP/mysql/.freepanel-version"
    place www/mysql "$DBA_TMP/mysql"
  fi
  # Adminer is one file that runs whatever it is asked to; it is kept out
  # of the web folder, so only our wrapper (www/pgsql/index.php) reaches it.
  if [ "$POSTGRES" -eq 1 ] && [ "$(cat "$DBA/lib/adminer/.freepanel-version" 2>/dev/null)" != "$ADMINER_VERSION" ]; then
    mkdir "$DBA_TMP/adminer"
    fetch "$ADMINER_URL" "$ADMINER_SHA256" "$DBA_TMP/adminer/adminer.php"
    if [ -f /etc/freepanel/mongodb.json ]; then
      fetch "$ADMINER_MONGO_URL" "$ADMINER_MONGO_SHA256" "$DBA_TMP/adminer/mongo.php"
    fi
    echo "$ADMINER_VERSION" >"$DBA_TMP/adminer/.freepanel-version"
    place lib/adminer "$DBA_TMP/adminer"
  fi
  # An earlier layout served Adminer from www/pgsql.
  if [ -e "$DBA/www/pgsql/adminer.php" ] || [ -e "$DBA/www/pgsql/.freepanel-version" ]; then
    place www/pgsql "$(mktemp -d "$DBA/.new-XXXXXX")"
  fi
  rmdir "$DBA_TMP" 2>/dev/null || true
  # Our own pages follow the release on every run.
  install -m 0644 -o root -g root "$SRC/installer/dbadmin/signon.php" "$SRC/installer/dbadmin/index.html" "$DBA/www/"
  install -m 0644 -o root -g root "$SRC/installer/dbadmin/ratelimit.php" "$DBA/lib/"
  if [ "$POSTGRES" -eq 1 ]; then
    install -d -m 0755 -o root -g root "$DBA/www/pgsql"
    install -m 0644 -o root -g root "$SRC/installer/dbadmin/pgsql-index.php" "$DBA/www/pgsql/index.php"
  fi
  chown -R root:root "$DBA/www" "$DBA/lib"
  find "$DBA/www" "$DBA/lib" -type d -exec chmod 0755 {} + -o -type f -exec chmod 0644 {} +

  if [ "$MYSQL" -eq 1 ]; then
    # The secret signs phpMyAdmin's cookies; it is made here once and never shown.
    secret="$(sed -n "s/^\$cfg\['blowfish_secret'\] = '\([0-9a-f]\{32\}\)';$/\1/p" "$DBA_STATE/phpmyadmin.inc.php" 2>/dev/null || true)"
    [ -n "$secret" ] || secret="$(openssl rand -hex 16)"
    # sed is given the secret in a script on its standard input, written by
    # the shell's own printf: on its command line any local user could read
    # it in /proc while it runs.
    (umask 0077; printf 's|@SECRET@|%s|\n' "$secret" | sed -f - -e "s|@SOCKET@|$MYSQL_SOCKET|" \
      "$SRC/installer/dbadmin/phpmyadmin.inc.php.in" >"$DBA_STATE/phpmyadmin.inc.php.new")
    unset secret
    chown root:fpdbadmin "$DBA_STATE/phpmyadmin.inc.php.new"
    chmod 0640 "$DBA_STATE/phpmyadmin.inc.php.new"
    mv -f "$DBA_STATE/phpmyadmin.inc.php.new" "$DBA_STATE/phpmyadmin.inc.php"
  fi

  cat >"$PHP_POOL_DIR/freepanel-dbadmin.conf" <<POOL
; Written by the freePanel installer; re-running it rewrites this file.
[freepanel-dbadmin]
user = fpdbadmin
group = fpdbadmin
listen = $DBA_SOCK
listen.owner = root
listen.group = $WEB_GROUP
listen.mode = 0660
pm = ondemand
pm.max_children = 10
pm.process_idle_timeout = 60s
php_admin_value[open_basedir] = $DBA/www/:$DBA/lib/:$DBA_STATE/
php_admin_value[session.save_path] = $DBA_STATE/sessions
php_admin_value[upload_tmp_dir] = $DBA_STATE/tmp
php_admin_value[sys_temp_dir] = $DBA_STATE/tmp
php_admin_value[disable_functions] = exec,passthru,shell_exec,system,proc_open,popen,pcntl_exec,mail
php_admin_flag[allow_url_fopen] = off
php_admin_flag[session.cookie_secure] = on
php_admin_flag[session.cookie_httponly] = on
php_admin_value[session.gc_maxlifetime] = 3600
php_admin_value[memory_limit] = 512M
php_admin_value[upload_max_filesize] = 256M
php_admin_value[post_max_size] = 256M
php_admin_value[max_execution_time] = 300
POOL
  chmod 0644 "$PHP_POOL_DIR/freepanel-dbadmin.conf"

  cat >"$WEB_SITES/01-freepanel-dbadmin.conf" <<VHOST
# Written by the freePanel installer; re-running it rewrites this file.
# The database admin tool, on its own port and origin.
Listen $DBADMIN_PORT https
<VirtualHost *:$DBADMIN_PORT>
    ServerName $HOSTNAME_FQDN
    SSLEngine on
    SSLCertificateFile $ETC/tls/panel.crt
    SSLCertificateKeyFile $ETC/tls/panel.key
    DocumentRoot $DBA/www
    # The web application firewall, once an admin installs and turns it on,
    # inspects what a server-level engine does not know to leave alone: SQL
    # typed into the database admin, mail written in webmail, large bodies.
    # The panel's own tools stay outside it, as an exempt site does.
    <IfModule security2_module>
        SecRuleEngine Off
    </IfModule>
    # signon.php takes sign-ins only from the panels' pages.
    SetEnv FREEPANEL_PANEL_ORIGINS "$(panel_origin "$PORT") $(panel_origin "$USER_PORT")"
    # Browsers keep cookies per host name, not per port, so one signed in to
    # a panel sends the panel's cookie here too. It is dropped before PHP
    # sees the request (fp_admin and fp_user, with the __Host- prefix or
    # without): nothing in phpMyAdmin or Adminer needs it, and a flaw in
    # either must not expose a panel session.
    RequestHeader edit* Cookie "(?<![^;\s])(?:__Host-)?fp_[a-z]+=[^;]*;?\s*" ""
    DirectoryIndex index.php index.html
    <Directory "$DBA/www">
        Options None
        AllowOverride None
        Require all granted
    </Directory>
    # phpMyAdmin's code and templates are read by PHP, never served.
    <DirectoryMatch "^$DBA/www/mysql/(libraries|templates|vendor|sql|locale|tmp)(/|$)">
        Require all denied
    </DirectoryMatch>
    <FilesMatch "^\.">
        Require all denied
    </FilesMatch>
    <FilesMatch "\.php$">
        SetHandler "proxy:unix:$DBA_SOCK|fcgi://freepanel-dbadmin/"
    </FilesMatch>
    Header always set X-Frame-Options "DENY"
    Header always set X-Content-Type-Options "nosniff"
    Header always set Referrer-Policy "no-referrer"
</VirtualHost>
VHOST
  chmod 0644 "$WEB_SITES/01-freepanel-dbadmin.conf"

  if command -v selinuxenabled >/dev/null && selinuxenabled; then
    keep_selinux_local
    semanage port -a -t http_port_t -p tcp "$DBADMIN_PORT" 2>/dev/null ||
      semanage port -m -t http_port_t -p tcp "$DBADMIN_PORT"
    while read -r type spec; do
      semanage fcontext -a -t "$type" "$spec" 2>/dev/null || semanage fcontext -m -t "$type" "$spec"
    done <<FCONTEXT
httpd_sys_content_t $DBA(/.*)?
httpd_sys_rw_content_t $DBA_STATE(/.*)?
cert_t $ETC/tls(/.*)?
FCONTEXT
    restorecon -R "$DBA" "$DBA_STATE" "$ETC/tls"
    if [ -f "$DBA_STATE/phpmyadmin.inc.php" ]; then restorecon "$DBA_STATE/phpmyadmin.inc.php"; fi
  fi

  printf '{"url":"https://%s:%s"}\n' "$HOSTNAME_FQDN" "$DBADMIN_PORT" >"$ETC/dbadmin.json"
  chown root:root "$ETC/dbadmin.json"
  chmod 0644 "$ETC/dbadmin.json"
  if command -v restorecon >/dev/null; then restorecon "$ETC/dbadmin.json" || true; fi

  "$PHP_FPM_BIN" -t >/dev/null 2>&1 || die "the database admin tool's PHP-FPM pool does not load; see: $PHP_FPM_BIN -t"
  apachectl configtest >/dev/null 2>&1 || die "Apache rejects the database admin tool's site; see: apachectl configtest"
  systemctl restart "$PHP_UNIT"
  systemctl reload "$WEB_UNIT"
fi

# ---- Webmail (--webmail) ---------------------------------------------------
# Roundcube, served by Apache on its own port (--webmail-port, 7446) so it
# is a separate origin from the panels and the database admin tool, and run
# by its own PHP-FPM pool as the freepanel-webmail system user. It reaches
# Dovecot and Postfix on loopback only. Customers open it from the panel,
# which makes the mailbox a sign-in token (modules/webmail) and posts it to
# signon.php, or sign in on its page with a mailbox's password. Its address
# book and settings are kept in SQLite. The download is checked against the
# checksum pinned here.
if [ "$WEBMAIL" -eq 1 ]; then
  say "Installing webmail (Roundcube $RC_VERSION)"
  WM=$PREFIX/webmail
  WM_STATE=/var/lib/freepanel-webmail
  WM_SOCK=$PHP_SOCK_DIR/freepanel-webmail.sock
  WM_PHP=$PHP_CLI
  if [ "$FAMILY" = el ]; then
    dnf -y -q install "$PHP_PKG-php-cli" "$PHP_PKG-php-mbstring" "$PHP_PKG-php-xml" "$PHP_PKG-php-intl" "$PHP_PKG-php-pdo"
  else
    # pdo and its SQLite driver (Roundcube's database) are built into Ubuntu's
    # PHP and phpX.Y-sqlite3. cURL is a package of its own here (Remi's
    # php-common has it): Roundcube makes its HTTP client on every page, and
    # with allow_url_fopen off that client needs cURL, or every page is a 500.
    pkg_install "php$PHP_TAG-cli" "php$PHP_TAG-mbstring" "php$PHP_TAG-xml" "php$PHP_TAG-intl" "php$PHP_TAG-sqlite3" "php$PHP_TAG-curl"
  fi
  # PGP (--pgp): GnuPG from the distribution (gnupg2 on AlmaLinux, Rocky and
  # RHEL; gnupg on Ubuntu). Roundcube's Enigma plugin runs it as the webmail
  # user, so PHP needs proc_open and GnuPG's program folder in open_basedir for this
  # pool and no other.
  WM_DISABLED="exec,passthru,shell_exec,system,proc_open,popen,pcntl_exec,mail"
  WM_BASEDIR="$WM/roundcube/:$WM/lib/:$WM_STATE/"
  if [ "$PGP" -eq 1 ]; then
    if [ "$FAMILY" = el ]; then
      pkg_install gnupg2
    else
      pkg_install gnupg
    fi
    GPG_BIN="$(command -v gpg || true)"
    if [ -z "$GPG_BIN" ] || [ ! -x "$GPG_BIN" ]; then die "GnuPG did not install (no gpg); webmail's PGP needs it"; fi
    GPG_BIN="$(readlink -f "$GPG_BIN")"
    case "$GPG_BIN" in /usr/bin/*) ;; *) die "gpg is at $GPG_BIN, outside /usr/bin" ;; esac
    WM_DISABLED="exec,passthru,shell_exec,system,popen,pcntl_exec,mail"
    WM_BASEDIR="$WM_BASEDIR:/usr/bin/"
    # With SELinux enforcing, what PGP needs from the policy is read here, before
    # anything is written, so a policy that cannot give it stops the run with
    # the pool, the Enigma settings and webmail.json as they were: the boolean
    # that has Apache's PHP run GnuPG in the policy's own domain, and the one the
    # policy applies it under. The installer turns on the first (below) and
    # never the second, which lets Apache run CGI programs for every site.
    if command -v selinuxenabled >/dev/null && selinuxenabled && [ "$(getenforce 2>/dev/null)" = Enforcing ]; then
      getsebool httpd_use_gpg >/dev/null 2>&1 ||
        die "--pgp needs the SELinux boolean httpd_use_gpg, which this policy does not have; update selinux-policy, or leave out --pgp"
      case "$(getsebool httpd_enable_cgi 2>/dev/null)" in
        *" off") die "--pgp needs the SELinux boolean httpd_enable_cgi, which is off here (the policy lets Apache's PHP run GnuPG in its own domain only where it is on). Turn it on with 'setsebool -P httpd_enable_cgi on' if you accept that Apache may run CGI programs for every site, or leave out --pgp" ;;
      esac
    fi
  fi

  if ! id freepanel-webmail >/dev/null 2>&1; then
    useradd --system --user-group --home-dir "$WM_STATE" --no-create-home --shell "$NOLOGIN" freepanel-webmail
  fi
  install -d -m 0750 -o root -g freepanel-webmail "$WM_STATE"
  install -d -m 0700 -o freepanel-webmail -g freepanel-webmail \
    "$WM_STATE/db" "$WM_STATE/logs" "$WM_STATE/tmp" "$WM_STATE/sessions" "$WM_STATE/ratelimit" "$WM_STATE/signouts"
  # The keys are kept when --pgp is left out later, never deleted.
  [ "$PGP" -eq 0 ] || install -d -m 0700 -o freepanel-webmail -g freepanel-webmail "$WM_STATE/enigma"
  install -d -m 0755 -o root -g root "$WM" "$WM/lib" "$WM/parked"
  # Sign-in counts per address (lib/ratelimit.php) are kept for a day, and
  # Roundcube's own temporary files (uploads being written) for two. A
  # sign-out's file (the plugin leaves it for the panel to end that sign-in)
  # is read within a minute; one the panel was not running to read goes
  # after a day.
  printf '# Written by the freePanel installer.\nd %s/ratelimit 0700 freepanel-webmail freepanel-webmail 1d\nd %s/tmp 0700 freepanel-webmail freepanel-webmail 2d\nd %s/signouts 0700 freepanel-webmail freepanel-webmail 1d\n' \
    "$WM_STATE" "$WM_STATE" "$WM_STATE" >/etc/tmpfiles.d/freepanel-webmail.conf
  chmod 0644 /etc/tmpfiles.d/freepanel-webmail.conf

  if [ "$(cat "$WM/roundcube/.freepanel-version" 2>/dev/null)" != "$RC_VERSION" ]; then
    WM_TMP="$(mktemp -d "$WM/.new-XXXXXX")"
    fetch "$RC_URL" "$RC_SHA256" "$WM_TMP/rc.tar.gz"
    mkdir "$WM_TMP/roundcube"
    tar -C "$WM_TMP/roundcube" --strip-components=1 --no-same-owner -xzf "$WM_TMP/rc.tar.gz"
    rm -f "$WM_TMP/rc.tar.gz"
    # The setup pages are never served, and logs and temporary files go to
    # $WM_STATE.
    rm -rf "$WM_TMP/roundcube/installer" "$WM_TMP/roundcube/public_html/installer.php" \
      "$WM_TMP/roundcube/logs" "$WM_TMP/roundcube/temp"
    echo "$RC_VERSION" >"$WM_TMP/roundcube/.freepanel-version"
    # The release it replaces is parked beside it (one filesystem, so the
    # renames cannot fail with EXDEV).
    if [ -e "$WM/roundcube" ]; then
      mv "$WM/roundcube" "$WM/parked/roundcube.parked-$(date -u +%Y%m%dT%H%M%SZ)"
    fi
    mv "$WM_TMP/roundcube" "$WM/roundcube"
    rmdir "$WM_TMP"
  fi
  # Our own files follow the release on every run.
  printf "<?php\nrequire '%s/config.inc.php';\n" "$WM_STATE" >"$WM/roundcube/config/config.inc.php"
  install -m 0644 -o root -g root "$SRC/installer/webmail/signon.php" "$WM/roundcube/public_html/"
  install -m 0644 -o root -g root "$SRC/installer/webmail/ratelimit.php" "$WM/lib/"
  install -d -m 0755 -o root -g root "$WM/roundcube/plugins/freepanel_signon"
  install -m 0644 -o root -g root "$SRC/installer/webmail/freepanel_signon/freepanel_signon.php" "$WM/roundcube/plugins/freepanel_signon/"
  chown -R root:root "$WM/roundcube" "$WM/lib"
  find "$WM/roundcube" "$WM/lib" -type d -exec chmod 0755 {} + -o -type f -exec chmod 0644 {} +

  # The key encrypts the mailbox password (or token) Roundcube keeps in its
  # session; it is made here once and never shown.
  deskey="$(sed -n "s/^\$config\['des_key'\] = '\([0-9a-f]\{32\}\)';$/\1/p" "$WM_STATE/config.inc.php" 2>/dev/null || true)"
  [ -n "$deskey" ] || deskey="$(openssl rand -hex 16)"
  # As phpMyAdmin's secret above: the key goes to sed on its standard input,
  # never on a command line.
  (umask 0077; printf 's|@DESKEY@|%s|\n' "$deskey" | sed -f - -e "s|@HOSTNAME@|$HOSTNAME_FQDN|" \
    "$SRC/installer/webmail/config.inc.php.in" >"$WM_STATE/config.inc.php.new")
  unset deskey
  if [ "$PGP" -eq 1 ]; then
    (umask 0077; sed -e "s|@GPG@|$GPG_BIN|" "$SRC/installer/webmail/config.pgp.inc.php.in" >>"$WM_STATE/config.inc.php.new")
  fi
  chown root:freepanel-webmail "$WM_STATE/config.inc.php.new"
  chmod 0640 "$WM_STATE/config.inc.php.new"
  mv -f "$WM_STATE/config.inc.php.new" "$WM_STATE/config.inc.php"

  cat >"$PHP_POOL_DIR/freepanel-webmail.conf" <<POOL
; Written by the freePanel installer; re-running it rewrites this file.
[freepanel-webmail]
user = freepanel-webmail
group = freepanel-webmail
listen = $WM_SOCK
listen.owner = root
listen.group = $WEB_GROUP
listen.mode = 0660
pm = ondemand
pm.max_children = 20
pm.process_idle_timeout = 60s
php_admin_value[open_basedir] = $WM_BASEDIR
php_admin_value[session.save_path] = $WM_STATE/sessions
php_admin_value[upload_tmp_dir] = $WM_STATE/tmp
php_admin_value[sys_temp_dir] = $WM_STATE/tmp
php_admin_value[disable_functions] = $WM_DISABLED
php_admin_flag[allow_url_fopen] = off
php_admin_flag[session.cookie_secure] = on
php_admin_flag[session.cookie_httponly] = on
php_admin_value[memory_limit] = 256M
php_admin_value[upload_max_filesize] = 25M
php_admin_value[post_max_size] = 30M
php_admin_value[max_execution_time] = 120
POOL
  chmod 0644 "$PHP_POOL_DIR/freepanel-webmail.conf"

  cat >"$WEB_SITES/01-freepanel-webmail.conf" <<VHOST
# Written by the freePanel installer; re-running it rewrites this file.
# Webmail, on its own port and origin. Only public_html is served; the rest
# of Roundcube is read by PHP.
Listen $WEBMAIL_PORT https
<VirtualHost *:$WEBMAIL_PORT>
    ServerName $HOSTNAME_FQDN
    SSLEngine on
    SSLCertificateFile $ETC/tls/panel.crt
    SSLCertificateKeyFile $ETC/tls/panel.key
    DocumentRoot $WM/roundcube/public_html
    # The web application firewall, once an admin installs and turns it on,
    # inspects what a server-level engine does not know to leave alone: SQL
    # typed into the database admin, mail written in webmail, large bodies.
    # The panel's own tools stay outside it, as an exempt site does.
    <IfModule security2_module>
        SecRuleEngine Off
    </IfModule>
    # signon.php takes sign-ins only from the panels' pages.
    SetEnv FREEPANEL_PANEL_ORIGINS "$(panel_origin "$PORT") $(panel_origin "$USER_PORT")"
    # Browsers keep cookies per host name, not per port, so one signed in to
    # a panel sends the panel's cookie here too. It is dropped before PHP
    # sees the request (fp_admin and fp_user, with the __Host- prefix or
    # without): nothing in webmail needs it, and a flaw in Roundcube must
    # not expose a panel session.
    RequestHeader edit* Cookie "(?<![^;\s])(?:__Host-)?fp_[a-z]+=[^;]*;?\s*" ""
    DirectoryIndex index.php
    <Directory "$WM/roundcube/public_html">
        Options None
        AllowOverride None
        Require all granted
    </Directory>
    <FilesMatch "^\.">
        Require all denied
    </FilesMatch>
    <FilesMatch "\.php$">
        SetHandler "proxy:unix:$WM_SOCK|fcgi://freepanel-webmail/"
    </FilesMatch>
    # Roundcube sets its own frame and content policies; these are the rest.
    Header always set X-Content-Type-Options "nosniff"
    Header always set Referrer-Policy "no-referrer"
    Header always set X-Robots-Tag "noindex, nofollow"
    # Calendars and contacts (--dav) pass /dav/ to Radicale from here.
    IncludeOptional $WEB_CONF/freepanel-dav.inc
</VirtualHost>
VHOST
  chmod 0644 "$WEB_SITES/01-freepanel-webmail.conf"

  # Roundcube runs in Apache's PHP-FPM type and connects to IMAP and
  # submission on loopback. The module allows those connections for all of
  # Apache's PHP; it matters only where httpd_can_network_connect is off
  # (installer/selinux/freepanel-webmail.cil).
  if command -v semodule >/dev/null && [ -f /etc/selinux/config ]; then
    if ! semodule -i "$SRC/installer/selinux/freepanel-webmail.cil"; then
      if command -v selinuxenabled >/dev/null && selinuxenabled; then die "could not load webmail's SELinux policy"; fi
      echo "  Warning: could not load webmail's SELinux policy (SELinux is off); re-run the installer to try again." >&2
    fi
  fi
  if command -v selinuxenabled >/dev/null && selinuxenabled; then
    keep_selinux_local
    semanage port -a -t http_port_t -p tcp "$WEBMAIL_PORT" 2>/dev/null ||
      semanage port -m -t http_port_t -p tcp "$WEBMAIL_PORT"
    while read -r type spec; do
      semanage fcontext -a -t "$type" "$spec" 2>/dev/null || semanage fcontext -m -t "$type" "$spec"
    done <<FCONTEXT
httpd_sys_content_t $WM(/.*)?
httpd_sys_rw_content_t $WM_STATE(/.*)?
cert_t $ETC/tls(/.*)?
FCONTEXT
    restorecon -R "$WM" "$WM_STATE" "$ETC/tls"
  fi

  # PGP (--pgp): this boolean has Apache's PHP run GnuPG in the policy's own
  # domain for it. It does not keep the pool to GnuPG: Apache's PHP may run
  # other programs anyway, so what a flaw in Roundcube could start is limited
  # by the webmail user's own rights. Where the policy has no such boolean and
  # SELinux is enforcing, the run stopped above, before anything was written.
  # A later run without --pgp leaves the boolean as it is (it applies to every
  # Apache PHP pool; 'setsebool -P httpd_use_gpg off' turns it off).
  if [ "$PGP" -eq 1 ] && command -v selinuxenabled >/dev/null && selinuxenabled; then
    if getsebool httpd_use_gpg >/dev/null 2>&1; then
      keep_sebools httpd_use_gpg
      setsebool -P httpd_use_gpg on
    fi
  fi
  # GnuPG 2 needs its agent for every secret-key step, and the boolean's
  # domain may not start it (installer/selinux/freepanel-pgp.cil).
  if [ "$PGP" -eq 1 ] && command -v semodule >/dev/null && [ -f /etc/selinux/config ]; then
    if ! semodule -i "$SRC/installer/selinux/freepanel-pgp.cil"; then
      if command -v selinuxenabled >/dev/null && selinuxenabled; then die "could not load webmail's PGP SELinux policy"; fi
      echo "  Warning: could not load webmail's PGP SELinux policy (SELinux is off); re-run the installer to try again." >&2
    fi
  fi

  # The database is made on first use; a new release updates it here.
  if [ -f "$WM_STATE/db/roundcube.db" ]; then
    runuser -u freepanel-webmail -- "$WM_PHP" "$WM/roundcube/bin/updatedb.sh" \
      --package=roundcube --dir="$WM/roundcube/SQL" >/dev/null || die "could not update webmail's database"
  fi

  if [ "$PGP" -eq 1 ]; then
    printf '{"url":"https://%s:%s","pgp":true}\n' "$HOSTNAME_FQDN" "$WEBMAIL_PORT" >"$ETC/webmail.json"
  else
    printf '{"url":"https://%s:%s"}\n' "$HOSTNAME_FQDN" "$WEBMAIL_PORT" >"$ETC/webmail.json"
  fi
  chown root:root "$ETC/webmail.json"
  chmod 0644 "$ETC/webmail.json"
  if command -v restorecon >/dev/null; then restorecon "$ETC/webmail.json" || true; fi

  "$PHP_FPM_BIN" -t >/dev/null 2>&1 || die "webmail's PHP-FPM pool does not load; see: $PHP_FPM_BIN -t"
  apachectl configtest >/dev/null 2>&1 || die "Apache rejects webmail's site; see: apachectl configtest"
  systemctl restart "$PHP_UNIT"
  systemctl reload "$WEB_UNIT"
fi

# ---- Calendars and contacts (--dav) ----------------------------------------
# Radicale, from freePanel's own package (packaging/radicale, signed and
# served from the package repository the way packaging/repo describes: EPEL 9
# has no Radicale, and the owner chose a package of ours over a Python
# environment made on each server, issue 326), as the radicale user the package makes, on
# 127.0.0.1:5232 only, by its own unit (freepanel-dav.service); the
# package's own unit stays off. Apache passes webmail's /dav/ to it, and
# /.well-known/caldav and /.well-known/carddav there lead to /dav/, so a
# device given webmail's host finds the rest. A mailbox signs in with its
# address and password: the root agent writes Radicale's sign-ins from the
# mail module's bcrypt hashes and the rights from the mailboxes' shares
# (modules/dav). The collections are under /var/lib/freepanel-dav.
if [ "$DAV" -eq 1 ]; then
  say "Installing calendars and contacts (Radicale)"
  DAV_DIR=/var/lib/freepanel-dav
  DAV_ETC=/etc/freepanel-dav
  # Radicale checks bcrypt hashes with Python's bcrypt module, which the
  # package requires as python3-bcrypt (from EPEL on EL: AlmaLinux's own
  # repositories have none; from Ubuntu's main). The package is freePanel's,
  # from its repository (freepanel.repo or freepanel.sources, written by
  # packaging/repo/enable-repo.sh once the repository is switched on);
  # FP_DAV_RPM (EL) or FP_DAV_DEB (Ubuntu) names a package file instead, for
  # a machine that cannot reach the repository and for the test harness,
  # which builds the package from this checkout.
  if [ "$FAMILY" = el ]; then
    install_epel_rhel
    dnf -y -q install epel-release
    if [ -n "${FP_DAV_RPM:-}" ]; then
      [ -f "$FP_DAV_RPM" ] || die "FP_DAV_RPM names no file: $FP_DAV_RPM"
      dnf -y -q install "$FP_DAV_RPM"
    elif [ -f /etc/yum.repos.d/freepanel.repo ]; then
      dnf -y -q install radicale
    else
      die "--dav needs the radicale package from freePanel's package repository, which this server does not use yet (packaging/repo); FP_DAV_RPM=/path/to/radicale.rpm installs a package file instead"
    fi
  elif [ -n "${FP_DAV_DEB:-}" ]; then
    [ -f "$FP_DAV_DEB" ] || die "FP_DAV_DEB names no file: $FP_DAV_DEB"
    case "$FP_DAV_DEB" in /*) ;; *) FP_DAV_DEB="./$FP_DAV_DEB" ;; esac
    pkg_install_held radicale -- "$FP_DAV_DEB"
  else
    # apt takes the highest version it is offered: freePanel's 3.5 package
    # once freepanel.sources is there (it sorts above Ubuntu's), Ubuntu's own
    # otherwise. Ubuntu 24.04's is 3.1.8, too old (packaging/radicale), so
    # the version apt would install is looked at before anything is
    # installed: a server is never left with a Radicale freePanel cannot use.
    DAV_CAND="$(apt-cache policy radicale 2>/dev/null | sed -n 's/^[[:space:]]*Candidate:[[:space:]]*//p')"
    if [ -z "$DAV_CAND" ] || [ "$DAV_CAND" = "(none)" ] || ! dpkg --compare-versions "$DAV_CAND" ge 3.5~; then
      if [ -f /etc/apt/sources.list.d/freepanel.sources ]; then
        die "--dav needs Radicale 3.5 or later, and apt offers radicale ${DAV_CAND:-none}: freePanel's package repository is set up but carries no radicale package yet (packaging/radicale); FP_DAV_DEB=/path/to/radicale.deb installs a package file instead"
      fi
      die "--dav needs Radicale 3.5 or later, and apt offers radicale ${DAV_CAND:-none} (Ubuntu 24.04's own is 3.1.8): freePanel's package repository, which carries it, is not set up on this server (packaging/repo); FP_DAV_DEB=/path/to/radicale.deb installs a package file instead"
    fi
    pkg_install_held radicale -- radicale
  fi
  RADICALE=/usr/bin/radicale
  [ -x "$RADICALE" ] || die "Radicale did not install (no $RADICALE)"
  # 3.5 or later: the rights' D and O (removing or replacing a whole
  # collection) and the sign-ins read once and again only when they change.
  DAV_VER="$("$RADICALE" --version 2>/dev/null | tr -d '[:space:]' || true)"
  if ! [[ "$DAV_VER" =~ ^3\.([0-9]+)(\.|$) ]] || [ "${BASH_REMATCH[1]}" -lt 5 ]; then
    die "--dav needs Radicale 3.5 or later; the installed package is ${DAV_VER:-none}"
  fi
  DAV_PY="$(sed -n '1s|^#![[:space:]]*\(/[^[:space:]]*\).*|\1|p' "$RADICALE")"
  if [ -z "$DAV_PY" ] || ! "$DAV_PY" -c 'import bcrypt' 2>/dev/null; then
    die "Radicale's Python has no bcrypt module (python3-bcrypt)"
  fi
  if ! getent passwd radicale >/dev/null || ! getent group radicale >/dev/null; then
    die "Radicale's package made no radicale user and group"
  fi
  for db in passwd group; do
    id=$(getent "$db" radicale | cut -d: -f3)
    [ "$id" -le 999 ] || die "the $db entry radicale has id $id, which is not a system id: a hosting account may hold the name"
  done
  keep_units radicale freepanel-dav
  # The package's own unit would listen with its own settings.
  if systemctl is-enabled --quiet radicale 2>/dev/null || systemctl is-active --quiet radicale 2>/dev/null; then
    systemctl disable --now --quiet radicale
  fi
  install -d -m 0750 -o root -g radicale "$DAV_DIR" "$DAV_ETC"
  install -d -m 0700 -o radicale -g radicale "$DAV_DIR/collections"
  install -d -m 0700 -o root -g root "$DAV_DIR/parked"
  [ -e "$DAV_DIR/collections/.Radicale.lock" ] || install -m 0600 -o radicale -g radicale /dev/null "$DAV_DIR/collections/.Radicale.lock"
  # The agent rewrites both; until it has, no one signs in.
  for f in users rights; do
    if [ ! -f "$DAV_ETC/$f" ]; then
      printf '# Written by freePanel from the mail accounts; edits here are replaced.\n' >"$DAV_ETC/$f"
    fi
    chown root:radicale "$DAV_ETC/$f"
    chmod 0640 "$DAV_ETC/$f"
  done
  cat >"$DAV_ETC/config.new" <<CONF
# Written by the freePanel installer; re-running it rewrites this file.
# Read by freepanel-dav.service. Everything here overrides Radicale's own
# defaults; /etc/radicale/config is not read.
[server]
hosts = 127.0.0.1:5232
max_connections = 20
max_content_length = 10000000
timeout = 30

[encoding]
request = utf-8
stock = utf-8

[auth]
# Each line is a mailbox's address and its bcrypt hash, written by the root
# agent. Read again when it changes.
type = htpasswd
htpasswd_filename = $DAV_ETC/users
htpasswd_encryption = bcrypt
htpasswd_cache = True
lc_username = True
delay = 1
realm = Calendars and contacts

[rights]
type = from_file
file = $DAV_ETC/rights
permit_delete_collection = False
permit_overwrite_collection = False

[storage]
type = multifilesystem
filesystem_folder = $DAV_DIR/collections

[web]
type = none

[logging]
level = warning
mask_passwords = True
CONF
  chown root:radicale "$DAV_ETC/config.new"
  chmod 0640 "$DAV_ETC/config.new"
  mv -f "$DAV_ETC/config.new" "$DAV_ETC/config"
  install -m 0644 "$SRC/installer/systemd/freepanel-dav.service" /etc/systemd/system/

  # Inside webmail's site (its vhost includes this file). The client's own
  # X-Remote-User and X-Script-Name are never passed on: Radicale checks the
  # password itself and is told where it is served.
  cat >"$WEB_CONF/freepanel-dav.inc" <<VHOST
# Written by the freePanel installer (--dav); re-running it rewrites this file.
# Included by webmail's site: calendars and contacts at /dav/.
RedirectMatch 301 "^/\.well-known/(caldav|carddav)/?$" "/dav/"
# Login protection (--protect) reads this file: one line for each request to
# /dav/ that came with an Authorization header, with its time, the address the
# connection came from and the answer, and nothing the client wrote. How the
# header is spelled is not looked at: Radicale reads anything that begins with
# Basic as a login, with the space after it or without, so a condition on
# "Basic " would leave out a login it refuses and no one would count it. A
# refused login is answered 401, which a device's first request without a
# header is too, and that one is not logged. The address is read here and not
# from Radicale's own log, which names whatever X-Forwarded-For says, and
# anything on this server can send that to 127.0.0.1:5232. The file is root's
# and the web server's logrotate takes it with the other logs.
LogFormat "%{%Y-%m-%d %H:%M:%S}t dav-sign-in %a %>s" freepanel_dav_signin
CustomLog "$WEB_LOG/freepanel-dav-auth.log" freepanel_dav_signin env=fp_dav_signin
# A site with a CustomLog of its own does not write the server's: this keeps
# webmail's requests in the access log they went to before (the server's own).
CustomLog "$WEB_ACCESS_LOG" $WEB_ACCESS_FORMAT
<Location "/dav/">
    SetEnvIf Authorization "." fp_dav_signin
    ProxyPass "http://127.0.0.1:5232/" retry=0 timeout=120
    ProxyPassReverse "http://127.0.0.1:5232/"
    RequestHeader unset X-Remote-User
    RequestHeader set X-Script-Name "/dav"
    LimitRequestBody 10485760
    Header always set Content-Security-Policy "default-src 'none'; sandbox"
    Header always set X-Content-Type-Options "nosniff"
    Require all granted
</Location>
VHOST
  chmod 0644 "$WEB_CONF/freepanel-dav.inc"

  # freePanel's folders take the labels of the package's own, so a policy that
  # confines Radicale lets it read its settings and write its collections.
  if command -v selinuxenabled >/dev/null && selinuxenabled; then
    keep_selinux_local
    semanage fcontext -a -e /var/lib/radicale "$DAV_DIR" 2>/dev/null || semanage fcontext -m -e /var/lib/radicale "$DAV_DIR"
    semanage fcontext -a -e /etc/radicale "$DAV_ETC" 2>/dev/null || semanage fcontext -m -e /etc/radicale "$DAV_ETC"
    restorecon -R "$DAV_DIR" "$DAV_ETC" "$WEB_CONF/freepanel-dav.inc"
  fi

  systemctl daemon-reload
  systemctl enable --quiet freepanel-dav
  systemctl restart freepanel-dav
  for _ in $(seq 1 20); do
    systemctl is-active --quiet freepanel-dav && break
    sleep 1
  done
  systemctl is-active --quiet freepanel-dav || die "Radicale did not start; see: journalctl -u freepanel-dav"

  printf '{"url":"https://%s:%s/dav/"}\n' "$HOSTNAME_FQDN" "$WEBMAIL_PORT" >"$ETC/dav.json.new"
  chown root:root "$ETC/dav.json.new"
  chmod 0644 "$ETC/dav.json.new"
  mv -f "$ETC/dav.json.new" "$ETC/dav.json"
  if command -v restorecon >/dev/null; then restorecon "$ETC/dav.json" || true; fi

  apachectl configtest >/dev/null 2>&1 || die "Apache rejects calendars and contacts in webmail's site; see: apachectl configtest"
  systemctl reload "$WEB_UNIT"
fi

# ---- Firewall --------------------------------------------------------------
# Nothing is opened unless --open-firewall is given, for any option: a server
# is not made reachable by installing a service on it. The lists are the ports
# --open-firewall opens; without it they are what the closing lines name.
FW_SERVICES=("$PORT/tcp" "$USER_PORT/tcp")
UFW_PORTS=("$PORT/tcp" "$USER_PORT/tcp")
# The ports of the options that were asked for, without the panel's and the
# database admin tool's, which the closing lines name on their own.
SERVICE_PORTS=""
if [ "$WEB" -eq 1 ]; then
  FW_SERVICES+=(http https)
  UFW_PORTS+=(80/tcp 443/tcp)
  SERVICE_PORTS="$SERVICE_PORTS 80/tcp 443/tcp"
fi
if [ "$MAIL" -eq 1 ]; then
  FW_SERVICES+=(smtp smtp-submission imap imaps)
  UFW_PORTS+=(25/tcp 587/tcp 143/tcp 993/tcp)
  SERVICE_PORTS="$SERVICE_PORTS 25/tcp 587/tcp 143/tcp 993/tcp"
fi
if [ "$DNS" -eq 1 ]; then
  FW_SERVICES+=(dns)
  UFW_PORTS+=(53)
  SERVICE_PORTS="$SERVICE_PORTS 53/tcp 53/udp"
fi
if [ "$FTP" -eq 1 ]; then
  FW_SERVICES+=(21/tcp "$FTP_PASV_MIN-$FTP_PASV_MAX/tcp")
  UFW_PORTS+=(21/tcp "$FTP_PASV_MIN:$FTP_PASV_MAX/tcp")
  SERVICE_PORTS="$SERVICE_PORTS 21/tcp $FTP_PASV_MIN-$FTP_PASV_MAX/tcp"
fi
# The database admin tool is reached from the panels' pages, so its port
# opens with theirs, never on its own (41-2).
if [ "$DBADMIN" -eq 1 ]; then
  FW_SERVICES+=("$DBADMIN_PORT/tcp")
  UFW_PORTS+=("$DBADMIN_PORT/tcp")
fi
if [ "$WEBMAIL" -eq 1 ]; then
  FW_SERVICES+=("$WEBMAIL_PORT/tcp")
  UFW_PORTS+=("$WEBMAIL_PORT/tcp")
  SERVICE_PORTS="$SERVICE_PORTS $WEBMAIL_PORT/tcp"
fi
SERVICE_PORTS="${SERVICE_PORTS# }"
# --protect on AlmaLinux, Rocky and RHEL bans through firewalld. Most cloud
# images ship with it off; then it is installed and turned on here, never
# skipped. Before it starts, its saved configuration gets sshd's ports and the
# ports above (firewall-offline-cmd writes it with the daemon stopped), so the
# first rules it loads keep SSH, the panels and every chosen service
# reachable, and it lets established connections on, so this SSH session goes
# on. A server that had no firewall had those ports open, so they are opened
# as with --open-firewall.
if [ "$PROTECT" -eq 1 ] && [ "$FAMILY" = el ] && ! { command -v firewall-cmd >/dev/null && firewall-cmd --state >/dev/null 2>&1; }; then
  say "Turning on the firewall (firewalld): it was off, and login protection needs it"
  keep_units firewalld
  dnf -y -q install firewalld
  command -v firewall-offline-cmd >/dev/null || die "firewall-offline-cmd is missing; the firewall was not turned on"
  keep_state_once firewalld-ports firewall-offline-cmd --list-ports
  keep_state_once firewalld-services firewall-offline-cmd --list-services
  FW_SSH_PORTS="$(sshd -T 2>/dev/null | awk '$1 == "port" { print $2 }' | sort -un || true)"
  [ -n "$FW_SSH_PORTS" ] || FW_SSH_PORTS=22
  for p in $FW_SSH_PORTS; do
    [[ "$p" =~ ^[0-9]+$ ]] || die "could not read sshd's ports ($FW_SSH_PORTS); the firewall was not turned on"
    firewall-offline-cmd --add-port="$p/tcp" >/dev/null || die "could not allow SSH port $p in firewalld's configuration; the firewall was not turned on"
  done
  for s in "${FW_SERVICES[@]}"; do
    if [[ "$s" == */* ]]; then
      firewall-offline-cmd --add-port="$s" >/dev/null || die "could not open $s in firewalld's configuration; the firewall was not turned on"
    else
      firewall-offline-cmd --add-service="$s" >/dev/null || die "could not open $s in firewalld's configuration; the firewall was not turned on"
    fi
  done
  systemctl enable --now firewalld || die "firewalld did not start; see: journalctl -u firewalld"
  for _ in $(seq 1 20); do
    firewall-cmd --state >/dev/null 2>&1 && break
    sleep 0.5
  done
  firewall-cmd --state >/dev/null 2>&1 || die "firewalld did not start; see: journalctl -u firewalld"
  for p in $FW_SSH_PORTS; do
    firewall-cmd --query-port="$p/tcp" >/dev/null || die "firewalld runs without SSH's port $p; allow it now (firewall-cmd --permanent --add-port=PORT/tcp, then --reload)"
  done
  OPEN_FIREWALL=1
fi
# --open-firewall and --no-firewall contradict each other (checked at the top),
# so the second needs no test here.
if [ "$OPEN_FIREWALL" -eq 1 ]; then
  if systemctl is-active --quiet firewalld; then
    say "Opening in firewalld: ${FW_SERVICES[*]}"
    keep_state_once firewalld-ports firewall-cmd --permanent --list-ports
    keep_state_once firewalld-services firewall-cmd --permanent --list-services
    for s in "${FW_SERVICES[@]}"; do
      if [[ "$s" == */* ]]; then
        firewall-cmd --quiet --permanent --add-port="$s"
      else
        firewall-cmd --quiet --permanent --add-service="$s"
      fi
    done
    firewall-cmd --quiet --reload
  elif command -v ufw >/dev/null && ufw status | grep -q "Status: active"; then
    say "Opening in ufw: ${UFW_PORTS[*]}"
    keep_state_once ufw ufw status verbose
    for p in "${UFW_PORTS[@]}"; do ufw allow "$p" >/dev/null; done
  else
    say "No active firewalld or ufw found; nothing opened"
  fi
fi

# ---- Login protection (--protect) ------------------------------------------
# fail2ban blocks addresses that keep failing to sign in to SSH, the panels,
# mail and FTP, and the root agent's security module keeps the allow and deny
# lists (modules/security/README.md). The installer installs fail2ban and
# writes $ETC/security.json, whose presence turns the module on; the agent
# writes everything of fail2ban's own and starts it. The jail and filter
# files are new files of ours, so there is nothing of a server's own to keep
# but the state of fail2ban's unit and of firewalld's ipsets and drop zone.

# ssh_client_ip prints the address of the SSH client this script runs under,
# if it runs under one: from SSH_CONNECTION if sudo kept it, else from the
# connection of the sshd above this script in the process tree.
ssh_client_ip() {
  local pid=$$ ppid comm peer
  if [ -n "${SSH_CONNECTION:-}" ]; then
    printf '%s\n' "${SSH_CONNECTION%% *}"
    return 0
  fi
  while [ "$pid" -gt 1 ]; do
    read -r ppid comm < <(ps -o ppid=,comm= -p "$pid" 2>/dev/null) || return 0
    if [ "$comm" = sshd ] || [ "$comm" = sshd-session ]; then
      # ss prints the peer as ADDR:PORT, an IPv6 address in brackets. awk
      # reads all of ss's output, so ss is never cut off.
      peer="$(ss -Htnp 2>/dev/null | awk -v p="pid=$pid," 'index($0, p) && !done { print $5; done = 1 }' || true)"
      peer="${peer%:*}"
      peer="${peer#[}"
      peer="${peer%]}"
      [ -z "$peer" ] || printf '%s\n' "$peer"
      return 0
    fi
    pid="$ppid"
  done
}

# uniq_csv LIST prints a comma separated list without empty entries or
# repeats (compared in lower case, so 2001:DB8::1 and 2001:db8::1 are one),
# in the order given: the address you are signed in from is often also the
# one given to --protect-allow.
uniq_csv() {
  local a out="" list
  IFS=, read -ra list <<<"$1"
  for a in "${list[@]}"; do
    [ -n "$a" ] || continue
    case ",${out,,}," in *",${a,,},"*) continue ;; esac
    out="${out:+$out,}$a"
  done
  printf '%s\n' "$out"
}

# security_json SSH_PORTS PANEL_PORT USER_PORT SEEDS [DAV_PORT] prints
# $ETC/security.json: sshd's ports (comma separated), the panels' ports, the
# port calendars and contacts are served on (given with --dav) and the
# addresses to put on the allow list (comma separated; one that is not
# an address or a range is left out). Only addresses go in, so nothing needs
# quoting.
security_json() {
  local ssh="$1" port="$2" uport="$3" seeds="$4" dav="${5:-}" a out="" list davjson=""
  IFS=, read -ra list <<<"$seeds"
  for a in "${list[@]}"; do
    [[ "$a" =~ ^[0-9A-Fa-f.:/]+$ ]] || continue
    out="${out:+$out,}\"$a\""
  done
  [ -z "$dav" ] || davjson="\"dav_ports\":[$dav],"
  printf '{"ssh_ports":[%s],"panel_ports":[%s,%s],%s"seed_allow":[%s]}\n' "$ssh" "$port" "$uport" "$davjson" "$out"
}

PROTECT_SEEDS=""
# Ubuntu's own sshd jail, turned off where --protect installs fail2ban.
F2B_STOCK_OFF=/etc/fail2ban/jail.d/zz-freepanel-stock-sshd.conf
if [ "$PROTECT" -eq 1 ]; then
  say "Setting up login protection (fail2ban)"
  if [ "$FAMILY" = el ]; then
    # The firewall section above turned firewalld on where it was off.
    firewall-cmd --state >/dev/null 2>&1 || die "login protection needs firewalld running, and it is not; see: journalctl -u firewalld"
    keep_units fail2ban
    keep_state_once firewalld-ipsets firewall-cmd --permanent --get-ipsets
    keep_state_once firewalld-drop-sources firewall-cmd --permanent --zone=drop --list-sources
    keep_original /etc/fail2ban/jail.d/zz-freepanel.conf /etc/fail2ban/fail2ban.d/zz-freepanel.conf /etc/fail2ban/filter.d/freepanel-panel.conf /etc/fail2ban/filter.d/freepanel-sshd.conf /etc/fail2ban/filter.d/freepanel-ftp.conf /etc/fail2ban/filter.d/freepanel-dav.conf /etc/fail2ban/filter.d/freepanel-dovecot.conf
    install_epel_rhel
    dnf -y -q install epel-release
    dnf -y -q install fail2ban fail2ban-firewalld python3-systemd
  else
    # Ubuntu: the deny list is a table of the agent's own in nftables (inet
    # freepanel), and fail2ban bans from a table of its own (its nftables
    # action). Neither drops anything but the addresses they name, so no
    # firewall needs to be running, and ufw, when it is, and the server's
    # own nftables rules stay as they are. The stock nftables.service is
    # left as it is, and not kept: its configuration, and its stop, flush
    # every table, so neither enabling it nor putting it back (a restart)
    # is safe for those.
    keep_units fail2ban
    keep_state_once nftables-ruleset nft list ruleset
    keep_original /etc/fail2ban/jail.d/zz-freepanel.conf /etc/fail2ban/fail2ban.d/zz-freepanel.conf /etc/fail2ban/filter.d/freepanel-panel.conf /etc/fail2ban/filter.d/freepanel-sshd.conf /etc/fail2ban/filter.d/freepanel-ftp.conf /etc/fail2ban/filter.d/freepanel-dav.conf /etc/fail2ban/filter.d/freepanel-dovecot.conf "$F2B_STOCK_OFF"
    F2B_NEW=0
    dpkg-query -W -f='${Status}' fail2ban 2>/dev/null | grep -q 'install ok installed' || F2B_NEW=1
    pkg_install nftables fail2ban python3-systemd
    # Ubuntu's package turns on its own sshd jail (jail.d/defaults-debian.conf),
    # with fail2ban's stock sshd filter, which a login name can steer to
    # another address (finding 229-2), and without the allow list, so it
    # could block the admin. Where this run installed fail2ban, that jail
    # is turned off; freepanel-ssh covers SSH. One a server had before is
    # its own and stays.
    if [ "$F2B_NEW" -eq 1 ]; then
      printf '# Written by the freePanel installer: Ubuntu'"'"'s own sshd jail is off; freepanel-ssh covers SSH.\n[sshd]\nenabled = false\n' >"$F2B_STOCK_OFF.new"
      chmod 0644 "$F2B_STOCK_OFF.new"
      mv -f "$F2B_STOCK_OFF.new" "$F2B_STOCK_OFF"
    fi
    # The deny list survives a reboot: this loads the agent's last ruleset
    # at boot, before the network is up.
    install -m 0644 "$SRC/installer/systemd/freepanel-firewall.service" /etc/systemd/system/
    systemctl daemon-reload
    systemctl enable --quiet freepanel-firewall
  fi
  # The agent starts it once its jails are written.
  systemctl enable --quiet fail2ban

  SSH_PORTS="$(sshd -T 2>/dev/null | awk '$1 == "port" { print $2 }' | sort -un | paste -sd, - || true)"
  [ -n "$SSH_PORTS" ] || SSH_PORTS=22
  [[ "$SSH_PORTS" =~ ^[0-9]+(,[0-9]+)*$ ]] || die "could not read sshd's ports ($SSH_PORTS)"

  # The allow list starts with the address you are signed in from and the
  # addresses given, so nothing blocks the person running the installer.
  # The agent adds each once; one an admin takes off later stays off.
  PROTECT_SEEDS="$(ssh_client_ip || true)"
  [ -z "$PROTECT_ALLOW" ] || PROTECT_SEEDS="${PROTECT_SEEDS:+$PROTECT_SEEDS,}$PROTECT_ALLOW"
  PROTECT_SEEDS="$(uniq_csv "$PROTECT_SEEDS")"
  say "Writing $ETC/security.json"
  DAV_JAIL_PORT=""
  if [ "$DAV" -eq 1 ]; then DAV_JAIL_PORT="$WEBMAIL_PORT"; fi
  security_json "$SSH_PORTS" "$PORT" "$USER_PORT" "$PROTECT_SEEDS" "$DAV_JAIL_PORT" >"$ETC/security.json.new"
  chown root:root "$ETC/security.json.new"
  chmod 0644 "$ETC/security.json.new"
  mv -f "$ETC/security.json.new" "$ETC/security.json"
  if command -v restorecon >/dev/null; then restorecon "$ETC/security.json" || true; fi
fi

# ---- App hosting (--apps) --------------------------------------------------
# The runtimes are the distribution's own packages, from its own repositories
# (modules/web/apphost): the panel runs an app as its account with the program
# at /usr/bin/node, /usr/bin/python3 or /usr/bin/ruby and no other. Apache
# passes a site to the app over a unix socket of the app's account, in
# /run/freepanel-apps/<account>/<app>/. The app makes the socket in a folder that is
# root's, with the account's group, mode 0770, while it starts (the account cannot
# change the folder and the web server is not in its group); the unit then has
# freepanel-privd seal the folder: closed to everyone, looked at, and only then
# opened to the web server's group (mode 0750) with nothing in it but the account's
# socket, so a link the account put there to another account's socket can never be
# followed. A
# loopback port belongs to every account on the server, so another account could
# answer in the place of an app that is stopped or starting. A port is a fallback
# the admin allows in the panel (modules/web/apphost). With SELinux enforcing, Apache needs the
# folder's file type and the right to connect to the app's process, and to no
# other service (installer/selinux/freepanel-apps.cil: a process type and a file
# type of their own for the apps).
# $ETC/apps.json is what turns the feature on: the panel makes and starts no app
# without it, whatever runtimes the server has.
# Beside the system's Node.js the admin can install Node.js LTS lines from the
# panel (modules/web/nodejs): official release tarballs from nodejs.org, each
# taken only if its checksum is in the release's SHASUMS256 file and that file is
# signed by one of the releasers' keys pinned in freePanel (checked with gpgv),
# into /opt/freepanel-node/<release>, with /opt/freepanel-node/<line> the link an
# app's unit names. Nothing is fetched until the admin installs a line. gpg and
# gpgv are the distribution's own; the folder is made here, root's and 0755.
if [ "$APPS" -eq 1 ]; then
  say "Installing the app runtimes (Node.js, Python, Ruby) and the installers of customers' libraries"
  if [ "$FAMILY" = el ]; then
    dnf -y -q install nodejs python3 ruby gnupg2
  else
    # Ubuntu's nodejs has /usr/bin/node, and ruby /usr/bin/ruby (a link to
    # ruby3.2); gem is ruby-rubygems. cpanm came with the base packages.
    pkg_install nodejs python3 ruby ruby-rubygems gpg gpgv
  fi
  for b in /usr/bin/gpg /usr/bin/gpgv; do
    [ -x "$b" ] || die "$b is not there after installing its package; the Node.js versions of the panel are checked with it"
  done
  install -d -m 0755 -o root -g root /opt/freepanel-node
  for b in /usr/bin/node /usr/bin/python3 /usr/bin/ruby; do
    [ -x "$b" ] || die "$b is not there after installing its package"
  done
  # Customers' code libraries (modules/libraries): Ruby's gem command (rubygems,
  # which ruby only recommends) and cpanm for Perl modules into ~/perl5, both run
  # by the panel as the account, never as root. cpanm is AppStream's
  # (perl-App-cpanminus); where it can't be had, cpan (perl-CPAN) does the same
  # with the latest version only. Neither brings a compiler: a library that
  # builds C code needs one the admin installs and opens to accounts.
  if [ "$FAMILY" = el ]; then
    dnf -y -q install rubygems
    if ! dnf -y -q install perl-App-cpanminus; then
      echo "  Warning: perl-App-cpanminus could not be installed; installing perl-CPAN for customers' Perl modules instead." >&2
      dnf -y -q install perl-CPAN || echo "  Warning: perl-CPAN could not be installed either; customers can't add Perl modules until one is." >&2
    fi
  fi
  if command -v semodule >/dev/null && [ -f /etc/selinux/config ]; then
    if ! semodule -i "$SRC/installer/selinux/freepanel-apps.cil"; then
      if command -v selinuxenabled >/dev/null && selinuxenabled; then die "could not load app hosting's SELinux policy"; fi
      echo "  Warning: could not load app hosting's SELinux policy (SELinux is off); re-run the installer to try again." >&2
    fi
  fi
  if command -v selinuxenabled >/dev/null && selinuxenabled; then
    # The folder's type is the module's (a filecon in freepanel-apps.cil). An earlier
    # run of this installer gave it httpd_var_run_t with a local rule, which would
    # win over the module's, so it is taken away.
    keep_selinux_local
    if semanage fcontext -l -C 2>/dev/null | grep -q '^/run/freepanel-apps(/\.\*)?[[:space:]]'; then
      semanage fcontext -d '/run/freepanel-apps(/.*)?'
    fi
    if [ -e /run/freepanel-apps ]; then restorecon -R /run/freepanel-apps; fi
    # The Node.js lines' programs are bin_t (a filecon of the module), which an
    # app's process type may start from.
    restorecon -R /opt/freepanel-node
  fi
  if [ ! -f "$ETC/apps.json" ]; then
    say "Writing $ETC/apps.json"
    printf '{}\n' >"$ETC/apps.json"
    chown root:root "$ETC/apps.json"
    chmod 0644 "$ETC/apps.json"
  else
    echo "Keeping existing $ETC/apps.json"
  fi
  if command -v restorecon >/dev/null; then restorecon "$ETC/apps.json" || true; fi
fi

# ---- nginx (--nginx) -------------------------------------------------------
# Only the package, from the distribution's repositories, stopped and disabled.
# The panel's switch (docs/api.md, "Web server") is what puts nginx in front of
# Apache, and it does nothing until an admin uses it. A server that already had
# nginx installed keeps it exactly as it is, running or not: it may serve
# something else, and the installer does not decide that. The ports nginx will
# need (80, 443) are the web stack's already, and Apache's two loopback ports
# (8008, 8009) are in SELinux's http_port_t, so there is no port rule to add.
# On Ubuntu the package would start nginx as it installs, on ports 80 and 443,
# which are Apache's: a policy-rc.d that refuses every start, there only while
# apt runs, keeps it stopped (one the admin has is left as it is, and then the
# start may fail and is stopped after). The front runs nginx as a user of its
# own, nginx (webd.DefaultNginxFor), not the package's www-data, which is
# Apache's, and needs mod_remoteip to read the visitor's address from nginx.
nginx_installed() {
  if [ "$FAMILY" = el ]; then
    rpm -q nginx >/dev/null 2>&1
  else
    dpkg-query -W -f '${db:Status-Abbrev}' nginx 2>/dev/null | grep -q '^ii'
  fi
}
if [ "$NGINX" -eq 1 ]; then
  if nginx_installed; then
    echo "nginx is already installed here; leaving it as it is"
  else
    say "Installing nginx (stopped and disabled)"
    if [ "$FAMILY" = el ]; then
      dnf -y -q install nginx
    elif [ -e /usr/sbin/policy-rc.d ]; then
      pkg_install nginx || true
      nginx_installed || die "nginx did not install"
    else
      printf '#!/bin/sh\n# Written by the freePanel installer while it installs nginx; removed after.\nexit 101\n' >/usr/sbin/policy-rc.d
      chmod 0755 /usr/sbin/policy-rc.d
      rc=0
      pkg_install nginx || rc=$?
      rm -f /usr/sbin/policy-rc.d
      [ "$rc" -eq 0 ] || die "nginx did not install"
    fi
    systemctl disable --quiet --now nginx.service 2>/dev/null || true
  fi
  [ -x /usr/sbin/nginx ] || die "/usr/sbin/nginx is not there after installing its package"
  if [ "$FAMILY" = ubuntu ]; then
    if ! getent passwd nginx >/dev/null; then
      useradd --system --user-group --home-dir /nonexistent --no-create-home --shell "$NOLOGIN" \
        --comment "nginx front" nginx
    fi
    if ! a2query -q -m remoteip; then
      # shellcheck disable=SC2046 # one file per line, no spaces
      keep_original $(apache2_link_files mods-enabled remoteip)
      a2enmod -q remoteip >/dev/null
      out="$(apachectl -t 2>&1)" || die "Apache's configuration does not pass apachectl -t after turning on remoteip: $out"
      if systemctl is-active --quiet "$WEB_UNIT"; then systemctl reload "$WEB_UNIT"; fi
    fi
  fi
fi

# ---- Varnish (--varnish) ---------------------------------------------------
# Only the package, from the distribution's own repositories, stopped and
# disabled (and varnishncsa, which comes with it). The panel's switch (docs/api.md,
# "Web server") is what puts it between the front and Apache: it then listens on
# 127.0.0.1:6081 only, with its management port on 127.0.0.1:6082 for root
# alone, starts from freePanel's own VCL and secret through a drop-in, and the
# distribution's default.vcl and unit are left as they are. A server that already
# had Varnish keeps it exactly as it is; the switch refuses while it runs or is
# enabled. On Ubuntu and Debian the package would start Varnish as it installs,
# on every address: a policy-rc.d that refuses every start, there only while apt
# runs, keeps it stopped, as for nginx. Apache's hosts behind the cache read the
# visitor's address with mod_remoteip (on Ubuntu, turned on here); the edge hosts
# that pass to the cache without the nginx front need mod_proxy_http and
# mod_headers, which --web already has. Under SELinux, freepanel-varnish.cil lets
# Varnish reach Apache's loopback ports and Apache and nginx reach Varnish's.
varnish_installed() {
  if [ "$FAMILY" = el ]; then
    rpm -q varnish >/dev/null 2>&1
  else
    dpkg-query -W -f '${db:Status-Abbrev}' varnish 2>/dev/null | grep -q '^ii'
  fi
}
if [ "$VARNISH" -eq 1 ]; then
  if varnish_installed; then
    echo "Varnish is already installed here; leaving it as it is"
  else
    say "Installing Varnish (stopped and disabled)"
    if [ "$FAMILY" = el ]; then
      dnf -y -q install varnish || die "Varnish did not install from this release's repositories (it comes from AppStream); leave out --varnish"
    elif [ -e /usr/sbin/policy-rc.d ]; then
      pkg_install varnish || true
      varnish_installed || die "Varnish did not install"
    else
      printf '#!/bin/sh\n# Written by the freePanel installer while it installs Varnish; removed after.\nexit 101\n' >/usr/sbin/policy-rc.d
      chmod 0755 /usr/sbin/policy-rc.d
      rc=0
      pkg_install varnish || rc=$?
      rm -f /usr/sbin/policy-rc.d
      [ "$rc" -eq 0 ] || die "Varnish did not install"
    fi
    systemctl disable --quiet --now varnish.service varnishncsa.service 2>/dev/null || true
  fi
  if [ ! -x /usr/sbin/varnishd ] || [ ! -x /usr/bin/varnishadm ]; then
    die "/usr/sbin/varnishd or /usr/bin/varnishadm is not there after installing Varnish's package"
  fi
  getent passwd varnish >/dev/null || die "Varnish's package did not make its user, varnish"
  if [ "$FAMILY" = ubuntu ] && ! a2query -q -m remoteip; then
    # shellcheck disable=SC2046 # one file per line, no spaces
    keep_original $(apache2_link_files mods-enabled remoteip)
    a2enmod -q remoteip >/dev/null
    out="$(apachectl -t 2>&1)" || die "Apache's configuration does not pass apachectl -t after turning on remoteip: $out"
    if systemctl is-active --quiet "$WEB_UNIT"; then systemctl reload "$WEB_UNIT"; fi
  fi
  if command -v semodule >/dev/null && [ -f /etc/selinux/config ]; then
    if ! semodule -i "$SRC/installer/selinux/freepanel-varnish.cil"; then
      if command -v selinuxenabled >/dev/null && selinuxenabled; then die "could not load the Varnish cache's SELinux policy"; fi
      echo "  Warning: could not load the Varnish cache's SELinux policy (SELinux is off); re-run the installer to try again." >&2
    fi
  fi
fi

# ---- FTP (--ftp) -----------------------------------------------------------
# Pure-FTPd serves the FTP logins customers add (modules/ftp/README.md).
# pure-authd asks freepanel-ftpauth about each sign-in; it runs as its own
# user, which may read the root agent's list of logins and nothing else of
# ours. Sessions and file transfers must be encrypted, with the server's
# certificate. The package's own service stays off: its settings let system
# users sign in. Both families run the same binary the same way:
# freepanel-ftpd.service starts /usr/sbin/pure-ftpd with
# /etc/freepanel/pure-ftpd.conf, so Ubuntu's /etc/pure-ftpd/conf folder,
# which only its wrapper for the package's service reads, is not used.
if [ "$FTP" -eq 1 ]; then
  say "Installing FTP (Pure-FTPd)"
  INETD_NEW=0
  if [ "$FAMILY" = el ]; then
    install_epel_rhel
    pkg_install epel-release
    pkg_install pure-ftpd
  else
    # Ubuntu's pure-ftpd needs an inetd (openbsd-inetd), which freePanel
    # does not use: one this run installs is left off, with nothing in it.
    if [ "$(dpkg-query -W -f '${db:Status-Status}' openbsd-inetd 2>/dev/null || true)" != installed ]; then
      INETD_NEW=1
    fi
    pkg_install_held pure-ftpd.service inetd.service -- pure-ftpd
  fi
  command -v pure-authd >/dev/null || die "this pure-ftpd package has no pure-authd"
  keep_units pure-ftpd
  systemctl disable --quiet --now pure-ftpd.service 2>/dev/null || true
  if [ "$INETD_NEW" -eq 1 ]; then
    keep_units inetd
    systemctl disable --quiet --now inetd.service 2>/dev/null || true
  fi
  # Anonymous sessions (when the admin turns them on) run as the ftp user,
  # whose home must not exist (modules/ftp/ftpd). EL's base system has one;
  # Ubuntu has none, and Pure-FTPd logs at every start that it is missing.
  if ! getent passwd ftp >/dev/null && ! getent passwd _ftp >/dev/null; then
    if getent group ftp >/dev/null; then
      useradd --system --gid ftp --home-dir /srv/ftp --no-create-home --shell "$NOLOGIN" --comment "FTP anonymous sessions" ftp
    else
      useradd --system --user-group --home-dir /srv/ftp --no-create-home --shell "$NOLOGIN" --comment "FTP anonymous sessions" ftp
    fi
  fi
  if ! getent group "$FTP_GROUP" >/dev/null; then groupadd --system "$FTP_GROUP"; fi
  if ! getent passwd "$FTP_GROUP" >/dev/null; then
    useradd --system --gid "$FTP_GROUP" --home-dir / --no-create-home --shell "$NOLOGIN" \
      --comment "freePanel FTP sign-in" "$FTP_GROUP"
  fi
  install -d -m 0750 -o root -g "$FTP_GROUP" /var/lib/freepanel-ftp
  # The helper's own counts of failed guesses and its check slots.
  install -d -m 0700 -o "$FTP_GROUP" -g "$FTP_GROUP" /var/lib/freepanel-ftpauth
  sed -e "s#@AUTHSOCK@#/run/freepanel-ftpauth/authd.sock#" -e "s#@TLS@#3#" \
    -e "s#@CERT@#$ETC/ssl/_server/fullchain.pem#" -e "s#@KEY@#$ETC/ssl/_server/privkey.pem#" \
    -e "s#@PASVMIN@#$FTP_PASV_MIN#" -e "s#@PASVMAX@#$FTP_PASV_MAX#" \
    -e "s#@PIDFILE@#/run/freepanel-ftpd/pure-ftpd.pid#" -e "s#@DAEMONIZE@#no#" \
    "$SRC/installer/ftp/pure-ftpd.conf.in" >"$ETC/pure-ftpd.conf.new"
  chown root:root "$ETC/pure-ftpd.conf.new"
  chmod 0644 "$ETC/pure-ftpd.conf.new"
  mv -f "$ETC/pure-ftpd.conf.new" "$ETC/pure-ftpd.conf"
  if [ ! -f "$ETC/ftp.json" ]; then
    say "Writing $ETC/ftp.json"
    printf '{}\n' >"$ETC/ftp.json"
    chown root:root "$ETC/ftp.json"
    chmod 0644 "$ETC/ftp.json"
  else
    say "Keeping existing $ETC/ftp.json"
  fi
  if command -v restorecon >/dev/null; then
    restorecon "$ETC/ftp.json" "$ETC/pure-ftpd.conf" /var/lib/freepanel-ftp /var/lib/freepanel-ftpauth || true
  fi
  # Pure-FTPd may work in accounts' homes and reach pure-authd, and nothing
  # more (installer/selinux/freepanel-ftp.cil), rather than the policy's
  # ftpd_full_access. With SELinux off, a failure only warns.
  if command -v semodule >/dev/null && [ -f /etc/selinux/config ]; then
    if ! semodule -i "$SRC/installer/selinux/freepanel-ftp.cil"; then
      if command -v selinuxenabled >/dev/null && selinuxenabled; then die "could not load FTP's SELinux policy"; fi
      echo "  Warning: could not load FTP's SELinux policy (SELinux is off); re-run the installer to try again." >&2
    fi
  fi
fi

# ---- Redis for accounts (--redis) ------------------------------------------
# The distribution's Redis, started per account by a template unit
# (installer/redis/freepanel-redis@.service.in) that the root agent's Redis
# module drives (modules/redis/README.md). The package's own server, which
# would be one cache with no password for every account, is stopped and
# masked, and each account's runs as the account on a Unix socket in a folder
# only the account can enter (no TCP port, so no other account can reach it or
# use up its connections). SELinux: the accounts' folder gets the type Redis
# makes its socket in, so its domain may make the socket there.
if [ "$REDIS" -eq 1 ]; then
  say "Installing Redis"
  pkg_install "$REDIS_PKG"
  REDIS_DEFAULT_UNIT=$REDIS_UNIT
  REDIS_BIN="$(command -v "$REDIS_SERVER" || true)"
  [ -n "$REDIS_BIN" ] || die "Redis did not install (no $REDIS_SERVER)"
  # The unit runs it by its own name: on Ubuntu redis-server is a link to
  # redis-check-rdb, one binary that picks what it does from the name it was
  # run by, so the link's target would check an RDB file instead of serving.
  # Only the folder is resolved, and the link must lead into /usr as well.
  REDIS_BIN="$(readlink -f "$(dirname "$REDIS_BIN")")/$(basename "$REDIS_BIN")"
  case "$REDIS_BIN" in /usr/bin/*|/usr/sbin/*) ;; *) die "$REDIS_SERVER is at $REDIS_BIN, outside /usr" ;; esac
  case "$(readlink -f "$REDIS_BIN")" in /usr/bin/*|/usr/sbin/*) ;; *) die "$REDIS_SERVER leads to $(readlink -f "$REDIS_BIN"), outside /usr" ;; esac
  keep_units "$REDIS_DEFAULT_UNIT" freepanel-redis@.service
  systemctl disable --quiet --now "$REDIS_DEFAULT_UNIT" 2>/dev/null || true
  systemctl mask --quiet "$REDIS_DEFAULT_UNIT"
  install -d -m 0755 -o root -g root /var/lib/freepanel-redis
  sed -e "s#@BINARY@#$REDIS_BIN#" "$SRC/installer/redis/freepanel-redis@.service.in" >/etc/systemd/system/freepanel-redis@.service.new
  chown root:root /etc/systemd/system/freepanel-redis@.service.new
  chmod 0644 /etc/systemd/system/freepanel-redis@.service.new
  mv -f /etc/systemd/system/freepanel-redis@.service.new /etc/systemd/system/freepanel-redis@.service
  systemctl daemon-reload
  if command -v selinuxenabled >/dev/null && selinuxenabled; then
    [ "$FAMILY" != el ] || dnf -y -q install policycoreutils-python-utils
    keep_selinux_local
    semanage fcontext -a -t redis_var_run_t '/var/lib/freepanel-redis(/.*)?' 2>/dev/null ||
      semanage fcontext -m -t redis_var_run_t '/var/lib/freepanel-redis(/.*)?'
  fi
  if command -v restorecon >/dev/null; then restorecon -R /var/lib/freepanel-redis /etc/systemd/system/freepanel-redis@.service || true; fi
  # The PHP extension, so a site's code can talk to it (PHP-FPM reads it at
  # its next start). Only where the web stack is on this server.
  if [ "$FAMILY" = el ] && { [ "$WEB" -eq 1 ] || [ -f "$ETC/web.json" ]; }; then
    dnf -y -q install "$PHP_PKG-php-pecl-redis6" || echo "  Warning: could not install the PHP extension for Redis ($PHP_PKG-php-pecl-redis6)." >&2
    systemctl try-reload-or-restart "$PHP_PKG-php-fpm.service" 2>/dev/null || true
  elif [ "$FAMILY" = ubuntu ] && { [ "$WEB" -eq 1 ] || [ -f "$ETC/web.json" ]; }; then
    # The archive's (8.3) or the PHP PPA's build for the other versions.
    pkg_install "php$PHP_TAG-redis" || echo "  Warning: could not install the PHP extension for Redis (php$PHP_TAG-redis)." >&2
    systemctl try-reload-or-restart "$PHP_UNIT.service" 2>/dev/null || true
  fi
  printf '{"enabled":true}\n' >"$ETC/redis.json.new"
  chown root:root "$ETC/redis.json.new"
  chmod 0644 "$ETC/redis.json.new"
  mv -f "$ETC/redis.json.new" "$ETC/redis.json"
  if command -v restorecon >/dev/null; then restorecon "$ETC/redis.json" || true; fi
fi

# ---- Memcached for accounts (--memcached) ----------------------------------
# The distribution's memcached, started per account by a template unit
# (installer/memcached/freepanel-memcached@.service.in) that the root agent's
# Memcached module drives (modules/memcached/README.md). Memcached has no
# passwords, so the package's own server (one cache on a port of the loopback
# for every account) is stopped and masked, and each account's runs as the
# account on a Unix socket in a folder only the account can enter. SELinux: the
# accounts' folder gets memcached's own type, so its domain may make the
# socket there.
if [ "$MEMCACHED" -eq 1 ]; then
  say "Installing Memcached"
  if [ "$FAMILY" = el ]; then
    pkg_install memcached
  else
    pkg_install memcached
  fi
  MEMCACHED_BIN="$(command -v memcached || true)"
  [ -n "$MEMCACHED_BIN" ] || die "Memcached did not install (no memcached)"
  MEMCACHED_BIN="$(readlink -f "$MEMCACHED_BIN")"
  case "$MEMCACHED_BIN" in /usr/bin/*|/usr/sbin/*) ;; *) die "memcached is at $MEMCACHED_BIN, outside /usr" ;; esac
  keep_units memcached.service freepanel-memcached@.service
  systemctl disable --quiet --now memcached.service 2>/dev/null || true
  systemctl mask --quiet memcached.service
  install -d -m 0755 -o root -g root /var/lib/freepanel-memcached
  sed -e "s#@BINARY@#$MEMCACHED_BIN#" "$SRC/installer/memcached/freepanel-memcached@.service.in" >/etc/systemd/system/freepanel-memcached@.service.new
  chown root:root /etc/systemd/system/freepanel-memcached@.service.new
  chmod 0644 /etc/systemd/system/freepanel-memcached@.service.new
  mv -f /etc/systemd/system/freepanel-memcached@.service.new /etc/systemd/system/freepanel-memcached@.service
  systemctl daemon-reload
  if command -v selinuxenabled >/dev/null && selinuxenabled; then
    [ "$FAMILY" != el ] || dnf -y -q install policycoreutils-python-utils
    keep_selinux_local
    semanage fcontext -a -t memcached_var_run_t '/var/lib/freepanel-memcached(/.*)?' 2>/dev/null ||
      semanage fcontext -m -t memcached_var_run_t '/var/lib/freepanel-memcached(/.*)?'
  fi
  if command -v restorecon >/dev/null; then restorecon -R /var/lib/freepanel-memcached /etc/systemd/system/freepanel-memcached@.service || true; fi
  # The PHP extension, so a site's code can talk to it (PHP-FPM reads it at
  # its next start). Only where the web stack is on this server.
  if [ "$FAMILY" = el ] && { [ "$WEB" -eq 1 ] || [ -f "$ETC/web.json" ]; }; then
    dnf -y -q install "$PHP_PKG-php-pecl-memcached" || echo "  Warning: could not install the PHP extension for Memcached ($PHP_PKG-php-pecl-memcached)." >&2
    systemctl try-reload-or-restart "$PHP_PKG-php-fpm.service" 2>/dev/null || true
  elif [ "$FAMILY" = ubuntu ] && { [ "$WEB" -eq 1 ] || [ -f "$ETC/web.json" ]; }; then
    # The archive's (8.3) or the PHP PPA's build for the other versions.
    pkg_install "php$PHP_TAG-memcached" || echo "  Warning: could not install the PHP extension for Memcached (php$PHP_TAG-memcached)." >&2
    systemctl try-reload-or-restart "$PHP_UNIT.service" 2>/dev/null || true
  fi
  printf '{"enabled":true}\n' >"$ETC/memcached.json.new"
  chown root:root "$ETC/memcached.json.new"
  chmod 0644 "$ETC/memcached.json.new"
  mv -f "$ETC/memcached.json.new" "$ETC/memcached.json"
  if command -v restorecon >/dev/null; then restorecon "$ETC/memcached.json" || true; fi
fi

# ---- Disk quotas ------------------------------------------------------------
# Packages' disk space is enforced as user quotas on the filesystem holding
# /home (docs/disk-quotas.md). The installer turns them on where that is safe:
# ext4 now (the mount option, a remount, quotacheck and quotaon), XFS at the
# next restart (XFS reads quota options only when it mounts: rootflags=uquota
# for /, uquota in /etc/fstab for a /home of its own). It never restarts the
# server, never unmounts anything, and parks /etc/fstab and /etc/default/grub
# beside themselves before the first change. --no-quotas leaves all of it as
# it is. QUOTA_NOTE is the closing note, empty when quotas are enforced.
# quotaon exits with the number of quota types that are on, so its status
# stays out of the tests. With --verbose it says "is on (accounting)" when
# usage is counted but not enforced.
QUOTA_NOTE=""
FSTAB_BEFORE=""
QUOTA_PENDING=/etc/freepanel/quota-restart
quota_enforced() {
  local state
  state="$(quotaon --print-state --verbose --user "$1" 2>/dev/null || true)"
  printf '%s\n' "$state" | grep '^user quota on ' | grep ') is on' | grep -v accounting >/dev/null
}
# park_once FILE: a copy of FILE beside it, made once, before the installer
# first changes it.
park_once() {
  [ -e "$1.freepanel-orig" ] || cp -p "$1" "$1.freepanel-orig"
}
# fstab_add_opt MOUNT OPT: adds OPT to the options of MOUNT's line in
# /etc/fstab (the first that is not a comment). Fails, changing nothing, when
# there is no such line.
fstab_add_opt() {
  local tmp
  awk -v m="$1" '!/^[[:space:]]*#/ && NF >= 4 && $2 == m { found = 1 } END { exit !found }' /etc/fstab || return 1
  park_once /etc/fstab
  FSTAB_BEFORE="$(mktemp /etc/fstab.before.XXXXXX)"
  cp -p /etc/fstab "$FSTAB_BEFORE"
  tmp="$(mktemp /etc/fstab.XXXXXX)"
  awk -v m="$1" -v o="$2" '
    !done && !/^[[:space:]]*#/ && NF >= 4 && $2 == m {
      n = split($4, a, ","); has = 0
      for (i = 1; i <= n; i++) if (a[i] == o) has = 1
      if (!has) { $4 = ($4 == "defaults" ? "defaults," o : $4 "," o) }
      done = 1
    }
    { print }' /etc/fstab >"$tmp"
  chmod 0644 "$tmp"
  mv -f "$tmp" /etc/fstab
  if command -v restorecon >/dev/null; then restorecon /etc/fstab || true; fi
  systemctl daemon-reload 2>/dev/null || true
}
# quota_v2_ready: the kernel can keep quota files of the current format.
# Ubuntu's smallest cloud kernels keep the module in linux-modules-extra.
quota_v2_ready() {
  modprobe -q quota_v2 2>/dev/null && return 0
  grep -qs '/quota_v2.ko' "/lib/modules/$(uname -r)/modules.builtin" && return 0
  [ "$FAMILY" = ubuntu ] || return 1
  pkg_install "linux-modules-extra-$(uname -r)" >/dev/null 2>&1 || return 1
  modprobe -q quota_v2 2>/dev/null
}
# xfs_root_quota: rootflags=uquota on every boot entry, and in
# /etc/default/grub for kernels installed later.
xfs_root_quota() {
  if [ -f /etc/default/grub ] && ! grep -Eq '^GRUB_CMDLINE_LINUX="[^"]*rootflags=' /etc/default/grub; then
    park_once /etc/default/grub
    sed -i -E 's/^(GRUB_CMDLINE_LINUX=")([^"]*)"/\1\2 rootflags=uquota"/; s/^(GRUB_CMDLINE_LINUX=") /\1/' /etc/default/grub
  fi
  if command -v grubby >/dev/null; then
    grubby --update-kernel=ALL --args=rootflags=uquota >/dev/null
  elif command -v update-grub >/dev/null; then
    update-grub >/dev/null 2>&1
  else
    return 1
  fi
}
enable_quotas() {
  local mount fstype root_flags
  mount="$(findmnt --noheadings --output TARGET --target /home 2>/dev/null || true)"
  if [ -z "$mount" ]; then
    QUOTA_NOTE="Disk quotas are off: the filesystem holding /home was not found. Packages' disk space is not enforced. See docs/disk-quotas.md."
    return 0
  fi
  if quota_enforced "$mount"; then
    rm -f "$QUOTA_PENDING"
    return 0
  fi
  if systemd-detect-virt --quiet --container 2>/dev/null; then
    QUOTA_NOTE="Disk quotas are off: this server is a container, whose host decides them. Packages' disk space is not enforced."
    return 0
  fi
  fstype="$(findmnt --noheadings --output FSTYPE --target /home 2>/dev/null || true)"
  case "$fstype" in
    ext4|ext3)
      say "Turning on disk quotas for $mount"
      if ! quota_v2_ready; then
        QUOTA_NOTE="Disk quotas are off: this kernel has no quota support (module quota_v2). Packages' disk space is not enforced. See docs/disk-quotas.md."
        return 0
      fi
      if ! findmnt --fstab --noheadings --output OPTIONS --mountpoint "$mount" 2>/dev/null | tr ',' '\n' | grep -Ex 'usrquota|usrjquota=.*|quota' >/dev/null; then
        if ! fstab_add_opt "$mount" usrquota; then
          QUOTA_NOTE="Disk quotas are off: $mount has no line in /etc/fstab to add usrquota to. Packages' disk space is not enforced. See docs/disk-quotas.md."
          return 0
        fi
      fi
      if ! mount -o remount "$mount" 2>/dev/null; then
        # Put the parked fstab back, so the next boot mounts as before.
        if [ -n "$FSTAB_BEFORE" ]; then mv -f "$FSTAB_BEFORE" /etc/fstab; FSTAB_BEFORE=""; systemctl daemon-reload 2>/dev/null || true; fi
        QUOTA_NOTE="Disk quotas are off: $mount could not be remounted with usrquota. Packages' disk space is not enforced. See docs/disk-quotas.md."
        return 0
      fi
      [ -z "$FSTAB_BEFORE" ] || rm -f "$FSTAB_BEFORE"
      quotacheck --create-files --user --no-remount "$mount" >/dev/null 2>&1 || quotacheck -cum "$mount" >/dev/null 2>&1 || true
      quotaon --user "$mount" >/dev/null 2>&1 || true
      if ! quota_enforced "$mount"; then
        QUOTA_NOTE="Disk quotas could not be turned on for $mount. Packages' disk space is not enforced. See docs/disk-quotas.md."
      fi
      ;;
    xfs)
      say "Turning on disk quotas for $mount (at the next restart)"
      if [ "$mount" = / ]; then
        root_flags="$(grep -o 'rootflags=[^ ]*' /proc/cmdline || true)"
        if [ -n "$root_flags" ] && [ "$root_flags" != rootflags=uquota ]; then
          QUOTA_NOTE="Disk quotas are off: the boot settings already give / other mount flags ($root_flags). Packages' disk space is not enforced. See docs/disk-quotas.md."
          return 0
        fi
        if ! xfs_root_quota; then
          QUOTA_NOTE="Disk quotas are off: no grubby or update-grub to add rootflags=uquota with. Packages' disk space is not enforced. See docs/disk-quotas.md."
          return 0
        fi
      else
        if ! findmnt --fstab --noheadings --output OPTIONS --mountpoint "$mount" 2>/dev/null | tr ',' '\n' | grep -Ex 'uquota|usrquota|quota|uqnoenforce' >/dev/null; then
          if ! fstab_add_opt "$mount" uquota; then
            QUOTA_NOTE="Disk quotas are off: $mount has no line in /etc/fstab to add uquota to. Packages' disk space is not enforced. See docs/disk-quotas.md."
            return 0
          fi
        fi
      fi
      [ -z "$FSTAB_BEFORE" ] || rm -f "$FSTAB_BEFORE"
      # The root agent reads this to say why limits wait (internal/privd/quota.go).
      printf '%s\n' "$mount" >"$QUOTA_PENDING"
      chmod 0644 "$QUOTA_PENDING"
      QUOTA_NOTE="Disk quotas turn on for $mount when the server next restarts. Until then packages' disk space is not enforced."
      ;;
    *)
      QUOTA_NOTE="Disk quotas are off: freePanel turns them on for ext4 and XFS, and $mount is ${fstype:-of an unknown type}. Packages' disk space is not enforced. See docs/disk-quotas.md."
      ;;
  esac
}
if [ "$QUOTAS" -eq 1 ]; then
  enable_quotas
else
  HOME_MOUNT_NQ="$(findmnt --noheadings --output TARGET --target /home 2>/dev/null || true)"
  if [ -z "$HOME_MOUNT_NQ" ] || ! quota_enforced "$HOME_MOUNT_NQ"; then
    QUOTA_NOTE="Disk quotas are off (--no-quotas), so packages' disk space is not enforced. See docs/disk-quotas.md."
  fi
fi

# ---- Database --------------------------------------------------------------
say "Migrating the database"
runuser -u "$SVC_USER" -- "$PREFIX/bin/freepanelctl" migrate

# ---- Services --------------------------------------------------------------
say "Starting services"
install -m 0644 "$SRC/installer/systemd/freepanel-privd.service" /etc/systemd/system/
install -m 0644 "$SRC/installer/systemd/freepanel-api.service" /etc/systemd/system/
# The agent's socket folder, root:freepanel 0750, kept across restarts so
# the API can reach the socket as soon as the agent listens (85-1).
printf '# Written by the freePanel installer.\nd /run/freepanel 0750 root %s -\n' "$SVC_USER" \
  >/etc/tmpfiles.d/freepanel.conf
chmod 0644 /etc/tmpfiles.d/freepanel.conf
systemd-tmpfiles --create /etc/tmpfiles.d/freepanel.conf
# With the mail stack, also on a re-run without --mail.
MILTER=0
if [ "$MAIL" -eq 1 ] || [ -f "$ETC/mail.json" ]; then MILTER=1; fi
if [ "$MILTER" -eq 1 ]; then
  install -m 0644 "$SRC/installer/systemd/freepanel-milter.service" /etc/systemd/system/
fi
# The FTP helper's check of accounts' own logins, once the FTP step has
# made the helper's user (freepanel-ftpauth); systemd makes the socket.
FTPCHECK=0
if getent group freepanel-ftpauth >/dev/null; then
  FTPCHECK=1
  install -m 0644 "$SRC/installer/systemd/freepanel-ftpcheck.socket" /etc/systemd/system/
fi
# The web server's way to the customer panel for the resellers' own panel
# names on 443, with the web stack (internal/api.PanelProxy): systemd makes the
# socket, which only Apache's group may open, and Apache may connect to the
# panel through it (installer/selinux/freepanel-panelproxy.cil) and nothing
# more. With SELinux off, a failure to load the policy only warns.
# On Ubuntu the socket's group is the web server's there (www-data); SELinux's
# policy is EL's alone.
PANELPROXY=0
if [ "$FAMILY" = ubuntu ] && { [ "$WEB" -eq 1 ] || [ -f "$ETC/web.json" ]; } && getent group "$WEB_GROUP" >/dev/null; then
  PANELPROXY=1
  sed "s/^SocketGroup=apache\$/SocketGroup=$WEB_GROUP/" "$SRC/installer/systemd/freepanel-panelproxy.socket" \
    >/etc/systemd/system/freepanel-panelproxy.socket.new
  grep -qx "SocketGroup=$WEB_GROUP" /etc/systemd/system/freepanel-panelproxy.socket.new ||
    die "installer/systemd/freepanel-panelproxy.socket has no SocketGroup=apache line to set to $WEB_GROUP"
  chmod 0644 /etc/systemd/system/freepanel-panelproxy.socket.new
  mv -f /etc/systemd/system/freepanel-panelproxy.socket.new /etc/systemd/system/freepanel-panelproxy.socket
fi
if [ "$FAMILY" = el ] && { [ "$WEB" -eq 1 ] || [ -f "$ETC/web.json" ]; } && getent group apache >/dev/null; then
  PANELPROXY=1
  install -m 0644 "$SRC/installer/systemd/freepanel-panelproxy.socket" /etc/systemd/system/
  if command -v semodule >/dev/null && [ -f /etc/selinux/config ]; then
    if ! semodule -i "$SRC/installer/selinux/freepanel-panelproxy.cil"; then
      if command -v selinuxenabled >/dev/null && selinuxenabled; then die "could not load the panel proxy's SELinux policy"; fi
      echo "  Warning: could not load the panel proxy's SELinux policy (SELinux is off); re-run the installer to try again." >&2
    fi
  fi
fi
systemctl daemon-reload
if [ "$MILTER" -eq 1 ]; then
  # The sendmail command's sender check where Postfix has none of its own
  # (3.5; modules/mail/milter). It is up before freepanel-privd points
  # Postfix at it, so no local mail waits for it. Our policy module runs it
  # in its own SELinux type, which alone Postfix's cleanup and smtpd may
  # reach. It goes in wherever the SELinux tools are, so it is there if
  # SELinux is turned on later.
  # With SELinux off (as on most hosts coming from other panels), a failure
  # only warns; the next run tries again.
  if command -v semodule >/dev/null && [ -f /etc/selinux/config ]; then
    SELINUX_ON=0
    if command -v selinuxenabled >/dev/null && selinuxenabled; then SELINUX_ON=1; fi
    if ! semodule -i "$SRC/installer/selinux/freepanel-milter.cil"; then
      [ "$SELINUX_ON" -eq 1 ] && die "could not load freepanel-milter's SELinux policy"
      echo "  Warning: could not load freepanel-milter's SELinux policy (SELinux is off); re-run the installer to try again." >&2
    elif ! restorecon "$PREFIX/bin/freepanel-milter"; then
      [ "$SELINUX_ON" -eq 1 ] && die "could not label freepanel-milter"
      echo "  Warning: could not label freepanel-milter for SELinux (SELinux is off); re-run the installer to try again." >&2
    fi
    # An rspamd already running keeps the folder it made before the policy
    # named it; systemd makes it with the new type at its next start.
    if [ -d /run/rspamd ]; then restorecon -R /run/rspamd || true; fi
    # rspamd runs in its own type (freepanel-services.cil) from its next start; one started before is started again
    # now, once. While it restarts, Postfix takes port 25 mail unscored (default_action=accept), as when rspamd is off.
    if [ "$SELINUX_ON" -eq 1 ] && systemctl is-active --quiet rspamd && [ "$(unit_selinux_type rspamd)" != freepanel_rspamd_t ]; then
      systemctl restart rspamd || echo "  Warning: rspamd did not restart in its SELinux type; see: journalctl -u rspamd" >&2
    fi
  fi
  keep_units freepanel-milter
  systemctl enable --quiet freepanel-milter
  systemctl restart freepanel-milter
  systemctl is-active --quiet freepanel-milter || die "freepanel-milter did not start; see: journalctl -u freepanel-milter"
fi
# Every service user and group the panel relies on must have a system ID.
# One above that may be a hosting account that took the name before the
# service was installed; the root agent refuses such a group or user too.
for name in "$WEB_USER" postfix postdrop dovecot dovenull opendkim pdns mysql postgres; do
  for db in passwd group; do
    id=$(getent "$db" "$name" | cut -d: -f3) || continue
    if [ -n "$id" ] && [ "$id" -gt 999 ]; then
      die "the $db entry $name has id $id, which is not a system id: a hosting account may hold the name. Rename or remove it, then re-run the installer"
    fi
  done
done

# Customers' scheduled tasks run under the system's cron.
keep_units "$CRON_UNIT" freepanel-privd freepanel-api
systemctl enable --now --quiet "$CRON_UNIT"
systemctl enable --quiet freepanel-privd freepanel-api
if [ "$FTPCHECK" -eq 1 ]; then
  # Listening before the API starts, so the API is handed the socket.
  # systemd won't start a socket while its service runs, so the API stops
  # first; the restart below starts it again.
  systemctl enable --quiet freepanel-ftpcheck.socket
  if ! systemctl is-active --quiet freepanel-ftpcheck.socket; then
    systemctl stop freepanel-api
    systemctl start freepanel-ftpcheck.socket
  fi
fi
if [ "$PANELPROXY" -eq 1 ]; then
  # As for the FTP check: listening before the API starts.
  systemctl enable --quiet freepanel-panelproxy.socket
  if ! systemctl is-active --quiet freepanel-panelproxy.socket; then
    systemctl stop freepanel-api
    systemctl start freepanel-panelproxy.socket
  fi
  # The socket file's type is installer/selinux/freepanel-panelproxy.cil's,
  # which systemd gives it when it makes it; one made before the module was
  # loaded (an upgrade) is labelled here, or Apache may not write it.
  if command -v restorecon >/dev/null && [ -S /run/freepanel-panelproxy.sock ]; then restorecon /run/freepanel-panelproxy.sock || true; fi
fi
# freepanel-api's listening sockets take its SELinux type when systemd makes them, worked out from the binary's type
# (installer/selinux/freepanel-services.cil). Sockets made while the binary was bin_t are unconfined_service_t, which
# Apache and the FTP helper may not connect to once the bridge is gone, so on the first run of this release (the API still
# runs as unconfined_service_t) they are made again while the API is stopped. That is the one moment in the upgrade when a
# panel proxy request or an FTP sign-in with an account's own login can fail: a socket's type is fixed when it is made.
if command -v selinuxenabled >/dev/null && selinuxenabled && [ "$(unit_selinux_type freepanel-api)" != freepanel_api_t ]; then
  for s in freepanel-ftpcheck.socket freepanel-panelproxy.socket; do
    if systemctl is-active --quiet "$s"; then
      systemctl stop freepanel-api
      systemctl restart "$s"
    fi
  done
  if command -v restorecon >/dev/null && [ -S /run/freepanel-panelproxy.sock ]; then restorecon /run/freepanel-panelproxy.sock || true; fi
fi
systemctl restart freepanel-privd
systemctl restart freepanel-api

for _ in $(seq 1 20); do
  systemctl is-active --quiet freepanel-api && break
  sleep 0.5
done
systemctl is-active --quiet freepanel-privd || die "freepanel-privd did not start; see: journalctl -u freepanel-privd"
systemctl is-active --quiet freepanel-api || die "freepanel-api did not start; see: journalctl -u freepanel-api"

# ---- Licence ---------------------------------------------------------------
# The key goes in on stdin, not on a command line. A key that is refused or a
# service that cannot be reached is a warning: the panel is up and opens on
# its Licence page, and a re-run or the page can try again.
if [ -n "$LICENSE_KEY" ]; then
  say "Storing the licence key"
  if LICENSE_OUT="$(printf '%s\n' "$LICENSE_KEY" | runuser -u "$SVC_USER" -- "$PREFIX/bin/freepanelctl" license set-key - 2>&1)"; then
    printf '%s\n' "$LICENSE_OUT" | sed 's/^/  /'
  else
    printf '  Warning: the licence key was not stored: %s\n' "$LICENSE_OUT" >&2
  fi
  unset LICENSE_KEY LICENSE_OUT FREEPANEL_LICENSE_KEY
fi
# Empty on a build that does not check a licence.
LICENSE_STATE="$(runuser -u "$SVC_USER" -- "$PREFIX/bin/freepanelctl" license status 2>/dev/null | awk '$1 == "state" { print $2; exit }' || true)"

if [ "$MAIL" -eq 1 ]; then
  # freepanel-privd writes Dovecot's config, users file and tables before
  # it opens its socket, so Dovecot never starts on the package's stock
  # settings. The unit removes the socket when the agent stops (the units
  # are reloaded above, before the restart), so the socket is the new
  # agent's (85-3).
  for _ in $(seq 1 40); do
    [ -S /run/freepanel/privd.sock ] && break
    sleep 0.5
  done
  [ -S /run/freepanel/privd.sock ] || die "freepanel-privd did not open its socket; see: journalctl -u freepanel-privd"
  # The agent listens even when writing the mail config failed, so the
  # file itself must be ours before Dovecot reads it (26-2).
  head -n 1 /etc/dovecot/dovecot.conf 2>/dev/null | grep -q '^# Managed by freePanel\.' ||
    die "freepanel-privd has not written Dovecot's config, so Dovecot was not restarted on it; see: journalctl -u freepanel-privd"
  systemctl restart dovecot
  systemctl is-active --quiet dovecot || die "dovecot did not start; see: journalctl -u dovecot"
fi

# FTP starts once freepanel-privd has written the list of logins and the web
# module the server's certificate; also on a re-run without --ftp.
if [ "$FTP" -eq 1 ] || [ -f "$ETC/ftp.json" ]; then
  FTP_UID="$(id -u "$FTP_GROUP")"
  FTP_GID="$(getent group "$FTP_GROUP" | cut -d: -f3)"
  sed -e "s#@UID@#$FTP_UID#" -e "s#@GID@#$FTP_GID#" \
    "$SRC/installer/systemd/freepanel-ftpauth.service.in" >/etc/systemd/system/freepanel-ftpauth.service
  chmod 0644 /etc/systemd/system/freepanel-ftpauth.service
  install -m 0644 "$SRC/installer/systemd/freepanel-ftpd.service" /etc/systemd/system/
  systemctl daemon-reload
  for _ in $(seq 1 40); do
    [ -f /var/lib/freepanel-ftp/logins.json ] && [ -f "$ETC/ssl/_server/fullchain.pem" ] && break
    sleep 0.5
  done
  [ -f /var/lib/freepanel-ftp/logins.json ] || die "freepanel-privd did not write the FTP logins; see: journalctl -u freepanel-privd"
  [ -f "$ETC/ssl/_server/fullchain.pem" ] || die "the server certificate is missing; see: journalctl -u freepanel-privd"
  # On a re-run without --ftp the FTP step above did not load Pure-FTPd's module; the version that names pure-authd's
  # type must be in before pure-authd starts in it.
  if [ "$FTP" -ne 1 ] && command -v semodule >/dev/null && [ -f /etc/selinux/config ]; then
    if ! semodule -i "$SRC/installer/selinux/freepanel-ftp.cil"; then
      if command -v selinuxenabled >/dev/null && selinuxenabled; then die "could not load FTP's SELinux policy"; fi
      echo "  Warning: could not load FTP's SELinux policy (SELinux is off); re-run the installer to try again." >&2
    fi
  fi
  keep_units freepanel-ftpauth freepanel-ftpd
  systemctl enable --quiet freepanel-ftpauth freepanel-ftpd
  systemctl restart freepanel-ftpauth freepanel-ftpd
  # pure-authd's folder takes its type from installer/selinux/freepanel-ftp.cil
  # when systemd makes it; a folder made before the module was loaded is
  # labelled here, or Pure-FTPd may not reach the socket in it.
  if command -v restorecon >/dev/null && [ -d /run/freepanel-ftpauth ]; then restorecon -R /run/freepanel-ftpauth || true; fi
  # The panel restarts freepanel-ftpd itself when it writes the FTP settings,
  # which can land on this check (Rocky 10 run 42444152809: started, stopped,
  # started within the same second), so a stop and start is waited out.
  for _ in $(seq 1 20); do
    systemctl is-active --quiet freepanel-ftpd && break
    sleep 0.5
  done
  systemctl is-active --quiet freepanel-ftpauth || die "freepanel-ftpauth did not start; see: journalctl -u freepanel-ftpauth"
  systemctl is-active --quiet freepanel-ftpd || die "freepanel-ftpd did not start; see: journalctl -u freepanel-ftpd"
fi

# The root agent turns the firewall and the scanner on at its first start
# (above); what it did is checked here, so the closing lines say what is so.
if [ "$WEB" -eq 1 ] && [ -z "$WAF_OFF_WHY" ]; then
  waf_conf=/etc/apache2/conf-enabled/zz-freepanel-waf.conf
  [ "$FAMILY" != el ] || waf_conf=/etc/httpd/conf.d/zz-freepanel-waf.conf
  for _ in $(seq 1 120); do
    grep -Eq '^[[:space:]]*SecRuleEngine (On|DetectionOnly)$' "$waf_conf" 2>/dev/null && break
    sleep 1
  done
  if ! grep -Eq '^[[:space:]]*SecRuleEngine (On|DetectionOnly)$' "$waf_conf" 2>/dev/null; then
    WAF_OFF_WHY="the root agent did not turn it on; see: journalctl -u freepanel-privd"
  fi
fi
if [ "$WEB" -eq 1 ] && [ -z "$SCAN_OFF_WHY" ]; then
  for _ in $(seq 1 120); do
    grep -Eq '"enabled": *true' /var/lib/freepanel-privd/web/clamav.json 2>/dev/null && break
    sleep 1
  done
  if ! grep -Eq '"enabled": *true' /var/lib/freepanel-privd/web/clamav.json 2>/dev/null; then
    SCAN_OFF_WHY="the root agent did not turn it on; see: journalctl -u freepanel-privd"
  fi
fi

# ---- Services in their SELinux domains --------------------------------------
# EL10's policy names programs by /usr/bin and treats /usr/sbin as the same
# folder, but a package's files under /usr/sbin can arrive labelled bin_t; a
# service started from one then runs unconfined (unconfined_service_t)
# instead of in its own domain. OpenDKIM did: Postfix, which may connect
# only to dkim_milter_t, got "Permission denied" and mail went out unsigned.
# Every service running unconfined whose program the policy labels otherwise
# is relabelled and restarted, and must then run in its own domain.
if [ "$FAMILY" = el ] && command -v selinuxenabled >/dev/null && selinuxenabled; then
  relabelled_units=()
  while read -r pid label; do
    case "$label" in *:unconfined_service_t:*) ;; *) continue ;; esac
    exe="$(readlink -f "/proc/$pid/exe" 2>/dev/null)" || continue
    want="$(matchpathcon -n "$exe" 2>/dev/null | cut -d: -f3)" || continue
    have="$(stat -c %C "$exe" 2>/dev/null | cut -d: -f3)" || continue
    if [ -z "$want" ] || [ "$want" = "$have" ]; then continue; fi
    unit="$(ps -o unit= -p "$pid" 2>/dev/null | tr -d ' ')" || continue
    case "$unit" in *.service) ;; *) continue ;; esac
    restorecon -F "$exe"
    echo "relabelled $exe ($have to $want) for $unit"
    relabelled_units+=("$unit")
  done < <(ps -eo pid=,label=)
  if [ "${#relabelled_units[@]}" -gt 0 ]; then
    mapfile -t relabelled_units < <(printf '%s\n' "${relabelled_units[@]}" | sort -u)
    systemctl restart "${relabelled_units[@]}"
    for unit in "${relabelled_units[@]}"; do
      pid="$(systemctl show -p MainPID --value "$unit")"
      dom="$(ps -o label= -p "$pid" 2>/dev/null | cut -d: -f3)" || dom=
      if [ "$dom" = unconfined_service_t ] || [ -z "$dom" ]; then
        die "$unit still runs unconfined after its program was relabelled; see: ls -Z /proc/$pid/exe"
      fi
    done
  fi
fi

# ---- The SELinux bridge ----------------------------------------------------
# freepanel-bridge.cil (loaded above on the first run of this release) kept the earlier rules while freepanel-api,
# pure-authd and rspamd still ran as unconfined_service_t. Each that runs is now in its own type, so it goes; if one is
# not, it stays, nothing that worked stops working, and the next run tries again.
if command -v semodule >/dev/null && [ -f /etc/selinux/config ]; then
  fp_modules="$(semodule -l 2>/dev/null || true)"
  if grep -qx freepanel-bridge <<<"$fp_modules"; then
    fp_old=""
    for u in freepanel-api:freepanel_api_t freepanel-ftpauth:freepanel_ftpauth_t rspamd:freepanel_rspamd_t; do
      if systemctl is-active --quiet "${u%%:*}" && [ "$(unit_selinux_type "${u%%:*}")" != "${u#*:}" ]; then fp_old="$fp_old ${u%%:*}"; fi
    done
    if [ -n "$fp_old" ] && command -v selinuxenabled >/dev/null && selinuxenabled; then
      echo "  Warning: still not in their own SELinux types:$fp_old; the module freepanel-bridge stays loaded until a re-run of the installer." >&2
    elif ! semodule -r freepanel-bridge; then
      echo "  Warning: could not remove the SELinux module freepanel-bridge; re-run the installer to try again." >&2
    fi
    unset fp_old
  fi
  unset fp_modules
fi

# ---- First-run setup -------------------------------------------------------
URL="https://$HOSTNAME_FQDN:$PORT"
if TOKEN="$(runuser -u "$SVC_USER" -- "$PREFIX/bin/freepanelctl" setup-token 2>/dev/null)"; then
  say "freePanel is running"
  echo
  echo "  Create the admin login within 24 hours at:"
  echo "    $URL/setup#$TOKEN"
  echo
  echo "  This link works once. To get a new one: runuser -u $SVC_USER -- freepanelctl setup-token"
else
  say "freePanel is running at $URL"
fi
echo "  Customers sign in at https://$HOSTNAME_FQDN:$USER_PORT"
case "$LICENSE_STATE" in
  unlicensed|locked)
    echo "  Licence: the panel has no working licence key, so it opens on its Licence page. Enter the key there, or run:"
    echo "    echo KEY | runuser -u $SVC_USER -- freepanelctl license set-key -"
    echo "  The server must reach the licence service over HTTPS (outbound port 443). Sites and mail are not affected."
    ;;
  grace)
    echo "  Licence: this server has no licence key yet. The panel keeps working for a while; run"
    echo "    runuser -u $SVC_USER -- freepanelctl license status"
    echo "  to see until when, and enter the key on the Licence page."
    ;;
esac
# The disk quota state worked out under "Disk quotas" above.
if [ -n "$QUOTA_NOTE" ]; then
  echo "  $QUOTA_NOTE"
fi
if [ "$MAIL" -eq 1 ] || [ -f "$ETC/mail.json" ]; then
  # Every local user may send as LOGIN@hostname, so DMARC's relaxed SPF
  # alignment would let any account's mail pass as the hostname's domain.
  echo "  Mail: every local user may send as LOGIN@$HOSTNAME_FQDN. Keep this hostname under a domain that sends no"
  echo "  other mail, or publish aspf=s in that domain's DMARC record."
fi
if [ "$PROTECT" -eq 1 ]; then
  echo "  Login protection is on (SSH, the panels, and mail and FTP where installed). Never blocked: ${PROTECT_SEEDS:-no address was found to allow; add yours in the panel}."
fi
if [ "$WEB" -eq 1 ]; then
  if [ -n "$WAF_OFF_WHY" ]; then
    echo "  THE WEB APPLICATION FIREWALL IS OFF: $WAF_OFF_WHY. Security > Web application firewall installs and turns it on."
  else
    echo "  The web application firewall (ModSecurity, OWASP Core Rule Set) is on and blocks what its rules flag. Security > Web application firewall."
  fi
  if [ -n "$SCAN_OFF_WHY" ]; then
    echo "  THE VIRUS SCANNER IS OFF: $SCAN_OFF_WHY. Security > Virus scanner."
  else
    echo "  The virus scanner (ClamAV) is on; its first signature download can take a few minutes. Security > Virus scanner."
  fi
  if [ "$FAMILY" != el ] && [ -n "$APPARMOR_OFF_WHY" ]; then
    echo "  APACHE AND PHP ARE NOT CONFINED: $APPARMOR_OFF_WHY."
  elif [ "$FAMILY" != el ]; then
    echo "  AppArmor confines Apache and PHP (freepanel-apache2, freepanel-php-fpm, enforce mode)."
  fi
fi
if [ "$OPEN_FIREWALL" -eq 0 ]; then
  if [ "$DBADMIN" -eq 1 ]; then
    echo "  Ports $PORT/tcp, $USER_PORT/tcp and $DBADMIN_PORT/tcp were not opened in the firewall. Re-run with --open-firewall, or open them yourself."
  else
    echo "  Ports $PORT/tcp and $USER_PORT/tcp were not opened in the firewall. Re-run with --open-firewall, or open them yourself."
  fi
  if [ -n "${SERVICE_PORTS:-}" ]; then
    echo "  The ports of the services you chose were not opened either: $SERVICE_PORTS."
  fi
fi

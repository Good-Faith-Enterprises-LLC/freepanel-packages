#!/bin/bash
# Points dnf (or apt, on Ubuntu) at freePanel's package repository as
# repo.conf names it, does
# nothing while repo.conf has it off, or takes it away from the server when
# repo.conf says withdrawn. The installer runs it on every run, so a new
# address, key or state in repo.conf reaches every server on its next run.
#
#   enable-repo.sh CONF KEYFILE
#
# CONF is repo.conf; KEYFILE the public key shipped with the release. Run
# as root. The checks on the key and the address are setup-repo.sh's (EL9)
# and setup-apt.sh's (Ubuntu 24.04, chosen when the server has apt and no dnf).
set -euo pipefail

CONF=${1:?usage: enable-repo.sh CONF KEYFILE}
KEYFILE=${2:?usage: enable-repo.sh CONF KEYFILE}
HERE=$(dirname "$(realpath "$0")")
SETUP=$HERE/setup-repo.sh
TOOL=dnf
if ! command -v dnf >/dev/null 2>&1 && command -v apt-get >/dev/null 2>&1; then
    SETUP=$HERE/setup-apt.sh
    TOOL=apt
fi

# One value from CONF, read as text (the file is never run).
value() {
    local v
    v=$(sed -n "s/^$1=//p" "$CONF" | tail -n 1)
    printf '%s' "${v%$'\r'}"
}

state=$(value enabled)
fpr=$(value fingerprint)
case "$state" in
    yes) ;;
    withdrawn)
        # An incident: servers that already use the repository stop.
        [ -n "$fpr" ] || { echo "repo.conf has no fingerprint" >&2; exit 1; }
        exec "$SETUP" --withdraw "$fpr"
        ;;
    *)
        echo "freePanel's package repository is off (repo.conf); $TOOL left as it is"
        exit 0
        ;;
esac
url=$(value url)
[ -n "$url" ] || { echo "repo.conf has no url" >&2; exit 1; }
[ -n "$fpr" ] || { echo "repo.conf has no fingerprint" >&2; exit 1; }
case "$url" in
    https://*) ;;
    *) echo "repo.conf's url must be https://" >&2; exit 1 ;;
esac
exec "$SETUP" "$KEYFILE" "$fpr" "$url"

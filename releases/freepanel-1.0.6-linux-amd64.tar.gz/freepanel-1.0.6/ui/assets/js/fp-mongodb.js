/* freePanel MongoDB (#/tool/mongodb_server), the admin panel's page for MongoDB (docs/api.md, "MongoDB"): MongoDB is not
   part of the base install. Here the admin installs it, choosing a series from the ones MongoDB's own repository offers for
   this server's release, or removes it; both run as a package job whose output the page follows. Both ask for the admin's
   password again. Once it is installed, accounts get their own MongoDB databases page. Everything the server says
   (versions, the job's output) is shown as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var POLL_MS = 3000;
  var MAX_LOG = 200;
  var SERIES_RE = /^[0-9]{1,2}\.[0-9]{1,2}$/;
  var STATES = ['idle', 'running', 'succeeded', 'failed'];
  var CARDS = ['fp-mdb-status', 'fp-mdb-job'];

  var S = null;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 400) : ''; }
  function obj(v) { return v && typeof v === 'object' ? v : {}; }
  function list(v) { return Array.isArray(v) ? v : []; }
  function when(iso) {
    var d = typeof iso === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(iso) ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }
  function cleanJob(j) {
    j = obj(j);
    return {state: STATES.indexOf(j.state) >= 0 ? j.state : 'idle', label: str(j.label, 64), started: str(j.started), ended: str(j.ended),
      exit: typeof j.exit_code === 'number' && isFinite(j.exit_code) ? Math.floor(j.exit_code) : null, timedOut: j.timed_out === true,
      log: list(j.log).filter(function (l) { return typeof l === 'string'; }).slice(-MAX_LOG).map(function (l) { return l.slice(0, 400); }),
      truncated: j.log_truncated === true};
  }
  function cleanStatus(r) {
    r = obj(r);
    return {installed: r.installed === true, series: SERIES_RE.test(str(r.series)) ? r.series : '', version: str(r.version, 40), running: r.running === true,
      error: str(r.error), os: str(r.os, 100), supported: r.supported === true, reason: str(r.reason),
      accounts: typeof r.accounts === 'number' && r.accounts >= 0 ? Math.floor(r.accounts) : 0, job: cleanJob(r.job)};
  }
  function busy() { return S.status.job.state === 'running'; }

  function passwordField(id) {
    return el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: id, text: t('mdb_password')}),
      el('input', {class: 'sig-input', id: id, name: 'current_password', type: 'password', autocomplete: 'current-password', maxlength: '1024',
        'aria-describedby': id + '-hint'}),
      el('span', {class: 'sig-hint', id: id + '-hint', text: t('mdb_password_hint')})]);
  }

  /* ---------- the cards ---------- */
  function statusCard() {
    var d = S.status;
    var parts = [M.errorLine(), M.statusLine()];
    if (d.installed) {
      parts.push(el('p', {'data-fp-mdb': 'installed', text: d.running ? t('mdb_running', {version: d.version || d.series}) : t('mdb_not_running', {series: d.series})}));
      if (!d.running && d.error) { parts.push(el('p', {class: 'fp-muted', text: d.error})); }
      parts.push(el('p', {class: 'fp-muted', text: t('mdb_local_only')}));
      parts.push(el('p', {class: 'fp-muted', 'data-fp-mdb-accounts': '', text: t('mdb_accounts', {n: String(d.accounts)})}));
      if (S.removing) {
        var form = el('form', {class: 'fp-form', novalidate: '', 'data-fp-form': 'remove'}, [
          el('p', {text: d.accounts ? t('mdb_remove_blocked') : t('mdb_remove_ask')}),
          passwordField('fp-mdb-rm-pw'),
          el('div', {class: 'fp-actions'}, [
            el('button', {class: 'sig-btn sig-btn--danger fp-submit', type: 'submit', text: t('mdb_remove'), disabled: busy()}),
            el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'cancel', text: t('cancel')})])]);
        parts.push(form);
      } else {
        parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'ask-remove',
          text: t('mdb_remove'), disabled: busy()})]));
      }
      return M.card('fp-mdb-status-h', t('mdb_title'), parts, 'fp-mdb-status');
    }
    parts.push(el('div', {class: 'fp-note fp-mdb-missing', 'data-fp-mdb': 'missing', text: t('mdb_missing')}));
    if (!d.supported) {
      parts.push(el('p', {'data-fp-unsupported': '', text: d.reason || t('mdb_unsupported')}));
      return M.card('fp-mdb-status-h', t('mdb_title'), parts, 'fp-mdb-status');
    }
    parts.push(el('p', {class: 'fp-muted', text: t('mdb_install_desc', {os: d.os})}));
    if (!S.versions) {
      parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'versions',
        text: t('mdb_install'), disabled: busy()})]));
      return M.card('fp-mdb-status-h', t('mdb_title'), parts, 'fp-mdb-status');
    }
    var select = el('select', {class: 'sig-input', id: 'fp-mdb-series', name: 'series', 'aria-describedby': 'fp-mdb-series-hint'},
      S.versions.series.map(function (v) {
        var o = el('option', {value: v, text: v === S.versions.def ? t('mdb_series_newest', {series: v}) : v});
        if (v === S.versions.def) { o.selected = true; }
        return o;
      }));
    parts.push(el('form', {class: 'fp-form', novalidate: '', 'data-fp-form': 'install'}, [
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: 'fp-mdb-series', text: t('mdb_series')}), select,
        el('span', {class: 'sig-hint', id: 'fp-mdb-series-hint', text: t('mdb_series_hint')})]),
      passwordField('fp-mdb-pw'),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('mdb_install'), disabled: busy()})])]));
    return M.card('fp-mdb-status-h', t('mdb_title'), parts, 'fp-mdb-status');
  }
  function jobCard() {
    var j = S.status.job;
    if (j.state === 'idle') { return null; }
    var parts = [M.errorLine(), M.statusLine()];
    var at = when(j.state === 'running' ? j.started : j.ended) || '—';
    var key = j.state === 'running' ? 'mdb_job_running' : (j.state === 'succeeded' ? 'mdb_job_ok' : 'mdb_job_failed');
    parts.push(el('p', {'data-fp-job': j.state, class: j.state === 'failed' ? 'fp-bk-bad' : '', text: t(key, {what: j.label, when: at})}));
    if (j.state === 'failed' && j.timedOut) { parts.push(el('p', {class: 'fp-muted', text: t('mdb_job_timeout')})); }
    if (j.log.length) {
      if (j.truncated) { parts.push(el('p', {class: 'fp-muted sig-hint', text: t('mdb_log_cut')})); }
      parts.push(el('pre', {class: 'fp-upd-log sig-mono', tabindex: '0', role: 'region', 'aria-label': t('mdb_log_label'), 'data-fp-log': '', text: j.log.join('\n')}));
    }
    return M.card('fp-mdb-job-h', t('mdb_job_title'), parts, 'fp-mdb-job');
  }
  var MAKERS = {'fp-mdb-status': statusCard, 'fp-mdb-job': jobCard};
  function draw(cls) {
    var old = S.page.querySelector('.' + cls);
    var fresh = MAKERS[cls]();
    if (!fresh) { if (old) { old.remove(); } return; }
    if (old) {
      old.replaceWith(fresh);
    } else {
      var later = null;
      for (var i = CARDS.indexOf(cls) + 1; i < CARDS.length && !later; i++) { later = S.page.querySelector('.' + CARDS[i]); }
      S.page.insertBefore(fresh, later);
    }
    var log = fresh.querySelector('[data-fp-log]');
    if (log) { log.scrollTop = log.scrollHeight; }
  }
  function drawAll() { CARDS.forEach(draw); }
  function say(cls, text) {
    var s = S.page.querySelector('.' + cls + ' [data-fp-status]');
    if (s) { s.textContent = text || ''; }
  }
  function fail(cls, err) { UI.showError(S.page.querySelector('.' + cls), err ? err.message : t('api_failed')); }

  /* ---------- actions ---------- */
  function loadVersions(b) {
    var mine = S;
    UI.setBusy(b, true);
    FP.call('get', 'mongoServerVersions').then(function (r) {
      if (S !== mine) { return; }
      r = obj(r);
      var series = list(r.series).filter(function (v) { return typeof v === 'string' && SERIES_RE.test(v); }).slice(0, 20);
      if (!series.length) { UI.setBusy(b, false); fail('fp-mdb-status', null); return; }
      mine.versions = {series: series, def: series.indexOf(r.default) >= 0 ? r.default : series[0]};
      draw('fp-mdb-status');
      var f = S.page.querySelector('#fp-mdb-series');
      if (f) { f.focus(); }
    }, function (err) {
      if (S !== mine) { return; }
      UI.setBusy(b, false);
      fail('fp-mdb-status', err);
    });
  }
  function submit(form, route, body, message) {
    var mine = S;
    var b = form.querySelector('.fp-submit');
    if (b.disabled) { return; }
    UI.showError(S.page.querySelector('.fp-mdb-status'), '');
    var pw = form.querySelector('[name="current_password"]');
    if (!pw.value) { pw.setAttribute('aria-invalid', 'true'); pw.focus(); fail('fp-mdb-status', {message: t('mdb_password_needed')}); return; }
    body.current_password = pw.value;
    UI.setBusy(b, true);
    FP.call('post', route, body).then(function (r) {
      if (S !== mine) { return; }
      mine.removing = false;
      mine.status.job = cleanJob(obj(r).job);
      drawAll();
      var h = S.page.querySelector('.fp-mdb-job .fp-h2');
      if (h) { h.focus(); }
      say('fp-mdb-job', message);
      poll();
    }, function (err) {
      if (S !== mine) { return; }
      UI.setBusy(b, false);
      pw.value = '';
      fail('fp-mdb-status', err);
    });
  }
  function poll() {
    window.clearTimeout(S.timer);
    var mine = S;
    mine.timer = window.setTimeout(function () {
      if (S !== mine || !document.body.contains(mine.page)) { return; }
      FP.call('get', 'mongoServer').then(function (r) {
        if (S !== mine) { return; }
        mine.status = cleanStatus(r);
        if (busy()) { draw('fp-mdb-job'); poll(); return; }
        mine.versions = null;
        drawAll();
        say('fp-mdb-job', t(mine.status.job.state === 'succeeded' ? 'mdb_ended_ok' : 'mdb_ended_bad'));
      }, function () { if (S === mine) { poll(); } });
    }, POLL_MS);
  }

  function onClick(e) {
    var target = e.target && e.target.closest ? e.target : null;
    var b = target && S && S.page && S.page.contains(target) ? target.closest('[data-fp-act]') : null;
    if (!b || b.disabled) { return; }
    var act = b.getAttribute('data-fp-act');
    if (act === 'versions') {
      loadVersions(b);
    } else if (act === 'ask-remove') {
      S.removing = true;
      draw('fp-mdb-status');
      var f = S.page.querySelector('#fp-mdb-rm-pw');
      if (f) { f.focus(); }
    } else if (act === 'cancel') {
      S.removing = false;
      draw('fp-mdb-status');
      var back = S.page.querySelector('[data-fp-act="ask-remove"]');
      if (back) { back.focus(); }
    }
  }
  function onSubmit(e) {
    var form = e.target;
    if (!S || !S.page || !S.page.contains(form)) { return; }
    var kind = form.getAttribute('data-fp-form');
    if (kind !== 'install' && kind !== 'remove') { return; }
    e.preventDefault();
    if (kind === 'install') {
      var series = String(form.querySelector('[name="series"]').value || '');
      if (!SERIES_RE.test(series)) { return; }
      submit(form, 'mongoServerInstall', {series: series}, t('mdb_started_install', {series: series}));
    } else {
      submit(form, 'mongoServerRemove', {}, t('mdb_started_remove'));
    }
  }
  document.addEventListener('click', onClick);
  document.addEventListener('submit', onSubmit);

  FP.view('tool:mongodb_server', function () {
    var tool = FP.tools.mongodb_server;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('mdb_desc'), cls: 'fp-mail fp-upd fp-mdb',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    if (S) { window.clearTimeout(S.timer); }
    S = {page: body, status: null, versions: null, removing: false, timer: 0};
    var mine = S;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'mongoServer').then(function (r) {
      if (S !== mine) { return; }
      mine.status = cleanStatus(r);
      body.textContent = '';
      drawAll();
      if (busy()) { poll(); }
    }, function (err) {
      if (S !== mine) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

/* freePanel databases (#/tool/mysql, #/tool/postgresql and #/tool/mongodb), the customer panel's pages for the account's MySQL,
   PostgreSQL and MongoDB databases (docs/api.md, "MySQL databases", "PostgreSQL databases" and "MongoDB"): make a database, make a user, give
   a user a database (MySQL with chosen privileges), change a user's password, and remove each. When the database admin
   tool is set up (feature dbadmin), "Manage databases" signs in to it in a new tab; #/tool/db_browser offers the same
   for each engine. Every name starts with the account's prefix, shown before the field. The database wizard (fp-dbwizard.js) is the
   first card: a database, its user and the user's access in one step. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;

  /* the two engines: their tool, the API's module name, the admin tool's engine, and name limits (docs/api.md) */
  var ENGINES = {
    mysql: {tool: 'mysql', api: 'mysql', signin: 'mysql', grants: true, maxDb: 64, maxUser: 32},
    postgresql: {tool: 'postgresql', api: 'postgres', signin: 'pgsql', grants: false, maxDb: 57, maxUser: 63},
    /* MongoDB, once the admin installed it: no wizard and no table checks (their routes are MySQL's and PostgreSQL's) */
    mongodb: {tool: 'mongodb', api: 'mongodb', signin: 'mongo', grants: false, maxDb: 63, maxUser: 63, simple: true}
  };
  var NAME_RE = /^[a-z][a-z0-9]{0,15}_[a-z0-9_]{1,80}$/;
  var PRIV_RE = /^[A-Z][A-Z ]{1,40}$/;
  /* a sign-in as signon.php takes it: ACCOUNT_fpa<8 hex>, 40 hex digits, posted to an https origin's signon.php */
  var SIGNIN_USER_RE = /^[a-z][a-z0-9]{0,15}_fpa[0-9a-f]{8}$/;
  var SIGNIN_PW_RE = /^[0-9a-f]{40}$/;
  /* a panel's own IPv4 address, other than loopback (a tunnel, where the tool keeps its name) */
  var IPV4_RE = /^(?!127\.)[0-9]{1,3}(\.[0-9]{1,3}){3}$/;
  var SIGNON_RE = /^https:\/\/[A-Za-z0-9.-]+(:[0-9]{1,5})?\/signon\.php$/;
  var ALL = 'ALL PRIVILEGES';

  var E = null;       /* the page's engine */
  var page = null;    /* the frame's body */
  var state = null;   /* the last list the server sent, cleaned */
  var account = '';
  var granting = null; /* {db, user} whose privileges the grant form is changing, or null */
  var passwordFor = '';  /* the user whose password form is open */

  function str(v) { return typeof v === 'string' ? v : ''; }
  function names(list) {
    return (Array.isArray(list) ? list : []).filter(function (n) { return typeof n === 'string' && NAME_RE.test(n); });
  }
  function privs(list) {
    return (Array.isArray(list) ? list : []).filter(function (p) { return typeof p === 'string' && PRIV_RE.test(p); });
  }
  function clean(v) {
    v = v && typeof v === 'object' ? v : {};
    var dbs = (Array.isArray(v.databases) ? v.databases : []).filter(function (d) { return d && NAME_RE.test(str(d.name)); }).map(function (d) {
      var users = (Array.isArray(d.users) ? d.users : []).map(function (u) {
        /* MySQL lists {user, privileges}; PostgreSQL lists names */
        return typeof u === 'string' ? {user: u, privileges: []} : {user: str(u && u.user), privileges: privs(u && u.privileges)};
      }).filter(function (u) { return NAME_RE.test(u.user); });
      return {name: d.name, size: typeof d.size_bytes === 'number' && isFinite(d.size_bytes) && d.size_bytes >= 0 ? d.size_bytes : null, users: users};
    });
    var users = (Array.isArray(v.users) ? v.users : []).filter(function (u) { return u && NAME_RE.test(str(u.name)); }).map(function (u) {
      return {name: u.name, databases: names(u.databases)};
    });
    var prefix = str(v.prefix) === account + '_' ? v.prefix : account + '_';
    return {prefix: prefix, databases: dbs, users: users, privileges: privs(v.privileges).filter(function (p) { return p !== ALL; })};
  }

  /* sizes the way hosting panels show them: binary steps named KB, MB, GB, TB */
  var UNITS = ['KB', 'MB', 'GB', 'TB', 'PB'];
  function size(n) {
    if (n === null) { return '—'; }
    if (n < 1024) { return t('size_bytes', {n: String(Math.round(n))}); }
    var u = -1;
    do { n /= 1024; u++; } while (n >= 1024 && u < UNITS.length - 1);
    return (n < 10 ? n.toFixed(1) : Math.round(n).toLocaleString('en')) + ' ' + UNITS[u];
  }

  function card(id, title, children, extra) {
    var head = el('div', {class: 'fp-db-head'}, [el('h2', {class: 'fp-h2', id: id, tabindex: '-1', text: title}), extra || null]);
    return el('section', {class: 'sig-card fp-db-card', 'aria-labelledby': id}, [el('div', {class: 'sig-card-body'}, [head].concat(children))]);
  }
  function errorLine() { return el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': ''}); }
  function statusLine() { return el('p', {class: 'fp-ok-line', role: 'status', 'data-fp-status': ''}); }
  function say(scope, text) {
    var s = scope && scope.querySelector('[data-fp-status]');
    if (s) { s.textContent = text || ''; }
  }
  function sayIn(cls, text) { say(page.querySelector('.' + cls), text); }
  function hintId(id) { return id + '-hint'; }
  /* a name field: the account's prefix as fixed text before what the customer types */
  function nameField(id, label, maxSuffix, hint) {
    return el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: id, text: label}),
      el('div', {class: 'fp-db-prefixed'}, [el('span', {class: 'fp-db-prefix sig-mono', 'aria-hidden': 'true', text: state.prefix}),
        el('input', {class: 'sig-input sig-mono', id: id, name: 'name', type: 'text', autocomplete: 'off', spellcheck: 'false',
          autocapitalize: 'none', maxlength: String(maxSuffix), 'aria-describedby': hintId(id)})]),
      el('span', {class: 'sig-hint', id: hintId(id), text: hint})]);
  }
  function passwordFields(id) {
    var eye = UI.icon(FP.ui, 'ui_eye');
    return [el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: id, text: t('label_password')}),
      el('div', {class: 'fp-reveal-wrap'}, [
        el('input', {class: 'sig-input', id: id, name: 'password', type: 'password', autocomplete: 'new-password', minlength: '12',
          maxlength: '1024', 'aria-describedby': hintId(id)}),
        el('button', {class: 'sig-ghost fp-reveal', type: 'button', 'data-overlap-ok': '', 'data-fp-reveal': id + ',' + id + '-again',
          'aria-pressed': 'false', 'aria-label': 'Show password'}, [eye])]),
      el('span', {class: 'sig-hint', id: hintId(id), text: E.signin === 'pgsql' || E.signin === 'mongo' ? t('db_password_hint_pg') : t('db_password_hint')})]),
    el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: id + '-again', text: t('db_password_again')}),
      el('input', {class: 'sig-input', id: id + '-again', name: 'again', type: 'password', autocomplete: 'new-password', maxlength: '1024'})]),
    el('div', {class: 'fp-db-gen'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'generate',
      'data-fp-for': id, text: t('db_generate')})])];
  }
  /* 20 characters a shell, a URL and PostgreSQL all take as they are */
  var GEN = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789-_.+=';
  function generate() {
    var out = '';
    var buf = new Uint8Array(1);
    while (out.length < 20) {
      window.crypto.getRandomValues(buf);
      if (buf[0] < 256 - (256 % GEN.length)) { out += GEN.charAt(buf[0] % GEN.length); }
    }
    return out;
  }

  /* an error line and the field it is about: the field is marked and focused, and the page scrolls so the line shows */
  function fieldError(form, f, message) {
    UI.showError(form, message);
    if (f) {
      f.setAttribute('aria-invalid', 'true');
      f.focus({preventScroll: true});
    }
    var line = form.querySelector('[data-fp-error]');
    if (line && line.scrollIntoView) { line.scrollIntoView({block: 'nearest'}); }
  }
  function failed(form, err) {
    var f = err && err.field ? UI.fieldNamed(form, err.field) : null;
    var label = f ? form.querySelector('label[for="' + f.id + '"]') : null;
    fieldError(form, f, (label ? label.textContent + ': ' : '') + (err ? err.message : t('api_failed')));
  }
  function start(form) {
    var b = form.querySelector('.fp-submit');
    if (b.disabled) { return null; }
    UI.showError(form, '');
    say(form, '');
    var bad = form.querySelectorAll('[aria-invalid]');
    for (var i = 0; i < bad.length; i++) { bad[i].removeAttribute('aria-invalid'); }
    return b;
  }
  /* the suffix typed after the prefix: lowercase letters, digits and underscores, the whole name within max */
  function checkName(form, max, what) {
    var f = form.querySelector('[name="name"]');
    var v = f.value.trim().toLowerCase();
    if (v.indexOf(state.prefix) === 0) { v = v.slice(state.prefix.length); }
    if (!v) { fieldError(form, f, t('db_need_name', {what: what})); return null; }
    if (!/^[a-z0-9_]+$/.test(v)) { fieldError(form, f, t('db_bad_name')); return null; }
    if ((state.prefix + v).length > max) { fieldError(form, f, t('db_long_name', {n: max - state.prefix.length})); return null; }
    return state.prefix + v;
  }
  function checkPassword(form) {
    var p = form.querySelector('[name="password"]');
    var a = form.querySelector('[name="again"]');
    if (p.value.length < 12) { fieldError(form, p, t('db_short_password')); return null; }
    if ((E.signin === 'pgsql' || E.signin === 'mongo') && !/^[\x20-\x7e]+$/.test(p.value)) { fieldError(form, p, t('db_ascii_password')); return null; }
    if (p.value !== a.value) { fieldError(form, a, t('db_password_mismatch')); return null; }
    return p.value;
  }
  function call(method, path, body, arg) {
    return FP.call(method, E.api + path, body, Object.assign({name: account}, arg || {}));
  }
  /* after a change: the list again, then the page drawn with a status line in the card the change belongs to */
  function reload(cls, text, focusId) {
    return call('get', '', undefined).then(function (r) {
      state = clean(r);
      render();
      sayIn(cls, text);
      var h = focusId && page.querySelector('#' + focusId);
      if (h) { h.focus(); }
    }, function (err) {
      page.textContent = '';
      page.appendChild(FP.empty(FP.tools[E.tool].label, err.message));
    });
  }

  /* ---- the database admin tool ---- */
  function hasAdminTool() { return Boolean(FP.session && Array.isArray(FP.session.features) && FP.session.features.indexOf('dbadmin') >= 0); }
  /* a sign-in from the server, posted as a top-level form to the tool in a new tab. The tab opens on the click, so no
     pop-up blocker stops it, and is closed again if the sign-in fails. */
  function openAdminTool(engine, button, scope) {
    var target = 'fp-dbadmin-' + Math.random().toString(36).slice(2);
    var w = window.open('about:blank', target);
    UI.showError(scope, '');
    say(scope, '');
    UI.setBusy(button, true);
    FP.call('post', engine.api + 'Signin', {}, account).then(function (r) {
      UI.setBusy(button, false);
      var url = str(r && r.signon_url);
      var user = str(r && r.user);
      var pw = str(r && r.password);
      if (!SIGNON_RE.test(url) || !SIGNIN_USER_RE.test(user) || !SIGNIN_PW_RE.test(pw) || str(r.engine) !== engine.signin) {
        if (w) { w.close(); }
        UI.showError(scope, url ? t('api_failed') : t('db_manage_off'));
        return;
      }
      /* a panel opened at one of the server's IPv4 addresses (before its name resolves, or on a LAN) reaches the tool at that same
         address: the name may not lead to this server from here. The tool and the panel's policy accept it (signon.php). */
      if (IPV4_RE.test(window.location.hostname)) { url = url.replace(/^https:\/\/[A-Za-z0-9.-]+/, 'https://' + window.location.hostname); }
      var form = el('form', {method: 'post', action: url, target: w ? target : '_blank', hidden: true}, [
        el('input', {type: 'hidden', name: 'engine', value: engine.signin}),
        el('input', {type: 'hidden', name: 'user', value: user}),
        el('input', {type: 'hidden', name: 'password', value: pw})]);
      document.body.appendChild(form);
      form.submit();
      form.parentNode.removeChild(form);
      say(scope, t('db_manage_opened'));
    }, function (err) {
      if (w) { w.close(); }
      UI.setBusy(button, false);
      UI.showError(scope, err.message);
    });
  }
  function manageButton(engine, label) {
    return el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'manage', 'data-fp-engine': engine.tool},
      [el('span', {text: label}), UI.icon(FP.ui, 'ui_external', 'sig-ext'), el('span', {class: 'sig-vh', text: ' ' + t('opens_new')})]);
  }

  /* ---- make a database ---- */
  function createDbCard() {
    var form = el('form', {class: 'fp-form', novalidate: ''}, [errorLine(), statusLine(),
      nameField('fp-db-new', t('db_new_name'), E.maxDb - state.prefix.length, t('db_name_hint', {prefix: state.prefix})),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('db_create')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = start(form);
      if (!b) { return; }
      var name = checkName(form, E.maxDb, t('db_what_database'));
      if (!name) { return; }
      UI.setBusy(b, true);
      call('post', 'Databases', {name: name}).then(function () {
        reload('fp-db-list', t('db_created', {name: name}), 'fp-db-list-h');
      }, function (err) {
        UI.setBusy(b, false);
        failed(form, err);
      });
    });
    var node = card('fp-db-new-h', t('db_create_title'), [form]);
    node.classList.add('fp-db-create');
    return node;
  }

  /* ---- the databases ---- */
  function privilegeText(u) {
    if (!E.grants) { return ''; }
    if (u.privileges.indexOf(ALL) >= 0 || !u.privileges.length) { return t('db_all_privileges'); }
    return u.privileges.join(', ');
  }
  function dbUsers(d) {
    if (!d.users.length) { return [el('span', {class: 'fp-muted', text: t('db_no_users')})]; }
    return [el('ul', {class: 'fp-db-grants'}, d.users.map(function (u) {
      return el('li', {'data-fp-grant': u.user}, [
        el('span', {class: 'fp-db-grant-who'}, [el('b', {class: 'sig-mono', text: u.user}),
          E.grants ? el('span', {class: 'fp-muted fp-db-privs', text: privilegeText(u)}) : null]),
        el('span', {class: 'fp-db-grant-acts'}, [
          E.grants ? el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'privileges',
            'aria-label': t('db_privileges_of', {user: u.user, db: d.name}), text: t('db_privileges')}) : null,
          el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'revoke',
            'aria-label': t('db_revoke_of', {user: u.user, db: d.name}), text: t('db_revoke')})])]);
    }))];
  }
  function listCard() {
    var parts = [errorLine(), statusLine()];
    if (!state.databases.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('db_none')}));
    } else {
      var head = el('tr', null, [el('th', {scope: 'col', text: t('db_col_database')}), el('th', {scope: 'col', class: 'fp-num', text: t('db_col_size')}),
        el('th', {scope: 'col', text: t('db_col_users')}), el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('db_col_actions')})])]);
      var rows = state.databases.map(function (d) {
        return el('tr', {'data-fp-db': d.name}, [el('th', {scope: 'row', class: 'sig-mono', text: d.name}),
          el('td', {class: 'fp-num', text: size(d.size)}), el('td', null, dbUsers(d)),
          el('td', {class: 'fp-db-acts'}, [E.simple ? null : el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'maintain',
            'aria-label': t(E.api === 'mysql' ? 'dbm_open_of' : 'dbm_open_pg_of', {name: d.name}), text: t(E.api === 'mysql' ? 'dbm_open' : 'dbm_open_pg')}),
            el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button',
            'data-fp-act': 'remove-db', 'aria-label': t('db_remove_of', {name: d.name}), text: t('db_remove')})])]);
      });
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-db-list-h'}, [
        el('table', {class: 'sig-table fp-db-table'}, [el('thead', null, [head]), el('tbody', null, rows)])]));
    }
    var node = card('fp-db-list-h', t('db_list_title'), parts, hasAdminTool() ? manageButton(E, t('db_manage')) : null);
    node.classList.add('fp-db-list');
    return node;
  }

  /* ---- make a user ---- */
  function createUserCard() {
    var form = el('form', {class: 'fp-form', novalidate: ''}, [errorLine(), statusLine(),
      nameField('fp-db-user-new', t('db_user_name'), E.maxUser - state.prefix.length, t('db_name_hint', {prefix: state.prefix}))]
      .concat(passwordFields('fp-db-user-pw'), [el('div', {class: 'fp-actions'}, [
        el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('db_user_create')})])]));
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = start(form);
      if (!b) { return; }
      var name = checkName(form, E.maxUser, t('db_what_user'));
      var pw = name && checkPassword(form);
      if (!pw) { return; }
      UI.setBusy(b, true);
      call('post', 'Users', {name: name, password: pw}).then(function () {
        reload('fp-db-users', t('db_user_created', {name: name}), 'fp-db-users-h');
      }, function (err) {
        UI.setBusy(b, false);
        failed(form, err);
      });
    });
    var node = card('fp-db-user-new-h', t('db_user_create_title'), [form]);
    node.classList.add('fp-db-user-create');
    return node;
  }

  /* ---- give a user a database ---- */
  function select(id, label, options, value) {
    return el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: id, text: label}),
      el('select', {class: 'sig-select', id: id, name: id === 'fp-db-grant-user' ? 'user' : 'database'},
        [el('option', {value: '', text: t('db_pick')})].concat(options.map(function (o) {
          var opt = el('option', {value: o, text: o});
          if (o === value) { opt.selected = true; }
          return opt;
        })))]);
  }
  function privilegeBoxes(current) {
    var all = current.indexOf(ALL) >= 0 || !current.length;
    var boxes = [el('label', {class: 'fp-check fp-check--all'}, [el('input', {type: 'checkbox', name: 'all', checked: all ? '' : null}),
      el('span', {text: t('db_all_privileges')})])];
    var list = el('div', {class: 'fp-db-privgrid'}, state.privileges.map(function (p) {
      return el('label', {class: 'fp-check'}, [el('input', {type: 'checkbox', name: 'privilege', value: p,
        checked: all || current.indexOf(p) >= 0 ? '' : null}), el('span', {class: 'sig-mono', text: p})]);
    }));
    return el('fieldset', {class: 'fp-db-privs-set'}, [el('legend', {class: 'sig-label', text: t('db_privileges')})].concat(boxes, [list]));
  }
  function grantCard() {
    var g = granting;
    var current = [];
    if (g) {
      state.databases.forEach(function (d) {
        if (d.name === g.db) { d.users.forEach(function (u) { if (u.user === g.user) { current = u.privileges; } }); }
      });
    }
    var parts = [errorLine(), statusLine()];
    if (!state.users.length || !state.databases.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-grant-none': '', text: t('db_grant_need')}));
      return card('fp-db-grant-h', t('db_grant_title'), [el('div', {class: 'fp-form'}, parts)]);
    }
    parts.push(el('div', {class: 'fp-db-pair'}, [
      select('fp-db-grant-user', t('db_col_user'), state.users.map(function (u) { return u.name; }), g ? g.user : ''),
      select('fp-db-grant-db', t('db_col_database'), state.databases.map(function (d) { return d.name; }), g ? g.db : '')]));
    if (E.grants) { parts.push(privilegeBoxes(g ? current : [ALL])); }
    parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit',
      text: g ? t('db_grant_save') : t('db_grant_add')}),
    g ? el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'cancel-grant', text: t('cancel')}) : null]));
    var form = el('form', {class: 'fp-form', novalidate: ''}, parts);
    form.addEventListener('change', function (e) {
      if (e.target.name === 'all') {
        var boxes = form.querySelectorAll('[name="privilege"]');
        for (var i = 0; i < boxes.length; i++) { boxes[i].checked = e.target.checked; }
      } else if (e.target.name === 'privilege') {
        var every = form.querySelectorAll('[name="privilege"]:not(:checked)').length === 0;
        form.querySelector('[name="all"]').checked = every;
      }
    });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = start(form);
      if (!b) { return; }
      var u = form.querySelector('[name="user"]');
      var d = form.querySelector('[name="database"]');
      if (!u.value) { fieldError(form, u, t('db_pick_user')); return; }
      if (!d.value) { fieldError(form, d, t('db_pick_database')); return; }
      var body;
      if (E.grants) {
        var chosen = [];
        var boxes = form.querySelectorAll('[name="privilege"]:checked');
        for (var i = 0; i < boxes.length; i++) { chosen.push(boxes[i].value); }
        if (form.querySelector('[name="all"]').checked) { chosen = [ALL]; }
        if (!chosen.length) { fieldError(form, form.querySelector('[name="all"]'), t('db_pick_privilege')); return; }
        body = {privileges: chosen};
      }
      UI.setBusy(b, true);
      var user = u.value;
      var db = d.value;
      call('put', 'Grant', body, {db: db, user: user}).then(function () {
        var changed = Boolean(granting);
        granting = null;
        reload('fp-db-list', changed ? t('db_grant_saved', {user: user, db: db}) : t('db_granted', {user: user, db: db}), 'fp-db-list-h');
      }, function (err) {
        UI.setBusy(b, false);
        failed(form, err);
      });
    });
    var node = card('fp-db-grant-h', g ? t('db_grant_edit_title', {user: g.user, db: g.db}) : t('db_grant_title'), [form]);
    node.classList.add('fp-db-grant');
    return node;
  }

  /* ---- the users ---- */
  function passwordRow(name) {
    var form = el('form', {class: 'fp-form fp-db-pwform', novalidate: ''}, [errorLine(),
      el('p', {class: 'fp-muted', text: t('db_password_for', {user: name})})].concat(passwordFields('fp-db-pw'), [
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('db_password_save')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'cancel-password', text: t('cancel')})])]));
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = start(form);
      if (!b) { return; }
      var pw = checkPassword(form);
      if (!pw) { return; }
      UI.setBusy(b, true);
      call('put', 'Password', {password: pw}, {user: name}).then(function () {
        passwordFor = '';
        render();
        sayIn('fp-db-users', t('db_password_changed', {user: name}));
        var back = page.querySelector('tr[data-fp-user="' + name + '"] [data-fp-act="password"]');
        if (back) { back.focus(); }
      }, function (err) {
        UI.setBusy(b, false);
        failed(form, err);
      });
    });
    return el('tr', {class: 'fp-db-pwrow'}, [el('td', {colspan: '3'}, [form])]);
  }
  function usersCard() {
    var parts = [errorLine(), statusLine()];
    if (!state.users.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('db_users_none')}));
    } else {
      var head = el('tr', null, [el('th', {scope: 'col', text: t('db_col_user')}), el('th', {scope: 'col', text: t('db_col_databases')}),
        el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('db_col_actions')})])]);
      var rows = [];
      state.users.forEach(function (u) {
        rows.push(el('tr', {'data-fp-user': u.name}, [el('th', {scope: 'row', class: 'sig-mono', text: u.name}),
          el('td', {class: 'sig-mono', text: u.databases.length ? u.databases.join(', ') : ''}, u.databases.length ? null :
            [el('span', {class: 'fp-muted', text: t('db_user_no_dbs')})]),
          el('td', {class: 'fp-db-acts'}, [
            el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'password',
              'aria-label': t('db_password_of', {user: u.name}), 'aria-expanded': String(passwordFor === u.name), text: t('db_password')}),
            el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'remove-user',
              'aria-label': t('db_remove_of', {name: u.name}), text: t('db_remove')})])]));
        if (passwordFor === u.name) { rows.push(passwordRow(u.name)); }
      });
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-db-users-h'}, [
        el('table', {class: 'sig-table fp-db-table fp-db-users-table'}, [el('thead', null, [head]), el('tbody', null, rows)])]));
    }
    var node = card('fp-db-users-h', t('db_users_title'), parts);
    node.classList.add('fp-db-users');
    return node;
  }

  /* ---- remove: a confirmation in place of the row's buttons ---- */
  function confirmIn(cell, question, act) {
    cell.textContent = '';
    var yes = el('button', {class: 'sig-btn sig-btn--danger sig-btn--sm', type: 'button', 'data-fp-act': act, text: t('db_remove')});
    cell.appendChild(el('span', {class: 'fp-db-confirm', id: 'fp-db-confirm', text: question}));
    cell.appendChild(yes);
    var no = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'confirm-no', text: t('cancel')});
    cell.appendChild(no);
    yes.setAttribute('aria-describedby', 'fp-db-confirm');
    no.setAttribute('aria-describedby', 'fp-db-confirm');
    no.focus();
  }
  function act(button, scopeCls, fn, okText, focusId) {
    var scope = page.querySelector('.' + scopeCls);
    UI.showError(scope, '');
    UI.setBusy(button, true);
    fn().then(function () {
      reload(scopeCls, okText, focusId);
    }, function (err) {
      UI.setBusy(button, false);
      UI.showError(scope, err.message);
    });
  }

  function onClick(e) {
    var target = e.target.closest ? e.target : null;
    if (!target || !page || !page.contains(target)) { return; }
    var b = target.closest('[data-fp-act]');
    if (!b) { return; }
    var a = b.getAttribute('data-fp-act');
    var tr = b.closest('tr');
    var li = b.closest('li');
    var db = tr ? tr.getAttribute('data-fp-db') : '';
    var user = tr ? tr.getAttribute('data-fp-user') : '';
    /* the wizard's buttons (data-fp-act="dbw-...") are only on the engines' pages, where E and state are set */
    if (a.indexOf('dbw-') === 0) {
      if (FP.dbWizard && E && state) { FP.dbWizard.click(wizardCtx(), b); }
      return;
    }
    if (a === 'manage') {
      openAdminTool(ENGINES[b.getAttribute('data-fp-engine')], b, b.closest('section'));
    } else if (a === 'generate') {
      var form = b.closest('form');
      var pw = generate();
      var id = b.getAttribute('data-fp-for');
      var p = form.querySelector('#' + id);
      var again = form.querySelector('#' + id + '-again');
      p.value = pw;
      again.value = pw;
      p.type = 'text';
      again.type = 'text';
      var eye = form.querySelector('[data-fp-reveal]');
      if (eye && eye.getAttribute('aria-pressed') !== 'true') { eye.click(); }
      UI.announce(t('db_generated'));
      p.focus();
      p.select();
    } else if (a === 'maintain') {
      FP.dbMaint.open(maintCtx(), db);
    } else if (a === 'maint-close') {
      FP.dbMaint.close(maintCtx());
    } else if (a === 'remove-db') {
      confirmIn(b.parentNode, t('db_remove_db_ask', {name: db}), 'remove-db-yes');
    } else if (a === 'remove-db-yes') {
      act(b, 'fp-db-list', function () { return call('del', 'Database', undefined, {db: db}); }, t('db_removed_db', {name: db}), 'fp-db-list-h');
    } else if (a === 'remove-user') {
      confirmIn(b.parentNode, t('db_remove_user_ask', {name: user}), 'remove-user-yes');
    } else if (a === 'remove-user-yes') {
      if (passwordFor === user) { passwordFor = ''; }
      act(b, 'fp-db-users', function () { return call('del', 'User', undefined, {user: user}); }, t('db_removed_user', {name: user}), 'fp-db-users-h');
    } else if (a === 'revoke') {
      var who = li.getAttribute('data-fp-grant');
      confirmIn(b.parentNode, t('db_revoke_ask', {user: who, db: db}), 'revoke-yes');
    } else if (a === 'revoke-yes') {
      var u = li.getAttribute('data-fp-grant');
      if (granting && granting.db === db && granting.user === u) { granting = null; }
      act(b, 'fp-db-list', function () { return call('del', 'Grant', undefined, {db: db, user: u}); }, t('db_revoked', {user: u, db: db}), 'fp-db-list-h');
    } else if (a === 'confirm-no') {
      var back = li ? '[data-fp-grant="' + li.getAttribute('data-fp-grant') + '"] [data-fp-act="revoke"]' : (db ? '[data-fp-act="remove-db"]' : '[data-fp-act="remove-user"]');
      var key = db ? 'tr[data-fp-db="' + db + '"] ' : 'tr[data-fp-user="' + user + '"] ';
      render();
      var again2 = page.querySelector(key + back);
      if (again2) { again2.focus(); }
    } else if (a === 'privileges') {
      granting = {db: db, user: li.getAttribute('data-fp-grant')};
      render();
      page.querySelector('#fp-db-grant-h').focus();
    } else if (a === 'cancel-grant') {
      /* back to the Privileges button the keys came from */
      var closing = granting;
      granting = null;
      render();
      var opener = closing ? page.querySelector('tr[data-fp-db="' + window.CSS.escape(closing.db) + '"] [data-fp-grant="' + window.CSS.escape(closing.user) + '"] [data-fp-act="privileges"]') : null;
      (opener || page.querySelector('#fp-db-grant-h')).focus();
    } else if (a === 'password') {
      passwordFor = passwordFor === user ? '' : user;
      render();
      var f = passwordFor ? page.querySelector('#fp-db-pw') : page.querySelector('tr[data-fp-user="' + user + '"] [data-fp-act="password"]');
      if (f) { f.focus(); }
    } else if (a === 'cancel-password') {
      var was = passwordFor;
      passwordFor = '';
      render();
      var pb = page.querySelector('tr[data-fp-user="' + was + '"] [data-fp-act="password"]');
      if (pb) { pb.focus(); }
    }
  }
  document.addEventListener('click', onClick);

  /* what the check and repair card (fp-dbmaint.js) needs of this page */
  function maintCtx() {
    return {engine: E.api, page: page, call: call, render: render, has: function (n) { return state.databases.some(function (d) { return d.name === n; }); }};
  }
  /* what the database wizard (fp-dbwizard.js) needs of this page */
  function wizardCtx() {
    return {engine: E.api, prefix: state.prefix, privileges: state.privileges, maxDb: E.maxDb, maxUser: E.maxUser, empty: !state.databases.length,
      page: page, call: call, render: render, refresh: function (focusId, text) { return reload('fp-dbw', text, focusId); }};
  }
  function render() {
    page.textContent = '';
    if (FP.dbWizard && !E.simple) { page.appendChild(FP.dbWizard.card(wizardCtx())); }
    page.appendChild(createDbCard());
    page.appendChild(listCard());
    var maint = FP.dbMaint && !E.simple ? FP.dbMaint.card(maintCtx()) : null;
    if (maint) { page.appendChild(maint); }
    page.appendChild(createUserCard());
    page.appendChild(grantCard());
    page.appendChild(usersCard());
  }

  function show(engine) {
    var tool = FP.tools[engine.tool];
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    E = engine;
    account = FP.account();
    granting = null;
    passwordFor = '';
    if (FP.dbMaint) { FP.dbMaint.reset(); }
    if (FP.dbWizard) { FP.dbWizard.reset(); }
    page = FP.frame({title: tool.label, desc: t(engine.tool === 'mysql' ? 'db_desc_mysql' : (engine.tool === 'mongodb' ? 'db_desc_mongo' : 'db_desc_pg')), cls: 'fp-db',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    var mine = page;
    call('get', '', undefined).then(function (r) {
      if (page !== mine) { return; }
      state = clean(r);
      render();
    }, function (err) {
      if (page !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err.message));
    });
  }
  FP.view('tool:mysql', function () { show(ENGINES.mysql); });
  FP.view('tool:postgresql', function () { show(ENGINES.postgresql); });
  FP.view('tool:mongodb', function () { show(ENGINES.mongodb); });

  /* ---- the database admin tool's own page: one button per engine the account has ---- */
  FP.view('tool:db_browser', function () {
    var tool = FP.tools.db_browser;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    account = FP.account();
    page = FP.frame({title: tool.label, desc: t('db_browser_desc'), cls: 'fp-db',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    var engines = ['mysql', 'postgresql', 'mongodb'].filter(function (k) { return FP.tools[k]; });
    var body = [errorLine(), statusLine()];
    if (!engines.length) {
      body.push(el('p', {class: 'fp-muted', text: t('db_browser_none')}));
    } else {
      body.push(el('div', {class: 'fp-actions fp-db-open'}, engines.map(function (k) {
        return manageButton(ENGINES[k], t(k === 'mysql' ? 'db_open_mysql' : (k === 'mongodb' ? 'db_open_mongo' : 'db_open_pg')));
      })));
    }
    page.appendChild(card('fp-db-browser-h', t('db_browser_title'), body));
  });
})();

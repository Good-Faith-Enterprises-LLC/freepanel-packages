/* freePanel services (#/tool/service_manager), the admin panel's page for the services freePanel installs (docs/api.md,
   "Server"): each one's state, and a way to restart it, stop or start it, and choose whether it starts with the server.
   The services come from the server's own list; the panel names one only by the name it was given there. freePanel's own
   two services are shown and not changed (the server refuses them), and a stop is asked about first, with what stops. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;
  var S = FP.services;

  var UNIT_RE = /^[a-z0-9][a-z0-9@.-]{0,63}$/;
  var V = null;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 64) : ''; }
  function cleanList(r) {
    return (r && Array.isArray(r.services) ? r.services : []).filter(function (v) { return v && typeof v.unit === 'string' && UNIT_RE.test(v.unit); })
      .map(function (v) { return {unit: v.unit, load: str(v.load, 32), active: str(v.active, 32), enabled: str(v.enabled, 32), own: v.protected === true}; });
  }
  function find(unit) {
    for (var i = 0; i < V.list.length; i++) { if (V.list[i].unit === unit) { return V.list[i]; } }
    return null;
  }
  function name(unit) { return S.label(unit); }
  function stateWord(v) {
    var s = S.state(v);
    return s ? t(s[1]) : (v.active || '—');
  }
  /* what stops with a service, for the question before it is stopped */
  function effect(unit) {
    var php = /^php(\d)(\d)-php-fpm$/.exec(unit) || /^php(\d)\.(\d)-fpm$/.exec(unit);
    if (php) { return t('sv_fx_php', {v: php[1] + '.' + php[2]}); }
    /* Ubuntu's names for the same services (internal/platform) */
    if (unit === 'apache2') { unit = 'httpd'; } else if (unit === 'postfix@-') { unit = 'postfix'; }
    var k = 'sv_fx_' + (/^postgresql@/.test(unit) ? 'postgresql' : unit.replace(/-/g, '_'));
    return t(k) === k ? t('sv_fx_other') : t(k);
  }

  function button(act, text, label, unit, slot, cls) {
    return el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm' + (cls ? ' ' + cls : ''), type: 'button', 'data-fp-act': act, 'data-fp-slot': slot,
      'data-fp-unit': unit, 'aria-label': label, text: text});
  }
  /* the buttons of one row, each in a slot that stays put when the button changes (Stop becomes Start), so focus can stay on it */
  function actions(v) {
    if (v.own) { return [el('span', {class: 'fp-muted fp-sv-note', text: t('sv_own')})]; }
    if (v.load !== 'loaded') { return [el('span', {class: 'fp-muted fp-sv-note', text: t('sv_blocked')})]; }
    var n = name(v.unit);
    var btns = [button('restart', t('sv_restart'), t('sv_restart_of', {name: n}), v.unit, 'restart')];
    if (S.up(v)) {
      btns.push(button('stop', t('sv_stop'), t('sv_stop_of', {name: n}), v.unit, 'power', 'fp-btn-danger-text'));
    } else {
      btns.push(button('start', t('sv_start'), t('sv_start_of', {name: n}), v.unit, 'power'));
    }
    if (v.enabled === 'enabled') {
      btns.push(button('boot-off', t('sv_boot_off'), t('sv_boot_off_of', {name: n}), v.unit, 'boot', 'fp-btn-danger-text'));
    } else if (v.enabled === 'disabled') {
      btns.push(button('boot-on', t('sv_boot_on'), t('sv_boot_on_of', {name: n}), v.unit, 'boot'));
    }
    return [el('div', {class: 'fp-sv-btns'}, btns)];
  }
  function row(v) {
    var s = S.state(v);
    return el('tr', {'data-fp-service': v.unit}, [
      el('th', {scope: 'row'}, [el('span', {class: 'fp-srv-name', text: name(v.unit)}), el('span', {class: 'sig-mono fp-muted fp-srv-unit', text: v.unit})]),
      el('td', null, [s ? el('span', {class: 'sig-pill' + (s[0] ? ' sig-pill--' + s[0] : ''), 'data-fp-state': '', text: t(s[1])}) : el('span', {text: v.active || '—'})]),
      el('td', {text: S.boot(v) || '—'}),
      el('td', {class: 'fp-sv-acts'}, actions(v))]);
  }

  function summary() {
    var down = V.list.filter(function (v) { return !S.up(v); }).length;
    return el('p', {class: 'fp-srv-sum' + (down ? ' fp-srv-sum-down' : ''), 'data-fp-sum': '',
      text: down ? t(down === 1 ? 'svc_down_1' : 'svc_down', {n: down, total: V.list.length}) : t(V.list.length === 1 ? 'svc_all_up_1' : 'svc_all_up', {n: V.list.length})});
  }
  function listCard() {
    var parts = [el('p', {class: 'fp-muted', text: t('sv_what')}), M.errorLine(), M.statusLine()];
    if (!V.list.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('svc_none')}));
    } else {
      parts.push(summary(), el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'refresh', text: t('status_again')})]),
        el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-sv-h'}, [
          el('table', {class: 'sig-table fp-mail-table fp-srv-table fp-sv-table'}, [el('thead', null, [el('tr', null, [
            el('th', {scope: 'col', text: t('svc_service')}), el('th', {scope: 'col', text: t('svc_state')}), el('th', {scope: 'col', text: t('svc_boot')}),
            el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('acct_actions')})])])]),
          el('tbody', null, V.list.map(row))])]));
    }
    return M.card('fp-sv-h', t('sv_title'), parts, 'fp-sv');
  }
  function draw(focus) {
    var old = V.page.querySelector('.fp-sv');
    var made = listCard();
    if (old) { old.replaceWith(made); } else { V.page.appendChild(made); }
    var target = focus ? V.page.querySelector(focus) : null;
    if (target) { target.focus(); }
  }
  function slotOf(unit, slot) { return '[data-fp-service="' + unit + '"] [data-fp-slot="' + slot + '"]'; }
  function card() { return V.page.querySelector('.fp-sv'); }

  function load() {
    var mine = V;
    return FP.call('get', 'serverServices').then(function (r) {
      if (V !== mine) { return null; }
      V.list = cleanList(r);
      return V.list;
    });
  }
  /* while one change runs, no other starts: the server does one at a time. The list is drawn again when it ends, with its buttons free. */
  function lock(on) {
    V.busy = on;
    if (!on) { return; }
    var all = V.page.querySelectorAll('.fp-sv-btns button, [data-fp-act="refresh"]');
    for (var i = 0; i < all.length; i++) { all[i].disabled = true; }
  }

  var DONE = {restart: 'sv_done_restart', start: 'sv_done_start', stop: 'sv_done_stop', enable: 'sv_done_enable', disable: 'sv_done_disable'};
  var DOING = {restart: 'sv_doing_restart', start: 'sv_doing_start', stop: 'sv_doing_stop', enable: 'sv_doing_enable', disable: 'sv_doing_disable'};
  /* what the answer says: said or trouble, in words */
  function outcome(action, unit, got) {
    var n = name(unit);
    var v = got && typeof got === 'object' && got.unit === unit ? {unit: unit, load: str(got.load, 32), active: str(got.active, 32), enabled: str(got.enabled, 32)} : null;
    if (!v) { return {said: t(DONE[action], {name: n})}; }
    if ((action === 'start' || action === 'restart') && !S.up(v)) {
      return v.active === 'activating' ? {said: t('sv_starting', {name: n})} : {trouble: t('sv_not_up', {name: n, state: stateWord(v)})};
    }
    if (action === 'stop' && S.up(v)) { return {trouble: t('sv_still_up', {name: n})}; }
    return {said: t(DONE[action], {name: n})};
  }
  function change(unit, action, b, slot) {
    var mine = V;
    var n = name(unit);
    lock(true);
    UI.setBusy(b, true);
    UI.showError(card(), '');
    M.say(card(), t(DOING[action], {name: n}));
    FP.call('post', 'serviceAction', {unit: unit, action: action}).then(function (r) {
      if (V !== mine) { return; }
      var o = outcome(action, unit, r && r.service);
      /* the list is read again: a service another depends on changes with it */
      return load().then(function () {
        if (V !== mine) { return; }
        draw(slotOf(unit, slot));
        lock(false);
        M.say(card(), o.said || '');
        if (o.trouble) { UI.showError(card(), o.trouble); }
      }, function () {
        if (V !== mine) { return; }
        var v = r && r.service && find(unit);
        if (v) { v.active = str(r.service.active, 32); v.enabled = str(r.service.enabled, 32); }
        draw(slotOf(unit, slot));
        lock(false);
        M.say(card(), o.said || '');
        if (o.trouble) { UI.showError(card(), o.trouble); }
      });
    }, function (err) {
      if (V !== mine) { return; }
      /* what the server refused is said in its words, and the list is read again so it shows what is true now */
      load().then(function () {}, function () {}).then(function () {
        if (V !== mine) { return; }
        draw(find(unit) ? slotOf(unit, slot) : '#fp-sv-h');
        lock(false);
        M.say(card(), '');
        UI.showError(card(), err && err.message ? err.message : t('api_failed'));
      });
    });
  }

  var ASK = {stop: ['sv_ask_stop', 'sv_stop_yes', 'stop-yes'], 'boot-off': ['sv_ask_boot', 'sv_boot_off', 'boot-off-yes']};
  function onClick(e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !V || !V.page.contains(b) || b.disabled) { return; }
    var a = b.getAttribute('data-fp-act');
    var tr = b.closest('tr[data-fp-service]');
    var unit = tr ? tr.getAttribute('data-fp-service') : '';
    if (a === 'refresh') {
      if (V.busy) { return; }
      UI.setBusy(b, true);
      var mine = V;
      load().then(function () {
        if (V !== mine) { return; }
        draw('[data-fp-act="refresh"]');
        M.say(card(), t('status_checked', {when: new Date().toLocaleTimeString('en', {timeStyle: 'short'})}));
      }, function (err) {
        if (V !== mine) { return; }
        UI.setBusy(b, false);
        UI.showError(card(), err.message);
        b.focus();
      });
      return;
    }
    if (!unit || V.busy) { return; }
    var v = find(unit);
    if (!v) { return; }
    var slot = b.getAttribute('data-fp-slot') || '';
    if (a === 'restart') { change(unit, 'restart', b, slot); } else if (a === 'start') { change(unit, 'start', b, slot); } else if (a === 'boot-on') { change(unit, 'enable', b, slot); } else if (ASK[a]) {
      var holder = b.closest('.fp-sv-btns');
      holder.setAttribute('data-fp-from', slot);
      M.confirmIn(holder, t(ASK[a][0], {name: name(unit), effect: effect(unit)}), ASK[a][2], t(ASK[a][1]));
    } else if (a === 'stop-yes') {
      change(unit, 'stop', b, 'power');
    } else if (a === 'boot-off-yes') {
      change(unit, 'disable', b, 'boot');
    } else if (a === 'confirm-no') {
      var from = b.closest('.fp-sv-btns').getAttribute('data-fp-from');
      var cell = tr.querySelector('.fp-sv-acts');
      cell.textContent = '';
      actions(v).forEach(function (n) { cell.appendChild(n); });
      var back = cell.querySelector('[data-fp-slot="' + from + '"]');
      if (back) { back.focus(); }
    }
  }
  document.addEventListener('click', onClick);

  FP.view('tool:service_manager', function () {
    var tool = FP.tools.service_manager;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('sv_desc'), cls: 'fp-mail fp-srv fp-sv-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    V = {page: page, list: [], busy: false};
    var mine = V;
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    load().then(function () {
      if (V !== mine) { return; }
      page.textContent = '';
      draw();
    }, function (err) {
      if (V !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

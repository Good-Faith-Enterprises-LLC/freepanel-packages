/* freePanel staff logins (docs/api.md, "Staff and roles", /staff, /staff/roles): the admin panel's page (#/tool/staff) where the
   server admin makes logins for staff and roles that open only some parts of this panel. Staff logins: add one, change its role,
   address or password, turn it off or on, reset its two-factor, remove it. Roles: add one, set read or change for each area, remove
   one no login holds. A change that gives more access asks for the admin's own password, as the API does. The server admin's own
   login only. Everything the server sends is shown as text. The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var USER_RE = /^[a-z][a-z0-9]{0,15}$/;
  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 200) : ''; }
  function id(v) { return typeof v === 'number' && isFinite(v) && v > 0 ? Math.floor(v) : 0; }
  function level(v) { return v === 'read' || v === 'write' ? v : ''; }

  function cleanLogin(x) {
    if (!x || !USER_RE.test(str(x.username))) { return null; }
    return {username: x.username, email: str(x.email, 254), roleId: id(x.role_id), role: str(x.role, 40), disabled: x.disabled === true,
      twoFactor: x.two_factor === true};
  }
  function cleanRole(x) {
    if (!x || !id(x.id)) { return null; }
    var perms = {};
    if (x.perms && typeof x.perms === 'object') { Object.keys(x.perms).forEach(function (k) { if (level(x.perms[k])) { perms[k] = x.perms[k]; } }); }
    return {id: id(x.id), name: str(x.name, 40), description: str(x.description, 200), perms: perms, logins: id(x.logins)};
  }
  function cleanArea(x) { return x && /^[a-z0-9_]{1,40}$/.test(str(x.id)) ? {id: x.id, label: str(x.label, 80), description: str(x.description, 400)} : null; }

  var S = {page: null, staff: [], roles: [], areas: [], limit: 50, rolesLimit: 30, open: '', busy: false};

  function read(r) {
    r = r && typeof r === 'object' ? r : {};
    S.staff = (Array.isArray(r.staff) ? r.staff : []).map(cleanLogin).filter(Boolean);
    S.roles = (Array.isArray(r.roles) ? r.roles : []).map(cleanRole).filter(Boolean);
    S.areas = (Array.isArray(r.areas) ? r.areas : []).map(cleanArea).filter(Boolean);
    S.limit = id(r.limit) || 50;
    S.rolesLimit = id(r.roles_limit) || 30;
  }
  function reload(note, where, focus) {
    var mine = S.page;
    return FP.call('get', 'staff').then(function (r) {
      if (S.page !== mine) { return; }
      read(r);
      render();
      if (note && where) { M.say(S.page.querySelector(where), note); }
      var f = focus && S.page.querySelector(focus);
      if (f) { f.focus(); }
    });
  }

  function roleSelect(fid, current) {
    var s = el('select', {class: 'sig-input', id: fid, name: 'role_id'}, [el('option', {value: '0', text: t('stf_no_role')})].concat(
      S.roles.map(function (r) { return el('option', {value: String(r.id), text: r.name}); })));
    s.value = String(current || 0);
    return s;
  }
  function pwField(fid, name, label, hint, auto) {
    return M.field(fid, label, el('input', {class: 'sig-input', id: fid, name: name, type: 'password', autocomplete: auto || 'new-password', maxlength: '1024'}), hint);
  }
  function mineField(fid) { return pwField(fid, 'current_password', t('stf_your_password'), t('stf_your_password_hint'), 'current-password'); }

  /* sends a form's call; the answer re-reads the page */
  function send(f, method, name, body, arg, note, where, focus) {
    var b = M.start(f);
    if (!b || S.busy) { return; }
    S.busy = true;
    UI.setBusy(b, true);
    var mine = S.page;
    FP.call(method, name, body, arg).then(function () {
      S.busy = false;
      if (S.page !== mine) { return; }
      S.open = '';
      return reload(note, where, focus);
    }).catch(function (err) {
      S.busy = false;
      if (S.page !== mine) { return; }
      UI.setBusy(b, false);
      if (err && err.code === 'forbidden' && f.querySelector('[name="current_password"]')) { err = {message: err.message, field: 'current_password'}; }
      M.failed(f, err);
    });
  }
  function value(f, n) { var x = f.querySelector('[name="' + n + '"]'); return x ? x.value : ''; }
  function actions(label) {
    return el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: label}),
      el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'stf-cancel', text: t('cancel')})]);
  }

  /* ---- staff logins ---- */
  function addLoginForm() {
    var f = el('form', {class: 'fp-form fp-stf-form', novalidate: '', 'data-fp-stf-form': 'new-login'}, [M.errorLine(), M.statusLine(),
      M.field('fp-stf-user', t('stf_username'), el('input', {class: 'sig-input sig-mono', id: 'fp-stf-user', name: 'username', type: 'text', autocomplete: 'off',
        spellcheck: 'false', autocapitalize: 'none', maxlength: '16'}), t('stf_username_hint')),
      pwField('fp-stf-pw', 'password', t('stf_password'), null),
      M.field('fp-stf-email', t('stf_email'), el('input', {class: 'sig-input', id: 'fp-stf-email', name: 'email', type: 'email', autocomplete: 'off', maxlength: '254'}),
        t('stf_email_hint')),
      M.field('fp-stf-role', t('stf_role'), roleSelect('fp-stf-role', 0)),
      mineField('fp-stf-mine'), actions(t('stf_add_login'))]);
    f.addEventListener('submit', function (e) {
      e.preventDefault();
      var u = value(f, 'username').trim().toLowerCase();
      if (!USER_RE.test(u)) { M.fieldError(f, f.querySelector('[name="username"]'), t('stf_bad_username')); return; }
      if (!value(f, 'password')) { M.fieldError(f, f.querySelector('[name="password"]'), t('stf_need_password')); return; }
      if (!value(f, 'current_password')) { M.fieldError(f, f.querySelector('[name="current_password"]'), t('stf_need_mine')); return; }
      send(f, 'post', 'staff', {username: u, password: value(f, 'password'), email: value(f, 'email').trim(), role_id: Number(value(f, 'role_id')),
        current_password: value(f, 'current_password')}, undefined, t('stf_added', {name: u}), '.fp-stf-logins', '[data-fp-act="stf-login-change"][data-fp-who="' + u + '"]');
    });
    return M.card('fp-stf-form-h', t('stf_add_login_title'), [f], 'fp-stf-formcard');
  }
  function changeLoginForm(l) {
    var on = el('select', {class: 'sig-input', id: 'fp-stf-on', name: 'disabled'}, [el('option', {value: 'false', text: t('stf_on')}),
      el('option', {value: 'true', text: t('stf_off')})]);
    on.value = l.disabled ? 'true' : 'false';
    var email = el('input', {class: 'sig-input', id: 'fp-stf-email', name: 'email', type: 'email', autocomplete: 'off', maxlength: '254'});
    email.value = l.email;
    var tf = el('input', {type: 'checkbox', id: 'fp-stf-2fa', name: 'reset_two_factor'});
    var f = el('form', {class: 'fp-form fp-stf-form', novalidate: '', 'data-fp-stf-form': l.username}, [M.errorLine(), M.statusLine(),
      M.field('fp-stf-role', t('stf_role'), roleSelect('fp-stf-role', l.roleId)),
      M.field('fp-stf-email', t('stf_email'), email, t('stf_email_hint')),
      pwField('fp-stf-pw', 'password', t('stf_new_password'), t('stf_new_password_hint')),
      M.field('fp-stf-on', t('stf_state'), on),
      l.twoFactor ? el('div', {class: 'sig-field fp-stf-check'}, [tf, el('label', {for: 'fp-stf-2fa', text: t('stf_reset_2fa')})]) : null,
      mineField('fp-stf-mine'), actions(t('stf_save'))]);
    f.addEventListener('submit', function (e) {
      e.preventDefault();
      var body = {};
      var role = Number(value(f, 'role_id'));
      if (role !== l.roleId) { body.role_id = role; }
      var em = value(f, 'email').trim();
      if (em !== l.email) { body.email = em; }
      if (value(f, 'password')) { body.password = value(f, 'password'); }
      var off = value(f, 'disabled') === 'true';
      if (off !== l.disabled) { body.disabled = off; }
      if (tf.checked) { body.reset_two_factor = true; }
      if (value(f, 'current_password')) { body.current_password = value(f, 'current_password'); }
      if (!Object.keys(body).filter(function (k) { return k !== 'current_password'; }).length) {
        M.fieldError(f, f.querySelector('[name="role_id"]'), t('stf_nothing'));
        return;
      }
      send(f, 'patch', 'staffLogin', body, l.username, t('stf_saved', {name: l.username}), '.fp-stf-logins',
        '[data-fp-act="stf-login-change"][data-fp-who="' + l.username + '"]');
    });
    return M.card('fp-stf-form-h', t('stf_change_title', {name: l.username}), [f], 'fp-stf-formcard');
  }
  function loginRow(l) {
    return el('tr', {'data-fp-login': l.username}, [el('th', {scope: 'row', class: 'sig-mono', text: l.username}),
      el('td', {text: l.email || '—'}), el('td', {text: l.roleId ? l.role : t('stf_no_role')}),
      el('td', {text: l.twoFactor ? t('stf_2fa_on') : t('stf_2fa_off')}),
      el('td', null, [el('span', {class: 'sig-pill' + (l.disabled ? ' sig-pill--warn' : ''), text: l.disabled ? t('stf_off') : t('stf_on')})]),
      el('td', {class: 'fp-stf-acts'}, [
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'stf-login-change', 'data-fp-who': l.username,
          'aria-label': t('stf_change_for', {name: l.username}), text: t('stf_change')}),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'stf-login-remove', 'data-fp-who': l.username,
          'aria-label': t('stf_remove_for', {name: l.username}), text: t('stf_remove')})])]);
  }
  function loginsCard() {
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t('stf_logins_what')})];
    if (!S.staff.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('stf_no_logins')}));
    } else {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-stf-logins-h'}, [
        el('table', {class: 'sig-table fp-stf-table'}, [el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('stf_username')}),
          el('th', {scope: 'col', text: t('stf_email')}), el('th', {scope: 'col', text: t('stf_role')}), el('th', {scope: 'col', text: t('stf_2fa')}),
          el('th', {scope: 'col', text: t('stf_state')}), el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]),
        el('tbody', null, S.staff.map(loginRow))])]));
    }
    parts.push(el('div', {class: 'fp-actions'}, [S.staff.length < S.limit ? el('button', {class: 'sig-btn sig-btn--primary', type: 'button',
      'data-fp-act': 'stf-login-add', text: t('stf_add_login')}) : el('p', {class: 'fp-muted', text: t('stf_at_limit', {n: S.limit})})]));
    return M.card('fp-stf-logins-h', t('stf_logins_title'), parts, 'fp-stf-logins');
  }

  /* ---- roles ---- */
  function roleForm(r) {
    var name = el('input', {class: 'sig-input', id: 'fp-stf-rname', name: 'name', type: 'text', autocomplete: 'off', maxlength: '40'});
    var desc = el('input', {class: 'sig-input', id: 'fp-stf-rdesc', name: 'description', type: 'text', autocomplete: 'off', maxlength: '200'});
    name.value = r ? r.name : '';
    desc.value = r ? r.description : '';
    var rows = S.areas.map(function (a) {
      var s = el('select', {class: 'sig-input', id: 'fp-stf-area-' + a.id, 'data-fp-area': a.id}, [el('option', {value: '', text: t('stf_none')}),
        el('option', {value: 'read', text: t('stf_read')}), el('option', {value: 'write', text: t('stf_write')})]);
      s.value = r && r.perms[a.id] ? r.perms[a.id] : '';
      return el('div', {class: 'sig-field fp-stf-area'}, [el('label', {class: 'sig-label', for: s.id, text: a.label || a.id}), s,
        a.description ? el('span', {class: 'sig-hint', text: a.description}) : null]);
    });
    var f = el('form', {class: 'fp-form fp-stf-form', novalidate: '', 'data-fp-stf-form': r ? 'role-' + r.id : 'new-role'}, [M.errorLine(), M.statusLine(),
      M.field('fp-stf-rname', t('stf_role_name'), name), M.field('fp-stf-rdesc', t('stf_role_desc'), desc),
      el('fieldset', {class: 'fp-stf-areas'}, [el('legend', {class: 'sig-label', text: t('stf_areas')}), el('p', {class: 'fp-muted', text: t('stf_areas_what')})].concat(rows)),
      r ? mineField('fp-stf-mine') : null, actions(r ? t('stf_save') : t('stf_add_role'))]);
    f.addEventListener('submit', function (e) {
      e.preventDefault();
      var n = name.value.trim();
      if (!/^[A-Za-z0-9 ._&-]{1,40}$/.test(n)) { M.fieldError(f, name, t('stf_bad_role_name')); return; }
      var perms = {};
      f.querySelectorAll('[data-fp-area]').forEach(function (s) { if (s.value) { perms[s.getAttribute('data-fp-area')] = s.value; } });
      var body = {name: n, description: desc.value.trim(), perms: perms};
      if (r && value(f, 'current_password')) { body.current_password = value(f, 'current_password'); }
      if (r) {
        send(f, 'patch', 'staffRole', body, String(r.id), t('stf_role_saved', {name: n}), '.fp-stf-roles', '[data-fp-act="stf-role-change"][data-fp-who="' + r.id + '"]');
      } else {
        send(f, 'post', 'staffRoles', body, undefined, t('stf_role_added', {name: n}), '.fp-stf-roles', '#fp-stf-roles-h');
      }
    });
    return M.card('fp-stf-form-h', r ? t('stf_role_change_title', {name: r.name}) : t('stf_add_role_title'), [f], 'fp-stf-formcard');
  }
  function areaLabel(aid) {
    for (var i = 0; i < S.areas.length; i++) { if (S.areas[i].id === aid) { return S.areas[i].label || aid; } }
    return aid;
  }
  function roleRow(r) {
    var keys = Object.keys(r.perms);
    return el('tr', {'data-fp-role': String(r.id)}, [el('th', {scope: 'row'}, [el('span', {text: r.name}),
      r.description ? el('span', {class: 'fp-muted fp-stf-sub', text: r.description}) : null]),
    el('td', {class: 'fp-stf-opens', text: keys.length ? keys.map(function (k) { return areaLabel(k) + ' (' + (r.perms[k] === 'write' ? t('stf_write') : t('stf_read')).toLowerCase() + ')'; }).join(', ') : t('stf_nothing_open')}),
    el('td', {class: 'fp-num', text: String(r.logins)}),
    el('td', {class: 'fp-stf-acts'}, [
      el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'stf-role-change', 'data-fp-who': String(r.id),
        'aria-label': t('stf_change_for', {name: r.name}), text: t('stf_change')}),
      r.logins ? null : el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'stf-role-remove', 'data-fp-who': String(r.id),
        'data-fp-name': r.name, 'aria-label': t('stf_remove_for', {name: r.name}), text: t('stf_remove')})])]);
  }
  function rolesCard() {
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t('stf_roles_what')})];
    if (!S.roles.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('stf_no_roles')}));
    } else {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-stf-roles-h'}, [
        el('table', {class: 'sig-table fp-stf-table'}, [el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('stf_role')}),
          el('th', {scope: 'col', text: t('stf_opens')}), el('th', {scope: 'col', class: 'fp-num', text: t('stf_logins_n')}),
          el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]),
        el('tbody', null, S.roles.map(roleRow))])]));
    }
    parts.push(el('div', {class: 'fp-actions'}, [S.roles.length < S.rolesLimit ? el('button', {class: 'sig-btn sig-btn--secondary', type: 'button',
      'data-fp-act': 'stf-role-add', text: t('stf_add_role')}) : el('p', {class: 'fp-muted', text: t('stf_roles_at_limit', {n: S.rolesLimit})})]));
    return M.card('fp-stf-roles-h', t('stf_roles_title'), parts, 'fp-stf-roles');
  }

  function render() {
    var page = S.page;
    page.textContent = '';
    page.appendChild(el('p', {class: 'fp-muted', text: t('stf_what')}));
    var o = S.open;
    if (o === 'new-login') { page.appendChild(addLoginForm()); }
    if (o === 'new-role') { page.appendChild(roleForm(null)); }
    if (o.indexOf('login:') === 0) {
      var l = S.staff.filter(function (x) { return 'login:' + x.username === o; })[0];
      if (l) { page.appendChild(changeLoginForm(l)); }
    }
    if (o.indexOf('role:') === 0) {
      var r = S.roles.filter(function (x) { return 'role:' + x.id === o; })[0];
      if (r) { page.appendChild(roleForm(r)); }
    }
    page.appendChild(loginsCard());
    page.appendChild(rolesCard());
  }

  function openForm(what) {
    S.open = what;
    render();
    var h = S.page.querySelector('#fp-stf-form-h');
    if (h) { h.focus(); }
  }
  function remove(b, method, name, arg, note, where) {
    S.busy = true;
    UI.setBusy(b, true);
    var mine = S.page;
    FP.call(method, name, undefined, arg).then(function () {
      S.busy = false;
      if (S.page !== mine) { return; }
      return reload(note, where, where + ' h2');
    }).catch(function (err) {
      S.busy = false;
      if (S.page !== mine) { return; }
      render();
      UI.showError(S.page.querySelector(where), err.message);
    });
  }

  document.addEventListener('click', function (e) {
    var node = e.target.closest ? e.target : null;
    var b = node && node.closest('[data-fp-act]');
    if (!b || !S.page || !S.page.contains(b) || S.busy) { return; }
    var a = b.getAttribute('data-fp-act');
    var who = b.getAttribute('data-fp-who') || '';
    var cell;
    if (a === 'stf-login-add') { openForm('new-login'); }
    else if (a === 'stf-role-add') { openForm('new-role'); }
    else if (a === 'stf-login-change') { openForm('login:' + who); }
    else if (a === 'stf-role-change') { openForm('role:' + who); }
    else if (a === 'stf-cancel') {
      S.open = '';
      render();
      var h = S.page.querySelector('#fp-stf-logins-h');
      if (h) { h.focus(); }
    } else if (a === 'stf-login-remove') {
      cell = b.parentNode;
      M.confirmIn(cell, t('stf_remove_ask', {name: who}), 'stf-login-remove-yes', t('stf_remove'));
      cell.querySelector('[data-fp-act="stf-login-remove-yes"]').setAttribute('data-fp-who', who);
    } else if (a === 'stf-role-remove') {
      cell = b.parentNode;
      M.confirmIn(cell, t('stf_remove_role_ask', {name: b.getAttribute('data-fp-name') || ''}), 'stf-role-remove-yes', t('stf_remove'));
      cell.querySelector('[data-fp-act="stf-role-remove-yes"]').setAttribute('data-fp-who', who);
    } else if (a === 'stf-login-remove-yes') {
      remove(b, 'del', 'staffLogin', who, t('stf_removed', {name: who}), '.fp-stf-logins');
    } else if (a === 'stf-role-remove-yes') {
      remove(b, 'del', 'staffRole', who, t('stf_role_removed'), '.fp-stf-roles');
    } else if (a === 'confirm-no') {
      render();
    }
  });

  FP.view('tool:staff', function () {
    var tool = FP.tools.staff;
    var u = FP.session.user;
    if (!tool || FP.realm !== 'admin' || u.role !== 'admin' || u.staff) { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    S.open = '';
    S.busy = false;
    var body = FP.frame({title: tool.label, desc: t('stf_desc'), cls: 'fp-mail fp-srv fp-stf-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    S.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    reload('', '', '').catch(function (err) {
      if (S.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

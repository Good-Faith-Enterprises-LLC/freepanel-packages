/* freePanel Terminal (#/tool/terminal), the customer panel's shell in the browser (docs/api.md, "Terminal"). The page drives the account's own
   login shell with plain HTTP: keystrokes go to .../input, the screen comes from a long poll of .../output, and a size change goes to
   .../resize. The screen is drawn by xterm.js (vendored, loaded here when the page is first used, as a script and a stylesheet of the panel's
   own origin). Its <style> elements are the three the policy names by hash (docs/api.md, "Content-Security-Policy"): they are only the same
   text if the terminal's options below, and the one Terminal made for the life of the page, stay as they are.
   What a program writes is drawn by xterm.js as text, never as markup; the only link it may open is an http or https one, after asking. A
   terminal is closed when the page is left. Paste and typing are bounded here (MAX_PASTE, MAX_QUEUE) as well as by the server. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var ID_RE = /^[0-9a-f]{32}$/;
  var MAX_PASTE = 256 * 1024;   /* characters of one paste */
  var MAX_QUEUE = 512 * 1024;   /* bytes waiting to be sent: more than this is dropped */
  var CHUNK = 32 * 1024;        /* bytes of one input call; the server takes 64 KiB */
  var POLL_WAIT = '20';         /* seconds a poll waits for output, at most 25 */
  var MIN_GAP = 400;            /* a poll that comes back at once with nothing is not asked again for this long */
  var RETRY = [1000, 2000, 4000, 8000, 10000];
  /* One font and one set of colours, whatever the panel's theme: the terminal is dark in both, and its stylesheets must be the same text each
     time (see the top of this file). */
  var FONT = 'ui-monospace, SFMono-Regular, Menlo, Consolas, "Liberation Mono", monospace';
  var THEME = {
    background: '#15171c', foreground: '#e4e6eb', cursor: '#ffb020', cursorAccent: '#15171c', selectionBackground: '#4a4030', selectionForeground: '#ffffff',
    black: '#2b2f38', red: '#ff7a6b', green: '#58e1a6', yellow: '#ffd166', blue: '#7aa7ff', magenta: '#d69bff', cyan: '#5fd7e6', white: '#d8dbe2',
    brightBlack: '#8b93a3', brightRed: '#ff9b8f', brightGreen: '#86f0c0', brightYellow: '#ffe08f', brightBlue: '#a3c2ff', brightMagenta: '#e6b8ff',
    brightCyan: '#8ee9f2', brightWhite: '#ffffff'
  };
  /* what a paste may not carry: C0 control characters but tab, carriage return and line feed (an ESC among them could end a bracketed paste early),
     DEL, and the C1 ones, which some terminals read as the start of a sequence */
  var PASTE_STRIP = /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f-\u009f]/g; // eslint-disable-line no-control-regex -- the point of it
  /* the colour changes a program may ask for (OSC 4, 10, 11, 12, their resets and the other colour slots): xterm.js would write the text of its
     stylesheet again, a text the policy has no hash for, so they are taken and ignored */
  var OSC_COLOURS = [4, 10, 11, 12, 17, 19, 104, 110, 111, 112, 117, 119];
  /* the only style a script may set as an attribute (below): a colour of a cell, as xterm.js writes them */
  var CELL_COLOUR = /^(color|background-color):\s*(#[0-9a-fA-F]{3,8}|rgba?\(\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}\s*(,\s*[01]?(\.\d+)?\s*)?\))$/;
  var X = {term: null, fit: null, host: null, loading: null, bound: false};
  var G = {page: null, account: '', state: 'loading', id: '', next: 0, token: 0, shell: 'normal', suspended: false, earlier: [], sent: null,
    queue: [], queued: 0, sending: false, retry: 0, observer: null, sizeTimer: 0, notice: ''};

  function str(v, n) { return typeof v === 'string' ? v.replace(/[\u0000-\u0008\u000b-\u001f\u007f؜‎‏‪-‮⁦-⁩]/g, '').slice(0, n || 300) : ''; } // eslint-disable-line no-control-regex -- text from the server is shown without control or direction characters
  function num(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.floor(v) : 0; }
  function when(iso) {
    var d = iso ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString(undefined, {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }
  function here() { return Boolean(G.page && G.page.isConnected); }
  /* the API path of the terminal this page drives: an account's, or root's (#/tool/root_terminal, the server admin's alone) */
  function K(key) { return G.root ? 'root' + key.charAt(0).toUpperCase() + key.slice(1) : key; }
  function hash() { return G.root ? '#/tool/root_terminal' : '#/tool/terminal'; }
  function live(token) { return token === G.token && here() && (G.state === 'live' || G.state === 'reconnecting'); }
  function q(sel) { return G.page.querySelector(sel); }

  /* ---- what the server sends, checked before it is used ---- */
  function cleanInfo(v) {
    if (!v || typeof v !== 'object' || !ID_RE.test(str(v.id, 40))) { return null; }
    return {id: v.id, opened: str(v.opened, 40), rows: num(v.rows), cols: num(v.cols)};
  }
  function cleanList(v) {
    var list = v && typeof v === 'object' && Array.isArray(v.terminals) ? v.terminals : null;
    return list ? list.slice(0, 10).map(cleanInfo).filter(Boolean) : null;
  }
  function cleanOutput(v) {
    if (!v || typeof v !== 'object' || typeof v.data !== 'string' || v.data.length > 3 * 1024 * 1024 || typeof v.next !== 'number' || !(v.next >= 0)) { return null; }
    var bytes;
    try {
      var bin = window.atob(v.data);
      bytes = new Uint8Array(bin.length);
      for (var i = 0; i < bin.length; i++) { bytes[i] = bin.charCodeAt(i); }
    } catch (e) { return null; }
    return {data: bytes, next: Math.floor(v.next), lost: v.lost === true, closed: v.closed === true, exit: str(v.exit, 200)};
  }
  /* the bytes of a string as UTF-8, base64 */
  function b64(bytes) {
    var out = '';
    for (var i = 0; i < bytes.length; i += 8192) { out += String.fromCharCode.apply(null, bytes.subarray(i, i + 8192)); }
    return window.btoa(out);
  }

  /* ---- xterm.js, loaded on first use ---- */
  function version() {
    var s = document.querySelector('script[src*="/assets/js/fp-terminal.js"]');
    var m = s && /[?&]v=([0-9a-f]{6,16})/.exec(s.getAttribute('src'));
    return m ? '?v=' + m[1] : '';
  }
  function loadScript(src) {
    return new Promise(function (resolve, reject) {
      var s = document.createElement('script');
      s.src = src;
      s.onload = function () { resolve(); };
      s.onerror = function () { s.remove(); reject(new Error('script')); };
      document.head.appendChild(s);
    });
  }
  function loadStyle(href) {
    return new Promise(function (resolve, reject) {
      var l = document.createElement('link');
      l.rel = 'stylesheet';
      l.href = href;
      l.onload = function () { resolve(); };
      l.onerror = function () { l.remove(); reject(new Error('style')); };
      document.head.appendChild(l);
    });
  }
  function assets() {
    if (window.Terminal && window.FitAddon) { return Promise.resolve(); }
    if (!X.loading) {
      var v = version();
      X.loading = Promise.all([loadStyle('/assets/css/xterm.css' + v),
        loadScript('/assets/js/vendor/xterm.js' + v).then(function () { return loadScript('/assets/js/vendor/xterm-addon-fit.js' + v); })]).then(function () {
        if (!window.Terminal || !window.FitAddon) { throw new Error('missing'); }
      }, function (err) { X.loading = null; throw err; });
    }
    return X.loading;
  }
  /* an address a program asks to open: http and https only, and only after the person says yes. The question names the host and shows the
     address as the browser reads it (a direction mark in it comes out percent-encoded), never the text the program wrote. */
  function linkHandler() {
    return {allowNonHttpProtocols: false, activate: function (e, url) {
      var u;
      try { u = new window.URL(String(url)); } catch (err) { return; }
      if ((u.protocol !== 'http:' && u.protocol !== 'https:') || !u.host) { return; }
      if (window.confirm(t('term_link_ask', {host: str(u.host, 120), url: str(u.href, 300)}))) { window.open(u.href, '_blank', 'noopener,noreferrer'); }
    }};
  }

  /* xterm.js colours a cell that has a true colour, or a colour it made readable, with a style attribute that it writes with setAttribute('style', ...),
     which the policy (style-src without 'unsafe-inline') blocks. The same declarations are set one by one through the style object, which the policy
     allows: it is what the page's own scripts do everywhere else. Only a script's own call that sets nothing but cell colours (CELL_COLOUR: a colour as
     a hex or rgb value) is changed; anything else goes to the browser as it was, which the policy refuses, and a style attribute in markup stays blocked. */
  function allowStyleCalls() {
    if (X.bound) { return; }
    X.bound = true;
    var set = window.Element.prototype.setAttribute;
    window.Element.prototype.setAttribute = function (name, value) {
      if (String(name).toLowerCase() !== 'style') { return set.apply(this, arguments); }
      var decls = String(value).split(';').map(function (d) { return d.trim(); }).filter(Boolean);
      if (!decls.length || !decls.every(function (d) { return CELL_COLOUR.test(d); })) { return set.apply(this, arguments); }
      this.removeAttribute('style');
      decls.forEach(function (decl) {
        var at = decl.indexOf(':');
        this.style.setProperty(decl.slice(0, at).trim(), decl.slice(at + 1).trim());
      }, this);
      return undefined;
    };
  }
  /* the one Terminal of the page's life, moved into the screen of each visit */
  function makeTerm() {
    allowStyleCalls();
    var term = new window.Terminal({cursorBlink: true, fontFamily: FONT, fontSize: 14, lineHeight: 1.2, scrollback: 5000, theme: THEME, minimumContrastRatio: 4.5,
      linkHandler: linkHandler(), allowProposedApi: false});
    var fit = new window.FitAddon.FitAddon();
    term.loadAddon(fit);
    OSC_COLOURS.forEach(function (n) { term.parser.registerOscHandler(n, function () { return true; }); });
    X.term = term;
    X.fit = fit;
    X.host = el('div', {class: 'fp-term-host'});
    term.onData(function (s) { sendBytes(new window.TextEncoder().encode(s)); });
    term.onBinary(function (s) {
      var b = new Uint8Array(s.length);
      for (var i = 0; i < s.length; i++) { b[i] = s.charCodeAt(i) & 255; }
      sendBytes(b);
    });
    /* Ctrl+M (which is Enter to a shell, and Enter works as before) leaves the screen for the buttons above it, so Tab is not a trap */
    term.attachCustomKeyEventHandler(function (e) {
      if (e.type === 'keydown' && e.ctrlKey && !e.altKey && !e.metaKey && !e.shiftKey && (e.key === 'm' || e.key === 'M')) {
        e.preventDefault();
        var b = q('.fp-term-bar button');
        if (b) { b.focus(); }
        return false;
      }
      return true;
    });
    /* A paste is taken by the page and never by xterm.js's own handler: its control characters are taken out (xterm.js wraps a paste in ESC [ 200 ~ and
       ESC [ 201 ~ for a shell that asked for it, and does not take an ESC out of the text, so one in the clipboard would end the bracket early and
       the rest would be typed, Enter and all), it is counted in bytes, which is what is sent, and bounded; then xterm.js is handed the text. */
    X.host.addEventListener('paste', function (e) {
      e.preventDefault();
      e.stopPropagation();
      var text = e.clipboardData ? e.clipboardData.getData('text/plain') : '';
      var clean = String(text).replace(PASTE_STRIP, '');
      var bytes = new window.TextEncoder().encode(clean).length;
      if (bytes > MAX_PASTE) {
        notice(t('term_paste_big', {size: Math.ceil(bytes / 1024).toLocaleString('en'), max: Math.round(MAX_PASTE / 1024).toLocaleString('en')}));
        return;
      }
      if (clean) { X.term.paste(clean); }
    }, true);
  }
  /* shows the screen, puts the terminal in it, and returns its size when it can be fitted */
  function prepareScreen() {
    var screen = q('.fp-term-screen');
    screen.hidden = false;
    q('.fp-term-hint').hidden = false;
    if (!X.term) { makeTerm(); }
    screen.appendChild(X.host);
    if (!X.host.querySelector('.xterm')) { X.term.open(X.host); }
    watchSize(screen);
    return fitNow();
  }
  function fitNow() {
    var d = X.fit ? X.fit.proposeDimensions() : null;
    if (!d || !isFinite(d.cols) || !isFinite(d.rows) || d.cols < 2 || d.rows < 1) { return null; }
    var size = {cols: Math.min(500, Math.floor(d.cols)), rows: Math.min(500, Math.floor(d.rows))};
    if (size.cols !== X.term.cols || size.rows !== X.term.rows) { X.term.resize(size.cols, size.rows); }
    return size;
  }
  /* the shell is told the screen's size when it changes, after the changes stop */
  function watchSize(screen) {
    if (G.observer) { G.observer.disconnect(); }
    if (!window.ResizeObserver) { return; }
    G.observer = new window.ResizeObserver(function () {
      window.clearTimeout(G.sizeTimer);
      G.sizeTimer = window.setTimeout(syncSize, 120);
    });
    G.observer.observe(screen);
  }
  function syncSize() {
    if (!here() || !X.term) { return; }
    var d = fitNow();
    if (!d || G.state !== 'live' || !G.id || (G.sent && G.sent.cols === d.cols && G.sent.rows === d.rows)) { return; }
    G.sent = d;
    var token = G.token;
    FP.call('post', K('terminalResize'), {rows: d.rows, cols: d.cols}, {name: G.account, id: G.id}).then(function () {
      if (token === G.token) { renderBar(); }
    }, function (err) { if (token === G.token) { callFailed(err); } });
  }

  /* ---- the page ---- */
  var PILL = {ready: '', opening: ' sig-pill--accent', live: ' sig-pill--ok', reconnecting: ' sig-pill--accent', ended: ' sig-pill--danger', closing: ' sig-pill--accent'};
  var PILL_TEXT = {ready: 'term_st_ready', opening: 'term_st_opening', live: 'term_st_connected', reconnecting: 'term_st_reconnecting', ended: 'term_st_ended',
    closing: 'term_st_closing'};
  function say(text) { M.say(q('.fp-term-card'), text); }
  function showError(text) { UI.showError(q('.fp-term-card'), text); }
  /* a notice that is neither an error of the server nor a state: it is said politely and kept until the next one */
  function notice(text) { G.notice = text; say(text); }
  function pill() {
    var p = q('.fp-term-pill');
    var key = G.state === 'live' ? 'live' : G.state === 'ended' ? 'ended' : PILL[G.state] !== undefined ? G.state : 'ready';
    p.className = 'sig-pill fp-term-pill' + PILL[key];
    p.textContent = t(PILL_TEXT[key]);
    p.hidden = G.state === 'blocked' || G.state === 'loading';
  }
  function button(act, label, extra, cls) {
    var b = el('button', {class: 'sig-btn ' + (cls || 'sig-btn--secondary sig-btn--sm'), type: 'button', text: label});
    if (act) { b.setAttribute('data-fp-act', act); }
    Object.keys(extra || {}).forEach(function (k) { b.setAttribute(k, extra[k]); });
    return b;
  }
  function renderBar() {
    var bar = q('.fp-term-bar');
    var active = G.state === 'live' || G.state === 'reconnecting' || G.state === 'ended' || G.state === 'closing';
    bar.hidden = !active;
    bar.textContent = '';
    if (!active) { return; }
    if (G.state === 'ended') {
      bar.appendChild(button('start', t('term_open_new'), {}, 'sig-btn--primary sig-btn--sm'));
    } else {
      var size = X.term ? t('term_size', {cols: X.term.cols, rows: X.term.rows}) : '';
      bar.appendChild(el('span', {class: 'fp-muted fp-term-size', text: size}));
      bar.appendChild(button('', t('term_copy'), {'data-fp-copy': ''}));
      var close = button('close-term', t('term_close'), {}, 'sig-btn--secondary sig-btn--sm');
      close.disabled = G.state === 'closing';
      bar.appendChild(close);
    }
  }
  /* what the page shows for a state: the screen only while there is one to see; the way in only while nothing is open */
  function render() {
    var blocked = G.state === 'blocked';
    var idle = G.state === 'ready';
    var opening = G.state === 'opening';
    pill();
    q('.fp-term-intro').hidden = !(idle || opening);
    q('.fp-term-earlier').hidden = !(idle && G.earlier.length);
    q('.fp-term-start').hidden = !(idle || opening);
    q('.fp-term-start button').disabled = opening;
    q('.fp-term-start button').setAttribute('aria-busy', opening ? 'true' : 'false');
    if (!(G.state === 'live' || G.state === 'reconnecting' || G.state === 'ended' || G.state === 'closing' || opening)) {
      q('.fp-term-screen').hidden = true;
      q('.fp-term-hint').hidden = true;
    }
    if (blocked) { q('.fp-term-intro').hidden = true; }
    renderBar();
  }
  function earlierList() {
    var list = q('.fp-term-earlier ul');
    list.textContent = '';
    G.earlier.forEach(function (i) {
      var date = when(i.opened);
      list.appendChild(el('li', {'data-fp-terminal': i.id}, [el('span', {text: t('term_opened_at', {date: date})}),
        el('span', {class: 'fp-term-acts'}, [button('resume', t('term_reconnect'), {'aria-label': t('term_reconnect_of', {date: date}), 'data-fp-id': i.id}),
          button('close-earlier', t('term_close'), {'aria-label': t('term_close_of', {date: date}), 'data-fp-id': i.id}, 'sig-btn--secondary sig-btn--sm fp-btn-danger-text')])]));
    });
  }
  function layout() {
    var blocked = el('div', {class: 'fp-term-blocked', hidden: true});
    var intro = el('p', {class: 'fp-muted fp-term-intro', text: t('term_intro')});
    var earlier = el('div', {class: 'fp-term-earlier', hidden: true}, [el('h3', {class: 'fp-h3', text: t('term_earlier')}),
      el('p', {class: 'fp-muted', text: t('term_earlier_hint')}), el('ul', {class: 'fp-term-list'})]);
    /* a root terminal asks the admin's own password again */
    var pw = G.root ? [el('label', {class: 'sig-label', for: 'fp-rterm-pw', text: t('rterm_password')}),
      el('input', {class: 'sig-input', id: 'fp-rterm-pw', name: 'current_password', type: 'password', autocomplete: 'current-password', maxlength: '1024'})] : [];
    var start = el('div', {class: 'fp-term-start fp-actions'}, pw.concat([button('start', t('term_open'), {}, 'sig-btn--primary')]));
    var bar = el('div', {class: 'fp-term-bar', role: 'group', 'aria-label': t('term_bar'), hidden: true});
    var screen = el('div', {class: 'fp-term-screen', role: 'group', 'aria-label': t('term_screen'), 'aria-describedby': 'fp-term-hint', 'data-overlap-ok': '',
      'data-overflow-ok': '', hidden: true});
    var hint = el('p', {class: 'fp-muted fp-term-hint', id: 'fp-term-hint', text: t('term_screen_hint'), hidden: true});
    return el('section', {class: 'sig-card fp-mail-card fp-term-card', 'aria-labelledby': 'fp-term-h'}, [el('div', {class: 'sig-card-body'}, [
      el('div', {class: 'fp-term-head'}, [el('h2', {class: 'fp-h2', id: 'fp-term-h', tabindex: '-1', text: t('term_title')}), el('span', {class: 'sig-pill fp-term-pill', hidden: true})]),
      M.errorLine(), M.statusLine(), blocked, intro, earlier, start, bar, screen, hint])]);
  }

  /* ---- a session ---- */
  function resetQueue() { G.queue = []; G.queued = 0; G.sending = false; }
  /* the terminal is over for this page: nothing more is asked of the server and nothing more is sent */
  function finish(state, text) {
    G.token++;
    G.state = state;
    G.id = '';
    resetQueue();
    var inScreen = document.activeElement && q('.fp-term-screen').contains(document.activeElement);
    render();
    say(text || '');
    /* what is typed now goes nowhere: focus moves from the screen to the way to a new terminal */
    var next = q('.fp-term-bar button');
    if (inScreen && state === 'ended' && next) { next.focus(); }
  }
  function gone(text) { finish('ended', text || t('term_gone')); }
  /* the answer to a call that failed while a terminal is open */
  function callFailed(err) {
    if (err && err.status === 404) { gone(); return; }
    if (err && err.status === 401) { finish('ended', t('term_signed_out')); return; }
    if (err && err.status === 403) { finish('ended', t('term_refused', {reason: err.message || t('api_failed')})); return; }
    showError(err && err.message ? err.message : t('api_failed'));
  }
  function begin(info, replay) {
    G.token++;
    G.id = info.id;
    G.next = 0;
    G.retry = 0;
    /* a terminal opened here has the size the page asked for; one opened before is told the size of this screen */
    G.sent = replay ? null : {cols: X.term.cols, rows: X.term.rows};
    G.state = 'live';
    resetQueue();
    X.term.reset();
    render();
    UI.showError(q('.fp-term-card'), '');
    say(t('term_say_connected'));
    X.term.focus();
    if (replay) { syncSize(); }
    poll(G.token);
  }
  function poll(token) {
    if (!live(token)) { return; }
    var asked = Date.now();
    FP.call('get', K('terminalOutput'), undefined, {name: G.account, id: G.id, after: String(G.next), wait: POLL_WAIT}).then(function (r) {
      if (!live(token)) { return; }
      var o = cleanOutput(r);
      if (!o) { retry(token); return; }
      if (G.state === 'reconnecting') {
        G.state = 'live';
        G.retry = 0;
        render();
        UI.showError(q('.fp-term-card'), '');
        say(t('term_say_back'));
      }
      if (o.lost) { notice(t('term_lost')); }
      G.next = o.next;
      if (o.data.length) { X.term.write(o.data); }
      if (o.closed) {
        finish('ended', o.exit ? t('term_ended', {exit: o.exit}) : t('term_ended_plain'));
        return;
      }
      var gap = o.data.length || Date.now() - asked >= MIN_GAP ? 0 : MIN_GAP;
      window.setTimeout(function () { poll(token); }, gap);
    }, function (err) {
      if (!live(token)) { return; }
      if (err && (err.status === 404 || err.status === 401 || err.status === 403)) { callFailed(err); return; }
      retry(token, err);
    });
  }
  /* a poll that failed: the screen is kept, and the server is asked again, a little later each time */
  function retry(token, err) {
    if (G.state === 'live') {
      G.state = 'reconnecting';
      render();
      say(t('term_say_reconnecting'));
    }
    if (err && err.message) { showError(err.message); }
    var wait = RETRY[Math.min(G.retry, RETRY.length - 1)];
    G.retry++;
    window.setTimeout(function () { poll(token); }, wait);
  }

  /* typing: sent in order, a chunk at a time, and no more than MAX_QUEUE waiting */
  function sendBytes(bytes) {
    if (!bytes.length || !(G.state === 'live' || G.state === 'reconnecting') || !G.id) { return; }
    if (G.queued + bytes.length > MAX_QUEUE) { notice(t('term_slow')); return; }
    G.queue.push(bytes);
    G.queued += bytes.length;
    pump();
  }
  function pump() {
    if (G.sending || !G.queue.length || !G.id) { return; }
    var take = Math.min(G.queued, CHUNK);
    var chunk = new Uint8Array(take);
    var at = 0;
    while (at < take) {
      var head = G.queue[0];
      var n = Math.min(head.length, take - at);
      chunk.set(head.subarray(0, n), at);
      at += n;
      if (n === head.length) { G.queue.shift(); } else { G.queue[0] = head.subarray(n); }
    }
    G.queued -= take;
    G.sending = true;
    var token = G.token;
    FP.call('post', K('terminalInput'), {data: b64(chunk)}, {name: G.account, id: G.id}).then(function () {
      if (token !== G.token) { return; }
      G.sending = false;
      pump();
    }, function (err) {
      if (token !== G.token) { return; }
      G.sending = false;
      resetQueue();
      if (err && (err.status === 404 || err.status === 401 || err.status === 403)) { callFailed(err); return; }
      /* also a 409 (the terminal is not taking input, or has ended: the next poll says so too): what was waiting was dropped, so the person is told */
      notice(t('term_input_failed', {reason: err && err.message ? err.message : t('api_failed')}));
    });
  }

  /* ---- opening, reconnecting and closing ---- */
  /* the terminals the server holds for the account, read again (a refusal because of three open may be about ones opened in another tab) */
  function refreshEarlier() {
    var token = G.token;
    FP.call('get', K('terminal'), undefined, G.account).then(function (r) {
      var list = cleanList(r);
      if (token !== G.token || !here() || !list || G.state !== 'ready') { return; }
      G.earlier = list;
      earlierList();
      render();
    }, function () { /* the page keeps what it has */ });
  }
  function openFailed(err) {
    G.state = 'ready';
    render();
    say('');
    if (err && err.status === 409 && /no shell/i.test(err.message || '')) {
      G.state = 'blocked';
      G.shell = 'disabled';
      blockedView();
      return;
    }
    if (err && err.status === undefined) { showError(t('term_load_failed')); return; }
    showError(err && err.message ? err.message : t('api_failed'));
    if (err && err.status === 409) { refreshEarlier(); }
  }
  function start() {
    if (G.state !== 'ready' && G.state !== 'ended') { return; }
    UI.showError(q('.fp-term-card'), '');
    say('');
    G.state = 'opening';
    render();
    say(t('term_opening'));
    var size;
    assets().then(function () {
      if (!here()) { return null; }
      size = prepareScreen();
      var body = size ? {rows: size.rows, cols: size.cols} : {};
      var pwField = G.root ? q('#fp-rterm-pw') : null;
      if (pwField) { body.current_password = pwField.value; pwField.value = ''; }
      return FP.call('post', K('terminal'), body, G.account);
    }).then(function (r) {
      if (!r || !here()) { return; }
      var info = cleanInfo(r);
      if (!info) { openFailed(); return; }
      begin(info, false);
    }, function (err) {
      if (here()) { openFailed(err); }
    });
  }
  function resume(id) {
    var info = G.earlier.filter(function (i) { return i.id === id; })[0];
    if (!info || G.state !== 'ready') { return; }
    UI.showError(q('.fp-term-card'), '');
    G.state = 'opening';
    render();
    say(t('term_opening'));
    assets().then(function () {
      if (!here()) { return; }
      prepareScreen();
      G.earlier = G.earlier.filter(function (i) { return i.id !== id; });
      begin(info, true);
    }, function (err) {
      if (here()) { openFailed(err); }
    });
  }
  /* closes a terminal of the server; done is told whether it worked (a terminal that is gone is as good as closed) */
  function closeRemote(id, done) {
    FP.call('del', K('terminalOne'), undefined, {name: G.account, id: id}).then(function () { done(null); }, function (err) { done(err && err.status === 404 ? null : err); });
  }
  function closeTerm() {
    if (G.state !== 'live' && G.state !== 'reconnecting') { return; }
    var id = G.id;
    G.token++;
    G.state = 'closing';
    resetQueue();
    render();
    closeRemote(id, function (err) {
      if (!here()) { return; }
      if (err) {
        G.id = id;
        G.state = 'live';
        G.token++;
        render();
        showError(t('term_close_failed', {reason: err.message || t('api_failed')}));
        poll(G.token);
        return;
      }
      G.id = '';
      G.state = 'ready';
      render();
      q('.fp-term-screen').hidden = true;
      q('.fp-term-hint').hidden = true;
      say(t('term_say_closed'));
      var open = q('.fp-term-start button');
      if (open) { open.focus(); }
    });
  }
  function closeEarlier(id) {
    var li = q('[data-fp-terminal="' + id + '"]');
    closeRemote(id, function (err) {
      if (!here()) { return; }
      if (err) { showError(t('term_close_failed', {reason: err.message || t('api_failed')})); return; }
      G.earlier = G.earlier.filter(function (i) { return i.id !== id; });
      if (li && li.parentNode) { li.parentNode.removeChild(li); }
      say(t('term_say_closed'));
      render();
      var open = q('.fp-term-start button');
      if (open) { open.focus(); }
    });
  }
  /* the page is left: the terminal is closed with it, and nothing is asked of the server any more */
  function leave() {
    var done = Promise.resolve();
    if (G.id) {
      var id = G.id;
      G.id = '';
      G.token++;
      G.state = 'ready';
      done = new Promise(function (resolve) { closeRemote(id, resolve); }); /* the server ends it in 15 minutes anyway if this fails */
    }
    if (G.observer) { G.observer.disconnect(); G.observer = null; }
    return done;
  }
  /* the shell is closed before the session ends: afterwards the server would refuse the call, and the shell would outlive the sign-in */
  FP.beforeSignOut.push(function () {
    var open = Boolean(G.id);
    var done = leave();
    if (open && here()) { render(); say(t('term_say_closed')); }
    return done;
  });
  window.addEventListener('hashchange', function () { if (G.id && window.location.hash !== hash()) { leave(); } });
  window.addEventListener('pagehide', function () { if (G.id) { leave(); } });
  window.addEventListener('online', function () { if (G.state === 'reconnecting') { G.retry = 0; } });

  document.addEventListener('click', function (e) {
    var b = e.target && e.target.closest ? e.target.closest('button') : null;
    if (!b || !G.page || !G.page.contains(b)) { return; }
    var a = b.getAttribute('data-fp-act');
    if (a === 'start') {
      start();
    } else if (a === 'close-term') {
      closeTerm();
    } else if (a === 'resume') {
      resume(b.getAttribute('data-fp-id'));
    } else if (a === 'close-earlier') {
      closeEarlier(b.getAttribute('data-fp-id'));
    } else if (b.hasAttribute('data-fp-copy')) {
      if (!X.term || !X.term.hasSelection()) { say(t('term_copy_none')); return; }
      var text = X.term.getSelection();
      if (!window.navigator.clipboard || !window.navigator.clipboard.writeText) { say(t('term_copy_failed')); return; }
      window.navigator.clipboard.writeText(text).then(function () { say(t('term_copied')); }, function () { say(t('term_copy_failed')); });
    }
  });

  /* the page for an account that can't have a terminal, in the server's words or ours */
  function blockedView() {
    G.state = 'blocked';
    var card = q('.fp-term-card');
    UI.showError(card, '');
    q('.fp-term-intro').hidden = true;
    q('.fp-term-start').hidden = true;
    q('.fp-term-earlier').hidden = true;
    var box = q('.fp-term-blocked');
    box.textContent = '';
    box.hidden = false;
    if (G.suspended) {
      box.appendChild(el('p', {text: t('term_suspended')}));
    } else {
      box.appendChild(el('h3', {class: 'fp-h3', text: t('term_no_shell_title')}));
      box.appendChild(el('p', {class: 'fp-muted', text: t('term_no_shell')}));
    }
    render();
  }

  /* root's terminal: off until the server's owner turns it on in the config, which the server says at the open */
  FP.view('tool:root_terminal', function () {
    if (G.page) { leave(); }
    G.token++;
    G.page = null;
    var tool = FP.tools.root_terminal;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('rterm_desc'), cls: 'fp-term fp-rterm',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    G.page = body;
    G.root = true;
    G.account = 'root';
    G.state = 'loading';
    G.id = '';
    G.earlier = [];
    G.shell = 'normal';
    G.suspended = false;
    resetQueue();
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', K('terminal')).then(function (r) {
      if (G.page !== body) { return; }
      body.textContent = '';
      var list = cleanList(r);
      if (!list) { body.appendChild(FP.empty(tool.label, t('api_failed'))); return; }
      body.appendChild(el('p', {class: 'fp-alert fp-alert--warn', role: 'note', text: t('rterm_warning')}));
      body.appendChild(layout());
      G.earlier = list;
      G.state = 'ready';
      earlierList();
      render();
    }, function (err) {
      if (G.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });

  FP.view('tool:terminal', function () {
    if (G.page) { leave(); }
    G.root = false;
    G.token++;
    G.page = null;
    var body = M.frame('terminal', 'fp-term');
    if (!body) { return; }
    G.page = body;
    G.account = FP.account();
    G.state = 'loading';
    G.id = '';
    G.earlier = [];
    G.shell = 'normal';
    G.suspended = false;
    resetQueue();
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    var calls = [FP.call('get', 'account', undefined, G.account), FP.call('get', K('terminal'), undefined, G.account)];
    /* the account's own record tells the shell type and whether it is suspended; when it can't be had the server says no again at the open */
    Promise.all(calls.map(function (p) { return p.then(function (v) { return {ok: v}; }, function (e) { return {err: e}; }); })).then(function (res) {
      if (G.page !== body) { return; }
      body.textContent = '';
      if (res[1].err) {
        body.appendChild(FP.empty(FP.tools.terminal.label, res[1].err.message));
        return;
      }
      var list = cleanList(res[1].ok);
      if (!list) { body.appendChild(FP.empty(FP.tools.terminal.label, t('api_failed'))); return; }
      var acct = res[0].ok && typeof res[0].ok === 'object' ? res[0].ok : null;
      G.shell = acct && typeof acct.shell === 'string' ? acct.shell : 'normal';
      G.suspended = Boolean(acct && acct.status === 'suspended');
      body.appendChild(layout());
      G.earlier = list;
      G.state = 'ready';
      earlierList();
      if (G.suspended || G.shell === 'disabled') { blockedView(); } else { render(); }
    });
  });
})();

/* freePanel billing registrar choice (#/tool/billing_registrar; docs/api.md, "Billing: domains"; docs/billing/navigation-map.md, "Domain
   pricing"): which registrar the panel registers, renews and searches domains through, or none. Only the built-in test registrar ships; it
   registers nothing anywhere. Moving off the registrar in use is asked first. Below the choice, each registrar has a card for its settings
   (docs/api.md, "Billing: domains", Registrars and their settings): the ones it says it takes, a secret write-only (a box left empty keeps
   what is saved), what it still needs before it can be used, and its connection test when it has one. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;
  var M = FP.mail;

  FP.view('tool:billing_registrar', function () {
    var page = B.frame('billing_registrar', 'fp-brg');
    if (!page) { return; }
    var alive = function () { return page.isConnected; };
    /* the choice and the settings cards are drawn apart, so changing the choice never throws away settings typed but not saved */
    var top = el('div', {'data-fp-part': 'choice'});
    var cards = el('div', {class: 'fp-brs-cards', 'data-fp-part': 'settings'});
    var cardsDrawn = false;
    function draw(r, said) {
      var active = B.str(r && r.active, 40);
      var list = B.pickAll(r && r.registrars, {id: [40], name: [60]}, 'id').filter(function (x) { return /^[a-z0-9_-]{1,40}$/.test(x.id); });
      var opts = [{id: '', name: t('brg_none')}].concat(list);
      var radios = opts.map(function (x) {
        var fid = 'fp-brg-' + (x.id || 'none');
        return el('label', {class: 'fp-bil-check', for: fid}, [el('input', {type: 'radio', id: fid, name: 'active', value: x.id, checked: x.id === active ? true : null}),
          el('span', {text: x.name || x.id}), x.id === 'test' ? el('span', {class: 'fp-muted', text: ' ' + t('brg_test_mark')}) : null]);
      });
      var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bil_save_changes')});
      var form = el('form', {class: 'fp-form fp-bil-crud-form fp-brg-form', novalidate: '', 'aria-labelledby': 'fp-brg-h'}, [M.errorLine(), M.statusLine(),
        el('p', {'data-fp-active': '', text: active ? t('brg_now', {name: (list.filter(function (x) { return x.id === active; })[0] || {name: active}).name}) : t('brg_now_none')}),
        el('fieldset', {class: 'fp-bil-set'}, [el('legend', {class: 'sig-label', text: t('brg_legend')}), el('div', {class: 'fp-bil-checks fp-brg-list'}, radios)]),
        el('div', {class: 'fp-actions', 'data-fp-acts': ''}, [save])]);
      function send(b, v) {
        UI.setBusy(b, true);
        FP.call('patch', 'billingRegistrar', {active: v}).then(function (x) {
          if (!alive()) { return; }
          draw(x, t('brg_saved'));
        }, function (err) {
          if (!alive()) { return; }
          draw(r);
          /* a refusal on "active" (a registrar not ready) is about the choice, not the None button */
          var shown = err && err.field === 'active' ? {message: err.message} : err;
          B.failed(top.querySelector('.fp-brg-form'), shown);
        });
      }
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!B.begin(form, save)) { return; }
        var picked = form.querySelector('[name="active"]:checked');
        var v = picked ? picked.value : '';
        if (v === active) { M.say(form, t('bil_nothing_changed')); return; }
        if (!active) { send(save, v); return; }
        var box = form.querySelector('[data-fp-acts]');
        box.textContent = '';
        var yes = el('button', {class: 'sig-btn sig-btn--danger', type: 'button', text: t('brg_yes'), 'aria-describedby': 'fp-brg-q'});
        var no = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', text: t('brg_keep'), 'aria-describedby': 'fp-brg-q'});
        box.appendChild(el('p', {class: 'fp-mail-confirm', id: 'fp-brg-q', text: t(v ? 'brg_ask_switch' : 'brg_ask_none')}));
        box.appendChild(yes);
        box.appendChild(no);
        yes.addEventListener('click', function () { send(yes, v); });
        no.addEventListener('click', function () { box.textContent = ''; box.appendChild(save); save.focus(); });
        no.focus();
      });
      B.screen(top, [B.card('fp-brg-h', t('brg_title'), [el('p', {class: 'fp-muted', text: t('brg_what')}), form], 'fp-brg', 'registrar')]);
      if (said) { M.say(top.querySelector('.fp-brg-form'), said); top.querySelector('#fp-brg-h').focus(); }
      if (!cardsDrawn && list.length) { cardsDrawn = true; settingsAll(); }
    }
    /* ---- a registrar's settings ---- */
    function cleanDetail(r) {
      var v = B.pick(r, {id: [40], name: [60], active: 'b', ready: 'b', can_test: 'b', problem: [300]}) || {};
      v.missing = (r && Array.isArray(r.missing) ? r.missing : []).filter(function (x) { return typeof x === 'string'; }).map(function (x) { return x.slice(0, 40); });
      v.settings = (r && Array.isArray(r.settings) ? r.settings : []).map(function (x) {
        if (!x || typeof x.name !== 'string' || !/^[a-z][a-z0-9_]{0,39}$/.test(x.name)) { return null; }
        return {name: x.name, label: typeof x.label === 'string' && x.label ? x.label.slice(0, 200) : x.name, secret: x.secret === true, required: x.required === true,
          set: x.set === true, value: typeof x.value === 'string' ? x.value.slice(0, 4096) : ''};
      }).filter(Boolean);
      return v;
    }
    /* every registrar's settings come in one call (GET /billing/registrars), a card each */
    function settingsAll() {
      cards.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
      FP.call('get', 'billingRegistrars').then(function (r) {
        if (!alive()) { return; }
        cards.textContent = '';
        (r && Array.isArray(r.registrars) ? r.registrars : []).map(cleanDetail).filter(function (v) { return /^[a-z0-9_-]{1,40}$/.test(v.id); }).forEach(function (v) {
          var slot = el('div', {'data-fp-registrar': v.id});
          cards.appendChild(slot);
          settingsCard(slot, {id: v.id, name: v.name}, v);
        });
      }, function (err) {
        if (!alive()) { return; }
        cards.textContent = '';
        cards.appendChild(el('p', {class: 'fp-warn-line', text: err.message}));
      });
    }
    function settingsCard(slot, x, v, said) {
      var pre = 'fp-brs-' + x.id;
      var name = x.name || x.id;
      var labels = {};
      v.settings.forEach(function (f) { labels[f.name] = f.label; });
      var parts = [el('p', {class: 'fp-muted', text: t('brs_what')})];
      if (v.problem) { parts.push(el('p', {class: 'fp-warn-line', 'data-fp-problem': '', text: v.problem})); }
      if (v.ready || v.missing.length) {
        parts.push(el('p', {class: v.ready ? 'fp-ok-line fp-brs-state' : 'fp-warn-line fp-brs-state', 'data-fp-ready': v.ready ? 'yes' : 'no',
          text: v.ready ? t('brs_ready') : t('brs_missing', {names: v.missing.map(function (k) { return labels[k] || k; }).join(', ')})}));
      }
      if (!v.settings.length) {
        parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('brs_none')}));
      }
      var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('brs_save', {name: name})});
      var test = v.can_test ? el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'test', text: t('brs_test'), disabled: v.ready ? null : true}) : null;
      var fields = v.settings.map(function (f) {
        var fid = pre + '-' + f.name;
        var hint = (f.required ? t('brs_required') : t('brs_optional')) + (f.secret ? ' ' + t(f.set ? 'brs_secret_set' : 'brs_secret_unset') : '');
        return M.field(fid, f.label, B.input(fid, f.name, f.secret ? '' : f.value, {type: f.secret ? 'password' : 'text', maxlength: '4096', spellcheck: 'false',
          autocapitalize: 'none', autocomplete: f.secret ? 'new-password' : 'off', 'data-fp-secret': f.secret ? (f.set ? 'set' : 'unset') : null}), hint);
      });
      var form = el('form', {class: 'fp-form fp-bil-crud-form fp-brs-form', novalidate: '', autocomplete: 'off', 'aria-labelledby': pre + '-h'}, [M.errorLine(), M.statusLine(),
        fields.length ? el('div', {class: 'fp-bil-grid'}, fields) : null, el('div', {class: 'fp-actions'}, [fields.length ? save : null, test])]);
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!fields.length || !B.begin(form, save)) { return; }
        var values = {};
        v.settings.forEach(function (f) {
          var c = UI.fieldNamed(form, f.name);
          var now = c.value.trim();
          /* a one-line box drops line breaks, so a value is compared as the box shows it: one kept with a break is not rewritten */
          if (f.secret ? now : now !== f.value.replace(/[\r\n]/g, '').trim()) { values[f.name] = now; }
        });
        if (!Object.keys(values).length) { M.say(form, t('bil_nothing_changed')); return; }
        UI.setBusy(save, true);
        if (test) { test.disabled = true; }
        FP.call('patch', 'billingRegistrarSettings', {values: values}, {id: x.id}).then(function (r) {
          if (!alive() || !form.isConnected) { return; }
          settingsCard(slot, x, cleanDetail(r), t('brs_saved', {name: name}));
        }, function (err) {
          if (!alive() || !form.isConnected) { return; }
          UI.setBusy(save, false);
          if (test) { test.disabled = !v.ready; }
          B.failed(form, err);
        });
      });
      if (test) {
        test.addEventListener('click', function () {
          if (!B.begin(form, test)) { return; }
          UI.setBusy(test, true);
          if (fields.length) { save.disabled = true; }
          FP.call('post', 'billingRegistrarTest', {}, {id: x.id}).then(function (r) {
            if (!alive() || !form.isConnected) { return; }
            UI.setBusy(test, false);
            save.disabled = false;
            if (r && r.ok === true) { M.say(form, t('brs_test_ok')); return; }
            M.fieldError(form, null, t('brs_test_failed', {error: B.str(r && r.error, 200) || t('api_failed')}));
          }, function (err) {
            if (!alive() || !form.isConnected) { return; }
            UI.setBusy(test, false);
            save.disabled = false;
            B.failed(form, err);
          });
        });
      }
      slot.textContent = '';
      slot.appendChild(B.card(pre + '-h', t('brs_title', {name: name}), parts.concat([form]), 'fp-brs'));
      if (said) { M.say(form, said); slot.querySelector('#' + pre + '-h').focus(); }
    }
    page.appendChild(top);
    page.appendChild(cards);
    top.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    function load() {
      FP.call('get', 'billingRegistrar').then(function (r) { if (alive()) { draw(r); } }, function (err) {
        if (!alive()) { return; }
        B.screen(top, [FP.empty(t('brg_title'), err.message, B.button('reload', t('bil_try_again')))]);
        top.querySelector('[data-fp-act="reload"]').addEventListener('click', load);
      });
    }
    load();
  });
})();

/* freePanel first-run tour: a "Getting started" card on the home page of both panels that walks a new user through the
   first things to do, one step at a time, each step opening its tool. It shows until the user closes it, which is
   remembered in this browser for that user (fp.tour.<realm>.<user>), and "Show the getting started tour" on the home page
   brings it back. A step whose tool the session doesn't have is left out. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;

  var STEPS = {
    admin: [['account_new', 'tour_a_account'], ['packages', 'tour_a_packages'], ['dns_nameservers', 'tour_a_ns'], ['ssl_auto', 'tour_a_ssl'], ['backup_settings', 'tour_a_backups']],
    user: [['mailboxes', 'tour_u_mail'], ['file_manager', 'tour_u_files'], ['ssl_guide', 'tour_u_ssl'], ['mysql', 'tour_u_db'], ['backup_guide', 'tour_u_backup']]
  };
  function key() {
    var u = FP.session && FP.session.user && typeof FP.session.user.username === 'string' ? FP.session.user.username : '';
    return 'fp.tour.' + FP.realm + '.' + u.slice(0, 64);
  }
  function steps() {
    return (STEPS[FP.realm === 'admin' ? 'admin' : 'user'] || []).filter(function (s) { return FP.tools[s[0]]; });
  }

  /* the card, at step i; replaced in place as the user moves through it */
  function card(list, i) {
    var s = list[i];
    var tool = FP.tools[s[0]];
    var back = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-tour': 'back', disabled: i === 0 ? true : null, text: t('tour_back')});
    var next = i < list.length - 1 ? el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-tour': 'next', text: t('tour_next')}) :
      el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-tour': 'close', text: t('tour_finish')});
    var box = el('section', {class: 'sig-card fp-tour', 'aria-labelledby': 'fp-tour-h', 'data-fp-step': String(i)}, [
      el('div', {class: 'sig-card-head'}, [el('h2', {class: 'sig-card-title', id: 'fp-tour-h', tabindex: '-1', text: t('tour_title')}),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-tour': 'close', 'aria-label': t('tour_close_named'), text: t('tour_close')})]),
      el('div', {class: 'sig-card-body'}, [
        el('p', {class: 'fp-muted', 'data-fp-tour-count': '', text: t('tour_count', {n: i + 1, of: list.length})}),
        el('h3', {class: 'fp-tour-step', text: tool.label}),
        el('p', {text: t(s[1])}),
        el('div', {class: 'fp-actions'}, [el('a', {class: 'sig-btn sig-btn--primary sig-btn--sm', href: '#/tool/' + s[0], text: t('tour_open', {tool: tool.label})}), back, next])])]);
    box.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('[data-fp-tour]') : null;
      if (!b || b.disabled) { return; }
      var act = b.getAttribute('data-fp-tour');
      if (act === 'close') {
        UI.store.set(key(), 'closed');
        var again = againLink(box.parentNode);
        box.replaceWith(again);
        again.querySelector('button').focus();
        return;
      }
      var n = act === 'next' ? i + 1 : i - 1;
      var fresh = card(list, Math.max(0, Math.min(list.length - 1, n)));
      box.replaceWith(fresh);
      fresh.querySelector('#fp-tour-h').focus();
    });
    return box;
  }
  function againLink(parent) {
    var b = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', text: t('tour_again')});
    var wrap = el('p', {class: 'fp-tour-again'}, [b]);
    b.addEventListener('click', function () {
      UI.store.del(key());
      var list = steps();
      if (!list.length) { return; }
      var c = card(list, 0);
      wrap.replaceWith(c);
      c.querySelector('#fp-tour-h').focus();
    });
    void parent;
    return wrap;
  }

  /* puts the tour, or the way back to it, at the top of a home page */
  FP.tour = function (body) {
    var list = steps();
    if (!list.length) { return; }
    var node = UI.store.get(key()) === 'closed' ? againLink(body) : card(list, 0);
    body.insertBefore(node, body.firstChild);
  };
})();

/* freePanel billing pages, the shared part (docs/api.md, "Billing: ..."): money in whole cents shown in the invoice's currency, days and
   times, the status pills of clients and invoices, the form helpers the billing pages share, reading every page of a list, and handing a
   client or an invoice from one billing tool to another (the router has no sub-routes, so the page that opens reads what it was handed).
   Money is never worked out in floating point: amounts are whole cents, and what is typed is read digit by digit.
   Declares only FP.billing. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;

  var MAX_CENTS = 1000000000;
  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 500) : ''; }
  function id(v) { return typeof v === 'number' && Number.isSafeInteger(v) && v > 0 ? v : null; }
  function cents(v) { return typeof v === 'number' && Number.isSafeInteger(v) && Math.abs(v) <= 100 * MAX_CENTS ? v : null; }
  function whole(v) { return typeof v === 'number' && Number.isSafeInteger(v) && v >= 0 ? v : null; }
  function currencyOf(v) { return typeof v === 'string' && /^[A-Z]{3}$/.test(v) ? v : 'USD'; }

  /* $1,234.56: the division is only for the display, the amount itself stays whole cents */
  function money(c, currency) {
    if (c === null || c === undefined) { return '—'; }
    return (c / 100).toLocaleString('en', {style: 'currency', currency: currencyOf(currency)});
  }
  /* what to put in an amount field: 1234.5 dollars is written 1234.50, from the cents, without a division */
  function amountText(c) {
    if (c === null || c === undefined) { return ''; }
    var a = Math.abs(c);
    var frac = String(a % 100);
    return (c < 0 ? '-' : '') + String((a - (a % 100)) / 100) + '.' + (frac.length < 2 ? '0' + frac : frac);
  }
  /* an amount typed in dollars and cents ("1,234.5", "$20", "-3.75") as whole cents; null when it is not one. signed allows a minus.
     A comma only groups thousands (1,234 or 1,234,567.89): "12,50" is refused, never read as twelve hundred and fifty dollars. */
  function parseAmount(text, signed) {
    var v = String(text || '').replace(/\s/g, '').replace(/^(-?)\$/, '$1');
    var m = /^(-)?(\d{1,3}(?:,\d{3})+|\d{1,10})(?:\.(\d{0,2}))?$/.exec(v) || /^(-)?()\.(\d{1,2})$/.exec(v);
    if (!m || (m[1] && !signed)) { return null; }
    var frac = (m[3] || '') + '00';
    var c = parseInt((m[2] || '0').replace(/,/g, ''), 10) * 100 + parseInt(frac.slice(0, 2), 10);
    if (c > 100 * MAX_CENTS) { return null; }
    return m[1] ? -c : c;
  }

  /* a day (YYYY-MM-DD, UTC) and a time (UTC), as people read them */
  function day(v) {
    var s = str(v, 40);
    var m = /^(\d{4}-\d{2}-\d{2})/.exec(s);
    var d = m ? new Date(m[1] + 'T00:00:00Z') : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleDateString('en', {dateStyle: 'medium', timeZone: 'UTC'}) : '';
  }
  function when(v) {
    var d = new Date(str(v, 40));
    return isNaN(d.getTime()) ? '' : d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'});
  }
  function num(n) { return n.toLocaleString('en'); }

  /* ---- pills: the state in words, the colour only adds to it ---- */
  function pill(text, kind, attrs) {
    return el('span', Object.assign({class: 'sig-pill fp-bil-pill' + (kind ? ' sig-pill--' + kind : ''), text: text}, attrs || {}));
  }
  var CLIENT = {active: 'ok', inactive: 'warn', closed: ''};
  function clientPill(status) {
    return Object.prototype.hasOwnProperty.call(CLIENT, status) ? pill(t('bil_client_' + status), CLIENT[status], {'data-fp-status-of': status}) : pill('—', '');
  }
  /* overdue is not stored: an unpaid invoice reads overdue from the day after its due day */
  var INVOICE = {draft: '', unpaid: 'warn', overdue: 'danger', paid: 'ok', cancelled: '', refunded: 'accent'};
  function invoiceState(inv) { return inv.status === 'unpaid' && inv.overdue ? 'overdue' : inv.status; }
  function invoicePill(inv) {
    var s = invoiceState(inv);
    return Object.prototype.hasOwnProperty.call(INVOICE, s) ? pill(t('bil_inv_' + s), INVOICE[s], {'data-fp-status-of': s}) : pill('—', '');
  }

  /* ---- what the server sends, kept to what the pages show ---- */
  var STATUSES = ['active', 'inactive', 'closed'];
  function cleanCustomer(c) {
    if (!c || typeof c !== 'object' || !id(c.id)) { return null; }
    var fields = {};
    if (c.fields && typeof c.fields === 'object') {
      Object.keys(c.fields).forEach(function (k) { if (/^[1-9][0-9]{0,9}$/.test(k) && typeof c.fields[k] === 'string') { fields[k] = c.fields[k].slice(0, 200); } });
    }
    return {id: c.id, name: str(c.name, 100), company: str(c.company, 100), email: str(c.email, 254), phone: str(c.phone, 30),
      address1: str(c.address1, 100), address2: str(c.address2, 100), city: str(c.city, 60), region: str(c.region, 60), postcode: str(c.postcode, 20),
      country: /^[A-Z]{2}$/.test(str(c.country, 2)) ? c.country : '', status: STATUSES.indexOf(c.status) >= 0 ? c.status : '',
      group_id: id(c.group_id), fields: fields, created: str(c.created, 40), updated: str(c.updated, 40)};
  }
  var INV_STATUSES = ['draft', 'unpaid', 'paid', 'cancelled', 'refunded'];
  function cleanLine(l) {
    if (!l || typeof l !== 'object') { return null; }
    var q = whole(l.quantity);
    return {description: str(l.description, 200), quantity: q && q <= 100000 ? q : 1, unit_cents: cents(l.unit_cents) || 0,
      amount_cents: cents(l.amount_cents) || 0, no_tax: l.no_tax === true};
  }
  function cleanInvoice(v) {
    if (!v || typeof v !== 'object' || !id(v.id) || INV_STATUSES.indexOf(v.status) < 0) { return null; }
    var z = function (k) { var c = cents(v[k]); return c === null ? 0 : c; };
    return {id: v.id, customer_id: id(v.customer_id), status: v.status, number: str(v.number, 40), currency: currencyOf(v.currency),
      subtotal_cents: z('subtotal_cents'), tax_cents: z('tax_cents'), total_cents: z('total_cents'), paid_cents: z('paid_cents'),
      credited_cents: z('credited_cents'), balance_cents: z('balance_cents'), tax_name: str(v.tax_name, 60),
      tax_rate_bp: whole(v.tax_rate_bp), note: str(v.note, 500), overdue: v.overdue === true,
      lines: (Array.isArray(v.lines) ? v.lines : []).slice(0, 100).map(cleanLine).filter(Boolean),
      issued: str(v.issued, 40), due_on: str(v.due_on, 10), paid: str(v.paid, 40), cancelled: str(v.cancelled, 40),
      reason: str(v.reason, 200), created: str(v.created, 40), service_id: id(v.service_id), merged_into: id(v.merged_into)};
  }
  function invoiceName(inv) { return inv.number || t('bil_draft_n', {id: String(inv.id)}); }

  /* ---- forms ---- */
  /* the form's error line names the field it is about: a label, or the control's own name when it has no label (a cell of the lines table) */
  function nameOf(form, f) {
    var label = f && f.id ? form.querySelector('label[for="' + f.id + '"]') : null;
    var text = label ? label.textContent : f ? f.getAttribute('aria-label') || '' : '';
    return text ? text.replace(/\s*\*$/, '') + ': ' : '';
  }
  function failed(form, err) {
    var f = err && err.field ? UI.fieldNamed(form, err.field) : null;
    FP.mail.fieldError(form, f, nameOf(form, f) + (err && err.message ? err.message : t('api_failed')));
  }
  /* starts a submit with button b: false while one is running; clears the last answer and the marks */
  function begin(form, b) {
    if (!b || b.disabled) { return false; }
    UI.showError(form, '');
    FP.mail.say(form, '');
    var bad = form.querySelectorAll('[aria-invalid]');
    for (var i = 0; i < bad.length; i++) { bad[i].removeAttribute('aria-invalid'); }
    return true;
  }
  function input(id, name, value, extra) {
    return el('input', Object.assign({class: 'sig-input', id: id, name: name, type: 'text', value: value || '', autocomplete: 'off'}, extra || {}));
  }
  function select(id, name, options, value, extra) {
    return el('select', Object.assign({class: 'sig-select', id: id, name: name}, extra || {}), options.map(function (o) {
      return el('option', {value: o[0], text: o[1], selected: String(o[0]) === String(value) ? true : null});
    }));
  }
  function button(act, text, cls, extra) {
    return el('button', Object.assign({class: 'sig-btn ' + (cls || 'sig-btn--secondary'), type: 'button', 'data-fp-act': act, text: text}, extra || {}));
  }
  function back(act, text) {
    var b = button(act, '', 'sig-btn--secondary sig-btn--sm fp-bil-back');
    b.appendChild(UI.icon(FP.ui, 'ui_arrow_left'));
    b.appendChild(el('span', {text: text}));
    return b;
  }
  function th(text, cls) { return el('th', {scope: 'col', class: cls || null, text: text}); }
  /* a table in a frame that scrolls sideways on a narrow screen, named by its card's heading */
  function table(headingId, cls, heads, rows) {
    return el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': headingId}, [
      el('table', {class: 'sig-table fp-bil-table ' + (cls || '')}, [el('thead', null, [el('tr', null, heads)]), el('tbody', null, rows)])]);
  }
  /* label: value pairs, the values given as text or as nodes */
  function facts(pairs, cls) {
    var items = [];
    pairs.forEach(function (p) {
      if (!p) { return; }
      items.push(el('div', {class: 'fp-bil-fact'}, [el('dt', {text: p[0]}), el('dd', null, Array.isArray(p[1]) ? p[1] : [p[1] === '' || p[1] === null ? '—' : String(p[1])])]));
    });
    return el('dl', {class: 'fp-bil-facts' + (cls ? ' ' + cls : '')}, items);
  }

  /* ---- reading ---- */
  function has(feature) { return Array.isArray(FP.session.features) && FP.session.features.indexOf(feature) >= 0; }
  /* every page of a list, up to max pages of 200: {items, complete} */
  function allPages(name, arg, key, max) {
    var out = [];
    function next(offset, left) {
      return FP.call('get', name, undefined, Object.assign({limit: '200', offset: String(offset)}, arg)).then(function (r) {
        var items = r && Array.isArray(r[key]) ? r[key] : [];
        var total = whole(r && r.total);
        out = out.concat(items);
        var done = !items.length || total === null || out.length >= total;
        if (done || left <= 1) { return {items: out, complete: done}; }
        return next(offset + items.length, left - 1);
      });
    }
    return next(0, max || 5);
  }

  /* ---- from one billing tool to another ---- */
  var handed = null;
  /* opens the tool with something for it: {client: id} for the clients page, {invoice: id} or {create: clientId} for the invoices page */
  function go(tool, what) {
    handed = {tool: tool, what: what};
    if (window.location.hash === '#/tool/' + tool) { FP.route(true); } else { window.location.hash = '#/tool/' + tool; }
  }
  function take(tool) {
    var h = handed && handed.tool === tool ? handed.what : null;
    handed = null;
    return h;
  }

  /* the page frame of a billing tool, for the administrator and for a reseller, each in its own billing book (the session offers a reseller
     only the back office's tools, never the server's own: the import, the hosting panel's pages); null when this login may not have it */
  function frame(toolId, cls) {
    var tool = FP.tools[toolId];
    if (!tool || FP.realm !== 'admin' || (FP.session.user.role !== 'admin' && FP.session.user.role !== 'reseller')) { FP.views['not-found']({view: 'not-found'}); return null; }
    var g = FP.group(tool.group);
    return FP.frame({title: tool.label, desc: t(toolId + '_desc'), cls: 'fp-bil ' + cls,
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
  }

  /* ---- more states: services, orders, quotes, tickets, payments, domains, saved methods. Each word has its own string (bil_<kind>_<word>)
     and a colour that only adds to it; a word the page does not know shows as it came, with no colour ---- */
  var STATES = {
    svc: {active: 'ok', suspended: 'warn', cancelled: '', terminated: 'danger'},
    order: {pending: 'warn', accepted: 'ok', cancelled: ''},
    quote: {draft: '', sent: 'accent', accepted: 'ok', declined: 'danger', expired: 'warn', invoiced: 'ok'},
    ticket: {open: 'danger', customer_reply: 'warn', answered: 'ok', on_hold: '', closed: ''},
    tx: {succeeded: 'ok', pending: 'warn', failed: 'danger'},
    domain: {pending: 'warn', active: 'ok', expired: 'danger', cancelled: '', failed: 'danger', transferred_away: ''},
    pm: {pending: 'warn', active: 'ok', refused: 'danger', removed: ''},
    msg: {queued: 'warn', sent: 'ok', failed: 'danger'}
  };
  function stateText(kind, word) {
    var k = 'bil_' + kind + '_' + word;
    return t(k) === k ? String(word || '—') : t(k);
  }
  function statePill(kind, word) {
    var map = STATES[kind] || {};
    return Object.prototype.hasOwnProperty.call(map, word) ? pill(stateText(kind, word), map[word], {'data-fp-status-of': word}) : pill(word ? String(word) : '—', '');
  }
  /* a word from a fixed list shown in words: bil_<kind>_<word> when there is one, else the word itself */
  function word(kind, w) { return stateText(kind, w); }
  var TERMS = ['monthly', 'quarterly', 'semiannual', 'annual', 'biennial', 'triennial'];

  /* ---- what the server sends, kept to its shape: spec names each member's kind ('id', 'c' cents or 0, 'n' a whole number or null,
     'b' true or false, 'd' a day, 'w' a time, [max] text of up to max characters, ['=', list] one of the words of list or '') ---- */
  function pick(v, spec) {
    if (!v || typeof v !== 'object') { return null; }
    var out = {};
    Object.keys(spec).forEach(function (k) {
      var s = spec[k];
      var x = v[k];
      if (s === 'id') { out[k] = id(x); } else if (s === 'c') { var c = cents(x); out[k] = c === null ? 0 : c; } else if (s === 'n') { out[k] = whole(x); } else if (s === 'b') { out[k] = x === true; } else if (s === 'd') { out[k] = str(x, 10); } else if (s === 'w') { out[k] = str(x, 40); } else if (Array.isArray(s) && s[0] === '=') { out[k] = s[1].indexOf(x) >= 0 ? x : ''; } else if (Array.isArray(s)) { out[k] = str(x, s[0]); }
    });
    return out;
  }
  function pickAll(list, spec, need) {
    return (Array.isArray(list) ? list : []).map(function (x) { var p = pick(x, spec); return p && (!need || p[need]) ? p : null; }).filter(Boolean);
  }
  function words(list, re, max) {
    return (Array.isArray(list) ? list : []).filter(function (x) { return typeof x === 'string' && (re || /^[a-z_]{1,40}$/).test(x); }).slice(0, max || 50);
  }
  var SERVICE = {id: 'id', customer_id: 'id', order_id: 'id', plan_id: 'id', plan_name: [60], package: [64], term: ['=', TERMS], status: ['=', ['active', 'suspended', 'cancelled', 'terminated']],
    currency: [3], renewal_cents: 'c', started_on: 'd', next_due: 'd', periods: 'n', username: [32], suspend_reason: [20], created: 'w'};
  var TX = {id: 'id', customer_id: 'id', invoice_id: 'id', kind: ['=', ['payment', 'refund']], gateway: [40], method: [40], status: ['=', ['pending', 'succeeded', 'failed']], currency: [3],
    amount_cents: 'c', refunded_cents: 'c', refund_of: 'id', reference: [100], note: [200], error: [300], by: [64], created: 'w'};
  function cleanService(x) { var s = pick(x, SERVICE); return s && s.id ? s : null; }
  function cleanTx(x) { var s = pick(x, TX); return s && s.id && s.kind ? s : null; }
  function termText(term) { return term ? word('term', term) : '—'; }
  function methodText(m) { return m ? word('method', m) : '—'; }
  function gatewayText(g) { return g ? word('gateway', g) : '—'; }

  /* ---- the client of a row, by name: the names a page knows are in cache; the others are read one by one, up to twenty at a time ---- */
  function namesFor(cache, ids) {
    var want = ids.filter(function (cid, i) { return cid && !cache[cid] && ids.indexOf(cid) === i; }).slice(0, 20);
    return Promise.all(want.map(function (cid) {
      return FP.call('get', 'billingCustomer', undefined, {id: String(cid)}).then(function (r) {
        var c = cleanCustomer(r);
        if (c) { cache[c.id] = c.name; }
      }, function () { /* the id stands in for the name */ });
    }));
  }
  function nameIn(cache, cid) { return cid && cache[cid] ? cache[cid] : cid ? t('binv_client_n', {id: String(cid)}) : '—'; }
  /* a client's name as a link to their page on Clients (when this login has it), or as text */
  function clientLink(cache, cid) {
    var name = nameIn(cache, cid);
    if (!cid || !FP.tools.billing_clients) { return name; }
    return button('open-client', name, 'sig-btn--link fp-bil-link', {'data-fp-id': String(cid), 'aria-label': t('binv_open_client', {name: name})});
  }

  /* ---- a client picker: a list of clients to choose from, and a search that fills it, so a panel with thousands of clients is never read
     whole. The list keeps the chosen client while a search shows others. opts: name (the control's name, customer_id by default), label,
     placeholder, value and valueName (the client chosen now), active (only active clients), clients (a first list already read), hint ---- */
  function clientPicker(pre, opts) {
    opts = opts || {};
    var label = function (c) { return c.name + (c.company ? ' (' + c.company + ')' : ''); };
    var sel = select(pre, opts.name || 'customer_id', [['', opts.placeholder || t('bil_any')]], '', opts.required ? {'aria-required': 'true'} : null);
    var find = input(pre + '-find', 'find_client', '', {type: 'search', maxlength: '100', spellcheck: 'false', autocapitalize: 'none', 'aria-controls': pre, enterkeyhint: 'search'});
    var said = el('span', {class: 'sig-hint fp-bil-picker-said', id: pre + '-find-said', role: 'status'});
    var seq = 0;
    var timer = 0;
    function fill(list, keep) {
      var cur = sel.value;
      var curText = cur && sel.selectedOptions[0] ? sel.selectedOptions[0].textContent : '';
      var placeholder = sel.options[0];
      sel.textContent = '';
      sel.appendChild(placeholder);
      var have = {};
      if (keep && cur && !list.some(function (c) { return String(c.id) === cur; })) { sel.appendChild(el('option', {value: cur, text: curText})); have[cur] = true; }
      list.forEach(function (c) { if (!have[c.id]) { sel.appendChild(el('option', {value: String(c.id), text: label(c)})); } });
      sel.value = cur && (have[cur] || list.some(function (c) { return String(c.id) === cur; })) ? cur : '';
    }
    function search(q, quiet) {
      var mine = ++seq;
      return FP.call('get', 'billingCustomers', undefined, {limit: '50', offset: '0', q: q, status: opts.active ? 'active' : ''}).then(function (r) {
        if (mine !== seq) { return; }
        var list = (r && Array.isArray(r.customers) ? r.customers : []).map(cleanCustomer).filter(Boolean);
        list.sort(function (a, b) { return a.name.localeCompare(b.name, 'en'); });
        fill(list, true);
        var total = whole(r && r.total) || list.length;
        if (!quiet) { said.textContent = !list.length ? t('bil_pick_none') : total > list.length ? t('bil_pick_some', {n: num(list.length), total: num(total)}) : list.length === 1 ? t('bil_pick_1') : t('bil_pick_n', {n: num(list.length)}); }
      }, function (err) {
        if (mine === seq && !quiet) { said.textContent = err.message; }
      });
    }
    find.addEventListener('input', function () {
      window.clearTimeout(timer);
      timer = window.setTimeout(function () { search(find.value.trim()); }, 250);
    });
    /* Enter searches at once and never sends the form the picker sits in */
    find.addEventListener('keydown', function (e) {
      if (e.key !== 'Enter') { return; }
      e.preventDefault();
      window.clearTimeout(timer);
      search(find.value.trim());
    });
    var first = (opts.clients || []).filter(function (c) { return !opts.active || c.status === 'active'; });
    if (opts.value && opts.valueName && !first.some(function (c) { return c.id === Number(opts.value); })) { first = [{id: Number(opts.value), name: opts.valueName, company: ''}].concat(first); }
    fill(first, false);
    if (opts.value) { sel.value = String(opts.value); }
    var ready = opts.clients ? Promise.resolve() : search('', true).then(function () { if (opts.value) { sel.value = String(opts.value); } });
    find.setAttribute('aria-describedby', pre + '-find-hint ' + pre + '-find-said');
    var node = el('div', {class: 'fp-bil-picker', 'data-fp-picker': pre}, [M().field(pre, opts.label || t('binv_client'), sel, opts.hint || null),
      el('div', {class: 'sig-field fp-bil-picker-find'}, [el('label', {class: 'sig-label', for: pre + '-find', text: t('bil_find_client')}), find,
        el('span', {class: 'sig-hint', id: pre + '-find-hint', text: t('bil_find_client_hint')}), said])]);
    return {node: node, select: sel, find: find, ready: ready};
  }
  function M() { return FP.mail; }

  /* ---- lines, written on a new invoice, a draft invoice and a draft quote: a line as typed is {description, quantity, unit, no_tax},
     each the text of its field; amounts and the sum are worked out in whole cents as the server does ---- */
  function typedOf(l) { return {description: l.description, quantity: String(l.quantity), unit: amountText(l.unit_cents), no_tax: l.no_tax}; }
  function blankLine() { return {description: '', quantity: '1', unit: '', no_tax: false}; }
  function lineAmount(l) {
    var q = /^[0-9]{1,6}$/.test(String(l.quantity).trim()) ? parseInt(l.quantity, 10) : null;
    var u = parseAmount(l.unit, true);
    return q === null || u === null ? null : q * u;
  }
  function emptyLine(l) { return !l.description.trim() && !l.unit.trim() && (!l.quantity.trim() || l.quantity.trim() === '1'); }
  /* the lines editor; heading names its table for a screen reader. Add line and Remove line are its own buttons */
  function linesBox(pre, typed, heading) {
    var box = el('div', {class: 'fp-binv-lines', 'data-fp-lines': pre, 'data-fp-heading': heading || t('binv_lines_table')});
    drawLines(box, typed.length ? typed : [blankLine()]);
    box.addEventListener('input', function () { sums(box); });
    box.addEventListener('change', function () { sums(box); });
    box.addEventListener('click', function (e) {
      var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
      if (!b || b.disabled || !box.contains(b)) { return; }
      var a = b.getAttribute('data-fp-act');
      if (a === 'line-add') {
        var more = typedIn(box).concat([blankLine()]);
        if (more.length > 100) { return; }
        drawLines(box, more);
        box.querySelector('[name="lines.' + more.length + '.description"]').focus();
      } else if (a === 'line-remove') {
        var n = Number(b.getAttribute('data-fp-line'));
        var left = typedIn(box).filter(function (_, i) { return i !== n - 1; });
        drawLines(box, left.length ? left : [blankLine()]);
        var next = box.querySelector('[data-fp-act="line-remove"][data-fp-line="' + Math.min(n, left.length || 1) + '"]');
        (next && !next.disabled ? next : box.querySelector('[data-fp-act="line-add"]')).focus();
      }
    });
    return box;
  }
  function drawLines(box, typed) {
    var pre = box.getAttribute('data-fp-lines');
    var hid = pre + '-lines-h';
    box.textContent = '';
    var rows = typed.map(function (l, i) {
      var n = i + 1;
      var f = function (k) { return 'lines.' + n + '.' + k; };
      return el('tr', {'data-fp-line': String(n)}, [
        el('td', {class: 'fp-binv-desc'}, [el('input', {class: 'sig-input', type: 'text', id: pre + '-l' + n + '-d', name: f('description'), value: l.description, maxlength: '200',
          autocomplete: 'off', 'aria-label': t('binv_line_desc', {n: n})})]),
        el('td', {class: 'fp-binv-qty'}, [el('input', {class: 'sig-input', type: 'text', inputmode: 'numeric', id: pre + '-l' + n + '-q', name: f('quantity'), value: l.quantity,
          maxlength: '6', autocomplete: 'off', 'aria-label': t('binv_line_qty', {n: n})})]),
        el('td', {class: 'fp-binv-unit'}, [el('input', {class: 'sig-input', type: 'text', inputmode: 'decimal', id: pre + '-l' + n + '-u', name: f('unit_cents'), value: l.unit,
          maxlength: '16', autocomplete: 'off', 'aria-label': t('binv_line_unit', {n: n})})]),
        el('td', {class: 'fp-binv-notax'}, [el('label', {class: 'fp-bil-check', for: pre + '-l' + n + '-t'}, [el('input', {type: 'checkbox', id: pre + '-l' + n + '-t', name: f('no_tax'),
          checked: l.no_tax ? true : null}), el('span', {class: 'sig-vh', text: t('binv_line_notax', {n: n})}), el('span', {'aria-hidden': 'true', text: t('binv_notax_short')})])]),
        el('td', {class: 'fp-bil-num', 'data-fp-amount': ''}),
        el('td', {class: 'fp-bil-acts'}, [button('line-remove', t('bil_remove'), 'sig-btn--secondary sig-btn--sm', {'data-fp-line': String(n), 'aria-label': t('binv_line_remove', {n: n})})])]);
    });
    box.appendChild(el('h3', {class: 'fp-h3 sig-vh', id: hid, text: box.getAttribute('data-fp-heading')}));
    box.appendChild(table(hid, 'fp-binv-edit-table', [th(t('binv_col_desc')), th(t('binv_col_qty')), th(t('binv_col_unit')), th(t('binv_col_notax')),
      th(t('binv_col_amount'), 'fp-bil-num'), el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('acct_actions')})])], rows));
    box.appendChild(el('div', {class: 'fp-binv-lines-foot'}, [button('line-add', t('binv_line_add'), 'sig-btn--secondary sig-btn--sm', {name: 'lines'}),
      el('p', {class: 'fp-binv-sum', 'data-fp-sum': ''})]));
    sums(box);
  }
  function typedIn(box) {
    return Array.prototype.map.call(box.querySelectorAll('tr[data-fp-line]'), function (tr) {
      var v = function (s) { return tr.querySelector(s).value; };
      return {description: v('[name$=".description"]'), quantity: v('[name$=".quantity"]'), unit: v('[name$=".unit_cents"]'), no_tax: tr.querySelector('[name$=".no_tax"]').checked};
    });
  }
  function sums(box) {
    var total = 0;
    var all = true;
    var typed = typedIn(box);
    Array.prototype.forEach.call(box.querySelectorAll('tr[data-fp-line]'), function (tr, i) {
      var a = lineAmount(typed[i]);
      var empty = !typed[i].description.trim() && !typed[i].unit.trim();
      tr.querySelector('[data-fp-amount]').textContent = a === null ? '—' : money(a, 'USD');
      if (a === null) { if (!empty) { all = false; } } else { total += a; }
    });
    box.querySelector('[data-fp-sum]').textContent = all ? t('binv_lines_sum', {amount: money(total, 'USD')}) : t('binv_lines_sum_unsure');
    var removes = box.querySelectorAll('[data-fp-act="line-remove"]');
    for (var i = 0; i < removes.length; i++) { removes[i].disabled = removes.length === 1; }
  }
  /* the lines to send, or null with the field marked; a line left wholly empty is left out */
  function readLines(form, box) {
    var out = [];
    var trs = box.querySelectorAll('tr[data-fp-line]');
    var typed = typedIn(box);
    for (var i = 0; i < typed.length; i++) {
      var l = typed[i];
      var tr = trs[i];
      var n = i + 1;
      if (emptyLine(l)) { continue; }
      if (!l.description.trim()) { M().fieldError(form, tr.querySelector('[name$=".description"]'), t('binv_line_desc_needed', {n: n})); return null; }
      if (!/^[0-9]{1,6}$/.test(l.quantity.trim()) || parseInt(l.quantity, 10) < 1 || parseInt(l.quantity, 10) > 100000) {
        M().fieldError(form, tr.querySelector('[name$=".quantity"]'), t('binv_line_qty_bad', {n: n}));
        return null;
      }
      var u = parseAmount(l.unit, true);
      if (u === null) { M().fieldError(form, tr.querySelector('[name$=".unit_cents"]'), t('binv_line_unit_bad', {n: n})); return null; }
      out.push({description: l.description.trim(), quantity: parseInt(l.quantity, 10), unit_cents: u, no_tax: l.no_tax});
    }
    return out;
  }
  /* a refusal about lines.N... is about the Nth line sent; empty lines were left out, so N is found among the lines that were sent */
  function linesFailed(form, box, err) {
    var m = err && typeof err.field === 'string' ? /^lines\.([0-9]+)\.([a-z_]+)$/.exec(err.field) : null;
    if (m) {
      var at = 0;
      var trs = box.querySelectorAll('tr[data-fp-line]');
      var typed = typedIn(box);
      for (var i = 0; i < typed.length; i++) {
        if (emptyLine(typed[i])) { continue; }
        at++;
        if (at === Number(m[1])) {
          M().fieldError(form, trs[i].querySelector('[name$=".' + m[2] + '"]'), t('binv_line_n', {n: i + 1}) + ' ' + err.message);
          return;
        }
      }
    }
    failed(form, err);
  }
  /* fixed lines and the totals block, as an invoice and a quote show them */
  function linesTable(hid, lines, currency) {
    return table(hid, 'fp-binv-lines-table', [th(t('binv_col_desc')), th(t('binv_col_qty'), 'fp-bil-num'), th(t('binv_col_unit'), 'fp-bil-num'), th(t('binv_col_amount'), 'fp-bil-num')],
      lines.map(function (l) {
        return el('tr', null, [el('td', {class: 'fp-bil-wrap fp-binv-desc', text: l.description + (l.no_tax ? ' ' + t('binv_no_tax_mark') : '')}), el('td', {class: 'fp-bil-num', text: num(l.quantity)}),
          el('td', {class: 'fp-bil-num', text: money(l.unit_cents, currency)}), el('td', {class: 'fp-bil-num', text: money(l.amount_cents, currency)})]);
      }));
  }
  function totalsBlock(pairs) {
    return el('dl', {class: 'fp-binv-totals', 'data-fp-totals': ''}, pairs.map(function (p, i) {
      return el('div', {class: 'fp-binv-total' + (i === pairs.length - 1 ? ' is-due' : '')}, [el('dt', {text: p[0]}), el('dd', {text: p[1]})]);
    }));
  }

  /* ---- a page's screen: what it shows now, and what takes focus ---- */
  function screen(page, nodes, focus) {
    page.textContent = '';
    nodes.forEach(function (n) { if (n) { page.appendChild(n); } });
    var target = focus ? page.querySelector(focus) : null;
    if (target) { target.focus(); }
  }
  function card(id, title, parts, cls, name) {
    var c = M().card(id, title, parts, cls);
    if (name) { c.setAttribute('data-fp-card', name); }
    return c;
  }

  /* ---- a list with filters and pages of fifty, as the billing lists share it. cfg: page (the page element), pre (the id prefix), title,
     before (nodes above the filters: a toolbar, a note), filters ([{name, label, control(value), hint}]: each control gets its name and the value
     now), blank (the filters cleared), load(filters, offset, limit) -> Promise {items, total}, heads ([th]), row(item) -> tr, tableCls, none
     and noneMatch (the empty texts), found(total) -> text, alive() (false once the page has gone). The list's buttons are its own. ---- */
  function lister(cfg) {
    var PAGE = cfg.pageSize || 50;
    var start = Object.assign({}, cfg.blank, cfg.start || {});
    var L = {filters: Object.assign({}, start), offset: 0, data: null};
    function filtered() { return Object.keys(cfg.blank).some(function (k) { return String(L.filters[k] || '') !== String(start[k] || ''); }); }
    function load() {
      return cfg.load(L.filters, L.offset, PAGE).then(function (r) {
        var total = whole(r.total);
        if (!r.items.length && L.offset > 0 && total) {
          L.offset = Math.floor((total - 1) / PAGE) * PAGE;
          return load();
        }
        L.data = {items: r.items, total: total === null ? r.items.length : total};
        return L.data;
      });
    }
    function results() {
      var d = L.data;
      if (!d.items.length) { return [el('p', {class: 'fp-muted fp-bil-empty', 'data-fp-empty': '', text: filtered() ? cfg.noneMatch : cfg.none})]; }
      var out = [el('p', {class: 'fp-muted', 'data-fp-count': '', text: d.total === 1 ? t('bil_range_1') :
        t('bil_range', {from: num(L.offset + 1), to: num(L.offset + d.items.length), total: num(d.total)})}), table(cfg.pre + '-list-h', cfg.tableCls, cfg.heads, d.items.map(cfg.row))];
      if (d.total > PAGE) {
        var prev = button('list-prev', t('bil_prev'));
        var next = button('list-next', t('bil_next'));
        prev.disabled = L.offset === 0;
        next.disabled = L.offset + PAGE >= d.total;
        out.push(el('div', {class: 'fp-actions'}, [prev, next]));
      }
      return out;
    }
    function form() { return cfg.page.querySelector('[data-fp-list="' + cfg.pre + '"] .fp-bil-filters'); }
    function draw(focus) {
      var box = cfg.page.querySelector('[data-fp-list="' + cfg.pre + '"] [data-fp-results]');
      if (!box) { return; }
      box.textContent = '';
      results().forEach(function (n) { box.appendChild(n); });
      var clear = cfg.page.querySelector('[data-fp-list="' + cfg.pre + '"] [data-fp-act="list-clear"]');
      if (clear) { clear.hidden = !filtered(); }
      var target = focus ? cfg.page.querySelector(focus) : null;
      if (target) { target.focus(); }
    }
    function filterForm() {
      var controls = {};
      var row = cfg.filters.map(function (f) {
        var node = f.control(L.filters[f.name]);
        controls[f.name] = node.node ? node.select : node;
        return node.node || M().field(cfg.pre + '-f-' + f.name, f.label, node, f.hint || null);
      });
      var f = el('form', {class: 'fp-form fp-bil-filters', novalidate: '', role: 'search', 'aria-label': cfg.findLabel}, [M().errorLine(), M().statusLine(),
        el('div', {class: 'fp-bil-filter-row'}, row),
        el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bil_show')}),
          button('list-clear', t('bil_clear'), 'sig-btn--secondary', {hidden: filtered() ? null : true})])]);
      f.addEventListener('submit', function (e) {
        e.preventDefault();
        var b = f.querySelector('.fp-submit');
        if (!begin(f, b)) { return; }
        Object.keys(controls).forEach(function (k) { var c = controls[k]; L.filters[k] = c.type === 'checkbox' ? c.checked : c.value.trim(); });
        L.offset = 0;
        L.refresh(b, cfg.focusAfter || null);
      });
      L.controls = controls;
      return f;
    }
    L.card = function () {
      var c = card(cfg.pre + '-list-h', cfg.title, (cfg.before ? cfg.before() : []).concat([cfg.filters.length ? filterForm() : el('div', null, [M().errorLine(), M().statusLine()]),
        el('div', {'data-fp-results': ''})]), cfg.pre + '-list', 'list');
      c.setAttribute('data-fp-list', cfg.pre);
      c.addEventListener('click', function (e) {
        var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
        if (!b || b.disabled) { return; }
        var a = b.getAttribute('data-fp-act');
        if (a === 'list-clear') {
          L.filters = Object.assign({}, start);
          L.offset = 0;
          Object.keys(L.controls || {}).forEach(function (k) { var x = L.controls[k]; if (x.type === 'checkbox') { x.checked = Boolean(start[k]); } else { x.value = start[k] || ''; } });
          var finds = c.querySelectorAll('[name="find_client"]');
          for (var i = 0; i < finds.length; i++) { finds[i].value = ''; }
          L.refresh(null, cfg.focusAfter || null);
        } else if (a === 'list-prev' || a === 'list-next') {
          L.offset = Math.max(0, L.offset + (a === 'list-next' ? PAGE : -PAGE));
          L.refresh(b, '#' + cfg.pre + '-list-h');
        }
      });
      return c;
    };
    L.say = function (text) { var f = form() || cfg.page.querySelector('[data-fp-list="' + cfg.pre + '"]'); if (f) { M().say(f, text); } };
    L.error = function (err) { var f = form() || cfg.page.querySelector('[data-fp-list="' + cfg.pre + '"]'); if (f) { failed(f, err); } };
    L.refresh = function (b, focus, said) {
      if (b) { UI.setBusy(b, true); }
      return load().then(function (d) {
        if (!cfg.alive()) { return; }
        if (b) { UI.setBusy(b, false); }
        draw(focus);
        if (said) { L.say(said); } else if (b && b.classList.contains('fp-submit')) { L.say(cfg.found(d.total)); }
      }, function (err) {
        if (!cfg.alive()) { return; }
        if (b) { UI.setBusy(b, false); }
        L.error(err);
      });
    };
    /* the whole list in place of what the page showed; nodes go above it */
    L.show = function (focus, said, nodes) {
      screen(cfg.page, [el('p', {class: 'fp-muted', text: t('loading')})]);
      return load().then(function () {
        if (!cfg.alive()) { return; }
        screen(cfg.page, (nodes || []).concat([L.card()]));
        draw();
        if (focus) { (cfg.page.querySelector(focus) || cfg.page.querySelector('#' + cfg.pre + '-list-h')).focus(); }
        if (said) { L.say(said); }
      }, function (err) {
        if (!cfg.alive()) { return; }
        screen(cfg.page, [FP.empty(cfg.title, err.message, button('list-reload', t('bil_try_again')))]);
        cfg.page.querySelector('[data-fp-act="list-reload"]').addEventListener('click', function () { L.show(focus, said, nodes); });
      });
    };
    return L;
  }
  /* a list read for a filter: the API's page as {items, total}, each item cleaned */
  function listOf(name, arg, key, clean) {
    return FP.call('get', name, undefined, arg).then(function (r) {
      return {items: (r && Array.isArray(r[key]) ? r[key] : []).map(clean).filter(Boolean), total: whole(r && r.total)};
    });
  }

  /* ---- a form's fields from a list of specs, and what they hold. A spec is {name, label, kind, hint, max, rows, options ([value, text]),
     required, num (a select of numbers, '' for none), empty (what an empty amount or number means: null, or left out)}; kind is text, textarea,
     check, select, amount (dollars typed, cents sent), number, date, percent (a percent typed, hundredths sent) or picks (a box for each of
     options, the numbers ticked sent as a list in the options' order) ---- */
  function bpText(bp) { if (bp === null || bp === undefined) { return ''; } var f = String(bp % 100); return String((bp - (bp % 100)) / 100) + (bp % 100 ? '.' + (f.length < 2 ? '0' + f : f).replace(/0$/, '') : ''); }
  function parseBp(text) {
    var m = /^(\d{1,5})(?:\.(\d{1,2}))?$/.exec(String(text || '').trim().replace(/%$/, ''));
    if (!m) { return null; }
    var v = parseInt(m[1], 10) * 100 + parseInt(((m[2] || '') + '00').slice(0, 2), 10);
    return v <= 10000 ? v : null;
  }
  function fieldsOf(pre, specs, item) {
    return specs.map(function (f) {
      var fid = pre + '-' + f.name.replace(/[^a-z0-9_]/g, '-');
      var v = item ? item[f.name] : f.value;
      var control;
      if (f.kind === 'textarea') {
        control = el('textarea', {class: 'sig-input fp-bil-text', id: fid, name: f.name, rows: String(f.rows || 4), maxlength: String(f.max || 2000)});
        control.value = v || '';
      } else if (f.kind === 'check') {
        control = el('input', {type: 'checkbox', id: fid, name: f.name, checked: v ? true : null});
        if (f.hint) { control.setAttribute('aria-describedby', fid + '-hint'); }
        return el('div', {class: 'sig-field fp-bil-check-field', 'data-fp-field': f.name}, [el('label', {class: 'fp-bil-check', for: fid}, [control, el('span', {text: f.label})]),
          f.hint ? el('span', {class: 'sig-hint', id: fid + '-hint', text: f.hint}) : null]);
      } else if (f.kind === 'select') {
        control = select(fid, f.name, f.options, v === null || v === undefined ? '' : String(v));
      } else if (f.kind === 'picks') {
        var had = Array.isArray(v) ? v.map(String) : [];
        var boxes = (f.options || []).map(function (o, i) {
          return el('label', {class: 'fp-bil-check', for: fid + '-' + i}, [el('input', {type: 'checkbox', id: fid + '-' + i, name: f.name, value: String(o[0]),
            checked: had.indexOf(String(o[0])) >= 0 ? true : null}), el('span', {text: o[1]})]);
        });
        return el('fieldset', {class: 'sig-field fp-bil-picks' + (f.wide ? ' fp-bil-wide' : ''), 'data-fp-field': f.name, 'aria-describedby': f.hint ? fid + '-hint' : null},
          [el('legend', {class: 'sig-label', text: f.label})].concat(boxes.length ? boxes : [el('p', {class: 'fp-muted', text: f.none || '—'})])
            .concat([f.hint ? el('span', {class: 'sig-hint', id: fid + '-hint', text: f.hint}) : null]));
      } else {
        var shown = f.kind === 'amount' ? (v === null || v === undefined ? '' : amountText(v)) : f.kind === 'percent' ? bpText(v) : v === null || v === undefined ? '' : String(v);
        control = input(fid, f.name, shown, {type: f.kind === 'date' ? 'date' : 'text', maxlength: String(f.max || (f.kind === 'amount' ? 16 : f.kind === 'number' || f.kind === 'percent' ? 8 : 200)),
          inputmode: f.kind === 'amount' || f.kind === 'percent' ? 'decimal' : f.kind === 'number' ? 'numeric' : null,
          class: 'sig-input' + (f.kind === 'amount' || f.kind === 'number' || f.kind === 'percent' ? ' fp-bil-amount' : f.kind === 'date' ? ' fp-binv-date' : ''),
          spellcheck: f.code ? 'false' : null, autocapitalize: f.code ? 'none' : null});
      }
      if (f.required) { control.setAttribute('aria-required', 'true'); }
      var node = M().field(fid, f.label, control, f.hint || null);
      node.setAttribute('data-fp-field', f.name);
      if (f.wide) { node.classList.add('fp-bil-wide'); }
      return node;
    });
  }
  /* what the form holds, as the API takes it: {body} or null with the field marked. old (the item changed) leaves out what did not change */
  function readFields(form, specs, old) {
    var body = {};
    for (var i = 0; i < specs.length; i++) {
      var f = specs[i];
      var c = UI.fieldNamed(form, f.name);
      if (!c) { continue; }
      var v;
      if (f.kind === 'picks') {
        v = Array.prototype.slice.call(form.querySelectorAll('input[type="checkbox"][name="' + f.name + '"]')).filter(function (x) { return x.checked; })
          .map(function (x) { return Number(x.value); });
        if (f.required && !v.length) { M().fieldError(form, c, t('bil_pick_one', {name: f.label})); return null; }
        if (old && Array.isArray(old[f.name]) && old[f.name].join(',') === v.join(',')) { continue; }
        body[f.name] = v;
        continue;
      }
      if (f.kind === 'check') {
        v = c.checked;
      } else if (f.kind === 'amount' || f.kind === 'number' || f.kind === 'percent') {
        var raw = c.value.trim();
        if (!raw) {
          if (f.required) { M().fieldError(form, c, t('bil_needed', {name: f.label})); return null; }
          if (f.empty === undefined) { continue; }
          v = f.empty;
        } else {
          v = f.kind === 'amount' ? parseAmount(raw, false) : f.kind === 'percent' ? parseBp(raw) : /^[0-9]{1,9}$/.test(raw) ? Number(raw) : null;
          if (v === null) { M().fieldError(form, c, t(f.kind === 'amount' ? 'bil_amount_any_bad' : f.kind === 'percent' ? 'bil_percent_bad' : 'bil_number_bad')); return null; }
        }
      } else if (f.kind === 'select' && f.num) {
        v = c.value ? Number(c.value) : null;
      } else {
        v = f.kind === 'textarea' ? c.value : c.value.trim();
        if (f.required && !String(v).trim()) { M().fieldError(form, c, t('bil_needed', {name: f.label})); return null; }
      }
      if (old) {
        var was = old[f.name];
        if (f.kind === 'textarea' ? String(was || '').trim() === String(v).trim() : (was === undefined ? null : was) === v || (was === null && v === '')) { continue; }
      } else if (v === '' && !f.send_empty) {
        continue;
      }
      body[f.name] = v;
    }
    return body;
  }

  /* ---- a table of records with a form to add one and to change one, and Remove asked first on the row. cfg: page, pre, title, what (nodes
     above the table), load() -> Promise [items], heads, cells(item) -> [td], fields (specs) or fieldsFor(item), add (PATHS key, or null for
     none), item (PATHS key with {id}), idOf(item), nameOf(item), removable(item), patchOnly (send only changes), strings: {none, addTitle,
     editTitle(name), added(name), saved(name), removed(name), removeAsk(name), removeYes, addSave}, rowActs(item) -> [buttons], onAct(act, id,
     button) for those, alive(). ---- */
  function crud(cfg) {
    var S = cfg.strings;
    var R = {items: [], editing: null};
    function idOf(x) { return cfg.idOf ? cfg.idOf(x) : x.id; }
    function find(v) { for (var i = 0; i < R.items.length; i++) { if (String(idOf(R.items[i])) === String(v)) { return R.items[i]; } } return null; }
    function row(x) {
      var name = cfg.nameOf(x);
      var acts = (cfg.rowActs ? cfg.rowActs(x) : []).concat([
        cfg.item && (!cfg.editable || cfg.editable(x)) ? button('crud-edit', t('bil_change'), 'sig-btn--secondary sig-btn--sm', {'data-fp-key': String(idOf(x)), 'aria-label': t('bil_change_of', {name: name})}) : null,
        cfg.item && (!cfg.removable || cfg.removable(x)) ? button('crud-remove', t('bil_remove'), 'sig-btn--secondary sig-btn--sm fp-btn-danger-text', {'data-fp-key': String(idOf(x)), 'aria-label': t('bil_remove_of', {name: name})}) : null]).filter(Boolean);
      return el('tr', {'data-fp-row': String(idOf(x))}, cfg.cells(x).concat([el('td', {class: 'fp-bil-acts'}, acts.length ? [el('div', {class: 'fp-bil-row-acts'}, acts)] : [])]));
    }
    function formCard(x) {
      var specs = cfg.fieldsFor ? cfg.fieldsFor(x) : cfg.fields;
      var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: x ? t('bil_save_changes') : S.addSave});
      var form = el('form', {class: 'fp-form fp-bil-crud-form', novalidate: '', 'aria-labelledby': cfg.pre + '-form-h', 'data-fp-editing': x ? String(idOf(x)) : ''}, [M().errorLine(), M().statusLine(),
        el('div', {class: 'fp-bil-grid'}, fieldsOf(cfg.pre + '-f', specs, x)), el('div', {class: 'fp-actions'}, [save, x ? button('crud-cancel', t('cancel')) : null])]);
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!begin(form, save)) { return; }
        var body = readFields(form, specs, x && cfg.patchOnly !== false ? x : null);
        if (!body) { return; }
        if (cfg.check) { var bad = cfg.check(body, x, form); if (bad) { return; } }
        if (x && !Object.keys(body).length) { M().say(form, t('bil_nothing_changed')); return; }
        UI.setBusy(save, true);
        var call = x ? FP.call(cfg.itemMethod || 'patch', cfg.item, body, cfg.argOf ? cfg.argOf(x) : {id: String(idOf(x))}) : FP.call('post', cfg.add, body, cfg.addArg || undefined);
        call.then(function (r) {
          if (!cfg.alive()) { return; }
          var name = x ? cfg.nameOf(x) : r && cfg.nameOf(cfg.clean ? cfg.clean(r) || {} : r) || '';
          R.show(x ? S.saved(name) : S.added(name), x ? '[data-fp-act="crud-edit"][data-fp-key="' + idOf(x) + '"]' : '#' + cfg.pre + '-h').then(cfg.changed || null);
        }, function (err) {
          if (!cfg.alive()) { return; }
          UI.setBusy(save, false);
          failed(form, err);
        });
      });
      return card(cfg.pre + '-form-h', x ? S.editTitle(cfg.nameOf(x)) : S.addTitle, [S.formWhat ? el('p', {class: 'fp-muted', text: S.formWhat}) : null, form].filter(Boolean), cfg.pre + '-form-card', 'form');
    }
    function listCard() {
      var parts = [M().errorLine(), M().statusLine()].concat(cfg.what ? cfg.what() : []);
      parts.push(R.items.length ? table(cfg.pre + '-h', cfg.pre + '-table', cfg.heads.concat([el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('acct_actions')})])]), R.items.map(row)) :
        el('p', {class: 'fp-muted', 'data-fp-empty': '', text: S.none}));
      if (cfg.after) { parts = parts.concat(cfg.after(R.items)); }
      return card(cfg.pre + '-h', cfg.title, parts, cfg.pre + '-list', 'list');
    }
    /* reads the records and draws the page; said goes on the list, focus is what takes focus */
    R.show = function (said, focus) {
      return cfg.load().then(function (items) {
        if (!cfg.alive()) { return; }
        R.items = items;
        R.editing = null;
        var nodes = (cfg.before ? cfg.before() : []).concat([listCard(), cfg.add && (!cfg.canAdd || cfg.canAdd(items)) ? formCard(null) : null]).concat(cfg.below ? cfg.below(items) : []);
        screen(cfg.page, nodes);
        if (said) { M().say(cfg.page.querySelector('[data-fp-card="list"]'), said); }
        var f = focus ? cfg.page.querySelector(focus) : null;
        if (f) { f.focus(); }
      }, function (err) {
        if (!cfg.alive()) { return; }
        screen(cfg.page, [FP.empty(cfg.title, err.message, button('crud-reload', t('bil_try_again')))]);
      });
    };
    R.edit = function (x) {
      var old = cfg.page.querySelector('[data-fp-card="form"]');
      var made = formCard(x);
      var listCardNow = cfg.page.querySelector('[data-fp-card="list"]');
      /* with no add form (nothing left to add), the change form goes under the list, above what cfg.below put there */
      if (old) { old.replaceWith(made); } else if (listCardNow) { listCardNow.after(made); } else { cfg.page.appendChild(made); }
      R.editing = x;
      var first = made.querySelector('input:not([type="checkbox"]), select, textarea, input');
      if (first) { first.focus(); }
    };
    cfg.page.addEventListener('click', function (e) {
      var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
      if (!b || b.disabled || !cfg.alive()) { return; }
      var a = b.getAttribute('data-fp-act');
      var key = b.getAttribute('data-fp-key');
      if (a === 'crud-reload') {
        R.show();
      } else if (a === 'crud-edit') {
        var x = find(key);
        if (!x) { return; }
        if (!cfg.fetch) { R.edit(x); return; }
        /* the list leaves out what the form needs (an article's text): the record is read first */
        UI.setBusy(b, true);
        cfg.fetch(x).then(function (full) {
          if (!cfg.alive()) { return; }
          UI.setBusy(b, false);
          R.edit(full);
        }, function (err) {
          if (!cfg.alive()) { return; }
          UI.setBusy(b, false);
          UI.showError(cfg.page.querySelector('[data-fp-card="list"]'), err.message);
          b.focus();
        });
      } else if (a === 'crud-cancel') {
        var was = R.editing;
        var old = cfg.page.querySelector('[data-fp-card="form"]');
        if (cfg.add && (!cfg.canAdd || cfg.canAdd(R.items))) { old.replaceWith(formCard(null)); } else { old.remove(); }
        R.editing = null;
        var back = was ? cfg.page.querySelector('[data-fp-act="crud-edit"][data-fp-key="' + idOf(was) + '"]') : null;
        if (back) { back.focus(); }
      } else if (a === 'crud-remove') {
        var y = find(key);
        var cell = b.closest('.fp-bil-row-acts');
        M().confirmIn(cell, S.removeAsk(y ? cfg.nameOf(y) : ''), 'crud-remove-yes', S.removeYes);
        cell.querySelector('[data-fp-act="crud-remove-yes"]').setAttribute('data-fp-key', key);
      } else if (a === 'crud-remove-yes') {
        var z = find(key);
        var listBox = cfg.page.querySelector('[data-fp-card="list"]');
        UI.setBusy(b, true);
        UI.showError(listBox, '');
        FP.call('del', cfg.item, undefined, cfg.argOf && z ? cfg.argOf(z) : {id: key}).then(function () {
          if (!cfg.alive()) { return; }
          R.show(S.removed(z ? cfg.nameOf(z) : ''), '#' + cfg.pre + '-h').then(cfg.changed || null);
        }, function (err) {
          if (!cfg.alive()) { return; }
          UI.setBusy(b, false);
          UI.showError(listBox, err.message);
          b.focus();
        });
      } else if (a === 'confirm-no' && b.closest('tr[data-fp-row]')) {
        var tr = b.closest('tr[data-fp-row]');
        var item = find(tr.getAttribute('data-fp-row'));
        if (item) { var again = row(item); tr.replaceWith(again); var r = again.querySelector('[data-fp-act="crud-remove"]'); if (r) { r.focus(); } }
      } else if (cfg.onAct) {
        cfg.onAct(a, key, b, find(key));
      }
    });
    return R;
  }

  FP.billing = {str: str, id: id, cents: cents, whole: whole, money: money, amountText: amountText, parseAmount: parseAmount, day: day, when: when, num: num,
    pill: pill, clientPill: clientPill, invoicePill: invoicePill, invoiceState: invoiceState, cleanCustomer: cleanCustomer, cleanInvoice: cleanInvoice,
    invoiceName: invoiceName, failed: failed, begin: begin, input: input, select: select, button: button, back: back, th: th, table: table, facts: facts,
    has: has, allPages: allPages, go: go, take: take, frame: frame, MAX_CENTS: MAX_CENTS,
    statePill: statePill, word: word, TERMS: TERMS, pick: pick, pickAll: pickAll, words: words, cleanService: cleanService, cleanTx: cleanTx, termText: termText,
    methodText: methodText, gatewayText: gatewayText, namesFor: namesFor, nameIn: nameIn, clientLink: clientLink, clientPicker: clientPicker,
    lines: {typedOf: typedOf, box: linesBox, read: readLines, failed: linesFailed, table: linesTable}, totalsBlock: totalsBlock, screen: screen, card: card,
    lister: lister, listOf: listOf, fieldsOf: fieldsOf, readFields: readFields, crud: crud, bpText: bpText, parseBp: parseBp};
})();

/* freePanel Varnish cache, in the admin panel (docs/api.md, "Web server", GET and PUT /web/varnish, POST /web/varnish/purge): the Varnish cache page
   (#/tool/varnish_cache). With the switch on, Varnish runs on this server's loopback between the front (nginx when the nginx front is on, Apache's own
   edge hosts when it is off) and Apache's sites, and keeps copies of the pages every visitor gets alike. Turning it on or off reloads the web server, so the
   page asks first and says what happens. The server tests every file before it reloads anything; if a test fails it puts the files back, and if a page
   does not come through Varnish it turns the cache off again and says so. Each site can be purged while the cache is on. The page shows what the server
   says and nothing it works out for itself; everything the server sends is shown as text. The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var DOMAIN_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var ACCOUNT_RE = /^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/;
  var VERSION_RE = /^[0-9][0-9A-Za-z.+-]{0,23}$/;
  var LISTEN_RE = /^127\.0\.0\.1:[0-9]{1,5}$/;
  var FRONTS = ['nginx', 'apache'];
  /* more sites than this and the list gets a box to find one by name */
  var FILTER_FROM = 12;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 400) : ''; }
  function isAdmin() { return FP.session.user.role === 'admin'; }

  /* what GET and PUT /web/varnish say, in the shapes the page draws */
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var seen = {};
    var sites = [];
    (Array.isArray(r.sites) ? r.sites : []).forEach(function (s) {
      if (!s || typeof s !== 'object' || !DOMAIN_RE.test(str(s.domain)) || seen[s.domain]) { return; }
      seen[s.domain] = true;
      sites.push({domain: s.domain, account: ACCOUNT_RE.test(str(s.account, 80)) ? s.account : ''});
    });
    sites.sort(function (a, b) { return a.domain < b.domain ? -1 : 1; });
    return {available: r.available === true, installed: r.installed === true, reason: str(r.reason), on: r.on === true, running: r.running === true,
      guard: r.guard === true, version: VERSION_RE.test(str(r.version, 40)) ? r.version : '', front: FRONTS.indexOf(r.front) >= 0 ? r.front : 'apache',
      listen: LISTEN_RE.test(str(r.listen, 40)) ? r.listen : '', sites: sites};
  }

  var V = {page: null, data: null, busy: false};
  function pill(kind, text) { return el('span', {class: 'sig-pill' + (kind ? ' sig-pill--' + kind : ''), text: text}); }
  function banner(kind, text, attr) {
    var b = el('div', {class: 'sig-banner sig-banner--' + kind, role: 'note'}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: text})]);
    if (attr) { b.setAttribute(attr, ''); }
    return b;
  }
  function canTurnOn() { return V.data.available && V.data.installed; }

  /* ---- the switch ---- */
  function row(label, value, attr) {
    var dd = el('dd', {}, [value]);
    if (attr) { dd.setAttribute(attr, ''); }
    return [el('dt', {text: label}), dd];
  }
  function facts() {
    var d = V.data;
    var items = [];
    items = items.concat(row(t('vrn_f_state'), pill(d.on ? 'ok' : '', t(d.on ? 'vrn_on' : 'vrn_off')), 'data-fp-state'));
    items = items.concat(row(t('vrn_f_varnish'), el('span', {}, [pill(d.running ? 'ok' : '', t(d.running ? 'vrn_running' : 'vrn_stopped')),
      d.version ? el('span', {class: 'fp-muted fp-row-note', text: ' ' + t('vrn_version', {version: d.version})}) : null]), 'data-fp-running'));
    items = items.concat(row(t('vrn_f_chain'), el('span', {text: t('vrn_chain_' + d.front + (d.on ? '' : '_off'))}), 'data-fp-chain'));
    if (d.on && d.listen) {
      items = items.concat(row(t('vrn_f_listen'), el('span', {class: 'sig-mono', text: t('vrn_listen_at', {listen: d.listen})}), 'data-fp-listen'));
    }
    if (d.on) {
      items = items.concat(row(t('vrn_f_guard'), pill(d.guard ? 'ok' : 'warn', t(d.guard ? 'vrn_guard_on' : 'vrn_guard_off')), 'data-fp-guard'));
    }
    items = items.concat(row(t('vrn_f_kept'), el('span', {text: t('vrn_kept')}), 'data-fp-kept'));
    return el('dl', {class: 'fp-vrn-facts'}, items);
  }
  function actions() {
    var cell = el('div', {class: 'fp-vrn-acts', 'data-fp-acts': ''});
    drawActions(cell);
    return cell;
  }
  function drawActions(cell) {
    var d = V.data;
    cell.textContent = '';
    if (d.on) {
      cell.appendChild(el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'vrn-off', text: t('vrn_turn_off')}));
    } else {
      var on = el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'vrn-on', text: t('vrn_turn_on')});
      if (!canTurnOn()) {
        on.disabled = true;
        on.setAttribute('aria-describedby', 'fp-vrn-why');
      }
      cell.appendChild(on);
    }
  }
  function switchCard() {
    var d = V.data;
    var body = [el('p', {class: 'fp-muted', text: t('vrn_intro')})];
    if (!d.available) {
      body.push(banner('warn', d.reason || t('vrn_unavailable'), 'data-fp-unavailable'));
    } else if (!d.installed && !d.on) {
      body.push(banner('warn', d.reason || t('vrn_not_installed'), 'data-fp-not-installed'));
    } else if (d.on && !d.installed) {
      body.push(banner('warn', t('vrn_gone'), 'data-fp-gone'));
    } else if (d.on && !d.running) {
      body.push(banner('warn', t('vrn_not_running'), 'data-fp-not-running'));
    }
    if (!canTurnOn() && !d.on) { body.push(el('span', {class: 'fp-vrn-why', id: 'fp-vrn-why', text: t('vrn_cannot')})); }
    body.push(facts());
    if (d.on) { body.push(el('p', {class: 'fp-muted', 'data-fp-nginx-note': '', text: t('vrn_nginx_note')})); }
    body.push(M.errorLine(), M.statusLine(), actions());
    return M.card('fp-vrn-h', t('vrn_title'), body, 'fp-vrn-switch');
  }

  /* ---- the sites ---- */
  function siteItem(s) {
    var b = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'vrn-purge', 'data-fp-site': s.domain,
      'aria-label': t('vrn_purge_of', {domain: s.domain}), text: t('vrn_purge')});
    if (!V.data.on) { b.disabled = true; }
    return el('li', {class: 'fp-vrn-item', 'data-fp-domain': s.domain}, [
      el('div', {class: 'fp-vrn-who'}, [el('span', {class: 'sig-mono fp-vrn-name', text: s.domain}),
        el('span', {class: 'fp-muted fp-row-note', text: t('vrn_account', {account: s.account || '?'})})]),
      el('div', {class: 'fp-vrn-pick'}, [b])]);
  }
  function sitesCard() {
    var d = V.data;
    var body = [];
    if (!d.sites.length) {
      body.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('vrn_no_sites')}));
      return M.card('fp-vrn-sites-h', t('vrn_sites_title'), body, 'fp-vrn-sites');
    }
    body.push(el('p', {class: 'fp-muted', text: t(d.on ? 'vrn_sites_intro_on' : 'vrn_sites_intro_off')}), M.errorLine(), M.statusLine());
    if (d.sites.length > FILTER_FROM) {
      var box = el('input', {class: 'sig-input', id: 'fp-vrn-find', type: 'search', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', maxlength: '253'});
      box.addEventListener('input', function () { find(box.value); });
      body.push(el('div', {class: 'fp-vrn-findrow'}, [M.field('fp-vrn-find', t('vrn_find'), box, t('vrn_find_hint'))]));
    }
    body.push(el('ul', {class: 'fp-vrn-list', 'aria-labelledby': 'fp-vrn-sites-h'}, d.sites.map(siteItem)));
    body.push(el('p', {class: 'fp-muted', 'data-fp-nomatch': '', hidden: '', text: t('vrn_nomatch')}));
    return M.card('fp-vrn-sites-h', t('vrn_sites_title'), body, 'fp-vrn-sites');
  }
  /* shows the sites whose name holds what was typed */
  function find(text) {
    var q = text.trim().toLowerCase();
    var shown = 0;
    var card = V.page.querySelector('.fp-vrn-sites');
    Array.prototype.forEach.call(card.querySelectorAll('li.fp-vrn-item'), function (li) {
      var hit = !q || li.getAttribute('data-fp-domain').indexOf(q) >= 0;
      li.hidden = !hit;
      if (hit) { shown++; }
    });
    card.querySelector('[data-fp-nomatch]').hidden = shown > 0;
  }
  function helpCard() {
    var parts = ['kept', 'never', 'owner'];
    return M.card('fp-vrn-help-h', t('vrn_help_title'), [el('dl', {class: 'fp-vrn-help'}, parts.reduce(function (out, k) {
      return out.concat([el('dt', {text: t('vrn_help_' + k + '_t')}), el('dd', {text: t('vrn_help_' + k)})]);
    }, []))], 'fp-vrn-help-card');
  }

  function render() {
    V.page.textContent = '';
    V.page.appendChild(switchCard());
    V.page.appendChild(sitesCard());
    V.page.appendChild(helpCard());
  }

  /* ---- doing things ---- */
  /* a failed call: the page asks the server what is true now, since a change that was tried may have been undone or may not, and shows the error in
     the card it was about */
  function failedCall(err, card) {
    var mine = V.page;
    var message = err && err.message ? err.message : t('api_failed');
    var show = function () {
      var c = V.page.querySelector(card);
      if (!c) { return; }
      UI.showError(c, message);
      var line = c.querySelector('[data-fp-error]');
      if (line && line.scrollIntoView) { line.scrollIntoView({block: 'nearest'}); }
    };
    FP.call('get', 'webVarnish').then(function (r) {
      if (V.page !== mine) { return; }
      V.data = clean(r);
      render();
      show();
    }, function () { if (V.page === mine) { show(); } });
  }
  function setSwitch(on, button) {
    if (V.busy) { return; }
    var mine = V.page;
    V.busy = true;
    UI.setBusy(button, true);
    V.page.setAttribute('aria-busy', 'true');
    FP.call('put', 'webVarnish', {on: on}).then(function (r) {
      V.busy = false;
      if (V.page !== mine) { return; }
      mine.removeAttribute('aria-busy');
      V.data = clean(r);
      render();
      M.say(V.page.querySelector('.fp-vrn-switch'), t(on ? 'vrn_now_on' : 'vrn_now_off'));
      V.page.querySelector('#fp-vrn-h').focus();
    }, function (err) {
      V.busy = false;
      if (V.page !== mine) { return; }
      mine.removeAttribute('aria-busy');
      failedCall(err, '.fp-vrn-switch');
    });
  }
  function purge(domain, button) {
    if (V.busy) { return; }
    var mine = V.page;
    var card = V.page.querySelector('.fp-vrn-sites');
    UI.showError(card, '');
    M.say(card, '');
    V.busy = true;
    UI.setBusy(button, true);
    FP.call('post', 'webVarnishPurge', {domain: domain}).then(function () {
      V.busy = false;
      if (V.page !== mine) { return; }
      UI.setBusy(button, false);
      M.say(card, t('vrn_purged', {domain: domain}));
      button.focus();
    }, function (err) {
      V.busy = false;
      if (V.page !== mine) { return; }
      UI.setBusy(button, false);
      UI.showError(card, err && err.message ? err.message : t('api_failed'));
      button.focus();
    });
  }

  document.addEventListener('click', function (e) {
    if (!V.page) { return; }
    var a = e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!a || !V.page.contains(a)) { return; }
    var act = a.getAttribute('data-fp-act');
    var cell = a.closest('[data-fp-acts]');
    if (act === 'vrn-on' || act === 'vrn-off') {
      M.confirmIn(cell, t(act === 'vrn-on' ? 'vrn_ask_on' : 'vrn_ask_off'), act + '-yes', t(act === 'vrn-on' ? 'vrn_turn_on' : 'vrn_turn_off'));
    } else if (act === 'confirm-no' && cell) {
      drawActions(cell);
      cell.querySelector('button').focus();
    } else if (act === 'vrn-on-yes' || act === 'vrn-off-yes') {
      var card = V.page.querySelector('.fp-vrn-switch');
      UI.showError(card, '');
      M.say(card, '');
      setSwitch(act === 'vrn-on-yes', a);
    } else if (act === 'vrn-purge') {
      var d = a.getAttribute('data-fp-site');
      if (DOMAIN_RE.test(d || '')) { purge(d, a); }
    }
  });

  FP.view('tool:varnish_cache', function () {
    V = {page: null, data: null, busy: false};
    var tool = FP.tools.varnish_cache;
    if (!tool || FP.realm !== 'admin' || !isAdmin()) { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('vrn_desc'), cls: 'fp-mail fp-vrn-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    if (!body) { return; }
    V.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'webVarnish').then(function (r) {
      if (V.page !== body) { return; }
      V.data = clean(r);
      render();
    }, function (err) {
      if (V.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

/* freePanel site cache, the customer's side (docs/api.md, "Web server", GET /accounts/{username}/site-cache and POST
   /accounts/{username}/site-cache/purge): the Clear site cache page (#/tool/site_cache). It lists the account's own sites, each with a button that
   clears the copies the server's Varnish cache keeps of it. The server checks that the site is the account's; the page shows what it says, as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var DOMAIN_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var C = null;

  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var seen = {};
    var sites = (Array.isArray(r.sites) ? r.sites : []).filter(function (d) {
      if (typeof d !== 'string' || !DOMAIN_RE.test(d) || seen[d]) { return false; }
      seen[d] = true;
      return true;
    }).sort();
    return {on: r.on === true, suspended: r.suspended === true, sites: sites};
  }
  function note(kind, text) {
    return el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-scc-note': kind}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: text})]);
  }
  function row(domain, frozen) {
    return el('tr', {'data-fp-site': domain}, [el('th', {scope: 'row', class: 'fp-mail-name', text: domain}),
      el('td', {class: 'fp-mail-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'scc-clear',
        disabled: frozen ? true : null, 'aria-label': t('scc_clear_named', {domain: domain}), text: t('scc_clear')})])]);
  }
  function card() {
    var d = C.data;
    var frozen = !d.on || d.suspended;
    var parts = [el('p', {class: 'fp-muted', text: t('scc_what')}), M.errorLine(), M.statusLine()];
    if (d.suspended) { parts.push(note('suspended', t('scc_suspended'))); } else if (!d.on) { parts.push(note('off', t('scc_off'))); }
    if (!d.sites.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('scc_none')}));
    } else {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-scc-h'}, [el('table', {class: 'sig-table fp-mail-table fp-scc-table'}, [
        el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('scc_col_site')}), el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]),
        el('tbody', null, d.sites.map(function (s) { return row(s, frozen); }))])]));
      if (!frozen) { parts.push(el('p', {class: 'fp-muted', text: t('scc_note')})); }
    }
    return M.card('fp-scc-h', t('scc_title'), parts, 'fp-scc');
  }
  function onClick(e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act="scc-clear"]') : null;
    if (!b || !C || !C.page.contains(b) || b.disabled) { return; }
    var domain = b.closest('tr[data-fp-site]').getAttribute('data-fp-site');
    var mine = C;
    var box = C.page.querySelector('.fp-scc');
    UI.showError(box, '');
    M.say(box, '');
    UI.setBusy(b, true);
    FP.call('post', 'acctSiteCachePurge', {domain: domain}, C.account).then(function () {
      if (C !== mine) { return; }
      UI.setBusy(b, false);
      M.say(box, t('scc_cleared', {domain: domain}));
      b.focus();
    }, function (err) {
      if (C !== mine) { return; }
      UI.setBusy(b, false);
      UI.showError(box, err.message);
      b.focus();
    });
  }
  document.addEventListener('click', onClick);

  FP.view('tool:site_cache', function () {
    C = null;
    var page = M.frame('site_cache', 'fp-scc-page');
    if (!page) { return; }
    C = {page: page, account: FP.account(), data: null};
    var mine = C;
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'acctSiteCache', undefined, C.account).then(function (r) {
      if (C !== mine) { return; }
      C.data = clean(r);
      page.textContent = '';
      page.appendChild(card());
    }, function (err) {
      if (C !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(FP.tools.site_cache.label, err.message));
    });
  });
})();

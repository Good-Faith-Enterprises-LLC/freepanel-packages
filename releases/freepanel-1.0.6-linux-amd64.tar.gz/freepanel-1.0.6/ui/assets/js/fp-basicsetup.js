/* freePanel basic setup (#/tool/server_setup): one admin page with the server's main settings as they are now, each with a link to
   the page where it changes: the host name (GET /server/hostname), the main address (GET /server/ips), the name servers
   (GET /dns/nameservers), the contact addresses (GET /server/contacts) and the home folders with their disk quotas
   (GET /home-roots). Each is read on its own; one that can't be read says so and the rest still show. Admin only. Everything the
   server sends is shown as text. The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 253) : ''; }
  function list(v, n) { return (Array.isArray(v) ? v : []).filter(function (x) { return typeof x === 'string'; }).slice(0, n || 8).map(function (x) { return x.slice(0, 254); }); }

  /* each row: what it is, how to read it from the answer, and where it changes */
  var ROWS = [
    {id: 'hostname', label: 'bsu_hostname', api: 'serverHostname', tool: 'server_hostname',
      show: function (r) { return str(r && r.hostname) || t('bsu_not_set'); }},
    {id: 'address', label: 'bsu_address', api: 'serverIps', tool: 'server_ips', show: function (r) {
      var ips = r && Array.isArray(r.ips) ? r.ips : [];
      for (var i = 0; i < ips.length; i++) { if (ips[i] && ips[i].main === true) { return str(ips[i].address, 45); } }
      return t('bsu_not_set');
    }},
    {id: 'nameservers', label: 'bsu_ns', api: 'dnsNameservers', tool: 'dns_nameservers', show: function (r) {
      var ns = list(r && r.nameservers);
      return ns.length ? ns.join(', ') : t('bsu_not_set');
    }},
    {id: 'contacts', label: 'bsu_contacts', api: 'serverContacts', tool: 'server_contacts', show: function (r) {
      var c = (r && Array.isArray(r.contacts) ? r.contacts : []).map(function (x) { return str(x && x.email, 254); }).filter(Boolean).slice(0, 10);
      return c.length ? c.join(', ') : t('bsu_no_contacts');
    }},
    {id: 'homes', label: 'bsu_homes', api: 'homeRoots', tool: 'home_move', show: function (r) {
      var roots = r && r.roots && Array.isArray(r.roots.roots) ? r.roots.roots : [];
      var p = roots.map(function (x) { return str(x && x.path, 200); }).filter(Boolean).slice(0, 10);
      return p.length ? p.join(', ') : '/home';
    }},
    {id: 'quotas', label: 'bsu_quotas', api: 'homeRoots', tool: 'home_move', plain: true, show: function (r) {
      var roots = r && r.roots && Array.isArray(r.roots.roots) ? r.roots.roots : [];
      var q = roots[0] && roots[0].quotas;
      if (!q) { return t('bsu_unknown'); }
      return q.enforced === true ? t('bsu_quotas_on') : t('bsu_quotas_off', {why: str(q.reason, 300) || t('bsu_unknown')});
    }}
  ];

  var B = {page: null};

  function row(x, answer, failed) {
    var tool = FP.tools[x.tool];
    var text = failed ? t('bsu_cant_read') : x.show(answer);
    return el('div', {class: 'fp-bsu-row', 'data-fp-bsu': x.id}, [el('dt', {text: t(x.label)}),
      el('dd', {class: failed ? 'fp-muted' : x.plain ? '' : 'sig-mono', text: text}),
      el('dd', null, [tool ? el('a', {class: 'sig-btn sig-btn--secondary sig-btn--sm', href: '#/tool/' + x.tool,
        'aria-label': t('bsu_change_where', {what: t(x.label).toLowerCase()}), text: t('bsu_change')}) : null])]);
  }

  FP.view('tool:server_setup', function () {
    var tool = FP.tools.server_setup;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('bsu_desc'), cls: 'fp-mail fp-srv fp-bsu-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    B.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    var asked = {};
    ROWS.forEach(function (x) {
      if (!asked[x.api]) {
        asked[x.api] = FP.call('get', x.api).then(function (r) { return {ok: true, r: r}; }, function () { return {ok: false}; });
      }
    });
    var apis = Object.keys(asked);
    Promise.all(apis.map(function (k) { return asked[k]; })).then(function (answers) {
      if (B.page !== body) { return; }
      var got = {};
      apis.forEach(function (k, i) { got[k] = answers[i]; });
      body.textContent = '';
      body.appendChild(M.card('fp-bsu-h', t('bsu_title'), [el('p', {class: 'fp-muted', text: t('bsu_what')}),
        el('dl', {class: 'fp-bsu-list'}, ROWS.map(function (x) { return row(x, got[x.api].r, !got[x.api].ok); }))], 'fp-bsu-card'));
    });
  });
})();

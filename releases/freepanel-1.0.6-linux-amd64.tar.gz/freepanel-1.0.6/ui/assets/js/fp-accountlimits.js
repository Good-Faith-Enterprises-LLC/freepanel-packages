/* freePanel disk and bandwidth limits per account (docs/api.md, GET /account-limits and GET and PUT /accounts/{username}/limits):
   the admin panel's page (#/tool/account_quota). It lists every account with the disk space and monthly bandwidth in force and
   what it uses, and changes one account's limits: its package's, a number of MB of its own, or no limit. Admin only. Everything
   the server sends is shown as text. The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var USER_RE = /^[a-z][a-z0-9]{0,15}$/;
  var NAME_RE = /^[A-Za-z0-9][A-Za-z0-9_. -]{0,63}$/;
  var MAX = {disk: Math.pow(2, 40), bandwidth: Math.pow(2, 40)};
  var KINDS = ['disk', 'bandwidth'];

  function str(v) { return typeof v === 'string' ? v : ''; }
  function mbOrNull(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.floor(v) : null; }
  function count(n) { return Math.round(n).toLocaleString('en'); }
  function mb(n) {
    if (n < 1024) { return t('pkg_mb', {n: count(n)}); }
    var g = n / 1024;
    if (g < 1024) { return t('pkg_gb', {n: (Math.round(g * 10) / 10).toLocaleString('en')}); }
    return t('pkg_tb', {n: (Math.round(g / 1024 * 10) / 10).toLocaleString('en')});
  }
  function limitText(v) { return v === null ? t('unlimited') : mb(v); }
  function usedText(bytes) { return bytes === null ? '—' : mb(bytes / 1048576); }

  function clean(a) {
    if (!a || typeof a !== 'object' || !USER_RE.test(str(a.username))) { return null; }
    return {username: a.username, domain: str(a.domain).slice(0, 253), owner: USER_RE.test(str(a.owner)) ? a.owner : '',
      package: NAME_RE.test(str(a.package)) ? a.package : '',
      disk: {own: a.disk_own === true, limit: mbOrNull(a.disk_mb), pkg: mbOrNull(a.package_disk_mb), used: mbOrNull(a.disk_used_bytes)},
      bandwidth: {own: a.bandwidth_own === true, limit: mbOrNull(a.bandwidth_mb), pkg: mbOrNull(a.package_bandwidth_mb),
        used: mbOrNull(a.bandwidth_used_bytes) || 0}};
  }

  var L = {page: null, list: [], open: '', filter: '', busy: false};

  function limitCell(v) {
    var pct = v.limit ? Math.round(v.used / 1048576 / v.limit * 100) : -1;
    var td = el('td', {class: 'fp-num'}, [el('span', {text: usedText(v.used) + ' / ' + limitText(v.limit)}),
      v.own ? el('span', {class: 'sig-pill sig-pill--accent fp-alim-own', text: t('alim_own')}) : null]);
    if (pct >= 0 && v.used !== null) {
      var bar = el('i');
      bar.style.width = Math.min(100, pct) + '%';
      td.appendChild(el('div', {class: 'sig-meter' + (pct >= 100 ? ' is-danger' : pct >= 80 ? ' is-warn' : ''), 'aria-hidden': 'true'}, [bar]));
    }
    return td;
  }

  function row(a) {
    return el('tr', {'data-fp-account': a.username}, [el('th', {scope: 'row'}, [el('span', {class: 'sig-mono', text: a.username}),
      a.domain ? el('span', {class: 'fp-muted fp-alim-domain', text: a.domain}) : null]),
    el('td', {text: a.owner || '—'}), el('td', {text: a.package || '—'}), limitCell(a.disk), limitCell(a.bandwidth),
    el('td', {class: 'fp-alim-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'alim-change',
      'data-fp-who': a.username, 'aria-label': t('alim_change_for', {name: a.username}), text: t('alim_change')})])]);
  }

  /* one limit's choice: the package's, a number of its own, or none */
  function chooser(a, kind) {
    var v = a[kind];
    var how = el('select', {class: 'sig-input', id: 'fp-alim-' + kind + '-how', name: kind + '_how'}, [
      el('option', {value: 'package', text: t('alim_pkg', {limit: limitText(v.pkg)})}),
      el('option', {value: 'own', text: t('alim_set')}),
      el('option', {value: 'unlimited', text: t('alim_none')})]);
    how.value = !v.own ? 'package' : v.limit === null ? 'unlimited' : 'own';
    var num = el('input', {class: 'sig-input fp-alim-mb', id: 'fp-alim-' + kind, name: kind, type: 'number', inputmode: 'numeric', min: '0', step: '1',
      max: String(MAX[kind]), autocomplete: 'off', value: v.own && v.limit !== null ? String(v.limit) : (v.pkg !== null ? String(v.pkg) : '')});
    var numField = M.field('fp-alim-' + kind, t(kind === 'disk' ? 'alim_disk_mb' : 'alim_bw_mb'), num, t(kind === 'disk' ? 'alim_disk_hint' : 'alim_bw_hint'));
    function sync() { numField.hidden = how.value !== 'own'; }
    how.addEventListener('change', sync);
    sync();
    return el('fieldset', {class: 'fp-alim-set'}, [el('legend', {class: 'sig-label', text: t(kind === 'disk' ? 'alim_disk' : 'alim_bw')}),
      M.field('fp-alim-' + kind + '-how', t('alim_which'), how), numField]);
  }

  function formCard(a) {
    var f = el('form', {class: 'fp-form fp-alim-form', novalidate: '', 'data-fp-alim-form': a.username}, [M.errorLine(), M.statusLine(),
      el('p', {class: 'fp-muted', text: t('alim_form_what', {pkg: a.package || '—'})}), chooser(a, 'disk'), chooser(a, 'bandwidth'),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('alim_save')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'alim-cancel', text: t('cancel')})])]);
    f.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(f);
      if (!b || L.busy) { return; }
      var body = {};
      for (var i = 0; i < KINDS.length; i++) {
        var k = KINDS[i];
        var how = f.querySelector('[name="' + k + '_how"]').value;
        if (how === 'own') {
          var input = f.querySelector('[name="' + k + '"]');
          var s = input.value.trim();
          var n = Number(s);
          if (!/^\d+$/.test(s) || n > MAX[k]) { M.fieldError(f, input, t('alim_bad')); return; }
          body[k] = n;
        } else {
          body[k] = how;
        }
      }
      L.busy = true;
      UI.setBusy(b, true);
      var mine = L.page;
      FP.call('put', 'accountLimits', body, a.username).then(function (r) {
        L.busy = false;
        if (L.page !== mine) { return; }
        var v = clean(r);
        if (v) { L.list = L.list.map(function (x) { return x.username === a.username ? v : x; }); }
        L.open = '';
        render(t('alim_saved', {name: a.username}));
        var back = L.page.querySelector('[data-fp-act="alim-change"][data-fp-who="' + a.username + '"]');
        if (back) { back.focus(); }
      }, function (err) {
        L.busy = false;
        if (L.page !== mine) { return; }
        UI.setBusy(b, false);
        M.failed(f, err);
      });
    });
    return M.card('fp-alim-form-h', t('alim_form_title', {name: a.username}), [f], 'fp-alim-formcard');
  }

  function render(note) {
    var page = L.page;
    page.textContent = '';
    page.appendChild(el('p', {class: 'fp-muted', text: t('alim_what')}));
    var open = null;
    for (var i = 0; i < L.list.length; i++) { if (L.list[i].username === L.open) { open = L.list[i]; } }
    if (open) { page.appendChild(formCard(open)); }
    var parts = [M.errorLine(), el('p', {class: 'fp-ok-line', role: 'status', 'data-fp-status': '', text: note || ''})];
    if (!L.list.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('alim_no_accounts')}));
      page.appendChild(M.card('fp-alim-h', t('alim_title'), parts, 'fp-alim-list'));
      return;
    }
    var filter = el('input', {class: 'sig-input', id: 'fp-alim-filter', type: 'search', autocomplete: 'off', spellcheck: 'false', maxlength: '64'});
    filter.value = L.filter;
    filter.addEventListener('input', function () {
      L.filter = filter.value.trim();
      render('');
      var f = L.page.querySelector('#fp-alim-filter');
      f.focus();
      f.setSelectionRange(f.value.length, f.value.length);
    });
    parts.push(el('div', {class: 'sig-field fp-alim-filter'}, [el('label', {class: 'sig-label', for: 'fp-alim-filter', text: t('alim_filter')}), filter]));
    var q = L.filter.toLowerCase();
    var shown = q ? L.list.filter(function (a) { return [a.username, a.domain, a.owner, a.package].join(' ').toLowerCase().indexOf(q) >= 0; }) : L.list;
    if (!shown.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('alim_no_match')}));
    } else {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-alim-h'}, [
        el('table', {class: 'sig-table fp-alim-table'}, [el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('alim_account')}),
          el('th', {scope: 'col', text: t('acct_owner')}), el('th', {scope: 'col', text: t('acct_package')}),
          el('th', {scope: 'col', class: 'fp-num', text: t('alim_disk')}), el('th', {scope: 'col', class: 'fp-num', text: t('alim_bw')}),
          el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]),
        el('tbody', null, shown.map(row))])]));
    }
    page.appendChild(M.card('fp-alim-h', t('alim_title'), parts, 'fp-alim-list'));
  }

  document.addEventListener('click', function (e) {
    var node = e.target.closest ? e.target : null;
    var b = node && node.closest('[data-fp-act]');
    if (!b || !L.page || !L.page.contains(b)) { return; }
    var a = b.getAttribute('data-fp-act');
    if (a === 'alim-change' && !L.busy) {
      L.open = b.getAttribute('data-fp-who') || '';
      render('');
      var h = L.page.querySelector('#fp-alim-form-h');
      if (h) { h.focus(); }
    } else if (a === 'alim-cancel') {
      var was = L.open;
      L.open = '';
      render('');
      var back = L.page.querySelector('[data-fp-act="alim-change"][data-fp-who="' + was + '"]');
      if (back) { back.focus(); }
    }
  });

  FP.view('tool:account_quota', function () {
    var tool = FP.tools.account_quota;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    L.list = [];
    L.open = '';
    L.filter = '';
    L.busy = false;
    var body = FP.frame({title: tool.label, desc: t('alim_desc'), cls: 'fp-mail fp-srv fp-alim-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    L.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'accountLimitsList').then(function (r) {
      if (L.page !== body) { return; }
      L.list = (r && Array.isArray(r.accounts) ? r.accounts : []).map(clean).filter(Boolean);
      render('');
    }, function (err) {
      if (L.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

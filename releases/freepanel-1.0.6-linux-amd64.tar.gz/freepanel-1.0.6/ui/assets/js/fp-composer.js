/* freePanel Composer (#/tool/composer), the customer panel's page for running composer install or composer update for a PHP project in one of
   the account's own sites (docs/api.md, "Composer"). The customer picks the site (its PHP version is the one the PHP selector set for it) and,
   if the project is not the site's folder itself, a folder in it; the server checks there is a composer.json there and runs Composer as the
   account. A run goes on in the background: its log is shown as it is written, asked for again every few seconds while it runs, and kept with
   the account's last runs to read later. Credentials are hidden on the server before anything is kept. What the server sends is drawn as text.
   It shares the mail pages' look and helpers (FP.mail). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var ACTIONS = ['install', 'update'];
  var STATUS = {running: 'cmp_st_running', done: 'cmp_st_done', failed: 'cmp_st_failed', stopped: 'cmp_st_stopped'};
  var PART = /^[A-Za-z0-9_][A-Za-z0-9_.-]{0,127}$/;
  var ID = /^[0-9]{8}T[0-9]{6}-[0-9a-f]{8}$/;
  var EVERY = 2000;
  var MAX_LINES = 500;
  var G = {page: null, account: '', state: null, sel: '', log: null, timer: 0, follow: true};

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function when(iso) {
    var d = iso ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString(undefined, {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }
  /* a folder in the site's folder: '' or names joined by /, none starting with a dot; null when it isn't one */
  function okFolder(v) {
    v = v.replace(/^\/+|\/+$/g, '');
    if (v === '') { return ''; }
    var parts = v.split('/');
    if (v.length > 255 || parts.length > 8) { return null; }
    for (var i = 0; i < parts.length; i++) { if (!PART.test(parts[i])) { return null; } }
    return v;
  }
  function cleanSite(s) {
    if (!s || typeof s !== 'object' || typeof s.domain !== 'string' || !s.domain) { return null; }
    return {domain: str(s.domain, 253), aliases: Array.isArray(s.aliases) ? s.aliases.slice(0, 50).map(function (a) { return str(a, 253); }) : [],
      folder: str(s.folder, 300), php: str(s.php_version, 10), hasPHP: s.php === true, json: s.composer_json === true, problem: str(s.problem, 400)};
  }
  function cleanJob(j) {
    if (!j || typeof j !== 'object' || !ID.test(str(j.id, 40)) || ACTIONS.indexOf(j.action) < 0 || !STATUS[j.status]) { return null; }
    return {id: j.id, action: j.action, domain: str(j.domain, 253), folder: str(j.folder, 300), sub: str(j.sub, 300), php: str(j.php_version, 10),
      noDev: j.no_dev === true, scripts: j.scripts === true, status: j.status, started: str(j.started, 40), ended: str(j.ended, 40), problem: str(j.problem, 600)};
  }
  function clean(v) {
    if (!v || typeof v !== 'object' || !v.composer || typeof v.composer !== 'object' || !Array.isArray(v.sites) || !Array.isArray(v.jobs)) { return null; }
    return {tool: {available: v.composer.available === true, version: str(v.composer.version, 40), reason: str(v.composer.reason, 400)},
      sites: v.sites.slice(0, 500).map(cleanSite).filter(Boolean), jobs: v.jobs.slice(0, 20).map(cleanJob).filter(Boolean), started: str(v.started, 40)};
  }
  function cleanLog(v) {
    if (!v || typeof v !== 'object' || !Array.isArray(v.lines) || !STATUS[v.status]) { return null; }
    return {id: str(v.id, 40), status: v.status, lines: v.lines.slice(-MAX_LINES).map(function (l) { return str(l, 1200); }), earlier: v.earlier === true, cut: v.cut === true};
  }
  function running() { return Boolean(G.state && G.state.jobs.some(function (j) { return j.status === 'running'; })); }
  function jobOf(id) {
    for (var i = 0; i < G.state.jobs.length; i++) { if (G.state.jobs[i].id === id) { return G.state.jobs[i]; } }
    return null;
  }
  function siteOf(domain) {
    for (var i = 0; i < G.state.sites.length; i++) { if (G.state.sites[i].domain === domain) { return G.state.sites[i]; } }
    return null;
  }
  function usable(s) { return !s.problem && s.hasPHP; }

  /* ---- the form that starts a run ---- */
  function siteHint(form) {
    var s = siteOf(form.querySelector('[name="domain"]').value);
    if (!s) { return ''; }
    if (s.problem) { return s.problem; }
    var sub = okFolder(form.querySelector('[name="folder"]').value.trim());
    var where = '~/' + s.folder + (sub ? '/' + sub : '');
    return t(sub || s.json ? 'cmp_site_hint' : 'cmp_site_hint_nojson', {php: s.php, folder: where});
  }
  function syncForm(form) {
    var s = siteOf(form.querySelector('[name="domain"]').value);
    var hint = form.querySelector('#fp-cmp-site-hint');
    hint.textContent = siteHint(form);
    hint.classList.toggle('fp-clb-off', Boolean(s && s.problem));
    var act = form.querySelector('[name="action"]:checked');
    form.querySelector('.fp-submit').textContent = t('cmp_run_' + (act ? act.value : 'install'));
    /* while a run goes on the button stays: the server says to wait (409), one run at a time for an account */
    form.querySelector('.fp-submit').disabled = !G.state.tool.available || !s || !usable(s);
  }
  function actionField() {
    var radios = ACTIONS.map(function (a) {
      var id = 'fp-cmp-act-' + a;
      return el('div', {class: 'fp-atok-choice'}, [el('label', {class: 'fp-check', for: id}, [
        el('input', {type: 'radio', id: id, name: 'action', value: a, checked: a === 'install' ? true : null, 'aria-describedby': id + '-hint'}),
        el('span', {text: t('cmp_action_' + a)})]),
      el('span', {class: 'sig-hint', id: id + '-hint', text: t('cmp_action_' + a + '_hint')})]);
    });
    return el('fieldset', {class: 'sig-field fp-atok-scopes'}, [el('legend', {class: 'sig-label', text: t('cmp_action')})].concat(radios));
  }
  function check(id, name, label, hint) {
    return el('div', {class: 'fp-atok-choice'}, [el('label', {class: 'fp-check', for: id}, [
      el('input', {type: 'checkbox', id: id, name: name, 'aria-describedby': id + '-hint'}), el('span', {text: label})]),
    el('span', {class: 'sig-hint', id: id + '-hint', text: hint})]);
  }
  function runCard() {
    var first = G.state.sites.filter(function (s) { return usable(s) && s.json; })[0] || G.state.sites.filter(usable)[0] || G.state.sites[0];
    var site = el('select', {class: 'sig-select', id: 'fp-cmp-site', name: 'domain', 'aria-describedby': 'fp-cmp-site-hint'}, G.state.sites.map(function (s) {
      return el('option', {value: s.domain, selected: s === first ? true : null, text: s.domain + (usable(s) ? '' : ' ' + t('cmp_site_off'))});
    }));
    var folder = el('input', {class: 'sig-input sig-mono', id: 'fp-cmp-folder', name: 'folder', type: 'text', autocomplete: 'off', spellcheck: 'false',
      autocapitalize: 'none', maxlength: '255', placeholder: t('cmp_folder_ph')});
    var form = el('form', {class: 'fp-form fp-mail-form fp-clb-form fp-cmp-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: 'fp-cmp-site', text: t('cmp_site')}), site,
        el('span', {class: 'sig-hint', id: 'fp-cmp-site-hint'})]),
      M.field('fp-cmp-folder', t('cmp_folder'), folder, t('cmp_folder_hint')),
      actionField(),
      el('fieldset', {class: 'sig-field fp-atok-scopes'}, [el('legend', {class: 'sig-label', text: t('cmp_options')}),
        check('fp-cmp-nodev', 'no_dev', t('cmp_no_dev'), t('cmp_no_dev_hint')),
        check('fp-cmp-scripts', 'scripts', t('cmp_scripts'), t('cmp_scripts_hint'))]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('cmp_run_install')})])]);
    site.addEventListener('change', function () { syncForm(form); });
    folder.addEventListener('input', function () { syncForm(form); });
    form.addEventListener('change', function (e) { if (e.target && e.target.name === 'action') { syncForm(form); } });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var s = siteOf(site.value);
      if (!s || !usable(s)) { M.fieldError(form, site, s && s.problem ? s.problem : t('cmp_site_bad')); return; }
      var sub = okFolder(folder.value.trim());
      if (sub === null) { M.fieldError(form, folder, t('cmp_folder_bad')); return; }
      var act = form.querySelector('[name="action"]:checked').value;
      var body = {domain: s.domain, folder: sub, action: act, no_dev: form.querySelector('[name="no_dev"]').checked,
        scripts: form.querySelector('[name="scripts"]').checked};
      UI.setBusy(b, true);
      FP.call('post', 'composerRuns', body, G.account).then(function (r) {
        var st = clean(r);
        UI.setBusy(b, false);
        if (!st) { M.fieldError(form, null, t('api_failed')); return; }
        G.state = st;
        G.sel = st.started || (st.jobs[0] ? st.jobs[0].id : '');
        G.log = null;
        G.follow = true;
        syncForm(form);
        drawRuns();
        M.say(form, t('cmp_started_' + act, {where: s.domain + (sub ? '/' + sub : '')}));
        loadLog();
      }, function (err) {
        UI.setBusy(b, false);
        M.failed(form, err);
        syncForm(form);
      });
    });
    var c = M.card('fp-cmp-run-h', t('cmp_run_title'), [el('p', {class: 'fp-muted', text: t('cmp_run_desc')}), form], 'fp-cmp-run');
    syncForm(form);
    return c;
  }

  /* ---- the account's runs and the log of the one chosen ---- */
  function jobWhere(j) { return j.domain + (j.sub ? '/' + j.sub : ''); }
  function jobText(j) {
    return t('cmp_job_' + j.action + '_' + j.status, {where: jobWhere(j), date: when(j.ended || j.started)});
  }
  function pill(status) {
    return el('span', {class: 'sig-pill ' + (status === 'done' ? 'sig-pill--ok' : status === 'running' ? 'sig-pill--accent' : 'sig-pill--danger'), text: t(STATUS[status])});
  }
  function drawRuns() {
    var holder = G.page.querySelector('[data-fp-runs]');
    holder.textContent = '';
    G.page.querySelector('[data-fp-empty]').hidden = G.state.jobs.length > 0;
    if (G.state.jobs.length) {
      holder.appendChild(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-cmp-runs-h'}, [
        el('table', {class: 'sig-table fp-cmp-table'}, [
          el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('cmp_col_when')}), el('th', {scope: 'col', text: t('cmp_col_what')}),
            el('th', {scope: 'col', text: t('cmp_col_status')}), el('th', {scope: 'col', class: 'fp-clb-acts', text: t('cmp_col_log')})])]),
          el('tbody', null, G.state.jobs.map(function (j) {
            var on = j.id === G.sel;
            return el('tr', {'data-fp-run': j.id, class: on ? 'fp-cmp-on' : null}, [
              el('td', {text: when(j.started)}),
              el('th', {scope: 'row', class: 'fp-cmp-what'}, [el('span', {class: 'sig-mono fp-cmp-cmd', text: 'composer ' + j.action}),
                el('span', {class: 'fp-cmp-where', text: jobWhere(j)}), el('span', {class: 'fp-muted fp-row-note', text: t('cmp_job_php', {php: j.php}) +
                  (j.noDev ? ' · --no-dev' : '') + (j.scripts ? ' · ' + t('cmp_with_scripts') : '')})]),
              el('td', null, [pill(j.status)]),
              el('td', {class: 'fp-clb-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'log',
                'aria-pressed': on ? 'true' : 'false', 'aria-label': t('cmp_log_of', {what: 'composer ' + j.action + ' ' + jobWhere(j), date: when(j.started)}),
                text: t('cmp_show_log')})])]);
          }))])]));
    }
    drawLog();
  }
  function drawLog() {
    var box = G.page.querySelector('[data-fp-log]');
    box.textContent = '';
    var j = G.sel ? jobOf(G.sel) : null;
    box.hidden = !j;
    if (!j) { return; }
    box.className = 'fp-clb-job fp-cmp-log fp-clb-job--' + j.status;
    box.appendChild(el('div', {class: 'fp-clb-job-head'}, [pill(j.status), el('h3', {class: 'fp-clb-job-what fp-h3', id: 'fp-cmp-log-h', tabindex: '-1', text: jobText(j)})]));
    if (j.status === 'running') { box.appendChild(el('p', {class: 'fp-muted', text: t('cmp_running_hint')})); }
    if (j.problem) { box.appendChild(el('p', {class: 'fp-warn-line', 'data-fp-problem': '', text: j.problem})); }
    var log = G.log && G.log.id === j.id ? G.log : null;
    if (!log) { box.appendChild(el('p', {class: 'fp-muted', text: t('loading')})); return; }
    if (log.earlier) { box.appendChild(el('p', {class: 'fp-muted', 'data-fp-earlier': '', text: t('cmp_log_earlier', {n: log.lines.length})})); }
    var pre = el('pre', {class: 'fp-clb-pre fp-cmp-pre sig-mono', tabindex: '0', role: 'log', 'aria-labelledby': 'fp-cmp-log-h', text: log.lines.join('\n')});
    box.appendChild(pre);
    if (log.cut) { box.appendChild(el('p', {class: 'fp-muted', text: t('cmp_log_cut')})); }
    box.appendChild(el('p', {class: 'fp-muted fp-cmp-hidden-note', text: t('cmp_log_hidden')}));
    if (G.follow) { pre.scrollTop = pre.scrollHeight; }
    pre.addEventListener('scroll', function () { G.follow = pre.scrollTop + pre.clientHeight >= pre.scrollHeight - 4; });
  }
  function aboutCard() {
    return M.card('fp-cmp-about-h', t('cmp_about_title'), [el('ul', {class: 'fp-cmp-about'}, [
      el('li', {text: t('cmp_about_account')}), el('li', {text: t('cmp_about_php')}), el('li', {text: t('cmp_about_where')}),
      el('li', {text: t('cmp_about_limits')}), el('li', null, [document.createTextNode(t('cmp_about_auth') + ' '), el('code', {text: 'auth.json'})])]),
    G.state.tool.version ? el('p', {class: 'fp-muted', 'data-fp-version': '', text: t('cmp_version', {version: G.state.tool.version})}) : null], 'fp-clb-how-card');
  }
  function render() {
    G.page.textContent = '';
    if (!G.state.tool.available) {
      G.page.appendChild(el('div', {class: 'fp-note', role: 'note', 'data-fp-none-here': '', text: G.state.tool.reason || t('cmp_none_here')}));
    } else if (!G.state.sites.length) {
      G.page.appendChild(el('div', {class: 'fp-note', role: 'note', 'data-fp-no-sites': '', text: t('cmp_no_sites')}));
    }
    if (G.state.sites.length) { G.page.appendChild(runCard()); }
    G.page.appendChild(M.card('fp-cmp-runs-h', t('cmp_runs_title'), [M.errorLine(), M.statusLine(),
      el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('cmp_runs_none')}), el('div', {'data-fp-runs': ''}),
      el('div', {'data-fp-log': '', hidden: true})], 'fp-cmp-runs'));
    G.page.appendChild(aboutCard());
    drawRuns();
  }

  /* ---- while a run goes on, the view and its log are asked for again ---- */
  function here() { return Boolean(G.page && G.page.isConnected); }
  function schedule() {
    window.clearTimeout(G.timer);
    G.timer = 0;
    var j = G.sel ? jobOf(G.sel) : null;
    if (here() && (running() || (j && G.log && G.log.id === j.id && G.log.status !== j.status))) { G.timer = window.setTimeout(refresh, EVERY); }
  }
  function loadLog() {
    var page = G.page;
    var id = G.sel;
    if (!id) { schedule(); return Promise.resolve(); }
    return FP.call('get', 'composerLog', undefined, {name: G.account, id: id}).then(function (r) {
      if (G.page !== page || !here() || G.sel !== id) { return; }
      var l = cleanLog(r);
      if (!l) { return; }
      G.log = l;
      drawLog();
      schedule();
    }, function (err) {
      if (G.page !== page || !here()) { return; }
      UI.showError(G.page.querySelector('.fp-cmp-runs'), err.message);
      G.timer = window.setTimeout(refresh, EVERY * 3);
    });
  }
  function refresh() {
    var page = G.page;
    G.timer = 0;
    if (!here()) { return; }
    FP.call('get', 'composer', undefined, G.account).then(function (r) {
      if (G.page !== page || !here()) { return; }
      var s = clean(r);
      if (!s) { return; }
      var was = G.sel ? jobOf(G.sel) : null;
      G.state = s;
      var now = G.sel ? jobOf(G.sel) : null;
      var form = G.page.querySelector('.fp-cmp-form');
      if (form) { syncForm(form); }
      drawRuns();
      if (was && now && was.status === 'running' && now.status !== 'running') { M.say(G.page.querySelector('.fp-cmp-runs'), jobText(now)); }
      loadLog();
    }, function () {
      if (G.page !== page || !here()) { return; }
      UI.showError(G.page.querySelector('.fp-cmp-runs'), t('cmp_refresh_failed'));
      G.timer = window.setTimeout(refresh, EVERY * 3);
    });
  }

  document.addEventListener('click', function (e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act="log"]') : null;
    if (!b || !G.page || !G.page.contains(b)) { return; }
    var row = b.closest('[data-fp-run]');
    var id = row ? row.getAttribute('data-fp-run') : '';
    if (!jobOf(id)) { return; }
    G.sel = id;
    G.log = null;
    G.follow = true;
    drawRuns();
    loadLog().then(function () {
      var h = G.page && G.page.querySelector('#fp-cmp-log-h');
      if (h) { h.focus(); }
    });
  });

  FP.view('tool:composer', function () {
    window.clearTimeout(G.timer);
    G.page = null;
    var body = M.frame('composer', 'fp-cmp');
    if (!body) { return; }
    G.page = body;
    G.account = FP.account();
    G.sel = '';
    G.log = null;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'composer', undefined, G.account).then(function (r) {
      if (G.page !== body) { return; }
      var s = clean(r);
      body.textContent = '';
      if (!s) { body.appendChild(FP.empty(FP.tools.composer.label, t('api_failed'))); return; }
      G.state = s;
      var live = s.jobs.filter(function (j) { return j.status === 'running'; })[0];
      G.sel = live ? live.id : (s.jobs[0] ? s.jobs[0].id : '');
      render();
      loadLog();
    }, function (err) {
      if (G.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(FP.tools.composer.label, err.message));
    });
  });
})();

/* freePanel reseller name servers (docs/api.md, "Resellers", GET and PUT /resellers/{username}/nameservers): the admin panel's page
   (#/tool/reseller_ns) that gives a reseller name servers of its own, so the zones of its accounts list the reseller's names instead
   of the server's. One card per reseller: its names (or the server's), how many accounts list them, and a form to change them or go
   back to the server's. Admin only. Everything the server sends is shown as text. The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var USER_RE = /^[a-z][a-z0-9]{0,15}$/;
  var HOST_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var MAX = 8;
  var MAX_RESELLERS = 200;

  function names(v) { return (Array.isArray(v) ? v : []).filter(function (n) { return typeof n === 'string' && HOST_RE.test(n); }).slice(0, MAX); }
  function whole(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.floor(v) : 0; }
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    return {username: typeof r.username === 'string' ? r.username.slice(0, 16) : '', ns: names(r.nameservers), server: names(r.server), accounts: whole(r.accounts)};
  }

  var R = {page: null, list: [], open: '', busy: false};

  function nsLine(list) {
    return el('span', {class: 'sig-mono', text: list.join(', ')});
  }

  function form(v) {
    var id = 'fp-rns-' + v.username;
    var start = v.ns.length ? v.ns : ['', ''];
    var area = el('textarea', {class: 'sig-input sig-mono', id: id, name: 'nameservers', rows: '3', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none',
      maxlength: '2100'});
    area.value = start.join('\n').trim();
    var f = el('form', {class: 'fp-form fp-rns-form', novalidate: '', 'data-fp-rns-form': v.username}, [M.errorLine(), M.statusLine(),
      M.field(id, t('rns_names_label'), area, t('rns_names_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('rns_save')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'rns-cancel', text: t('cancel')})])]);
    f.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(f);
      if (!b || R.busy) { return; }
      var list = area.value.toLowerCase().split(/[\s,]+/).map(function (n) { return n.replace(/\.$/, ''); }).filter(Boolean);
      for (var i = 0; i < list.length; i++) {
        if (!HOST_RE.test(list[i])) { M.fieldError(f, area, t('rns_bad', {name: list[i].slice(0, 60)})); return; }
        if (list.indexOf(list[i]) !== i) { M.fieldError(f, area, t('rns_twice', {name: list[i]})); return; }
      }
      if (list.length < 2 || list.length > MAX) { M.fieldError(f, area, t('rns_count', {n: MAX})); return; }
      save(v.username, list, f, b);
    });
    return f;
  }

  function save(who, list, f, b) {
    R.busy = true;
    if (b) { UI.setBusy(b, true); }
    var mine = R.page;
    FP.call('put', 'resellerNameservers', {nameservers: list}, who).then(function (r) {
      R.busy = false;
      if (R.page !== mine) { return; }
      var v = clean(r);
      R.list = R.list.map(function (x) { return x.username === who ? v : x; });
      R.open = '';
      render();
      var card = R.page.querySelector('[data-fp-rns="' + who + '"]');
      M.say(card, list.length ? t('rns_saved', {n: whole(r && r.zones)}) : t('rns_cleared', {n: whole(r && r.zones)}));
      var back = card && card.querySelector('[data-fp-act="rns-change"]');
      if (back) { back.focus(); }
    }, function (err) {
      R.busy = false;
      if (R.page !== mine) { return; }
      if (b) { UI.setBusy(b, false); }
      if (f) {
        M.failed(f, err);
      } else {
        render();
        UI.showError(R.page.querySelector('[data-fp-rns="' + who + '"]'), err.message);
      }
    });
  }

  function card(v) {
    var own = v.ns.length > 0;
    var parts = [el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': ''}), el('p', {class: 'fp-ok-line', role: 'status', 'data-fp-status': ''}),
      el('p', {'data-fp-rns-names': ''}, [el('span', {class: 'sig-pill' + (own ? ' sig-pill--accent' : ''), text: own ? t('rns_own') : t('rns_server')}), ' ',
        nsLine(own ? v.ns : v.server)]),
      el('p', {class: 'fp-muted', text: t(v.accounts === 1 ? 'rns_accounts_1' : 'rns_accounts', {n: v.accounts})})];
    if (R.open === v.username) {
      parts.push(form(v));
    } else {
      parts.push(el('div', {class: 'fp-actions'}, [
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'rns-change', 'data-fp-who': v.username,
          'aria-label': t('rns_change_for', {name: v.username}), text: t('rns_change')}),
        own ? el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'rns-clear', 'data-fp-who': v.username,
          'aria-label': t('rns_clear_for', {name: v.username}), text: t('rns_clear')}) : null]));
    }
    var h = 'fp-rns-h-' + v.username;
    return el('section', {class: 'sig-card fp-mail-card fp-rns-card', 'aria-labelledby': h, 'data-fp-rns': v.username}, [el('div', {class: 'sig-card-body'},
      [el('h2', {class: 'fp-h2', id: h, tabindex: '-1', text: v.username})].concat(parts))]);
  }

  function render() {
    R.page.textContent = '';
    R.page.appendChild(el('p', {class: 'fp-muted', text: t('rns_what')}));
    if (!R.list.length) {
      R.page.appendChild(FP.empty(t('rns_none'), t('rns_none_desc'), el('a', {class: 'sig-btn sig-btn--secondary', href: '#/tool/reseller_list', text: t('rns_add_reseller')})));
      return;
    }
    R.page.appendChild(el('div', {class: 'fp-rns-cards'}, R.list.map(card)));
  }

  document.addEventListener('click', function (e) {
    var node = e.target.closest ? e.target : null;
    var b = node && node.closest('[data-fp-act]');
    if (!b || !R.page || !R.page.contains(b)) { return; }
    var a = b.getAttribute('data-fp-act');
    var who = b.getAttribute('data-fp-who') || '';
    if (a === 'rns-change' && !R.busy) {
      R.open = who;
      render();
      var f = R.page.querySelector('#fp-rns-' + who);
      if (f) { f.focus(); }
    } else if (a === 'rns-cancel') {
      var was = R.open;
      R.open = '';
      render();
      var back = R.page.querySelector('[data-fp-act="rns-change"][data-fp-who="' + was + '"]');
      if (back) { back.focus(); }
    } else if (a === 'rns-clear') {
      var cell = b.parentNode;
      M.confirmIn(cell, t('rns_clear_ask', {name: who}), 'rns-clear-yes', t('rns_clear_yes'));
      var yes = cell.querySelector('[data-fp-act="rns-clear-yes"]');
      if (yes) { yes.setAttribute('data-fp-who', who); }
    } else if (a === 'rns-clear-yes' && !R.busy) {
      save(who, [], null, b);
    } else if (a === 'confirm-no') {
      render();
    }
  });

  FP.view('tool:reseller_ns', function () {
    var tool = FP.tools.reseller_ns;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    R.list = [];
    R.open = '';
    R.busy = false;
    var body = FP.frame({title: tool.label, desc: t('rns_desc'), cls: 'fp-mail fp-srv fp-rns-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    R.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'resellers').then(function (r) {
      var who = (r && Array.isArray(r.resellers) ? r.resellers : []).map(function (x) { return x && typeof x.username === 'string' ? x.username : ''; })
        .filter(function (n) { return USER_RE.test(n); }).slice(0, MAX_RESELLERS);
      return Promise.all(who.map(function (n) { return FP.call('get', 'resellerNameservers', undefined, n).then(clean); }));
    }).then(function (list) {
      if (R.page !== body) { return; }
      R.list = list.filter(function (v) { return v.username; });
      render();
    }, function (err) {
      if (R.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

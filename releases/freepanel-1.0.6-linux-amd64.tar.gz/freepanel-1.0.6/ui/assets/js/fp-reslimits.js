/* freePanel resource limits (docs/api.md, "Resource limits"): the admin panel's page (#/tool/resource_limits) for limits on what an account may use:
   CPU, memory, processes and threads, and disk read and write speed, held by the kernel through control groups. The limits hold the PHP of the
   account's websites (each account runs its sites' PHP in a service of its own, inside its limits) and, separately, its login sessions (SSH, SFTP,
   su and the panel's terminal) through its systemd user slice; each gets the full limit. The page says first, and everywhere it is used, what the
   limits cover and what they do not reach: mail, FTP and databases, and on Ubuntu the account's scheduled tasks (cron). It shows what this server's
   control groups can limit, the accounts that have a limit (whether their websites run inside it and whether a login is open), and a form for one
   account. A save names only the limits that changed; an empty box takes a limit away; a save that answers with a warning shows it. Admin only:
   the server refuses these calls to anyone else. Everything the server sends is shown as text. The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var FIELDS = ['cpu_percent', 'memory_mb', 'tasks', 'io_read_mib_s', 'io_write_mib_s'];
  var CONTROLLERS = {cpu_percent: 'cpu', memory_mb: 'memory', tasks: 'pids', io_read_mib_s: 'io', io_write_mib_s: 'io'};
  var NAME_RE = /^[a-z][a-z0-9]{0,15}$/;
  var USER_RE = /^[a-z][a-z0-9_]{0,31}$/;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  function num(v) { return typeof v === 'number' && isFinite(v) && Math.floor(v) === v ? v : null; }
  function limitsOf(v) {
    var out = {};
    FIELDS.forEach(function (f) { out[f] = v && typeof v === 'object' ? num(v[f]) : null; });
    return out;
  }
  function status(v) {
    v = v && typeof v === 'object' ? v : {};
    var s = v.status && typeof v.status === 'object' ? v.status : {};
    var byField = {};
    (Array.isArray(s.fields) ? s.fields : []).forEach(function (f) {
      if (f && typeof f === 'object' && FIELDS.indexOf(f.field) >= 0) {
        byField[f.field] = {controller: str(f.controller, 20) || CONTROLLERS[f.field], min: num(f.min), max: num(f.max), available: f.available === true};
      }
    });
    return {v2: s.cgroup_v2 === true, controllers: (Array.isArray(s.controllers) ? s.controllers : []).filter(function (c) { return typeof c === 'string'; }).map(function (c) { return c.slice(0, 20); }).slice(0, 30),
      fields: byField,
      accounts: (Array.isArray(v.accounts) ? v.accounts : []).filter(function (a) { return a && typeof a === 'object' && USER_RE.test(str(a.username, 32)); }).slice(0, 500)
        .map(function (a) { return {username: a.username, limits: limitsOf(a.limits)}; })};
  }
  function account(v) {
    v = v && typeof v === 'object' ? v : {};
    var logins = v.logins && typeof v.logins === 'object' ? v.logins : {};
    return {username: USER_RE.test(str(v.username, 32)) ? v.username : '', limits: limitsOf(v.limits), applied: limitsOf(v.applied), active: v.active === true,
      loginsActive: logins.active === true, warning: str(v.warning, 600)};
  }
  function summary(l) {
    var parts = FIELDS.filter(function (f) { return l[f] !== null; }).map(function (f) { return t('rlm_short_' + f, {n: l[f].toLocaleString('en')}); });
    return parts.length ? parts.join(', ') : t('rlm_no_limit');
  }

  var R = {page: null, S: null, cur: null, busy: false};

  function coverCard() {
    return M.card('fp-rlm-cover-h', t('rlm_cover_title'), [
      el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-rlm-cover': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('rlm_cover_key')})]),
      el('ul', {class: 'fp-rlm-bullets'}, [el('li', {'data-fp-rlm-php': '', text: t('rlm_cover_php')}), el('li', {'data-fp-rlm-logins': '', text: t('rlm_cover_logins')}),
        el('li', {'data-fp-rlm-others': '', text: t('rlm_cover_others')}), el('li', {'data-fp-rlm-cron': '', text: t('rlm_cover_cron')})])], 'fp-rlm-cover');
  }
  function canCard() {
    var S = R.S;
    var rows = FIELDS.map(function (f) {
      var info = S.fields[f];
      var ok = info && info.available;
      return el('li', {class: 'fp-rlm-can', 'data-fp-can': f}, [el('div', {class: 'fp-rlm-can-head'}, [el('span', {class: 'fp-rlm-what', text: t('rlm_label_' + f)}),
        el('span', {class: 'sig-pill ' + (ok ? 'sig-pill--ok' : 'sig-pill--warn'), text: ok ? t('rlm_available') : t('rlm_unavailable')})]),
      el('p', {class: 'fp-muted fp-rlm-range', text: info ? t('rlm_range', {min: info.min === null ? '?' : info.min.toLocaleString('en'), max: info.max === null ? '?' : info.max.toLocaleString('en'), unit: t('rlm_unit_' + f)}) : t('rlm_unknown')}),
      ok ? null : el('p', {class: 'fp-muted', text: t('rlm_lacks', {controller: info ? info.controller : CONTROLLERS[f]})})]);
    });
    var parts = [el('p', {class: 'fp-rlm-v2', 'data-fp-cgroup': S.v2 ? 'v2' : 'none'}, [el('span', {class: 'sig-pill ' + (S.v2 ? 'sig-pill--ok' : 'sig-pill--warn'), text: S.v2 ? t('rlm_v2') : t('rlm_no_v2')}), ' ',
      el('span', {class: 'fp-muted', text: S.controllers.length ? t('rlm_controllers', {list: S.controllers.join(', ')}) : t('rlm_no_controllers')})]),
    el('ul', {class: 'fp-rlm-list'}, rows)];
    if (!S.v2) { parts.push(el('p', {class: 'fp-muted', text: t('rlm_no_v2_what')})); }
    return M.card('fp-rlm-can-h', t('rlm_can_title'), parts, 'fp-rlm-cancard');
  }
  function withCard() {
    var S = R.S;
    var parts;
    if (!S.accounts.length) {
      parts = [el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('rlm_none')})];
    } else {
      parts = [el('ul', {class: 'fp-rlm-list', 'data-fp-with': ''}, S.accounts.map(function (a) {
        return el('li', {class: 'fp-rlm-item', 'data-fp-account': a.username}, [el('div', {class: 'fp-rlm-who'}, [el('span', {class: 'sig-mono fp-rlm-name', text: a.username}),
          el('span', {class: 'fp-muted fp-rlm-sum', text: summary(a.limits)})]),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'rlm-open', 'aria-label': t('rlm_change_of', {name: a.username}), text: t('rlm_change')})]);
      }))];
    }
    return M.card('fp-rlm-with-h', t('rlm_with_title'), parts, 'fp-rlm-withcard');
  }

  function limitInput(f, cur) {
    var info = R.S.fields[f];
    var id = 'fp-rlm-' + f;
    var ok = info && info.available;
    var input = el('input', {class: 'sig-input fp-rlm-num', id: id, name: f, type: 'text', inputmode: 'numeric', autocomplete: 'off', maxlength: '8', value: cur.limits[f] === null ? '' : String(cur.limits[f]),
      disabled: ok || cur.limits[f] !== null ? null : true, 'aria-describedby': id + '-hint'});
    var held = cur.applied[f];
    var hint = t('rlm_hint', {min: info && info.min !== null ? info.min.toLocaleString('en') : '?', max: info && info.max !== null ? info.max.toLocaleString('en') : '?', unit: t('rlm_unit_' + f)}) +
      (ok ? '' : ' ' + t('rlm_lacks', {controller: info ? info.controller : CONTROLLERS[f]})) +
      (cur.limits[f] !== null && held !== null && held !== cur.limits[f] ? ' ' + t('rlm_held', {n: held.toLocaleString('en')}) : '');
    return M.field(id, t('rlm_label_' + f), input, hint);
  }
  function readForm(form, cur) {
    var body = {};
    var any = false;
    for (var i = 0; i < FIELDS.length; i++) {
      var f = FIELDS[i];
      var box = form.querySelector('[name="' + f + '"]');
      var v = box.value.trim().replace(/[\s,]/g, '');
      var info = R.S.fields[f];
      if (v === '') {
        if (cur.limits[f] !== null) { body[f] = null; any = true; }
        continue;
      }
      if (!/^[0-9]{1,8}$/.test(v)) { M.fieldError(form, box, t('rlm_bad_number')); return null; }
      var n = Number(v);
      if (info && info.min !== null && info.max !== null && (n < info.min || n > info.max)) { M.fieldError(form, box, t('rlm_out_of_range', {min: info.min.toLocaleString('en'), max: info.max.toLocaleString('en')})); return null; }
      if (n !== cur.limits[f]) { body[f] = n; any = true; }
    }
    if (!any) { M.fieldError(form, null, t('rlm_nothing')); return null; }
    return body;
  }
  function setCard() {
    var parts = [el('p', {class: 'fp-muted', text: t('rlm_set_what')})];
    var pick = el('input', {class: 'sig-input sig-mono', id: 'fp-rlm-account', name: 'username', type: 'text', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', maxlength: '16',
      value: R.cur ? R.cur.username : '', 'aria-describedby': 'fp-rlm-account-hint'});
    var pickForm = el('form', {class: 'fp-form fp-rlm-form', novalidate: ''}, [M.errorLine(), M.field('fp-rlm-account', t('rlm_account'), pick, t('rlm_account_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('rlm_load')})])]);
    pickForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(pickForm);
      if (!b || R.busy) { return; }
      var name = pick.value.trim().toLowerCase();
      if (!NAME_RE.test(name)) { M.fieldError(pickForm, pick, t('rlm_bad_account')); return; }
      load(name, b, pickForm);
    });
    parts.push(pickForm);
    if (R.cur) { parts.push(accountForm()); }
    return M.card('fp-rlm-set-h', t('rlm_set_title'), parts, 'fp-rlm-setcard');
  }
  function accountForm() {
    var cur = R.cur;
    var anySet = FIELDS.some(function (f) { return cur.limits[f] !== null; });
    var form = el('form', {class: 'fp-form fp-rlm-form fp-rlm-account', novalidate: '', 'data-fp-rlm-for': cur.username}, [
      el('h3', {class: 'fp-h3', id: 'fp-rlm-for-h', tabindex: '-1', text: t('rlm_for', {name: cur.username})}), M.errorLine(), M.statusLine(),
      el('p', {class: 'fp-muted', 'data-fp-active': cur.active ? 'yes' : 'no', text: t(cur.active ? 'rlm_active' : 'rlm_inactive')}),
      el('p', {class: 'fp-muted', 'data-fp-logins-active': cur.loginsActive ? 'yes' : 'no', text: t(cur.loginsActive ? 'rlm_logins_active' : 'rlm_logins_inactive')}),
      /* the agent's own words, with the numbers: the account's PHP workers may use more memory than its limit (nothing was refused) */
      cur.warning ? el('div', {class: 'sig-banner sig-banner--warn', role: 'status', 'data-fp-rlm-warning': ''}, [UI.icon(FP.ui, 'ui_warning'),
        el('span', {}, [el('strong', {text: t('rlm_warning_title') + ' '}), document.createTextNode(cur.warning)])]) : null]
      .concat(FIELDS.map(function (f) { return limitInput(f, cur); }), [
        el('div', {class: 'fp-actions fp-rlm-acts'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('rlm_save')}),
          anySet ? el('button', {class: 'sig-btn sig-btn--secondary fp-btn-danger-text', type: 'button', 'data-fp-act': 'rlm-clear', text: t('rlm_clear')}) : null])]));
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || R.busy) { return; }
      var body = readForm(form, cur);
      if (!body) { return; }
      save(body, b, form, t('rlm_saved', {name: cur.username}));
    });
    return form;
  }
  function render() {
    R.page.textContent = '';
    R.page.appendChild(coverCard());
    R.page.appendChild(canCard());
    R.page.appendChild(withCard());
    R.page.appendChild(setCard());
  }

  function refreshList() {
    var mine = R.page;
    return FP.call('get', 'resourceLimits').then(function (r) {
      if (R.page !== mine) { return; }
      R.S = status(r);
    }, function () { /* the list stays as it was; the change itself was saved */ });
  }
  function load(name, b, form) {
    R.busy = true;
    UI.setBusy(b, true);
    var mine = R.page;
    FP.call('get', 'acctResourceLimits', undefined, name).then(function (r) {
      R.busy = false;
      if (R.page !== mine) { return; }
      R.cur = account(r);
      if (!R.cur.username) { R.cur.username = name; }
      render();
      R.page.querySelector('#fp-rlm-for-h').focus();
    }, function (err) {
      R.busy = false;
      if (R.page !== mine) { return; }
      UI.setBusy(b, false);
      M.failed(form, err);
    });
  }
  function save(body, b, form, done) {
    R.busy = true;
    UI.setBusy(b, true);
    var mine = R.page;
    var name = R.cur.username;
    FP.call('put', 'acctResourceLimits', body, name).then(function (r) {
      R.busy = false;
      if (R.page !== mine) { return; }
      R.cur = account(r);
      if (!R.cur.username) { R.cur.username = name; }
      return refreshList().then(function () {
        if (R.page !== mine) { return; }
        render();
        M.say(R.page.querySelector('.fp-rlm-account'), done);
        R.page.querySelector('#fp-rlm-for-h').focus();
      });
    }, function (err) {
      R.busy = false;
      if (R.page !== mine) { return; }
      UI.setBusy(b, false);
      M.failed(form, err);
    });
  }

  document.addEventListener('click', function (e) {
    var node = e.target.closest ? e.target : null;
    var b = node && node.closest('[data-fp-act]');
    if (!b || !R.page || !R.page.contains(b) || !R.S) { return; }
    var a = b.getAttribute('data-fp-act');
    if (a === 'rlm-open') {
      var li = b.closest('li[data-fp-account]');
      var name = li ? li.getAttribute('data-fp-account') : '';
      var form = R.page.querySelector('.fp-rlm-setcard form');
      if (name && form && !R.busy) { load(name, b, form); }
    } else if (a === 'rlm-clear' && R.cur) {
      M.confirmIn(b.parentNode, t('rlm_clear_ask', {name: R.cur.username}), 'rlm-clear-yes', t('rlm_clear_yes'));
    } else if (a === 'confirm-no') {
      render();
      var again = R.page.querySelector('[data-fp-act="rlm-clear"]');
      if (again) { again.focus(); }
    } else if (a === 'rlm-clear-yes' && R.cur && !R.busy) {
      var body = {};
      FIELDS.forEach(function (f) { if (R.cur.limits[f] !== null) { body[f] = null; } });
      save(body, b, R.page.querySelector('.fp-rlm-account'), t('rlm_cleared', {name: R.cur.username}));
    }
  });

  FP.view('tool:resource_limits', function () {
    var tool = FP.tools.resource_limits;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    R.S = null;
    R.cur = null;
    R.busy = false;
    var body = FP.frame({title: tool.label, desc: t('rlm_desc'), cls: 'fp-mail fp-srv fp-rlm-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    R.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'resourceLimits').then(function (r) {
      if (R.page !== body) { return; }
      R.S = status(r);
      render();
    }, function (err) {
      if (R.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

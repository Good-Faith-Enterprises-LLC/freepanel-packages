/* freePanel first paint: apply the stored colour mode, panel theme and the folded main menu before anything is drawn, so the
   page never flashes the other way. Loaded without defer in <head>; external so a strict CSP needs no inline script. */
(function () {
  'use strict';
  var root = document.documentElement;
  try {
    var mode = window.localStorage.getItem('fp.mode');
    if (mode === 'light' || mode === 'dark') { root.setAttribute('data-sig-mode', mode); }
    if (window.localStorage.getItem('fp.side') === 'collapsed') { root.setAttribute('data-sig-side', 'collapsed'); }
    /* the panel theme the session gave last time (fp-theme.js keeps it): known names only, so a stored value is never a class we do not ship */
    var layout = window.localStorage.getItem('fp.layout');
    var scheme = window.localStorage.getItem('fp.scheme');
    /* nothing kept yet: a browser that asks for more contrast gets the high-contrast scheme until the session says otherwise */
    if (!scheme && window.matchMedia && window.matchMedia('(prefers-contrast: more)').matches) { scheme = 'high-contrast'; }
    root.classList.add('fp-layout-' + (layout === 'classic' || layout === 'cards' || layout === 'domains' ? layout : 'modern'),
      'fp-scheme-' + (scheme === 'ocean' || scheme === 'high-contrast' ? scheme : 'default'));
  } catch (e) { /* storage blocked: system mode, open menu */ }
})();

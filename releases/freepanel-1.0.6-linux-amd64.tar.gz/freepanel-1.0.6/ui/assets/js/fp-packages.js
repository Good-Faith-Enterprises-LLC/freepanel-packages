/* freePanel packages in the admin panel (docs/api.md, "Packages"): #/tool/package_list lists the packages with
   their limits and how many accounts use each, makes new ones, changes a package's limits in its row, and removes
   a package no account uses. An admin sees every package and grants shell access; a reseller sees its own, whose
   names the server starts with the reseller's username and _. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;

  var NAME_RE = /^[A-Za-z0-9][A-Za-z0-9_. -]{0,63}$/;   /* as internal/validate allows them */
  var USER_RE = /^[a-z][a-z0-9]{0,15}$/;
  /* [field, label, short column heading, in MB] in the order hosting panels list them */
  var LIMITS = [['disk_mb', 'pkg_disk', 'pkg_disk_col', true], ['bandwidth_mb', 'pkg_bandwidth', 'pkg_bandwidth_col', true],
    ['max_domains', 'pkg_domains', 'pkg_domains_col'], ['max_subdomains', 'pkg_subdomains', 'pkg_subdomains_col'],
    ['max_email_accounts', 'pkg_mailboxes', 'pkg_mailboxes_col'], ['max_databases', 'pkg_databases', 'pkg_databases_col'],
    ['max_ftp_accounts', 'pkg_ftp', 'pkg_ftp_col']];
  var MAX = 1e12;   /* far above any real limit, and still a safe integer */

  function str(v) { return typeof v === 'string' ? v : ''; }
  function isAdmin() { return FP.session.user.role === 'admin'; }
  function limit(v) { return typeof v === 'number' && isFinite(v) && v >= 0 && v <= MAX && Math.floor(v) === v ? v : null; }
  function cleanPackage(p) {
    if (!p || !NAME_RE.test(str(p.name))) { return null; }
    var out = {name: p.name, owner: USER_RE.test(str(p.owner)) ? p.owner : '', shell: p.shell_access === true};
    LIMITS.forEach(function (l) { out[l[0]] = limit(p[l[0]]); });
    return out;
  }
  function mb(n) {
    if (n < 1024) { return t('pkg_mb', {n: n.toLocaleString('en')}); }
    var g = n / 1024;
    if (g < 1024) { return t('pkg_gb', {n: (Math.round(g * 10) / 10).toLocaleString('en')}); }
    return t('pkg_tb', {n: (Math.round(g / 1024 * 10) / 10).toLocaleString('en')});
  }
  function shown(l, v) { return v === null ? t('unlimited') : (l[3] ? mb(v) : v.toLocaleString('en')); }

  function errorLine() { return el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': ''}); }
  function say(scope, text) {
    var s = scope && scope.querySelector('[data-fp-status]');
    if (s) { s.textContent = text || ''; }
  }
  function fieldError(form, f, message) {
    UI.showError(form, message);
    if (f) {
      f.setAttribute('aria-invalid', 'true');
      f.focus({preventScroll: true});
    }
    var line = form.querySelector('[data-fp-error]');
    if (line && line.scrollIntoView) { line.scrollIntoView({block: 'nearest'}); }
  }
  function failed(form, err) {
    var f = err && err.field ? UI.fieldNamed(form, err.field) : null;
    var label = f ? form.querySelector('label[for="' + f.id + '"]') : null;
    fieldError(form, f, (label ? label.textContent + ': ' : '') + (err ? err.message : t('api_failed')));
  }
  function start(form) {
    var b = form.querySelector('.fp-submit');
    if (b.disabled) { return null; }
    UI.showError(form, '');
    var bad = form.querySelectorAll('[aria-invalid]');
    for (var i = 0; i < bad.length; i++) { bad[i].removeAttribute('aria-invalid'); }
    return b;
  }

  /* one limit: a whole number, or Unlimited, which hides the number box */
  function limitField(prefix, l, value) {
    var id = prefix + '-' + l[0];
    var input = el('input', {class: 'sig-input fp-num-input', id: id, name: l[0], type: 'number', inputmode: 'numeric', min: '0', step: '1',
      max: String(MAX), value: value === null ? '' : String(value), disabled: value === null ? true : null, hidden: value === null,
      'aria-describedby': l[3] ? id + '-hint' : null});
    var none = el('input', {type: 'checkbox', id: id + '-none', 'data-fp-unlimited': l[0], checked: value === null ? true : null});
    var hint = l[3] ? el('span', {class: 'sig-hint', id: id + '-hint', hidden: value === null, text: t('pkg_in_mb')}) : null;
    none.addEventListener('change', function () {
      input.disabled = none.checked;
      input.hidden = none.checked;
      if (hint) { hint.hidden = none.checked; }
      input.removeAttribute('aria-invalid');
      if (!none.checked) {
        if (input.value === '') { input.value = '0'; }
        input.focus();
        input.select();
      }
    });
    return el('div', {class: 'sig-field fp-pkg-limit'}, [el('label', {class: 'sig-label', for: id, text: t(l[1])}),
      el('div', {class: 'fp-pkg-limit-row'}, [input,
        el('label', {class: 'fp-check fp-pkg-none', for: id + '-none'}, [none, el('span', {text: t('unlimited')}),
          el('span', {class: 'sig-vh', text: ' ' + t(l[1])})])]),
      hint]);
  }
  function limitFields(prefix, p) {
    return el('div', {class: 'fp-pkg-limits'}, LIMITS.map(function (l) { return limitField(prefix, l, p ? p[l[0]] : null); }));
  }
  /* the limits as the API takes them, every one sent (an omitted limit means unlimited); null when one is wrong */
  function readLimits(form) {
    var out = {};
    for (var i = 0; i < LIMITS.length; i++) {
      var l = LIMITS[i];
      var input = form.querySelector('[name="' + l[0] + '"]');
      if (input.disabled) { out[l[0]] = null; continue; }
      var v = input.value.trim();
      if (!/^[0-9]{1,13}$/.test(v) || Number(v) > MAX) { fieldError(form, input, t('pkg_bad_number', {field: t(l[1])})); return null; }
      out[l[0]] = Number(v);
    }
    return out;
  }
  /* one line pointing the admin to Resource limits for CPU, memory and process limits */
  function resourceNote() {
    if (!isAdmin() || !FP.tools.resource_limits) { return null; }
    return el('p', {class: 'sig-hint fp-pkg-reslimits', 'data-fp-pkg-reslimits': ''}, [t('pkg_reslimits') + ' ', el('a', {href: '#/tool/resource_limits', text: t('pkg_reslimits_link')}), '.']);
  }
  function shellField(prefix, p) {
    return el('label', {class: 'fp-check', for: prefix + '-shell'}, [
      el('input', {type: 'checkbox', id: prefix + '-shell', name: 'shell_access', checked: p && p.shell ? true : null}),
      el('span', {text: t('pkg_shell_grant')})]);
  }

  var page = null;
  var packages = [];
  var used = null;   /* package name -> accounts on it, or null when the accounts list didn't load */
  var open = '';     /* the package whose change form is open, or '+' for the new-package form */

  function uses(name) { return used ? (used[name] || 0) : null; }
  function cols() { return LIMITS.length + (isAdmin() ? 5 : 4); }

  function newForm() {
    var name = el('input', {class: 'sig-input', id: 'fp-pkg-name', name: 'name', type: 'text', autocomplete: 'off', spellcheck: 'false', maxlength: '64'});
    name.setAttribute('aria-describedby', 'fp-pkg-name-hint');
    var form = el('form', {class: 'fp-form fp-pkg-form', novalidate: '', 'aria-labelledby': 'fp-pkg-new-h'}, [
      el('h2', {class: 'fp-h2', id: 'fp-pkg-new-h', text: t('pkg_new')}), errorLine(),
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: 'fp-pkg-name', text: t('pkg_name')}), name,
        el('span', {class: 'sig-hint', id: 'fp-pkg-name-hint', text: isAdmin() ? t('pkg_name_hint') :
          t('pkg_name_hint_reseller', {prefix: FP.session.user.username + '_'})})]),
      limitFields('fp-pkg-n', null), isAdmin() ? shellField('fp-pkg-n', null) : null, resourceNote(),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('pkg_create')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'close', text: t('cancel')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = start(form);
      if (!b) { return; }
      var n = name.value.trim();
      if (!NAME_RE.test(n)) { fieldError(form, name, t('pkg_bad_name')); return; }
      var body = readLimits(form);
      if (!body) { return; }
      body.name = n;
      if (isAdmin()) { body.shell_access = form.querySelector('[name="shell_access"]').checked; }
      UI.setBusy(b, true);
      FP.call('post', 'packages', body).then(function (r) {
        var p = cleanPackage(r);
        if (p) {
          packages = packages.filter(function (x) { return x.name !== p.name; }).concat([p]).sort(byName);
        }
        open = '';
        draw(t('pkg_created', {name: p ? p.name : n}), p ? p.name : '', 'change');
      }, function (err) {
        UI.setBusy(b, false);
        failed(form, err);
      });
    });
    return el('section', {class: 'sig-card'}, [el('div', {class: 'sig-card-body'}, [form])]);
  }

  function changeRow(p) {
    var form = el('form', {class: 'fp-form fp-pkg-inline', novalidate: ''}, [errorLine(),
      el('p', {class: 'fp-muted', text: uses(p.name) ? t('pkg_change_used', {name: p.name, n: uses(p.name)}) : t('pkg_change_for', {name: p.name})}),
      limitFields('fp-pkg-c', p), isAdmin() ? shellField('fp-pkg-c', p) : null, resourceNote(),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('pkg_save')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'close', text: t('cancel')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = start(form);
      if (!b) { return; }
      var body = readLimits(form);
      if (!body) { return; }
      /* a reseller can't grant shell access, but keeps what the admin gave */
      body.shell_access = isAdmin() ? form.querySelector('[name="shell_access"]').checked : p.shell;
      UI.setBusy(b, true);
      FP.call('put', 'package', body, p.name).then(function (r) {
        var q = cleanPackage(r);
        if (q) { packages = packages.map(function (x) { return x.name === p.name ? q : x; }); }
        open = '';
        draw(t('pkg_saved', {name: p.name}), p.name, 'change');
      }, function (err) {
        UI.setBusy(b, false);
        failed(form, err);
      });
    });
    return el('tr', {class: 'fp-pkg-formrow'}, [el('td', {colspan: String(cols())}, [form])]);
  }

  function row(p) {
    var n = uses(p.name);
    return el('tr', {'data-fp-package': p.name}, [
      el('th', {scope: 'row', text: p.name}),
      isAdmin() ? el('td', {text: p.owner || '–'}) : null]
      .concat(LIMITS.map(function (l) { return el('td', {class: 'fp-num', text: shown(l, p[l[0]])}); }), [
        el('td', {text: p.shell ? t('pkg_yes') : t('pkg_no')}),
        el('td', {class: 'fp-num', text: n === null ? '–' : String(n)}),
        el('td', {class: 'fp-pkg-acts'}, [
          el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'change', 'aria-expanded': String(open === p.name),
            'aria-label': t('pkg_change_of', {name: p.name}), text: t('pkg_change')}),
          el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'remove',
            'aria-label': t('pkg_remove_of', {name: p.name}), text: t('pkg_remove')})])]));
  }

  function byName(a, b) { return a.name < b.name ? -1 : 1; }
  function draw(message, focusName, focusAct) {
    page.textContent = '';
    var add = el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'new', 'aria-expanded': String(open === '+'), text: t('pkg_new')});
    /* while the new form is open its own buttons stand in for New, so the list shows neither New nor its empty line */
    var card = el('section', {class: 'sig-card fp-pkg-list'}, [el('div', {class: 'sig-card-body'}, [
      open === '+' ? null : el('div', {class: 'fp-actions fp-pkg-top'}, [add]), errorLine(), el('p', {class: 'fp-ok-line', role: 'status', 'data-fp-status': ''})])]);
    var inner = card.firstChild;
    if (open === '+') { page.appendChild(newForm()); }
    if (open !== '+' || packages.length) { page.appendChild(card); }
    if (!packages.length) {
      if (open !== '+') { inner.appendChild(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('pkg_none')})); }
    } else {
      var rows = [];
      packages.forEach(function (p) {
        rows.push(row(p));
        if (open === p.name) { rows.push(changeRow(p)); }
      });
      inner.appendChild(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-h1'}, [
        el('table', {class: 'sig-table fp-pkg-table'}, [el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('pkg_name')}),
          isAdmin() ? el('th', {scope: 'col', text: t('pkg_owner')}) : null]
          .concat(LIMITS.map(function (l) { return el('th', {scope: 'col', class: 'fp-num', text: t(l[2])}); }), [
            el('th', {scope: 'col', text: t('pkg_shell')}), el('th', {scope: 'col', class: 'fp-num', text: t('pkg_accounts')}),
            el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('pkg_actions')})])]))]), el('tbody', null, rows)])]));
    }
    say(card, message);
    var target = null;
    if (open === '+') {
      target = page.querySelector('#fp-pkg-name');
    } else if (open && open === focusName) {
      target = page.querySelector('.fp-pkg-formrow input:not([disabled])');
    } else if (focusName) {
      target = page.querySelector('tr[data-fp-package="' + window.CSS.escape(focusName) + '"] [data-fp-act="' + focusAct + '"]');
    } else if (focusAct === 'new') {
      target = add;
    }
    if (target) { target.focus(); }
  }

  function confirmRemove(tr) {
    var n = tr.getAttribute('data-fp-package');
    var cell = tr.querySelector('.fp-pkg-acts');
    cell.textContent = '';
    /* the server refuses to remove a package accounts use, so say why instead of offering it */
    var inUse = uses(n) > 0;
    var yes = inUse ? null : el('button', {class: 'sig-btn sig-btn--danger sig-btn--sm', type: 'button', 'data-fp-act': 'remove-yes', text: t('pkg_remove')});
    var no = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'remove-no', text: inUse ? t('pkg_ok') : t('cancel')});
    cell.appendChild(el('span', {class: 'fp-pkg-confirm', id: 'fp-pkg-confirm', text: inUse ? t('pkg_remove_used', {name: n, n: uses(n)}) : t('pkg_remove_ask', {name: n})}));
    if (yes) { cell.appendChild(yes); }
    cell.appendChild(no);
    if (yes) { yes.setAttribute('aria-describedby', 'fp-pkg-confirm'); }
    no.setAttribute('aria-describedby', 'fp-pkg-confirm');
    /* Cancel takes focus, so a second Enter on Remove can't remove the package */
    no.focus();
  }

  function onClick(e) {
    var target = e.target.closest ? e.target : null;
    if (!target || !page || !page.contains(target)) { return; }
    var b = target.closest('[data-fp-act]');
    if (!b) { return; }
    var a = b.getAttribute('data-fp-act');
    var tr = b.closest('tr[data-fp-package]');
    var n = tr ? tr.getAttribute('data-fp-package') : '';
    if (a === 'new') {
      open = open === '+' ? '' : '+';
      draw('', '', 'new');
    } else if (a === 'change') {
      open = open === n ? '' : n;
      draw('', n, 'change');
    } else if (a === 'close') {
      var was = open;
      open = '';
      draw('', was === '+' ? '' : was, was === '+' ? 'new' : 'change');
    } else if (a === 'remove') {
      confirmRemove(tr);
    } else if (a === 'remove-no') {
      draw('', n, 'remove');
    } else if (a === 'remove-yes') {
      var card = page.querySelector('.fp-pkg-list');
      UI.showError(card, '');
      UI.setBusy(b, true);
      FP.call('del', 'package', undefined, n).then(function () {
        packages = packages.filter(function (x) { return x.name !== n; });
        if (open === n) { open = ''; }
        draw(t('pkg_removed', {name: n}), '', 'new');
      }, function (err) {
        draw('', n, 'remove');
        UI.showError(page.querySelector('.fp-pkg-list'), err.message);
      });
    }
  }
  document.addEventListener('click', onClick);

  FP.view('tool:package_list', function () {
    var tool = FP.tools.package_list;
    if (!tool || FP.realm !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    open = '';
    page = FP.frame({title: tool.label, desc: t(isAdmin() ? 'pkg_desc' : 'pkg_desc_reseller'), cls: 'fp-pkg',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    var mine = page;
    Promise.all([FP.call('get', 'packages'), FP.call('get', 'accounts').then(function (r) {
      var count = {};
      (r && Array.isArray(r.accounts) ? r.accounts : []).forEach(function (a) {
        var p = a && str(a.package);
        if (p) { count[p] = (count[p] || 0) + 1; }
      });
      return count;
    }, function () { return null; })]).then(function (r) {
      if (page !== mine) { return; }
      packages = (r[0] && Array.isArray(r[0].packages) ? r[0].packages : []).map(cleanPackage).filter(Boolean).sort(byName);
      used = r[1];
      draw('');
    }, function (err) {
      if (page !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

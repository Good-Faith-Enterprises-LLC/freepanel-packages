/* freePanel billing payment gateways (#/tool/billing_gateways; docs/api.md, "Billing: payments", Gateways; docs/billing/navigation-map.md,
   "Payment gateways"): the gateways the server has, each on or off. Turning one off is asked first, since its payments and saved methods stop
   working; turning the test gateway on says plainly that it takes no money and that anyone with a checkout's link can mark it paid. Below the
   list, Stripe and PayPal each have a card for their keys (docs/api.md, "Billing: payment gateways"): the shown settings, and the secrets,
   which are write-only (a box left empty keeps what is saved; the page only ever says whether one is set). The card says what is still
   missing before the gateway can be turned on, and the webhook address and events to give the provider. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;
  var M = FP.mail;
  function has(key) { return Object.prototype.hasOwnProperty.call(window.FPSTRINGS || {}, key); }
  /* the settings each provider takes (docs/api.md, "Billing: payment gateways"): shown ones, and secrets that are never read back */
  var KEYS = {stripe: {mode: false, plain: [], secret: ['secret_key', 'webhook_secret']},
    paypal: {mode: true, plain: ['client_id', 'webhook_id'], secret: ['secret']}};
  /* the provider's own API address, by mode: the server answers it as api_base when none of the admin's is saved, so the box shows it
     only when it is the admin's own (and the default as the placeholder) */
  var API = {stripe: {sandbox: 'https://api.stripe.com', live: 'https://api.stripe.com'},
    paypal: {sandbox: 'https://api-m.sandbox.paypal.com', live: 'https://api-m.paypal.com'}};
  function ownBase(g, v) { var d = API[g] && API[g][v.mode || 'sandbox']; return v.api_base && v.api_base !== d ? v.api_base : ''; }

  FP.view('tool:billing_gateways', function () {
    var page = B.frame('billing_gateways', 'fp-bgw');
    if (!page) { return; }
    var alive = function () { return page.isConnected; };
    /* the list and the keys cards are drawn apart, so saving the list never throws away keys typed but not saved */
    var top = el('div', {'data-fp-part': 'gateways'}, [el('p', {class: 'fp-muted', text: t('loading')})]);
    var keys = el('div', {class: 'fp-bgk-cards', 'data-fp-part': 'keys'});
    var keysDrawn = false;
    page.appendChild(top);
    page.appendChild(keys);
    function clean(r) { return B.pickAll(r && r.gateways, {id: [40], name: [60], enabled: 'b'}, 'id').filter(function (g) { return /^[a-z0-9_-]{1,40}$/.test(g.id); }); }
    function draw(list, said) {
      var boxes = list.map(function (g) {
        var fid = 'fp-bgw-' + g.id;
        return el('li', {class: 'fp-bgw-item', 'data-fp-gateway': g.id}, [el('label', {class: 'fp-bil-check', for: fid}, [el('input', {type: 'checkbox', id: fid, name: 'enabled', value: g.id,
          checked: g.enabled ? true : null}), el('span', {class: 'fp-bgw-name', text: g.name || g.id})]),
          el('span', {class: 'fp-bgw-state'}, [B.pill(t(g.enabled ? 'bgw_on' : 'bgw_off'), g.enabled ? 'ok' : '')]),
          g.id === 'test' ? el('p', {class: 'fp-muted fp-row-note fp-bgw-warn', id: 'fp-bgw-test-warn', text: t('bgw_test_warn')}) : null]);
      });
      var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bil_save_changes')});
      var form = el('form', {class: 'fp-form fp-bgw-form', novalidate: '', 'aria-labelledby': 'fp-bgw-h'}, [M.errorLine(), M.statusLine(),
        list.length ? el('fieldset', {class: 'fp-bil-set'}, [el('legend', {class: 'sig-label', text: t('bgw_legend')}), el('ul', {class: 'fp-bgw-list'}, boxes)]) :
          el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('bgw_none')}),
        list.length ? el('div', {class: 'fp-actions', 'data-fp-acts': ''}, [save]) : null]);
      var test = form.querySelector('#fp-bgw-test');
      if (test) { test.setAttribute('aria-describedby', 'fp-bgw-test-warn'); }
      function chosen() { return Array.prototype.filter.call(form.querySelectorAll('[name="enabled"]'), function (c) { return c.checked; }).map(function (c) { return c.value; }); }
      function send(b, on) {
        UI.setBusy(b, true);
        FP.call('put', 'billingGatewaysSet', {enabled: on}).then(function (r) {
          if (!alive()) { return; }
          draw(clean(r), t('bgw_saved'));
        }, function (err) {
          if (!alive()) { return; }
          draw(list);
          /* a refusal on "enabled" is about the list as a whole: no one box is marked */
          var shown = err && err.field === 'enabled' ? {message: err.message} : err;
          B.failed(top.querySelector('.fp-bgw-form'), shown);
        });
      }
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!B.begin(form, save)) { return; }
        var on = chosen();
        var off = list.filter(function (g) { return g.enabled && on.indexOf(g.id) < 0; });
        if (!off.length && on.length === list.filter(function (g) { return g.enabled; }).length) { M.say(form, t('bil_nothing_changed')); return; }
        if (!off.length) { send(save, on); return; }
        /* turning a gateway off is asked first */
        var box = form.querySelector('[data-fp-acts]');
        box.textContent = '';
        var yes = el('button', {class: 'sig-btn sig-btn--danger', type: 'button', text: t('bgw_off_yes'), 'aria-describedby': 'fp-bgw-q'});
        var no = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', text: t('bgw_off_keep'), 'aria-describedby': 'fp-bgw-q'});
        box.appendChild(el('p', {class: 'fp-mail-confirm', id: 'fp-bgw-q', text: t('bgw_off_ask', {names: off.map(function (g) { return g.name || g.id; }).join(', ')})}));
        box.appendChild(yes);
        box.appendChild(no);
        yes.addEventListener('click', function () { send(yes, on); });
        no.addEventListener('click', function () { box.textContent = ''; box.appendChild(save); save.focus(); });
        no.focus();
      });
      B.screen(top, [B.card('fp-bgw-h', t('bgw_title'), [el('p', {class: 'fp-muted', text: t('bgw_what')}), form], 'fp-bgw', 'gateways')]);
      if (said) { M.say(top.querySelector('.fp-bgw-form'), said); top.querySelector('#fp-bgw-h').focus(); }
      if (!keysDrawn) { keysDrawn = true; list.forEach(function (g) { if (KEYS[g.id]) { keysOf(keys, g); } }); }
    }
    /* ---- a provider's keys: one card each for Stripe and PayPal ---- */
    function cleanKeys(r) {
      var v = B.pick(r, {gateway: [40], enabled: 'b', ready: 'b', mode: ['=', ['sandbox', 'live']], api_base: [200], notice_url: [300]}) || {};
      v.missing = (r && Array.isArray(r.missing) ? r.missing : []).filter(function (x) { return typeof x === 'string'; }).map(function (x) { return x.slice(0, 40); });
      v.events = (r && Array.isArray(r.events) ? r.events : []).filter(function (x) { return typeof x === 'string'; }).map(function (x) { return x.slice(0, 80); });
      var plain = r && r.settings && typeof r.settings === 'object' ? r.settings : {};
      var secrets = r && r.secrets && typeof r.secrets === 'object' ? r.secrets : {};
      v.plain = {};
      v.secrets = {};
      Object.keys(plain).forEach(function (k) { if (typeof plain[k] === 'string') { v.plain[k] = plain[k].slice(0, 300); } });
      Object.keys(secrets).forEach(function (k) { v.secrets[k] = secrets[k] === true; });
      return v;
    }
    function keysOf(box, g) {
      var slot = el('div', {'data-fp-keys': g.id}, [el('p', {class: 'fp-muted', text: t('loading')})]);
      box.appendChild(slot);
      FP.call('get', 'billingGatewaySettings', undefined, {id: g.id}).then(function (r) {
        if (alive() && slot.isConnected) { keysCard(slot, g, cleanKeys(r)); }
      }, function (err) {
        if (!alive() || !slot.isConnected) { return; }
        slot.textContent = '';
        slot.appendChild(B.card('fp-bgk-' + g.id + '-h', t('bgk_title', {name: g.name || g.id}), [el('p', {class: 'fp-warn-line', text: err.message})], 'fp-bgk'));
      });
    }
    function keysCard(slot, g, v, said) {
      var pre = 'fp-bgk-' + g.id;
      var spec = KEYS[g.id];
      var fields = [];
      if (spec.mode) {
        fields.push(M.field(pre + '-mode', t('bgk_mode'), B.select(pre + '-mode', 'mode', [['sandbox', t('bgk_mode_sandbox')], ['live', t('bgk_mode_live')]], v.mode || 'sandbox'),
          t('bgk_mode_hint')));
      }
      spec.plain.forEach(function (k) {
        fields.push(M.field(pre + '-' + k, t('bgk_' + k), B.input(pre + '-' + k, k, v.plain[k] || '', {maxlength: '200', spellcheck: 'false', autocapitalize: 'none'}),
          t('bgk_' + k + '_hint')));
      });
      spec.secret.forEach(function (k) {
        var set = v.secrets[k];
        fields.push(M.field(pre + '-' + k, t('bgk_' + k), B.input(pre + '-' + k, k, '', {type: 'password', maxlength: '500', autocomplete: 'new-password', spellcheck: 'false',
          autocapitalize: 'none', 'data-fp-secret': set ? 'set' : 'unset'}), t('bgk_' + k + '_hint') + ' ' + t(set ? 'bgk_secret_set' : 'bgk_secret_unset')));
      });
      var base = ownBase(g.id, v);
      fields.push(M.field(pre + '-api_base', t('bgk_api_base'), B.input(pre + '-api_base', 'api_base', base, {maxlength: '200', spellcheck: 'false',
        autocapitalize: 'none', inputmode: 'url', placeholder: (API[g.id] && API[g.id][v.mode || 'sandbox']) || null}), t('bgk_api_base_hint')));
      var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bgk_save', {name: g.name || g.id})});
      var form = el('form', {class: 'fp-form fp-bil-crud-form fp-bgk-form', novalidate: '', autocomplete: 'off', 'aria-labelledby': pre + '-h'}, [M.errorLine(), M.statusLine(),
        el('div', {class: 'fp-bil-grid'}, fields), el('div', {class: 'fp-actions'}, [save])]);
      var state = v.ready || v.missing.length ? el('p', {class: v.ready ? 'fp-ok-line fp-bgk-state' : 'fp-warn-line fp-bgk-state', 'data-fp-ready': v.ready ? 'yes' : 'no',
        text: v.ready ? t('bgk_ready') : t('bgk_missing', {names: v.missing.map(function (k) { return has('bgk_' + k) ? t('bgk_' + k) : k; }).join(', ')})}) : null;
      var hook = [el('h3', {class: 'fp-bgk-sub', text: t('bgk_hook_title')}), el('p', {class: 'fp-muted', text: t('bgk_hook_' + g.id)})];
      if (v.notice_url) { hook.push(el('p', {}, [el('code', {class: 'fp-bgk-url', 'data-fp-notice': '', text: v.notice_url})])); }
      if (v.events.length) {
        hook.push(el('p', {class: 'fp-muted', text: t('bgk_events')}));
        hook.push(el('ul', {class: 'fp-bgk-events'}, v.events.map(function (e) { return el('li', {}, [el('code', {text: e})]); })));
      }
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!B.begin(form, save)) { return; }
        var body = {};
        if (spec.mode) { var m = UI.fieldNamed(form, 'mode').value; if (m !== (v.mode || 'sandbox')) { body.mode = m; } }
        spec.plain.concat(['api_base']).forEach(function (k) {
          var x = UI.fieldNamed(form, k).value.trim();
          if (x !== ((k === 'api_base' ? base : v.plain[k]) || '')) { body[k] = x; }
        });
        spec.secret.forEach(function (k) { var x = UI.fieldNamed(form, k).value.trim(); if (x) { body[k] = x; } });
        if (!Object.keys(body).length) { M.say(form, t('bil_nothing_changed')); return; }
        UI.setBusy(save, true);
        FP.call('patch', 'billingGatewaySettings', body, {id: g.id}).then(function (r) {
          if (!alive() || !form.isConnected) { return; }
          keysCard(slot, g, cleanKeys(r), t('bgk_saved', {name: g.name || g.id}));
        }, function (err) {
          if (!alive() || !form.isConnected) { return; }
          UI.setBusy(save, false);
          B.failed(form, err);
        });
      });
      slot.textContent = '';
      slot.appendChild(B.card(pre + '-h', t('bgk_title', {name: g.name || g.id}), [el('p', {class: 'fp-muted', text: t('bgk_what_' + g.id)}), state, form].concat(hook), 'fp-bgk'));
      if (said) { M.say(form, said); slot.querySelector('#' + pre + '-h').focus(); }
    }
    function load() {
      FP.call('get', 'billingGateways').then(function (r) {
        if (alive()) { draw(clean(r)); }
      }, function (err) {
        if (!alive()) { return; }
        B.screen(top, [FP.empty(t('bgw_title'), err.message, B.button('reload', t('bil_try_again')))]);
        top.querySelector('[data-fp-act="reload"]').addEventListener('click', load);
      });
    }
    load();
  });
})();

/* freePanel panel themes (issue #659; docs/api.md, "Panel themes"): a layout (Modern, Classic) and a colour scheme, each the login's
   own choice or the server's default. The session says which to draw ("theme"); fp-boot.js applies the last one before first paint
   from what this file keeps, so a page never flashes the other way. The Switch theme menu sits in the top bar and in the account
   menu, and a change is drawn at once: the classes on <html> change and the current page is drawn again. Also keeps the tools a login
   opened last, for Classic's Frequently used box. Only names from the lists below ever become classes. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var root = document.documentElement;

  var LAYOUTS = ['modern', 'classic', 'cards', 'domains'];
  var SCHEMES = ['default', 'ocean', 'high-contrast'];
  var RECENT_MAX = 8;
  var current = {layout: 'modern', scheme: 'default'};

  function known(list, v) { return list.indexOf(v) >= 0 ? v : list[0]; }
  function setClass(prefix, list, v) {
    list.forEach(function (x) { root.classList.toggle(prefix + x, x === v); });
  }
  /* a login that has not chosen a scheme itself follows the browser's prefers-contrast: more with the high-contrast scheme */
  var schemeChosen = true;
  function moreContrast() { return Boolean(window.matchMedia && window.matchMedia('(prefers-contrast: more)').matches); }
  function apply(theme) {
    var th = theme && typeof theme === 'object' ? theme : {};
    current = {layout: known(LAYOUTS, th.layout), scheme: known(SCHEMES, th.scheme)};
    if (!schemeChosen && moreContrast()) { current.scheme = 'high-contrast'; }
    setClass('fp-layout-', LAYOUTS, current.layout);
    setClass('fp-scheme-', SCHEMES, current.scheme);
    UI.store.set('fp.layout', current.layout);
    UI.store.set('fp.scheme', current.scheme);
    syncButtons();
  }

  function label(kind, v) { return t('theme_' + kind + '_' + v.replace(/-/g, '_')); }
  function choiceGroup(kind, list, idBase) {
    var head = el('p', {class: 'fp-theme-head', id: idBase + '-' + kind, text: t('theme_' + kind)});
    var group = el('div', {class: 'sig-modes fp-theme-choices', role: 'group', 'aria-labelledby': idBase + '-' + kind},
      list.map(function (v) {
        return el('button', {type: 'button', 'data-fp-theme-kind': kind, 'data-fp-theme-value': v, 'aria-pressed': 'false', text: label(kind, v)});
      }));
    return [head, group];
  }
  function syncButtons() {
    var bs = document.querySelectorAll('[data-fp-theme-kind]');
    for (var i = 0; i < bs.length; i++) {
      var on = current[bs[i].getAttribute('data-fp-theme-kind')] === bs[i].getAttribute('data-fp-theme-value');
      bs[i].setAttribute('aria-pressed', String(on));
    }
  }
  function fillMenus() {
    var spots = document.querySelectorAll('[data-fp-theme-menu]');
    for (var i = 0; i < spots.length; i++) {
      var spot = spots[i];
      spot.textContent = '';
      var base = 'fp-theme-' + spot.getAttribute('data-fp-theme-menu');
      choiceGroup('layout', LAYOUTS, base).concat(choiceGroup('scheme', SCHEMES, base)).forEach(function (n) { spot.appendChild(n); });
      spot.appendChild(el('p', {class: 'fp-alert', role: 'alert', 'data-fp-theme-error': ''}));
    }
    syncButtons();
  }
  function showError(text) {
    var alerts = document.querySelectorAll('[data-fp-theme-error]');
    for (var i = 0; i < alerts.length; i++) { alerts[i].textContent = text; }
  }

  function choose(button) {
    var kind = button.getAttribute('data-fp-theme-kind');
    var value = button.getAttribute('data-fp-theme-value');
    if (current[kind] === value) { return; }
    var payload = {};
    payload[kind] = value;
    showError('');
    UI.setBusy(button, true);
    FP.call('put', 'panelTheme', payload).then(function (res) {
      var next = {layout: current.layout, scheme: current.scheme};
      next[kind] = value;
      if (kind === 'scheme') { schemeChosen = true; }
      /* an empty part of the answer follows the default the answer carries */
      var def = res && res.default && typeof res.default === 'object' ? res.default : {};
      if (res && typeof res.layout === 'string') { next.layout = res.layout || def.layout; }
      if (res && typeof res.scheme === 'string') { next.scheme = res.scheme || def.scheme; }
      apply(next);
      UI.setBusy(button, false);
      var live = document.getElementById('fp-live');
      if (live) { live.textContent = t('theme_changed', {name: label(kind, value)}); }
      if (FP.started) { if (kind === 'layout' && FP.renderMenu) { FP.renderMenu(); } renderFoot(); FP.route(false); }
      var again = document.querySelector('[data-fp-theme-kind="' + kind + '"][data-fp-theme-value="' + value + '"]');
      if (again && document.activeElement === document.body) { again.focus(); }
    }, function (err) {
      UI.setBusy(button, false);
      showError(err && err.message ? err.message : t('api_failed'));
    });
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('[data-fp-theme-kind]') : null;
    if (b && !b.disabled) { choose(b); }
  });

  /* ---- Frequently used: the tools this login opened last, newest first ---- */
  function recentKey() { return 'fp.recent.' + FP.realm; }
  function recent() {
    var list = UI.store.json(recentKey(), []);
    return (Array.isArray(list) ? list : []).filter(function (id) { return typeof id === 'string' && FP.tools[id]; }).slice(0, RECENT_MAX);
  }
  function remember() {
    var m = /^#\/tool\/([a-z0-9_]+)$/.exec(window.location.hash);
    var id = m ? m[1] : '';
    if (!id) {
      var v = /^#\/([a-z0-9-]+)$/.exec(window.location.hash);
      for (var k in FP.tools) { if (v && FP.tools[k].route === v[1]) { id = k; break; } }
    }
    if (!id || !FP.tools[id]) { return; }
    var list = [id].concat(recent().filter(function (x) { return x !== id; })).slice(0, RECENT_MAX);
    UI.store.set(recentKey(), JSON.stringify(list));
  }

  /* ---- a quick action's domain (or account), pre-selected on the page it opens: a row for it is brought into view and marked, or a
     picker that offers it is set to it. Only a value the page itself offers is ever chosen; kept for one page, at most 8 seconds. ---- */
  var PICK_RE = /^[a-z0-9][a-z0-9.-]{0,252}$/;
  var pickWatch = null;
  function stopPick() { if (pickWatch) { pickWatch.observer.disconnect(); window.clearTimeout(pickWatch.timer); pickWatch = null; } }
  function tryPick(main, v) {
    var row = main.querySelector('[data-fp-site="' + (window.CSS && window.CSS.escape ? window.CSS.escape(v) : v) + '"]');
    if (row) {
      row.classList.add('fp-picked');
      if (row.scrollIntoView) { row.scrollIntoView({block: 'center'}); }
      return true;
    }
    var sels = main.querySelectorAll('select');
    for (var i = 0; i < sels.length; i++) {
      var s = sels[i];
      for (var j = 0; j < s.options.length; j++) {
        if (s.options[j].value === v) {
          if (s.value !== v) { s.value = v; s.dispatchEvent(new Event('change', {bubbles: true})); }
          return true;
        }
      }
    }
    return false;
  }
  function watchPick() {
    stopPick();
    var v = UI.store.get('fp.pick') || '';
    UI.store.del('fp.pick');
    var main = document.getElementById('sig-main');
    if (!v || !PICK_RE.test(v) || !main || !window.MutationObserver) { return; }
    if (tryPick(main, v)) { return; }
    var observer = new window.MutationObserver(function () { if (tryPick(main, v)) { stopPick(); } });
    observer.observe(main, {childList: true, subtree: true});
    pickWatch = {observer: observer, timer: window.setTimeout(stopPick, 8000)};
  }
  document.addEventListener('click', function (e) {
    var a = e.target.closest ? e.target.closest('a[data-fp-pick]') : null;
    if (a && PICK_RE.test(a.getAttribute('data-fp-pick'))) { UI.store.set('fp.pick', a.getAttribute('data-fp-pick')); }
  });

  /* ---- Domains: the login's name and package at the foot of the side menu ---- */
  function renderFoot() {
    var foot = document.querySelector('[data-fp-side-foot]');
    if (!foot || !FP.session) { return; }
    var old = foot.querySelector('[data-fp-dm-foot]');
    if (old) { old.parentNode.removeChild(old); }
    if (current.layout !== 'domains') { return; }
    var u = FP.session.user || {};
    var box = el('div', {class: 'fp-dm-foot', 'data-fp-dm-foot': ''}, [el('b', {class: 'fp-dm-foot-name', text: typeof u.username === 'string' ? u.username : ''}),
      el('span', {class: 'fp-dm-foot-plan'})]);
    foot.appendChild(box);
    if (FP.summary && FP.realm === 'user') {
      FP.summary().then(function (acc) {
        if (acc && typeof acc.package === 'string' && acc.package) { box.querySelector('.fp-dm-foot-plan').textContent = t('dm_package', {name: acc.package}); }
      }, function () { /* the name alone */ });
    } else {
      box.querySelector('.fp-dm-foot-plan').textContent = t(u.role === 'admin' ? 'role_admin' : u.role === 'reseller' ? 'role_reseller' : 'role_user');
    }
  }

  FP.theme = {
    current: function () { return {layout: current.layout, scheme: current.scheme}; },
    classic: function () { return current.layout === 'classic'; },
    cards: function () { return current.layout === 'cards'; },
    domains: function () { return current.layout === 'domains'; },
    recent: recent
  };

  document.addEventListener('fp:ready', function () {
    remember();
    renderFoot();
    window.addEventListener('hashchange', function () { remember(); watchPick(); });
  });

  /* the session is read by fp-shell.js; take its theme before the first page is drawn */
  var before = FP.beforeStart;
  FP.beforeStart = function (session) {
    schemeChosen = !(session && session.theme && session.theme.scheme_chosen === false);
    apply(session && session.theme);
    fillMenus();
    return before ? before(session) : null;
  };
  /* until the session answers, draw what fp-boot.js applied */
  current = {layout: LAYOUTS.filter(function (l) { return root.classList.contains('fp-layout-' + l); })[0] || 'modern', scheme: 'default'};
})();

/* freePanel licence (#/tool/licence), the admin panel's Licence page (docs/api.md, "Licence"), the lock screen every login sees
   while the panel is locked, and the banner the administrator sees in grace. The page shows what the licence service has said
   about this server, checks again on request, and takes a key. Everything the server sends is drawn as text. The shell shows
   the lock screen (FP.locked, from the session) in place of every view: the administrator's is the Licence page with a note on
   top, anyone else's a plain "unavailable". Hosting is never locked, and the screens say so. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var STATES = ['unenforced', 'unlicensed', 'licensed', 'grace', 'locked'];
  var REASONS = ['no_key', 'no_lease', 'lease_ended', 'suspended', 'revoked', 'expired', 'in_use', 'unknown'];
  var KEY_RE = /^FP1\.[A-Za-z0-9_-]{1,64}\.[A-Za-z0-9_-]{1,4096}\.[A-Za-z0-9_-]{1,1024}$/;
  var DAY = 86400000;

  var V = null;   /* the page being shown: its body, what the server last said and whether a call is out */

  /* the daemon's own words, which start in lower case */
  function sentence(m) { return typeof m === 'string' && m ? m.charAt(0).toUpperCase() + m.slice(1) : m; }
  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function stamp(iso) {
    var d = typeof iso === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(iso) ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) && d.getFullYear() > 2000 ? d : null;
  }
  function when(d) { return d ? d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'}) : t('lic_never'); }
  function day(d) { return d.toLocaleString('en', {dateStyle: 'medium'}); }

  /* the parts of freePanel a licence can name (internal/licensing) */
  var FEATURES = ['panel', 'billing'];

  /* the licence status, or null when the answer is not one */
  function clean(r) {
    if (!r || typeof r !== 'object' || STATES.indexOf(r.state) < 0) { return null; }
    return {enforced: r.enforced === true, state: r.state, reason: REASONS.indexOf(r.reason) >= 0 || r.reason === 'upgrade' ? r.reason : '',
      id: str(r.license_id, 80), customer: str(r.customer, 120), plan: str(r.plan, 40), validUntil: stamp(r.valid_until), graceUntil: stamp(r.grace_until),
      lastCheck: stamp(r.last_check), lastOk: stamp(r.last_ok), lastError: str(r.last_error, 300), message: str(r.message, 300), serverId: str(r.server_id, 80),
      features: Array.isArray(r.features) ? r.features.filter(function (f) { return FEATURES.indexOf(f) >= 0; }) : null,
      clockOff: r.clock_off === true, shopUrl: typeof r.shop_url === 'string' && /^https?:\/\/[A-Za-z0-9.:[\]-]{1,300}$/.test(r.shop_url) ? r.shop_url : ''};
  }

  /* what the state says in a sentence */
  function say(s) {
    if (s.state === 'unenforced') { return t('lic_say_unenforced'); }
    if (s.state === 'licensed') { return t('lic_say_licensed'); }
    if (s.state === 'grace') {
      if (s.reason === 'upgrade') { return t(s.graceUntil ? 'lic_say_upgrade' : 'lic_say_upgrade_nodate', {until: when(s.graceUntil)}); }
      return t(s.graceUntil ? 'lic_say_grace' : 'lic_say_grace_nodate', {until: when(s.graceUntil)});
    }
    var why = REASONS.indexOf(s.reason) >= 0 ? t('lic_reason_' + s.reason) : '';
    return (why ? why + ' ' : '') + t(s.state === 'unlicensed' ? 'lic_say_unlicensed' : 'lic_say_locked');
  }
  function pill(s) {
    var cls = s.state === 'licensed' ? ' sig-pill--ok' : s.state === 'grace' ? ' sig-pill--warn' : s.state === 'locked' || s.state === 'unlicensed' ? ' sig-pill--danger' : '';
    return el('span', {class: 'sig-pill' + cls, 'data-fp-state': s.state, text: t('lic_state_' + s.state)});
  }

  /* ---- the status ---- */
  function facts(s) {
    var rows = [];
    if (s.customer) { rows.push(['customer', t('lic_f_customer'), s.customer]); }
    if (s.plan) { rows.push(['plan', t('lic_f_plan'), s.plan]); }
    if (s.id) { rows.push(['id', t('lic_f_id'), s.id]); }
    if (s.enforced && s.features) {
      rows.push(['includes', t('lic_f_includes'), s.features.map(function (f) { return t('lic_feat_' + f); }).join(', ')]);
    }
    if (s.enforced) {
      rows.push(['valid', t('lic_f_valid'), s.validUntil ? when(s.validUntil) : '—']);
      if (s.graceUntil) { rows.push(['grace', t(s.reason === 'upgrade' ? 'lic_f_grace_upgrade' : 'lic_f_grace'), when(s.graceUntil)]); }
      rows.push(['check', t('lic_f_check'), when(s.lastCheck)], ['ok', t('lic_f_ok'), when(s.lastOk)]);
    }
    if (s.serverId) { rows.push(['server', t('lic_f_server'), s.serverId]); }
    return el('dl', {class: 'fp-mail-facts fp-lic-facts'}, rows.reduce(function (out, r) {
      return out.concat([el('dt', {text: r[1]}), el('dd', {'data-fp-fact': r[0], text: r[2]})]);
    }, []));
  }
  function statusCard() {
    var s = V.status;
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-lic-state'}, [pill(s), el('span', {'data-fp-say': '', text: ' ' + say(s)})])];
    if (s.state !== 'unenforced' && s.state !== 'licensed') { parts.push(el('p', {class: 'fp-muted', 'data-fp-runs': '', text: t('lic_hosting_runs')})); }
    parts.push(facts(s));
    if (s.lastError) { parts.push(el('p', {class: 'fp-warn-line', 'data-fp-last-error': '', text: t('lic_last_error', {error: s.lastError})})); }
    if (s.clockOff) { parts.push(el('p', {class: 'fp-warn-line', 'data-fp-clock': '', text: t('lic_clock_off')})); }
    if (s.message) { parts.push(el('p', {class: 'fp-muted', 'data-fp-message': '', text: t('lic_message', {message: s.message})})); }
    if (s.enforced && s.id) {
      parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'check', text: t('lic_check')})]));
    }
    return M.card('fp-lic-h', t('lic_status_title'), parts, 'fp-lic');
  }

  /* ---- the key ---- */
  /* when a key ends, read from the key itself (its middle part is the signed text, which says it); null when it can't be read.
     The server decides what a key is worth: this only keeps an old key, from before a renewal, from being sent at all. */
  function keyEnds(key) {
    try {
      var b = key.split('.')[2].replace(/-/g, '+').replace(/_/g, '/');
      while (b.length % 4) { b += '='; }
      var raw = window.atob(b);
      var bytes = new window.Uint8Array(raw.length);
      for (var i = 0; i < raw.length; i++) { bytes[i] = raw.charCodeAt(i); }
      var j = JSON.parse(new window.TextDecoder().decode(bytes));
      return j && typeof j === 'object' ? stamp(j.expires) : null;
    } catch (e) {
      return null;
    }
  }
  function keyCard() {
    var s = V.status;
    var has = Boolean(s.id);
    var area = el('textarea', {class: 'sig-input fp-lic-key', id: 'fp-lic-key', name: 'key', rows: '4', maxlength: '6000', autocomplete: 'off',
      spellcheck: 'false', autocapitalize: 'none', disabled: V.busy ? true : null});
    var form = el('form', {class: 'fp-form fp-lic-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-lic-key', t('lic_key_label'), area, t('lic_key_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('lic_key_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || V.busy) { return; }
      var key = area.value.replace(/\s+/g, '');
      if (!key) { M.fieldError(form, area, t('lic_key_none')); return; }
      if (!KEY_RE.test(key)) { M.fieldError(form, area, t('lic_key_bad')); return; }
      var ends = keyEnds(key);
      if (ends && ends.getTime() < Date.now() - DAY) { M.fieldError(form, area, t('lic_key_ended', {date: day(ends)})); return; }
      save(form, b, key);
    });
    return M.card('fp-lic-key-h', t(has ? 'lic_key_title_change' : 'lic_key_title'), [el('p', {class: 'fp-muted', text: t(has ? 'lic_key_desc_change' : 'lic_key_desc')}), form],
      'fp-lic-keycard');
  }
  function save(form, b, key) {
    var mine = V;
    V.busy = true;
    UI.setBusy(b, true);
    M.say(form, t('lic_key_working'));
    FP.call('put', 'licenseKey', {key: key}).then(function (r) {
      if (V !== mine) { return; }
      mine.busy = false;
      var s = clean(r);
      if (!s) { UI.setBusy(b, false); M.say(form, ''); M.fieldError(form, null, t('api_failed')); return; }
      mine.status = s;
      /* the key is not kept on the page: the box is made again, empty */
      if (FP.locked && !closes(s)) { window.location.reload(); return; }
      setBanner(s);
      draw(t('lic_key_saved', {say: say(s)}), '.fp-lic-keycard');
    }, function (err) {
      if (V !== mine) { return; }
      mine.busy = false;
      UI.setBusy(b, false);
      M.say(form, '');
      M.fieldError(form, err.field === 'key' ? UI.fieldNamed(form, 'key') : null, sentence(err.message));
    });
  }

  /* ---- buying and managing: the licence site takes the payment; a key bought from here is put in with the delivery code ----
     The purchase code goes to the licence site in the Buy link, so whoever made a link has it: the site gives the key only with the
     delivery code it shows the buyer after payment, on their own account page, which the admin types in here. */
  var CLAIM_KEY = 'fp.licclaim';
  var CLAIM_FOR = 24 * 3600000;   /* how long a purchase started here can be finished with its delivery code (the licence site's own limit) */
  var CODE_RE = /^[2-9A-HJ-NP-Z]{8}$/;
  function newClaim() {
    var b = new window.Uint8Array(16);
    window.crypto.getRandomValues(b);
    return Array.prototype.map.call(b, function (x) { return (x < 16 ? '0' : '') + x.toString(16); }).join('');
  }
  /* the purchase started from this browser that is still being waited for, or null */
  function heldClaim() {
    var c = UI.store.json(CLAIM_KEY, null);
    if (!c || typeof c.claim !== 'string' || !/^[a-f0-9]{32}$/.test(c.claim) || typeof c.at !== 'number' || Date.now() - c.at > CLAIM_FOR) {
      UI.store.del(CLAIM_KEY);
      return null;
    }
    return c.claim;
  }
  function shopLink(path) { return V.status.shopUrl + path; }
  /* this panel needs a key: a purchase started here puts the bought key in; otherwise Buy buys for another server */
  function needsKey(s) { return !s.id || closes(s) || s.state === 'grace'; }
  function buyCard() {
    var s = V.status;
    var need = needsKey(s);
    var buy = el('a', {class: 'sig-btn ' + (need ? 'sig-btn--primary' : 'sig-btn--secondary'), href: shopLink('/buy'), target: '_blank', rel: 'noopener',
      'data-fp-act': 'buy', text: t('lic_buy')});
    var manage = el('a', {class: 'sig-btn sig-btn--secondary', href: shopLink('/account'), target: '_blank', rel: 'noopener', 'data-fp-manage': '',
      text: t('lic_manage')});
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t(need ? 'lic_buy_desc' : 'lic_buy_desc_more')}),
      el('div', {class: 'fp-actions'}, [buy, manage])];
    if (V.claim) { parts.push(codeForm()); }
    return M.card('fp-lic-buy-h', t('lic_buy_title'), parts, 'fp-lic-buy');
  }
  /* support is bought on the licence site: a plan for a licence, or a one-off fix */
  function supportCard() {
    var open = el('a', {class: 'sig-btn sig-btn--secondary', href: shopLink('/support'), target: '_blank', rel: 'noopener', 'data-fp-support': '',
      text: t('lic_sup_open')});
    return M.card('fp-lic-sup-h', t('lic_sup_title'), [el('p', {class: 'fp-muted', text: t('lic_sup_desc')}), el('div', {class: 'fp-actions'}, [open])],
      'fp-lic-sup');
  }
  /* the Buy button: the licence site gets a purchase code; the key bought with it comes back here with the delivery code */
  function startBuy(a) {
    var claim = heldClaim() || newClaim();
    UI.store.set(CLAIM_KEY, JSON.stringify({claim: claim, at: Date.now()}));
    a.href = shopLink('/buy?claim=' + claim);
    V.claim = claim;
    var card = V.page.querySelector('.fp-lic-buy');
    if (card && !card.querySelector('[data-fp-claim]')) { card.appendChild(codeForm()); }
  }
  /* the delivery code the licence site shows after payment: typed here, it brings the key */
  function codeForm() {
    var input = el('input', {class: 'sig-input fp-lic-code', id: 'fp-lic-code', name: 'code', type: 'text', maxlength: '20', autocomplete: 'off',
      spellcheck: 'false', autocapitalize: 'characters'});
    var form = el('form', {class: 'fp-form fp-lic-claim', novalidate: '', 'data-fp-claim': ''}, [
      el('div', {class: 'sig-banner', role: 'note'}, [UI.icon(FP.ui, 'ui_key'), el('span', {text: t('lic_buy_waiting')})]),
      M.errorLine(), M.statusLine(),
      M.field('fp-lic-code', t('lic_code_label'), input, t('lic_code_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('lic_code_go')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || V.busy) { return; }
      var code = input.value.replace(/[\s-]+/g, '').toUpperCase();
      if (!code) { M.fieldError(form, input, t('lic_code_none')); return; }
      if (!CODE_RE.test(code)) { M.fieldError(form, input, t('lic_code_bad')); return; }
      sendCode(form, b, input, code);
    });
    return form;
  }
  function sendCode(form, b, input, code) {
    var mine = V;
    V.busy = true;
    UI.setBusy(b, true);
    M.say(form, t('lic_code_working'));
    FP.call('post', 'licenseClaim', {claim: mine.claim, code: code}).then(function (r) {
      if (V !== mine) { return; }
      mine.busy = false;
      UI.setBusy(b, false);
      var s = r && r.status ? clean(r.status) : null;
      if (!s) { M.say(form, t('lic_code_pending')); return; }
      UI.store.del(CLAIM_KEY);
      mine.claim = null;
      mine.status = s;
      if (FP.locked && !closes(s)) { window.location.reload(); return; }
      setBanner(s);
      draw(t('lic_buy_done', {say: say(s)}));
    }, function (err) {
      if (V !== mine) { return; }
      mine.busy = false;
      UI.setBusy(b, false);
      M.say(form, '');
      if (err.field === 'claim') { UI.store.del(CLAIM_KEY); mine.claim = null; draw(''); return; }
      M.fieldError(form, err.field === 'code' ? input : null, sentence(err.message));
    });
  }

  /* ---- the servers holding the licence: one the licence moved away from is freed here ---- */
  function serversCard() {
    var body = el('div', {'data-fp-servers': ''}, [el('p', {class: 'fp-muted', text: t('loading')})]);
    return M.card('fp-lic-srv-h', t('lic_srv_title'), [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t('lic_srv_desc')}), body],
      'fp-lic-servers');
  }
  function loadServers() {
    var mine = V;
    var card = V.page.querySelector('.fp-lic-servers');
    if (!card) { return; }
    FP.call('get', 'licenseServers').then(function (r) {
      if (V !== mine) { return; }
      fillServers(card, r);
    }, function (err) {
      if (V !== mine) { return; }
      var body = card.querySelector('[data-fp-servers]');
      body.textContent = '';
      UI.showError(card, sentence(err.message));
    });
  }
  function fillServers(card, r) {
    var body = card.querySelector('[data-fp-servers]');
    body.textContent = '';
    var list = r && Array.isArray(r.servers) ? r.servers.slice(0, 1000) : [];
    var max = r && typeof r.max_servers === 'number' ? r.max_servers : 0;
    body.appendChild(el('p', {'data-fp-places': '', text: t('lic_srv_places', {used: String(list.length), max: String(max)})}));
    if (!list.length) { return; }
    var tbody = el('tbody');
    list.forEach(function (x) {
      var id = str(x.server_id, 32);
      if (!/^[a-f0-9]{32}$/.test(id)) { return; }
      var act = el('td', {class: 'fp-actions-cell'});
      if (x.this === true) {
        act.appendChild(el('span', {class: 'sig-pill sig-pill--ok', 'data-fp-this': '', text: t('lic_srv_this')}));
      } else {
        act.appendChild(el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'release-ask',
          'aria-label': t('lic_srv_release_of', {name: str(x.hostname, 253) || id}), text: t('lic_srv_release')}));
      }
      tbody.appendChild(el('tr', {'data-fp-server': id}, [el('td', {text: str(x.hostname, 253) || '—'}), el('td', {text: str(x.ip, 60) || '—'}),
        el('td', {text: when(stamp(x.last_seen))}), act]));
    });
    var head = el('tr', null, [el('th', {scope: 'col', text: t('lic_srv_host')}), el('th', {scope: 'col', text: t('lic_srv_ip')}),
      el('th', {scope: 'col', text: t('lic_srv_seen')}), el('th', {scope: 'col'}, [el('span', {class: 'sig-sr-only', text: t('lic_srv_actions')})])]);
    body.appendChild(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-lic-srv-h'}, [
      el('table', {class: 'sig-table fp-lic-srv-table'}, [el('thead', null, [head]), tbody])]));
  }
  function release(button, id) {
    var mine = V;
    var card = V.page.querySelector('.fp-lic-servers');
    V.busy = true;
    UI.setBusy(button, true);
    UI.showError(card, '');
    M.say(card, t('lic_srv_releasing'));
    FP.call('post', 'licenseRelease', {server_id: id}).then(function (r) {
      if (V !== mine) { return; }
      mine.busy = false;
      var s = clean(r);
      if (!s) { UI.setBusy(button, false); M.say(card, ''); UI.showError(card, t('api_failed')); return; }
      mine.status = s;
      if (FP.locked && !closes(s)) { window.location.reload(); return; }
      setBanner(s);
      draw(t('lic_srv_released', {say: say(s)}), '.fp-lic-servers');
    }, function (err) {
      if (V !== mine) { return; }
      mine.busy = false;
      UI.setBusy(button, false);
      M.say(card, '');
      UI.showError(card, sentence(err.message));
      button.focus();
    });
  }

  /* ---- the page ---- */
  /* the panel is shut by this status (docs/api.md: locked and unlicensed) */
  /* freePanel's own terms and the third-party software in it: the notices file the build puts beside the panels' assets
     (and the installer in /usr/local/freepanel/share/doc). */
  function noticesCard() {
    return M.card('fp-lic-tp-h', t('lic_tp_title'), [el('p', {class: 'fp-muted', text: t('lic_tp_desc')}),
      el('p', null, [el('a', {href: '/assets/THIRD_PARTY_NOTICES.txt', target: '_blank', rel: 'noopener', 'data-fp-notices': '', text: t('lic_tp_link')})])],
      'fp-lic-tp');
  }
  function closes(s) { return s.enforced && (s.state === 'locked' || s.state === 'unlicensed'); }
  function lockNote() {
    return el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-lock-note': ''}, [UI.icon(FP.ui, 'ui_warning'),
      el('span', {text: t('lic_lock_note') + ' ' + t('lic_hosting_runs')})]);
  }
  function draw(note, scope) {
    V.page.textContent = '';
    if (V.locked || closes(V.status)) { V.page.appendChild(lockNote()); }
    V.page.appendChild(statusCard());
    if (V.status.enforced && V.status.shopUrl) { V.page.appendChild(buyCard()); V.page.appendChild(supportCard()); }
    if (V.status.enforced || V.status.state !== 'unenforced') { V.page.appendChild(keyCard()); }
    if (V.status.enforced && V.status.id) { V.page.appendChild(serversCard()); loadServers(); }
    V.page.appendChild(noticesCard());
    if (note) {
      var card = V.page.querySelector(scope || '.fp-lic');
      M.say(card, note);
    }
  }
  function check(button) {
    var mine = V;
    var card = V.page.querySelector('.fp-lic');
    V.busy = true;
    UI.setBusy(button, true);
    UI.showError(card, '');
    M.say(card, t('lic_check_working'));
    FP.call('post', 'licenseCheck', {}).then(function (r) {
      if (V !== mine) { return; }
      mine.busy = false;
      var s = clean(r);
      if (!s) { UI.setBusy(button, false); M.say(card, ''); UI.showError(card, t('api_failed')); return; }
      mine.status = s;
      if (FP.locked && !closes(s)) { window.location.reload(); return; }
      setBanner(s);
      draw(t('lic_checked', {say: say(s)}));
      var again = mine.page.querySelector('[data-fp-act="check"]');
      if (again) { again.focus(); }
    }, function (err) {
      if (V !== mine) { return; }
      mine.busy = false;
      UI.setBusy(button, false);
      M.say(card, '');
      UI.showError(card, sentence(err.message));
      button.focus();
    });
  }
  function show(locked) {
    var tool = FP.tools.licence;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var mine = {page: null, status: null, busy: false, locked: Boolean(locked), claim: heldClaim()};
    V = mine;
    mine.page = FP.frame({title: tool.label, desc: t('lic_desc'), cls: 'fp-mail fp-licence',
      crumbs: locked ? [] : [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    mine.page.addEventListener('click', function (e) {
      if (V !== mine || !e.target.closest) { return; }
      var b = e.target.closest('[data-fp-act]');
      if (!b) { return; }
      var act = b.getAttribute('data-fp-act');
      var row = b.closest('tr[data-fp-server]');
      if (act === 'buy') { if (needsKey(mine.status)) { startBuy(b); } return; }   /* the link opens the licence site itself */
      if (mine.busy) { return; }
      if (act === 'check') { check(b); return; }
      if (act === 'release-ask' && row) {
        M.confirmIn(b.parentNode, t('lic_srv_release_q'), 'release-yes', t('lic_srv_release'));
        return;
      }
      if (act === 'release-yes' && row) { release(b, row.getAttribute('data-fp-server')); return; }
      if (act === 'confirm-no') { loadServers(); }
    });
    mine.page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'license').then(function (r) {
      if (V !== mine) { return; }
      mine.status = clean(r);
      mine.page.textContent = '';
      if (!mine.status) { mine.page.appendChild(FP.empty(tool.label, t('api_failed'))); return; }
      draw('');
    }, function (err) {
      if (V !== mine) { return; }
      mine.page.textContent = '';
      mine.page.appendChild(FP.empty(tool.label, sentence(err.message)));
    });
  }
  FP.view('tool:licence', function () { show(false); });

  /* ---- the lock screen: the administrator's is the Licence page, everyone else's says to ask the host ---- */
  FP.view('license-lock', function () {
    if (FP.realm === 'admin' && FP.session.user.role === 'admin' && FP.tools.licence) { show(true); return; }
    var page = FP.frame({title: t('lic_lock_title'), desc: '', cls: 'fp-licence'});
    page.appendChild(M.card('fp-lic-lock-h', t('lic_lock_head'), [el('p', {'data-fp-lock': '', text: t('lic_lock_text')})], 'fp-lic-lock'));
  });

  /* ---- grace: a banner on every page, with the date the panel locks, for the administrator ---- */
  function makeBanner(s) {
    return el('div', {class: 'sig-banner sig-banner--warn fp-lic-banner', role: 'note', 'data-fp-grace': ''}, [UI.icon(FP.ui, 'ui_warning'),
      el('span', null, [t((s.reason === 'upgrade' ? 'lic_banner_upgrade' : 'lic_banner_grace') + (s.graceUntil ? '' : '_nodate'), {until: when(s.graceUntil)}), ' ',
        t('lic_hosting_runs'), ' ', FP.tools.licence && window.location.hash !== '#/tool/licence' ? el('a', {href: '#/tool/licence', text: t('lic_banner_link')}) : null])]);
  }
  /* what the administrator last heard: the banner on the page and on every page after it follows */
  function setBanner(s) {
    var shown = document.querySelectorAll('[data-fp-grace]');
    for (var i = 0; i < shown.length; i++) { shown[i].parentNode.removeChild(shown[i]); }
    FP.notice = s && s.state === 'grace' ? function () { return makeBanner(s); } : null;
  }
  FP.beforeStart = function (session) {
    if (FP.realm !== 'admin' || session.user.role !== 'admin' || !session.license || session.license.state !== 'grace') { return null; }
    return FP.call('get', 'license').then(function (r) {
      var s = clean(r);
      if (s && s.state === 'grace') { setBanner(s); }
    }, function () { return null; });
  };
})();

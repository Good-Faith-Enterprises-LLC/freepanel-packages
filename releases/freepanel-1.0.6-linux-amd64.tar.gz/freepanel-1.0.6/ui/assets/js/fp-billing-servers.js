/* freePanel billing over several servers (docs/api.md, "Billing: servers"): Billing servers (#/tool/billing_servers), the servers one store makes
   and bills accounts on, this server first and the linked freePanel servers put on the list, with billing turned off here below them; and Server
   groups (#/tool/billing_server_groups), the servers a plan's new accounts go to and the rule that picks one. The server admin's alone (feature
   cluster): no staff login or reseller reaches them. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;
  var M = FP.mail;

  var SERVER = {id: 'id', name: [64], node_id: 'n', this_server: 'b', max_accounts: 'n', closed: 'b', accounts: 'n', panel_url: [300]};
  var NODE = {id: 'id', name: [64], url: [300]};
  var RULES = ['fewest', 'in_order'];

  function simple(toolId, cls, make) {
    FP.view('tool:' + toolId, function () {
      var page = B.frame(toolId, cls);
      if (!page) { return; }
      page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
      make(page, function () { return page.isConnected; }).show();
    });
  }
  function strings(pre) {
    return {none: t(pre + '_none'), addTitle: t(pre + '_add_title'), addSave: t(pre + '_add'), editTitle: function (n) { return t('bil_change_title', {name: n}); },
      added: function (n) { return t('bil_added', {name: n}); }, saved: function (n) { return t('bil_saved', {name: n}); }, removed: function (n) { return t('bil_removed', {name: n}); },
      removeAsk: function (n) { return t(pre + '_remove_ask', {name: n}); }, removeYes: t(pre + '_remove_yes'), formWhat: t(pre + '_form_what')};
  }
  function servers() {
    return FP.call('get', 'billingServers').then(function (r) { return B.pickAll(r && r.servers, SERVER, 'id'); });
  }

  /* ---- billing turned off on this server: a form of its own below the servers ---- */
  function storeOffCard(alive) {
    var holder = el('div', {'data-fp-bsv-off-body': ''}, [el('p', {class: 'fp-muted', text: t('loading')})]);
    var card = B.card('fp-bsv-off-h', t('bsv_off_title'), [holder], 'fp-bsv-off', 'off');
    FP.call('get', 'billingStoreOff').then(function (r) {
      if (!alive()) { return; }
      var v = B.pick(r, {off: 'b', store_url: [300]}) || {off: false, store_url: ''};
      var specs = [{name: 'off', label: t('bsv_off_on'), kind: 'check', hint: t('bsv_off_hint')},
        {name: 'store_url', label: t('bsv_off_url'), max: 300, code: true, send_empty: true, hint: t('bsv_off_url_hint'), wide: true}];
      var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bil_save_changes')});
      var form = el('form', {class: 'fp-form fp-bil-crud-form', novalidate: '', 'aria-labelledby': 'fp-bsv-off-h', 'data-fp-bsv-off': ''}, [M.errorLine(), M.statusLine(),
        el('div', {class: 'fp-bil-grid'}, B.fieldsOf('fp-bsv-off', specs, v)), el('div', {class: 'fp-actions'}, [save])]);
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!B.begin(form, save)) { return; }
        var body = B.readFields(form, specs, null);
        if (!body) { return; }
        if (body.off === v.off && (body.store_url || '') === (v.store_url || '')) { M.say(form, t('bil_nothing_changed')); return; }
        UI.setBusy(save, true);
        FP.call('put', 'billingStoreOff', {off: body.off, store_url: body.store_url || ''}).then(function (r2) {
          if (!alive()) { return; }
          UI.setBusy(save, false);
          v = B.pick(r2, {off: 'b', store_url: [300]}) || v;
          M.say(form, t(v.off ? 'bsv_off_saved_off' : 'bsv_off_saved_on'));
        }, function (err) {
          if (!alive()) { return; }
          UI.setBusy(save, false);
          B.failed(form, err);
        });
      });
      B.screen(holder, [el('p', {class: 'fp-muted', text: t('bsv_off_what')}), form]);
    }, function (err) {
      if (!alive()) { return; }
      B.screen(holder, [el('p', {class: 'fp-muted', text: err.message})]);
    });
    return card;
  }

  /* ---- the servers ---- */
  simple('billing_servers', 'fp-bsv', function (page, alive) {
    var nodes = [];
    function free(items) { return nodes.filter(function (n) { return !items.some(function (s) { return s.node_id === n.id; }); }); }
    function where(s) {
      if (s.this_server) { return t('bsv_this'); }
      var n = nodes.filter(function (x) { return x.id === s.node_id; })[0];
      return n ? n.url : t('bsv_link_gone');
    }
    var items = [];
    return B.crud({page: page, pre: 'fp-bsv', title: t('bsv_title'), alive: alive,
      what: function () { return [el('p', {class: 'fp-muted', text: t('bsv_what')})]; },
      load: function () {
        return Promise.all([servers(), FP.call('get', 'clusterNodes').then(function (r) { return B.pickAll(r && r.nodes, NODE, 'id'); }, function () { return []; })]).then(function (r) {
          nodes = r[1];
          items = r[0];
          return items;
        });
      },
      heads: [B.th(t('bsv_col_name')), B.th(t('bsv_col_where')), B.th(t('bsv_col_accounts'), 'fp-bil-num'), B.th(t('bsv_col_limit'), 'fp-bil-num'), B.th(t('bsv_col_new'))],
      cells: function (s) {
        return [el('th', {scope: 'row', class: 'fp-bil-wrap', text: s.name}), el('td', {class: 'fp-bil-wrap' + (s.this_server ? '' : ' sig-mono'), text: where(s)}),
          el('td', {class: 'fp-bil-num', text: s.accounts === null ? '—' : B.num(s.accounts)}),
          el('td', {class: 'fp-bil-num', text: s.max_accounts ? B.num(s.max_accounts) : t('bsv_no_limit')}),
          el('td', null, [el('span', {class: 'sig-pill ' + (s.closed ? 'sig-pill--warn' : 'sig-pill--ok'), text: t(s.closed ? 'bsv_closed' : 'bsv_open')})])];
      },
      fieldsFor: function (x) {
        var common = [{name: 'max_accounts', label: t('bsv_col_limit'), kind: 'number', max: 7, empty: 0, hint: t('bsv_limit_hint')},
          {name: 'closed', label: t('bsv_closed_label'), kind: 'check', hint: t('bsv_closed_hint')}];
        if (x) { return [{name: 'name', label: t('bsv_col_name'), required: true, max: 64}].concat(common); }
        return [{name: 'node_id', label: t('bsv_node'), kind: 'select', num: true, required: true, options: free(items).map(function (n) { return [String(n.id), n.name + ' (' + n.url + ')']; }), hint: t('bsv_node_hint')},
          {name: 'name', label: t('bsv_col_name'), max: 64, hint: t('bsv_name_hint')}].concat(common);
      },
      canAdd: function (list) { return free(list).length > 0; },
      after: function (list) {
        if (free(list).length) { return []; }
        var go = FP.tools.server_nodes ? el('a', {class: 'sig-btn sig-btn--secondary', href: '#/tool/server_nodes', text: t('bsv_link_go')}) : null;
        return [el('p', {class: 'fp-muted', 'data-fp-bsv-nolinks': '', text: t(nodes.length ? 'bsv_all_added' : 'bsv_no_links')}), go ? el('div', {class: 'fp-actions'}, [go]) : null].filter(Boolean);
      },
      below: function () {
        var go = FP.tools.billing_server_groups ? el('a', {class: 'sig-btn sig-btn--secondary', href: '#/tool/billing_server_groups', text: t('bsv_groups_go')}) : null;
        return [go ? B.card('fp-bsv-groups-h', t('bsv_groups_title'), [el('p', {class: 'fp-muted', text: t('bsv_groups_what')}), el('div', {class: 'fp-actions'}, [go])], 'fp-bsv-groups', 'groups') : null,
          storeOffCard(alive)].filter(Boolean);
      },
      check: function (body, x, form) {
        if (!x && !body.node_id) { M.fieldError(form, UI.fieldNamed(form, 'node_id'), t('bil_needed', {name: t('bsv_node')})); return true; }
        return false;
      },
      add: 'billingServers', item: 'billingServer', nameOf: function (s) { return s.name; },
      removable: function (s) { return !s.this_server; },
      clean: function (x) { return B.pick(x, SERVER); },
      strings: strings('bsv')});
  });

  /* ---- the server groups ---- */
  simple('billing_server_groups', 'fp-bsg', function (page, alive) {
    var list = [];
    var plans = [];
    function names(ids, from) {
      var out = ids.map(function (id) { var x = from.filter(function (y) { return y.id === id; })[0]; return x ? x.name : '#' + id; });
      return out.length ? out.join(', ') : '—';
    }
    function clean(g) {
      var v = B.pick(g, {id: 'id', name: [64], rule: ['=', RULES]});
      if (!v || !v.id) { return null; }
      v.servers = (Array.isArray(g.servers) ? g.servers : []).filter(function (n) { return B.whole(n) > 0; }).slice(0, 50);
      v.plans = (Array.isArray(g.plans) ? g.plans : []).filter(function (n) { return B.whole(n) > 0; }).slice(0, 1000);
      return v;
    }
    return B.crud({page: page, pre: 'fp-bsg', title: t('bsg_title'), alive: alive, itemMethod: 'put', patchOnly: false,
      what: function () { return [el('p', {class: 'fp-muted', text: t('bsg_what')})]; },
      load: function () {
        return Promise.all([FP.call('get', 'billingServerGroups').then(function (r) { return (r && Array.isArray(r.groups) ? r.groups : []).map(clean).filter(Boolean); }), servers(),
          FP.call('get', 'billingPlans', undefined, {}).then(function (r) { return B.pickAll(r && r.plans, {id: 'id', name: [60]}, 'id'); }, function () { return []; })]).then(function (r) {
          list = r[1];
          plans = r[2];
          return r[0];
        });
      },
      heads: [B.th(t('bsg_col_name')), B.th(t('bsg_col_rule')), B.th(t('bsg_col_servers')), B.th(t('bsg_col_plans'))],
      cells: function (g) {
        return [el('th', {scope: 'row', class: 'fp-bil-wrap', text: g.name}), el('td', {text: g.rule ? t('bsg_rule_' + g.rule) : '—'}),
          el('td', {class: 'fp-bil-wrap', text: names(g.servers, list)}), el('td', {class: 'fp-bil-wrap', text: names(g.plans, plans)})];
      },
      fieldsFor: function () {
        return [{name: 'name', label: t('bsg_col_name'), required: true, max: 64},
          {name: 'rule', label: t('bsg_col_rule'), kind: 'select', options: RULES.map(function (r) { return [r, t('bsg_rule_' + r)]; }), hint: t('bsg_rule_hint')},
          {name: 'servers', label: t('bsg_col_servers'), kind: 'picks', required: true, wide: true, options: list.map(function (s) { return [s.id, s.this_server ? t('bsv_this_named', {name: s.name}) : s.name]; }),
            hint: t('bsg_servers_hint')},
          {name: 'plans', label: t('bsg_col_plans'), kind: 'picks', wide: true, options: plans.map(function (p) { return [p.id, p.name]; }), none: t('bsg_no_plans'), hint: t('bsg_plans_hint')}];
      },
      add: 'billingServerGroups', item: 'billingServerGroup', nameOf: function (g) { return g.name; }, clean: clean,
      strings: strings('bsg')});
  });
})();

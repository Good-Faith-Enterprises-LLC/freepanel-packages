/* freePanel firewall and login protection in the admin panel (docs/api.md, "Firewall and login protection"):
   #/tool/firewall keeps the allow list (addresses never blocked for failing to sign in) and the deny list (addresses
   blocked on every port until removed); #/tool/login_protection sets how many failed sign-ins block an address and for how
   long, shows what is watched, and lists the addresses blocked now with a way to unblock one. Admin only: the server
   refuses these calls to anyone else, and the tools are offered only on a server installed with --protect. Addresses, notes
   and names come from the server and are shown as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;

  /* an address or a range, as the server keeps it: hex digits, dots, colons and one slash with a prefix length */
  var TARGET_RE = /^[0-9A-Fa-f:.]{2,45}(?:\/[0-9]{1,3})?$/;
  var JAIL_RE = /^[A-Za-z0-9_.-]{1,64}$/;
  var UNITS = [['seconds', 1], ['minutes', 60], ['hours', 3600], ['days', 86400]];
  var DEFAULTS = {login_protection: true, max_failures: 5, window_seconds: 600, ban_seconds: 3600, max_ban_seconds: 604800};
  var FAILURES = [2, 100];
  /* [field, label, hint, least, most] in seconds; the longest block also has to be at least the first one */
  var TIMES = [['window_seconds', 'lp_window', 'lp_window_hint', 60, 86400], ['ban_seconds', 'lp_ban', 'lp_ban_hint', 60, 2592000],
    ['max_ban_seconds', 'lp_max_ban', 'lp_max_ban_hint', 60, 31536000]];

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 200) : ''; }
  function whole(v) { return typeof v === 'number' && isFinite(v) && v >= 0 && Math.floor(v) === v ? v : null; }
  function count(v) { return (whole(v) || 0).toLocaleString('en'); }
  function when(iso) {
    var d = new Date(str(iso, 40));
    return isNaN(d.getTime()) ? '' : d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'});
  }
  /* the biggest unit that divides the length without a rest */
  function unitOf(seconds) {
    for (var i = UNITS.length - 1; i > 0; i--) { if (seconds % UNITS[i][1] === 0) { return i; } }
    return 0;
  }
  function duration(seconds) {
    var u = UNITS[unitOf(seconds)];
    var n = seconds / u[1];
    return t('lp_dur_' + u[0] + (n === 1 ? '_1' : ''), {n: n.toLocaleString('en')});
  }

  function cleanEntry(x) {
    if (!x || !TARGET_RE.test(str(x.target, 64))) { return null; }
    return {target: x.target, note: str(x.note), added: str(x.added, 40), by: str(x.by, 64)};
  }
  function cleanJail(j) {
    if (!j || !JAIL_RE.test(str(j.name, 64))) { return null; }
    return {name: j.name, label: str(j.label, 80) || j.name, present: j.present === true, running: j.running === true,
      failing: whole(j.currently_failed) || 0, failed: whole(j.total_failed) || 0, blocked: whole(j.currently_banned) || 0, blockedTotal: whole(j.total_banned) || 0};
  }
  function cleanBans(r) {
    return (r && Array.isArray(r.bans) ? r.bans : []).filter(function (b) { return b && TARGET_RE.test(str(b.ip, 64)); }).map(function (b) {
      return {ip: b.ip, jail: JAIL_RE.test(str(b.jail, 64)) ? b.jail : '', since: str(b.banned_at, 40), until: str(b.expires_at, 40)};
    });
  }
  function cleanService(s) { return {installed: Boolean(s && s.installed === true), active: Boolean(s && s.active === true)}; }
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var s = r.settings && typeof r.settings === 'object' ? r.settings : {};
    var settings = {login_protection: s.login_protection !== false};
    ['max_failures', 'window_seconds', 'ban_seconds', 'max_ban_seconds'].forEach(function (k) { settings[k] = whole(s[k]) || DEFAULTS[k]; });
    return {firewall: r.firewall === 'nftables' ? 'nftables' : 'firewalld', firewalld: cleanService(r.firewalld), fail2ban: cleanService(r.fail2ban), settings: settings,
      jails: (Array.isArray(r.jails) ? r.jails : []).map(cleanJail).filter(Boolean),
      allow: (Array.isArray(r.allow) ? r.allow : []).map(cleanEntry).filter(Boolean),
      deny: (Array.isArray(r.deny) ? r.deny : []).map(cleanEntry).filter(Boolean),
      pending: r.pending === true, problem: str(r.problem, 300)};
  }

  /* ---- the usual page parts ---- */
  function errorLine() { return el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': ''}); }
  function statusLine() { return el('p', {class: 'fp-ok-line', role: 'status', 'data-fp-status': ''}); }
  function say(scope, text) {
    var s = scope && scope.querySelector('[data-fp-status]');
    if (s) { s.textContent = text || ''; }
  }
  function card(id, title, children, cls) {
    return el('section', {class: 'sig-card fp-sec-card' + (cls ? ' ' + cls : ''), 'aria-labelledby': id}, [el('div', {class: 'sig-card-body'},
      [el('h2', {class: 'fp-h2', id: id, tabindex: '-1', text: title})].concat(children))]);
  }
  /* the page's cards by name; a change redraws the cards it touches and leaves a form the admin is typing in alone */
  var CARDS = {allow: function () { return listCard('allow'); }, deny: function () { return listCard('deny'); }, settings: function () { return settingsCard(); },
    jails: function () { return jailsCard(); }, bans: function () { return bansCard(); }};
  var ORDER = {firewall: ['allow', 'deny'], login_protection: ['settings', 'jails', 'bans']};
  function field(id, label, control, hint) {
    if (hint) { control.setAttribute('aria-describedby', id + '-hint'); }
    return el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: id, text: label}), control,
      hint ? el('span', {class: 'sig-hint', id: id + '-hint', text: hint}) : null]);
  }
  function fieldError(form, f, message) {
    UI.showError(form, message);
    if (f) {
      f.setAttribute('aria-invalid', 'true');
      f.focus({preventScroll: true});
    }
    var line = form.querySelector('[data-fp-error]');
    if (line && line.scrollIntoView) { line.scrollIntoView({block: 'nearest'}); }
  }
  function failed(form, err) {
    var f = err && err.field ? UI.fieldNamed(form, err.field) : null;
    var label = f ? form.querySelector('label[for="' + f.id + '"]') : null;
    fieldError(form, f, (label ? label.textContent + ': ' : '') + (err ? err.message : t('api_failed')));
  }
  function start(form) {
    var b = form.querySelector('.fp-submit');
    if (!b || b.disabled) { return null; }
    UI.showError(form, '');
    say(form, '');
    var bad = form.querySelectorAll('[aria-invalid]');
    for (var i = 0; i < bad.length; i++) { bad[i].removeAttribute('aria-invalid'); }
    return b;
  }
  function banner(text) {
    return el('div', {class: 'sig-banner sig-banner--warn', role: 'note'}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: text})]);
  }
  function pendingText(d) { return d.problem ? t('sec_pending_why', {problem: d.problem}) : t('sec_pending'); }
  function notices(d, which) {
    var out = [];
    if (d.pending) { out.push(banner(pendingText(d))); }
    var svc = which === 'firewall' ? d.firewalld : d.fail2ban;
    var key = which === 'firewall' ? 'sec_' + d.firewall + '_' : 'sec_f2b_';
    if (!svc.installed) { out.push(banner(t(key + 'missing'))); } else if (!svc.active) { out.push(banner(t(key + 'stopped'))); }
    return out;
  }
  function pill(kind, icon, text, attrs) {
    return el('span', Object.assign({class: 'sig-pill' + (kind ? ' sig-pill--' + kind : '')}, attrs || {}), [UI.icon(FP.ui, icon, 'fp-pill-ico'), el('span', {text: text})]);
  }
  function tableFrame(headId, cls, heads, rows) {
    return el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': headId}, [
      el('table', {class: 'sig-table ' + cls}, [el('thead', null, [el('tr', null, heads)]), el('tbody', null, rows)])]);
  }
  function th(text, num) { return el('th', {scope: 'col', class: num ? 'fp-num' : null, text: text}); }
  function actionsTh() { return el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('acct_actions')})]); }

  var page = null;
  var which = '';
  var sec = null;      /* the server's Security reply, cleaned */
  var bans = null;     /* the blocked addresses, or null when the list can't be had */
  var seq = 0;         /* tells a row's question from another's */

  /* ---- the allow list and the deny list ---- */
  var LISTS = {
    allow: {title: 'fw_allow_title', what: 'fw_allow_what', add: 'fw_allow_add', none: 'fw_none_allow', added: 'fw_allowed', removed: 'fw_removed_allow',
      ask: 'fw_ask_allow', of: 'fw_remove_allow_of', post: 'securityAllow', del: 'securityAllowEntry'},
    deny: {title: 'fw_deny_title', what: 'fw_deny_what', add: 'fw_deny_add', none: 'fw_none_deny', added: 'fw_denied', removed: 'fw_removed_deny',
      ask: 'fw_ask_deny', of: 'fw_remove_deny_of', post: 'securityDeny', del: 'securityDenyEntry'}
  };

  function addForm(kind) {
    var L = LISTS[kind];
    var id = 'fp-fw-' + kind;
    var target = el('input', {class: 'sig-input sig-mono', id: id + '-target', name: 'target', type: 'text', autocomplete: 'off', spellcheck: 'false',
      autocapitalize: 'none', maxlength: '64'});
    var note = el('input', {class: 'sig-input', id: id + '-note', name: 'note', type: 'text', autocomplete: 'off', maxlength: '200'});
    var form = el('form', {class: 'fp-form fp-fw-form', novalidate: '', 'data-fp-list': kind}, [errorLine(), statusLine(),
      el('div', {class: 'fp-fw-fields'}, [field(id + '-target', t('fw_target'), target, t('fw_target_hint')), field(id + '-note', t('fw_note'), note, t('fw_note_hint'))]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t(L.add)})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = start(form);
      if (!b) { return; }
      var v = target.value.trim();
      if (!TARGET_RE.test(v)) { fieldError(form, target, t('fw_bad_target')); return; }
      var body = {target: v};
      var n = note.value.trim();
      if (n) { body.note = n; }
      UI.setBusy(b, true);
      FP.call('post', L.post, body).then(function (r) {
        sec = clean(r);
        draw([kind], {say: [kind, t(L.added, {target: v})], focus: '#' + id + '-target'});
      }, function (err) {
        UI.setBusy(b, false);
        failed(form, err);
      });
    });
    return form;
  }

  function entryRow(kind, e, n) {
    var L = LISTS[kind];
    return el('tr', {'data-fp-target': e.target}, [
      el('th', {scope: 'row', class: 'sig-mono fp-fw-target', text: e.target}),
      el('td', {class: 'fp-fw-note', text: e.note || '–'}),
      el('td', {text: when(e.added) || '–'}),
      el('td', {class: 'fp-fw-by', text: e.by === 'installer' ? t('sec_installer') : e.by || '–'}),
      el('td', {class: 'fp-sec-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'remove',
        'data-fp-row': String(n), 'aria-label': t(L.of, {target: e.target}), text: t('fw_remove')})])]);
  }

  function listCard(kind) {
    var L = LISTS[kind];
    var id = 'fp-fw-' + kind + '-h';
    var entries = sec[kind];
    var parts = [el('p', {class: 'fp-muted', text: t(L.what)}), addForm(kind)];
    if (!entries.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': kind, text: t(L.none)}));
    } else {
      parts.push(el('p', {class: 'fp-muted fp-sec-count', 'data-fp-count': kind, text: t(entries.length === 1 ? 'fw_count_1' : 'fw_count', {n: entries.length.toLocaleString('en')})}));
      parts.push(tableFrame(id, 'fp-fw-table', [th(t('fw_target')), th(t('fw_col_note')), th(t('sec_col_added')), th(t('sec_col_by')), actionsTh()],
        entries.map(function (e, i) { return entryRow(kind, e, i); })));
    }
    return card(id, t(L.title), parts, 'fp-fw-' + kind);
  }

  /* a question in the row: Cancel takes focus, so a second Enter can't confirm it */
  function ask(tr, kind, text) {
    var cell = tr.querySelector('.fp-sec-acts');
    seq += 1;
    var id = 'fp-sec-ask-' + seq;
    var row = tr.querySelector('[data-fp-act="remove"]').getAttribute('data-fp-row');
    cell.textContent = '';
    var yes = el('button', {class: 'sig-btn sig-btn--danger sig-btn--sm', type: 'button', 'data-fp-act': 'remove-yes', 'data-fp-row': row, text: t('fw_remove')});
    var no = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'remove-no', 'data-fp-row': row, text: t('cancel')});
    cell.appendChild(el('span', {class: 'fp-sec-confirm', id: id, text: text}));
    cell.appendChild(yes);
    cell.appendChild(no);
    yes.setAttribute('aria-describedby', id);
    no.setAttribute('aria-describedby', id);
    no.focus();
  }

  /* ---- login protection: settings ---- */
  function timeField(x, seconds) {
    var id = 'fp-lp-' + x[0];
    var u = unitOf(seconds);
    var number = el('input', {class: 'sig-input fp-num-input', id: id, name: x[0], type: 'number', inputmode: 'numeric', min: '1', step: '1',
      value: String(seconds / UNITS[u][1]), 'aria-describedby': id + '-hint'});
    var select = el('select', {class: 'sig-select fp-lp-unit', id: id + '-unit', 'data-fp-unit': x[0], 'aria-label': t('lp_unit_of', {field: t(x[1])})},
      UNITS.map(function (un, i) { return i > 0 || u === 0 ? el('option', {value: String(un[1]), selected: i === u ? true : null, text: t('lp_dur_' + un[0]).replace('{n} ', '')}) : null; }));
    return el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: id, text: t(x[1])}),
      el('div', {class: 'fp-lp-time'}, [number, select]), el('span', {class: 'sig-hint', id: id + '-hint', text: t(x[2])})]);
  }

  function settingsCard() {
    var s = sec.settings;
    var id = 'fp-lp-enabled';
    var on = el('input', {type: 'checkbox', id: id, name: 'login_protection', checked: s.login_protection ? true : null, 'aria-describedby': id + '-hint'});
    var failures = el('input', {class: 'sig-input fp-num-input', id: 'fp-lp-max_failures', name: 'max_failures', type: 'number', inputmode: 'numeric',
      min: String(FAILURES[0]), max: String(FAILURES[1]), step: '1', value: String(s.max_failures)});
    var actions = el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('lp_save')})]);
    var form = el('form', {class: 'fp-form fp-lp-form', novalidate: ''}, [errorLine(), statusLine(),
      el('div', {class: 'sig-field'}, [el('label', {class: 'fp-check', for: id}, [on, el('span', {text: t('lp_enable')})]),
        el('span', {class: 'sig-hint', id: id + '-hint', text: t('lp_enable_hint')})]),
      field('fp-lp-max_failures', t('lp_failures'), failures, t('lp_failures_hint'))]
      .concat(TIMES.map(function (x) { return timeField(x, s[x[0]]); }), [actions]));

    /* every field is read and checked here; the server checks them again */
    function read() {
      var body = {login_protection: on.checked};
      var v = failures.value.trim();
      if (!/^[0-9]{1,4}$/.test(v)) { fieldError(form, failures, t('lp_bad_failures')); return null; }
      if (Number(v) < FAILURES[0] || Number(v) > FAILURES[1]) { fieldError(form, failures, t('lp_bad_failures')); return null; }
      body.max_failures = Number(v);
      for (var i = 0; i < TIMES.length; i++) {
        var x = TIMES[i];
        var input = form.querySelector('[name="' + x[0] + '"]');
        var unit = Number(form.querySelector('[data-fp-unit="' + x[0] + '"]').value);
        var n = input.value.trim();
        if (!/^[0-9]{1,9}$/.test(n)) { fieldError(form, input, t('lp_bad_number')); return null; }
        var seconds = Number(n) * unit;
        if (seconds < x[3] || seconds > x[4]) { fieldError(form, input, t('lp_bad_time', {min: duration(x[3]), max: duration(x[4])})); return null; }
        body[x[0]] = seconds;
      }
      if (body.max_ban_seconds < body.ban_seconds) { fieldError(form, form.querySelector('[name="max_ban_seconds"]'), t('lp_max_short')); return null; }
      return body;
    }
    function save(body, b) {
      UI.setBusy(b, true);
      FP.call('put', 'securitySettings', body).then(function (r) {
        sec = clean(r);
        var text = t(sec.settings.login_protection ? 'lp_saved' : 'lp_saved_off');
        var done = function () { draw(['settings', 'jails', 'bans'], {say: ['settings', sec.pending ? text + ' ' + pendingText(sec) : text], focus: '#fp-lp-enabled'}); };
        /* turning protection off lifts the blocks: the list is read again; a failed look leaves it as it was */
        FP.call('get', 'securityBans').then(function (x) { bans = cleanBans(x); }, function () { return null; }).then(done);
      }, function (err) {
        UI.setBusy(b, false);
        failed(form, err);
        restoreActions();
      });
    }
    function restoreActions() {
      var now = form.querySelector('.fp-actions');
      if (now !== actions) { now.replaceWith(actions); }
    }
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = start(form);
      if (!b) { return; }
      var body = read();
      if (!body) { return; }
      if (!body.login_protection && sec.settings.login_protection) {
        /* turning protection off lifts every block: ask first, with Cancel under focus */
        var yes = el('button', {class: 'sig-btn sig-btn--danger', type: 'button', 'data-fp-act': 'off-yes', text: t('lp_off_yes')});
        var no = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'off-no', text: t('cancel')});
        var q = el('div', {class: 'fp-actions fp-lp-ask'}, [el('p', {class: 'fp-sec-confirm', id: 'fp-lp-off-ask', text: t('lp_off_ask')}), yes, no]);
        yes.setAttribute('aria-describedby', 'fp-lp-off-ask');
        no.setAttribute('aria-describedby', 'fp-lp-off-ask');
        yes.addEventListener('click', function () { save(body, yes); });
        no.addEventListener('click', function () { restoreActions(); form.querySelector('.fp-submit').focus(); });
        actions.replaceWith(q);
        no.focus();
        return;
      }
      save(body, b);
    });
    return card('fp-lp-settings-h', t('lp_settings_title'), [form], 'fp-lp-settings');
  }

  /* ---- login protection: what is watched, and what is blocked ---- */
  function stateOf(j) {
    if (!j.present) { return pill('', 'ui_minus', t('lp_state_absent')); }
    if (j.running) { return pill('ok', 'ui_check', t('lp_state_running')); }
    return sec.settings.login_protection ? pill('warn', 'ui_warning', t('lp_state_stopped')) : pill('', 'ui_minus', t('lp_state_stopped'));
  }
  function num(j, v) { return el('td', {class: 'fp-num', text: j.present ? count(v) : '–'}); }
  function jailsCard() {
    var parts = [el('p', {class: 'fp-muted', text: t('lp_jails_what')})];
    if (!sec.jails.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': 'jails', text: t('lp_jails_none')}));
    } else {
      parts.push(tableFrame('fp-lp-jails-h', 'fp-lp-jail-table', [th(t('lp_col_service')), th(t('lp_col_state')), th(t('lp_col_failing'), true), th(t('lp_col_failed'), true),
        th(t('lp_col_blocked'), true), th(t('lp_col_blocked_total'), true)], sec.jails.map(function (j) {
        return el('tr', {'data-fp-jail': j.name}, [el('th', {scope: 'row', text: j.label}), el('td', null, [stateOf(j)]),
          num(j, j.failing), num(j, j.failed), num(j, j.blocked), num(j, j.blockedTotal)]);
      })));
    }
    return card('fp-lp-jails-h', t('lp_jails_title'), parts, 'fp-lp-jails');
  }

  function jailLabel(name) {
    for (var i = 0; i < sec.jails.length; i++) { if (sec.jails[i].name === name) { return sec.jails[i].label; } }
    return name || '–';
  }
  function bansCard() {
    var parts = [el('p', {class: 'fp-muted', text: t('lp_bans_what')}), errorLine(), statusLine()];
    if (bans === null) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': 'bans-failed', text: t('lp_bans_failed')}));
    } else if (!bans.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': 'bans', text: t('lp_bans_none')}));
    } else {
      parts.push(tableFrame('fp-lp-bans-h', 'fp-lp-ban-table', [th(t('lp_col_address')), th(t('lp_col_caught')), th(t('lp_col_since')), th(t('lp_col_until')), actionsTh()],
        bans.map(function (b, i) {
          return el('tr', {'data-fp-ban': b.ip}, [el('th', {scope: 'row', class: 'sig-mono fp-fw-target', text: b.ip}), el('td', {text: jailLabel(b.jail)}),
            el('td', {text: when(b.since) || '–'}), el('td', {text: b.until ? when(b.until) || '–' : t('lp_until_lifted')}),
            el('td', {class: 'fp-sec-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'unblock', 'data-fp-row': String(i),
              'aria-label': t('lp_unblock_of', {ip: b.ip}), text: t('lp_unblock')})])]);
        })));
    }
    var actions = [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': bans === null ? 'retry' : 'refresh',
      text: t(bans === null ? 'sec_try_again' : 'sec_look_again')})];
    parts.push(el('div', {class: 'fp-actions'}, actions));
    if (FP.tools.firewall) {
      parts.push(el('p', {class: 'fp-muted fp-lp-allowlink'}, [t('lp_allow_1') + ' ', el('a', {href: '#/tool/firewall', text: t('lp_allow_link')}), '.']));
    }
    return card('fp-lp-bans-h', t('lp_bans_title'), parts, 'fp-lp-bans');
  }

  /* ---- drawing ---- */
  function drawNotices() {
    var box = page.querySelector('.fp-sec-notices');
    box.textContent = '';
    notices(sec, which).forEach(function (n) { box.appendChild(n); });
  }
  function build(name) {
    var node = CARDS[name]();
    node.setAttribute('data-fp-card', name);
    return node;
  }
  function drawAll() {
    page.textContent = '';
    page.appendChild(el('div', {class: 'fp-sec-notices'}));
    ORDER[which].forEach(function (name) { page.appendChild(build(name)); });
    drawNotices();
  }
  /* redraws the cards named; opts.say is [card, text] for that card's status line, opts.focus a selector for the control that takes focus */
  function draw(names, opts) {
    opts = opts || {};
    names.forEach(function (name) {
      var old = page.querySelector('[data-fp-card="' + name + '"]');
      if (old) { old.replaceWith(build(name)); }
    });
    drawNotices();
    if (opts.say) { say(page.querySelector('[data-fp-card="' + opts.say[0] + '"]'), opts.say[1]); }
    var target = opts.focus ? page.querySelector(opts.focus) : null;
    if (target) { target.focus(); }
  }

  function reload(mine, then) {
    var calls = [FP.call('get', 'security')];
    if (which === 'login_protection') { calls.push(FP.call('get', 'securityBans').then(cleanBans, function () { return null; })); }
    return Promise.all(calls).then(function (x) {
      if (page !== mine) { return; }
      sec = clean(x[0]);
      if (which === 'login_protection') { bans = x[1]; }
      then();
    });
  }

  function rowOf(b) {
    var n = Number(b.getAttribute('data-fp-row'));
    return isFinite(n) ? n : -1;
  }
  function removeButton(kind, target) { return 'tr[data-fp-target="' + window.CSS.escape(target) + '"] [data-fp-act="remove"]'; }
  function onClick(e) {
    var target = e.target.closest ? e.target : null;
    if (!target || !page || !page.contains(target) || !sec) { return; }
    var b = target.closest('[data-fp-act]');
    if (!b) { return; }
    var a = b.getAttribute('data-fp-act');
    var mine = page;
    var tr = b.closest('tr');
    var kindCard = b.closest('.fp-fw-allow, .fp-fw-deny');
    var kind = kindCard ? (kindCard.classList.contains('fp-fw-allow') ? 'allow' : 'deny') : '';
    var i = rowOf(b);
    var entry = kind ? sec[kind][i] : null;
    if (a === 'remove' && entry) {
      ask(tr, kind, t(LISTS[kind].ask, {target: entry.target}));
    } else if (a === 'remove-no' && entry) {
      /* the row alone is put back, so what is typed in the form above stays */
      var again = entryRow(kind, entry, i);
      tr.replaceWith(again);
      again.querySelector('[data-fp-act="remove"]').focus();
    } else if (a === 'remove-yes' && entry) {
      UI.setBusy(b, true);
      FP.call('del', LISTS[kind].del, undefined, {target: entry.target}).then(function (r) {
        if (page !== mine) { return; }
        sec = clean(r);
        var rows = sec[kind];
        var next = rows[Math.min(i, rows.length - 1)];
        draw([kind], {say: [kind, t(LISTS[kind].removed, {target: entry.target})],
          focus: next ? removeButton(kind, next.target) : '#fp-fw-' + kind + '-target'});
      }, function (err) {
        if (page !== mine) { return; }
        var form = kindCard.querySelector('form');
        if (err && err.status === 404) {
          /* gone already: the row goes, and the server's words say so */
          sec[kind] = sec[kind].filter(function (x) { return x.target !== entry.target; });
          draw([kind], {focus: '#fp-fw-' + kind + '-target'});
          UI.showError(page.querySelector('[data-fp-card="' + kind + '"] form'), err.message);
          return;
        }
        var back = entryRow(kind, entry, i);
        tr.replaceWith(back);
        back.querySelector('[data-fp-act="remove"]').focus();
        UI.showError(form, err.message);
      });
    } else if (a === 'unblock' && bans && bans[i]) {
      var ban = bans[i];
      UI.setBusy(b, true);
      FP.call('del', 'securityBan', undefined, {ip: ban.ip}).then(function (r) {
        bans = cleanBans(r);
        /* the counts of the lines above are best had again; a failed look leaves them as they were */
        return FP.call('get', 'security').then(function (x) { sec = clean(x); }, function () { return null; });
      }).then(function () {
        if (page !== mine) { return; }
        var next = bans[Math.min(i, bans.length - 1)];
        draw(['jails', 'bans'], {say: ['bans', t('lp_unblocked', {ip: ban.ip})],
          focus: next ? 'tr[data-fp-ban="' + window.CSS.escape(next.ip) + '"] [data-fp-act="unblock"]' : '#fp-lp-bans-h'});
      }, function (err) {
        if (page !== mine) { return; }
        if (err && err.status === 404) { bans = bans.filter(function (x) { return x.ip !== ban.ip; }); }
        draw(['bans'], {focus: '#fp-lp-bans-h'});
        UI.showError(page.querySelector('.fp-lp-bans'), err.message);
      });
    } else if (a === 'refresh' || a === 'retry') {
      UI.setBusy(b, true);
      reload(mine, function () {
        draw(['jails', 'bans'], {say: ['bans', t('sec_up_to_date')], focus: '[data-fp-act="refresh"]'});
      }).catch(function (err) {
        if (page !== mine) { return; }
        UI.setBusy(b, false);
        UI.showError(page.querySelector('.fp-lp-bans'), err.message);
        b.focus();
      });
    }
  }
  document.addEventListener('click', onClick);

  function show(id) {
    var tool = FP.tools[id];
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    which = id;
    sec = null;
    bans = null;
    page = FP.frame({title: tool.label, desc: t(id === 'firewall' ? 'fw_desc' : 'lp_desc'), cls: 'fp-sec fp-sec-' + (id === 'firewall' ? 'firewall' : 'login'),
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    var mine = page;
    reload(mine, drawAll).catch(function (err) {
      if (page !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err.message));
    });
  }
  FP.view('tool:firewall', function () { show('firewall'); });
  FP.view('tool:login_protection', function () { show('login_protection'); });
})();

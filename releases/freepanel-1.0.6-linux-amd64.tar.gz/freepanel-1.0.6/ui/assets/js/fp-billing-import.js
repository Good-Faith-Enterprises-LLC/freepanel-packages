/* freePanel billing import (#/tool/billing_import; docs/api.md, "Billing: import"; docs/billing/navigation-map.md, "Import"): clients,
   opening balances and services brought in from CSV files in the panel's own format, each in three steps: choose the file, check it (nothing
   is made, every wrong row is listed), then import it, which the page offers only for the file just checked clean; and a whole move from
   another billing system (docs/billing/moving-from-another-billing-system.md), for the admin into the server's book and for a reseller into
   its own. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;
  var M = FP.mail;

  /* ================= Import ================= */
  var FILES = [
    {kind: 'customers', cols: 'name, email, company, phone, address1, address2, city, region, postcode, country, status, group, credit_cents'},
    {kind: 'balances', cols: 'customer_email, description, amount_cents, due_on'},
    {kind: 'services', cols: 'customer_email, plan, term, started_on, next_due, renewal_cents, status'}];
  function cleanResult(r) {
    return {rows: B.whole(r && r.rows) || 0, made: B.whole(r && r.made) || 0, dry: r && r.dry_run === true, more: B.whole(r && r.more) || 0,
      errors: B.pickAll(r && r.errors, {row: 'n', field: [40], message: [300]})};
  }
  function importCard(f) {
    var pre = 'fp-bim-' + f.kind;
    var file = el('input', {type: 'file', id: pre + '-file', name: 'file', accept: '.csv,text/csv', class: 'fp-btk-file-input', 'aria-describedby': pre + '-file-hint'});
    var check = el('button', {class: 'sig-btn sig-btn--secondary fp-submit', type: 'submit', value: 'check', text: t('bim_check')});
    var go = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', value: 'import', text: t('bim_import'), disabled: true});
    var out = el('div', {'data-fp-result': ''});
    var checked = null;
    var form = el('form', {class: 'fp-form fp-bim-form', novalidate: '', 'aria-labelledby': pre + '-h', 'data-fp-import': f.kind}, [M.errorLine(), M.statusLine(),
      el('ol', {class: 'fp-bim-steps'}, [el('li', {text: t('bim_step_1')}), el('li', {text: t('bim_step_2')}), el('li', {text: t('bim_step_3')})]),
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: pre + '-file', text: t('bim_file')}), file,
        el('span', {class: 'sig-hint', id: pre + '-file-hint', text: t('bim_cols', {cols: f.cols})})]),
      el('div', {class: 'fp-actions'}, [check, go]), out]);
    file.addEventListener('change', function () { checked = null; go.disabled = true; out.textContent = ''; M.say(form, ''); });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = e.submitter && e.submitter.classList.contains('fp-submit') ? e.submitter : check;
      if (!B.begin(form, b)) { return; }
      var picked = file.files && file.files[0];
      if (!picked) { M.fieldError(form, file, t('bim_file_needed')); return; }
      if (picked.size > 5 * 1048576) { M.fieldError(form, file, t('bim_file_big')); return; }
      var dry = b === check;
      if (!dry && checked !== picked) { M.fieldError(form, file, t('bim_check_first')); return; }
      UI.setBusy(check, true);
      UI.setBusy(go, true);
      FP.call('post', 'billingImport', undefined, {kind: f.kind, dry_run: dry ? '1' : '0'}, {body: picked, type: 'text/csv'}).then(function (r) {
        if (!form.isConnected) { return; }
        UI.setBusy(check, false);
        go.removeAttribute('aria-busy');
        var res = cleanResult(r);
        drawResult(out, res, f);
        if (dry) {
          checked = res.errors.length ? null : picked;
          go.disabled = !checked;
          M.say(form, res.errors.length ? t('bim_checked_bad', {n: B.num(res.errors.length + res.more)}) : t('bim_checked_ok', {n: B.num(res.rows)}));
          (checked ? go : out.querySelector('[tabindex="-1"]') || check).focus();
        } else {
          checked = null;
          go.disabled = true;
          M.say(form, t('bim_done', {n: B.num(res.made)}));
          out.querySelector('[tabindex="-1"]').focus();
        }
      }, function (err) {
        if (!form.isConnected) { return; }
        UI.setBusy(check, false);
        go.disabled = !checked;
        go.removeAttribute('aria-busy');
        out.textContent = '';
        B.failed(form, err.field === 'file' ? Object.assign({}, err, {field: ''}) : err);
        if (err.field === 'file') { file.setAttribute('aria-invalid', 'true'); file.focus(); }
      });
    });
    return B.card(pre + '-h', t('bim_kind_' + f.kind), [el('p', {class: 'fp-muted', text: t('bim_what_' + f.kind)}), form], 'fp-bim-card', f.kind);
  }
  function drawResult(out, res, f) {
    out.textContent = '';
    var hid = 'fp-bim-' + f.kind + '-res';
    var parts = [el('h3', {class: 'fp-h3', id: hid, tabindex: '-1', text: res.errors.length ? t('bim_wrong_title') : res.dry ? t('bim_clean_title') : t('bim_made_title')}),
      B.facts([[t('bim_rows'), B.num(res.rows)], [t('bim_made'), B.num(res.made)], [t('bim_wrong'), B.num(res.errors.length + res.more)]])];
    if (res.errors.length) {
      parts.push(el('p', {class: 'fp-muted fp-row-note', text: t('bim_nothing_made')}));
      parts.push(B.table(hid, 'fp-bim-errors', [B.th(t('bim_col_row'), 'fp-bil-num'), B.th(t('bim_col_field')), B.th(t('bim_col_message'))], res.errors.map(function (e) {
        return el('tr', null, [el('td', {class: 'fp-bil-num', text: e.row === null ? '—' : B.num(e.row)}), el('td', null, [el('code', {text: e.field || '—'})]), el('td', {class: 'fp-bil-wrap', text: e.message})]);
      })));
      if (res.more) { parts.push(el('p', {class: 'fp-muted fp-row-note', text: t('bim_more', {n: B.num(res.more)})})); }
    }
    out.appendChild(el('div', {class: 'fp-bim-result', 'data-fp-outcome': res.errors.length ? 'wrong' : res.dry ? 'clean' : 'made'}, parts));
  }
  /* ================= Move from another billing system ================= */
  /* the old system's API (its address and an API credential, typed each time and sent with that run only) or a copy of its database (a
     dump file, kept by the server for the run). Check first: nothing is written, and the report lists the problems, what stays behind and
     the warnings. Move is offered only after a clean check of the very same inputs, which the server binds to the check with a token */
  var REPORT = {digest: [80], dry_run: 'b', owed_cents: 'c', credit_cents: 'c', overdue_balances: 'n', more_problems: 'n'};
  var COUNTS = {customers: 'n', services: 'n', domains: 'n', balances: 'n'};
  var ITEM = {kind: [20], id: 'n', field: [40], message: [400]};
  function cleanReport(r) {
    var rep = r && r.report;
    var out = B.pick(rep, REPORT) || {};
    ['moving', 'made', 'already_there'].forEach(function (k) { out[k] = B.pick(rep && rep[k], COUNTS) || {customers: 0, services: 0, domains: 0, balances: 0}; });
    out.problems = B.pickAll(rep && rep.problems, ITEM);
    out.warnings = B.pickAll(rep && rep.warnings, ITEM);
    out.left = [];
    var lc = rep && rep.not_moved_counts && typeof rep.not_moved_counts === 'object' ? rep.not_moved_counts : {};
    Object.keys(lc).sort().forEach(function (k) { if (typeof k === 'string' && k.length <= 200) { out.left.push([k, B.whole(lc[k]) || 0]); } });
    out.token = r && typeof r.token === 'string' && /^[0-9a-f]{32}$/.test(r.token) ? r.token : '';
    return out;
  }
  function moveCard() {
    var pre = 'fp-bmv';
    var source = B.select(pre + '-from', 'from', [['api', t('bmv_from_api')], ['dump', t('bmv_from_dump')]], 'api');
    var url = B.input(pre + '-url', 'url', '', {type: 'url', inputmode: 'url', placeholder: 'https://billing.example.com/', spellcheck: 'false'});
    var ident = B.input(pre + '-identifier', 'identifier', '', {spellcheck: 'false'});
    var secret = B.input(pre + '-secret', 'secret', '', {type: 'password', autocomplete: 'off'});
    var access = B.input(pre + '-accesskey', 'accesskey', '', {type: 'password', autocomplete: 'off'});
    var file = el('input', {type: 'file', id: pre + '-file', name: 'upload', accept: '.sql,.gz,application/sql,application/gzip', class: 'fp-btk-file-input', 'aria-describedby': pre + '-file-hint'});
    var mapping = el('textarea', {class: 'sig-input fp-bmv-map', id: pre + '-mapping', name: 'mapping', rows: '4', spellcheck: 'false', 'aria-describedby': pre + '-mapping-hint', placeholder: 'kind,from,to'});
    var skip = B.input(pre + '-skip', 'skip_clients', '', {inputmode: 'numeric', spellcheck: 'false'});
    var untied = el('input', {type: 'checkbox', id: pre + '-untied', name: 'leave_untied', class: 'sig-check'});
    var check = el('button', {class: 'sig-btn sig-btn--secondary fp-submit', type: 'submit', value: 'check', text: t('bmv_check')});
    var go = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', value: 'apply', text: t('bmv_apply'), disabled: true});
    var out = el('div', {'data-fp-result': ''});
    var apiPart = el('div', {class: 'fp-bmv-api'}, [M.field(pre + '-url', t('bmv_url'), url, t('bmv_url_hint')), M.field(pre + '-identifier', t('bmv_identifier'), ident),
      M.field(pre + '-secret', t('bmv_secret'), secret, t('bmv_secret_hint')), M.field(pre + '-accesskey', t('bmv_accesskey'), access, t('bmv_accesskey_hint'))]);
    var dumpPart = el('div', {class: 'fp-bmv-dump', hidden: true}, [el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: pre + '-file', text: t('bmv_file')}), file,
      el('span', {class: 'sig-hint', id: pre + '-file-hint', text: t('bmv_file_hint')})])]);
    var form = el('form', {class: 'fp-form fp-bmv-form', novalidate: '', 'aria-labelledby': pre + '-h', 'data-fp-move': ''}, [M.errorLine(), M.statusLine(),
      el('ol', {class: 'fp-bim-steps'}, [el('li', {text: t('bmv_step_1')}), el('li', {text: t('bmv_step_2')}), el('li', {text: t('bmv_step_3')})]),
      M.field(pre + '-from', t('bmv_from'), source), apiPart, dumpPart,
      M.field(pre + '-mapping', t('bmv_mapping'), mapping, t('bmv_mapping_hint')), M.field(pre + '-skip', t('bmv_skip'), skip, t('bmv_skip_hint')),
      el('div', {class: 'sig-field sig-field--check'}, [untied, el('label', {class: 'sig-label', for: pre + '-untied', text: t('bmv_untied')})]),
      el('div', {class: 'fp-actions'}, [check, go]), out]);
    var token = '';
    var upload = null; /* {file, id}: the file the server keeps for this login */
    function reset() { token = ''; go.disabled = true; }
    function showSource() {
      var dump = source.value === 'dump';
      apiPart.hidden = dump;
      dumpPart.hidden = !dump;
      reset();
    }
    source.addEventListener('change', showSource);
    [url, ident, secret, access, mapping, skip].forEach(function (x) { x.addEventListener('input', function () { if (token) { reset(); M.say(form, t('bmv_changed')); } }); });
    [file, untied].forEach(function (x) { x.addEventListener('change', function () { if (token) { reset(); M.say(form, t('bmv_changed')); } }); });
    function body(withToken) {
      var b = {from: source.value, mapping: mapping.value, skip_clients: skip.value, leave_untied: untied.checked};
      if (source.value === 'api') {
        b.url = url.value.trim();
        b.identifier = ident.value;
        b.secret = secret.value;
        b.accesskey = access.value;
      } else {
        b.upload = upload ? upload.id : '';
      }
      if (withToken) { b.token = token; }
      return b;
    }
    /* the dump goes up once per file chosen; another file, another upload */
    function sendFile() {
      var picked = file.files && file.files[0];
      if (upload && upload.file === picked) { return Promise.resolve(); }
      return FP.call('post', 'billingMoveUpload', undefined, undefined, {body: picked, type: 'application/octet-stream'}).then(function (r) {
        upload = {file: picked, id: r && typeof r.upload === 'string' ? r.upload : ''};
      });
    }
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = e.submitter && e.submitter.classList.contains('fp-submit') ? e.submitter : check;
      if (!B.begin(form, b)) { return; }
      var dry = b === check;
      if (source.value === 'api') {
        if (!url.value.trim()) { M.fieldError(form, url, t('bmv_url') + ': ' + t('bmv_needed')); return; }
        if (!ident.value || !secret.value) { M.fieldError(form, ident.value ? secret : ident, t('bmv_credential_needed')); return; }
      } else {
        var picked = file.files && file.files[0];
        if (!picked) { M.fieldError(form, file, t('bmv_file_needed')); return; }
        if (picked.size > 100 * 1048576) { M.fieldError(form, file, t('bmv_file_big')); return; }
      }
      if (!dry && !token) { M.fieldError(form, check, t('bmv_check_first')); return; }
      UI.setBusy(check, true);
      UI.setBusy(go, true);
      M.say(form, t('bmv_reading'));
      var first = source.value === 'dump' && dry ? sendFile() : Promise.resolve();
      first.then(function () {
        return FP.call('post', dry ? 'billingMoveCheck' : 'billingMoveApply', body(!dry));
      }).then(function (r) {
        if (!form.isConnected) { return; }
        UI.setBusy(check, false);
        go.removeAttribute('aria-busy');
        var rep = cleanReport(r);
        drawReport(out, rep);
        if (dry) {
          token = rep.token;
          go.disabled = !token;
          M.say(form, token ? t('bmv_checked_ok') : t('bmv_checked_bad', {n: B.num(rep.problems.length + (rep.more_problems || 0))}));
          (token ? go : out.querySelector('[tabindex="-1"]') || check).focus();
        } else {
          reset();
          upload = null;
          if (rep.dry_run) {
            M.say(form, t('bmv_not_made'));
          } else {
            /* the credential has done its work: it leaves the form too */
            secret.value = '';
            access.value = '';
            M.say(form, t('bmv_done', {n: B.num(rep.made.customers)}));
          }
          out.querySelector('[tabindex="-1"]').focus();
        }
      }, function (err) {
        if (!form.isConnected) { return; }
        UI.setBusy(check, false);
        go.removeAttribute('aria-busy');
        if (!dry) { reset(); upload = null; }
        go.disabled = !token;
        M.say(form, '');
        out.textContent = '';
        var field = err && err.field === 'source' ? (source.value === 'api' ? 'url' : 'upload') : err && err.field;
        B.failed(form, Object.assign({}, err, {field: field || ''}));
      });
    });
    return B.card(pre + '-h', t('bmv_title'), [el('p', {class: 'fp-muted', text: t('bmv_what')}), el('p', {class: 'fp-muted', text: t('bmv_safe')}), form], 'fp-bim-card fp-bmv-card', 'move');
  }
  function itemRows(list) {
    return list.map(function (x) {
      return el('tr', null, [el('td', {text: t('bmv_kind_' + x.kind) === 'bmv_kind_' + x.kind ? x.kind : t('bmv_kind_' + x.kind)}), el('td', {class: 'fp-bil-num', text: x.id ? String(x.id) : '—'}),
        el('td', null, [el('code', {text: x.field || '—'})]), el('td', {class: 'fp-bil-wrap', text: x.message})]);
    });
  }
  function drawReport(out, rep) {
    out.textContent = '';
    var hid = 'fp-bmv-res';
    var heads = function () { return [B.th(t('bmv_col_kind')), B.th(t('bmv_col_id'), 'fp-bil-num'), B.th(t('bim_col_field')), B.th(t('bmv_col_message'))]; };
    var made = !rep.dry_run;
    var mv = made ? rep.made : rep.moving;
    var parts = [el('h3', {class: 'fp-h3', id: hid, tabindex: '-1', text: rep.problems.length ? t('bmv_problems_title') : made ? t('bmv_made_title') : t('bmv_clean_title')}),
      B.facts([[t('bmv_customers'), B.num(mv.customers)], [t('bmv_services'), B.num(mv.services)], [t('bmv_domains'), B.num(mv.domains)], [t('bmv_balances'), B.num(mv.balances)],
        [t('bmv_owed'), B.money(rep.owed_cents)], [t('bmv_credit'), B.money(rep.credit_cents)]])];
    var there = rep.already_there;
    if (there.customers + there.services + there.domains + there.balances > 0) {
      parts.push(el('p', {class: 'fp-muted fp-row-note', text: t('bmv_already', {c: B.num(there.customers), s: B.num(there.services), d: B.num(there.domains), b: B.num(there.balances)})}));
    }
    if (rep.overdue_balances) { parts.push(el('p', {class: 'fp-muted fp-row-note', text: t('bmv_overdue', {n: B.num(rep.overdue_balances)})})); }
    if (rep.problems.length) {
      parts.push(el('p', {class: 'fp-muted fp-row-note', text: t('bmv_nothing_made')}));
      parts.push(B.table(hid, 'fp-bmv-problems', heads(), itemRows(rep.problems)));
      if (rep.more_problems) { parts.push(el('p', {class: 'fp-muted fp-row-note', text: t('bim_more', {n: B.num(rep.more_problems)})})); }
    }
    if (rep.left.length) {
      var lid = 'fp-bmv-left-h';
      parts.push(el('h4', {class: 'fp-h4', id: lid, text: t('bmv_left_title')}));
      parts.push(B.table(lid, 'fp-bmv-left', [B.th(t('bmv_col_what')), B.th(t('bmv_col_count'), 'fp-bil-num')], rep.left.map(function (x) {
        return el('tr', null, [el('td', {class: 'fp-bil-wrap', text: x[0]}), el('td', {class: 'fp-bil-num', text: B.num(x[1])})]);
      })));
    }
    if (rep.warnings.length) {
      var wid = 'fp-bmv-warn-h';
      parts.push(el('h4', {class: 'fp-h4', id: wid, text: t('bmv_warnings_title')}));
      parts.push(B.table(wid, 'fp-bmv-warnings', heads(), itemRows(rep.warnings)));
    }
    out.appendChild(el('div', {class: 'fp-bim-result', 'data-fp-outcome': rep.problems.length ? 'wrong' : made ? 'made' : 'clean'}, parts));
  }

  FP.view('tool:billing_import', function () {
    var page = B.frame('billing_import', 'fp-bim');
    if (!page) { return; }
    /* the CSV files go to the server's book, the admin's; a move from another system goes to the login's own book, a reseller's too */
    if (FP.session.user.role === 'admin') {
      B.screen(page, [el('p', {class: 'fp-muted fp-bim-intro', text: t('bim_intro')})].concat(FILES.map(importCard), [moveCard()]));
    } else {
      B.screen(page, [el('p', {class: 'fp-muted fp-bim-intro', text: t('bmv_intro_reseller')}), moveCard()]);
    }
  });

})();

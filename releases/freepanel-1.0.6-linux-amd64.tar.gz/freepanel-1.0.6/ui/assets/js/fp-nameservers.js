/* freePanel name servers (docs/api.md, "DNS", GET and PUT /dns/nameservers): the admin panel's page (#/tool/dns_nameservers) for the
   names every zone on the server lists as its name servers. It shows the names, the address new zones point at, and what the
   registrar needs (glue records for names under a domain this server answers for). Saving writes every zone again, so the zones
   list the new names at once; zones of a reseller with names of its own keep those. Admin only. Everything the server sends is
   shown as text. The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var MAX = 8;
  var HOST_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;

  function names(v) { return (Array.isArray(v) ? v : []).filter(function (n) { return typeof n === 'string' && HOST_RE.test(n); }).slice(0, MAX); }

  var N = {page: null, ns: null, zones: 0, address: '', busy: false, result: null};

  function read(r) {
    r = r && typeof r === 'object' ? r : {};
    N.ns = names(r.nameservers);
    N.zones = Array.isArray(r.zones) ? r.zones.length : 0;
  }
  /* the address new zones point at, from the server's addresses (best effort: the page works without it) */
  function mainAddress(ips) {
    var list = ips && Array.isArray(ips.ips) ? ips.ips : [];
    for (var i = 0; i < list.length; i++) {
      if (list[i] && list[i].main === true && typeof list[i].address === 'string' && list[i].address.indexOf(':') < 0) { return list[i].address.slice(0, 45); }
    }
    return '';
  }

  function nowCard() {
    var rows = N.ns.map(function (n, i) {
      return el('li', {class: 'fp-nsv-row'}, [el('span', {class: 'sig-mono', text: n}), i === 0 ? el('span', {class: 'sig-pill', text: t('nsv_primary')}) : null]);
    });
    var parts = [el('ul', {class: 'fp-nsv-list', 'data-fp-nsv-now': ''}, rows.length ? rows : [el('li', {text: t('nsv_none')})])];
    if (N.address) {
      parts.push(el('p', {'data-fp-nsv-address': ''}, [el('strong', {text: t('nsv_address') + ' '}), el('span', {class: 'sig-mono', text: N.address})]));
    }
    parts.push(el('p', {class: 'fp-muted', text: t('nsv_zones', {n: N.zones})}));
    return M.card('fp-nsv-now-h', t('nsv_now_title'), parts, 'fp-nsv-now');
  }

  function glueCard() {
    var addr = N.address || t('nsv_your_address');
    var items = N.ns.map(function (n) { return el('li', {}, [el('span', {class: 'sig-mono', text: n}), ' → ', el('span', {class: 'sig-mono', text: addr})]); });
    return M.card('fp-nsv-glue-h', t('nsv_glue_title'), [el('p', {text: t('nsv_glue_what')}), el('ul', {class: 'fp-nsv-glue', 'data-fp-nsv-glue': ''}, items),
      el('p', {class: 'fp-muted', text: t('nsv_glue_second')})], 'fp-nsv-gluecard');
  }

  function setCard() {
    var inputs = [];
    for (var i = 0; i < MAX; i++) {
      var id = 'fp-nsv-' + (i + 1);
      inputs.push(M.field(id, t('nsv_name_n', {n: i + 1}), el('input', {class: 'sig-input sig-mono', id: id, name: 'ns' + (i + 1), type: 'text', autocomplete: 'off',
        spellcheck: 'false', autocapitalize: 'none', maxlength: '253', value: N.ns[i] || ''}), i === 0 ? t('nsv_name_hint') : null));
    }
    var form = el('form', {class: 'fp-form fp-nsv-form', novalidate: ''}, [M.errorLine(), M.statusLine()].concat(inputs, [
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('nsv_save')})])]));
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || N.busy) { return; }
      var list = [];
      for (var j = 1; j <= MAX; j++) {
        var f = form.querySelector('[name="ns' + j + '"]');
        var v = f.value.trim().toLowerCase().replace(/\.$/, '');
        if (!v) { continue; }
        if (!HOST_RE.test(v)) { M.fieldError(form, f, t('nsv_bad')); return; }
        if (list.indexOf(v) >= 0) { M.fieldError(form, f, t('nsv_twice')); return; }
        list.push(v);
      }
      if (list.length < 2) { M.fieldError(form, form.querySelector('[name="ns' + (list.length + 1) + '"]'), t('nsv_need_two')); return; }
      N.busy = true;
      UI.setBusy(b, true);
      var mine = N.page;
      FP.call('put', 'dnsNameservers', {nameservers: list}).then(function (r) {
        N.busy = false;
        if (N.page !== mine) { return; }
        N.ns = names(r && r.nameservers);
        N.result = {zones: Number(r && r.changed) || 0, done: !(r && r.done === false),
          errors: (r && Array.isArray(r.errors) ? r.errors : []).filter(function (x) { return typeof x === 'string'; }).slice(0, 20).map(function (x) { return x.slice(0, 300); })};
        render();
        M.say(N.page.querySelector('.fp-nsv-setcard'), t('nsv_saved', {n: N.result.zones}));
        N.page.querySelector('#fp-nsv-1').focus();
      }, function (err) {
        N.busy = false;
        if (N.page !== mine) { return; }
        UI.setBusy(b, false);
        if (err && err.field === 'nameservers') {
          M.fieldError(form, form.querySelector('[name="ns1"]'), err.message);
        } else {
          M.failed(form, err);
        }
      });
    });
    return M.card('fp-nsv-set-h', t('nsv_set_title'), [el('p', {class: 'fp-muted', text: t('nsv_set_what')}), form], 'fp-nsv-setcard');
  }

  function resultCard() {
    if (!N.result || (N.result.done && !N.result.errors.length)) { return null; }
    var parts = [];
    if (!N.result.done) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-nsv-partial': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('nsv_partial')})]));
    }
    if (N.result.errors.length) {
      parts.push(el('ul', {class: 'fp-nsv-errors', 'data-fp-nsv-errors': ''}, N.result.errors.map(function (x) { return el('li', {text: x}); })));
    }
    return M.card('fp-nsv-res-h', t('nsv_result_title'), parts, 'fp-nsv-result');
  }

  function render() {
    N.page.textContent = '';
    N.page.appendChild(nowCard());
    var res = resultCard();
    if (res) { N.page.appendChild(res); }
    N.page.appendChild(setCard());
    N.page.appendChild(glueCard());
  }

  FP.view('tool:dns_nameservers', function () {
    var tool = FP.tools.dns_nameservers;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    N.ns = null;
    N.busy = false;
    N.result = null;
    N.address = '';
    var body = FP.frame({title: tool.label, desc: t('nsv_desc'), cls: 'fp-mail fp-srv fp-nsv-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    N.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    var ips = FP.call('get', 'serverIps').then(mainAddress, function () { return ''; });
    Promise.all([FP.call('get', 'dnsNameservers'), ips]).then(function (both) {
      if (N.page !== body) { return; }
      read(both[0]);
      N.address = both[1];
      render();
    }, function (err) {
      if (N.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });

  FP.nameservers = {names: names, HOST_RE: HOST_RE, MAX: MAX};
})();

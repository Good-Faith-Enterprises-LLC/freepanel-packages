#!/bin/bash
# Points apt at freePanel's package repository (Ubuntu 24.04), trusting only
# the key with the pinned fingerprint, or takes the repository away from this
# server: the apt twin of setup-repo.sh.
#
#   setup-apt.sh KEYFILE FINGERPRINT BASEURL
#   setup-apt.sh --withdraw FINGERPRINT
#
# KEYFILE is the public key shipped with the release, FINGERPRINT the one the
# installer pins, BASEURL the site (https://, or file:// for a test); the apt
# repository is its apt/ folder. The key is refused unless it is exactly one
# key with that fingerprint. It goes to /etc/apt/keyrings/freepanel.asc and
# /etc/apt/sources.list.d/freepanel.sources names it as Signed-By, so apt
# trusts it for this repository alone and the repository by it alone.
#
# --withdraw, for an incident: the sources file and the key are moved aside,
# so apt stops using the repository and trusting the key. Run as root.
set -euo pipefail

usage="usage: setup-apt.sh KEYFILE FINGERPRINT BASEURL | --withdraw FINGERPRINT"
[ "$(id -u)" -eq 0 ] || { echo "run as root" >&2; exit 1; }
LIST=/etc/apt/sources.list.d/freepanel.sources
KEY=/etc/apt/keyrings/freepanel.asc

fingerprint() {
  local f
  f=$(printf '%s' "$1" | tr 'a-f' 'A-F')
  case "$f" in
    *[!0-9A-F]* | "") echo "the fingerprint must be hex" >&2; exit 1 ;;
  esac
  [ "${#f}" -eq 40 ] || [ "${#f}" -eq 64 ] || { echo "the fingerprint must be a full fingerprint" >&2; exit 1; }
  printf '%s' "$f"
}

if [ "${1:-}" = --withdraw ]; then
  FPR=$(fingerprint "${2:?$usage}")
  stamp=$(date +%Y%m%d%H%M%S)
  for f in "$LIST" "$KEY"; do
    # Aside under a name apt does not read (it reads *.sources only).
    [ -e "$f" ] && mv "$f" "$f.withdrawn-$stamp"
  done
  echo "freePanel's package repository is withdrawn from this server; apt no longer uses it or trusts $FPR"
  exit 0
fi

KEYFILE=${1:?$usage}
FPR=$(fingerprint "${2:?$usage}")
URL=${3:?$usage}
case "$URL" in
  https://* | file:///*) ;;
  *) echo "the repository must be https:// (or file:// for a test)" >&2; exit 1 ;;
esac
case "$URL" in
  *[[:space:]]* | *\$* | *\\* | *'#'*) echo "the repository URL has characters apt would read as syntax" >&2; exit 1 ;;
esac

gh=$(mktemp -d)
trap 'rm -rf "$gh"' EXIT
keys=$(GNUPGHOME=$gh gpg --batch --with-colons --import-options show-only --import "$KEYFILE" 2>/dev/null |
  awk -F: '$1=="pub"{p=1} $1=="fpr" && p {print $10; p=0}')
if [ "$(printf '%s\n' "$keys" | grep -c .)" -ne 1 ] || [ "$keys" != "$FPR" ]; then
  echo "$KEYFILE is not the key with fingerprint $FPR (it holds: ${keys:-nothing})" >&2
  exit 1
fi
grep -q -- '-----BEGIN PGP PUBLIC KEY BLOCK-----' "$KEYFILE" || { echo "$KEYFILE is not an armored key (.asc)" >&2; exit 1; }

umask 022
install -d -m 0755 /etc/apt/keyrings
install -m 0644 -o root -g root "$KEYFILE" "$KEY.tmp"
mv "$KEY.tmp" "$KEY"
cat >"$LIST.tmp" <<LIST
# Managed by freePanel.
Types: deb
URIs: ${URL%/}/apt
Suites: noble
Components: main
Architectures: amd64
Signed-By: $KEY
LIST
chmod 0644 "$LIST.tmp"
mv "$LIST.tmp" "$LIST"
echo "apt now uses ${URL%/}/apt, signed by $FPR"

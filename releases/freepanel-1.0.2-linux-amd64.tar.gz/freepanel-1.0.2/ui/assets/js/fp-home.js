/* freePanel home views: the customer's tools home (groups of tiles beside the account card), the admin
   home (every function group beside the server card), one group's page, a tool that has no page yet and not found. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var admin = FP.realm === 'admin';

  function count(n) { return typeof n === 'number' && isFinite(n) ? n.toLocaleString('en') : '\u2014'; }

  function row(label, value, mono) {
    return el('li', {class: 'sig-row'}, [el('span', {class: 'sig-row-label', text: label}),
      el('span', {class: 'sig-row-value' + (mono ? ' sig-mono' : ''), text: value})]);
  }
  function infoCard(title, id) {
    var list = el('ul', {class: 'sig-rows', 'data-fp-rows': id}, [el('li', {class: 'sig-row fp-muted', text: t('loading')})]);
    return el('section', {class: 'sig-card', 'aria-labelledby': 'fp-card-' + id}, [
      el('div', {class: 'sig-card-head'}, [el('h2', {class: 'sig-card-title', id: 'fp-card-' + id, text: title})]), list]);
  }
  function fill(list, rows) {
    list.textContent = '';
    rows.forEach(function (r) { list.appendChild(r); });
  }
  function unavailable(list) { fill(list, [el('li', {class: 'sig-row fp-muted', text: t('summary_unavailable')})]); }

  function str(v) { return typeof v === 'string' && v ? v : '—'; }
  function num(v) { return typeof v === 'number' && isFinite(v) && v >= 0; }

  /* sizes the way hosting panels show them: binary steps named KB, MB, GB, TB */
  var UNITS = ['KB', 'MB', 'GB', 'TB', 'PB'];
  function size(n) {
    if (!num(n)) { return '\u2014'; }
    if (n < 1024) { return t('size_bytes', {n: count(Math.round(n))}); }
    var u = -1;
    do { n /= 1024; u++; } while (n >= 1024 && u < UNITS.length - 1);
    return (n < 10 ? n.toFixed(1) : Math.round(n).toLocaleString('en')) + ' ' + UNITS[u];
  }
  /* one measure against its limit: "used of limit" with a bar, "used (no limit)", or not measured yet (never shown as 0) */
  function meterRow(label, used, limit, fmt) {
    var value;
    var level = '';
    var pct = -1;
    if (!num(used)) {
      value = t('usage_not_measured');
    } else if (!num(limit)) {
      value = t('used_no_limit', {used: fmt(used)});
    } else {
      value = t('of_limit', {used: fmt(used), limit: fmt(limit)});
      pct = limit > 0 ? Math.min(100, used / limit * 100) : 100;
      level = pct >= 95 ? ' is-danger' : pct >= 80 ? ' is-warn' : '';
    }
    var li = el('li', {class: 'sig-row'}, [el('div', {class: 'sig-row-head'}, [el('span', {class: 'sig-row-label', text: label}),
      el('span', {class: 'sig-stat-v' + level + (num(used) ? '' : ' fp-muted'), text: value})])]);
    if (pct >= 0) {
      var bar = el('i');
      bar.style.width = pct.toFixed(1) + '%';
      li.appendChild(el('div', {class: 'sig-meter' + level, 'aria-hidden': 'true'}, [bar]));
    }
    return li;
  }
  function note(text) { return el('li', {class: 'sig-row fp-muted fp-row-note', text: text}); }
  function when(iso) {
    var d = typeof iso === 'string' ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }
  function uptime(sec) {
    if (!num(sec)) { return '\u2014'; }
    var d = Math.floor(sec / 86400);
    var h = Math.floor(sec % 86400 / 3600);
    return d ? t(d === 1 ? 'uptime_day' : 'uptime_days', {d: count(d), h: h}) : t('uptime_hours', {h: h, m: Math.floor(sec % 3600 / 60)});
  }

  /* ---- customer home ---- */
  function groupCard(g, i, closed) {
    var listId = 'fp-grp-' + g.id;
    var open = !closed[g.id];
    var toggle = el('button', {class: 'sig-ghost sig-grp-toggle', type: 'button', 'aria-expanded': String(open), 'aria-controls': listId,
      'aria-label': t('group_toggle', {group: g.label})}, [UI.icon(FP.ui, 'ui_caret_down')]);
    var tiles = el('ul', {class: 'sig-tiles', id: listId});
    tiles.hidden = !open;
    g.tools.forEach(function (tool) { tiles.appendChild(el('li', null, [FP.toolLink(tool, 'sig-tile', true, 'sig-ico--36')])); });
    var card = el('section', {class: 'sig-card sig-grp' + (open ? '' : ' is-closed'), 'aria-labelledby': 'fp-grp-h-' + g.id, 'data-fp-grp': g.id}, [
      el('div', {class: 'sig-card-head'}, [UI.icon(FP.sprite, 'grp_' + g.id, 'sig-ico--24'),
        el('h2', {class: 'sig-grp-title', id: 'fp-grp-h-' + g.id, text: g.label}),
        el('div', {class: 'sig-card-actions'}, [toggle])]),
      tiles]);
    card.style.setProperty('--sig-i', String(i));
    return card;
  }

  /* the account's sites stopped for the monthly bandwidth limit (docs/api.md, Usage), or back for a while */
  function bandwidthNotice(u) {
    var text = '';
    if (u.bandwidth_limited === true) {
      var m = /^(\d{4})-(\d{2})$/.exec(typeof u.month === 'string' ? u.month : '');
      var next = m ? new Date(Date.UTC(Number(m[1]), Number(m[2]), 1)) : null;
      text = t('bw_home_stopped', {date: next ? next.toLocaleDateString('en', {month: 'long', day: 'numeric', timeZone: 'UTC'}) : t('bw_next_month')});
    } else if (typeof u.bandwidth_lifted_until === 'string' && when(u.bandwidth_lifted_until)) {
      text = t('bw_home_lifted', {when: when(u.bandwidth_lifted_until)});
    }
    return text ? el('div', {class: 'sig-banner sig-banner--warn fp-home-notice', role: 'note', 'data-fp-bandwidth': ''},
      [UI.icon(FP.ui, 'ui_warning'), el('span', {text: text})]) : null;
  }

  function userHome() {
    var body = FP.frame({title: t('home_user'), desc: t('home_user_desc_plain')});
    var layout = el('div', {class: 'fp-home'});
    var groups = el('div', {class: 'sig-groups'});
    var closed = {};
    (UI.store.json('fp.home.closed', []) || []).forEach(function (id) { if (typeof id === 'string') { closed[id] = true; } });
    FP.groups.forEach(function (g, i) { groups.appendChild(groupCard(g, i, closed)); });
    if (!FP.groups.length) { groups.appendChild(FP.empty(t('no_tools'), '')); }
    groups.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('.sig-grp-toggle') : null;
      if (!b) { return; }
      var open = b.getAttribute('aria-expanded') !== 'true';
      var card = b.closest('.sig-grp');
      b.setAttribute('aria-expanded', String(open));
      document.getElementById(b.getAttribute('aria-controls')).hidden = !open;
      card.classList.toggle('is-closed', !open);
      if (open) { delete closed[card.getAttribute('data-fp-grp')]; } else { closed[card.getAttribute('data-fp-grp')] = true; }
      UI.store.set('fp.home.closed', JSON.stringify(Object.keys(closed)));
    });
    var account = infoCard(t('account_card'), 'account');
    var usage = infoCard(t('usage_card'), 'usage');
    var info = el('aside', {class: 'sig-info', 'aria-label': t('account_info')}, [account, usage]);
    layout.appendChild(groups);
    layout.appendChild(info);
    body.appendChild(layout);
    if (FP.tour) { FP.tour(body); }

    FP.summary().then(function (acc) {
      if (!document.body.contains(account)) { return; }
      if (typeof acc.domain === 'string' && acc.domain) {
        var desc = document.querySelector('.fp-page .sig-desc');
        if (desc) { desc.textContent = t('home_user_desc', {domain: acc.domain}); }
      }
      fill(account.querySelector('ul'), [row(t('row_username'), str(acc.username), true), row(t('row_domain'), str(acc.domain), true),
        row(t('row_plan'), str(acc.package)), row(t('row_contact'), str(acc.contact_email), true),
        row(t('row_status'), acc.status === 'suspended' ? t('status_suspended') : acc.status === 'creating' ? t('status_creating') : t('status_active'))]);
    }, function () { unavailable(account.querySelector('ul')); });

    FP.call('get', 'usage', undefined, FP.account()).then(function (u) {
      if (!document.body.contains(usage)) { return; }
      var notice = bandwidthNotice(u);
      if (notice) { layout.parentNode.insertBefore(notice, layout); }
      var part = function (k) { return u[k] && typeof u[k] === 'object' ? u[k] : {}; };
      var rows = [meterRow(t('usage_disk'), part('disk_bytes').used, part('disk_bytes').limit, size),
        meterRow(t('usage_bandwidth'), part('bandwidth_bytes').used, part('bandwidth_bytes').limit, size),
        meterRow(t('usage_mailboxes'), part('email_accounts').used, part('email_accounts').limit, count),
        meterRow(t('usage_databases'), part('databases').used, part('databases').limit, count)];
      var at = when(u.disk_measured_at);
      if (at && num(part('disk_bytes').used)) { rows.push(note(t('usage_disk_when', {when: at}))); }
      if (u.disk_partial === true) { rows.push(note(t('usage_disk_partial'))); }
      fill(usage.querySelector('ul'), rows);
    }, function () { unavailable(usage.querySelector('ul')); });
  }

  /* ---- admin home ---- */
  function adminHome() {
    var body = FP.frame({title: t('home_admin'), desc: window.location.hostname ? t('home_admin_desc', {host: window.location.hostname}) : t('home_admin_desc_plain')});
    var layout = el('div', {class: 'fp-home'});
    var grid = el('div', {class: 'fp-admin-grid'});
    FP.groups.forEach(function (g) {
      var list = el('ul', {class: 'fp-fn-list'});
      g.tools.forEach(function (tool) { list.appendChild(el('li', null, [FP.toolLink(tool, 'fp-fn', true, 'sig-ico--16')])); });
      grid.appendChild(el('section', {class: 'sig-card fp-fn-card', 'aria-labelledby': 'fp-grp-h-' + g.id}, [
        el('div', {class: 'sig-card-head'}, [UI.icon(FP.sprite, 'grp_' + g.id, 'sig-ico--24'),
          el('h2', {class: 'sig-card-title', id: 'fp-grp-h-' + g.id}, [el('a', {class: 'fp-card-link', href: '#/group/' + g.id, text: g.label})])]),
        list]));
    });
    if (!FP.groups.length) { grid.appendChild(FP.empty(t('no_tools_admin'), '')); }
    var server = infoCard(t('server_card'), 'server');
    layout.appendChild(grid);
    layout.appendChild(el('aside', {class: 'sig-info', 'aria-label': t('server_card')}, [server]));
    body.appendChild(layout);
    if (FP.tour) { FP.tour(body); }
    FP.summary().then(function (sum) {
      if (!document.body.contains(server)) { return; }
      fill(server.querySelector('ul'), sum.status && typeof sum.status === 'object' ? statusRows(sum.version, sum.status) : basicRows(sum));
    }, function () { unavailable(server.querySelector('ul')); });
  }
  /* an admin sees the server itself (GET /server/status) */
  function statusRows(version, st) {
    var mem = st.memory && typeof st.memory === 'object' ? st.memory : {};
    var disk = st.home_disk && typeof st.home_disk === 'object' ? st.home_disk : null;
    var accounts = st.accounts && typeof st.accounts === 'object' ? st.accounts : {};
    var load = Array.isArray(st.load) && st.load.length === 3 && st.load.every(num) ? st.load.map(function (n) { return n.toFixed(2); }).join(', ') : '\u2014';
    var rows = [row(t('row_hostname'), str(st.hostname), true), row(t('row_os'), str(st.os)), row(t('row_kernel'), str(st.kernel), true),
      row(t('row_version'), str(version), true), row(t('row_uptime'), uptime(st.uptime_seconds)), row(t('row_load'), load, true),
      row(t('row_cpus'), count(st.cpus)),
      meterRow(t('row_memory'), num(mem.total_bytes) && num(mem.available_bytes) ? Math.max(0, mem.total_bytes - mem.available_bytes) : null,
        mem.total_bytes, size)];
    if (disk && num(disk.total_bytes) && num(disk.free_bytes)) {
      var path = typeof disk.path === 'string' && disk.path ? disk.path.slice(0, 64) : '/home';
      rows.push(meterRow(t('row_home_disk', {path: path}), Math.max(0, disk.total_bytes - disk.free_bytes), disk.total_bytes, size));
    } else {
      rows.push(row(t('row_home_disk_plain'), t('summary_unavailable')));
    }
    rows.push(row(t('row_accounts'), count(accounts.total)), row(t('row_suspended'), count(accounts.suspended)));
    return rows;
  }
  /* a reseller may not see the server: the panel version and its own accounts */
  function basicRows(sum) {
    var rows = [row(t('row_hostname'), str(window.location.hostname), true), row(t('row_version'), str(sum.version), true)];
    if (sum.accounts) {
      var suspended = sum.accounts.filter(function (a) { return a && a.status === 'suspended'; }).length;
      rows.push(row(t('row_accounts'), count(sum.accounts.length)));
      rows.push(row(t('row_suspended'), count(suspended)));
    }
    return rows;
  }

  /* ---- one group ---- */
  function toolRow(tool) {
    var a = FP.toolLink(tool, 'fp-tool-row', true, 'sig-ico--36');
    a.appendChild(el('span', {class: 'fp-tool-desc', text: tool.desc}));
    return el('li', null, [a]);
  }
  FP.view('group', function (r) {
    var g = FP.group(r.id);
    if (!g) { FP.views['not-found'](r); return; }
    var body = FP.frame({title: g.label, crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label}]});
    var list = el('ul', {class: 'fp-tool-list'});
    g.tools.forEach(function (tool) { list.appendChild(toolRow(tool)); });
    body.appendChild(el('div', {class: 'sig-card'}, [list]));
  });

  /* ---- a tool with no page yet ---- */
  FP.view('tool', function (r) {
    var tool = FP.tools[r.id];
    if (!tool) { FP.views['not-found'](r); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: tool.desc,
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    body.appendChild(FP.empty(t('tool_pending'), t('tool_pending_desc'),
      el('a', {class: 'sig-btn sig-btn--secondary', href: '#/group/' + g.id, text: t('open_group', {group: g.label})})));
  });

  FP.view('not-found', function () {
    var body = FP.frame({title: t('not_found'), desc: t('not_found_desc')});
    body.appendChild(el('p', null, [el('a', {class: 'sig-btn sig-btn--secondary', href: '#/', text: t('back_home')})]));
  });

  /* ---- Classic home (issue #659): a left column of boxes (Notices, Find, Frequently used, Stats) beside titled sections of
     large icon tiles, one per tool group, each of which folds. Under 768px the left column follows the sections. ---- */
  function box(id, title, parts) {
    return el('section', {class: 'fp-cl-box', 'aria-labelledby': 'fp-cl-h-' + id, 'data-fp-cl-box': id}, [
      el('h2', {class: 'fp-cl-box-title', id: 'fp-cl-h-' + id, text: title}), el('div', {class: 'fp-cl-box-body'}, parts)]);
  }
  function classicSection(g, closed) {
    var listId = 'fp-cl-' + g.id;
    var open = !closed[g.id];
    var toggle = el('button', {class: 'fp-cl-sec-toggle', type: 'button', 'aria-expanded': String(open), 'aria-controls': listId}, [
      UI.icon(FP.sprite, 'grp_' + g.id, 'sig-ico--24'), el('span', {class: 'fp-cl-sec-name', text: g.label}),
      el('span', {class: 'sig-vh', text: ' ' + t('classic_section_toggle', {group: g.label})}), UI.icon(FP.ui, 'ui_caret_down', 'fp-cl-caret')]);
    var tiles = el('ul', {class: 'fp-cl-tiles', id: listId});
    tiles.hidden = !open;
    g.tools.forEach(function (tool) { tiles.appendChild(el('li', {'data-fp-cl-tool': tool.id}, [FP.toolLink(tool, 'sig-tile', true, 'sig-ico--36')])); });
    return el('section', {class: 'fp-cl-sec' + (open ? '' : ' is-closed'), 'aria-labelledby': 'fp-cl-sh-' + g.id, 'data-fp-cl-sec': g.id}, [
      el('h2', {class: 'fp-cl-sec-title', id: 'fp-cl-sh-' + g.id}, [toggle]), tiles]);
  }
  function classicHome() {
    var body = FP.frame({title: admin ? t('home_admin') : t('home_user'), desc: admin ? (window.location.hostname ? t('home_admin_desc', {host: window.location.hostname}) : t('home_admin_desc_plain')) : t('home_user_desc_plain')});
    var closedKey = admin ? 'fp.classic.closed.admin' : 'fp.classic.closed';
    var closed = {};
    (UI.store.json(closedKey, []) || []).forEach(function (id) { if (typeof id === 'string') { closed[id] = true; } });
    var secs = el('div', {class: 'fp-cl-secs'});
    FP.groups.forEach(function (g) { secs.appendChild(classicSection(g, closed)); });
    var none = el('p', {class: 'fp-muted fp-cl-none', role: 'status'});
    secs.appendChild(none);
    if (!FP.groups.length) { secs.appendChild(FP.empty(admin ? t('no_tools_admin') : t('no_tools'), '')); }
    secs.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('.fp-cl-sec-toggle') : null;
      if (!b) { return; }
      var open = b.getAttribute('aria-expanded') !== 'true';
      var sec = b.closest('.fp-cl-sec');
      b.setAttribute('aria-expanded', String(open));
      document.getElementById(b.getAttribute('aria-controls')).hidden = !open;
      sec.classList.toggle('is-closed', !open);
      if (open) { delete closed[sec.getAttribute('data-fp-cl-sec')]; } else { closed[sec.getAttribute('data-fp-cl-sec')] = true; }
      UI.store.set(closedKey, JSON.stringify(Object.keys(closed)));
    });

    var notices = el('div', {class: 'fp-cl-notices'}, [el('p', {class: 'fp-muted', 'data-fp-cl-quiet': '', text: t('classic_notices_none')})]);
    var find = el('input', {id: 'fp-cl-find', type: 'search', class: 'sig-input', autocomplete: 'off', spellcheck: 'false', placeholder: t('classic_find_label')});
    find.addEventListener('input', function () {
      var q = find.value.trim().toLowerCase();
      var any = false;
      var all = secs.querySelectorAll('.fp-cl-sec');
      for (var i = 0; i < all.length; i++) {
        var sec = all[i];
        var hits = 0;
        var items = sec.querySelectorAll('[data-fp-cl-tool]');
        for (var j = 0; j < items.length; j++) {
          var ok = FP.matches(FP.tools[items[j].getAttribute('data-fp-cl-tool')], q);
          items[j].hidden = !ok;
          if (ok) { hits++; }
        }
        sec.hidden = Boolean(q) && !hits;
        var list = sec.querySelector('.fp-cl-tiles');
        list.hidden = q ? !hits : sec.classList.contains('is-closed');
        if (hits) { any = true; }
      }
      none.textContent = q && !any ? t('classic_find_none', {q: find.value.trim().slice(0, 60)}) : '';
    });
    find.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && find.value) { e.stopPropagation(); find.value = ''; find.dispatchEvent(new Event('input')); }
    });
    var ids = FP.theme ? FP.theme.recent() : [];
    var recentList = ids.length ? el('ul', {class: 'fp-cl-recent'}, ids.map(function (id) {
      return el('li', null, [FP.toolLink(FP.tools[id], 'fp-fn', true, 'sig-ico--16')]);
    })) : el('p', {class: 'fp-muted', text: t('classic_recent_none')});
    var facts = el('table', {class: 'fp-cl-facts'}, [el('tbody', null, [el('tr', null, [el('td', {class: 'fp-muted', colspan: '2', text: t('loading')})])])]);
    var meters = el('ul', {class: 'sig-rows fp-cl-meters'});
    var side = el('aside', {class: 'fp-cl-side', 'aria-label': admin ? t('server_card') : t('account_info')}, [
      box('notices', t('classic_notices'), [notices]),
      box('find', t('classic_find'), [el('label', {class: 'sig-vh', for: 'fp-cl-find', text: t('classic_find_label')}), find]),
      box('recent', t('classic_recent'), [recentList]),
      box('stats', t('classic_stats'), [facts, meters])]);
    body.appendChild(el('div', {class: 'fp-cl-home'}, [secs, side]));

    function factRows(pairs) {
      var tb = facts.querySelector('tbody');
      tb.textContent = '';
      pairs.forEach(function (p) {
        tb.appendChild(el('tr', null, [el('th', {scope: 'row', text: p[0]}), el('td', {class: p[2] ? 'sig-mono' : '', text: p[1]})]));
      });
    }
    function failed() { factRows([[t('classic_stats'), t('summary_unavailable')]]); }
    if (admin) {
      FP.summary().then(function (sum) {
        if (!document.body.contains(facts)) { return; }
        facts.hidden = true;
        fill(meters, sum.status && typeof sum.status === 'object' ? statusRows(sum.version, sum.status) : basicRows(sum));
      }, function () { if (document.body.contains(facts)) { failed(); } });
      return;
    }
    FP.summary().then(function (acc) {
      if (!document.body.contains(facts)) { return; }
      factRows([[t('row_username'), str(acc.username), true], [t('row_domain'), str(acc.domain), true], [t('row_plan'), str(acc.package)],
        [t('classic_server'), str(window.location.hostname), true],
        [t('row_status'), acc.status === 'suspended' ? t('status_suspended') : acc.status === 'creating' ? t('status_creating') : t('status_active')]]);
    }, function () { if (document.body.contains(facts)) { failed(); } });
    FP.call('get', 'usage', undefined, FP.account()).then(function (u) {
      if (!document.body.contains(meters)) { return; }
      var notice = bandwidthNotice(u);
      if (notice) { notices.textContent = ''; notices.appendChild(notice); }
      var part = function (k) { return u[k] && typeof u[k] === 'object' ? u[k] : {}; };
      var rows = [['usage_disk', 'disk_bytes', size], ['usage_bandwidth', 'bandwidth_bytes', size], ['usage_mailboxes', 'email_accounts', count],
        ['usage_forwarders', 'forwarders', count], ['usage_databases', 'databases', count], ['usage_domains', 'domains', count],
        ['usage_subdomains', 'subdomains', count]].map(function (m) { return meterRow(t(m[0]), part(m[1]).used, part(m[1]).limit, m[2]); });
      fill(meters, rows);
    }, function () { if (document.body.contains(meters)) { unavailable(meters); } });
  }

  /* ---- Cards home (issue #660): a strip of usage gauges across the top, then a grid of category cards, one per tool group,
     each listing up to 8 of its tools as text links before a link to the whole group ---- */
  var CARD_LINKS = 8;
  function gauge(label, used, limit, fmt) {
    var pct = num(used) && num(limit) && limit > 0 ? Math.min(100, used / limit * 100) : -1;
    var level = pct >= 95 ? ' is-danger' : pct >= 80 ? ' is-warn' : '';
    var value = !num(used) ? t('usage_not_measured') : !num(limit) ? t('used_no_limit', {used: fmt(used)}) : t('of_limit', {used: fmt(used), limit: fmt(limit)});
    var li = el('li', {class: 'fp-cd-gauge' + level}, [el('span', {class: 'fp-cd-gauge-label', text: label}),
      el('span', {class: 'fp-cd-gauge-value' + (num(used) ? '' : ' fp-muted'), text: value})]);
    if (pct >= 0) {
      var bar = el('i');
      bar.style.width = pct.toFixed(1) + '%';
      li.appendChild(el('div', {class: 'sig-meter' + level, 'aria-hidden': 'true'}, [bar]));
    }
    return li;
  }
  function categoryCard(g) {
    var list = el('ul', {class: 'fp-cd-links'});
    g.tools.slice(0, CARD_LINKS).forEach(function (tool) { list.appendChild(el('li', null, [FP.toolLink(tool, 'fp-fn', true, 'sig-ico--16')])); });
    var card = el('section', {class: 'fp-cd-card', 'aria-labelledby': 'fp-cd-h-' + g.id}, [
      el('div', {class: 'fp-cd-card-head'}, [UI.icon(FP.sprite, 'grp_' + g.id, 'sig-ico--24'),
        el('h2', {class: 'fp-cd-card-title', id: 'fp-cd-h-' + g.id}, [el('a', {href: '#/group/' + g.id, text: g.label})])]),
      list]);
    if (g.tools.length > CARD_LINKS) {
      card.appendChild(el('a', {class: 'fp-cd-more', href: '#/group/' + g.id, text: t('cards_more', {group: g.label, count: g.tools.length})}));
    }
    return card;
  }
  function cardsHome() {
    var body = FP.frame({title: admin ? t('home_admin') : t('home_user'), desc: admin ? (window.location.hostname ? t('home_admin_desc', {host: window.location.hostname}) : t('home_admin_desc_plain')) : t('home_user_desc_plain')});
    var strip = el('ul', {class: 'fp-cd-gauges', 'aria-labelledby': 'fp-cd-usage'}, [el('li', {class: 'fp-cd-gauge fp-muted', text: t('loading')})]);
    var grid = el('div', {class: 'fp-cd-grid'});
    FP.groups.forEach(function (g) { grid.appendChild(categoryCard(g)); });
    if (!FP.groups.length) { grid.appendChild(FP.empty(admin ? t('no_tools_admin') : t('no_tools'), '')); }
    body.appendChild(el('h2', {class: 'sig-vh', id: 'fp-cd-usage', text: t('cards_usage')}));
    body.appendChild(strip);
    body.appendChild(grid);
    if (FP.tour) { FP.tour(body); }
    if (admin) {
      FP.summary().then(function (sum) {
        if (!document.body.contains(strip)) { return; }
        var st = sum.status && typeof sum.status === 'object' ? sum.status : null;
        var rows = [];
        if (st) {
          var mem = st.memory && typeof st.memory === 'object' ? st.memory : {};
          var disk = st.home_disk && typeof st.home_disk === 'object' ? st.home_disk : {};
          var acc = st.accounts && typeof st.accounts === 'object' ? st.accounts : {};
          rows.push(gauge(t('row_memory'), num(mem.total_bytes) && num(mem.available_bytes) ? Math.max(0, mem.total_bytes - mem.available_bytes) : null, mem.total_bytes, size));
          rows.push(gauge(t('row_home_disk_plain'), num(disk.total_bytes) && num(disk.free_bytes) ? Math.max(0, disk.total_bytes - disk.free_bytes) : null, disk.total_bytes, size));
          rows.push(gauge(t('row_accounts'), acc.total, null, count), gauge(t('row_suspended'), acc.suspended, acc.total, count));
        } else if (sum.accounts) {
          var susp = sum.accounts.filter(function (a) { return a && a.status === 'suspended'; }).length;
          rows.push(gauge(t('row_accounts'), sum.accounts.length, null, count), gauge(t('row_suspended'), susp, sum.accounts.length, count));
        }
        if (rows.length) { fill(strip, rows); } else { strip.hidden = true; }
      }, function () { if (document.body.contains(strip)) { unavailable(strip); } });
      return;
    }
    FP.call('get', 'usage', undefined, FP.account()).then(function (u) {
      if (!document.body.contains(strip)) { return; }
      var notice = bandwidthNotice(u);
      if (notice) { strip.parentNode.insertBefore(notice, strip); }
      var part = function (k) { return u[k] && typeof u[k] === 'object' ? u[k] : {}; };
      fill(strip, [['usage_disk', 'disk_bytes', size], ['usage_bandwidth', 'bandwidth_bytes', size], ['usage_mailboxes', 'email_accounts', count],
        ['usage_databases', 'databases', count], ['usage_domains', 'domains', count]].map(function (m) { return gauge(t(m[0]), part(m[1]).used, part(m[1]).limit, m[2]); }));
    }, function () { if (document.body.contains(strip)) { unavailable(strip); } });
  }

  /* ---- Domains home (issue #661): one card per domain (main, addon, sub, and each alias), with its folder, SSL and PHP and a row
     of quick actions that open the tools with that domain picked; resource usage and a quick start list on the right. In the
     admin panel the cards are the hosting accounts. ---- */
  var DM_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var USER_RE = /^[a-z][a-z0-9]{0,15}$/;
  var DM_ACTIONS = ['file_manager', 'mysql', 'mailboxes', 'ssl', 'php_version', 'dns', 'access_logs'];
  var DM_ADMIN_ACTIONS = ['account_edit', 'account_password', 'account_suspend', 'resource_limits', 'account_login'];
  var DM_QUICK = admin ? ['account_new', 'package_list', 'account_list', 'ssl_auto', 'backup_settings'] : ['domains', 'mailboxes', 'mysql', 'app_installer', 'ssl', 'file_manager'];
  var DM_ORDER = {main: 0, addon: 1, sub: 2, parked: 3};
  function dmSites(v) {
    var out = [];
    (v && Array.isArray(v.sites) ? v.sites : []).forEach(function (x) {
      if (!x || !DM_RE.test(str(x.domain))) { return; }
      var kind = x.kind === 'main' || x.kind === 'addon' ? x.kind : x.kind === 'sub' || x.kind === 'subdomain' ? 'sub' : '';
      if (!kind) { return; }
      var c = x.certificate && typeof x.certificate === 'object' ? x.certificate : null;
      var site = {domain: x.domain, kind: kind, root: typeof x.docroot === 'string' ? x.docroot.slice(0, 200) : '',
        php: typeof x.php_version === 'string' && /^\d+\.\d+$/.test(x.php_version) ? x.php_version : '',
        ssl: c ? (c.expired === true ? 'expired' : 'ok') : 'none', until: c ? when(c.not_after).split(',').slice(0, 2).join(',') : '', of: ''};
      out.push(site);
      (Array.isArray(x.aliases) ? x.aliases : []).forEach(function (a) {
        if (DM_RE.test(str(a))) { out.push({domain: a, kind: 'parked', root: site.root, php: site.php, ssl: '', until: '', of: x.domain}); }
      });
    });
    out.sort(function (a, b) { return DM_ORDER[a.kind] - DM_ORDER[b.kind] || (a.domain < b.domain ? -1 : 1); });
    return out;
  }
  function actionLinks(ids, pick, label) {
    var list = el('ul', {class: 'fp-dm-acts', 'aria-label': label});
    ids.forEach(function (id) {
      var tool = FP.tools[id];
      if (!tool) { return; }
      var a = FP.toolLink(tool, 'fp-dm-act', true, 'sig-ico--16');
      if (!tool.external) { a.setAttribute('data-fp-pick', pick); }
      list.appendChild(el('li', null, [a]));
    });
    return list.children.length ? list : null;
  }
  function fact(label, value, mono, cls) {
    return el('div', {class: 'fp-dm-fact'}, [el('dt', {text: label}), el('dd', {class: (mono ? 'sig-mono' : '') + (cls ? ' ' + cls : ''), text: value})]);
  }
  function domainCard(s) {
    var id = 'fp-dm-' + s.domain.replace(/[^a-z0-9]/g, '-');
    var ssl = s.kind === 'parked' ? '' : s.ssl === 'ok' ? t('dm_ssl_ok', {date: s.until || '—'}) : s.ssl === 'expired' ? t('dm_ssl_expired') : t('dm_ssl_none');
    var facts = el('dl', {class: 'fp-dm-facts'}, [fact(t('dm_root'), s.root || '—', true)]);
    if (s.kind !== 'parked') {
      facts.appendChild(fact(t('dm_ssl'), ssl, false, s.ssl === 'ok' ? 'fp-dm-good' : s.ssl === 'expired' ? 'fp-dm-bad' : 'fp-muted'));
      facts.appendChild(fact(t('dm_php'), s.php || '—', true));
    }
    return el('section', {class: 'fp-dm-card', 'aria-labelledby': id, 'data-fp-dm': s.domain}, [
      el('div', {class: 'fp-dm-card-head'}, [UI.icon(FP.ui, 'ui_link', 'sig-ico--24'), el('div', {class: 'fp-dm-card-name'}, [
        el('h2', {class: 'fp-dm-card-title', id: id, text: s.domain}),
        el('span', {class: 'fp-dm-kind', text: s.kind === 'parked' ? t('dm_kind_parked', {domain: s.of}) : t('dm_kind_' + s.kind)})])]),
      facts,
      actionLinks(s.kind === 'parked' ? ['dns'] : DM_ACTIONS, s.domain, t('dm_actions_for', {domain: s.domain}))]);
  }
  function accountCard(a) {
    var id = 'fp-dm-acct-' + a.username;
    return el('section', {class: 'fp-dm-card', 'aria-labelledby': id, 'data-fp-dm': a.username}, [
      el('div', {class: 'fp-dm-card-head'}, [UI.icon(FP.ui, 'ui_user', 'sig-ico--24'), el('div', {class: 'fp-dm-card-name'}, [
        el('h2', {class: 'fp-dm-card-title', id: id, text: a.domain || a.username}),
        el('span', {class: 'fp-dm-kind sig-mono', text: a.username})])]),
      el('dl', {class: 'fp-dm-facts'}, [fact(t('row_plan'), a.package || '—'), fact(t('dm_account_status'),
        a.status === 'suspended' ? t('status_suspended') : a.status === 'creating' ? t('status_creating') : t('status_active'), false, a.status === 'suspended' ? 'fp-dm-bad' : '')]),
      actionLinks(DM_ADMIN_ACTIONS, a.username, t('dm_actions_for', {domain: a.username}))]);
  }
  function domainsHome() {
    var body = FP.frame({title: t(admin ? 'dm_title_admin' : 'dm_title_user'), desc: t(admin ? 'dm_desc_admin' : 'dm_desc_user')});
    var list = el('div', {class: 'fp-dm-list', 'aria-live': 'polite'}, [el('p', {class: 'fp-muted', text: t('loading')})]);
    var usage = el('ul', {class: 'sig-rows fp-dm-usage'}, [el('li', {class: 'sig-row fp-muted', text: t('loading')})]);
    var quick = el('ul', {class: 'fp-dm-quick'});
    DM_QUICK.forEach(function (id) { if (FP.tools[id]) { quick.appendChild(el('li', null, [FP.toolLink(FP.tools[id], 'fp-fn', true, 'sig-ico--16')])); } });
    var side = el('aside', {class: 'fp-dm-side', 'aria-label': t(admin ? 'server_card' : 'dm_usage')}, [
      el('section', {class: 'fp-dm-box', 'aria-labelledby': 'fp-dm-usage-h'}, [el('h2', {class: 'fp-dm-box-title', id: 'fp-dm-usage-h', text: t(admin ? 'server_card' : 'dm_usage')}), usage]),
      quick.children.length ? el('section', {class: 'fp-dm-box', 'aria-labelledby': 'fp-dm-quick-h'}, [el('h2', {class: 'fp-dm-box-title', id: 'fp-dm-quick-h', text: t('dm_quick')}), quick]) : null]);
    body.appendChild(el('div', {class: 'fp-dm-home'}, [list, side]));
    if (FP.tour) { FP.tour(body); }
    var none = function (text, toolId) {
      list.textContent = '';
      var tool = toolId ? FP.tools[toolId] : null;
      list.appendChild(FP.empty(text, '', tool ? el('a', {class: 'sig-btn sig-btn--secondary', href: tool.href, text: admin ? tool.label : t('dm_add')}) : null));
    };
    if (admin) {
      FP.call('get', 'accounts').then(function (r) {
        if (!document.body.contains(list)) { return; }
        var accts = (r && Array.isArray(r.accounts) ? r.accounts : []).filter(function (a) { return a && USER_RE.test(str(a.username)); }).map(function (a) {
          return {username: a.username, domain: DM_RE.test(str(a.domain)) ? a.domain : '', package: typeof a.package === 'string' ? a.package.slice(0, 64) : '', status: a.status};
        });
        if (!accts.length) { none(t('dm_none_admin'), 'account_new'); return; }
        list.textContent = '';
        accts.forEach(function (a) { list.appendChild(accountCard(a)); });
      }, function () { if (document.body.contains(list)) { list.textContent = ''; list.appendChild(FP.empty(t('dm_failed'), '')); } });
      FP.summary().then(function (sum) {
        if (document.body.contains(usage)) { fill(usage, sum.status && typeof sum.status === 'object' ? statusRows(sum.version, sum.status) : basicRows(sum)); }
      }, function () { if (document.body.contains(usage)) { unavailable(usage); } });
      return;
    }
    FP.call('get', 'domains', undefined, FP.account()).then(function (r) {
      if (!document.body.contains(list)) { return; }
      var sites = dmSites(r);
      if (!sites.length) { none(t('dm_none'), 'domains'); return; }
      list.textContent = '';
      sites.forEach(function (x) { list.appendChild(domainCard(x)); });
    }, function () { if (document.body.contains(list)) { list.textContent = ''; list.appendChild(FP.empty(t('dm_failed'), '')); } });
    FP.call('get', 'usage', undefined, FP.account()).then(function (u) {
      if (!document.body.contains(usage)) { return; }
      var notice = bandwidthNotice(u);
      if (notice) { body.insertBefore(notice, body.firstChild); }
      var part = function (k) { return u[k] && typeof u[k] === 'object' ? u[k] : {}; };
      fill(usage, [meterRow(t('usage_disk'), part('disk_bytes').used, part('disk_bytes').limit, size),
        meterRow(t('usage_bandwidth'), part('bandwidth_bytes').used, part('bandwidth_bytes').limit, size),
        meterRow(t('usage_mailboxes'), part('email_accounts').used, part('email_accounts').limit, count),
        meterRow(t('usage_databases'), part('databases').used, part('databases').limit, count)]);
    }, function () { if (document.body.contains(usage)) { unavailable(usage); } });
  }

  FP.view('home', function (r) {
    if (FP.theme && FP.theme.domains()) { domainsHome(r); return; }
    if (FP.theme && FP.theme.cards()) { cardsHome(r); return; }
    if (FP.theme && FP.theme.classic()) { classicHome(r); return; }
    (admin ? adminHome : userHome)(r);
  });

  /* for the Service status page (fp-server.js) */
  FP.home = {statusRows: statusRows, meterRow: meterRow, row: row, infoCard: infoCard, fill: fill, count: count};
})();

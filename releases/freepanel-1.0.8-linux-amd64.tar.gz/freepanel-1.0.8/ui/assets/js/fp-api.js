/* freePanel API client for the daemon's HTTP API, version 1 (docs/api.md). Every path the panels use is in PATHS. JSON in and out, same-origin cookie session, the session's CSRF token on every
   call that changes something. A file (a Blob) as the body is sent as it is, with its own type. A call resolves with the reply object or rejects with
   {status, code, message, retryAfter}; message is always plain text for the page to show.
   Declares only window.FPAPI. */
(function () {
  'use strict';
  var PATHS = {
    health: '/api/v1/health',
    setup: '/api/v1/setup',
    login: '/api/v1/auth/login',
    twoFactorLogin: '/api/v1/auth/login/two-factor',
    loginUnlock: '/api/v1/auth/login/unlock',
    ssoOffer: '/api/v1/auth/oidc',
    ssoExchange: '/api/v1/auth/oidc/exchange',
    ssoLink: '/api/v1/auth/oidc/link',
    ssoProvider: '/api/v1/server/oidc',
    ssoTest: '/api/v1/server/oidc/test',
    forgot: '/api/v1/auth/password/forgot',
    reset: '/api/v1/auth/password/reset',
    supportSignin: '/api/v1/auth/support-signin',
    accountSupportSessions: '/api/v1/accounts/{name}/support-sessions',
    accountSupportSignin: '/api/v1/accounts/{name}/support-signin',
    session: '/api/v1/auth/session',
    sessions: '/api/v1/auth/sessions',
    sessionEnd: '/api/v1/auth/sessions/{id}',
    history: '/api/v1/auth/history?limit=50',
    notices: '/api/v1/auth/notifications',
    language: '/api/v1/auth/language',
    panelTheme: '/api/v1/auth/theme',
    serverTheme: '/api/v1/server/panel-theme',
    languages: '/api/v1/languages',
    serverInfo: '/api/v1/accounts/{name}/server-info',
    logout: '/api/v1/auth/logout',
    password: '/api/v1/auth/password',
    email: '/api/v1/auth/email',
    accounts: '/api/v1/accounts',
    accountsBulk: '/api/v1/accounts/bulk',
    accountsOverQuota: '/api/v1/accounts/over-quota?threshold={threshold}',
    loginPasswordChange: '/api/v1/logins/{name}/password-change',
    announcements: '/api/v1/announcements',
    starterFiles: '/api/v1/server/starter-files',
    starterFile: '/api/v1/server/starter-files/file?path={path}',
    starterFileDelete: '/api/v1/server/starter-files?path={path}',
    serverWelcome: '/api/v1/server/welcome',
    suspendedPage: '/api/v1/web/suspended-page',
    sitePage: '/api/v1/web/site-pages/{page}',
    account: '/api/v1/accounts/{name}',
    usage: '/api/v1/accounts/{name}/usage',
    serverStatus: '/api/v1/server/status',
    redis: '/api/v1/accounts/{name}/redis',
    memcached: '/api/v1/accounts/{name}/memcached',
    dbConfig: '/api/v1/database-servers/{id}/config',
    serverProfile: '/api/v1/server/profile',
    serverServices: '/api/v1/server/services',
    serviceAction: '/api/v1/server/services/action',
    serverServiceMemory: '/api/v1/server/service-memory',
    serverToolAccess: '/api/v1/server/tool-access',
    serverHostAccess: '/api/v1/server/host-access',
    dbMap: '/api/v1/databases/map?account={account}&engine={engine}',
    dbMapRepair: '/api/v1/databases/map/repair',
    mailArchive: '/api/v1/accounts/{name}/email/mailboxes/{address}/archive',
    mailHeldBox: '/api/v1/accounts/{name}/email/mailboxes/{address}/held-box',
    mailHeld: '/api/v1/accounts/{name}/email/mailboxes/{address}/held',
    mailHeldRelease: '/api/v1/accounts/{name}/email/mailboxes/{address}/held/release',
    mailHeldDelete: '/api/v1/accounts/{name}/email/mailboxes/{address}/held/delete',
    serverIps: '/api/v1/server/ips',
    serverPublicIp: '/api/v1/server/public-ip',
    serverIpAdd: '/api/v1/server/ips',
    ipMigrationPlan: '/api/v1/server/ip-migration/plan',
    ipMigration: '/api/v1/server/ip-migration',
    ipv6Ranges: '/api/v1/server/ipv6-ranges',
    ipv6Range: '/api/v1/server/ipv6-ranges/{id}',
    accountIPv6: '/api/v1/server/ipv6-ranges/accounts/{name}',
    serverIp: '/api/v1/server/ips/{address}',
    supportAccess: '/api/v1/server/support-access',
    serverReservedIps: '/api/v1/server/reserved-ips',
    acctIp: '/api/v1/accounts/{name}/ip',
    acctIpSet: '/api/v1/accounts/{name}/ip',
    acctIpMail: '/api/v1/accounts/{name}/ip/mail',
    serverDedicatedMail: '/api/v1/server/dedicated-ip-mail',
    serverHostname: '/api/v1/server/hostname',
    hostnamePlan: '/api/v1/server/hostname/plan',
    hostnameRevert: '/api/v1/server/hostname/revert',
    dnsHostname: '/api/v1/dns/hostname',
    serverTime: '/api/v1/server/time',
    serverLanguages: '/api/v1/server/languages',
    serverTimeZones: '/api/v1/server/time/zones',
    serverTimeZone: '/api/v1/server/time/zone',
    serverTimeSync: '/api/v1/server/time/sync',
    serverReboot: '/api/v1/server/reboot',
    branding: '/api/v1/branding',
    brandingLogo: '/api/v1/branding/logo',
    audit: '/api/v1/audit?limit=100',
    auditBefore: '/api/v1/audit?limit=100&before={before}',
    serverLogs: '/api/v1/server/logs',
    serverLog: '/api/v1/server/logs/{id}?lines={lines}{&match}',
    plugins: '/api/v1/plugins',
    pluginKeys: '/api/v1/plugins/keys',
    pluginKey: '/api/v1/plugins/keys/{fingerprint}',
    plugin: '/api/v1/plugins/{id}',
    pluginApprove: '/api/v1/plugins/{id}/approve',
    pluginEnable: '/api/v1/plugins/{id}/enable',
    pluginDisable: '/api/v1/plugins/{id}/disable',
    pluginRun: '/api/v1/plugins/{id}/run',
    apiReference: '/api/v1/server/api-reference',
    smon: '/api/v1/accounts/{name}/site-monitor',
    smonSite: '/api/v1/accounts/{name}/site-monitor/{domain}',
    smonCheck: '/api/v1/accounts/{name}/site-monitor/{domain}/check',
    smonReport: '/api/v1/accounts/{name}/site-monitor/{domain}/report',
    smonOverview: '/api/v1/site-monitor',
    smonSettings: '/api/v1/site-monitor/settings',
    apiRoutes: '/api/v1/auth/api-routes',
    tfSetup: '/api/v1/auth/two-factor/setup',
    tfEnable: '/api/v1/auth/two-factor/enable',
    tfDisable: '/api/v1/auth/two-factor/disable',
    tfCodes: '/api/v1/auth/two-factor/recovery-codes',
    twoFactorPolicy: '/api/v1/two-factor-policy',
    /* Linked servers (fp-cluster.js) */
    clusterKeys: '/api/v1/cluster/keys',
    clusterKey: '/api/v1/cluster/keys/{id}',
    clusterNodes: '/api/v1/cluster/nodes',
    clusterProbe: '/api/v1/cluster/nodes/probe',
    clusterNode: '/api/v1/cluster/nodes/{id}',
    clusterNodeStatus: '/api/v1/cluster/nodes/{id}/status',
    clusterNodeAccounts: '/api/v1/cluster/nodes/{id}/accounts',
    clusterNodeTransfer: '/api/v1/cluster/nodes/{id}/transfers',
    clusterNodeSettings: '/api/v1/cluster/nodes/{id}/settings',
    clusterSettingsReceive: '/api/v1/cluster/settings-receive',
    ssh: '/api/v1/server/ssh',
    sshSettings: '/api/v1/server/ssh',
    sshPort: '/api/v1/server/ssh/port',
    sshPortConfirm: '/api/v1/server/ssh/port/confirm',
    apiTokens: '/api/v1/api-tokens',
    apiToken: '/api/v1/api-tokens/{id}',
    securityCheck: '/api/v1/server/security-check',
    loginProtectionInstall: '/api/v1/server/login-protection/install',
    cron: '/api/v1/accounts/{name}/cron',
    cronEmail: '/api/v1/accounts/{name}/cron/email',
    cronTasks: '/api/v1/accounts/{name}/cron/tasks',
    cronTask: '/api/v1/accounts/{name}/cron/tasks/{id}',
    mysql: '/api/v1/accounts/{name}/mysql',
    dbServers: '/api/v1/database-servers',
    dbServer: '/api/v1/database-servers/{id}',
    dbServerProcs: '/api/v1/database-servers/{id}/processes',
    dbServerProcKill: '/api/v1/database-servers/{id}/processes/{pid}/kill',
    dbServerTest: '/api/v1/database-servers/{id}/test',
    dbAdminPw: '/api/v1/database-servers/{id}/admin-password',
    dbVersion: '/api/v1/database-servers/{id}/version',
    dbUpgrade: '/api/v1/database-servers/{id}/upgrade',
    allDbs: '/api/v1/databases?limit={limit}&offset={offset}{&engine}{&account}{&q}',
    mysqlDatabases: '/api/v1/accounts/{name}/mysql/databases',
    mysqlDatabase: '/api/v1/accounts/{name}/mysql/databases/{db}',
    mysqlUsers: '/api/v1/accounts/{name}/mysql/users',
    mysqlUser: '/api/v1/accounts/{name}/mysql/users/{user}',
    mysqlPassword: '/api/v1/accounts/{name}/mysql/users/{user}/password',
    mysqlGrant: '/api/v1/accounts/{name}/mysql/databases/{db}/users/{user}',
    mysqlSignin: '/api/v1/accounts/{name}/mysql/signin',
    mysqlSetup: '/api/v1/accounts/{name}/mysql/setup',
    acctRemoteHosts: '/api/v1/accounts/{name}/mysql/remote-hosts',
    acctRemoteHost: '/api/v1/accounts/{name}/mysql/remote-hosts?host={host}',
    remoteDatabases: '/api/v1/server/remote-databases',
    remoteDatabasesMysql: '/api/v1/server/remote-databases/mysql',
    mysqlMaintenance: '/api/v1/accounts/{name}/mysql/databases/{db}/maintenance',
    mongodb: '/api/v1/accounts/{name}/mongodb',
    mongodbDatabases: '/api/v1/accounts/{name}/mongodb/databases',
    mongodbDatabase: '/api/v1/accounts/{name}/mongodb/databases/{db}',
    mongodbUsers: '/api/v1/accounts/{name}/mongodb/users',
    mongodbUser: '/api/v1/accounts/{name}/mongodb/users/{user}',
    mongodbPassword: '/api/v1/accounts/{name}/mongodb/users/{user}/password',
    mongodbGrant: '/api/v1/accounts/{name}/mongodb/databases/{db}/users/{user}',
    mongodbSignin: '/api/v1/accounts/{name}/mongodb/signin',
    mongoServer: '/api/v1/server/mongodb',
    mongoServerVersions: '/api/v1/server/mongodb/versions',
    mongoServerInstall: '/api/v1/server/mongodb/install',
    mongoServerRemove: '/api/v1/server/mongodb/remove',
    postgres: '/api/v1/accounts/{name}/postgres',
    postgresDatabases: '/api/v1/accounts/{name}/postgres/databases',
    postgresDatabase: '/api/v1/accounts/{name}/postgres/databases/{db}',
    postgresUsers: '/api/v1/accounts/{name}/postgres/users',
    postgresUser: '/api/v1/accounts/{name}/postgres/users/{user}',
    postgresPassword: '/api/v1/accounts/{name}/postgres/users/{user}/password',
    postgresGrant: '/api/v1/accounts/{name}/postgres/databases/{db}/users/{user}',
    postgresSignin: '/api/v1/accounts/{name}/postgres/signin',
    postgresSetup: '/api/v1/accounts/{name}/postgres/setup',
    postgresMaintenance: '/api/v1/accounts/{name}/postgres/databases/{db}/maintenance',
    dnsZones: '/api/v1/dns/zones',
    zoneIpv6: '/api/v1/accounts/{name}/dns/zones/{zone}/ipv6',
    dnsIpv6: '/api/v1/dns/ipv6',
    dnsIpv6Zones: '/api/v1/dns/ipv6/zones',
    dnsLookup: '/api/v1/dns/lookup?name={name}&type={type}&source={source}',
    reverse: '/api/v1/dns/reverse',
    serverResolver: '/api/v1/server/resolver',
    reverseIp: '/api/v1/dns/reverse/{ip}',
    dnsCluster: '/api/v1/dns/cluster',
    dnsClusterSecondaries: '/api/v1/dns/cluster/secondaries',
    dnsClusterPrimaries: '/api/v1/dns/cluster/primaries',
    dnsClusterPrimaryAllow: '/api/v1/dns/cluster/primaries/{id}/allow',
    dnsClusterPeer: '/api/v1/dns/cluster/peers/{id}',
    dnsClusterPeerKey: '/api/v1/dns/cluster/peers/{id}/key',
    dnsClusterSettings: '/api/v1/dns/cluster/settings',
    dnsClusterNotify: '/api/v1/dns/cluster/notify',
    dnsClusterSync: '/api/v1/dns/cluster/sync',
    resourceLimits: '/api/v1/server/resource-limits',
    acctResourceLimits: '/api/v1/accounts/{name}/resource-limits',
    serverContacts: '/api/v1/server/contacts',
    serverNotifications: '/api/v1/server/notifications',
    serverNotificationsCheck: '/api/v1/server/notifications/check',
    serverContactsTest: '/api/v1/server/contacts/test',
    dnsTemplate: '/api/v1/dns/template',
    serverTls: '/api/v1/server/tls',
    domainPreview: '/api/v1/accounts/{name}/domains/{domain}/preview',
    ddnsNames: '/api/v1/accounts/{name}/dns/ddns',
    ddnsName: '/api/v1/accounts/{name}/dns/ddns/{host}',
    ddnsToken: '/api/v1/accounts/{name}/dns/ddns/{host}/token',
    accountZones: '/api/v1/accounts/{name}/dns/zones',
    accountZone: '/api/v1/accounts/{name}/dns/zones/{zone}',
    acctDnssec: '/api/v1/accounts/{name}/dns/zones/{zone}/dnssec',
    acctDnssecOff: '/api/v1/accounts/{name}/dns/zones/{zone}/dnssec?force=true',
    acctDnssecRollover: '/api/v1/accounts/{name}/dns/zones/{zone}/dnssec/rollover',
    mailAuth: '/api/v1/accounts/{name}/dns/zones/{zone}/mail-auth',
    mailAuthFix: '/api/v1/accounts/{name}/dns/zones/{zone}/mail-auth/fix',
    domains: '/api/v1/accounts/{name}/domains',
    sitePub: '/api/v1/accounts/{name}/site-publisher',
    sitePubSite: '/api/v1/accounts/{name}/site-publisher/{domain}',
    domain: '/api/v1/accounts/{name}/domains/{domain}',
    protectedFolders: '/api/v1/accounts/{name}/protected-folders',
    protectedLogins: '/api/v1/accounts/{name}/protected-folders/logins',
    protectedLogin: '/api/v1/accounts/{name}/protected-folders/logins?folder={folder}&login={login}',
    domainProof: '/api/v1/accounts/{name}/domain-proof',
    domainCheck: '/api/v1/accounts/{name}/domain-proof/{domain}/check',
    proofPending: '/api/v1/domain-proof/pending',
    proofApprove: '/api/v1/domain-proof/{domain}/approve',
    proofSettings: '/api/v1/domain-proof/settings',
    statsBandwidth: '/api/v1/accounts/{name}/stats/bandwidth',
    statsBandwidthSite: '/api/v1/accounts/{name}/stats/bandwidth?domain={domain}',
    statsVisitors: '/api/v1/accounts/{name}/stats/visitors?domain={domain}',
    statsErrors: '/api/v1/accounts/{name}/stats/errors',
    statsReport: '/api/v1/accounts/{name}/stats/report?domain={domain}',
    statsHistory: '/api/v1/accounts/{name}/stats/history?domain={domain}{&from}{&to}',
    ftpAccounts: '/api/v1/accounts/{name}/ftp',
    ftpLogins: '/api/v1/accounts/{name}/ftp/logins',
    ftpLogin: '/api/v1/accounts/{name}/ftp/logins/{login}',
    ftpSessions: '/api/v1/accounts/{name}/ftp/sessions',
    ftpSession: '/api/v1/accounts/{name}/ftp/sessions/{id}',
    anonFtp: '/api/v1/accounts/{name}/anonymous-ftp',
    anonFtpServer: '/api/v1/ftp/anonymous',
    ftpTraffic: '/api/v1/accounts/{name}/ftp/traffic?days={days}',
    ftpLog: '/api/v1/accounts/{name}/ftp/log?days={days}',
    ftpServerSettings: '/api/v1/server/ftp/settings',
    webdiskServer: '/api/v1/server/webdisk',
    forwarderImport: '/api/v1/accounts/{name}/email/forwarders/import',
    imapPopSettings: '/api/v1/email/server-settings/imap-pop',
    domainForwards: '/api/v1/web/domain-forwards',
    dnsBulk: '/api/v1/dns/bulk',
    dnsNameservers: '/api/v1/dns/nameservers',
    dnsNameserversPublic: '/api/v1/dns/nameservers?check=public',
    dnsZoneReset: '/api/v1/accounts/{name}/dns/zones/{zone}/reset',
    resUsage: '/api/v1/accounts/{name}/resources?hours={hours}',
    resNow: '/api/v1/accounts/{name}/resources/now',
    resTop: '/api/v1/resources/top?hours={hours}&by={by}&limit={limit}',
    sitePHP: '/api/v1/accounts/{name}/domains/{domain}/php',
    siteRedirects: '/api/v1/accounts/{name}/domains/{domain}/redirects',
    siteRedirectsCheck: '/api/v1/accounts/{name}/domains/{domain}/redirects/check',
    siteRedirectsTest: '/api/v1/accounts/{name}/domains/{domain}/redirects/test',
    siteCanonical: '/api/v1/accounts/{name}/domains/{domain}/canonical',
    siteSEO: '/api/v1/accounts/{name}/domains/{domain}/seo',
    siteSEORobots: '/api/v1/accounts/{name}/domains/{domain}/seo/robots',
    siteSEOSitemap: '/api/v1/accounts/{name}/domains/{domain}/seo/sitemap',
    siteCatchall: '/api/v1/accounts/{name}/domains/{domain}/catchall',
    siteCertificate: '/api/v1/accounts/{name}/domains/{domain}/certificate',
    webApps: '/api/v1/web/apps',
    webAppsCheck: '/api/v1/web/apps/check',
    apps: '/api/v1/accounts/{name}/apps',
    appInstall: '/api/v1/accounts/{name}/apps/{app}/install',
    appInstalls: '/api/v1/accounts/{name}/apps/installs',
    appUninstall: '/api/v1/accounts/{name}/apps/installs/{id}?remove_files={files}&remove_database={db}',
    appHosting: '/api/v1/accounts/{name}/app-hosting',
    appHostingApp: '/api/v1/accounts/{name}/app-hosting/{app}',
    appHostingControl: '/api/v1/accounts/{name}/app-hosting/{app}/control',
    appHostingLogs: '/api/v1/accounts/{name}/app-hosting/{app}/logs?lines={lines}',
    appRuntimes: '/api/v1/web/app-runtimes',
    appPorts: '/api/v1/web/app-ports',
    webNode: '/api/v1/web/node',
    webNodeCheck: '/api/v1/web/node/check',
    webNodeInstall: '/api/v1/web/node/install',
    webNodeInstallOf: '/api/v1/web/node/{major}/install',
    webNodeOf: '/api/v1/web/node/{major}',
    wpStatus: '/api/v1/accounts/{name}/apps/installs/{id}/status',
    wpSettings: '/api/v1/accounts/{name}/apps/installs/{id}/settings',
    wpUpdate: '/api/v1/accounts/{name}/apps/installs/{id}/update',
    appAuto: '/api/v1/accounts/{name}/apps/installs/{id}/auto_update',
    wpUndo: '/api/v1/accounts/{name}/apps/installs/{id}/undo',
    wpScan: '/api/v1/accounts/{name}/apps/installs/{id}/scan',
    siteHTTPS: '/api/v1/accounts/{name}/domains/{domain}/https',
    sslKeys: '/api/v1/accounts/{name}/ssl/keys',
    sslKeyNew: '/api/v1/accounts/{name}/ssl/keys',
    sslKey: '/api/v1/accounts/{name}/ssl/keys/{id}',
    sslCsrs: '/api/v1/accounts/{name}/ssl/csrs',
    sslCsr: '/api/v1/accounts/{name}/ssl/csrs/{id}',
    certVendorOffer: '/api/v1/accounts/{name}/ssl/vendor',
    certVendorApprovers: '/api/v1/accounts/{name}/ssl/vendor/approver-emails?domain={domain}&product={product}',
    certOrders: '/api/v1/accounts/{name}/ssl/orders',
    certOrder: '/api/v1/accounts/{name}/ssl/orders/{id}',
    certOrderCheck: '/api/v1/accounts/{name}/ssl/orders/{id}/check',
    certOrderReissue: '/api/v1/accounts/{name}/ssl/orders/{id}/reissue',
    certOrderCancel: '/api/v1/accounts/{name}/ssl/orders/{id}/cancel',
    certVendors: '/api/v1/web/cert-vendors',
    certVendor: '/api/v1/web/cert-vendors/{vendor}',
    certVendorTest: '/api/v1/web/cert-vendors/{vendor}/test',
    certVendorProducts: '/api/v1/web/cert-vendors/{vendor}/products?fresh={fresh}',
    certOrdersAll: '/api/v1/web/cert-orders',
    webCertificates: '/api/v1/web/certificates?limit={limit}&offset={offset}{&account}{&source}{&expired}{&expires_within_days}',
    phpVersions: '/api/v1/web/php-versions',
    phpSettings: '/api/v1/accounts/{name}/domains/{domain}/php/settings',
    svcCerts: '/api/v1/server/certificates',
    svcCertsRenew: '/api/v1/server/certificates/renew',
    webAutossl: '/api/v1/web/autossl',
    webAutosslTerms: '/api/v1/web/autossl/terms',
    webAutosslRun: '/api/v1/web/autossl/run',
    license: '/api/v1/license',
    licenseKey: '/api/v1/license/key',
    licenseCheck: '/api/v1/license/check',
    licenseServers: '/api/v1/license/servers',
    licenseRelease: '/api/v1/license/release',
    licenseClaim: '/api/v1/license/claim',
    siteRules: '/api/v1/accounts/{name}/domains/{domain}/rules',
    siteRule: '/api/v1/accounts/{name}/domains/{domain}/rules/{rule}',
    siteListing: '/api/v1/accounts/{name}/domains/{domain}/rules/listing?path={path}',
    backups: '/api/v1/backups',
    demoLogins: '/api/v1/demo-logins',
    demoLogin: '/api/v1/demo-logins/{name}',
    demoLoginReset: '/api/v1/demo-logins/{name}/reset',
    backupStatus: '/api/v1/backups/status',
    backupSettings: '/api/v1/backups/settings',
    backupIncremental: '/api/v1/backups/incremental',
    backupRun: '/api/v1/backups/run',
    backupRemote: '/api/v1/backups/remote',
    backupDestinations: '/api/v1/backups/destinations',
    backupDestination: '/api/v1/backups/destinations/{id}',
    backupDestinationTest: '/api/v1/backups/destinations/{id}/test',
    backupDestinationsTest: '/api/v1/backups/destinations/test',
    backupDestinationsProbe: '/api/v1/backups/destinations/probe',
    accountBackup: '/api/v1/accounts/{name}/backups',
    backupRestore: '/api/v1/accounts/{name}/backups/{archive}/restore',
    ownBackups: '/api/v1/accounts/{name}/backups',
    backupContents: '/api/v1/accounts/{name}/backups/{archive}/contents',
    backupContentsAt: '/api/v1/accounts/{name}/backups/{archive}/contents?path={path}',
    backupDownload: '/api/v1/accounts/{name}/backups/download',
    backupUpload: '/api/v1/accounts/{name}/backups/upload?kind=home',
    backupUploadCancel: '/api/v1/accounts/{name}/backups/upload',
    git: '/api/v1/accounts/{name}/git',
    gitRepos: '/api/v1/accounts/{name}/git/repositories',
    libraries: '/api/v1/accounts/{name}/libraries',
    library: '/api/v1/accounts/{name}/libraries/{kind}/{lib}',
    serverLibraries: '/api/v1/server/libraries',
    serverLibrary: '/api/v1/server/libraries/{kind}/{lib}',
    composer: '/api/v1/accounts/{name}/composer',
    composerRuns: '/api/v1/accounts/{name}/composer/runs',
    composerLog: '/api/v1/accounts/{name}/composer/runs/{id}/log',
    gitRepo: '/api/v1/accounts/{name}/git/repositories/{repo}',
    gitRepoFiles: '/api/v1/accounts/{name}/git/repositories/{repo}?files=1',
    gitUpdate: '/api/v1/accounts/{name}/git/repositories/{repo}/update',
    gitDeploy: '/api/v1/accounts/{name}/git/repositories/{repo}/deploy',
    terminal: '/api/v1/accounts/{name}/terminal',
    terminalOne: '/api/v1/accounts/{name}/terminal/{id}',
    terminalOutput: '/api/v1/accounts/{name}/terminal/{id}/output?after={after}&wait={wait}',
    terminalInput: '/api/v1/accounts/{name}/terminal/{id}/input',
    terminalResize: '/api/v1/accounts/{name}/terminal/{id}/resize',
    rootTerminal: '/api/v1/server/root-terminal',
    rootTerminalOne: '/api/v1/server/root-terminal/{id}',
    rootTerminalOutput: '/api/v1/server/root-terminal/{id}/output?after={after}&wait={wait}',
    rootTerminalInput: '/api/v1/server/root-terminal/{id}/input',
    rootTerminalResize: '/api/v1/server/root-terminal/{id}/resize',
    gitBranches: '/api/v1/accounts/{name}/git/repositories/{repo}/branches',
    gitLog: '/api/v1/accounts/{name}/git/repositories/{repo}/log?limit={limit}&skip={skip}{&ref}',
    gitCommit: '/api/v1/accounts/{name}/git/repositories/{repo}/commit?ref={ref}',
    gitTree: '/api/v1/accounts/{name}/git/repositories/{repo}/tree?ref={ref}{&path}',
    gitFile: '/api/v1/accounts/{name}/git/repositories/{repo}/file?ref={ref}&path={path}',
    webdisk: '/api/v1/accounts/{name}/webdisk',
    webdiskAdd: '/api/v1/accounts/{name}/webdisk/logins',
    webdiskLogin: '/api/v1/accounts/{name}/webdisk/logins/{login}',
    statsLogs: '/api/v1/accounts/{name}/stats/logs',
    mail: '/api/v1/accounts/{name}/email',
    mailUsage: '/api/v1/accounts/{name}/email/usage?limit={limit}&offset={offset}',
    mailboxUsage: '/api/v1/accounts/{name}/email/mailboxes/{address}/usage',
    spamFolder: '/api/v1/accounts/{name}/email/spam-folder',
    spamFolderEmpty: '/api/v1/accounts/{name}/email/spam-folder/empty',
    emailAuth: '/api/v1/accounts/{name}/email/authentication/{domain}',
    emailAuthDmarc: '/api/v1/accounts/{name}/email/authentication/{domain}/dmarc',
    emailAuthSts: '/api/v1/accounts/{name}/email/authentication/{domain}/mta-sts',
    mailImport: '/api/v1/accounts/{name}/email/mailboxes/import',
    mailDelivery: '/api/v1/accounts/{name}/email/delivery?limit={limit}{&q}{&from}{&to}{&status}',
    mailRouting: '/api/v1/accounts/{name}/email/routing/{domain}',
    davList: '/api/v1/accounts/{name}/email/calendars',
    davBox: '/api/v1/accounts/{name}/email/calendars/{address}',
    davItem: '/api/v1/accounts/{name}/email/calendars/{address}/{id}',
    davShare: '/api/v1/accounts/{name}/email/calendars/{address}/{id}/shares/{to}',
    mailGreylist: '/api/v1/accounts/{name}/email/greylisting',
    mailGreylistDomain: '/api/v1/accounts/{name}/email/greylisting/{domain}',
    mailRepair: '/api/v1/accounts/{name}/email/repair',
    mailDeliverability: '/api/v1/email/deliverability?limit={limit}&offset={offset}{&account}{&problems}',
    mailDeliverabilityRepair: '/api/v1/email/deliverability/repair',
    mailTrace: '/api/v1/email/trace?address={address}',
    mailGreylistServer: '/api/v1/email/greylisting',
    mailLimit: '/api/v1/accounts/{name}/email/limit',
    mailboxes: '/api/v1/accounts/{name}/email/mailboxes',
    mailClient: '/api/v1/accounts/{name}/email/mailboxes/{address}/client',
    mailbox: '/api/v1/accounts/{name}/email/mailboxes/{address}',
    mailboxFilters: '/api/v1/accounts/{name}/email/mailboxes/{address}/filters',
    autoresponder: '/api/v1/accounts/{name}/email/mailboxes/{address}/autoresponder',
    forwarders: '/api/v1/accounts/{name}/email/forwarders',
    forwarder: '/api/v1/accounts/{name}/email/forwarders/{address}',
    mailDefault: '/api/v1/accounts/{name}/email/defaults/{domain}',
    mailLists: '/api/v1/accounts/{name}/email/lists',
    mailList: '/api/v1/accounts/{name}/email/lists/{address}',
    mailListMembers: '/api/v1/accounts/{name}/email/lists/{address}/members',
    mailFilters: '/api/v1/accounts/{name}/email/filters',
    mailRefused: '/api/v1/email/refused',
    mailQueue: '/api/v1/email/queue?limit={limit}&offset={offset}{&queue}{&q}',
    mailQueueMessage: '/api/v1/email/queue/{id}',
    mailQueueBody: '/api/v1/email/queue/{id}?body=1',
    mailDeliveryAll: '/api/v1/email/delivery?limit={limit}{&q}{&from}{&to}{&status}',
    mailQueueActions: '/api/v1/email/queue/actions',
    mailQueueRetryAll: '/api/v1/email/queue/retry-all',
    mailServerSettings: '/api/v1/email/server-settings',
    mailServerSpam: '/api/v1/email/server-spam',
    mailSmtpRestrictions: '/api/v1/email/smtp-restrictions',
    mailWelcome: '/api/v1/email/welcome',
    mailStats: '/api/v1/email/statistics?days={days}{&refresh}',
    mailBlocks: '/api/v1/email/blocks',
    mailCountries: '/api/v1/email/countries',
    mailOutIps: '/api/v1/email/outgoing-ips',
    mailSpam: '/api/v1/accounts/{name}/email/spam',
    mailSpamSenders: '/api/v1/accounts/{name}/email/spam/senders',
    packages: '/api/v1/packages',
    package: '/api/v1/packages/{name}',
    resellers: '/api/v1/resellers',
    reseller: '/api/v1/resellers/{name}',
    resellerLimits: '/api/v1/resellers/{name}/limits',
    packageFeatures: '/api/v1/packages/{name}/features',
    accountMainDomain: '/api/v1/accounts/{name}/main-domain',
    resellerUsage: '/api/v1/resellers/usage',
    resellerTemplates: '/api/v1/resellers/templates',
    resellerTemplateDelete: '/api/v1/resellers/templates?name={tname}',
    resellerTemplateApply: '/api/v1/resellers/{name}/template',
    resellerReset: '/api/v1/resellers/{name}/reset',
    serverDomains: '/api/v1/accounts/domains',
    serverDomainsKind: '/api/v1/accounts/domains?kind={kind}',
    accountsActivity: '/api/v1/accounts/activity?days={days}',
    sessionPolicy: '/api/v1/security/session-policy',
    loginDisable: '/api/v1/logins/{name}/disable',
    loginEnable: '/api/v1/logins/{name}/enable',
    loginTfReset: '/api/v1/logins/{name}/two-factor/reset',
    accountSuspend: '/api/v1/accounts/{name}/suspend',
    accountUnsuspend: '/api/v1/accounts/{name}/unsuspend',
    imports: '/api/v1/imports',
    importRead: '/api/v1/imports/{file}/read',
    importApply: '/api/v1/imports/{file}/import',
    accountShell: '/api/v1/accounts/{name}/shell',
    serverShell: '/api/v1/server/shell',
    sshKeys: '/api/v1/accounts/{name}/ssh/keys',
    rootAccess: '/api/v1/server/root-access',
    rootKeys: '/api/v1/server/root-access/keys',
    rootKeyOf: '/api/v1/server/root-access/keys?fingerprint={fingerprint}',
    rootSudo: '/api/v1/server/root-access/sudo-users',
    rootSudoOf: '/api/v1/server/root-access/sudo-users?username={username}',
    rootPassword: '/api/v1/server/root-access/password',
    rootMail: '/api/v1/server/root-mail',
    logRotation: '/api/v1/server/log-rotation',
    processKiller: '/api/v1/server/process-killer',
    processKillerRun: '/api/v1/server/process-killer/run',
    processLog: '/api/v1/server/process-log?day={day}',
    processLogLatest: '/api/v1/server/process-log',
    serverTasks: '/api/v1/server/tasks',
    maintenance: '/api/v1/server/maintenance',
    processes: '/api/v1/processes',
    processKill: '/api/v1/processes/{pid}/kill',
    sshKeyImport: '/api/v1/accounts/{name}/ssh/keys/import',
    sshKey: '/api/v1/accounts/{name}/ssh/keys/{key}',
    sshKeyPublic: '/api/v1/accounts/{name}/ssh/keys/{key}?part=public',
    sshKeyPrivate: '/api/v1/accounts/{name}/ssh/keys/{key}?part=private',
    sshKeyAuthorize: '/api/v1/accounts/{name}/ssh/keys/{key}/authorize',
    sshKeyDeauthorize: '/api/v1/accounts/{name}/ssh/keys/{key}/deauthorize',
    acctTeam: '/api/v1/accounts/{name}/team',
    acctTeamMember: '/api/v1/accounts/{name}/team/{member}',
    acctTokens: '/api/v1/accounts/{name}/api-tokens',
    acctToken: '/api/v1/accounts/{name}/api-tokens/{id}',
    files: '/api/v1/accounts/{name}/files?path={path}',
    filesHidden: '/api/v1/accounts/{name}/files?path={path}&hidden=1',
    fileContent: '/api/v1/accounts/{name}/files/content?path={path}',
    fileDownload: '/api/v1/accounts/{name}/files/download?path={path}',
    fileUpload: '/api/v1/accounts/{name}/files/upload?path={path}',
    fileUploadOver: '/api/v1/accounts/{name}/files/upload?path={path}&overwrite=1',
    fileFolder: '/api/v1/accounts/{name}/files/folder',
    fileNew: '/api/v1/accounts/{name}/files/file',
    fileRename: '/api/v1/accounts/{name}/files/rename',
    fileMove: '/api/v1/accounts/{name}/files/move',
    fileCopy: '/api/v1/accounts/{name}/files/copy',
    filePerms: '/api/v1/accounts/{name}/files/permissions',
    fileTrash: '/api/v1/accounts/{name}/files/trash',
    fileDelete: '/api/v1/accounts/{name}/files/delete',
    fileArchive: '/api/v1/accounts/{name}/files/archive',
    fileExtract: '/api/v1/accounts/{name}/files/extract',
    fileSearch: '/api/v1/accounts/{name}/files/search?path={path}&q={q}',
    fileSearchHidden: '/api/v1/accounts/{name}/files/search?path={path}&q={q}&hidden=1',
    fileUsage: '/api/v1/accounts/{name}/files/usage?path={path}',
    trash: '/api/v1/accounts/{name}/files/trash',
    trashRestore: '/api/v1/accounts/{name}/files/trash/restore',
    bandwidth: '/api/v1/bandwidth',
    bandwidthLift: '/api/v1/accounts/{name}/bandwidth/lift',
    bandwidthLiftAll: '/api/v1/bandwidth/lift',
    resellerPrivileges: '/api/v1/resellers/{name}/privileges',
    resellerBranding: '/api/v1/resellers/{name}/branding',
    resellerBrandingLogo: '/api/v1/resellers/{name}/branding/logo',
    resellerBrandingColour: '/api/v1/resellers/{name}/branding/colour',
    resellerIps: '/api/v1/resellers/{name}/ips',
    resellerNameservers: '/api/v1/resellers/{name}/nameservers',
    accountLimitsList: '/api/v1/account-limits',
    staff: '/api/v1/staff',
    staffLogin: '/api/v1/staff/{name}',
    staffRoles: '/api/v1/staff/roles',
    staffRole: '/api/v1/staff/roles/{name}',
    accountLimits: '/api/v1/accounts/{name}/limits',
    resellerPanelDomain: '/api/v1/resellers/{name}/panel-domain',
    transfers: '/api/v1/transfers',
    transferSwitch: '/api/v1/transfers/switch',
    transferSources: '/api/v1/transfers/sources',
    transferSource: '/api/v1/transfers/sources/{id}',
    transferSourceTest: '/api/v1/transfers/sources/{id}/test',
    transferSourcesTest: '/api/v1/transfers/sources/test',
    transferSourcesProbe: '/api/v1/transfers/sources/probe',
    transferAccounts: '/api/v1/transfers/sources/{id}/accounts',
    transferArchives: '/api/v1/transfers/sources/{id}/accounts?account={account}',
    transferRuns: '/api/v1/transfers/runs',
    addonConversions: '/api/v1/addon-conversions',
    addonConvertCheck: '/api/v1/addon-conversions/check',
    addonConvertRetry: '/api/v1/addon-conversions/retry',
    addonConvertUndo: '/api/v1/addon-conversions/undo',
    addonConvertDismiss: '/api/v1/addon-conversions/dismiss',
    addonConvertFree: '/api/v1/addon-conversions/free',
    transferHandoff: '/api/v1/transfers/handoffs',
    homeRoots: '/api/v1/home-roots',
    homeRootRemove: '/api/v1/home-roots/remove',
    homeMoves: '/api/v1/home-moves',
    homeMoveCheck: '/api/v1/home-moves/check',
    homeMoveRetry: '/api/v1/home-moves/retry',
    homeMoveUndo: '/api/v1/home-moves/undo',
    homeMoveDismiss: '/api/v1/home-moves/dismiss',
    security: '/api/v1/security',
    securitySettings: '/api/v1/security/settings',
    securityBans: '/api/v1/security/bans',
    securityBan: '/api/v1/security/bans?ip={ip}',
    securityAllow: '/api/v1/security/allow',
    securityAllowEntry: '/api/v1/security/allow?target={target}',
    panelSettings: '/api/v1/server/panel-settings',
    loginLimits: '/api/v1/login-limits',
    loginLimitsExempt: '/api/v1/login-limits/exempt',
    loginLimitsExemptEntry: '/api/v1/login-limits/exempt?target={target}',
    loginLimitsLocked: '/api/v1/login-limits/locked',
    loginLimitsUnlockUser: '/api/v1/login-limits/locked?user={user}',
    loginLimitsUnlockAddress: '/api/v1/login-limits/locked?address={address}',
    securityDeny: '/api/v1/security/deny',
    securityDenyEntry: '/api/v1/security/deny?target={target}',
    serverUpdates: '/api/v1/server/updates',
    serverUpdatesRefresh: '/api/v1/server/updates/refresh',
    serverUpdatesApply: '/api/v1/server/updates/apply',
    serverUpdatesStop: '/api/v1/server/updates/stop',
    serverSelfUpdate: '/api/v1/server/self-update',
    serverSelfUpdateCheck: '/api/v1/server/self-update/check',
    serverSelfUpdateStart: '/api/v1/server/self-update/start',
    eventHooks: '/api/v1/event-hooks',
    eventHook: '/api/v1/event-hooks/{id}',
    eventHookTest: '/api/v1/event-hooks/{id}/test',
    eventHookSecret: '/api/v1/event-hooks/{id}/secret',
    eventHookDeliveries: '/api/v1/event-hooks/{id}/deliveries?limit=50',
    serverUpdatesAuto: '/api/v1/server/updates/auto',
    mailStorage: '/api/v1/email/storage',
    mailStorageBoxes: '/api/v1/email/storage/mailboxes?username={username}',
    mailStoragePlan: '/api/v1/email/storage/plan',
    mailStorageConvert: '/api/v1/email/storage/convert',
    mailStorageJob: '/api/v1/email/storage/job',
    mailStorageKept: '/api/v1/email/storage/kept/{id}',
    sysPkgs: '/api/v1/server/system-packages',
    sysPkgsSearch: '/api/v1/server/system-packages/search?q={q}',
    sysPkgsInfo: '/api/v1/server/system-packages/info?name={name}',
    sysPkgsInstalled: '/api/v1/server/system-packages/installed',
    sysPkgsPreview: '/api/v1/server/system-packages/preview',
    sysPkgsInstall: '/api/v1/server/system-packages/install',
    sysPkgsRemove: '/api/v1/server/system-packages/remove',
    sysPkgsRefresh: '/api/v1/server/system-packages/refresh',
    sysPkgsJob: '/api/v1/server/system-packages/job',
    sysPkgsHistory: '/api/v1/server/system-packages/history',
    sysPkgsRebuild: '/api/v1/server/system-packages/rebuild',
    releaseNotes: '/api/v1/server/release-notes',
    webPhp: '/api/v1/web/php',
    webPhpInstall: '/api/v1/web/php/install',
    webPhpInstallOf: '/api/v1/web/php/{version}/install',
    webPhpDefault: '/api/v1/web/php/default',
    webPhpSettings: '/api/v1/web/php/{version}/settings',
    webPhpExt: '/api/v1/web/php/{version}/extensions',
    webPhpExtInstall: '/api/v1/web/php/{version}/extensions/{name}/install',
    webPhpExtJob: '/api/v1/web/php-extensions/install',
    phpExt: '/api/v1/accounts/{name}/php/extensions',
    phpTuning: '/api/v1/accounts/{name}/php-tuning',
    webApache: '/api/v1/web/apache',
    webApacheModules: '/api/v1/web/apache/modules',
    webNginx: '/api/v1/web/nginx',
    webVarnish: '/api/v1/web/varnish',
    webVarnishPurge: '/api/v1/web/varnish/purge',
    webApacheIncludes: '/api/v1/web/apache/includes',
    webApacheInclude: '/api/v1/web/apache/includes/{point}',
    webApacheIncludeRestore: '/api/v1/web/apache/includes/{point}/restore',
    webApachePipedLog: '/api/v1/web/apache/piped-log',
    webApacheDirectoryIndex: '/api/v1/web/apache/directory-index',
    apacheStatus: '/api/v1/web/apache/status',
    passwordRules: '/api/v1/server/password-rules',
    shellLimits: '/api/v1/server/shell-limits',
    webWaf: '/api/v1/web/waf',
    webWafInstall: '/api/v1/web/waf/install',
    webWafRules: '/api/v1/web/waf/rules?limit={limit}&offset={offset}{&q}{&file}{&disabled}',
    webWafRule: '/api/v1/web/waf/rules/{id}',
    webWafHitsClear: '/api/v1/web/waf/hits',
    webWafHits: '/api/v1/web/waf/hits?limit={limit}{&domain}{&ip}{&rule}{&blocked}',
    webWafSites: '/api/v1/web/waf/sites?limit={limit}&offset={offset}{&q}',
    webWafSite: '/api/v1/web/waf/sites/{domain}',
    acctWaf: '/api/v1/accounts/{name}/waf',
    acctWafSite: '/api/v1/accounts/{name}/domains/{domain}/waf',
    acctSiteCache: '/api/v1/accounts/{name}/site-cache',
    acctSiteCachePurge: '/api/v1/accounts/{name}/site-cache/purge',
    billingCustomers: '/api/v1/billing/customers?limit={limit}&offset={offset}{&q}{&status}{&group}',
    billingCustomerNew: '/api/v1/billing/customers',
    billingCustomer: '/api/v1/billing/customers/{id}',
    billingContacts: '/api/v1/billing/customers/{id}/contacts',
    billingContact: '/api/v1/billing/customers/{id}/contacts/{contact}',
    billingNotes: '/api/v1/billing/customers/{id}/notes',
    billingNote: '/api/v1/billing/customers/{id}/notes/{note}',
    billingCredit: '/api/v1/billing/customers/{id}/credit',
    billingGroups: '/api/v1/billing/groups',
    billingGroup: '/api/v1/billing/groups/{id}',
    billingFields: '/api/v1/billing/fields',
    billingField: '/api/v1/billing/fields/{id}',
    billingServices: '/api/v1/billing/services?limit={limit}&offset={offset}{&customer}{&status}',
    billingInvoices: '/api/v1/billing/invoices?limit={limit}&offset={offset}{&customer}{&status}',
    billingInvoiceNew: '/api/v1/billing/invoices',
    billingInvoice: '/api/v1/billing/invoices/{id}',
    billingInvoiceIssue: '/api/v1/billing/invoices/{id}/issue',
    billingInvoiceCancel: '/api/v1/billing/invoices/{id}/cancel',
    billingInvoiceApplyCredit: '/api/v1/billing/invoices/{id}/apply-credit',
    billingInvoicePayments: '/api/v1/billing/invoices/{id}/payments',
    billingInvoicesGenerate: '/api/v1/billing/invoices/generate',
    billingTransactions: '/api/v1/billing/transactions?limit={limit}&offset={offset}{&invoice}{&customer}{&kind}{&status}{&gateway}',
    billingRefund: '/api/v1/billing/transactions/{id}/refund',
    billingServiceSuspend: '/api/v1/billing/services/{id}/suspend',
    billingServiceUnsuspend: '/api/v1/billing/services/{id}/unsuspend',
    billingServiceTerminate: '/api/v1/billing/services/{id}/terminate',
    billingAccounts: '/api/v1/billing/customers/{id}/accounts',
    billingAccount: '/api/v1/billing/customers/{id}/accounts/{username}',
    billingDomains: '/api/v1/billing/domains?limit={limit}&offset={offset}{&customer}{&status}{&name}',
    billingQuotes: '/api/v1/billing/quotes?limit={limit}&offset={offset}{&customer}{&status}',
    billingQuoteNew: '/api/v1/billing/quotes',
    billingQuote: '/api/v1/billing/quotes/{id}',
    billingQuoteSend: '/api/v1/billing/quotes/{id}/send',
    billingQuoteDecide: '/api/v1/billing/quotes/{id}/decide',
    billingQuoteInvoice: '/api/v1/billing/quotes/{id}/invoice',
    billingTickets: '/api/v1/billing/support/tickets?limit={limit}&offset={offset}{&customer}{&status}{&department}{&priority}{&assigned_to}',
    billingDepartments: '/api/v1/billing/support/departments',
    billingTicketNew: '/api/v1/billing/support/tickets',
    billingTicket: '/api/v1/billing/support/tickets/{id}',
    billingTicketReplies: '/api/v1/billing/support/tickets/{id}/replies',
    billingTicketAttach: '/api/v1/billing/support/tickets/{id}/messages/{message}/attachments?name={name}',
    billingDepartment: '/api/v1/billing/support/departments/{id}',
    billingCanned: '/api/v1/billing/support/canned?{&department}',
    billingCannedNew: '/api/v1/billing/support/canned',
    billingCannedOne: '/api/v1/billing/support/canned/{id}',
    billingAnnouncements: '/api/v1/billing/announcements',
    billingAnnouncement: '/api/v1/billing/announcements/{id}',
    billingKbCategories: '/api/v1/billing/kb/categories',
    billingKbCategory: '/api/v1/billing/kb/categories/{id}',
    billingKbArticles: '/api/v1/billing/kb/articles?{&category}{&status}{&q}',
    billingKbArticleNew: '/api/v1/billing/kb/articles',
    billingKbArticle: '/api/v1/billing/kb/articles/{id}',
    billingDownloads: '/api/v1/billing/downloads',
    billingDownloadAdd: '/api/v1/billing/downloads?name={name}{&title}{&description}{&audience}',
    billingDownload: '/api/v1/billing/downloads/{id}',
    billingReportIncome: '/api/v1/billing/reports/income?{&from}{&to}{&by}',
    billingReportSales: '/api/v1/billing/reports/sales?{&from}{&to}{&by}',
    billingReportAged: '/api/v1/billing/reports/aged-debt',
    billingReportTax: '/api/v1/billing/reports/tax?{&from}{&to}{&by}{&basis}',
    billingImport: '/api/v1/billing/import/{kind}?dry_run={dry_run}',
    billingMoveUpload: '/api/v1/billing/import/migrate/uploads',
    billingMoveUploadOne: '/api/v1/billing/import/migrate/uploads/{id}',
    billingMoveCheck: '/api/v1/billing/import/migrate/check',
    billingMoveApply: '/api/v1/billing/import/migrate/apply',
    billingMoveReport: '/api/v1/billing/import/migrate/report',
    billingOutbox: '/api/v1/billing/outbox?limit={limit}&offset={offset}{&customer}{&status}',
    billingOutboxOne: '/api/v1/billing/outbox/{id}',
    billingOverview: '/api/v1/billing/overview',
    billingStore: '/api/v1/billing/store',
    billingMassMail: '/api/v1/billing/mass-mail',
    billingNotices: '/api/v1/billing/notices?limit={limit}&offset={offset}{&customer}{&kind}{&status}',
    billingMessagesSend: '/api/v1/billing/messages/send',
    billingTaxRules: '/api/v1/billing/tax-rules',
    billingTaxRule: '/api/v1/billing/tax-rules/{id}',
    billingTaxSettings: '/api/v1/billing/tax-settings',
    billingRegistrar: '/api/v1/billing/domains/registrar',
    billingRegistrars: '/api/v1/billing/registrars',
    billingRegistrarSettings: '/api/v1/billing/registrars/{id}/settings',
    billingRegistrarTest: '/api/v1/billing/registrars/{id}/test',
    billingExtensions: '/api/v1/billing/domains/extensions',
    billingExtension: '/api/v1/billing/domains/extensions/{tld}',
    billingDomain: '/api/v1/billing/domains/{id}',
    billingDomainSync: '/api/v1/billing/domains/{id}/sync',
    billingDomainProcess: '/api/v1/billing/domains/{id}/process',
    billingDomainCode: '/api/v1/billing/domains/{id}/transfer-code',
    billingDomainAway: '/api/v1/billing/domains/{id}/transferred-away',
    billingDomainRenew: '/api/v1/billing/domains/{id}/renew',
    billingDomainRenewals: '/api/v1/billing/domains/{id}/renewals',
    billingDomainRenewalProcess: '/api/v1/billing/domains/{id}/renewals/{renewal}/process',
    billingTerms: '/api/v1/billing/terms',
    billingTermsOne: '/api/v1/billing/terms/{id}',
    billingAutomation: '/api/v1/billing/automation',
    billingAutomationRun: '/api/v1/billing/automation/run',
    billingAutomationRuns: '/api/v1/billing/automation/runs?{&limit}',
    billingAutomationEvents: '/api/v1/billing/automation/runs/{id}/events',
    billingMail: '/api/v1/billing/mail',
    billingTemplates: '/api/v1/billing/templates',
    billingTemplate: '/api/v1/billing/templates/{kind}',
    billingTemplatePreview: '/api/v1/billing/templates/{kind}/preview',
    billingSettings: '/api/v1/billing/settings',
    billingCompany: '/api/v1/billing/company',
    billingInvoiceSettings: '/api/v1/billing/invoice-settings',
    billingQuoteSettings: '/api/v1/billing/quote-settings',
    billingOrderSettings: '/api/v1/billing/order-settings',
    billingProvisioning: '/api/v1/billing/provisioning',
    billingServers: '/api/v1/billing/servers',
    billingServer: '/api/v1/billing/servers/{id}',
    billingServerGroups: '/api/v1/billing/server-groups',
    billingServerGroup: '/api/v1/billing/server-groups/{id}',
    billingStoreOff: '/api/v1/billing/store-off',
    billingMethods: '/api/v1/billing/customers/{id}/payment-methods',
    billingMethod: '/api/v1/billing/customers/{id}/payment-methods/{method}',
    billingMethodDefault: '/api/v1/billing/customers/{id}/payment-methods/{method}/default',
    billingGateways: '/api/v1/billing/gateways',
    billingGatewaysSet: '/api/v1/billing/gateways',
    billingGatewaySettings: '/api/v1/billing/gateways/{id}/settings',
    billingReferrer: '/api/v1/billing/customers/{id}/referrer',
    billingAffiliates: '/api/v1/billing/affiliates',
    billingAffiliate: '/api/v1/billing/affiliates/{id}',
    billingAffiliateSettings: '/api/v1/billing/affiliate-settings',
    billingAffiliateCommissions: '/api/v1/billing/affiliates/{id}/commissions',
    billingAffiliatePayouts: '/api/v1/billing/affiliates/{id}/payouts',
    billingInvoiceCharge: '/api/v1/billing/invoices/{id}/charge',
    billingInvoiceCreditNotes: '/api/v1/billing/invoices/{id}/credit-notes',
    billingCreditNotes: '/api/v1/billing/credit-notes?limit={limit}&offset={offset}{&invoice}{&customer}',
    billingInvoicesMerge: '/api/v1/billing/invoices/merge',
    billingOrders: '/api/v1/billing/orders?limit={limit}&offset={offset}{&customer}{&status}{&flag}{&plan}',
    billingOrderNew: '/api/v1/billing/orders',
    billingOrderQuote: '/api/v1/billing/orders/quote',
    billingOrder: '/api/v1/billing/orders/{id}',
    billingOrderAccept: '/api/v1/billing/orders/{id}/accept',
    billingOrderCancel: '/api/v1/billing/orders/{id}/cancel',
    billingOrderNotes: '/api/v1/billing/orders/{id}/notes',
    billingOrderNote: '/api/v1/billing/orders/{id}/notes/{note}',
    billingOrderReview: '/api/v1/billing/order-review',
    billingProductGroups: '/api/v1/billing/product-groups',
    billingPlans: '/api/v1/billing/plans?{&group}{&status}{&visibility}',
    billingPlanAddons: '/api/v1/billing/plans/{id}/addons',
    billingPlanOptions: '/api/v1/billing/plans/{id}/options',
    billingProductGroup: '/api/v1/billing/product-groups/{id}',
    billingPlanNew: '/api/v1/billing/plans',
    billingPlan: '/api/v1/billing/plans/{id}',
    billingPlanOption: '/api/v1/billing/plans/{id}/options/{option}',
    billingAddons: '/api/v1/billing/addons?{&status}',
    billingAddon: '/api/v1/billing/addons/{id}',
    billingPromos: '/api/v1/billing/promos?{&status}{&plan}',
    billingPromo: '/api/v1/billing/promos/{id}',
    webScan: '/api/v1/web/scan',
    webScanInstall: '/api/v1/web/scan/install',
    acctScan: '/api/v1/accounts/{name}/scan',
    acctScanRemove: '/api/v1/accounts/{name}/scan/remove',
    secq: '/api/v1/auth/security-questions',
    secqClear: '/api/v1/auth/security-questions/clear',
    secqAdmin: '/api/v1/security/questions',
    secqQuestion: '/api/v1/security/questions/{id}',
    secqSettings: '/api/v1/security/questions/settings',
    secqLogin: '/api/v1/logins/{login}/security-questions/clear',
    statsLeeches: '/api/v1/accounts/{name}/stats/leeches?domain={domain}&hours={hours}&addresses={addresses}',
    statsCountries: '/api/v1/accounts/{name}/stats/countries?domain={domain}&hours={hours}',
    webGeoip: '/api/v1/web/geoip',
    filesImage: '/api/v1/accounts/{name}/files/image',
    themes: '/api/v1/themes',
    themeUpload: '/api/v1/themes',
    theme: '/api/v1/themes/{id}',
    themeActivate: '/api/v1/themes/{id}/activate',
    themeRollback: '/api/v1/themes/rollback',
    themePreview: '/api/v1/themes/{id}/preview/{page}',
    themeKit: '/api/v1/themes/default/kit',
    themeScripts: '/api/v1/theme-scripts',
    themeDownload: '/api/v1/themes/{id}/download',
    resThemes: '/api/v1/reseller-themes',
    resThemeUpload: '/api/v1/reseller-themes',
    resTheme: '/api/v1/reseller-themes/{id}',
    resThemeActivate: '/api/v1/reseller-themes/{id}/activate',
    resThemeRollback: '/api/v1/reseller-themes/rollback',
    resThemePreview: '/api/v1/reseller-themes/{id}/preview/{page}',
    resThemeDownload: '/api/v1/reseller-themes/{id}/download',
    resThemeSettings: '/api/v1/reseller-themes/{id}/settings',
    resThemeKit: '/api/v1/reseller-themes/default/kit',
    market: '/api/v1/accounts/{name}/billing/market',
    marketQuote: '/api/v1/accounts/{name}/billing/market/quote',
    marketOrders: '/api/v1/accounts/{name}/billing/market/orders',
    marketChangeQuote: '/api/v1/accounts/{name}/billing/market/change-plan/quote',
    marketChange: '/api/v1/accounts/{name}/billing/market/change-plan',
    marketDomains: '/api/v1/accounts/{name}/billing/market/domains?q={q}',
    marketDomainOrder: '/api/v1/accounts/{name}/billing/market/domains',
    panelPages: '/api/v1/billing/panel-pages',
    panelTickets: '/api/v1/accounts/{name}/billing/tickets',
    panelTicket: '/api/v1/accounts/{name}/billing/tickets/{id}',
    panelTicketReply: '/api/v1/accounts/{name}/billing/tickets/{id}/replies',
    panelUsage: '/api/v1/panel-usage',
    panelAnalytics: '/api/v1/panel-analytics',
    panelAnalyticsRead: '/api/v1/panel-analytics?days={days}',
    panelAnalyticsPanel: '/api/v1/panel-analytics?days={days}&panel={panel}'
  };
  var TIMEOUT_MS = 30000;
  /* calls the server may hold longer: making or importing an SSH key, a private key for a certificate, changing a site's firewall or scan, or changing a domain's DNSSEC can wait up to 30 s for a slot before the work;
     adding an address, taking one away or giving an account one asks the network manager or reloads the web server, which the server bounds at two minutes */
  var LONG_MS = {pluginRun: 60000, sshKeys: 120000, sshKeyImport: 120000, sslKeyNew: 120000, acctWafSite: 120000, acctScan: 120000, acctScanRemove: 120000, acctDnssec: 120000, acctDnssecOff: 120000, acctDnssecRollover: 120000, serverIpAdd: 120000, serverIp: 120000, acctIpSet: 120000};
  /* calls that may run for minutes (copying, moving or deleting a big folder, packing or unpacking one, a search of a
     big home, emptying the trash, an upload, and a change to PHP that the server tests and applies before it answers): the
     page keeps waiting, and the server bounds them itself */
  var NO_TIMEOUT = {accountsBulk: true, dnsClusterSettings: true, dnsClusterNotify: true, dnsClusterPrimaryAllow: true, homeMoveCheck: true, homeMoves: true, suspendedPage: true, sitePage: true, mailRepair: true, spamFolderEmpty: true, mailImport: true, mailDeliverabilityRepair: true, appInstall: true, appUninstall: true, wpUpdate: true, wpUndo: true, wpScan: true, svcCerts: true, svcCertsRenew: true, webAutossl: true, webAutosslTerms: true, webAutosslRun: true, files: true, filesHidden: true, fileContent: true, fileUpload: true, fileUploadOver: true, fileMove: true, fileCopy: true, fileDelete: true, trash: true,
    fileArchive: true, fileExtract: true, fileSearch: true, fileSearchHidden: true, fileUsage: true,
    webPhpDefault: true, webPhpSettings: true, transferHandoff: true, webApache: true, webApacheModules: true, webNginx: true, webVarnish: true, webApacheInclude: true, webApacheIncludeRestore: true, webApachePipedLog: true, webWaf: true, webWafRule: true, webWafSite: true, webScan: true};
  /* a call to a linked server is bounded at 20 s by the server, after it checks the password (linking) or before it forgets the link (removing) */
  LONG_MS.clusterProbe = LONG_MS.clusterNodes = LONG_MS.clusterNode = LONG_MS.clusterNodeStatus = LONG_MS.clusterNodeAccounts = LONG_MS.clusterNodeTransfer = 60000;
  /* adding or changing an app writes its unit, restarts it and has the web server read its site again; a stop waits for the program */
  LONG_MS.appHostingApp = LONG_MS.appHostingControl = 120000;
  /* anonymous FTP's changes mount an account's folders and may restart the FTP server, which the server bounds at two minutes */
  LONG_MS.anonFtp = LONG_MS.anonFtpServer = 120000;
  /* a run of the billing automation does every step once and answers when it has ended, and a send round sends up to 200 messages: the page keeps waiting, because the server stops the work when the call is cut */
  NO_TIMEOUT.billingAutomationRun = NO_TIMEOUT.billingMessagesSend = true;
  var MAX_REPLY = 2 * 1024 * 1024;
  /* a text file opened for editing is up to 10 MiB, which its JSON escaping can make several times larger */
  var BIG_REPLY = {fileContent: 64 * 1024 * 1024};
  /* the Git viewer sends up to 256 KB of a patch or a file, which its JSON escaping can make six times larger */
  BIG_REPLY.gitCommit = BIG_REPLY.gitFile = 4 * 1024 * 1024;
  /* a check or repair of a database goes on for up to four minutes on the server (docs/api.md) */
  LONG_MS.mysqlMaintenance = 300000;
  /* a dry run asks Dovecot about every folder of every mailbox of an account */
  LONG_MS.mailStoragePlan = LONG_MS.mailStorageConvert = 120000;
  /* a quality report asks the site for a few dozen files, for at most 45 seconds */
  LONG_MS.smonReport = 90000;
  /* the package manager works out an install or a removal, or reads its lists, for up to 90 seconds on the server */
  LONG_MS.sysPkgsSearch = LONG_MS.sysPkgsInfo = LONG_MS.sysPkgsInstalled = LONG_MS.sysPkgsPreview = LONG_MS.sysPkgsInstall = LONG_MS.sysPkgsRemove = 120000;
  LONG_MS.postgresMaintenance = 300000;
  /* reading MongoDB's repository, and a database's dump before it is removed */
  LONG_MS.mongoServerVersions = 60000;
  LONG_MS.mongodbDatabase = 300000;
  /* the terminal is closed as the page is left: the browser lets that one call finish after the page has gone */
  var KEEPALIVE = {terminalOne: true, rootTerminalOne: true};
  var CODE_RE = /^[a-z_]{1,40}$/;
  var csrf = '';

  function t(key) { return (window.FPSTRINGS && window.FPSTRINGS[key]) || key; }

  function failure(status, code, message, retryAfter) {
    return {status: status, code: code, message: message, retryAfter: retryAfter};
  }

  function problemsOf(list) {
    return list.slice(0, 100).filter(function (p) { return p && typeof p === 'object' && typeof p.message === 'string'; }).map(function (p) {
      return {file: typeof p.file === 'string' ? p.file.slice(0, 200) : '', line: typeof p.line === 'number' && isFinite(p.line) && p.line > 0 ? Math.floor(p.line) : 0,
        message: p.message.slice(0, 500)};
    });
  }

  /* the reply's own error when it has one in the expected shape, else our words for the status */
  function errorFrom(status, body, retryHeader) {
    var err = body && typeof body === 'object' && body.error && typeof body.error === 'object' ? body.error : {};
    var code = typeof err.code === 'string' && CODE_RE.test(err.code) ? err.code : (status === 401 ? 'unauthorized' : 'failed');
    var retry = parseInt(retryHeader, 10) > 0 ? parseInt(retryHeader, 10) : 0;
    var message = typeof err.message === 'string' && err.message.trim() ? err.message.trim().slice(0, 300) : '';
    if (code === 'rate_limited' && retry) { message = ''; }
    if (!message) {
      if (code === 'rate_limited') {
        message = retry ? t('rate_limited').replace('{seconds}', String(retry)) : t('rate_limited_short');
      } else if (window.FPSTRINGS && window.FPSTRINGS[code]) {
        message = t(code);
      } else {
        message = t('api_failed');
      }
    }
    var f = failure(status, code, message, retry);
    if (typeof err.field === 'string') { f.field = err.field; }
    /* the problems a theme's check found, each a file, a line and words (docs/api.md, "Themes"), cleaned to that shape */
    if (Array.isArray(err.problems)) { f.problems = problemsOf(err.problems); }
    /* a free name the server found when the one asked for is taken (restoring from the file manager's trash) */
    if (typeof err.suggested === 'string' && err.suggested.length <= 4096) { f.suggested = err.suggested; }
    return f;
  }

  /* name is a PATHS key; each {key} in the path is filled from arg, URL-encoded: arg is the {name} itself, or an
     object such as {name: 'site1', id: '…'}. A missing or empty value fails the call rather than leave a hole, except
     for a {&key} at the end of a query, which is left out when there is no value and written as &key=value otherwise. */
  function fill(path, arg) {
    var vals = typeof arg === 'string' ? {name: arg} : (arg && typeof arg === 'object' ? arg : {});
    var ok = true;
    path = path.replace(/\{(&?)([a-z_]+)\}/g, function (m, optional, k) {
      var v = vals[k];
      if (optional) { return typeof v === 'string' && v ? '&' + k + '=' + encodeURIComponent(v) : ''; }
      if (typeof v !== 'string' || !v) { ok = false; return ''; }
      return encodeURIComponent(v);
    });
    return ok ? path : '';
  }
  /* raw, when given, is {body, type}: a body sent as it is (a file, or a text file's content) instead of JSON */
  function request(method, name, body, arg, raw) {
    var path = PATHS[name] ? fill(PATHS[name], arg) : '';
    if (!path) { return Promise.reject(failure(0, 'bad_request', t('api_failed'), 0)); }
    if (!window.fetch) { return Promise.reject(failure(0, 'unreachable', t('api_unreachable'), 0)); }
    var headers = {'Accept': 'application/json'};
    var file = window.Blob && body instanceof window.Blob;
    if (method !== 'GET') {
      if (method !== 'DELETE') { headers['Content-Type'] = raw ? raw.type : file ? body.type : 'application/json'; }
      if (csrf) { headers['X-CSRF-Token'] = csrf; }
    }
    var ctl = window.AbortController ? new window.AbortController() : null;
    var timer = 0;
    var timedOut = false;
    if (ctl && !NO_TIMEOUT[name]) { timer = window.setTimeout(function () { timedOut = true; ctl.abort(); }, LONG_MS[name] || TIMEOUT_MS); }
    return fetch(path, {
      method: method, credentials: 'same-origin', cache: 'no-store', headers: headers, keepalive: Boolean(KEEPALIVE[name]),
      body: method === 'GET' || method === 'DELETE' ? undefined : raw ? raw.body : file ? body : JSON.stringify(body || {}), signal: ctl ? ctl.signal : undefined
    }).then(function (r) {
      return r.text().then(function (text) {
        window.clearTimeout(timer);
        var data;
        try { data = text && text.length <= (BIG_REPLY[name] || MAX_REPLY) ? JSON.parse(text) : null; } catch (e) { data = null; }
        if (r.ok) {
          if (r.status === 202 || r.status === 204 || !text) { return data && typeof data === 'object' ? data : {}; }
          if (!data || typeof data !== 'object' || Array.isArray(data)) { throw failure(r.status, 'unreachable', t('api_unreachable'), 0); }
          return data;
        }
        var refused = errorFrom(r.status, data, r.headers.get('Retry-After'));
        /* a locked panel (the licence ran out): the shell loads again to show its lock screen */
        if (refused.code === 'license_required') { document.dispatchEvent(new window.CustomEvent('fp:locked')); }
        /* a login told to choose a new password: the shell loads again to show that screen */
        if (refused.code === 'password_change_required') { document.dispatchEvent(new window.CustomEvent('fp:mustchange')); }
        throw refused;
      }, function () {
        /* the answer broke off part way (the server stopped a stalled transfer): a failed call, never a short reply */
        window.clearTimeout(timer);
        throw timedOut ? failure(0, 'timeout', t('api_timeout'), 0) : failure(0, 'unreachable', t('api_unreachable'), 0);
      });
    }, function () {
      window.clearTimeout(timer);
      throw timedOut ? failure(0, 'timeout', t('api_timeout'), 0) : failure(0, 'unreachable', t('api_unreachable'), 0);
    });
  }

  /* sends a file as the request body (an archive to restore): no time limit, progress as a fraction, and abort() to stop
     it. The answer is read as request()'s is; a stopped send fails with code 'aborted'. */
  function upload(name, file, type, arg, progress) {
    var path = PATHS[name] ? fill(PATHS[name], arg) : '';
    var xhr = new XMLHttpRequest();
    var done = new Promise(function (resolve, reject) {
      if (!path) { reject(failure(0, 'bad_request', t('api_failed'), 0)); return; }
      xhr.open('POST', path);
      xhr.withCredentials = true;
      xhr.setRequestHeader('Accept', 'application/json');
      xhr.setRequestHeader('Content-Type', type);
      if (csrf) { xhr.setRequestHeader('X-CSRF-Token', csrf); }
      if (progress) { xhr.upload.onprogress = function (e) { if (e.lengthComputable && e.total) { progress(e.loaded / e.total); } }; }
      xhr.onload = function () {
        var text = xhr.responseText;
        var data;
        try { data = text && text.length <= MAX_REPLY ? JSON.parse(text) : null; } catch (e) { data = null; }
        if (xhr.status >= 200 && xhr.status < 300) { resolve(data && typeof data === 'object' && !Array.isArray(data) ? data : {}); return; }
        reject(errorFrom(xhr.status, data, xhr.getResponseHeader('Retry-After')));
      };
      xhr.onerror = function () { reject(failure(0, 'unreachable', t('api_unreachable'), 0)); };
      xhr.onabort = function () { reject(failure(0, 'aborted', '', 0)); };
      xhr.send(file);
    });
    return {done: done, abort: function () { xhr.abort(); }};
  }

  /* the API shell (fp-apishell.js): one request to a path of this API, made as the pages' own calls are (the session's cookie, the CSRF token on a
     write, this origin only), and the answer as it came: {status, statusText, headers: [[name, value]], text, cut, download}. A path that is not under
     /api/v1/ of this origin, or that climbs out of it, is refused without a request. Redirects are not followed. The body is read as it arrives and
     the request is stopped past SHELL_READ bytes (cut is then true), so a large answer never fills the tab; a file to download (Content-Disposition:
     attachment) is not read at all: download is then {bytes}, the length the server gave or -1. */
  var SHELL_PATH = /^\/api\/v1\/[A-Za-z0-9\-._~%!$&'()*+,;=:@/?]*$/;
  var SHELL_READ = 2 << 20;
  /* the first SHELL_READ bytes of r's body as text, and whether there was more; ctl, when there is one, stops the request at the limit */
  function shellText(r, ctl) {
    if (!r.body || typeof r.body.getReader !== 'function' || !window.TextDecoder) {
      return r.text().then(function (text) { return {text: text.length > SHELL_READ ? text.slice(0, SHELL_READ) : text, cut: text.length > SHELL_READ}; });
    }
    var reader = r.body.getReader();
    var dec = new window.TextDecoder();
    var parts = [];
    var got = 0;
    function pump() {
      return reader.read().then(function (x) {
        if (x.done) { return false; }
        var chunk = x.value;
        if (got + chunk.byteLength > SHELL_READ) {
          parts.push(dec.decode(chunk.subarray(0, SHELL_READ - got), {stream: true}));
          got = SHELL_READ;
          reader.cancel().catch(function () {});
          if (ctl) { ctl.abort(); }
          return true;
        }
        got += chunk.byteLength;
        parts.push(dec.decode(chunk, {stream: true}));
        return pump();
      });
    }
    return pump().then(function (cut) {
      parts.push(dec.decode());
      return {text: parts.join(''), cut: cut};
    });
  }
  function shell(method, path, bodyText) {
    if (['GET', 'POST', 'PUT', 'PATCH', 'DELETE'].indexOf(method) < 0 || typeof path !== 'string' || path.length > 4096 || !SHELL_PATH.test(path) ||
        /\/\/|\/\.\.?(\/|\?|$)|%2e%2e|%2f/i.test(path.split('?')[0])) {
      return Promise.reject(failure(0, 'bad_request', t('api_failed'), 0));
    }
    if (!window.fetch) { return Promise.reject(failure(0, 'unreachable', t('api_unreachable'), 0)); }
    var headers = {'Accept': 'application/json'};
    var send = method !== 'GET' && typeof bodyText === 'string' && bodyText !== '';
    if (send) { headers['Content-Type'] = 'application/json'; }
    if (method !== 'GET' && csrf) { headers['X-CSRF-Token'] = csrf; }
    var ctl = window.AbortController ? new window.AbortController() : null;
    var timer = ctl ? window.setTimeout(function () { ctl.abort(); }, 120000) : 0;
    return fetch(path, {method: method, credentials: 'same-origin', cache: 'no-store', redirect: 'manual', headers: headers,
      body: send ? bodyText : undefined, signal: ctl ? ctl.signal : undefined}).then(function (r) {
      var hs = [];
      r.headers.forEach(function (v, k) { hs.push([k, v]); });
      hs.sort(function (a, b) { return a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0; });
      var answer = {status: r.status, statusText: r.statusText || '', headers: hs, text: '', cut: false, download: null};
      if (/^\s*attachment\b/i.test(r.headers.get('Content-Disposition') || '')) {
        window.clearTimeout(timer);
        var n = Number(r.headers.get('Content-Length'));
        answer.download = {bytes: isFinite(n) && n >= 0 && r.headers.get('Content-Length') !== null ? n : -1};
        if (r.body && typeof r.body.cancel === 'function') { r.body.cancel().catch(function () {}); }
        if (ctl) { ctl.abort(); }
        return answer;
      }
      return shellText(r, ctl).then(function (got) {
        window.clearTimeout(timer);
        answer.text = got.text;
        answer.cut = got.cut;
        return answer;
      }, function () {
        window.clearTimeout(timer);
        throw failure(0, 'unreachable', t('api_unreachable'), 0);
      });
    }, function () {
      window.clearTimeout(timer);
      throw failure(0, 'unreachable', t('api_unreachable'), 0);
    });
  }

  window.FPAPI = {
    shell: shell,
    upload: upload,
    paths: PATHS,
    setCsrf: function (token) { csrf = typeof token === 'string' && /^[A-Za-z0-9_\-.]{16,256}$/.test(token) ? token : ''; },
    get: function (name, arg) { return request('GET', name, undefined, arg); },
    post: function (name, body, arg) { return request('POST', name, body, arg); },
    put: function (name, body, arg) { return request('PUT', name, body, arg); },
    del: function (name, arg) { return request('DELETE', name, undefined, arg); },
    patch: function (name, body, arg) { return request('PATCH', name, body, arg); },
    /* a body sent as it is: raw is {body, type} */
    send: function (method, name, arg, raw) { return request(method, name, undefined, arg, raw); }
  };
})();

/* freePanel web server includes (docs/api.md, "GET /web/apache/includes"): the admin panel's page (#/tool/web_includes) for the lines of web
   server configuration the admin writes at three fixed points (before every site, after every site, and at the end of the server's own
   values), for the piped access log, and for the index file order of every site (DirectoryIndex priority). The admin picks a point, never a file. A save is checked by the web server before it is used: a
   text it refuses changes nothing and its own lines are shown; the one replaced is kept, so it can be put back. The piped log sends every
   request to one of two programs the panel knows, with values from closed lists; nothing typed here reaches a command. Admin only: the
   server refuses these calls to anyone else. Everything the server sends is shown as text. The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var POINTS = ['before_sites', 'after_sites', 'global'];
  var PROGRAMS = ['off', 'syslog', 'rotatelogs'];
  var FACILITY_RE = /^local[0-7]$/;
  var NAME_RE = /^[A-Za-z][A-Za-z0-9]{0,40}$/;
  var PATH_RE = /^\/[A-Za-z0-9_./-]{1,300}$/;
  var MAX_BYTES = 65536;
  var MAX_DAYS = 90;
  /* an index file name, as the server checks it (apache.CheckDirectoryIndex): a file of the folder asked for, never a path */
  var INDEX_RE = /^[A-Za-z0-9_][A-Za-z0-9_.~+-]{0,99}$/;
  var INDEX_DEFAULT = ['index.php', 'index.html', 'index.htm'];

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  function int(v, lo, hi, d) { return typeof v === 'number' && isFinite(v) && v >= lo && v <= hi ? Math.round(v) : d; }
  function bytes(s) { return new window.TextEncoder().encode(s).length; }
  function count(n) { return Math.round(n).toLocaleString('en'); }
  function when(iso) { return (FP.bk && FP.bk.when(iso)) || iso; }

  function point(v, name) {
    v = v && typeof v === 'object' ? v : {};
    return {name: name, path: PATH_RE.test(str(v.path, 301)) ? v.path : '', text: str(v.text, MAX_BYTES * 2), saved: str(v.saved_at, 40),
      hasPrev: v.has_previous === true, prev: str(v.previous, MAX_BYTES * 2), hosts: v.hosts === true};
  }
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var pts = Array.isArray(r.points) ? r.points : [];
    var byName = {};
    pts.forEach(function (p) { if (p && POINTS.indexOf(p.name) >= 0 && !byName[p.name]) { byName[p.name] = p; } });
    var pl = r.piped_log && typeof r.piped_log === 'object' ? r.piped_log : {};
    var programs = {};
    (Array.isArray(pl.programs) ? pl.programs : []).forEach(function (p) {
      if (p && PROGRAMS.indexOf(p.name) >= 0) { programs[p.name] = {available: p.available === true, path: PATH_RE.test(str(p.path, 301)) ? p.path : ''}; }
    });
    var maxDays = int(pl.max_keep_days, 1, 3650, MAX_DAYS);
    var di = r.directory_index && typeof r.directory_index === 'object' ? r.directory_index : {};
    function names(list) { return (Array.isArray(list) ? list : []).filter(function (n) { return typeof n === 'string' && INDEX_RE.test(n); }).slice(0, 50); }
    var dflt = names(di['default']);
    var now = names(di.names);
    return {
      index: {names: now.length ? now : (dflt.length ? dflt : INDEX_DEFAULT.slice()), chosen: di.chosen === true, dflt: dflt.length ? dflt : INDEX_DEFAULT.slice(),
        max: int(di.max, 1, 50, 20)},
      available: r.available === true, reason: str(r.reason, 400), max: int(r.max_bytes, 1, 1 << 20, MAX_BYTES),
      points: POINTS.map(function (n) { return point(byName[n], n); }),
      sections: (Array.isArray(r.sections) ? r.sections : []).filter(function (s) { return typeof s === 'string' && NAME_RE.test(s); }).slice(0, 200),
      directives: (Array.isArray(r.directives) ? r.directives : []).filter(function (s) { return typeof s === 'string' && NAME_RE.test(s); }).slice(0, 400),
      piped: {program: PROGRAMS.indexOf(pl.program) >= 0 ? pl.program : 'off', facility: FACILITY_RE.test(str(pl.facility, 10)) ? pl.facility : 'local6',
        keep: int(pl.keep_days, 1, maxDays, 14), maxDays: maxDays, programs: programs,
        facilities: (Array.isArray(pl.facilities) ? pl.facilities : []).filter(function (f) { return typeof f === 'string' && FACILITY_RE.test(f); }),
        file: /^\/[A-Za-z0-9_./-]{1,300}$/.test(str(pl.file, 301)) ? pl.file : '', tag: /^[a-z0-9-]{1,40}$/.test(str(pl.tag, 41)) ? pl.tag : ''}
    };
  }

  var P = {page: null, S: null, busy: false, index: null};

  function lines(text) {
    var n = text.split('\n').filter(function (l) { var s = l.trim(); return s && s.charAt(0) !== '#'; }).length;
    return n;
  }
  function pill(p) {
    var n = lines(p.text);
    return el('span', {class: 'sig-pill' + (n ? ' sig-pill--accent' : ''), text: n ? t(n === 1 ? 'inc_pill_one' : 'inc_pill_many', {count: count(n)}) : t('inc_pill_empty')});
  }
  function counter(form, area) {
    var c = form.querySelector('[data-fp-count]');
    var n = bytes(area.value.replace(/\r\n/g, '\n'));
    c.textContent = t('inc_count', {used: count(n), max: count(P.S.max)});
    c.classList.toggle('fp-inc-over', n > P.S.max);
    return n;
  }

  function pointForm(p) {
    var id = 'fp-inc-' + p.name;
    var area = el('textarea', {class: 'sig-input sig-mono fp-inc-text', id: id + '-text', name: 'text', rows: '10', spellcheck: 'false', autocapitalize: 'none',
      autocomplete: 'off', wrap: 'off', 'aria-describedby': id + '-text-hint ' + id + '-count'});
    area.value = p.text;
    function restoreButton() { return el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'restore', text: t('inc_restore')}); }
    var restore = p.hasPrev ? el('span', {class: 'fp-inc-restore', 'data-fp-restore': p.name}, [restoreButton()]) : null;
    var form = el('form', {class: 'fp-form fp-inc-form', novalidate: '', 'data-fp-point': p.name}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: area.id, text: t('inc_text_label')}), area,
        el('span', {class: 'sig-hint', id: id + '-text-hint', text: t(p.hosts ? 'inc_text_hint_hosts' : 'inc_text_hint')}),
        el('span', {class: 'sig-hint fp-inc-count', id: id + '-count', 'data-fp-count': '', 'aria-live': 'polite'})]),
      /* Apache reads an include as root, so the admin's own password is asked again; the server checks it itself */
      M.field(id + '-pw', t('inc_password'), el('input', {class: 'sig-input', id: id + '-pw', name: 'current_password', type: 'password',
        autocomplete: 'current-password', maxlength: '1024'}), t('inc_password_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('inc_save')}), restore])]);
    area.addEventListener('input', function () { counter(form, area); });
    counter(form, area);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || P.busy) { return; }
      var text = area.value.replace(/\r\n/g, '\n');
      if (bytes(text) > P.S.max) {
        M.failed(form, {field: 'text', message: t('inc_too_big', {max: count(P.S.max)})});
        return;
      }
      if (text === p.text) {
        M.say(form, t('inc_nothing'));
        return;
      }
      var pw = form.querySelector('[name="current_password"]');
      if (!pw.value) {
        M.failed(form, {field: 'current_password', message: t('inc_password_needed')});
        return;
      }
      send(form, b, 'put', 'webApacheInclude', {text: text, current_password: pw.value}, p.name, t('inc_saved'));
    });
    /* putting the earlier version back asks first, in place: the question, then a button that does it and one that does not */
    if (restore) {
      restore.addEventListener('click', function (e) {
        var b = e.target.closest('button[data-fp-act]');
        if (!b || P.busy) { return; }
        var act = b.getAttribute('data-fp-act');
        if (act === 'restore') {
          M.confirmIn(restore, t('inc_restore_ask'), 'restore-yes', t('inc_restore_yes'));
        } else if (act === 'confirm-no') {
          restore.textContent = '';
          restore.appendChild(restoreButton()).focus();
        } else if (act === 'restore-yes' && M.start(form)) {
          send(form, b, 'post', 'webApacheIncludeRestore', {}, p.name, t('inc_restored'));
        }
      });
    }
    return form;
  }
  /* a save or a restore; the server checks the text with the web server before it answers, so the page waits */
  function send(form, b, method, key, body, name, done) {
    P.busy = true;
    UI.setBusy(b, true);
    var mine = P.page;
    FP.call(method, key, body, {point: name}).then(function (r) {
      P.busy = false;
      if (P.page !== mine) { return; }
      var keep = unsaved(name);
      P.S = clean(r);
      render();
      restoreUnsaved(keep);
      var card = P.page.querySelector('[data-fp-card="' + name + '"]');
      M.say(card, done);
      var h = P.page.querySelector('#fp-inc-' + name + '-h');
      if (h) { h.focus(); }
    }, function (err) {
      P.busy = false;
      if (P.page !== mine) { return; }
      UI.setBusy(b, false);
      M.failed(form, err);
    });
  }
  /* what is typed in the other forms and not saved; a save draws the page again from the server's answer, which would drop it */
  function unsaved(except) {
    var out = {};
    POINTS.forEach(function (n) {
      var a = n === except ? null : P.page.querySelector('[data-fp-point="' + n + '"] textarea');
      if (a) { out[n] = a.value; }
    });
    if (except !== 'index' && P.index) { out.index = P.index.slice(); }
    var f = except === 'piped' ? null : P.page.querySelector('.fp-inc-piped-form');
    if (f) {
      var c = f.querySelector('input[name="program"]:checked');
      out.piped = {program: c ? c.value : '', facility: f.querySelector('[name="facility"]').value, keep: f.querySelector('[name="keep_days"]').value};
    }
    return out;
  }
  function restoreUnsaved(keep) {
    if (keep.index) { P.index = keep.index; drawIndex(); }
    POINTS.forEach(function (n) {
      var form = P.page.querySelector('[data-fp-point="' + n + '"]');
      var a = form && form.querySelector('textarea');
      if (a && typeof keep[n] === 'string') { a.value = keep[n]; counter(form, a); }
    });
    var f = P.page.querySelector('.fp-inc-piped-form');
    if (f && keep.piped) {
      var r = f.querySelector('input[name="program"][value="' + keep.piped.program + '"]');
      if (r && !r.disabled) { r.checked = true; }
      f.querySelector('[name="facility"]').value = keep.piped.facility;
      f.querySelector('[name="keep_days"]').value = keep.piped.keep;
      shown(f);
    }
  }

  /* a button that shows and hides what is under it; what is hidden is not laid out */
  var disclosed = 0;
  function disclose(label, content, cls, attr) {
    var id = 'fp-inc-more-' + (++disclosed);
    var region = el('div', {class: 'fp-inc-more', id: id, hidden: ''}, content);
    var b = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-inc-toggle', type: 'button', 'aria-expanded': 'false', 'aria-controls': id, text: label});
    b.addEventListener('click', function () {
      var open = b.getAttribute('aria-expanded') !== 'true';
      b.setAttribute('aria-expanded', String(open));
      region.hidden = !open;
    });
    var w = el('div', {class: cls}, [b, region]);
    if (attr) { w.setAttribute(attr[0], attr[1]); }
    return w;
  }

  function pointCard(p) {
    var parts = [el('p', {class: 'fp-muted', text: t('inc_what_' + p.name)}),
      el('p', {class: 'fp-inc-now', 'data-fp-now': p.name}, [pill(p), ' ', p.path ? el('span', {class: 'sig-mono fp-inc-path', text: p.path}) : null]),
      p.saved ? el('p', {class: 'fp-muted fp-inc-when', text: t('inc_saved_at', {when: when(p.saved)})}) : null,
      pointForm(p)];
    if (p.hasPrev) {
      parts.push(disclose(t('inc_prev_show'), [p.prev.trim() ? el('pre', {class: 'sig-mono fp-inc-pre', tabindex: '0', 'aria-label': t('inc_prev_label'), text: p.prev}) :
        el('p', {class: 'fp-muted', text: t('inc_prev_empty')})], 'fp-inc-prev', ['data-fp-prev', p.name]));
    }
    var c = M.card('fp-inc-' + p.name + '-h', t('inc_title_' + p.name), parts, 'fp-inc-card');
    c.setAttribute('data-fp-card', p.name);
    return c;
  }

  /* ---- the piped access log ---- */
  function pipedNow(pl) {
    if (pl.program === 'syslog') { return t('inc_piped_now_syslog', {facility: pl.facility, tag: pl.tag || '—'}); }
    if (pl.program === 'rotatelogs') { return t('inc_piped_now_rotatelogs', {file: pl.file || '—', days: count(pl.keep)}); }
    return t('inc_piped_now_off');
  }
  function shown(form) {
    var c = form.querySelector('input[name="program"]:checked');
    var v = c ? c.value : 'off';
    form.querySelector('[data-fp-for="syslog"]').hidden = v !== 'syslog';
    form.querySelector('[data-fp-for="rotatelogs"]').hidden = v !== 'rotatelogs';
  }
  function pipedForm(pl) {
    var radios = PROGRAMS.map(function (name) {
      var id = 'fp-inc-piped-' + name;
      var info = pl.programs[name] || {available: name === 'off', path: ''};
      var hint = t('inc_program_' + name + '_hint');
      if (name !== 'off' && !info.available) { hint = t('inc_program_missing', {path: info.path || '—'}); }
      return el('div', {class: 'fp-inc-choice'}, [el('label', {class: 'fp-check', for: id}, [
        el('input', {type: 'radio', id: id, name: 'program', value: name, checked: name === pl.program ? true : null, disabled: !info.available && name !== pl.program ? true : null,
          'aria-describedby': id + '-hint'}), el('span', {text: t('inc_program_' + name)})]),
      el('span', {class: 'sig-hint', id: id + '-hint', text: hint})]);
    });
    var facilities = pl.facilities.length ? pl.facilities : ['local6'];
    var fac = el('select', {class: 'sig-select', id: 'fp-inc-facility', name: 'facility'}, facilities.map(function (f) { return el('option', {value: f, text: f}); }));
    fac.value = facilities.indexOf(pl.facility) >= 0 ? pl.facility : facilities[0];
    var keep = el('input', {class: 'sig-input fp-inc-days', id: 'fp-inc-keep', name: 'keep_days', type: 'number', inputmode: 'numeric', min: '1', max: String(pl.maxDays), step: '1', value: String(pl.keep)});
    var form = el('form', {class: 'fp-form fp-inc-piped-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('fieldset', {class: 'fp-inc-set'}, [el('legend', {class: 'sig-label', text: t('inc_program')})].concat(radios)),
      el('div', {'data-fp-for': 'syslog'}, [M.field('fp-inc-facility', t('inc_facility'), fac, t('inc_facility_hint', {tag: pl.tag || '—'}))]),
      el('div', {'data-fp-for': 'rotatelogs'}, [M.field('fp-inc-keep', t('inc_keep'), keep, t('inc_keep_hint', {max: count(pl.maxDays), file: pl.file || '—'}))]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('inc_piped_save')})])]);
    form.addEventListener('change', function () { shown(form); });
    shown(form);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || P.busy) { return; }
      var c = form.querySelector('input[name="program"]:checked');
      var body = {program: c ? c.value : 'off'};
      if (body.program === 'syslog') { body.facility = fac.value; }
      if (body.program === 'rotatelogs') {
        var n = Number(keep.value);
        if (!/^[0-9]{1,3}$/.test(keep.value.trim()) || n < 1 || n > pl.maxDays) {
          M.failed(form, {field: 'keep_days', message: t('inc_keep_bad', {max: count(pl.maxDays)})});
          return;
        }
        body.keep_days = n;
      }
      if (body.program === pl.program && (body.program === 'off' || (body.program === 'syslog' && body.facility === pl.facility) ||
          (body.program === 'rotatelogs' && body.keep_days === pl.keep))) {
        M.say(form, t('inc_nothing'));
        return;
      }
      P.busy = true;
      UI.setBusy(b, true);
      var mine = P.page;
      FP.call('put', 'webApachePipedLog', body).then(function (r) {
        P.busy = false;
        if (P.page !== mine) { return; }
        var kept = unsaved('piped');
        P.S = clean(r);
        render();
        restoreUnsaved(kept);
        M.say(P.page.querySelector('[data-fp-card="piped"]'), t('inc_piped_saved'));
        var h = P.page.querySelector('#fp-inc-piped-h');
        if (h) { h.focus(); }
      }, function (err) {
        P.busy = false;
        if (P.page !== mine) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return form;
  }
  function pipedCard() {
    var pl = P.S.piped;
    var c = M.card('fp-inc-piped-h', t('inc_piped_title'), [el('p', {class: 'fp-muted', text: t('inc_piped_what')}),
      el('p', {class: 'fp-inc-now', 'data-fp-now': 'piped'}, [el('span', {class: 'sig-pill' + (pl.program !== 'off' ? ' sig-pill--accent' : ''),
        text: t(pl.program !== 'off' ? 'inc_pill_on' : 'inc_pill_off')}), ' ', el('span', {text: pipedNow(pl)})]),
      pipedForm(pl)], 'fp-inc-card');
    c.setAttribute('data-fp-card', 'piped');
    return c;
  }

  /* ---- the index file order ---- */
  /* P.index is the order as edited here, saved only with the button; each row moves up or down or goes, and keeps the focus where it was */
  function clearError(form) {
    UI.showError(form, '');
    var bad = form.querySelectorAll('[aria-invalid]');
    for (var i = 0; i < bad.length; i++) { bad[i].removeAttribute('aria-invalid'); }
  }
  function sameList(a, b) { return a.length === b.length && a.every(function (n, i) { return n === b[i]; }); }
  function drawIndex(focus) {
    var list = P.page && P.page.querySelector('[data-fp-index-list]');
    if (!list) { return; }
    list.textContent = '';
    P.index.forEach(function (name, i) {
      function btn(act, label, off) {
        return el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': act, 'data-fp-i': String(i),
          'aria-label': t(label, {name: name}), text: t(label + '_short'), disabled: off ? true : null});
      }
      list.appendChild(el('li', {class: 'fp-inc-index-row', 'data-fp-index': name}, [el('span', {class: 'fp-inc-index-n', 'aria-hidden': 'true', text: count(i + 1) + '.'}),
        el('span', {class: 'sig-mono fp-inc-index-name', text: name}),
        el('span', {class: 'fp-inc-index-acts'}, [btn('up', 'inc_index_up', i === 0), btn('down', 'inc_index_down', i === P.index.length - 1),
          btn('remove', 'inc_index_remove', P.index.length === 1)])]));
    });
    var add = P.page.querySelector('#fp-inc-index-add');
    if (add) { add.disabled = P.index.length >= P.S.index.max; }
    if (focus) {
      var b = list.querySelector('button[data-fp-act="' + focus[0] + '"][data-fp-i="' + focus[1] + '"]');
      if (!b || b.disabled) { b = list.querySelector('button[data-fp-i="' + focus[1] + '"]:not([disabled])') || P.page.querySelector('#fp-inc-index-name'); }
      if (b) { b.focus(); }
    }
  }
  function indexForm(ix) {
    var input = el('input', {class: 'sig-input sig-mono fp-inc-index-input', id: 'fp-inc-index-name', name: 'name', type: 'text', maxlength: '100', spellcheck: 'false',
      autocapitalize: 'none', autocomplete: 'off'});
    var addBtn = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', id: 'fp-inc-index-add', 'data-fp-act': 'add', text: t('inc_index_add')});
    var list = el('ol', {class: 'fp-inc-index-list', 'data-fp-index-list': '', 'aria-label': t('inc_index_list')});
    var reset = ix.chosen ? el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'default', text: t('inc_index_reset')}) : null;
    var form = el('form', {class: 'fp-form fp-inc-index-form', novalidate: ''}, [M.errorLine(), M.statusLine(), list,
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: input.id, text: t('inc_index_name')}),
        el('div', {class: 'fp-inc-index-addrow'}, [input, addBtn]),
        el('span', {class: 'sig-hint', id: 'fp-inc-index-name-hint', text: t('inc_index_name_hint', {max: count(ix.max)})})]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('inc_index_save')}), reset])]);
    input.setAttribute('aria-describedby', 'fp-inc-index-name-hint');
    function addName() {
      var name = input.value.trim();
      if (!INDEX_RE.test(name) || name.toLowerCase() === 'disabled') {
        M.failed(form, {field: 'name', message: t('inc_index_bad')});
        return;
      }
      if (P.index.indexOf(name) >= 0) {
        M.failed(form, {field: 'name', message: t('inc_index_twice', {name: name})});
        return;
      }
      if (P.index.length >= ix.max) {
        M.failed(form, {field: 'name', message: t('inc_index_full', {max: count(ix.max)})});
        return;
      }
      clearError(form);
      P.index.push(name);
      input.value = '';
      drawIndex();
      M.say(form, t('inc_index_added', {name: name}));
      input.focus();
    }
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); addName(); }
    });
    form.addEventListener('click', function (e) {
      var b = e.target.closest('button[data-fp-act]');
      if (!b || P.busy || b.type === 'submit') { return; }
      var act = b.getAttribute('data-fp-act');
      var i = Number(b.getAttribute('data-fp-i'));
      if (act === 'add') { addName(); return; }
      if (act === 'default') {
        if (M.start(form)) { save(form, b, []); }
        return;
      }
      var name = P.index[i];
      if (name === undefined) { return; }
      if (act === 'up' && i > 0) {
        P.index.splice(i, 1);
        P.index.splice(i - 1, 0, name);
        drawIndex(['up', i - 1]);
        M.say(form, t('inc_index_moved', {name: name, place: count(i)}));
      } else if (act === 'down' && i < P.index.length - 1) {
        P.index.splice(i, 1);
        P.index.splice(i + 1, 0, name);
        drawIndex(['down', i + 1]);
        M.say(form, t('inc_index_moved', {name: name, place: count(i + 2)}));
      } else if (act === 'remove' && P.index.length > 1) {
        P.index.splice(i, 1);
        drawIndex(['remove', Math.min(i, P.index.length - 1)]);
        M.say(form, t('inc_index_removed', {name: name}));
      }
    });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || P.busy) { return; }
      if (sameList(P.index, ix.names)) {
        M.say(form, t('inc_nothing'));
        return;
      }
      save(form, b, P.index.slice());
    });
    return form;
  }
  /* an empty list puts the default back; the server rebuilds every site's host and checks the web server before it answers */
  function save(form, b, names) {
    P.busy = true;
    UI.setBusy(b, true);
    var mine = P.page;
    FP.call('put', 'webApacheDirectoryIndex', {names: names}).then(function (r) {
      P.busy = false;
      if (P.page !== mine) { return; }
      var kept = unsaved('index');
      P.S = clean(r);
      render();
      restoreUnsaved(kept);
      M.say(P.page.querySelector('[data-fp-card="index"]'), t(names.length ? 'inc_index_saved' : 'inc_index_reset_done'));
      var h = P.page.querySelector('#fp-inc-index-h');
      if (h) { h.focus(); }
    }, function (err) {
      P.busy = false;
      if (P.page !== mine) { return; }
      UI.setBusy(b, false);
      M.failed(form, err.field === 'names' ? {field: 'name', message: err.message} : err);
    });
  }
  function indexCard() {
    var ix = P.S.index;
    P.index = ix.names.slice();
    var c = M.card('fp-inc-index-h', t('inc_index_title'), [el('p', {class: 'fp-muted', text: t('inc_index_what')}),
      el('p', {class: 'fp-inc-now', 'data-fp-now': 'index'}, [el('span', {class: 'sig-pill' + (ix.chosen ? ' sig-pill--accent' : ''),
        text: t(ix.chosen ? 'inc_index_pill_chosen' : 'inc_index_pill_default')}), ' ', el('span', {class: 'sig-mono', text: ix.names.join(' ')})]),
      indexForm(ix)], 'fp-inc-card');
    c.setAttribute('data-fp-card', 'index');
    return c;
  }

  function allowedCard() {
    var S = P.S;
    function chips(list) {
      return el('ul', {class: 'fp-inc-chips'}, list.map(function (n) { return el('li', {class: 'sig-mono', text: n}); }));
    }
    return M.card('fp-inc-allowed-h', t('inc_allowed_title'), [el('p', {class: 'fp-muted', text: t('inc_allowed_what')}),
      disclose(t('inc_sections', {count: count(S.sections.length)}), [chips(S.sections)], 'fp-inc-list'),
      disclose(t('inc_directives', {count: count(S.directives.length)}), [chips(S.directives)], 'fp-inc-list'),
      el('p', {class: 'fp-muted', text: t('inc_not_allowed')})], 'fp-inc-allowed');
  }

  function render() {
    var S = P.S;
    P.page.textContent = '';
    P.page.appendChild(M.card('fp-inc-intro-h', t('inc_intro_title'), [el('p', {class: 'fp-muted', text: t('inc_intro_1')}),
      el('p', {class: 'fp-muted', text: t('inc_intro_2')})], 'fp-inc-intro'));
    if (!S.available) {
      P.page.appendChild(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-unavailable': ''}, [UI.icon(FP.ui, 'ui_warning'),
        el('span', {text: t('inc_unavailable', {reason: S.reason || t('inc_no_reason')})})]));
    } else {
      S.points.forEach(function (p) { P.page.appendChild(pointCard(p)); });
      P.page.appendChild(allowedCard());
    }
    P.page.appendChild(pipedCard());
    P.page.appendChild(indexCard());
    drawIndex();
  }

  FP.view('tool:web_includes', function () {
    var tool = FP.tools.web_includes;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    P.S = null;
    P.busy = false;
    var body = FP.frame({title: tool.label, desc: t('inc_desc'), cls: 'fp-mail fp-inc-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    P.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'webApacheIncludes').then(function (r) {
      if (P.page !== body) { return; }
      P.S = clean(r);
      render();
    }, function (err) {
      if (P.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

/* freePanel IP addresses (#/tool/server_ips), the admin panel's page for the server's addresses (docs/api.md,
   "Server"): each address on the server's network cards, whether it is the main one or a private one, and the sites
   set to it. An address freePanel added can be taken away here, a further address can be added to a card, and an
   account can be given one of the server's IPv4 addresses for its sites (and back), with its mail sent from it if wanted
   (fp-mailip.js, which also draws the card that allows that on the whole server). Behind NAT the router's public
   address is set here, and shown as the main one beside the address it is forwarded to. What the server sends is drawn
   as text, and an address that does not look like one is left out. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var ADDR_RE = /^[0-9a-fA-F:.]{2,45}$/;
  var USER_RE = /^[A-Za-z0-9_.@-]{1,60}$/;
  var CARD_RE = /^[A-Za-z0-9_.:@-]{1,32}$/;
  var V4_RE = /^[0-9]{1,3}(\.[0-9]{1,3}){3}$/;
  var BACKENDS = {networkmanager: 'ipw_backend_networkmanager', networkd: 'ipw_backend_networkd'};
  var V = null;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  function count(v) { return typeof v === 'number' && isFinite(v) && v > 0 ? Math.floor(v) : 0; }
  function sites(list) {
    return (Array.isArray(list) ? list : []).filter(function (s) { return s && typeof s.domain === 'string' && s.domain; })
      .map(function (s) { return {domain: str(s.domain, 253), account: str(s.account, 64)}; });
  }
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    return {
      ips: (Array.isArray(r.ips) ? r.ips : []).filter(function (v) { return v && typeof v.address === 'string' && ADDR_RE.test(v.address); })
        .map(function (v) {
          return {address: v.address, six: v.address.indexOf(':') >= 0, card: str(v.interface, 32), main: v.main === true, priv: v.private === true,
            removable: v.removable === true, reserved: v.reserved === true, sites: sites(v.sites), more: count(v.sites_more),
            pub: typeof v.public === 'string' && ADDR_RE.test(v.public) ? v.public : '', pubMain: v.public_main === true};
        }),
      shared: count(r.shared_sites),
      missing: (Array.isArray(r.missing) ? r.missing : []).filter(function (v) { return v && typeof v.address === 'string' && ADDR_RE.test(v.address); })
        .map(function (v) { return {address: v.address, sites: sites(v.sites), more: count(v.sites_more)}; })
    };
  }

  /* the sites of one address: their names, each with its account, and how many more the server did not list */
  function siteList(list, more, none) {
    if (!list.length && !more) { return [el('span', {class: 'fp-muted', text: none})]; }
    var items = list.map(function (s) {
      return el('li', null, [el('span', {class: 'fp-ip-domain', text: s.domain}), s.account ? el('span', {class: 'fp-muted fp-ip-acct', text: ' ' + t('ip_site_of', {account: s.account})}) : null]);
    });
    if (more) { items.push(el('li', {class: 'fp-muted', text: t('ip_more', {n: more})})); }
    return [el('ul', {class: 'fp-ip-sites'}, items)];
  }
  /* the Actions column is there only while an address can be taken away */
  function row(v, acts) {
    var pills = [];
    /* behind NAT the main address is the router's public one: it is shown first, with the address it reaches below */
    var nat = Boolean(v.pub && v.pubMain && v.main);
    if (v.main) { pills.push(el('span', {class: 'sig-pill sig-pill--accent', text: t('ip_main')})); }
    if (nat) { pills.push(el('span', {class: 'sig-pill', 'data-fp-nat': '', text: t('ip_nat_pill')})); }
    if (v.priv && !nat) { pills.push(el('span', {class: 'sig-pill', text: t('ip_private')})); }
    if (v.removable) { pills.push(el('span', {class: 'sig-pill', text: t('ipw_added_pill')})); }
    if (v.reserved) { pills.push(el('span', {class: 'sig-pill', 'data-fp-reserved': '', text: t('ip_reserved')})); }
    var cells = [
      el('th', {scope: 'row'}, [el('span', {class: 'sig-mono fp-ip-addr', text: nat ? v.pub : v.address}), pills.length ? el('span', {class: 'fp-ip-pills'}, pills) : null,
        v.pub ? el('span', {class: 'fp-muted fp-ip-nat', 'data-fp-nat-line': '', text: nat ? t('ip_nat_reaches', {address: v.address}) : t('ip_nat_from', {address: v.pub})}) : null]),
      el('td', {text: t(v.six ? 'ip_v6' : 'ip_v4')}),
      el('td', null, [v.card ? el('span', {class: 'sig-mono', text: v.card}) : el('span', {class: 'fp-muted', text: '—'})]),
      el('td', {'data-fp-sites': ''}, siteList(v.sites, v.more, t('ip_no_sites')))];
    if (acts) {
      cells.push(el('td', {class: 'fp-mail-acts'}, [v.removable ? el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'ip-remove',
        'aria-label': t('ipw_remove_named', {address: v.address}), text: t('ipw_remove')}) : null]));
    }
    return el('tr', {'data-fp-ip': v.address, 'data-fp-public': v.pub || null}, cells);
  }
  function head(cols, acts) {
    var ths = cols.map(function (c) { return el('th', {scope: 'col', text: c}); });
    if (acts) { ths.push(el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])); }
    return el('thead', null, [el('tr', null, ths)]);
  }
  function table(heading, cols, rows, acts) {
    return el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': heading}, [
      el('table', {class: 'sig-table fp-mail-table fp-srv-table fp-ip-table'}, [head(cols, acts), el('tbody', null, rows)])]);
  }

  function addressCard() {
    var n = V.data.ips.length;
    var acts = V.data.ips.some(function (v) { return v.removable; });
    var parts = [el('p', {class: 'fp-muted', text: t('ip_what')}), M.errorLine(), M.statusLine()];
    if (!n) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('ip_none')}));
    } else {
      parts.push(el('p', {class: 'fp-srv-sum', 'data-fp-sum': '', text: t(n === 1 ? 'ip_sum_1' : 'ip_sum', {n: n})}),
        table('fp-ip-h', [t('ip_address'), t('ip_type'), t('ip_card'), t('ip_sites')], V.data.ips.map(function (v) { return row(v, acts); }), acts),
        el('p', {class: 'fp-muted fp-ip-legend', text: t('ip_legend') + (acts ? ' ' + t('ipw_legend') : '')}));
    }
    if (V.data.shared) { parts.push(el('p', {class: 'fp-muted', 'data-fp-shared': '', text: t(V.data.shared === 1 ? 'ip_shared_1' : 'ip_shared', {n: V.data.shared})})); }
    parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'refresh', text: t('status_again')})]));
    return M.card('fp-ip-h', t('ip_title'), parts, 'fp-ip');
  }
  function missingCard() {
    if (!V.data.missing.length) { return null; }
    var rows = V.data.missing.map(function (v) {
      return el('tr', {'data-fp-missing': v.address}, [el('th', {scope: 'row'}, [el('span', {class: 'sig-mono fp-ip-addr', text: v.address})]),
        el('td', {'data-fp-sites': ''}, siteList(v.sites, v.more, t('ip_no_sites')))]);
    });
    return M.card('fp-ipm-h', t('ip_missing_title'), [el('p', {class: 'fp-warn-line', 'data-fp-missing-note': '', text: t('ip_missing_what')}),
      table('fp-ipm-h', [t('ip_address'), t('ip_sites')], rows)], 'fp-ipm');
  }
  function card() { return V.page.querySelector('.fp-ip'); }

  /* the cards of addresses are drawn again as the list changes; the two forms stay as they are, with what was typed */
  function redraw(focus) {
    var old = card();
    var fresh = addressCard();
    if (old) { old.replaceWith(fresh); } else { V.page.insertBefore(fresh, V.page.firstChild); }
    var was = V.page.querySelector('.fp-ipm');
    var m = missingCard();
    if (was && m) { was.replaceWith(m); } else if (was) { was.remove(); } else if (m) { fresh.after(m); }
    cardOptions();
    pickOptions();
    var target = focus ? V.page.querySelector(focus) : null;
    if (target) { target.focus(); }
  }
  function load() {
    var mine = V;
    return FP.call('get', 'serverIps').then(function (r) {
      if (V !== mine) { return null; }
      V.data = clean(r);
      return V.data;
    });
  }

  /* ---- add an address ---- */
  function cards() {
    var seen = [];
    V.data.ips.forEach(function (v) { if (v.card && CARD_RE.test(v.card) && seen.indexOf(v.card) < 0) { seen.push(v.card); } });
    return seen;
  }
  function cardOptions() {
    var sel = V.page.querySelector('#fp-ipw-card');
    if (!sel) { return; }
    var keep = sel.value;
    sel.textContent = '';
    sel.appendChild(el('option', {value: '', text: t('ipw_card_auto')}));
    cards().forEach(function (c) { sel.appendChild(el('option', {value: c, text: c, selected: c === keep ? true : null})); });
  }
  function wholeIn(v, lo, hi) { return /^[0-9]{1,3}$/.test(v) && Number(v) >= lo && Number(v) <= hi; }
  function addedLine(r, asked) {
    var address = typeof r.address === 'string' && ADDR_RE.test(r.address) ? r.address : asked;
    var prefix = typeof r.prefix === 'number' && r.prefix >= 1 && r.prefix <= 128 && r.prefix === Math.floor(r.prefix) ? '/' + r.prefix : '';
    var on = typeof r.interface === 'string' && CARD_RE.test(r.interface) ? r.interface : '—';
    var by = BACKENDS[r.backend];
    return by ? t('ipw_added_by', {address: address + prefix, card: on, backend: t(by)}) : t('ipw_added', {address: address + prefix, card: on});
  }
  function addCard() {
    var address = el('input', {class: 'sig-input', id: 'fp-ipw-address', name: 'address', type: 'text', maxlength: '45', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none'});
    var prefix = el('input', {class: 'sig-input', id: 'fp-ipw-prefix', name: 'prefix', type: 'text', inputmode: 'numeric', maxlength: '3', autocomplete: 'off'});
    var on = el('select', {class: 'sig-select', id: 'fp-ipw-card', name: 'interface'});
    var warn = el('p', {class: 'fp-warn-line', role: 'status', 'data-fp-warning': '', hidden: true});
    var form = el('form', {class: 'fp-form fp-mail-form fp-ipw-form', novalidate: ''}, [M.errorLine(), M.statusLine(), warn,
      M.field('fp-ipw-address', t('ipw_f_address'), address, t('ipw_f_address_hint')),
      M.field('fp-ipw-prefix', t('ipw_f_prefix'), prefix, t('ipw_f_prefix_hint')),
      M.field('fp-ipw-card', t('ipw_f_card'), on, t('ipw_f_card_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('ipw_add')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      warn.hidden = true;
      warn.textContent = '';
      var a = address.value.trim();
      var p = prefix.value.trim();
      if (!a) { M.fieldError(form, address, t('ipw_address_empty')); return; }
      if (!ADDR_RE.test(a)) { M.fieldError(form, address, t('ipw_address_bad')); return; }
      var six = a.indexOf(':') >= 0;
      if (p && !(six ? wholeIn(p, 48, 128) : wholeIn(p, 8, 32))) { M.fieldError(form, prefix, t(six ? 'ipw_prefix_bad6' : 'ipw_prefix_bad4')); return; }
      var body = {address: a};
      if (p) { body.prefix = Number(p); }
      if (on.value) { body.interface = on.value; }
      var mine = V;
      UI.setBusy(b, true);
      FP.call('post', 'serverIpAdd', body).then(function (r) {
        if (V !== mine) { return; }
        UI.setBusy(b, false);
        address.value = '';
        prefix.value = '';
        on.value = '';
        M.say(form, addedLine(r && typeof r === 'object' ? r : {}, a));
        var w = r && typeof r.warning === 'string' ? r.warning.slice(0, 300) : '';
        if (w) { warn.textContent = w; warn.hidden = false; }
        load().then(function () { if (V === mine) { redraw(); } }, function () { /* the list stays as it was; Check again reads it */ });
      }, function (err) {
        if (V !== mine) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return M.card('fp-ipw-add-h', t('ipw_add_title'), [el('p', {class: 'fp-muted', text: t('ipw_add_what')}), form], 'fp-ipw-add');
  }

  /* ---- take an address away ---- */
  function remove(address, button) {
    var mine = V;
    UI.setBusy(button, true);
    FP.call('del', 'serverIp', undefined, {address: address}).then(function () {
      if (V !== mine) { return; }
      var done = function () { redraw('#fp-ip-h'); M.say(card(), t('ipw_removed', {address: address})); };
      load().then(function () { if (V === mine) { done(); } }, function () {
        if (V !== mine) { return; }
        V.data.ips = V.data.ips.filter(function (v) { return v.address !== address; });
        done();
      });
    }, function (err) {
      if (V !== mine) { return; }
      redraw();
      var again = V.page.querySelector('tr[data-fp-ip="' + address + '"] [data-fp-act="ip-remove"]');
      UI.showError(card(), err.message);
      if (again) { again.focus(); }
    });
  }

  /* ---- an address for one account ---- */
  function spare() {
    var who = V.acct ? V.acct.user : '';
    return V.data.ips.filter(function (v) { return !v.six && !v.main; }).map(function (v) {
      var other = v.sites.filter(function (s) { return s.account && s.account !== who; })[0];
      return {address: v.address, priv: v.priv, other: other ? other.account : '', reserved: v.reserved};
    }).filter(function (c) { return !c.reserved; });
  }
  function pickOptions() {
    var sel = V.page.querySelector('#fp-ipw-pick');
    if (!sel || !V.acct) { return; }
    var keep = sel.value || V.acct.ip || '';
    sel.textContent = '';
    spare().forEach(function (c) {
      var note = c.other ? t('ipw_in_use', {account: c.other}) : (c.priv ? t('ip_private').toLowerCase() : '');
      sel.appendChild(el('option', {value: c.address, text: c.address + (note ? ' (' + note + ')' : ''), disabled: c.other ? true : null, selected: c.address === keep && !c.other ? true : null}));
    });
  }
  function dnsLine(d) {
    if (!d || typeof d !== 'object') { return {text: '', error: ''}; }
    var parts = [];
    [['records', 'ipw_dns_updated'], ['dropped', 'ipw_dns_dropped'], ['restored', 'ipw_dns_restored']].forEach(function (k) {
      var n = count(d[k[0]]);
      if (n) { parts.push(t(n === 1 ? k[1] + '_1' : k[1], {n: n})); }
    });
    return {text: parts.length ? t('ipw_dns', {list: parts.join(', ')}) : t('ipw_dns_none'), error: typeof d.error === 'string' ? d.error.slice(0, 300) : ''};
  }
  function acctLine(r, asked) {
    var ip = typeof r.ip === 'string' && ADDR_RE.test(r.ip) ? r.ip : null;
    var who = V.acct.user;
    var said = !r.changed ? t(ip ? 'ipw_same_set' : 'ipw_same_cleared', {account: who, address: ip || asked}) :
      t(ip ? 'ipw_set' : 'ipw_cleared', {account: who, address: ip || asked});
    var n = count(r.sites);
    if (r.changed && n) { said += ' ' + t(n === 1 ? 'ipw_sites_1' : 'ipw_sites', {n: n}); }
    var dns = r.changed ? dnsLine(r.dns) : {text: '', error: ''};
    return {text: said + (dns.text ? ' ' + dns.text : ''), error: dns.error ? t('ipw_dns_error', {error: dns.error}) : '', ip: ip};
  }
  /* what is asked of the account's address: the line about it, the choice of address, and the way back to the shared one */
  function acctShow(note, focus) {
    var out = V.page.querySelector('[data-fp-acct-out]');
    out.textContent = '';
    if (!V.acct) { if (V.mail) { V.mail.show(''); } return; }
    var who = V.acct.user;
    var warn = el('p', {class: 'fp-warn-line', role: 'status', 'data-fp-warning': '', hidden: note && note.error ? null : true, text: note ? note.error : ''});
    out.appendChild(M.errorLine());
    out.appendChild(el('p', {class: 'fp-ok-line', role: 'status', 'data-fp-status': '', text: note ? note.text : ''}));
    out.appendChild(warn);
    out.appendChild(el('p', {'data-fp-acct-now': '', text: V.acct.ip ? t('ipw_acct_own', {account: who, address: V.acct.ip}) : t('ipw_acct_shared', {account: who})}));
    var pick = el('select', {class: 'sig-select', id: 'fp-ipw-pick', name: 'address'});
    var free = spare().some(function (c) { return !c.other; });
    var parts = [];
    if (free) {
      parts.push(M.field('fp-ipw-pick', t('ipw_f_pick'), pick, t('ipw_f_pick_hint')));
    } else {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-no-spare': '', text: t('ipw_no_spare', {account: who})}));
    }
    var acts = [];
    if (free) { acts.push(el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('ipw_give')})); }
    if (V.acct.ip) { acts.push(el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'acct-shared', text: t('ipw_back')})); }
    if (acts.length) { parts.push(el('div', {class: 'fp-actions'}, acts)); }
    var form = el('form', {class: 'fp-form fp-mail-form fp-ipw-give', novalidate: ''}, parts);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(out);
      if (!b || !pick.value) { return; }
      changeAccount(form, b, 'put', pick.value);
    });
    out.appendChild(form);
    if (V.mail) { V.mail.show(who); }
    pickOptions();
    var target = focus ? out.querySelector(focus) : null;
    if (target) { target.focus(); }
  }
  function changeAccount(form, button, how, address) {
    var mine = V;
    var who = V.acct.user;
    UI.setBusy(button, true);
    var p = how === 'put' ? FP.call('put', 'acctIpSet', {address: address}, who) : FP.call('del', 'acctIpSet', undefined, who);
    p.then(function (r) {
      if (V !== mine || V.acct.user !== who) { return; }
      var line = acctLine(r && typeof r === 'object' ? r : {}, address || '');
      V.acct.ip = line.ip;
      var finish = function () { if (V === mine) { redraw(); acctShow(line, how === 'put' ? '#fp-ipw-pick' : '[data-fp-acct-now]'); } };
      load().then(finish, finish);
    }, function (err) {
      if (V !== mine) { return; }
      UI.setBusy(button, false);
      UI.showError(V.page.querySelector('[data-fp-acct-out]'), err.message);
    });
  }
  function acctCard() {
    var user = el('input', {class: 'sig-input', id: 'fp-ipw-user', name: 'username', type: 'text', maxlength: '60', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none'});
    var form = el('form', {class: 'fp-form fp-mail-form fp-ipw-lookup', novalidate: ''}, [M.errorLine(),
      M.field('fp-ipw-user', t('ipw_f_user'), user, t('ipw_f_user_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary fp-submit', type: 'submit', text: t('ipw_show')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var who = user.value.trim();
      if (!who) { M.fieldError(form, user, t('ipw_user_empty')); return; }
      if (!USER_RE.test(who)) { M.fieldError(form, user, t('ipw_user_bad')); return; }
      var mine = V;
      UI.setBusy(b, true);
      FP.call('get', 'acctIp', undefined, who).then(function (r) {
        if (V !== mine) { return; }
        UI.setBusy(b, false);
        V.acct = {user: who, ip: r && typeof r.ip === 'string' && ADDR_RE.test(r.ip) ? r.ip : null};
        acctShow(null, '#fp-ipw-pick');
      }, function (err) {
        if (V !== mine) { return; }
        UI.setBusy(b, false);
        V.acct = null;
        acctShow(null);
        M.failed(form, err);
      });
    });
    return M.card('fp-ipw-acct-h', t('ipw_acct_title'), [el('p', {class: 'fp-muted', text: t('ipw_acct_what')}), form, el('div', {class: 'fp-ipw-out', 'data-fp-acct-out': ''})], 'fp-ipw-acct');
  }

  /* ---- the public address behind NAT: the router's address, the one on this server it reaches, and (rarely) IPv6 ---- */
  function cleanPublic(r) {
    r = r && typeof r === 'object' ? r : {};
    var a = function (v) { return typeof v === 'string' && ADDR_RE.test(v) ? v : ''; };
    return {v4: a(r.public_ipv4), priv: a(r.private_ipv4), v6: a(r.public_ipv6), via: a(r.via_ipv4), available: r.available !== false,
      ifs: (Array.isArray(r.interface_ipv4) ? r.interface_ipv4 : []).filter(function (x) { return typeof x === 'string' && V4_RE.test(x); }).slice(0, 64),
      warnings: (Array.isArray(r.warnings) ? r.warnings : []).filter(function (x) { return typeof x === 'string'; }).map(function (x) { return x.slice(0, 300); }).slice(0, 8),
      from: a(r.migrate_from), map: mapPairs(r.map)};
  }
  /* the mapping table of a 1:1 NAT, as pairs in order of the address on this server */
  function mapPairs(m) {
    if (!m || typeof m !== 'object' || Array.isArray(m)) { return []; }
    return Object.keys(m).filter(function (k) { return V4_RE.test(k) && typeof m[k] === 'string' && V4_RE.test(m[k]); }).slice(0, 256)
      .sort(function (x, y) { return x.split('.').map(Number).reduce(function (d, n, i) { return d || n - Number(y.split('.')[i]); }, 0); })
      .map(function (k) { return [k, m[k]]; });
  }
  function privateMain() {
    var m = V.data ? V.data.ips.filter(function (v) { return v.main && !v.six; })[0] : null;
    return m && m.priv && !m.pub ? m.address : '';
  }
  /* what the setting is now: the ports to forward and, while new zones point elsewhere, the way to the IP migration */
  function publicNotes(box, p) {
    box.textContent = '';
    if (!p.v4 && privateMain()) { box.appendChild(el('p', {class: 'fp-warn-line', 'data-fp-nat-hint': '', text: t('pip_hint_private', {address: privateMain()})})); }
    if (p.from) {
      box.appendChild(el('p', {class: 'fp-warn-line', 'data-fp-migrate': '', text: t('pip_migrate', {from: p.from, to: p.v4})}));
      box.appendChild(el('p', null, [el('a', {href: '#/tool/ip_migration', text: t('pip_to_migration')})]));
    }
    if (p.v4) {
      box.appendChild(el('p', {class: 'fp-muted', 'data-fp-ports': '', text: t('pip_ports', {address: p.via || p.priv || '—'})}));
      box.appendChild(el('p', {class: 'fp-muted', text: t('pip_hairpin')}));
    }
  }
  function publicCard() {
    var v4 = el('input', {class: 'sig-input', id: 'fp-pip-v4', name: 'public_ipv4', type: 'text', maxlength: '15', inputmode: 'decimal', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none'});
    var priv = el('select', {class: 'sig-select', id: 'fp-pip-private', name: 'private_ipv4'});
    var v6 = el('input', {class: 'sig-input', id: 'fp-pip-v6', name: 'public_ipv6', type: 'text', maxlength: '45', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none'});
    var map = el('textarea', {class: 'sig-input fp-pip-map', id: 'fp-pip-map', name: 'map', rows: '3', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none'});
    var warn = el('p', {class: 'fp-warn-line', role: 'status', 'data-fp-warning': '', hidden: true});
    var notes = el('div', {'data-fp-pip-notes': ''});
    var clear = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'pip-clear', hidden: true, text: t('pip_clear')});
    var form = el('form', {class: 'fp-form fp-mail-form fp-pip-form', novalidate: ''}, [M.errorLine(), M.statusLine(), warn,
      M.field('fp-pip-v4', t('pip_f_v4'), v4, t('pip_f_v4_hint')),
      M.field('fp-pip-private', t('pip_f_private'), priv, t('pip_f_private_hint')),
      M.field('fp-pip-v6', t('pip_f_v6'), v6, t('pip_f_v6_hint')),
      M.field('fp-pip-map', t('pip_f_map'), map, t('pip_f_map_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('pip_save')}), clear])]);
    var body = el('div', {'data-fp-pip-body': ''}, [el('p', {class: 'fp-muted', text: t('loading')})]);
    var mine = V;
    var show = function (p) {
      V.pip = p;
      v4.value = p.v4;
      v6.value = p.v6;
      map.value = p.map.map(function (x) { return x[0] + ' ' + x[1]; }).join('\n');
      priv.textContent = '';
      priv.appendChild(el('option', {value: '', text: t('pip_private_auto')}));
      p.ifs.forEach(function (x) { priv.appendChild(el('option', {value: x, text: x, selected: x === p.priv ? true : null})); });
      clear.hidden = !(p.v4 || p.v6 || p.map.length);
      publicNotes(notes, p);
      warn.textContent = p.warnings.length ? p.warnings.map(function (w) { return t('pip_warning', {warning: w}); }).join(' ') : '';
      warn.hidden = !p.warnings.length;
    };
    var send = function (b, want, cleared) {
      UI.setBusy(b, true);
      FP.call('put', 'serverPublicIp', want).then(function (r) {
        if (V !== mine) { return; }
        UI.setBusy(b, false);
        var p = cleanPublic(r);
        show(p);
        var n = p.map.length;
        M.say(form, cleared ? t('pip_cleared') : (p.v4 || p.v6) ? t('pip_saved', {address: p.v4 || p.v6, via: p.via || '—'}) : t(n === 1 ? 'pip_saved_map_1' : 'pip_saved_map', {n: n}));
        load().then(function () { if (V === mine) { redraw(); publicNotes(notes, V.pip); } }, function () { /* Check again reads it */ });
      }, function (err) {
        if (V !== mine) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    };
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      warn.hidden = true;
      var a4 = v4.value.trim();
      var a6 = v6.value.trim();
      if (a4 && !V4_RE.test(a4)) { M.fieldError(form, v4, t('pip_v4_bad')); return; }
      if (a6 && (!ADDR_RE.test(a6) || a6.indexOf(':') < 0)) { M.fieldError(form, v6, t('pip_v6_bad')); return; }
      var pairs = {};
      var seen = {};
      var lines = map.value.split('\n');
      for (var i = 0; i < lines.length; i++) {
        var f = lines[i].trim().split(/\s+/).filter(Boolean);
        if (!f.length) { continue; }
        if (f.length !== 2 || !V4_RE.test(f[0]) || !V4_RE.test(f[1])) { M.fieldError(form, map, t('pip_map_bad', {line: i + 1})); return; }
        for (var j = 0; j < 2; j++) {
          if (seen[f[j]] || f[j] === a4) { M.fieldError(form, map, t('pip_map_twice', {line: i + 1, address: f[j]})); return; }
          seen[f[j]] = true;
        }
        pairs[f[0]] = f[1];
      }
      var none = !a4 && !a6 && !Object.keys(pairs).length;
      send(b, {public_ipv4: a4, private_ipv4: a4 ? priv.value : '', public_ipv6: a6, map: pairs}, none);
    });
    clear.addEventListener('click', function () {
      if (clear.disabled) { return; }
      UI.showError(form, '');
      M.say(form, '');
      send(clear, {public_ipv4: '', private_ipv4: '', public_ipv6: '', map: {}}, true);
    });
    FP.call('get', 'serverPublicIp').then(function (r) {
      if (V !== mine) { return; }
      var p = cleanPublic(r);
      body.textContent = '';
      if (!p.available) {
        body.appendChild(el('p', {class: 'fp-muted', 'data-fp-pip-off': '', text: t('pip_unavailable')}));
        return;
      }
      body.appendChild(form);
      body.appendChild(notes);
      show(p);
    }, function (err) {
      if (V !== mine) { return; }
      body.textContent = '';
      body.appendChild(M.errorLine());
      UI.showError(body, err.message);
    });
    return M.card('fp-pip-h', t('pip_title'), [el('p', {class: 'fp-muted', text: t('pip_what')}), body], 'fp-pip');
  }

  /* ---- reserved addresses: one per line, a note after the first space ---- */
  function reservedText(r) {
    var list = r && Array.isArray(r.ips) ? r.ips : [];
    return list.filter(function (v) { return v && typeof v.address === 'string' && ADDR_RE.test(v.address); })
      .map(function (v) { var n = str(v.note, 200); return v.address + (n ? ' ' + n : ''); }).join('\n');
  }
  function reservedAbsent(r) {
    var list = r && Array.isArray(r.ips) ? r.ips : [];
    return list.filter(function (v) { return v && typeof v.address === 'string' && ADDR_RE.test(v.address) && v.present === false; })
      .map(function (v) { return t('ipr_absent', {address: v.address}); }).join(' ');
  }
  function reservedCard() {
    var area = el('textarea', {class: 'sig-input fp-ipr-list', id: 'fp-ipr-list', name: 'reserved', rows: '5', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none'});
    var warn = el('p', {class: 'fp-warn-line', role: 'status', 'data-fp-warning': '', hidden: true});
    var form = el('form', {class: 'fp-form fp-mail-form fp-ipr-form', novalidate: ''}, [M.errorLine(), M.statusLine(), warn,
      M.field('fp-ipr-list', t('ipr_f_list'), area, t('ipr_f_list_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('ipr_save')})])]);
    var show = function (r) { area.value = reservedText(r); var a = reservedAbsent(r); warn.textContent = a; warn.hidden = !a; };
    var mine = V;
    FP.call('get', 'serverReservedIps').then(function (r) { if (V === mine) { show(r); } }, function (err) { if (V === mine) { UI.showError(form, err.message); } });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var ips = [];
      var lines = area.value.split('\n');
      for (var i = 0; i < lines.length; i++) {
        var line = lines[i].trim();
        if (!line) { continue; }
        var sp = line.search(/\s/);
        var a = sp < 0 ? line : line.slice(0, sp);
        if (!ADDR_RE.test(a)) { M.fieldError(form, area, t('ipr_bad', {line: i + 1, value: a.slice(0, 45)})); return; }
        ips.push({address: a, note: sp < 0 ? '' : line.slice(sp + 1).trim().slice(0, 200)});
      }
      if (ips.length > 256) { M.fieldError(form, area, t('ipr_too_many')); return; }
      UI.setBusy(b, true);
      FP.call('put', 'serverReservedIps', {ips: ips}).then(function (r) {
        if (V !== mine) { return; }
        UI.setBusy(b, false);
        show(r);
        M.say(form, t('ipr_saved', {n: r && Array.isArray(r.ips) ? r.ips.length : ips.length}));
        load().then(function () { if (V === mine) { redraw(); } }, function () { /* Check again reads it */ });
      }, function (err) {
        if (V !== mine) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return M.card('fp-ipr-h', t('ipr_title'), [el('p', {class: 'fp-muted', text: t('ipr_what')}), form], 'fp-ipr');
  }

  function refresh(b) {
    var mine = V;
    UI.setBusy(b, true);
    load().then(function () {
      if (V !== mine) { return; }
      redraw('[data-fp-act="refresh"]');
      M.say(card(), t('status_checked', {when: new Date().toLocaleTimeString('en', {timeStyle: 'short'})}));
    }, function (err) {
      if (V !== mine) { return; }
      UI.setBusy(b, false);
      UI.showError(card(), err.message);
      b.focus();
    });
  }
  function onClick(e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !V || !V.page.contains(b) || b.disabled) { return; }
    var act = b.getAttribute('data-fp-act');
    var tr = b.closest('tr[data-fp-ip]');
    var address = tr ? tr.getAttribute('data-fp-ip') : '';
    if (act === 'refresh') {
      refresh(b);
    } else if (act === 'ip-remove') {
      M.confirmIn(b.parentNode, t('ipw_remove_ask', {address: address}), 'ip-remove-yes', t('ipw_remove'));
    } else if (act === 'confirm-no' && tr) {
      redraw('tr[data-fp-ip="' + address + '"] [data-fp-act="ip-remove"]');
    } else if (act === 'ip-remove-yes' && tr) {
      remove(address, b);
    } else if (act === 'acct-shared' && V.acct) {
      var out = b.closest('[data-fp-acct-out]');
      UI.showError(out, '');
      M.say(out, '');
      changeAccount(b.closest('form'), b, 'del', '');
    }
  }
  document.addEventListener('click', onClick);

  FP.view('tool:server_ips', function () {
    var tool = FP.tools.server_ips;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('ip_desc'), cls: 'fp-mail fp-srv fp-ip-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    V = {page: page, data: null, acct: null, pip: null};
    var mine = V;
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    load().then(function () {
      if (V !== mine) { return; }
      page.textContent = '';
      page.appendChild(addressCard());
      var m = missingCard();
      if (m) { page.appendChild(m); }
      page.appendChild(publicCard());
      page.appendChild(addCard());
      page.appendChild(reservedCard());
      page.appendChild(acctCard());
      if (FP.mailIp) {
        V.mail = FP.mailIp.card();
        page.appendChild(V.mail.node);
        page.appendChild(FP.mailIp.serverCard());
      }
      cardOptions();
    }, function (err) {
      if (V !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

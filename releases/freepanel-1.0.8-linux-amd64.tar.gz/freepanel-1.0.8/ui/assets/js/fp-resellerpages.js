/* freePanel reseller pages of the administrators' panel (docs/api.md, "Resellers"): Reseller branding (#/tool/reseller_branding: the name,
   help link and logo a reseller's own customers see instead of the host's; the admin works on any reseller, a reseller on itself and, without
   the right, only sees what is set) and Reseller addresses (#/tool/reseller_ips: the server's addresses the admin has given a reseller to
   put on its own accounts; the admin chooses them, a reseller sees its own). What the server sends is drawn as text. The page pieces come
   from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var USER_RE = /^[a-z][a-z0-9]{0,15}$/;
  var IPV4_RE = /^(?:25[0-5]|2[0-4]\d|1?\d?\d)(?:\.(?:25[0-5]|2[0-4]\d|1?\d?\d)){3}$/;
  var MAX_LOGO = 256 * 1024;
  var MAX_SIDE = 1024;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function isAdmin() { return FP.session.user.role === 'admin'; }
  function frame(id) {
    var tool = FP.tools[id];
    if (!tool || FP.realm !== 'admin') { FP.views['not-found']({view: 'not-found'}); return null; }
    var g = FP.group(tool.group);
    return FP.frame({title: tool.label, desc: t(id + '_desc' + (isAdmin() ? '' : '_reseller')), cls: 'fp-mail fp-rp fp-rp-' + id,
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
  }
  /* the resellers the admin may choose from, by name */
  function resellers() {
    return FP.call('get', 'resellers').then(function (r) {
      return (r && Array.isArray(r.resellers) ? r.resellers : []).map(function (x) { return str(x && x.username, 20); })
        .filter(function (n) { return USER_RE.test(n); }).sort();
    });
  }
  /* the choice of a reseller (the admin's); the page for a reseller starts with itself */
  function picker(id, names, current, onPick) {
    var select = el('select', {class: 'sig-select', id: id, name: 'reseller'}, names.map(function (n) {
      return el('option', {value: n, selected: n === current ? true : null, text: n});
    }));
    select.addEventListener('change', function () { onPick(select.value); });
    return M.card(id + '-h', t('rp_pick_title'), [M.field(id, t('rp_pick'), select, t('rp_pick_hint'))], 'fp-rp-pick');
  }
  function listFail(body, label, err) {
    body.textContent = '';
    body.appendChild(FP.empty(label, err.message));
  }

  /* ================= Reseller branding ================= */
  var B = {page: null, who: '', view: null, names: []};
  function supportOk(u) {
    return !u || /^https:\/\/[^\s"'<>]+$/.test(u) || /^mailto:[^\s"'<>,;?&@]+@[^\s"'<>,;?&@]+$/.test(u);
  }
  function cleanBrand(r) {
    r = r && typeof r === 'object' ? r : {};
    return {name: str(r.name, 64), url: supportOk(str(r.support_url, 2048)) ? str(r.support_url, 2048) : '', logo: r.logo === true, allowed: r.allowed === true};
  }
  function logoUrl() { return '/api/v1/resellers/' + encodeURIComponent(B.who) + '/branding/logo?v=' + Date.now(); }
  /* may the viewer change it: the admin always, a reseller with the right */
  function canChange() { return isAdmin() || B.view.allowed; }

  function bNote() {
    var parts = [el('p', {class: 'fp-muted', text: t(isAdmin() ? 'rbr_what_admin' : 'rbr_what', {name: B.who})})];
    if (!B.view.allowed) { parts.push(el('p', {class: 'fp-warn-line', 'data-fp-not-allowed': '', text: t(isAdmin() ? 'rbr_off_admin' : 'rbr_off', {name: B.who})})); }
    return M.card('fp-rb-note-h', t('rbr_note_title'), parts, 'fp-rb-note');
  }
  /* what is set, for a reseller that may not change it */
  function bFacts() {
    var rows = [el('dt', {class: 'fp-rp-k', text: t('rbr_name')}), el('dd', {class: 'fp-rp-v', text: B.view.name || t('rbr_unset')}),
      el('dt', {class: 'fp-rp-k', text: t('rbr_url')}), el('dd', {class: 'fp-rp-v', text: B.view.url || t('rbr_unset')}),
      el('dt', {class: 'fp-rp-k', text: t('rbr_logo')}), el('dd', {class: 'fp-rp-v', text: B.view.logo ? t('rbr_logo_set') : t('rbr_unset')})];
    var parts = [el('dl', {class: 'fp-rp-vals'}, rows)];
    if (B.view.logo) { parts.push(el('div', {class: 'fp-brand-preview'}, [el('img', {src: logoUrl(), alt: t('rbr_logo_alt', {name: B.who}), 'data-fp-brand-preview': ''})])); }
    return M.card('fp-rb-facts-h', t('rbr_facts_title'), parts, 'fp-rb-facts');
  }
  function bNameCard() {
    var name = el('input', {class: 'sig-input', id: 'fp-rb-name', name: 'name', type: 'text', maxlength: '64', autocomplete: 'off', value: B.view.name, placeholder: t('rbr_name_placeholder')});
    var url = el('input', {class: 'sig-input', id: 'fp-rb-url', name: 'support_url', type: 'text', inputmode: 'url', maxlength: '2048', autocomplete: 'off',
      spellcheck: 'false', autocapitalize: 'none', value: B.view.url, placeholder: 'https://help.example.com'});
    var form = el('form', {class: 'fp-form fp-mail-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-rb-name', t('rbr_name'), name, t('rbr_name_hint')), M.field('fp-rb-url', t('rbr_url'), url, t('rbr_url_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('rbr_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var body = {name: name.value.trim(), support_url: url.value.trim()};
      if (Array.from(body.name).length > 64 || /[\u0000-\u001f\u007f]/.test(body.name)) { M.fieldError(form, name, t('rbr_name_bad')); return; }   // eslint-disable-line no-control-regex -- printable characters only
      if (!supportOk(body.support_url)) { M.fieldError(form, url, t('rbr_url_bad')); return; }
      UI.setBusy(b, true);
      FP.call('put', 'resellerBranding', body, B.who).then(function (r) {
        UI.setBusy(b, false);
        B.view = cleanBrand(r);
        name.value = B.view.name;
        url.value = B.view.url;
        M.say(form, t('rbr_saved'));
      }, function (err) {
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return M.card('fp-rb-name-h', t('rbr_name_title'), [form], 'fp-rb-names');
  }
  /* the picture's size in pixels, where the browser can tell without showing it; null when it can't */
  function sides(file) {
    if (!window.createImageBitmap) { return Promise.resolve(null); }
    return window.createImageBitmap(file).then(function (bmp) {
      var s = {w: bmp.width, h: bmp.height};
      if (bmp.close) { bmp.close(); }
      return s;
    }, function () { return {bad: true}; });
  }
  function bLogoCard() {
    var file = el('input', {class: 'sig-input fp-brand-file', id: 'fp-rb-file', name: 'logo', type: 'file', accept: 'image/png,image/jpeg'});
    var parts = [M.errorLine(), M.statusLine()];
    if (B.view.logo) {
      parts.push(el('div', {class: 'fp-brand-preview'}, [el('img', {src: logoUrl(), alt: t('rbr_logo_alt', {name: B.who}), 'data-fp-brand-preview': ''})]));
    } else {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('rbr_logo_none')}));
    }
    var form = el('form', {class: 'fp-form fp-mail-form', novalidate: ''}, [
      M.field('fp-rb-file', B.view.logo ? t('rbr_logo_new') : t('rbr_logo_pick'), file, t('rbr_logo_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('rbr_logo_upload')}),
        B.view.logo ? el('span', {class: 'fp-mail-acts fp-brand-remove'}, [el('button', {class: 'sig-btn sig-btn--secondary fp-btn-danger-text', type: 'button',
          'data-fp-act': 'logo-remove', text: t('rbr_logo_remove')})]) : null])]);
    var card = M.card('fp-rb-logo-h', t('rbr_logo_title'), parts.concat([form]), 'fp-rb-logo');
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = form.querySelector('.fp-submit');
      if (b.disabled) { return; }
      UI.showError(card, '');
      M.say(card, '');
      file.removeAttribute('aria-invalid');
      var f = file.files && file.files[0];
      if (!f) { M.fieldError(card, file, t('rbr_logo_none_picked')); return; }
      if (f.type !== 'image/png' && f.type !== 'image/jpeg') { M.fieldError(card, file, t('rbr_logo_type')); return; }
      if (f.size > MAX_LOGO) { M.fieldError(card, file, t('rbr_logo_big')); return; }
      UI.setBusy(b, true);
      sides(f).then(function (s) {
        if (s && (s.bad || s.w > MAX_SIDE || s.h > MAX_SIDE)) {
          UI.setBusy(b, false);
          M.fieldError(card, file, s.bad ? t('rbr_logo_type') : t('rbr_logo_sides', {w: s.w, h: s.h}));
          return;
        }
        FP.call('put', 'resellerBrandingLogo', f, B.who).then(function () {
          B.view.logo = true;
          bRender();
          M.say(B.page.querySelector('.fp-rb-logo'), t('rbr_logo_done'));
          B.page.querySelector('#fp-rb-logo-h').focus();
        }, function (err) {
          UI.setBusy(b, false);
          M.fieldError(card, file, err.message);
        });
      });
    });
    return card;
  }
  function bResetCard() {
    var any = B.view.name || B.view.url || B.view.logo;
    var parts = [el('p', {class: 'fp-muted', text: t(isAdmin() ? 'rbr_reset_desc_admin' : 'rbr_reset_desc', {name: B.who})}), M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-mail-acts fp-rb-reset'}, [el('button', {class: 'sig-btn sig-btn--secondary fp-btn-danger-text', type: 'button', 'data-fp-act': 'reset',
        disabled: any ? null : true, text: t('rbr_reset')})])];
    if (!any) { parts.splice(1, 0, el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('rbr_reset_none')})); }
    return M.card('fp-rb-reset-h', t('rbr_reset_title'), parts, 'fp-rb-resetc');
  }
  function bRender() {
    B.page.textContent = '';
    if (isAdmin()) { B.page.appendChild(picker('fp-rb-pick', B.names, B.who, bLoad)); }
    B.page.appendChild(bNote());
    if (canChange()) {
      B.page.appendChild(bNameCard());
      B.page.appendChild(bLogoCard());
      B.page.appendChild(bResetCard());
    } else {
      B.page.appendChild(bFacts());
    }
  }
  function bLoad(who) {
    var page = B.page;
    B.who = who;
    FP.call('get', 'resellerBranding', undefined, who).then(function (r) {
      if (B.page !== page || B.who !== who) { return; }
      B.view = cleanBrand(r);
      bRender();
      var sel = B.page.querySelector('#fp-rb-pick');
      if (sel && document.activeElement && document.activeElement.id === 'fp-rb-pick') { sel.focus(); }
    }, function (err) {
      if (B.page !== page || B.who !== who) { return; }
      listFail(page, FP.tools.reseller_branding.label, err);
    });
  }
  FP.view('tool:reseller_branding', function () {
    B.page = null;
    var body = frame('reseller_branding');
    if (!body) { return; }
    B.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    if (!isAdmin()) { bLoad(FP.account()); return; }
    resellers().then(function (names) {
      if (B.page !== body) { return; }
      B.names = names;
      if (!names.length) {
        body.textContent = '';
        body.appendChild(M.card('fp-rp-none-h', t('rp_none_title'), [el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('rp_none')})], 'fp-rp-none'));
        return;
      }
      bLoad(names[0]);
    }, function (err) {
      if (B.page !== body) { return; }
      listFail(body, FP.tools.reseller_branding.label, err);
    });
  });

  /* ================= Reseller addresses ================= */
  var I = {page: null, who: '', view: null, server: null, names: [], free: null};
  /* how many of the reseller's addresses a new account on a dedicated IP package could take now, as the server counts them; null when it did not say */
  function freeOf(r) { return r && typeof r.free === 'number' && isFinite(r.free) && r.free >= 0 ? Math.floor(r.free) : null; }
  function freeLine() {
    if (I.free === null || !I.view.length) { return null; }
    return el('p', {class: 'fp-muted fp-ri-free', 'data-fp-free': String(I.free), text: I.free === 0 ? t('ri_free_none') : t(I.free === 1 ? 'ri_free_count_1' : 'ri_free_count', {n: I.free, total: I.view.length})});
  }
  function cleanIps(r) {
    var list = r && Array.isArray(r.ips) ? r.ips : [];
    return list.slice(0, 200).filter(function (x) { return x && typeof x === 'object' && IPV4_RE.test(str(x.address, 20)); }).map(function (x) {
      return {address: x.address, present: x.present === true, iface: str(x.interface, 40),
        accounts: (Array.isArray(x.accounts) ? x.accounts : []).slice(0, 50).map(function (a) { return str(a, 20); }).filter(function (a) { return USER_RE.test(a); })};
    });
  }
  /* the server's addresses the admin may hand out: IPv4, not the one new accounts share */
  function cleanServer(r) {
    var list = r && Array.isArray(r.ips) ? r.ips : [];
    return list.slice(0, 500).filter(function (x) { return x && typeof x === 'object' && IPV4_RE.test(str(x.address, 20)) && x.main !== true; }).map(function (x) {
      var d = str(x.delegated_to, 20);
      return {address: x.address, iface: str(x.interface, 40), to: USER_RE.test(d) ? d : ''};
    });
  }
  function usedBy(accounts) { return accounts.length ? t('ri_used', {accounts: accounts.join(', ')}) : t('ri_unused'); }

  /* the reseller's own list, and the admin's when nothing is left to choose from */
  function iList(card, own) {
    var rows = I.view.map(function (x) {
      return el('tr', {'data-fp-ip': x.address}, [el('th', {scope: 'row', class: 'sig-mono', text: x.address}),
        el('td', {class: 'fp-rp-if', text: x.iface || '—'}),
        el('td', null, [el('span', {class: 'sig-pill' + (x.present ? ' sig-pill--ok' : ' sig-pill--warn'), text: t(x.present ? 'ri_present' : 'ri_missing')})]),
        el('td', {class: 'fp-rp-use', text: usedBy(x.accounts)})]);
    });
    var parts = [M.errorLine(), M.statusLine(), freeLine()];
    if (!rows.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': '', text: t(own ? 'ri_none_own' : 'ri_none', {name: I.who})}));
    } else {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': card}, [
        el('table', {class: 'sig-table fp-rp-table'}, [el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('ri_col_address')}),
          el('th', {scope: 'col', text: t('ri_col_card')}), el('th', {scope: 'col', text: t('ri_col_state')}), el('th', {scope: 'col', text: t('ri_col_use')})])]),
        el('tbody', null, rows)])]));
      if (I.view.some(function (x) { return !x.present; })) { parts.push(el('p', {class: 'fp-warn-line', 'data-fp-missing': '', text: t('ri_missing_note')})); }
    }
    return M.card(card, t(own ? 'ri_own_title' : 'ri_now_title', {name: I.who}), parts, 'fp-ri-list');
  }
  /* the admin's choice: every address the server has that may be handed out, with whom it is given to */
  function iEditor() {
    var mine = {};
    I.view.forEach(function (x) { mine[x.address] = x; });
    var rows = I.server.map(function (s) {
      var other = s.to && s.to !== I.who;
      var id = 'fp-ri-a-' + s.address.replace(/\./g, '-');
      var have = mine[s.address];
      var box = el('input', {type: 'checkbox', id: id, name: 'address', value: s.address, checked: s.to === I.who ? true : null, disabled: other ? true : null,
        'aria-describedby': id + '-note'});
      var note = other ? t('ri_given_to', {name: s.to}) : have ? usedBy(have.accounts) : t('ri_free');
      return el('div', {class: 'fp-ri-row'}, [el('label', {class: 'fp-check', for: id}, [box, el('span', {class: 'sig-mono', text: s.address}),
        el('span', {class: 'fp-muted fp-ri-card', text: s.iface ? t('ri_on', {card: s.iface}) : ''})]), el('span', {class: 'sig-hint', id: id + '-note', text: note})]);
    });
    // addresses the reseller has that the server no longer lists are kept in the list until the admin takes them back
    I.view.forEach(function (x) {
      if (I.server.some(function (s) { return s.address === x.address; })) { return; }
      var id = 'fp-ri-a-' + x.address.replace(/\./g, '-');
      rows.push(el('div', {class: 'fp-ri-row'}, [el('label', {class: 'fp-check', for: id}, [el('input', {type: 'checkbox', id: id, name: 'address', value: x.address,
        checked: true, 'aria-describedby': id + '-note'}), el('span', {class: 'sig-mono', text: x.address})]),
      el('span', {class: 'sig-hint', id: id + '-note', text: t('ri_gone')})]));
    });
    var form = el('form', {class: 'fp-form fp-mail-form fp-ri-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('fieldset', {class: 'fp-ri-set'}, [el('legend', {class: 'sig-label', text: t('ri_choose', {name: I.who})})].concat(rows.length ? rows :
        [el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('ri_server_none')})])),
      el('p', {class: 'sig-hint', text: t('ri_choose_hint')}),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', disabled: rows.length ? null : true, text: t('ri_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var picked = Array.prototype.map.call(form.querySelectorAll('input[name="address"]:checked'), function (x) { return x.value; });
      UI.setBusy(b, true);
      FP.call('put', 'resellerIps', {addresses: picked}, I.who).then(function (r) {
        UI.setBusy(b, false);
        I.view = cleanIps(r);
        I.free = freeOf(r);
        // the choice is drawn again from what the server now says; the server's list tells whom each is given to
        FP.call('get', 'serverIps').then(function (s) { I.server = cleanServer(s); }, function () { return null; }).then(function () {
          iRender();
          M.say(I.page.querySelector('.fp-ri-edit'), t('ri_saved', {name: I.who, n: picked.length}));
          I.page.querySelector('#fp-ri-edit-h').focus();
        });
      }, function (err) {
        UI.setBusy(b, false);
        M.fieldError(form, null, (err.field === 'addresses' ? t('ri_addresses') + ': ' : '') + err.message);
      });
    });
    return M.card('fp-ri-edit-h', t('ri_edit_title', {name: I.who}), [el('p', {class: 'fp-muted', text: t('ri_edit_desc', {name: I.who})}), form], 'fp-ri-edit');
  }
  function iRender() {
    I.page.textContent = '';
    if (isAdmin()) {
      I.page.appendChild(picker('fp-ri-pick', I.names, I.who, iLoad));
      I.page.appendChild(iEditor());
      I.page.appendChild(iList('fp-ri-now-h', false));
    } else {
      I.page.appendChild(iList('fp-ri-now-h', true));
      /* a reseller puts one of its addresses on one of its own accounts (fp-resellerip.js); the list above is read and drawn again after a change */
      if (FP.resellerIp) {
        I.page.appendChild(FP.resellerIp.card({addresses: I.view, reload: function () {
          var page = I.page;
          return FP.call('get', 'resellerIps', undefined, I.who).then(function (r) {
            if (I.page !== page) { return null; }
            I.view = cleanIps(r);
            I.free = freeOf(r);
            var old = page.querySelector('.fp-ri-list');
            if (old) { page.replaceChild(iList('fp-ri-now-h', true), old); }
            return I.view;
          });
        }}));
      }
    }
  }
  function iLoad(who) {
    var page = I.page;
    I.who = who;
    var calls = [FP.call('get', 'resellerIps', undefined, who)];
    if (isAdmin()) { calls.push(FP.call('get', 'serverIps')); }
    Promise.all(calls).then(function (r) {
      if (I.page !== page || I.who !== who) { return; }
      I.view = cleanIps(r[0]);
      I.free = freeOf(r[0]);
      I.server = r[1] ? cleanServer(r[1]) : [];
      iRender();
    }, function (err) {
      if (I.page !== page || I.who !== who) { return; }
      listFail(page, FP.tools.reseller_ips.label, err);
    });
  }
  FP.view('tool:reseller_ips', function () {
    I.page = null;
    var body = frame('reseller_ips');
    if (!body) { return; }
    I.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    if (!isAdmin()) { iLoad(FP.account()); return; }
    resellers().then(function (names) {
      if (I.page !== body) { return; }
      I.names = names;
      if (!names.length) {
        body.textContent = '';
        body.appendChild(M.card('fp-rp-none-h', t('rp_none_title'), [el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('rp_none')})], 'fp-rp-none'));
        return;
      }
      iLoad(names[0]);
    }, function (err) {
      if (I.page !== body) { return; }
      listFail(body, FP.tools.reseller_ips.label, err);
    });
  });

  /* ---- clicks on the branding page ---- */
  document.addEventListener('click', function (e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !B.page || !B.page.contains(b)) { return; }
    var a = b.getAttribute('data-fp-act');
    if (a === 'logo-remove') {
      M.confirmIn(b.parentNode, t('rbr_logo_remove_ask'), 'logo-remove-yes', t('rbr_logo_remove'));
    } else if (a === 'reset') {
      M.confirmIn(b.parentNode, t(isAdmin() ? 'rbr_reset_ask_admin' : 'rbr_reset_ask', {name: B.who}), 'reset-yes', t('rbr_reset'));
    } else if (a === 'confirm-no') {
      var was = b.closest('.fp-rb-reset') ? 'reset' : 'logo-remove';
      bRender();
      B.page.querySelector('[data-fp-act="' + was + '"]').focus();
    } else if (a === 'logo-remove-yes') {
      UI.setBusy(b, true);
      FP.call('del', 'resellerBrandingLogo', undefined, B.who).then(function () {
        B.view.logo = false;
        bRender();
        M.say(B.page.querySelector('.fp-rb-logo'), t('rbr_logo_removed'));
        B.page.querySelector('#fp-rb-logo-h').focus();
      }, function (err) {
        bRender();
        UI.showError(B.page.querySelector('.fp-rb-logo'), err.message);
        B.page.querySelector('[data-fp-act="logo-remove"]').focus();
      });
    } else if (a === 'reset-yes') {
      UI.setBusy(b, true);
      FP.call('del', 'resellerBranding', undefined, B.who).then(function () {
        B.view = {name: '', url: '', logo: false, allowed: B.view.allowed};
        bRender();
        M.say(B.page.querySelector('.fp-rb-resetc'), t('rbr_reset_done', {name: B.who}));
        B.page.querySelector('#fp-rb-reset-h').focus();
      }, function (err) {
        bRender();
        UI.showError(B.page.querySelector('.fp-rb-resetc'), err.message);
        B.page.querySelector('[data-fp-act="reset"]').focus();
      });
    }
  });
})();

/* freePanel mail from an account's own address (docs/api.md, "Dedicated IP addresses"): the part of the account address cards (fp-ips.js for the
   admin, fp-resellerip.js for a reseller) in which the account's domains' mail to other servers is set to leave from the account's own IPv4 address,
   with the account's SPF records naming it, or from the server's own again; and, for the admin, the card that allows or forbids that on the whole
   server. The server decides: a choice the admin forbids is refused in its words, and a choice on an account on the shared address is kept for when
   it has one. What the server sends is cleaned to the shapes drawn and shown as text. Page pieces come from FP.mail (fp-mail.js). A customer never
   reaches these cards. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var ADDR_RE = /^(?:25[0-5]|2[0-4]\d|1?\d?\d)(?:\.(?:25[0-5]|2[0-4]\d|1?\d?\d)){3}$/;
  var DOMAIN_RE = /^(?=.{4,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/;

  function whole(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.floor(v) : 0; }
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    return {on: r.on === true, allowed: r.allowed !== false, ip: typeof r.ip === 'string' && ADDR_RE.test(r.ip) ? r.ip : null,
      domains: (Array.isArray(r.domains) ? r.domains : []).filter(function (d) { return typeof d === 'string' && DOMAIN_RE.test(d); }).slice(0, 50),
      warning: typeof r.warning === 'string' ? r.warning.slice(0, 300) : '', spf: r.spf && typeof r.spf === 'object' ? r.spf : null};
  }
  function nowText(s, who) {
    if (s.ip) { return t(s.domains.length === 1 ? 'mip_now_own_1' : 'mip_now_own', {account: who, address: s.ip, n: s.domains.length, domains: s.domains.join(', ')}); }
    if (s.on) { return t('mip_now_waiting', {account: who}); }
    return t('mip_now_shared', {account: who});
  }

  /* the card for one account at a time, next to the card that gives it its address: show(name) reads and draws that account's, show('') hides it.
     An answer for an account no longer shown is dropped. */
  function card() {
    var body = el('div', {class: 'fp-mip', 'data-fp-mip': ''});
    var node = M.card('fp-mip-h', t('mip_title'), [el('p', {class: 'fp-muted', text: t('mip_what')}), body], 'fp-mip-card');
    node.hidden = true;
    var seq = 0;
    function show(who) {
      var mine = ++seq;
      body.textContent = '';
      node.hidden = !who;
      if (!who) { return; }
      body.appendChild(el('p', {class: 'fp-muted', 'data-fp-mip-loading': '', text: t('loading')}));
      box({account: who, holder: body, live: function () { return mine === seq; }});
    }
    return {node: node, show: show};
  }

  /* the part for one account, drawn in opts.holder: opts {account, holder, live} */
  function box(opts) {
    var who = opts.account;
    var holder = opts.holder;
    var live = opts.live || function () { return true; };
    var S = null;
    function draw(note, focus) {
      holder.textContent = '';
      var box = el('input', {type: 'checkbox', id: 'fp-mip-on', name: 'mail_ip', checked: S.on ? true : null, disabled: !S.allowed && !S.on ? true : null,
        'aria-describedby': 'fp-mip-hint'});
      var form = el('form', {class: 'fp-form fp-mail-form fp-mip-form', novalidate: ''}, [M.errorLine(),
        el('p', {class: 'fp-ok-line', role: 'status', 'data-fp-status': '', text: note ? note.text : ''}),
        el('p', {class: 'fp-warn-line', role: 'status', 'data-fp-mip-warning': '', hidden: note && note.warning ? null : true, text: note ? note.warning : ''}),
        el('p', {'data-fp-mip-now': S.ip ? 'own' : (S.on ? 'waiting' : 'shared'), text: nowText(S, who)}),
        el('div', {class: 'sig-field'}, [el('label', {class: 'fp-check', for: 'fp-mip-on'}, [box, el('span', {text: t('mip_f_on')})]),
          el('span', {class: 'sig-hint', id: 'fp-mip-hint', text: S.allowed ? t('mip_f_on_hint') : t('mip_off_server')})]),
        el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary fp-submit', type: 'submit', disabled: !S.allowed && !S.on ? true : null, text: t('mip_save')})])]);
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var b = M.start(form);
        if (!b) { return; }
        UI.setBusy(b, true);
        FP.call('put', 'acctIpMail', {on: box.checked}, who).then(function (r) {
          if (!live()) { return; }
          S = clean(r);
          var text = t(S.on ? 'mip_saved_on' : 'mip_saved_off', {account: who});
          var n = S.spf ? whole(S.spf.records) : 0;
          if (n) { text += ' ' + t(n === 1 ? 'mip_spf_1' : 'mip_spf', {n: n}); }
          draw({text: text, warning: S.warning}, '#fp-mip-on');
        }, function (err) {
          UI.setBusy(b, false);
          M.failed(form, err);
        });
      });
      holder.appendChild(form);
      var target = focus ? holder.querySelector(focus) : null;
      if (target) { target.focus(); }
    }
    FP.call('get', 'acctIpMail', undefined, who).then(function (r) {
      if (!live()) { return; }
      S = clean(r);
      draw();
    }, function (err) {
      if (!live()) { return; }
      holder.textContent = '';
      holder.appendChild(el('p', {class: 'fp-warn-line', role: 'status', 'data-fp-mip-failed': '', text: t('mip_failed', {account: who}) + ' ' + (err && err.message ? err.message : '')}));
    });
  }

  /* the admin's card: whether accounts may send their mail from their own address at all */
  function serverCard() {
    var holder = el('div', {class: 'fp-mip-srv-body'}, [el('p', {class: 'fp-muted', text: t('loading')})]);
    function draw(s, note, focus) {
      holder.textContent = '';
      var box = el('input', {type: 'checkbox', id: 'fp-mips-on', name: 'allowed', checked: s.allowed ? true : null, 'aria-describedby': 'fp-mips-hint'});
      var form = el('form', {class: 'fp-form fp-mail-form fp-mips-form', novalidate: ''}, [M.errorLine(),
        el('p', {class: 'fp-ok-line', role: 'status', 'data-fp-status': '', text: note || ''}),
        el('p', {'data-fp-mips-now': s.allowed ? 'on' : 'off', text: s.allowed ? t(s.accounts === 1 ? 'mips_now_on_1' : 'mips_now_on', {n: s.accounts}) : t('mips_now_off')}),
        el('div', {class: 'sig-field'}, [el('label', {class: 'fp-check', for: 'fp-mips-on'}, [box, el('span', {text: t('mips_f_on')})]),
          el('span', {class: 'sig-hint', id: 'fp-mips-hint', text: t('mips_f_on_hint')})]),
        el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('mips_save')})])]);
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var b = M.start(form);
        if (!b) { return; }
        UI.setBusy(b, true);
        FP.call('put', 'serverDedicatedMail', {allowed: box.checked}).then(function (r) {
          var n = {allowed: r && r.allowed === true, accounts: whole(r && r.accounts)};
          draw(n, t(n.allowed ? 'mips_saved_on' : 'mips_saved_off'), '#fp-mips-on');
        }, function (err) {
          UI.setBusy(b, false);
          M.failed(form, err);
        });
      });
      holder.appendChild(form);
      var target = focus ? holder.querySelector(focus) : null;
      if (target) { target.focus(); }
    }
    FP.call('get', 'serverDedicatedMail').then(function (r) {
      draw({allowed: r && r.allowed === true, accounts: whole(r && r.accounts)});
    }, function (err) {
      holder.textContent = '';
      holder.appendChild(el('p', {class: 'fp-warn-line', role: 'status', 'data-fp-mips-failed': '', text: err && err.message ? err.message : t('api_failed')}));
    });
    return M.card('fp-mips-h', t('mips_title'), [el('p', {class: 'fp-muted', text: t('mips_what')}), holder], 'fp-mips');
  }

  FP.mailIp = {card: card, serverCard: serverCard};
})();

/* freePanel IP migration (#/tool/ip_migration), the admin panel's wizard that moves the server from old addresses to new ones
   (docs/api.md, "IP migration"): pick each old address and the new one it moves to (the new one is on the server already, or is the
   public address behind NAT), check what
   moves (the accounts with an address of their own, the DNS records, the mail that leaves from it, a reseller's pool, the reserved list),
   then, with the admin's password, move it. The old addresses stay on the server; they are taken away on the IP addresses page once
   the new records have spread. What the server sends is drawn as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var ADDR_RE = /^[0-9a-fA-F:.]{2,45}$/;
  var MAX = 32;
  var V = null;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  function count(v) { return typeof v === 'number' && isFinite(v) && v > 0 ? Math.floor(v) : 0; }
  function strs(l, n) { return (Array.isArray(l) ? l : []).filter(function (x) { return typeof x === 'string' && x; }).slice(0, 200).map(function (x) { return x.slice(0, n); }); }
  function addrs(r) {
    r = r && typeof r === 'object' ? r : {};
    var ips = (Array.isArray(r.ips) ? r.ips : []).filter(function (v) { return v && typeof v.address === 'string' && ADDR_RE.test(v.address); })
      .map(function (v) { return {address: v.address, six: v.address.indexOf(':') >= 0, main: v.main === true, reserved: v.reserved === true, used: Array.isArray(v.sites) && v.sites.length > 0,
        pub: typeof v.public === 'string' && ADDR_RE.test(v.public) ? v.public : '', pubMain: v.public_main === true}; });
    var missing = (Array.isArray(r.missing) ? r.missing : []).filter(function (v) { return v && typeof v.address === 'string' && ADDR_RE.test(v.address); })
      .map(function (v) { return {address: v.address, six: v.address.indexOf(':') >= 0, missing: true}; });
    return {ips: ips, missing: missing};
  }
  function cleanPlan(r) {
    r = r && typeof r === 'object' ? r : {};
    return {ready: r.ready === true, zones: count(r.zones), records: count(r.records), dnsProblem: str(r.dns_problem, 300),
      pairs: (Array.isArray(r.pairs) ? r.pairs : []).filter(function (p) { return p && ADDR_RE.test(str(p.from, 45)) && ADDR_RE.test(str(p.to, 45)); }).map(function (p) {
        return {from: p.from, to: p.to, main: p.main === true, onServer: p.on_server === true, accounts: strs(p.accounts, 64), mail: strs(p.mail_domains, 253),
          reseller: str(p.reseller, 64), reserved: p.reserved === true, problem: str(p.problem, 300)};
      })};
  }
  function cleanResult(r) {
    r = r && typeof r === 'object' ? r : {};
    return {zones: count(r.zones), records: count(r.records), mail: count(r.mail_domains), problems: strs(r.problems, 400),
      accounts: (Array.isArray(r.accounts) ? r.accounts : []).filter(function (a) { return a && typeof a.username === 'string'; }).map(function (a) {
        return {username: str(a.username, 64), to: str(a.to, 45), error: str(a.error, 300)};
      })};
  }

  /* ---- the pairs ---- */
  function options(list, chosen, blank) {
    var o = [el('option', {value: '', text: blank})];
    list.forEach(function (a) {
      o.push(el('option', {value: a.address, selected: a.address === chosen ? true : null, text: a.address + (a.label ? ' ' + a.label : '')}));
    });
    return o;
  }
  /* behind NAT the records point at the router's public address: it is the old address once they do, and a new one until then */
  function olds() {
    var out = [];
    V.addrs.ips.forEach(function (a) {
      if (a.pub && a.pubMain) { out.push({address: a.pub, label: t('ipm_main_tag')}); }
      out.push({address: a.address, label: a.main && !(a.pub && a.pubMain) ? t('ipm_main_tag') : ''});
    });
    return out.concat(V.addrs.missing.map(function (a) { return {address: a.address, label: t('ipm_missing_tag')}; }));
  }
  function news() {
    var nat = V.addrs.ips.filter(function (a) { return a.pub && !a.pubMain; }).map(function (a) { return {address: a.pub, label: t('ipm_nat_tag')}; });
    return V.addrs.ips.filter(function (a) { return !a.main && !a.reserved && !a.used; }).map(function (a) { return {address: a.address, label: ''}; }).concat(nat);
  }
  function pairRow(i, p) {
    var fid = 'fp-ipm-from-' + i;
    var tid = 'fp-ipm-to-' + i;
    return el('li', {class: 'fp-ipm-pair', 'data-fp-pair': String(i)}, [
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: fid, text: t('ipm_from', {n: i + 1})}),
        el('select', {class: 'sig-select sig-mono', id: fid, name: 'from'}, options(olds(), p.from, t('ipm_pick')))]),
      el('span', {class: 'fp-ipm-arrow', 'aria-hidden': 'true', text: '→'}),
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: tid, text: t('ipm_to', {n: i + 1})}),
        el('select', {class: 'sig-select sig-mono', id: tid, name: 'to'}, options(news(), p.to, t('ipm_pick')))]),
      V.pairs.length > 1 ? el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'drop', 'data-fp-i': String(i),
        'aria-label': t('ipm_drop_of', {n: i + 1}), text: t('ipm_drop')}) : null]);
  }
  function readPairs() {
    var rows = V.page.querySelectorAll('[data-fp-pair]');
    V.pairs = [].map.call(rows, function (r) { return {from: r.querySelector('[name="from"]').value, to: r.querySelector('[name="to"]').value}; });
  }
  function pairsCard() {
    var form = el('form', {class: 'fp-form fp-ipm-form', novalidate: ''}, [M.errorLine(),
      el('ol', {class: 'fp-ipm-pairs'}, V.pairs.map(function (p, i) { return pairRow(i, p); })),
      el('div', {class: 'fp-actions'}, [
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'more', disabled: V.pairs.length >= MAX ? true : null, text: t('ipm_more')}),
        el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('ipm_check')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      readPairs();
      var b = M.start(form);
      if (!b) { return; }
      for (var i = 0; i < V.pairs.length; i++) {
        var p = V.pairs[i];
        if (!p.from || !p.to) { M.fieldError(form, form.querySelector('#fp-ipm-' + (p.from ? 'to-' : 'from-') + i), t('ipm_pick_both')); return; }
        if ((p.from.indexOf(':') >= 0) !== (p.to.indexOf(':') >= 0)) { M.fieldError(form, form.querySelector('#fp-ipm-to-' + i), t('ipm_family')); return; }
      }
      UI.setBusy(b, true);
      FP.call('post', 'ipMigrationPlan', {pairs: V.pairs}).then(function (r) {
        UI.setBusy(b, false);
        V.plan = cleanPlan(r);
        V.result = null;
        drawPlan();
        var h = V.page.querySelector('#fp-ipm-plan-h');
        if (h) { h.focus(); }
      }, function (err) {
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    var intro = [el('p', {class: 'fp-muted', text: t('ipm_intro')})];
    if (!news().length) { intro.push(el('p', {class: 'fp-warn-line', 'data-fp-no-new': '', text: t('ipm_no_new')})); }
    return M.card('fp-ipm-pairs-h', t('ipm_pairs_title'), intro.concat([form]), 'fp-ipm-pairs-card');
  }

  /* ---- what moves ---- */
  function listOr(l, none) { return l.length ? l.join(', ') : none; }
  function planRow(p) {
    var moves = [];
    if (p.main) { moves.push(t('ipm_moves_main')); }
    moves.push(t('ipm_moves_accounts', {list: listOr(p.accounts, t('ipm_none'))}));
    if (p.mail.length) { moves.push(t('ipm_moves_mail', {list: p.mail.join(', ')})); }
    if (p.reseller) { moves.push(t('ipm_moves_reseller', {name: p.reseller})); }
    if (p.reserved) { moves.push(t('ipm_moves_reserved')); }
    return el('tr', {'data-fp-plan': p.from}, [
      el('th', {scope: 'row'}, [el('span', {class: 'sig-mono', text: p.from}), el('span', {class: 'fp-muted', text: ' → '}), el('span', {class: 'sig-mono', text: p.to})]),
      el('td', null, [el('ul', {class: 'fp-ipm-moves'}, moves.map(function (m) { return el('li', {text: m}); })),
        p.problem ? el('p', {class: 'fp-warn-line', 'data-fp-problem': '', text: p.problem}) : null])]);
  }
  function drawPlan() {
    var old = V.page.querySelector('.fp-ipm-plan');
    var card = planCard();
    if (old) { old.replaceWith(card); } else if (card) { V.page.appendChild(card); }
  }
  function planCard() {
    var P = V.plan;
    var parts = [M.errorLine(), M.statusLine()];
    parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-ipm-plan-h'}, [el('table', {class: 'sig-table fp-ipm-table'}, [
      el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('ipm_col_pair')}), el('th', {scope: 'col', text: t('ipm_col_moves')})])]),
      el('tbody', null, P.pairs.map(planRow))])]));
    parts.push(el('p', {'data-fp-dns': '', class: P.dnsProblem ? 'fp-warn-line' : 'fp-muted', text: P.dnsProblem ? t('ipm_dns_problem', {problem: P.dnsProblem}) : t('ipm_dns', {records: P.records, zones: P.zones})}));
    if (V.result) {
      parts.push(resultBox());
    } else if (P.ready) {
      var pw = el('input', {class: 'sig-input', id: 'fp-ipm-pw', name: 'current_password', type: 'password', autocomplete: 'current-password', maxlength: '512'});
      var form = el('form', {class: 'fp-form fp-ipm-run', novalidate: ''}, [M.errorLine(),
        el('p', {class: 'fp-muted', text: t('ipm_run_intro')}),
        M.field('fp-ipm-pw', t('ipm_password'), pw, t('ipm_password_hint')),
        el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--danger fp-submit', type: 'submit', text: t('ipm_run')})])]);
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var b = M.start(form);
        if (!b) { return; }
        if (!pw.value) { M.fieldError(form, pw, t('ipm_password_needed')); return; }
        UI.setBusy(b, true);
        FP.call('post', 'ipMigration', {pairs: V.pairs, current_password: pw.value}).then(function (r) {
          V.result = cleanResult(r);
          drawPlan();
          var h = V.page.querySelector('#fp-ipm-plan-h');
          if (h) { h.focus(); }
        }, function (err) {
          UI.setBusy(b, false);
          pw.value = '';
          M.failed(form, err);
        });
      });
      parts.push(form);
    } else {
      parts.push(el('p', {class: 'fp-warn-line', 'data-fp-not-ready': '', text: t('ipm_not_ready')}));
    }
    return M.card('fp-ipm-plan-h', V.result ? t('ipm_done_title') : t('ipm_plan_title'), parts, 'fp-ipm-plan');
  }
  function resultBox() {
    var R = V.result;
    var items = [el('li', {text: t('ipm_done_records', {records: R.records, zones: R.zones})}), el('li', {text: t('ipm_done_mail', {n: R.mail})})];
    R.accounts.forEach(function (a) {
      items.push(el('li', {text: a.error ? t('ipm_done_account_failed', {name: a.username, error: a.error}) : t('ipm_done_account', {name: a.username, to: a.to})}));
    });
    var box = [el('ul', {class: 'fp-ipm-done', 'data-fp-done': ''}, items)];
    if (R.problems.length) {
      box.push(el('div', {class: 'fp-note fp-ipm-problems', role: 'note', 'data-fp-problems': ''}, [el('p', {text: t('ipm_problems')}),
        el('ul', null, R.problems.map(function (p) { return el('li', {text: p}); }))]));
    }
    box.push(el('p', {class: 'fp-muted', text: t('ipm_after')}, null));
    box.push(el('p', null, [el('a', {href: '#/tool/server_ips', text: t('ipm_to_ips')})]));
    return el('div', {class: 'fp-ipm-result'}, box);
  }

  function onClick(e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
    var form = V && V.page.querySelector('.fp-ipm-form');
    if (!b || !form || !form.contains(b)) { return; }
    var act = b.getAttribute('data-fp-act');
    readPairs();
    if (act === 'more' && V.pairs.length < MAX) {
      V.pairs.push({from: '', to: ''});
      redrawPairs();
      V.page.querySelector('#fp-ipm-from-' + (V.pairs.length - 1)).focus();
    } else if (act === 'drop') {
      var i = parseInt(b.getAttribute('data-fp-i'), 10);
      V.pairs.splice(i, 1);
      redrawPairs();
      V.page.querySelector('#fp-ipm-from-' + Math.min(i, V.pairs.length - 1)).focus();
    }
  }
  function redrawPairs() {
    V.page.querySelector('.fp-ipm-pairs-card').replaceWith(pairsCard());
  }
  document.addEventListener('click', onClick);

  FP.view('tool:ip_migration', function () {
    var tool = FP.tools.ip_migration;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('ipm_desc'), cls: 'fp-mail fp-srv fp-ipm-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    V = {page: page, addrs: null, pairs: [{from: '', to: ''}], plan: null, result: null};
    var mine = V;
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'serverIps').then(function (r) {
      if (V !== mine) { return; }
      page.textContent = '';
      V.addrs = addrs(r);
      page.appendChild(pairsCard());
    }, function (err) {
      if (V !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

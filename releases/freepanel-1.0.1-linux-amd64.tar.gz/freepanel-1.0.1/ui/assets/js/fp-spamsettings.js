/* freePanel spam settings (#/tool/spam_settings), the admin panel's page for the server-wide spam scores and the
   limit on outgoing mail (docs/api.md, "ServerSpam" and "ServerMailSettings"). The two scores are the ones an account
   that has chosen none is held to: mail scoring the first is marked as spam, mail scoring the second is refused. An
   account's own scores are never touched here. Where spam filtering is not set up the scores are shown and cannot be
   changed. The limit on outgoing mail is drawn only when the server has one (a fourth choice of the mail server
   settings); saving it goes through FP.mailset.save so the mail server's other limits are sent back as they are. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;
  var MS = FP.mailset;

  /* freePanel's own scores, used where none is chosen (docs/api.md) */
  var OWN = {default_mark: 6, default_reject: 15};
  var SCORE_RE = /^[0-9]{1,3}(\.[0-9])?$/;
  var FIELDS = [
    {name: 'default_mark', id: 'fp-sps-mark', key: 'mark'},
    {name: 'default_reject', id: 'fp-sps-reject', key: 'reject'}
  ];

  var V = null;

  function whole(v) { return typeof v === 'number' && isFinite(v) && v >= 0 && Math.floor(v) === v ? v : 0; }
  function score(v, d) { return typeof v === 'number' && isFinite(v) && v >= 0 && v <= 1000 ? Math.round(v * 10) / 10 : d; }

  /* what the server says, kept to the shapes the page draws */
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var set = r.set && typeof r.set === 'object' ? r.set : {};
    var b = r.bounds && typeof r.bounds === 'object' ? r.bounds : {};
    var min = score(b.min, 1);
    var max = score(b.max, 100);
    return {available: r.available === true, mark: score(r.default_mark, OWN.default_mark), reject: score(r.default_reject, OWN.default_reject),
      markSet: set.mark === true, rejectSet: set.reject === true, min: min, max: max >= min ? max : 100,
      own: whole(r.accounts_own), off: whole(r.accounts_off), warning: typeof r.warning === 'string' ? r.warning.slice(0, 400) : ''};
  }

  /* ---------- the default scores ---------- */
  function point(n) { return String(n); }
  function scoresCard() {
    var rows = [[t('sps_f_mark'), point(V.mark) + ' ' + t(V.markSet ? 'sps_chosen' : 'sps_own'), 'mark'],
      [t('sps_f_reject'), point(V.reject) + ' ' + t(V.rejectSet ? 'sps_chosen' : 'sps_own'), 'reject'],
      [t('sps_f_own'), t(V.own === 1 ? 'sps_accounts_1' : 'sps_accounts', {n: V.own.toLocaleString('en')}), 'own'],
      [t('sps_f_off'), t(V.off === 1 ? 'sps_accounts_1' : 'sps_accounts', {n: V.off.toLocaleString('en')}), 'off']];
    var parts = [];
    if (!V.available) { parts.push(el('p', {class: 'fp-warn-line', 'data-fp-unavailable': '', text: t('sps_unavailable')})); }
    if (V.warning) { parts.push(el('p', {class: 'fp-warn-line', 'data-fp-warning': '', text: t('sps_warning', {why: V.warning})})); }
    parts.push(el('dl', {class: 'fp-mail-facts fp-sps-facts'}, rows.reduce(function (out, r) {
      return out.concat([el('dt', {text: r[0]}), el('dd', {'data-fp-fact': r[2], text: r[1]})]);
    }, [])));
    parts.push(el('p', {class: 'fp-muted', text: t('sps_reach')}));
    return M.card('fp-sps-now-h', t('sps_now_title'), parts, 'fp-sps-now');
  }
  function drawScores() {
    var old = V.page.querySelector('.fp-sps-now');
    var fresh = scoresCard();
    if (old) { old.replaceWith(fresh); } else { V.page.insertBefore(fresh, V.page.firstChild); }
  }
  function formCard() {
    var form = el('form', {class: 'fp-form fp-mail-form fp-sps-form', novalidate: '', 'data-fp-form': 'scores'}, [M.errorLine(), M.statusLine()]);
    var values = {default_mark: V.markSet ? V.mark : '', default_reject: V.rejectSet ? V.reject : ''};
    FIELDS.forEach(function (f) {
      var attrs = {class: 'sig-input fp-num-input', id: f.id, name: f.name, type: 'text', inputmode: 'decimal', autocomplete: 'off', spellcheck: 'false',
        maxlength: '5', value: String(values[f.name])};
      if (!V.available) { attrs.disabled = ''; }
      form.appendChild(M.field(f.id, t('sps_l_' + f.key), el('input', attrs), t('sps_h_' + f.key, {min: V.min, max: V.max, own: OWN[f.name]})));
    });
    var save = {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('sps_save')};
    if (!V.available) { save.disabled = ''; }
    form.appendChild(el('div', {class: 'fp-actions'}, [el('button', save)]));
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      submit(form);
    });
    return M.card('fp-sps-form-h', t('sps_form_title'), [el('p', {class: 'fp-muted', text: t('sps_form_desc')}), form], 'fp-sps-choices');
  }
  /* the scores as the server takes them (empty is 0, not chosen); null, with the field marked, when one is plainly wrong */
  function read(form) {
    var body = {};
    var shown = {};
    for (var i = 0; i < FIELDS.length; i++) {
      var f = FIELDS[i];
      var raw = form.querySelector('[name="' + f.name + '"]').value.trim();
      var n = 0;
      if (raw !== '') {
        n = SCORE_RE.test(raw) ? parseFloat(raw) : -1;
        if (n < V.min || n > V.max) {
          M.fieldError(form, UI.fieldNamed(form, f.name), t('sps_bad', {field: t('sps_l_' + f.key), min: V.min, max: V.max}));
          return null;
        }
      }
      body[f.name] = n;
      shown[f.name] = n || OWN[f.name];
    }
    if (shown.default_mark >= shown.default_reject) {
      M.fieldError(form, UI.fieldNamed(form, 'default_mark'), t('sps_order', {mark: shown.default_mark, reject: shown.default_reject}));
      return null;
    }
    return body;
  }
  function submit(form) {
    var b = M.start(form);
    if (!b) { return; }
    var body = read(form);
    if (!body) { return; }
    var mine = V;
    UI.setBusy(b, true);
    FP.call('put', 'mailServerSpam', body).then(function (r) {
      UI.setBusy(b, false);
      if (V !== mine) { return; }
      var kept = clean(r);
      ['available', 'mark', 'reject', 'markSet', 'rejectSet', 'min', 'max', 'own', 'off', 'warning'].forEach(function (k) { mine[k] = kept[k]; });
      form.querySelector('[name="default_mark"]').value = kept.markSet ? String(kept.mark) : '';
      form.querySelector('[name="default_reject"]').value = kept.rejectSet ? String(kept.reject) : '';
      drawScores();
      M.say(form, t(kept.markSet || kept.rejectSet ? 'sps_saved' : 'sps_saved_own', {mark: kept.mark, reject: kept.reject}));
    }, function (err) {
      UI.setBusy(b, false);
      if (V !== mine) { return; }
      M.failed(form, err);
    });
  }

  /* ---------- the limit on outgoing mail ---------- */
  function hourlyCard() {
    var form = el('form', {class: 'fp-form fp-mail-form fp-sps-form', novalidate: '', 'data-fp-form': 'outgoing'}, [M.errorLine(), M.statusLine()]);
    var b = V.hourlyBounds;
    form.appendChild(M.field('fp-sps-hourly', t('sps_l_hourly'), el('input', {class: 'sig-input fp-num-input', id: 'fp-sps-hourly', name: MS.HOURLY, type: 'number',
      inputmode: 'numeric', min: String(b[0]), max: String(b[1]), step: '1', value: V.hourly ? String(V.hourly) : ''}),
    t('sps_h_hourly', {min: b[0].toLocaleString('en'), max: b[1].toLocaleString('en')})));
    form.appendChild(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('sps_hourly_save')})]));
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      submitHourly(form);
    });
    return M.card('fp-sps-out-h', t('sps_out_title'), [el('p', {class: 'fp-muted', text: t('sps_out_desc')}), form], 'fp-sps-out');
  }
  function submitHourly(form) {
    var b = M.start(form);
    if (!b) { return; }
    var lim = V.hourlyBounds;
    var raw = form.querySelector('[name="' + MS.HOURLY + '"]').value.trim();
    var n = raw === '' ? 0 : (/^[0-9]{1,7}$/.test(raw) ? parseInt(raw, 10) : -1);
    if (n < 0 || (n !== 0 && (n < lim[0] || n > lim[1]))) {
      M.fieldError(form, UI.fieldNamed(form, MS.HOURLY), t('sps_hourly_bad', {min: lim[0].toLocaleString('en'), max: lim[1].toLocaleString('en')}));
      return;
    }
    var mine = V;
    var patch = {};
    patch[MS.HOURLY] = n;
    UI.setBusy(b, true);
    MS.save(patch).then(function (r) {
      UI.setBusy(b, false);
      if (V !== mine) { return; }
      var kept = MS.clean(r);
      mine.hourly = kept.hourly;
      mine.hourlyBounds = kept.hourlyBounds;
      form.querySelector('[name="' + MS.HOURLY + '"]').value = kept.hourly ? String(kept.hourly) : '';
      M.say(form, kept.hourly ? t('sps_hourly_saved', {n: kept.hourly.toLocaleString('en')}) : t('sps_hourly_saved_none'));
    }, function (err) {
      UI.setBusy(b, false);
      if (V !== mine) { return; }
      M.failed(form, err);
    });
  }

  FP.view('tool:spam_settings', function () {
    var tool = FP.tools.spam_settings;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('sps_desc'), cls: 'fp-mail fp-sps',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    var mine = V = clean(null);
    mine.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    /* the limit on outgoing mail lives with the mail server settings: where they cannot be read the page goes on without it */
    Promise.all([FP.call('get', 'mailServerSpam'), FP.call('get', 'mailServerSettings').then(MS.clean, function () { return null; })]).then(function (r) {
      if (V !== mine) { return; }
      var kept = clean(r[0]);
      kept.page = body;
      kept.hourly = r[1] ? r[1].hourly : null;
      kept.hourlyBounds = r[1] ? r[1].hourlyBounds : MS.HOURLY_BOUNDS;
      V = kept;
      body.textContent = '';
      body.appendChild(scoresCard());
      body.appendChild(formCard());
      if (kept.hourly !== null) { body.appendChild(hourlyCard()); }
    }, function (err) {
      if (V !== mine) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

/* freePanel's Store themes page for a reseller (#/tool/store_themes, docs/api.md, "Resellers' themes"; docs/themes.md): the look of the
   reseller's own store, apart from the server's and every other reseller's. It lists the reseller's themes with their check, which is active
   and which is the previous one; uploads a zip and lists every problem the check found by file and line; opens a preview in a new tab;
   activates, rolls back and deletes, each after a question on the page; changes a theme's settings, its colours included; downloads the
   theme kit and the theme the store shows now; and sets the brand colour of the reseller's own customers' hosting panel. What the server
   answers is cleaned to the shapes drawn and shown as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var el = UI.el;
  var M = FP.mail;
  var t = UI.t;

  var MAX_UPLOAD = 16 * 1024 * 1024;
  var ID_RE = /^[a-z][a-z0-9-]{1,39}$/;
  var PAGE_RE = /^[a-z][a-z0-9-]{0,39}$/;
  var KEY_RE = /^[a-z][a-z0-9_-]{0,39}(\.[a-z0-9][a-z0-9_-]{0,39}){0,4}$/;
  var HEX_RE = /^#[0-9a-fA-F]{6}$/;
  var TYPES = ['string', 'number', 'integer', 'boolean', 'url-path', 'url', 'colour'];

  var P = null;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  function id(v) { return typeof v === 'string' && (v === 'default' || ID_RE.test(v)) ? v : ''; }
  function list(v, n, each) { return (Array.isArray(v) ? v : []).slice(0, n).map(each).filter(Boolean); }
  function problems(v) {
    return list(v, 100, function (p) {
      if (!p || typeof p !== 'object' || typeof p.message !== 'string') { return null; }
      return {file: str(p.file, 200), line: typeof p.line === 'number' && isFinite(p.line) && p.line > 0 ? Math.floor(p.line) : 0, message: str(p.message, 500)};
    });
  }
  function urls(v) { return list(v, 50, function (u) { return typeof u === 'string' && /^https:\/\//.test(u) ? u.slice(0, 300) : null; }); }
  function cleanTheme(x) {
    x = x && typeof x === 'object' ? x : {};
    var tid = id(x.id);
    if (!tid) { return null; }
    return {id: tid, name: str(x.name, 80) || tid, version: str(x.version, 32), author: str(x.author, 120), scripts: urls(x.scripts),
      host: tid === 'default', active: x.active === true, previous: x.previous === true, ok: x.status === 'ok', problems: problems(x.problems),
      kept: str(x.kept_version, 32)};
  }
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var seen = {};
    var themes = list(r.themes, 200, function (x) {
      var c = cleanTheme(x);
      if (!c || seen[c.id]) { return null; }
      seen[c.id] = true;
      return c;
    });
    var prev = r.previous && typeof r.previous === 'object' && id(r.previous.id) ? {id: id(r.previous.id), version: str(r.previous.version, 32)} : null;
    var pages = list(r.pages, 100, function (p) { return typeof p === 'string' && PAGE_RE.test(p) ? p : null; });
    return {active: id(r.active) || 'default', serving: id(r.serving) || 'default', previous: prev, problem: problems(r.problem), themes: themes,
      pages: pages.length ? pages : ['home']};
  }
  function cleanSettings(r) {
    r = r && typeof r === 'object' ? r : {};
    return list(r.fields, 400, function (f) {
      if (!f || typeof f !== 'object' || typeof f.key !== 'string' || !KEY_RE.test(f.key) || TYPES.indexOf(f.type) < 0) { return null; }
      var v = f.value;
      if (f.type === 'boolean') { v = v === true; } else if (f.type === 'number' || f.type === 'integer') { v = typeof v === 'number' && isFinite(v) ? v : ''; } else {
        v = str(v, 2000);
        if (f.type === 'colour' && !HEX_RE.test(v)) { v = '#000000'; }
      }
      return {key: f.key, type: f.type, label: str(f.label, 120) || f.key, group: str(f.group, 60), help: str(f.help, 300), value: v,
        multiline: f.multiline === true, max: typeof f.max === 'number' && isFinite(f.max) ? f.max : null, min: typeof f.min === 'number' && isFinite(f.min) ? f.min : null};
    });
  }
  function byId(tid) {
    for (var i = 0; i < P.data.themes.length; i++) { if (P.data.themes[i].id === tid) { return P.data.themes[i]; } }
    return null;
  }
  function label(th) { return th ? (th.host ? t('sth_host_theme') : th.name + (th.version ? ' ' + th.version : '')) : ''; }
  function path(name, arg) {
    var p = window.FPAPI.paths[name];
    Object.keys(arg || {}).forEach(function (k) { p = p.replace('{' + k + '}', encodeURIComponent(arg[k])); });
    return p;
  }

  function problemList(ps, cls) {
    if (!ps.length) { return null; }
    return el('ul', {class: 'fp-thm-problems' + (cls ? ' ' + cls : '')}, ps.map(function (p) {
      var where = p.file ? p.file + (p.line ? ':' + p.line : '') : '';
      return el('li', {}, [where ? el('span', {class: 'sig-mono fp-thm-where', text: where}) : null, where ? ' ' : null, el('span', {text: p.message})]);
    }));
  }

  /* ---- what the store shows, the live theme's download, and the rollback ---- */
  function statusCard() {
    var d = P.data;
    var act = byId(d.active);
    var serving = byId(d.serving);
    var parts = [M.errorLine(), M.statusLine()];
    parts.push(el('p', {class: 'fp-thm-serving', 'data-fp-sth-serving': ''}, [t('sth_serving') + ' ', el('strong', {text: label(serving) || label(act)})]));
    if (d.serving === 'default') { parts.push(el('p', {class: 'fp-muted', text: t('sth_host_note')})); }
    if (d.active !== d.serving) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn fp-thm-fallback', role: 'note', 'data-fp-sth-fallback': ''}, [UI.icon(FP.ui, 'ui_warning'),
        el('div', {}, [el('p', {text: t('sth_fallback', {theme: label(act) || d.active})}), problemList(d.problem)])]));
    }
    var acts = el('div', {class: 'fp-actions', 'data-fp-sth-rb': ''}, [el('a', {class: 'sig-btn sig-btn--secondary', href: path('resThemeDownload', {id: d.serving}),
      download: '', 'data-fp-sth-live': '', text: d.serving === 'default' ? t('sth_live_kit') : t('sth_live')})]);
    if (d.previous) {
      var prev = byId(d.previous.id);
      var what = prev && prev.host ? label(prev) : (prev ? prev.name : d.previous.id) + (d.previous.version ? ' ' + d.previous.version : '');
      parts.push(el('p', {class: 'fp-muted', text: t('thm_previous', {theme: what})}));
      acts.appendChild(el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'rollback', 'data-fp-what': what, text: t('thm_rollback')}));
    } else {
      parts.push(el('p', {class: 'fp-muted', text: t('thm_no_previous')}));
    }
    parts.push(acts);
    return M.card('fp-sth-status-h', t('sth_status_title'), parts, 'fp-thm-status fp-sth-status');
  }

  /* ---- the reseller's themes ---- */
  function themeRow(th) {
    var pills = el('span', {class: 'fp-thm-pills'}, [
      th.active ? el('span', {class: 'sig-pill sig-pill--accent', text: t('thm_active')}) : null,
      th.previous ? el('span', {class: 'sig-pill', text: t('thm_prev_pill')}) : null,
      th.host ? el('span', {class: 'sig-pill', text: t('sth_host_pill')}) : el('span', {class: 'sig-pill ' + (th.ok ? 'sig-pill--ok' : 'sig-pill--warn'), text: th.ok ? t('thm_ok') : t('thm_failed')})]);
    var body = [el('div', {class: 'fp-thm-head'}, [el('h3', {class: 'fp-h3 fp-thm-name', id: 'fp-sth-n-' + th.id, tabindex: '-1', text: label(th)}), pills])];
    if (th.host) {
      body.push(el('p', {class: 'fp-muted fp-thm-meta', text: t('sth_host_desc')}));
    } else {
      body.push(el('p', {class: 'fp-muted fp-thm-meta'}, [el('span', {class: 'sig-mono', text: th.id}), th.author ? ' · ' + t('thm_by', {author: th.author}) : '']));
      if (th.kept) { body.push(el('p', {class: 'fp-muted', text: t('thm_kept', {version: th.kept})})); }
      if (th.scripts.length) { body.push(el('p', {class: 'fp-muted', 'data-fp-sth-scripts': '', text: t('sth_scripts_note')})); }
      if (!th.ok) { body.push(problemList(th.problems)); }
    }
    var acts = el('div', {class: 'fp-actions fp-thm-acts', 'data-fp-thm-acts': th.id});
    if (th.ok && !th.host) {
      acts.appendChild(el('a', {class: 'sig-btn sig-btn--secondary sig-btn--sm', href: path('resThemePreview', {id: th.id, page: P.data.pages[0]}), target: '_blank', rel: 'noopener',
        'aria-label': t('thm_preview_of', {theme: label(th)}), text: t('thm_preview')}));
      acts.appendChild(el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'settings', 'data-fp-id': th.id,
        'aria-label': t('sth_settings_of', {theme: label(th)}), 'aria-expanded': String(P.edit === th.id), text: t('sth_settings')}));
    }
    if (!th.active && (th.ok || th.host)) {
      acts.appendChild(el('button', {class: 'sig-btn sig-btn--primary sig-btn--sm', type: 'button', 'data-fp-act': 'activate', 'data-fp-id': th.id,
        'aria-label': t('thm_activate_of', {theme: label(th)}), text: th.host ? t('sth_use_host') : t('thm_activate')}));
    }
    if (!th.host) {
      acts.appendChild(el('a', {class: 'sig-btn sig-btn--secondary sig-btn--sm', href: path('resThemeDownload', {id: th.id}), download: '',
        'aria-label': t('sth_download_of', {theme: label(th)}), text: t('sth_download')}));
    }
    if (!th.active && !th.host) {
      acts.appendChild(el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'delete', 'data-fp-id': th.id,
        'aria-label': t('thm_delete_of', {theme: label(th)}), text: t('thm_delete')}));
    }
    body.push(acts);
    if (P.edit === th.id) { body.push(settingsForm(th)); }
    return el('li', {class: 'fp-thm-item' + (th.active ? ' is-active' : ''), 'data-fp-thm': th.id}, body);
  }
  function listCard() {
    return M.card('fp-sth-list-h', t('sth_list_title'), [M.errorLine(), M.statusLine(), el('ul', {class: 'fp-thm-list'}, P.data.themes.map(themeRow))],
      'fp-thm-installed fp-sth-installed');
  }

  /* ---- a theme's settings, its colours included ---- */
  function control(f, fid) {
    var a = {class: 'sig-input', id: fid, name: f.key};
    if (f.type === 'boolean') { return el('input', {type: 'checkbox', id: fid, name: f.key, checked: f.value ? true : null}); }
    if (f.type === 'colour') {
      return el('input', {class: 'fp-sth-swatch', type: 'color', id: fid, name: f.key, value: f.value.toLowerCase()});
    }
    if (f.type === 'number' || f.type === 'integer') {
      a.type = 'number';
      a.inputmode = f.type === 'integer' ? 'numeric' : 'decimal';
      a.step = f.type === 'integer' ? '1' : 'any';
      if (f.min !== null) { a.min = String(f.min); }
      if (f.max !== null) { a.max = String(f.max); }
      a.value = String(f.value);
      return el('input', a);
    }
    a.maxlength = String(f.type === 'string' && f.max ? f.max : 2000);
    a.value = f.value;
    if (f.type === 'string' && f.multiline) { a.rows = '3'; a.class = 'sig-input sig-textarea'; return el('textarea', a); }
    a.type = f.type === 'url' ? 'url' : 'text';
    if (f.type !== 'string') { a.spellcheck = 'false'; a.autocapitalize = 'none'; }
    return el('input', a);
  }
  function settingsForm(th) {
    var box = el('div', {class: 'fp-sth-settings', 'data-fp-sth-settings': th.id});
    if (!P.fields || P.fieldsFor !== th.id) {
      box.appendChild(el('p', {class: 'fp-muted', text: P.fieldsFail || t('loading')}));
      return box;
    }
    if (!P.fields.length) { box.appendChild(el('p', {class: 'fp-muted', text: t('sth_settings_none')})); return box; }
    var rows = P.fields.map(function (f, i) {
      var fid = 'fp-sth-f-' + i;
      var c = control(f, fid);
      if (f.type === 'boolean') {
        return el('div', {class: 'sig-field'}, [el('label', {class: 'fp-check', for: fid}, [c, ' ', el('span', {text: f.label})]),
          f.help ? el('span', {class: 'sig-hint', text: f.help}) : null]);
      }
      return M.field(fid, f.label, c, f.help || (f.type === 'colour' ? t('sth_colour_hint') : ''));
    });
    var form = el('form', {class: 'fp-form fp-sth-form', novalidate: ''}, [el('h4', {class: 'fp-h3', id: 'fp-sth-set-h', tabindex: '-1', text: t('sth_settings_title', {theme: label(th)})})]
      .concat(rows, [M.errorLine(), M.statusLine(), el('div', {class: 'fp-actions'}, [
        el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('sth_settings_save')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'settings-close', text: t('cancel')})])]));
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!M.start(form)) { return; }
      var values = {};
      P.fields.forEach(function (f) {
        var c = form.querySelector('[name="' + f.key + '"]');
        if (!c) { return; }
        var v = f.type === 'boolean' ? c.checked : c.value;
        if (f.type === 'number' || f.type === 'integer') { v = c.value.trim() === '' ? null : Number(c.value); }
        if (f.type === 'colour') { v = String(v).toUpperCase(); }
        if (v !== f.value && !(f.type === 'colour' && String(f.value).toUpperCase() === v)) { values[f.key] = v; }
      });
      if (!Object.keys(values).length) { M.say(form, t('sth_settings_same')); return; }
      var b = form.querySelector('.fp-submit');
      b.disabled = true;
      var mine = P;
      FP.call('put', 'resThemeSettings', {values: values}, {id: th.id}).then(function (r) {
        if (P !== mine) { return; }
        P.fields = cleanSettings(r);
        draw('#fp-sth-set-h', '', '');
        M.say(P.page.querySelector('.fp-sth-form'), t('sth_settings_saved'));
      }, function (err) {
        if (P !== mine) { return; }
        b.disabled = false;
        M.failed(form, err);
      });
    });
    box.appendChild(form);
    return box;
  }
  function openSettings(tid) {
    var mine = P;
    P.edit = tid;
    P.fields = null;
    P.fieldsFor = '';
    P.fieldsFail = '';
    draw('', '', '');
    FP.call('get', 'resThemeSettings', undefined, {id: tid}).then(function (r) {
      if (P !== mine || P.edit !== tid) { return; }
      P.fields = cleanSettings(r);
      P.fieldsFor = tid;
      draw('#fp-sth-set-h', '', '');
    }, function (err) {
      if (P !== mine || P.edit !== tid) { return; }
      P.fieldsFail = (err && err.message) || t('api_failed');
      draw('#fp-sth-n-' + tid, '', '');
    });
  }

  /* ---- upload ---- */
  function uploadCard() {
    var file = el('input', {class: 'sig-input fp-up-file', id: 'fp-sth-file', name: 'zip', type: 'file', accept: '.zip,application/zip', disabled: P.sending ? true : null});
    var acts = el('div', {class: 'fp-actions', 'data-fp-sth-up-acts': ''}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('thm_upload'),
      disabled: P.sending ? true : null})]);
    var form = el('form', {class: 'fp-form fp-sth-upload', novalidate: ''}, [el('p', {class: 'fp-muted', text: t('sth_upload_desc')}),
      M.field('fp-sth-file', t('thm_file'), file, t('thm_file_hint')), M.errorLine(), el('div', {'data-fp-sth-up-problems': ''}), M.statusLine(), acts]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (P.sending || !M.start(form)) { return; }
      form.querySelector('[data-fp-sth-up-problems]').textContent = '';
      var f = file.files && file.files[0];
      if (!f) { M.fieldError(form, file, t('thm_file_none')); return; }
      if (!/\.zip$/i.test(f.name)) { M.fieldError(form, file, t('thm_file_bad')); return; }
      if (!f.size) { M.fieldError(form, file, t('thm_file_empty')); return; }
      if (f.size > MAX_UPLOAD) { M.fieldError(form, file, t('thm_file_big')); return; }
      send(form, f);
    });
    return M.card('fp-sth-up-h', t('thm_upload_title'), [form], 'fp-sth-up');
  }
  function send(form, f) {
    var mine = P;
    var acts = form.querySelector('[data-fp-sth-up-acts]');
    var bar = el('progress', {class: 'fp-up-bar', max: '100', value: '0', 'aria-labelledby': 'fp-sth-sending'});
    var line = el('span', {id: 'fp-sth-sending', text: t('thm_sending', {file: f.name, n: '0'})});
    var stop = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'stop', text: t('thm_stop')});
    acts.textContent = '';
    acts.appendChild(el('div', {class: 'fp-up-progress', 'data-fp-sth-progress': ''}, [line, bar]));
    acts.appendChild(stop);
    form.querySelector('#fp-sth-file').disabled = true;
    stop.focus();
    var shown = -1;
    P.sending = window.FPAPI.upload('resThemeUpload', f, 'application/zip', undefined, function (x) {
      var n = Math.floor(x * 100);
      bar.value = n;
      if (n - shown >= 10 || n === 100) { shown = n; line.textContent = n === 100 ? t('thm_checking') : t('thm_sending', {file: f.name, n: String(n)}); }
    });
    P.sending.done.then(function (r) {
      if (P !== mine) { return; }
      P.sending = null;
      var it = cleanTheme(r && r.installed);
      P.data = clean(r && r.list);
      var said = it ? t('thm_installed', {theme: label(it)}) : t('thm_installed_some');
      if (r && typeof r.replaced === 'string' && r.replaced) { said += ' ' + t('thm_replaced', {version: str(r.replaced, 32)}); }
      draw('#fp-sth-up-h', said, '.fp-sth-up');
    }, function (err) {
      if (P !== mine) { return; }
      P.sending = null;
      if (err && err.status === 401) { FP.signedOut(true); return; }
      draw('', '', '');
      var now = P.page.querySelector('.fp-sth-upload');
      if (err && err.code === 'aborted') { M.say(now, t('thm_stopped')); now.querySelector('#fp-sth-file').focus(); return; }
      var ps = err && Array.isArray(err.problems) ? problems(err.problems) : [];
      M.fieldError(now, now.querySelector('#fp-sth-file'), ps.length ? t('thm_refused', {n: String(ps.length)}) : (err && err.message) || t('api_failed'));
      if (ps.length) { now.querySelector('[data-fp-sth-up-problems]').appendChild(problemList(ps, 'fp-thm-up-list')); }
    });
  }

  /* ---- the theme kit ---- */
  function kitCard() {
    return M.card('fp-sth-kit-h', t('thm_kit_title'), [el('p', {class: 'fp-muted', text: t('sth_kit_desc')}),
      el('div', {class: 'fp-actions'}, [el('a', {class: 'sig-btn sig-btn--secondary', href: path('resThemeKit'), download: '', 'data-fp-sth-kit': '', text: t('thm_kit')})])], 'fp-sth-kit');
  }

  /* ---- the brand colour of the reseller's own customers' hosting panel ---- */
  function colourCard() {
    var c = P.colour;
    var parts = [el('p', {class: 'fp-muted', text: t('sth_panel_desc')})];
    if (!c) {
      parts.push(el('p', {class: 'fp-muted', text: P.colourFail || t('loading')}));
    } else if (!c.allowed) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-sth-panel-off': '', text: t('sth_panel_off')}));
    } else {
      var pick = el('input', {class: 'fp-sth-swatch', type: 'color', id: 'fp-sth-accent', name: 'accent', value: (c.accent || '#0E5E57').toLowerCase()});
      var form = el('form', {class: 'fp-form fp-sth-panel', novalidate: ''}, [
        el('p', {'data-fp-sth-panel-now': '', text: c.accent ? t('sth_panel_now', {colour: c.accent}) : t('sth_panel_none')}),
        M.field('fp-sth-accent', t('sth_panel_label'), pick, t('sth_panel_hint')), M.errorLine(), M.statusLine(),
        el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('sth_panel_save')}),
          c.accent ? el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'panel-reset', text: t('sth_panel_reset')}) : null])]);
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!M.start(form)) { return; }
        setColour(form, pick.value.toUpperCase());
      });
      parts.push(form);
    }
    return M.card('fp-sth-panel-h', t('sth_panel_title'), parts, 'fp-sth-panel-card');
  }
  function setColour(form, accent) {
    var mine = P;
    var b = form.querySelector('.fp-submit');
    b.disabled = true;
    FP.call('put', 'resellerBrandingColour', {accent: accent}, {name: FP.account()}).then(function (r) {
      if (P !== mine) { return; }
      P.colour = {allowed: true, accent: r && HEX_RE.test(r.accent) ? r.accent.toUpperCase() : ''};
      draw('#fp-sth-panel-h', accent ? t('sth_panel_saved', {colour: accent}) : t('sth_panel_cleared'), '.fp-sth-panel-card');
    }, function (err) {
      if (P !== mine) { return; }
      b.disabled = false;
      M.failed(form, err);
    });
  }
  function loadColour() {
    var mine = P;
    FP.call('get', 'resellerBranding', undefined, {name: FP.account()}).then(function (r) {
      if (P !== mine) { return; }
      r = r && typeof r === 'object' ? r : {};
      P.colour = {allowed: r.allowed === true, accent: HEX_RE.test(r.accent) ? r.accent.toUpperCase() : ''};
      if (P.data) { draw('', '', ''); }
    }, function (err) {
      if (P !== mine) { return; }
      P.colourFail = (err && err.message) || t('api_failed');
      if (P.data) { draw('', '', ''); }
    });
  }

  /* ---- the questions and the changes ---- */
  function ask(cell, question, act, yes, extra) {
    M.confirmIn(cell, question, act, yes);
    var b = cell.querySelector('[data-fp-act="' + act + '"]');
    Object.keys(extra || {}).forEach(function (k) { b.setAttribute(k, extra[k]); });
    b.classList.remove('sig-btn--sm');
    if (act !== 'delete-yes') { b.classList.remove('sig-btn--danger'); b.classList.add('sig-btn--primary'); }
  }
  function change(method, name, arg, said, scope) {
    var mine = P;
    Array.prototype.forEach.call(P.page.querySelectorAll('button'), function (b) { b.disabled = true; });
    FP.call(method, name, method === 'del' ? undefined : {}, arg).then(function (r) {
      if (P !== mine) { return; }
      P.data = clean(r);
      if (P.edit && !byId(P.edit)) { P.edit = ''; }
      draw(scope === 'status' ? '#fp-sth-status-h' : '#fp-sth-list-h', said, scope === 'status' ? '.fp-sth-status' : '.fp-sth-installed');
    }, function (err) {
      if (P !== mine) { return; }
      draw('', '', '');
      var card = P.page.querySelector(scope === 'status' ? '.fp-sth-status' : '.fp-sth-installed');
      var ps = err && Array.isArray(err.problems) ? problems(err.problems) : [];
      UI.showError(card, (err && err.message) || t('api_failed'));
      var line = card.querySelector('[data-fp-error]');
      if (ps.length && line) { line.appendChild(problemList(ps)); }
      var head = card.querySelector('.fp-h2');
      if (head) { head.focus({preventScroll: true}); }
    });
  }
  function onClick(e) {
    var b = e.target.closest('[data-fp-act]');
    if (!b || !P.page.contains(b)) { return; }
    var act = b.getAttribute('data-fp-act');
    var th = byId(id(b.getAttribute('data-fp-id')));
    if (act === 'stop') { if (P.sending) { P.sending.abort(); } return; }
    if (act === 'confirm-no') { var keep = b.closest('[data-fp-thm-acts]'); draw(keep ? '#fp-sth-n-' + keep.getAttribute('data-fp-thm-acts') : '#fp-sth-status-h', '', ''); return; }
    if (act === 'settings' && th) { if (P.edit === th.id) { P.edit = ''; draw('#fp-sth-n-' + th.id, '', ''); } else { openSettings(th.id); } return; }
    if (act === 'settings-close') { var was = P.edit; P.edit = ''; draw('#fp-sth-n-' + was, '', ''); return; }
    if (act === 'panel-reset') { var form = b.closest('form'); if (M.start(form)) { setColour(form, ''); } return; }
    if (act === 'activate' && th) {
      ask(b.parentNode, th.host ? t('sth_use_host_ask') : t('sth_activate_ask', {theme: label(th)}), 'activate-yes', t('thm_activate_yes'), {'data-fp-id': th.id});
      return;
    }
    if (act === 'delete' && th) { ask(b.parentNode, t('thm_delete_ask', {theme: label(th)}), 'delete-yes', t('thm_delete_yes'), {'data-fp-id': th.id}); return; }
    if (act === 'rollback') { ask(b.parentNode, t('sth_rollback_ask', {theme: b.getAttribute('data-fp-what') || ''}), 'rollback-yes', t('thm_rollback_yes')); return; }
    if (act === 'activate-yes' && th) { change('post', 'resThemeActivate', {id: th.id}, t('sth_activated', {theme: label(th)}), 'list'); return; }
    if (act === 'delete-yes' && th) { change('del', 'resTheme', {id: th.id}, t('thm_deleted', {theme: label(th)}), 'list'); return; }
    if (act === 'rollback-yes') { change('post', 'resThemeRollback', undefined, t('thm_rolled_back'), 'status'); }
  }

  function draw(focus, said, sayIn) {
    var page = P.page;
    page.textContent = '';
    page.appendChild(statusCard());
    page.appendChild(listCard());
    page.appendChild(uploadCard());
    page.appendChild(kitCard());
    page.appendChild(colourCard());
    if (said) { M.say(sayIn ? page.querySelector(sayIn) : page, said); }
    var target = focus ? page.querySelector(focus) : null;
    if (target) { target.focus(); }
  }

  FP.view('tool:store_themes', function () {
    if (P && P.sending) { P.sending.abort(); }
    P = null;
    var tool = FP.tools.store_themes;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'reseller') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('sth_desc'), cls: 'fp-mail fp-thm-page fp-sth-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    if (!page) { return; }
    P = {page: page, data: null, sending: null, edit: '', fields: null, fieldsFor: '', fieldsFail: '', colour: null, colourFail: ''};
    var mine = P;
    page.addEventListener('click', onClick);
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    loadColour();
    FP.call('get', 'resThemes').then(function (r) {
      if (P !== mine) { return; }
      P.data = clean(r);
      draw('', '', '');
    }, function (err) {
      if (P !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err && err.message ? err.message : t('sth_unavailable')));
    });
  });
})();

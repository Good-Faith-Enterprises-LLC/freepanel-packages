/* freePanel admin API tokens (docs/api.md, "An admin's API tokens"), in the admin panel: #/tool/api_tokens_admin, the server admin's alone. A token lets a script
   call the admin panel's API without a session. The page lists the admin's own tokens (never a secret: the server keeps only a hash, and the list shows the first
   eight characters to tell tokens apart), makes one (asking for the admin's own password again) and revokes one after asking. The secret of a new token is in the
   answer that makes it and nowhere else, so it is shown once: in a card of its own, as text, held in this script and nowhere in the page's attributes, in no
   storage and in no address, and gone when the admin says it is copied, when the page is left or when the browser puts the page away. While it is shown the form
   to make another waits, so a token cannot be lost to the next. A short guide says how a token is used and what each scope may do. What the server sends is
   cleaned to the shapes drawn and shown as text. Page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var MAX_TOKENS = 20;
  var MAX_ADDRESSES = 10;
  var DEFAULT_DAYS = 90;
  var MAX_DAYS = 365;
  var NAME_RE = /^[A-Za-z0-9][A-Za-z0-9 ._-]{0,63}$/;
  var PREFIX_RE = /^[A-Za-z0-9_-]{1,16}$/;
  var SCOPES = ['read', 'full'];
  var DAY_MS = 86400000;

  var S = null;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function arr(v) { return Array.isArray(v) ? v : []; }
  function when(v) {
    var d = typeof v === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(v) ? new Date(v) : null;
    return d && !isNaN(d.getTime()) ? d : null;
  }
  function dateText(d) { return d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'}); }

  function cleanToken(x) {
    if (!x || typeof x !== 'object' || typeof x.id !== 'number' || !isFinite(x.id) || x.id < 1) { return null; }
    return {id: Math.floor(x.id), name: str(x.name, 64), scope: SCOPES.indexOf(x.scope) >= 0 ? x.scope : '', prefix: PREFIX_RE.test(str(x.prefix, 16)) ? x.prefix : '',
      addresses: arr(x.addresses).filter(function (a) { return typeof a === 'string'; }).map(function (a) { return a.slice(0, 64); }).slice(0, MAX_ADDRESSES),
      created: when(x.created_at), expires: when(x.expires_at), expired: x.expired === true, used: when(x.last_used_at), usedFrom: str(x.last_used_ip, 45)};
  }
  function cleanList(r) {
    return arr(r && r.tokens).map(cleanToken).filter(Boolean).slice(0, MAX_TOKENS * 2);
  }

  /* ---- the new token, shown once ---- */
  function freshCard() {
    var f = S.fresh;
    var secret = el('code', {class: 'sig-mono fp-atok-secret', id: 'fp-atok-secret', tabindex: '0', role: 'group', 'aria-label': t('atok_secret_label', {name: f.name}), text: f.token});
    return M.card('fp-atok-fresh-h', t('atok_fresh_title', {name: f.name}), [
      M.statusLine(),
      el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-once': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('atok_once')})]),
      secret,
      el('p', {class: 'fp-muted', text: t(f.scope === 'full' ? 'atok_fresh_full' : 'atok_fresh_read')}),
      el('div', {class: 'fp-actions'}, [
        el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'copy'}, [UI.icon(FP.ui, 'ui_copy'), t('atok_copy')]),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'done', text: t('atok_done')})])], 'fp-atok-fresh');
  }

  /* ---- the tokens ---- */
  function tokenRow(k) {
    var now = Date.now();
    var life;
    if (k.expired || (k.expires && k.expires.getTime() <= now)) {
      life = el('span', {class: 'sig-pill sig-pill--danger', 'data-fp-expired': '', text: t('atok_expired')});
    } else if (k.expires) {
      var days = Math.max(1, Math.ceil((k.expires.getTime() - now) / DAY_MS));
      life = el('span', {class: 'fp-muted', text: t(days === 1 ? 'atok_ends_1' : 'atok_ends', {days: days, when: dateText(k.expires)})});
    } else {
      life = null;
    }
    var used = k.used ? t('atok_used', {when: dateText(k.used), from: k.usedFrom || t('atok_used_unknown')}) : t('atok_never');
    return el('li', {class: 'fp-rpp-row fp-atok-row', 'data-fp-token': String(k.id)}, [
      el('div', {class: 'fp-rpp-main'}, [
        el('span', {class: 'fp-atok-head'}, [el('span', {class: 'fp-rpp-title', text: k.name}),
          k.scope ? el('span', {class: 'sig-pill' + (k.scope === 'full' ? ' sig-pill--warn' : ''), text: t('atok_scope_' + k.scope)}) : null, life]),
        k.prefix ? el('span', {class: 'fp-muted sig-mono fp-row-note', text: t('atok_prefix', {prefix: k.prefix})}) : null,
        el('span', {class: 'fp-muted fp-row-note', text: used}),
        el('span', {class: 'fp-muted fp-row-note', 'data-fp-from': '', text: k.addresses.length ? t('atok_from', {list: k.addresses.join(', ')}) : t('atok_anywhere')}),
        k.created ? el('span', {class: 'fp-muted fp-row-note', text: t('atok_made', {when: dateText(k.created)})}) : null]),
      el('span', {class: 'fp-rpp-acts fp-atok-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'revoke',
        'aria-label': t('atok_revoke_of', {name: k.name}), text: t('atok_revoke')})])]);
  }
  function listCard() {
    var parts = [M.errorLine(), M.statusLine()];
    if (!S.tokens.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': 'tokens', text: t('atok_none')}));
    } else {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-count': '', text: t(S.tokens.length === 1 ? 'atok_count_1' : 'atok_count', {n: S.tokens.length, max: MAX_TOKENS})}));
      parts.push(el('ul', {class: 'fp-rpp-list'}, S.tokens.map(tokenRow)));
    }
    return M.card('fp-atok-list-h', t('atok_list_title'), parts, 'fp-atok-list');
  }

  /* ---- making one ---- */
  function addressesOf(text) {
    return text.split(/[\s,;]+/).filter(Boolean);
  }
  function scopeField() {
    var radios = SCOPES.map(function (s) {
      var id = 'fp-atok-scope-' + s;
      var input = el('input', {type: 'radio', id: id, name: 'scope', value: s, checked: s === 'read' ? true : null, 'aria-describedby': id + '-hint'});
      return el('div', {class: 'fp-atok-choice'}, [el('label', {class: 'fp-check', for: id}, [input, el('span', {text: t('atok_scope_' + s)})]),
        el('span', {class: 'sig-hint', id: id + '-hint', text: t('atok_scope_' + s + '_hint')})]);
    });
    return el('fieldset', {class: 'sig-field fp-atok-scopes'}, [el('legend', {class: 'sig-label', text: t('atok_scope')})].concat(radios));
  }
  function makeCard() {
    if (S.tokens.length >= MAX_TOKENS) {
      return M.card('fp-atok-make-h', t('atok_make_title'), [el('p', {class: 'fp-muted', 'data-fp-full': '', text: t('atok_full', {max: MAX_TOKENS})})], 'fp-atok-make');
    }
    var name = el('input', {class: 'sig-input', id: 'fp-atok-name', name: 'name', type: 'text', maxlength: '64', autocomplete: 'off', spellcheck: 'false'});
    var days = el('input', {class: 'sig-input fp-num-input', id: 'fp-atok-days', name: 'expires_days', type: 'number', inputmode: 'numeric', min: '1', max: String(MAX_DAYS), step: '1', value: String(DEFAULT_DAYS)});
    var addrs = el('textarea', {class: 'sig-input sig-mono', id: 'fp-atok-addresses', name: 'addresses', rows: '3', spellcheck: 'false', autocapitalize: 'none', autocomplete: 'off',
      placeholder: '203.0.113.7\n10.0.0.0/24'});
    var pw = el('input', {class: 'sig-input', id: 'fp-atok-password', name: 'current_password', type: 'password', autocomplete: 'current-password'});
    var form = el('form', {class: 'fp-form fp-rpp-form fp-atok-form', novalidate: ''}, [M.errorLine(),
      M.field('fp-atok-name', t('atok_name'), name, t('atok_name_hint')), scopeField(),
      M.field('fp-atok-days', t('atok_days'), days, t('atok_days_hint', {max: MAX_DAYS})),
      M.field('fp-atok-addresses', t('atok_addresses'), addrs, t('atok_addresses_hint', {max: MAX_ADDRESSES})),
      M.field('fp-atok-password', t('atok_password'), pw, t('atok_password_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('atok_make')})])]);
    form.addEventListener('submit', function (e) { e.preventDefault(); make(form); });
    return M.card('fp-atok-make-h', t('atok_make_title'), [el('p', {class: 'fp-muted', text: t('atok_make_intro')}), form], 'fp-atok-make');
  }
  function make(form) {
    var b = M.start(form);
    if (!b) { return; }
    var name = UI.fieldNamed(form, 'name');
    var days = UI.fieldNamed(form, 'expires_days');
    var pw = UI.fieldNamed(form, 'current_password');
    var list = addressesOf(UI.fieldNamed(form, 'addresses').value);
    var n = name.value.trim();
    var d = days.value.trim();
    if (!NAME_RE.test(n)) { M.fieldError(form, name, t('atok_name_bad')); return; }
    if (!/^[0-9]{1,3}$/.test(d) || Number(d) < 1 || Number(d) > MAX_DAYS) { M.fieldError(form, days, t('atok_days_bad', {max: MAX_DAYS})); return; }
    if (list.length > MAX_ADDRESSES) { M.fieldError(form, UI.fieldNamed(form, 'addresses'), t('atok_addresses_many', {max: MAX_ADDRESSES})); return; }
    if (!pw.value) { M.fieldError(form, pw, t('atok_need_password')); return; }
    var body = {name: n, scope: form.querySelector('input[name="scope"]:checked').value, expires_days: Number(d), addresses: list, current_password: pw.value};
    var mine = S;
    UI.setBusy(b, true);
    FP.call('post', 'apiTokens', body).then(function (r) {
      /* made: what was typed is done with (the form is drawn new after the secret is dealt with) */
      form.reset();
      if (S !== mine) { return; }
      var k = cleanToken(r);
      var token = typeof r.token === 'string' && /^fpt_[A-Za-z0-9_-]{20,80}$/.test(r.token) ? r.token : '';
      if (!token || !k) {
        /* made, but the answer is not one the page can show: the list says what exists */
        mine.fresh = null;
        reload(t('atok_made_unseen'));
        return;
      }
      mine.fresh = {name: k.name, scope: k.scope, token: token};
      mine.tokens = [k].concat(mine.tokens.filter(function (x) { return x.id !== k.id; }));
      draw();
      mine.page.querySelector('#fp-atok-fresh-h').focus();
    }, function (err) {
      UI.setBusy(b, false);
      if (S !== mine) { return; }
      /* refused or cut: everything typed stays, the password too, so the admin can correct one field and send again */
      if (err && err.status === 0) {
        /* the answer may have been lost after the token was made, and nothing here can show it: the admin is told, and the list is read again so the token is in it */
        UI.showError(form, err.message + ' ' + t('atok_cut'));
        FP.call('get', 'apiTokens').then(function (r) {
          if (S === mine && !mine.fresh) { mine.tokens = cleanList(r); redrawList(); }
        }, function () { /* the list stays as it was */ });
        return;
      }
      /* a wrong password is the password field's: it is marked and takes the focus, in the server's own words */
      if (err && err.status === 403) { M.fieldError(form, pw, err.message); return; }
      M.failed(form, err);
    });
  }

  /* ---- the guide ---- */
  function guideCard() {
    var origin = window.location.origin;
    var example = 'curl -H "Authorization: Bearer fpt_…" ' + origin + '/api/v1/server/status';
    return M.card('fp-atok-guide-h', t('atok_guide_title'), [
      el('p', {class: 'fp-muted', text: t('atok_guide_1')}),
      el('pre', {class: 'sig-mono fp-atok-example', tabindex: '0', role: 'region', 'aria-label': t('atok_example_label'), 'data-fp-example': '', text: example}),
      el('ul', {class: 'fp-atok-points'}, ['atok_point_scope', 'atok_point_session', 'atok_point_audit', 'atok_point_password', 'atok_point_port', 'atok_point_addresses'].map(function (k) {
        return el('li', {class: 'fp-muted', text: t(k)});
      })),
      // the routes are in this panel's own API reference page, when this build has it (it is the admin panel's page of docs/api.md); never a link to anywhere else
      FP.tools.api_reference ? el('p', {class: 'fp-muted fp-atok-ref'}, [document.createTextNode(t('atok_ref') + ' '), el('a', {href: '#/tool/api_reference', text: FP.tools.api_reference.label})]) : null], 'fp-atok-guide');
  }

  /* ---- the page ---- */
  function draw() {
    S.page.textContent = '';
    if (S.fresh) { S.page.appendChild(freshCard()); }
    S.page.appendChild(listCard());
    if (!S.fresh) { S.page.appendChild(makeCard()); }
    S.page.appendChild(guideCard());
  }
  function redrawList() {
    var old = S.page.querySelector('.fp-atok-list');
    if (old) { S.page.replaceChild(listCard(), old); }
  }
  /* the list again, with a sentence in its card when there is one to say */
  function reload(note) {
    var mine = S;
    return FP.call('get', 'apiTokens').then(function (r) {
      if (S !== mine) { return; }
      mine.tokens = cleanList(r);
      draw();
      if (note) { M.say(mine.page.querySelector('.fp-atok-list'), note); }
    }, function (err) {
      if (S !== mine) { return; }
      UI.showError(mine.page.querySelector('.fp-atok-list'), err.message);
    });
  }
  function forget() {
    if (S && S.fresh) {
      S.fresh = null;
      var secret = S.page && S.page.querySelector('#fp-atok-secret');
      if (secret) { secret.textContent = ''; }
    }
  }
  function copy(button) {
    var scope = S.page.querySelector('.fp-atok-fresh');
    var secret = S.page.querySelector('#fp-atok-secret');
    function selected() {
      var range = document.createRange();
      range.selectNodeContents(secret);
      var sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
      M.say(scope, t('atok_selected'));
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(S.fresh.token).then(function () { M.say(scope, t('atok_copied')); }, selected);
    } else {
      selected();
    }
    button.focus();
  }
  function onClick(e) {
    var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !S || !S.page.contains(b)) { return; }
    var act = b.getAttribute('data-fp-act');
    var mine = S;
    if (act === 'copy' && S.fresh) {
      copy(b);
    } else if (act === 'done') {
      forget();
      draw();
      S.page.querySelector('#fp-atok-list-h').focus();
    } else if (act === 'again') {
      start(true);
    } else if (act === 'revoke') {
      var row = b.closest('li');
      var k = S.tokens.filter(function (x) { return String(x.id) === row.getAttribute('data-fp-token'); })[0];
      M.confirmIn(b.closest('.fp-atok-acts'), t('atok_revoke_ask', {name: k ? k.name : ''}), 'revoke-yes', t('atok_revoke'));
    } else if (act === 'confirm-no') {
      draw();
    } else if (act === 'revoke-yes') {
      var li = b.closest('li');
      var id = li.getAttribute('data-fp-token');
      var token = S.tokens.filter(function (x) { return String(x.id) === id; })[0];
      UI.setBusy(b, true);
      FP.call('del', 'apiToken', undefined, {id: id}).then(function () {
        if (S !== mine) { return; }
        mine.tokens = mine.tokens.filter(function (x) { return String(x.id) !== id; });
        draw();
        M.say(mine.page.querySelector('.fp-atok-list'), t('atok_revoked', {name: token ? token.name : ''}));
        mine.page.querySelector('#fp-atok-list-h').focus();
      }, function (err) {
        UI.setBusy(b, false);
        if (S !== mine) { return; }
        if (err && err.status === 404) {
          /* gone already: the list is what it is now */
          reload('').then(function () { UI.showError(mine.page.querySelector('.fp-atok-list'), err.message); });
        } else {
          UI.showError(mine.page.querySelector('.fp-atok-list'), err.message);
        }
      });
    }
  }

  function start(again) {
    forget();
    S = null;
    var tool = FP.tools.api_tokens_admin;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('atok_desc'), cls: 'fp-mail fp-rpp fp-atok-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    var mine = S = {page: page, tokens: [], fresh: null};
    page.addEventListener('click', onClick);
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    if (again) { document.getElementById('fp-h1').focus(); }
    FP.call('get', 'apiTokens').then(function (r) {
      if (S !== mine) { return; }
      mine.tokens = cleanList(r);
      draw();
    }, function (err) {
      if (S !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err.message, el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'again', text: t('atok_try_again')})));
    });
  }
  /* a page the browser puts away (a link off the panel, a close) must not come back with the secret on it */
  window.addEventListener('pagehide', forget);
  /* leaving the page for another of the panel drops the secret with the page; this also covers a route that draws nothing of ours */
  window.addEventListener('hashchange', function () { if (S && window.location.hash !== '#/tool/api_tokens_admin') { forget(); } });
  FP.view('tool:api_tokens_admin', function () { start(false); });
})();

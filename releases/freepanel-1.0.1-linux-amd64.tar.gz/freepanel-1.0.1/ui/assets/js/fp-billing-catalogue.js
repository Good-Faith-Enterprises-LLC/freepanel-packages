/* freePanel billing catalogue (#/tool/billing_catalogue; docs/api.md, "Billing: catalogue"; docs/billing/navigation-map.md,
   "Products/Services"): the product groups, the plans in them and the add-ons. The plan form takes, in order, Details (group, name,
   description, package, visibility, status, stock) and Pricing (a price for each term, the setup fee, the free domain from); a plan's add-ons
   and options are set on its own card. Prices are whole cents, typed in dollars and cents; a term with no price is not sold. A plan or an
   add-on is removed only once retired, after a question. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;
  var M = FP.mail;

  var PLAN = {id: 'id', group_id: 'id', name: [60], description: [500], package: [64], visibility: ['=', ['public', 'hidden']], status: ['=', ['active', 'retired']], setup_cents: 'c',
    stock_limit: 'n', free_domain_from: [12]};
  var ADDON = {id: 'id', name: [60], description: [200], status: ['=', ['active', 'retired']], setup_cents: 'c', plans: 'n'};
  /* prices as flat fields (price_monthly ...), so the form reads and compares them one by one */
  function flat(x, spec) {
    var v = B.pick(x, spec);
    if (!v) { return null; }
    B.TERMS.forEach(function (k) { var c = x.prices && x.prices[k] !== null && x.prices[k] !== undefined ? B.cents(x.prices[k]) : null; v['price_' + k] = c; });
    return v;
  }
  /* the flat price fields back into prices; on a change only the terms that changed, null taking one away */
  function prices(body) {
    var out = {};
    B.TERMS.forEach(function (k) { if (Object.prototype.hasOwnProperty.call(body, 'price_' + k)) { out[k] = body['price_' + k]; delete body['price_' + k]; } });
    if (Object.keys(out).length) { body.prices = out; }
    return false;
  }
  function priceSpecs() {
    return B.TERMS.map(function (k) { return {name: 'price_' + k, label: t('bcg_price', {term: B.termText(k)}), kind: 'amount', empty: null, hint: k === 'monthly' ? t('bcg_price_hint') : null}; })
      .concat([{name: 'setup_cents', label: t('bcg_setup'), kind: 'amount', empty: 0, hint: t('bcg_setup_hint')}]);
  }
  function priceSummary(v) {
    var have = B.TERMS.filter(function (k) { return v['price_' + k] !== null; });
    return have.length ? have.map(function (k) { return B.termText(k) + ' ' + B.money(v['price_' + k], 'USD'); }).join(', ') : t('bcg_no_price');
  }
  function strings(p) {
    return {none: t(p + '_none'), addTitle: t(p + '_add_title'), addSave: t(p + '_add'), editTitle: function (n) { return t('bil_change_title', {name: n}); },
      added: function (n) { return t('bil_added', {name: n}); }, saved: function (n) { return t('bil_saved', {name: n}); }, removed: function (n) { return t('bil_removed', {name: n}); },
      removeAsk: function (n) { return t(p + '_remove_ask', {name: n}); }, removeYes: t(p + '_remove_yes')};
  }
  function statusPill(s) { return B.pill(t(s === 'retired' ? 'bcg_retired' : 'bcg_active'), s === 'retired' ? '' : 'ok'); }

  FP.view('tool:billing_catalogue', function () {
    var page = B.frame('billing_catalogue', 'fp-bcg');
    if (!page) { return; }
    var alive = function () { return page.isConnected; };
    var groups = [];
    var packages = [];
    var addons = [];
    var gBox = el('div');
    var pBox = el('div', {class: 'fp-bcg-part'});
    var planBox = el('div', {class: 'fp-bcg-part'});
    var aBox = el('div', {class: 'fp-bcg-part'});
    function gName(gid) { for (var i = 0; i < groups.length; i++) { if (groups[i].id === gid) { return groups[i].name; } } return '—'; }
    var G = B.crud({page: gBox, pre: 'fp-bcgg', title: t('bcg_groups'), alive: alive,
      what: function () { return [el('p', {class: 'fp-muted', text: t('bcg_groups_what')})]; },
      load: function () { return FP.call('get', 'billingProductGroups').then(function (r) { groups = B.pickAll(r && r.groups, {id: 'id', name: [60], description: [200], plans: 'n'}, 'id'); return groups; }); },
      heads: [B.th(t('bcg_col_name')), B.th(t('bcg_col_desc')), B.th(t('bcg_col_plans'), 'fp-bil-num')],
      cells: function (g) { return [el('th', {scope: 'row', class: 'fp-bil-wrap', text: g.name}), el('td', {class: 'fp-bil-wrap', text: g.description || '—'}), el('td', {class: 'fp-bil-num', text: g.plans === null ? '—' : B.num(g.plans)})]; },
      removable: function (g) { return !g.plans; },
      fields: [{name: 'name', label: t('bcg_col_name'), required: true, max: 60}, {name: 'description', label: t('bcg_col_desc'), max: 200}],
      add: 'billingProductGroups', item: 'billingProductGroup', nameOf: function (g) { return g.name; }, strings: strings('bcgg'),
      changed: function () { if (alive()) { P.show(); } }});
    var P = B.crud({page: pBox, pre: 'fp-bcgp', title: t('bcg_plans'), alive: alive,
      what: function () { return [el('p', {class: 'fp-muted', text: t('bcg_plans_what')})]; },
      load: function () { return FP.call('get', 'billingPlans', undefined, {}).then(function (r) { return (r && Array.isArray(r.plans) ? r.plans : []).map(function (x) { return flat(x, PLAN); }).filter(function (x) { return x && x.id; }); }); },
      heads: [B.th(t('bcg_col_name')), B.th(t('bcg_col_group')), B.th(t('bcg_col_package')), B.th(t('bcg_col_prices')), B.th(t('bcg_col_status'))],
      cells: function (v) {
        return [el('th', {scope: 'row', class: 'fp-bil-wrap'}, [el('span', {text: v.name}), v.visibility === 'hidden' ? el('span', {class: 'fp-muted', text: ' ' + t('bon_hidden_mark')}) : null]),
          el('td', {class: 'fp-bil-wrap', text: gName(v.group_id)}), el('td', {text: v.package || '—'}), el('td', {class: 'fp-bil-wrap', text: priceSummary(v)}), el('td', null, [statusPill(v.status)])];
      },
      removable: function (v) { return v.status === 'retired'; },
      rowActs: function (v) { return [B.button('plan-extras', t('bcg_extras'), 'sig-btn--secondary sig-btn--sm', {'data-fp-key': String(v.id), 'aria-label': t('bcg_extras_of', {name: v.name})})]; },
      onAct: function (a, key, b, v) { if (a === 'plan-extras' && v) { extras(v, b); } },
      canAdd: function () { return groups.length > 0; },
      below: function () { return groups.length ? [] : [el('p', {class: 'fp-muted', 'data-fp-no-group': '', text: t('bcg_no_group')})]; },
      fieldsFor: function (x) {
        var details = (x ? [] : [{name: 'group_id', label: t('bcg_col_group'), kind: 'select', num: true, options: groups.map(function (g) { return [String(g.id), g.name]; }), value: groups.length ? groups[0].id : ''}]).concat([
          {name: 'name', label: t('bcg_col_name'), required: true, max: 60}, {name: 'description', label: t('bcg_col_desc'), kind: 'textarea', max: 500, rows: 3, wide: true, send_empty: true},
          packages.length ? {name: 'package', label: t('bcg_col_package'), kind: 'select', options: packages.map(function (n) { return [n, n]; }), value: packages[0], hint: t('bcg_package_hint')} :
            {name: 'package', label: t('bcg_col_package'), required: true, max: 64, hint: t('bcg_package_hint')},
          {name: 'visibility', label: t('bcg_visibility'), kind: 'select', options: [['public', t('bcg_public')], ['hidden', t('bcg_hidden')]], value: 'public', hint: t('bcg_visibility_hint')},
          {name: 'status', label: t('bcg_col_status'), kind: 'select', options: [['active', t('bcg_active')], ['retired', t('bcg_retired')]], value: 'active', hint: t('bcg_status_hint')},
          {name: 'stock_limit', label: t('bcg_stock'), kind: 'number', max: 7, empty: null, hint: t('bcg_stock_hint')}]);
        return details.concat(priceSpecs()).concat([{name: 'free_domain_from', label: t('bcg_free_domain'), kind: 'select', options: [['', t('bcg_free_none')]].concat(B.TERMS.map(function (k) { return [k, B.termText(k)]; })),
          hint: t('bcg_free_domain_hint'), send_empty: true}]);
      },
      check: function (body) {
        prices(body);
        if (Object.prototype.hasOwnProperty.call(body, 'free_domain_from') && body.free_domain_from === '') { body.free_domain_from = null; }
        return false;
      },
      add: 'billingPlanNew', item: 'billingPlan', nameOf: function (v) { return v.name; }, strings: strings('bcgp'),
      changed: function () { if (alive()) { G.show(); } }});
    var A2 = B.crud({page: aBox, pre: 'fp-bcga', title: t('bcg_addons'), alive: alive,
      what: function () { return [el('p', {class: 'fp-muted', text: t('bcg_addons_what')})]; },
      load: function () { return FP.call('get', 'billingAddons', undefined, {}).then(function (r) { addons = (r && Array.isArray(r.addons) ? r.addons : []).map(function (x) { return flat(x, ADDON); }).filter(function (x) { return x && x.id; }); return addons; }); },
      heads: [B.th(t('bcg_col_name')), B.th(t('bcg_col_prices')), B.th(t('bcg_col_offered'), 'fp-bil-num'), B.th(t('bcg_col_status'))],
      cells: function (v) { return [el('th', {scope: 'row', class: 'fp-bil-wrap', text: v.name}), el('td', {class: 'fp-bil-wrap', text: priceSummary(v)}), el('td', {class: 'fp-bil-num', text: v.plans === null ? '—' : B.num(v.plans)}), el('td', null, [statusPill(v.status)])]; },
      removable: function (v) { return v.status === 'retired'; },
      fieldsFor: function () {
        return [{name: 'name', label: t('bcg_col_name'), required: true, max: 60}, {name: 'description', label: t('bcg_col_desc'), max: 200, send_empty: true},
          {name: 'status', label: t('bcg_col_status'), kind: 'select', options: [['active', t('bcg_active')], ['retired', t('bcg_retired')]], value: 'active'}].concat(priceSpecs());
      },
      check: prices, add: 'billingAddons', item: 'billingAddon', nameOf: function (v) { return v.name; }, strings: strings('bcga')});
    /* ---- a plan's add-ons and options ---- */
    var O = null;
    function extras(v, b) {
      UI.setBusy(b, true);
      FP.call('get', 'billingPlanAddons', undefined, {id: String(v.id)}).then(function (r) {
        if (!alive()) { return; }
        UI.setBusy(b, false);
        var offered = B.pickAll(r && r.addons, {id: 'id'}, 'id').map(function (x) { return x.id; });
        planBox.textContent = '';
        var boxes = addons.map(function (a) {
          var fid = 'fp-bcg-x-a' + a.id;
          var on = offered.indexOf(a.id) >= 0;
          return el('label', {class: 'fp-bil-check', for: fid}, [el('input', {type: 'checkbox', id: fid, name: 'addon_ids', value: String(a.id), checked: on ? true : null, disabled: a.status === 'retired' && !on ? true : null}),
            el('span', {text: a.name + (a.status === 'retired' ? ' ' + t('bcg_retired_mark') : '')})]);
        });
        var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bcg_offer_save')});
        var form = el('form', {class: 'fp-form fp-bil-crud-form fp-bcg-offer', novalidate: '', 'aria-labelledby': 'fp-bcg-x-h'}, [M.errorLine(), M.statusLine(),
          addons.length ? el('fieldset', {class: 'fp-bil-set'}, [el('legend', {class: 'sig-label', text: t('bcg_offer_legend')}), el('div', {class: 'fp-bil-checks fp-bcg-offer-list'}, boxes)]) :
            el('p', {class: 'fp-muted', text: t('bcg_no_addons')}), addons.length ? el('div', {class: 'fp-actions'}, [save]) : null]);
        form.addEventListener('submit', function (e) {
          e.preventDefault();
          if (!B.begin(form, save)) { return; }
          var ids = Array.prototype.filter.call(form.querySelectorAll('[name="addon_ids"]'), function (c) { return c.checked; }).map(function (c) { return Number(c.value); });
          UI.setBusy(save, true);
          FP.call('put', 'billingPlanAddons', {addon_ids: ids}, {id: String(v.id)}).then(function () {
            if (!alive()) { return; }
            UI.setBusy(save, false);
            M.say(form, t('bcg_offer_saved'));
            A2.show();
          }, function (err) {
            if (!alive()) { return; }
            UI.setBusy(save, false);
            B.failed(form, err.field === 'addon_ids' ? Object.assign({}, err, {field: ''}) : err);
          });
        });
        var optBox = el('div', {class: 'fp-bcg-options'});
        planBox.appendChild(B.card('fp-bcg-x-h', t('bcg_extras_title', {name: v.name}), [el('p', {class: 'fp-muted', text: t('bcg_extras_what')}), form, optBox,
          el('div', {class: 'fp-actions'}, [B.button('extras-close', t('btp_close'))])], 'fp-bcg-extras', 'extras'));
        O = B.crud({page: optBox, pre: 'fp-bcgo', title: t('bcg_options'), alive: alive,
          load: function () { return FP.call('get', 'billingPlanOptions', undefined, {id: String(v.id)}).then(function (x) { return (x && Array.isArray(x.options) ? x.options : []).map(function (o) {
            var f = B.pick(o, {id: 'id', name: [60], unit: [20], min: 'n', max: 'n'});
            if (!f) { return null; }
            B.TERMS.forEach(function (k) { var c = o.unit_prices && o.unit_prices[k] !== null && o.unit_prices[k] !== undefined ? B.cents(o.unit_prices[k]) : null; f['price_' + k] = c; });
            return f;
          }).filter(function (o) { return o && o.id; }); }); },
          heads: [B.th(t('bcg_col_name')), B.th(t('bcg_col_range')), B.th(t('bcg_col_unit_prices'))],
          cells: function (o) { return [el('th', {scope: 'row', class: 'fp-bil-wrap', text: o.name + (o.unit ? ' (' + o.unit + ')' : '')}), el('td', {text: t('bcg_range', {min: B.num(o.min || 0), max: B.num(o.max || 0)})}), el('td', {class: 'fp-bil-wrap', text: priceSummary(o)})]; },
          fieldsFor: function () {
            return [{name: 'name', label: t('bcg_col_name'), required: true, max: 60}, {name: 'unit', label: t('bcg_unit'), max: 20, hint: t('bcg_unit_hint'), send_empty: true},
              {name: 'min', label: t('bcg_min'), kind: 'number', max: 7, empty: 0, hint: t('bcg_min_hint')}, {name: 'max', label: t('bcg_max'), kind: 'number', max: 7, required: true}]
              .concat(B.TERMS.map(function (k) { return {name: 'price_' + k, label: t('bcg_unit_price', {term: B.termText(k)}), kind: 'amount', empty: null}; }));
          },
          check: function (body) {
            var out = {};
            B.TERMS.forEach(function (k) { if (Object.prototype.hasOwnProperty.call(body, 'price_' + k)) { out[k] = body['price_' + k]; delete body['price_' + k]; } });
            if (Object.keys(out).length) { body.unit_prices = out; }
            return false;
          },
          add: 'billingPlanOptions', addArg: {id: String(v.id)}, item: 'billingPlanOption', argOf: function (o) { return {id: String(v.id), option: String(o.id)}; },
          nameOf: function (o) { return o.name; }, strings: strings('bcgo')});
        O.show().then(function () { var h = planBox.querySelector('#fp-bcg-x-h'); if (h) { h.focus(); } });
      }, function (err) {
        if (!alive()) { return; }
        UI.setBusy(b, false);
        UI.showError(pBox.querySelector('[data-fp-card="list"]'), err.message);
      });
    }
    planBox.addEventListener('click', function (e) {
      var b = e.target && e.target.closest ? e.target.closest('[data-fp-act="extras-close"]') : null;
      if (b) { planBox.textContent = ''; var back = pBox.querySelector('[data-fp-act="plan-extras"]'); if (back) { back.focus(); } }
    });
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'packages').then(function (r) {
      packages = (r && Array.isArray(r.packages) ? r.packages : []).map(function (x) { return x && B.str(x.name, 64); }).filter(Boolean).sort();
    }, function () { packages = []; }).then(function () {
      if (!alive()) { return; }
      return G.show().then(function () {
        if (!alive()) { return; }
        if (gBox.querySelector('.sig-empty')) { B.screen(page, [gBox]); return; }
        B.screen(page, [gBox, pBox, planBox, aBox]);
        return Promise.all([P.show(), A2.show()]);
      });
    });
  });
})();

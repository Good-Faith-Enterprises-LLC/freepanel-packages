/* freePanel's Encryption keys page for the customer panel (#/tool/encryption): where PGP keys are made and kept (in webmail, with
   Roundcube's Enigma plugin, set up by the installer's --pgp), how to make one, and how to keep it. The page makes no keys itself and
   sends nothing: it lists the account's mailboxes, because each has its own keys, and links to webmail. The mailbox names come from the
   account's own list and are shown as text; the link is the one the server gave the session, and only an https address is used. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var el = UI.el;
  var M = FP.mail;

  var t = UI.t;

  var ADDRESS_RE = /^[^@\s]{1,64}@[^@\s]{1,253}$/;

  function boxes(r) {
    return (r && Array.isArray(r.mailboxes) ? r.mailboxes : []).slice(0, 500).filter(function (b) { return b && typeof b.address === 'string' && ADDRESS_RE.test(b.address); })
      .map(function (b) { return b.address.slice(0, 320); });
  }
  /* the link the server gave the session for webmail: an https address and nothing else */
  function webmailLink() {
    var l = FP.session && FP.session.links && typeof FP.session.links === 'object' ? FP.session.links.webmail : '';
    return typeof l === 'string' && /^https:\/\/[^\s"'<>]+$/.test(l) ? l : '';
  }
  function draw(page, list) {
    page.textContent = '';
    if (!list.length) { page.appendChild(FP.empty(FP.tools.encryption.label, t('enc_no_boxes'))); return; }
    var link = webmailLink();
    var open = link ? el('div', {class: 'fp-actions'}, [
      el('a', {class: 'sig-btn sig-btn--primary', href: link, target: '_blank', rel: 'noopener noreferrer', text: t('enc_open')}),
      el('span', {class: 'fp-muted', text: t('enc_open_note')})]) : el('p', {class: 'fp-muted', 'data-fp-no-link': '', text: t('enc_no_link')});
    page.appendChild(M.card('fp-enc-h', t('enc_title'), [
      el('p', {class: 'fp-muted', text: t('enc_what')}),
      el('h3', {class: 'fp-h3', text: t('enc_steps_title')}),
      el('ol', {class: 'fp-enc-steps'}, ['enc_step1', 'enc_step2', 'enc_step3', 'enc_step4'].map(function (k) { return el('li', {text: t(k)}); })),
      open,
      el('h3', {class: 'fp-h3', text: t('enc_boxes')}),
      el('p', {class: 'fp-muted', text: t('enc_boxes_note')}),
      el('ul', {class: 'fp-enc-boxes'}, list.map(function (a) { return el('li', {class: 'sig-mono', text: a}); }))], 'fp-enc'));
    page.appendChild(M.card('fp-enc-keep-h', t('enc_keep_title'), [
      el('p', {text: t('enc_keep')}), el('p', {class: 'fp-muted', text: t('enc_keep_two')})], 'fp-enc fp-enc-keep'));
  }
  FP.view('tool:encryption', function () {
    var tool = FP.tools.encryption;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('encryption_desc'), cls: 'fp-mail fp-enc-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    if (!page) { return; }
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'mail', undefined, FP.account()).then(function (r) {
      if (!page.isConnected) { return; }
      draw(page, boxes(r));
    }, function (err) {
      if (!page.isConnected) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err && err.message ? err.message : t('api_failed')));
    });
  });
})();

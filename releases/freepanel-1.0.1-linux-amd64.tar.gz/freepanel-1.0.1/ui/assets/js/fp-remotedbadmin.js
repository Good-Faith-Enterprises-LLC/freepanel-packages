/* freePanel remote database access in the admin panel (docs/api.md, "Remote database hosts"): #/tool/db_remote shows whether MariaDB lets
   customers list hosts to connect from, what that means on this server (what MariaDB listens on, the firewall and the port, how many
   accounts use it) and a switch with a question before it is turned on or off. A step that did not finish is shown in the server's words;
   the agent tries it again by itself. Admin only: the server refuses these calls to anyone else. Everything the server sends is text.
   The pieces of a page come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var FIREWALLS = ['firewalld', 'ufw', 'none'];
  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function whole(v) { return typeof v === 'number' && isFinite(v) && v >= 0 && Math.floor(v) === v ? v : 0; }
  function clean(r) {
    var s = r && typeof r === 'object' && r.mysql && typeof r.mysql === 'object' ? r.mysql : {};
    var port = whole(s.port);
    return {available: s.available === true, reason: str(s.reason), allowed: s.allowed === true, listening: s.listening === true,
      firewall: FIREWALLS.indexOf(s.firewall) >= 0 ? s.firewall : '', portOpened: s.port_opened === true, port: port > 0 && port < 65536 ? port : 3306,
      accounts: whole(s.accounts), hosts: whole(s.hosts), problem: str(s.problem)};
  }

  var page = null;
  var D = null;          /* the server's reply, cleaned */

  function pill(kind, text) { return el('span', {class: 'sig-pill' + (kind ? ' sig-pill--' + kind : ''), text: text}); }
  function row(label, content) { return el('div', null, [el('dt', {text: label}), el('dd', null, content)]); }

  function firewallText() {
    if (D.firewall === 'none') { return t('rdx_fw_none'); }
    if (!D.firewall) { return t('rdx_fw_closed'); }
    return t(D.portOpened ? 'rdx_fw_opened' : 'rdx_fw_already', {firewall: D.firewall, port: D.port});
  }
  /* every account that lists a host lists at least one, so one host means one account */
  function useText() {
    var n = {accounts: D.accounts.toLocaleString('en'), hosts: D.hosts.toLocaleString('en')};
    if (!D.hosts) { return t('rdx_use_0'); }
    if (D.accounts === 1) { return t(D.hosts === 1 ? 'rdx_use_1_1' : 'rdx_use_1', n); }
    return t('rdx_use', n);
  }
  function card() {
    var parts = [M.errorLine(), M.statusLine()];
    if (!D.available) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-rdx-unavailable': ''}, [UI.icon(FP.ui, 'ui_warning'),
        el('span', {text: D.reason ? t('rdx_unavailable_why', {reason: D.reason}) : t('rdx_unavailable')})]));
    } else {
      if (D.problem) {
        parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-rdx-problem': ''}, [UI.icon(FP.ui, 'ui_warning'),
          el('div', {class: 'fp-rdx-problem'}, [el('span', {text: t('rdx_problem', {problem: D.problem})}), el('span', {text: t('rdx_problem_retry')})])]));
      }
      parts.push(el('dl', {class: 'fp-rdx-facts'}, [
        row(t('rdx_access'), [pill(D.allowed ? 'ok' : '', t(D.allowed ? 'rdx_on' : 'rdx_off'))]),
        row(t('rdx_listens'), [el('span', {text: t(D.listening ? 'rdx_listens_all' : 'rdx_listens_local')})]),
        row(t('rdx_port'), [el('span', {class: 'sig-mono', text: String(D.port)})]),
        row(t('rdx_firewall'), [el('span', {'data-fp-rdx-firewall': '', text: firewallText()})]),
        row(t('rdx_usage'), [el('span', {text: useText()})])]));
    }
    parts.push(el('p', {class: 'fp-muted', text: t('rdx_what')}), el('p', {class: 'fp-muted', 'data-fp-rdx-care': '', text: t('rdx_care')}));
    var actions = el('div', {class: 'fp-actions fp-rdx-acts'}, []);
    if (D.available) {
      actions.appendChild(el('button', {class: 'sig-btn ' + (D.allowed ? 'sig-btn--secondary fp-btn-danger-text' : 'sig-btn--primary'), type: 'button', 'data-fp-act': 'switch',
        text: t(D.allowed ? 'rdx_turn_off' : 'rdx_turn_on')}));
    }
    actions.appendChild(el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'look', text: t('sec_look_again')}));
    parts.push(actions);
    return M.card('fp-rdx-h', t('rdx_title'), parts, 'fp-rdx-card');
  }
  /* redraws the card; opts.say is the text for its status line, opts.focus a selector for the control that takes focus */
  function draw(opts) {
    opts = opts || {};
    var old = page.querySelector('.fp-rdx-card');
    var node = card();
    if (old) { old.replaceWith(node); } else { page.appendChild(node); }
    if (opts.say) { M.say(node, opts.say); }
    var target = opts.focus ? node.querySelector(opts.focus) : null;
    if (target) { target.focus(); }
  }

  document.addEventListener('click', function (e) {
    var node = e.target.closest ? e.target : null;
    var b = node && node.closest('[data-fp-act]');
    if (!b || !page || !page.contains(b) || !D) { return; }
    var a = b.getAttribute('data-fp-act');
    var mine = page;
    var c = page.querySelector('.fp-rdx-card');
    if (a === 'switch') {
      M.confirmIn(b.parentNode, t(D.allowed ? 'rdx_ask_off' : 'rdx_ask_on'), 'switch-yes', t(D.allowed ? 'rdx_turn_off' : 'rdx_turn_on'));
    } else if (a === 'confirm-no') {
      draw({focus: '[data-fp-act="switch"]'});
    } else if (a === 'switch-yes') {
      var turning = !D.allowed;
      UI.setBusy(b, true);
      /* turning it on restarts MariaDB, so the answer can take a while */
      FP.call('put', 'remoteDatabasesMysql', {allowed: turning}).then(function (r) {
        if (page !== mine) { return; }
        D = clean(r);
        draw({say: t(turning ? 'rdx_turned_on' : 'rdx_turned_off'), focus: '[data-fp-act="switch"]'});
      }, function (err) {
        if (page !== mine) { return; }
        /* a step that fails is answered with an error, but the switch itself is saved: read the server again so the page shows what is there */
        var shown = function () {
          if (page !== mine) { return; }
          draw({focus: '[data-fp-act="switch"]'});
          UI.showError(page.querySelector('.fp-rdx-card'), err.message);
        };
        FP.call('get', 'remoteDatabases').then(function (r) { if (page === mine) { D = clean(r); } shown(); }, shown);
      });
    } else if (a === 'look') {
      UI.setBusy(b, true);
      FP.call('get', 'remoteDatabases').then(function (r) {
        if (page !== mine) { return; }
        D = clean(r);
        draw({say: t('rdx_looked'), focus: '[data-fp-act="look"]'});
      }, function (err) {
        if (page !== mine) { return; }
        UI.setBusy(b, false);
        UI.showError(c, err.message);
        b.focus();
      });
    }
  });

  FP.view('tool:db_remote', function () {
    var tool = FP.tools.db_remote;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    D = null;
    var mine = FP.frame({title: tool.label, desc: t('rdx_desc'), cls: 'fp-mail fp-srv fp-rdx-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    page = mine;
    mine.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'remoteDatabases').then(function (r) {
      if (page !== mine) { return; }
      D = clean(r);
      mine.textContent = '';
      draw();
    }, function (err) {
      if (page !== mine) { return; }
      mine.textContent = '';
      mine.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

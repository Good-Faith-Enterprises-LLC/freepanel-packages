/* freePanel billing registrar choice (#/tool/billing_registrar; docs/api.md, "Billing: domains"; docs/billing/navigation-map.md, "Domain
   pricing"): which registrar the panel registers, renews and searches domains through, or none. Only the built-in test registrar ships; it
   registers nothing anywhere. Moving off the registrar in use is asked first. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;
  var M = FP.mail;

  FP.view('tool:billing_registrar', function () {
    var page = B.frame('billing_registrar', 'fp-brg');
    if (!page) { return; }
    var alive = function () { return page.isConnected; };
    function draw(r, said) {
      var active = B.str(r && r.active, 40);
      var list = B.pickAll(r && r.registrars, {id: [40], name: [60]}, 'id').filter(function (x) { return /^[a-z0-9_-]{1,40}$/.test(x.id); });
      var opts = [{id: '', name: t('brg_none')}].concat(list);
      var radios = opts.map(function (x) {
        var fid = 'fp-brg-' + (x.id || 'none');
        return el('label', {class: 'fp-bil-check', for: fid}, [el('input', {type: 'radio', id: fid, name: 'active', value: x.id, checked: x.id === active ? true : null}),
          el('span', {text: x.name || x.id}), x.id === 'test' ? el('span', {class: 'fp-muted', text: ' ' + t('brg_test_mark')}) : null]);
      });
      var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bil_save_changes')});
      var form = el('form', {class: 'fp-form fp-bil-crud-form fp-brg-form', novalidate: '', 'aria-labelledby': 'fp-brg-h'}, [M.errorLine(), M.statusLine(),
        el('p', {'data-fp-active': '', text: active ? t('brg_now', {name: (list.filter(function (x) { return x.id === active; })[0] || {name: active}).name}) : t('brg_now_none')}),
        el('fieldset', {class: 'fp-bil-set'}, [el('legend', {class: 'sig-label', text: t('brg_legend')}), el('div', {class: 'fp-bil-checks fp-brg-list'}, radios)]),
        el('div', {class: 'fp-actions', 'data-fp-acts': ''}, [save])]);
      function send(b, v) {
        UI.setBusy(b, true);
        FP.call('patch', 'billingRegistrar', {active: v}).then(function (x) {
          if (!alive()) { return; }
          draw(x, t('brg_saved'));
        }, function (err) {
          if (!alive()) { return; }
          draw(r);
          B.failed(page.querySelector('.fp-brg-form'), err);
        });
      }
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!B.begin(form, save)) { return; }
        var picked = form.querySelector('[name="active"]:checked');
        var v = picked ? picked.value : '';
        if (v === active) { M.say(form, t('bil_nothing_changed')); return; }
        if (!active) { send(save, v); return; }
        var box = form.querySelector('[data-fp-acts]');
        box.textContent = '';
        var yes = el('button', {class: 'sig-btn sig-btn--danger', type: 'button', text: t('brg_yes'), 'aria-describedby': 'fp-brg-q'});
        var no = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', text: t('brg_keep'), 'aria-describedby': 'fp-brg-q'});
        box.appendChild(el('p', {class: 'fp-mail-confirm', id: 'fp-brg-q', text: t(v ? 'brg_ask_switch' : 'brg_ask_none')}));
        box.appendChild(yes);
        box.appendChild(no);
        yes.addEventListener('click', function () { send(yes, v); });
        no.addEventListener('click', function () { box.textContent = ''; box.appendChild(save); save.focus(); });
        no.focus();
      });
      B.screen(page, [B.card('fp-brg-h', t('brg_title'), [el('p', {class: 'fp-muted', text: t('brg_what')}), form], 'fp-brg', 'registrar')]);
      if (said) { M.say(page.querySelector('.fp-brg-form'), said); page.querySelector('#fp-brg-h').focus(); }
    }
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    function load() {
      FP.call('get', 'billingRegistrar').then(function (r) { if (alive()) { draw(r); } }, function (err) {
        if (!alive()) { return; }
        B.screen(page, [FP.empty(t('brg_title'), err.message, B.button('reload', t('bil_try_again')))]);
        page.querySelector('[data-fp-act="reload"]').addEventListener('click', load);
      });
    }
    load();
  });
})();

/* freePanel Linked servers in the admin panel (docs/api.md, "Linked servers"): #/tool/server_nodes. Three cards:
   - the servers this one is linked to, each with what it said last (version, load, disk, accounts), a button to ask again, its
     list of accounts, "move an account there" (a run of that server's Move accounts here page, from a source its admin set up),
     and removing the link, which asks first;
   - linking a server: its address, then its certificate (read, not trusted) for the admin to compare with the fingerprint that
     server's own page shows, then a name, the key its admin made and the admin's own password;
   - the remote access keys this server gives other servers, with this server's own fingerprint to read out, and making one: the
     key shows once, with a button to copy it.
   Everything a linked server says reaches the page through this server's API, cut and bounded there, and is cleaned again here
   and drawn as text only. Admin only: the server refuses these calls to anyone else. Declares nothing. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var USER_RE = /^[a-z][a-z0-9]{0,15}$/;
  var NAME_RE = /^[A-Za-z0-9][A-Za-z0-9 ._-]{0,63}$/;
  var FP_RE = /^[0-9A-F]{2}(:[0-9A-F]{2}){31}$/;
  var KEY_RE = /^fpn_[A-Za-z0-9_-]{43}$/;
  var PKG_RE = /^[A-Za-z0-9][A-Za-z0-9 ._-]{0,63}$/;
  var MAX_NODES = 20;
  var MAX_KEYS = 20;
  var MAX_ACCOUNTS = 5000;
  var SHOWN = 100;

  /* ---------- reading answers ---------- */
  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 200) : ''; }
  function whole(v) { return typeof v === 'number' && isFinite(v) && v >= 0 && Math.floor(v) === v ? v : 0; }
  function num(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? v : 0; }
  function stamp(v) { var s = str(v, 40); return s && !isNaN(new Date(s).getTime()) ? s : ''; }
  function fingerprint(v) { var s = str(v, 95); return FP_RE.test(s) ? s : ''; }

  function cleanRun(r) {
    if (!r || typeof r !== 'object') { return null; }
    return {id: str(r.id, 40), source: str(r.source, 64), started: stamp(r.started), ended: stamp(r.ended), stopped: r.stopped === true, aborted: str(r.aborted, 300),
      accounts: (Array.isArray(r.accounts) ? r.accounts : []).slice(0, 50).filter(function (a) { return a && USER_RE.test(str(a.username, 16)); }).map(function (a) {
        return {username: a.username, state: str(a.state, 20), error: str(a.error, 300)};
      })};
  }
  function cleanStatus(s) {
    if (!s || typeof s !== 'object') { return null; }
    var d = s.disk && typeof s.disk === 'object' ? s.disk : null;
    var acc = s.accounts && typeof s.accounts === 'object' ? s.accounts : {};
    var mv = s.moving && typeof s.moving === 'object' ? s.moving : {};
    var load = Array.isArray(s.load) ? s.load : [];
    var total = d ? whole(d.total_bytes) : 0;
    return {name: str(s.name, 253), version: str(s.version, 64), cpus: whole(s.cpus), load: [num(load[0]), num(load[1]), num(load[2])],
      disk: d && total > 0 && whole(d.free_bytes) <= total ? {total: total, free: whole(d.free_bytes)} : null,
      accounts: whole(acc.total), suspended: whole(acc.suspended),
      moving: {allowed: mv.allowed === true,
        sources: (Array.isArray(mv.sources) ? mv.sources : []).slice(0, 10).filter(function (x) { return x && whole(x.id) > 0; }).map(function (x) {
          return {id: x.id, name: str(x.name, 64), host: str(x.host, 253), handoff: x.handoff === true};
        }),
        packages: (Array.isArray(mv.packages) ? mv.packages : []).slice(0, 200).filter(function (p) { return typeof p === 'string' && PKG_RE.test(p); }),
        run: cleanRun(mv.run)}};
  }
  function cleanNode(n) {
    if (!n || typeof n !== 'object' || whole(n.id) < 1) { return null; }
    return {id: n.id, name: str(n.name, 64), url: str(n.url, 300), fingerprint: fingerprint(n.fingerprint), private: n.private === true,
      keyPrefix: str(n.key_prefix, 12), created: stamp(n.created_at), lastSeen: stamp(n.last_seen), status: cleanStatus(n.status)};
  }
  function cleanKey(k) {
    if (!k || typeof k !== 'object' || whole(k.id) < 1) { return null; }
    return {id: k.id, name: str(k.name, 64), prefix: str(k.prefix, 12), expires: stamp(k.expires_at), expired: k.expired === true,
      lastUsed: stamp(k.last_used_at), lastIp: str(k.last_used_ip, 45),
      addresses: (Array.isArray(k.addresses) ? k.addresses : []).filter(function (a) { return typeof a === 'string' && a.length <= 49; }).slice(0, 10),
      sources: (Array.isArray(k.source_ids) ? k.source_ids : []).filter(function (id) { return whole(id) > 0; }).slice(0, 10)};
  }
  /* this server's freePanel transfer sources whose settings open: the ones a key may be made for */
  function cleanSources(r) {
    return (r && Array.isArray(r.sources) ? r.sources : []).slice(0, 10).filter(function (x) {
      return x && whole(x.id) > 0 && x.kind === 'freepanel' && !x.problem;
    }).map(function (x) { return {id: x.id, name: str(x.name, 64), host: str(x.host, 253)}; });
  }
  function sourceName(id) {
    var s = S.sources.filter(function (x) { return x.id === id; })[0];
    return s ? s.name : t('cln_key_source_gone', {id: String(id)});
  }
  function cleanCert(r) {
    var c = r && typeof r === 'object' && r.certificate && typeof r.certificate === 'object' ? r.certificate : null;
    if (!c || !fingerprint(c.fingerprint)) { return null; }
    return {url: str(c.url, 300), fingerprint: c.fingerprint, subject: str(c.subject, 200), issuer: str(c.issuer, 200),
      names: (Array.isArray(c.names) ? c.names : []).filter(function (x) { return typeof x === 'string'; }).slice(0, 20).map(function (x) { return x.slice(0, 253); }),
      notAfter: stamp(c.not_after), selfSigned: c.self_signed === true};
  }
  function cleanAccounts(r) {
    return (r && Array.isArray(r.accounts) ? r.accounts : []).slice(0, MAX_ACCOUNTS).filter(function (a) { return a && USER_RE.test(str(a.username, 16)); }).map(function (a) {
      return {username: a.username, domain: str(a.domain, 253), status: str(a.status, 20), pkg: str(a.package, 64)};
    });
  }

  /* ---------- words for numbers ---------- */
  function when(iso) {
    var d = iso ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString(undefined, {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }
  function size(b) {
    var units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
    var i = 0;
    while (b >= 1024 && i < units.length - 1) { b /= 1024; i++; }
    return (i === 0 ? String(b) : b.toFixed(b < 10 ? 1 : 0)) + ' ' + units[i];
  }
  function meter(pct, warnAt, dangerAt) {
    var bar = el('i');
    bar.style.width = Math.min(100, Math.max(0, pct)) + '%';
    return el('div', {class: 'sig-meter' + (pct >= dangerAt ? ' is-danger' : pct >= warnAt ? ' is-warn' : ''), 'aria-hidden': 'true'}, [bar]);
  }

  /* ---------- state ---------- */
  var S = null;
  function fresh() {
    return {page: null, nodes: [], keys: [], own: '', mine: [], sources: [], probe: null, newKey: null, open: {}, lists: {}, nodeError: {}, shown: {}, busy: false};
  }
  function alive(mine) { return S && S.page === mine; }
  function nodeById(id) { return S.nodes.filter(function (n) { return n.id === id; })[0] || null; }

  /* ---------- the linked servers ---------- */
  function statTile(label, value, extra, cls) {
    return el('div', {class: 'fp-cln-stat' + (cls ? ' ' + cls : '')}, [el('span', {class: 'fp-cln-stat-k', text: label}),
      el('span', {class: 'fp-cln-stat-v', text: value})].concat(extra || []));
  }
  function stats(n) {
    var s = n.status;
    if (!s) { return el('p', {class: 'fp-muted', 'data-fp-cln-nostatus': '', text: t('cln_no_status')}); }
    var per = s.cpus ? s.load[0] / s.cpus : 0;
    var load = statTile(t('cln_load'), s.load[0].toFixed(2), [el('span', {class: 'sig-hint', text: s.cpus ? t('cln_load_of', {cpus: String(s.cpus)}) : ''}),
      s.cpus ? meter(Math.round(per * 100), 70, 100) : null], 'fp-cln-load');
    var disk = s.disk ? statTile(t('cln_disk'), t('cln_disk_free', {free: size(s.disk.free)}), [el('span', {class: 'sig-hint', text: t('cln_disk_of', {total: size(s.disk.total)})}),
      meter(Math.round((s.disk.total - s.disk.free) / s.disk.total * 100), 80, 92)], 'fp-cln-disk') : statTile(t('cln_disk'), '—', [el('span', {class: 'sig-hint', text: t('cln_disk_unknown')})], 'fp-cln-disk');
    return el('div', {class: 'fp-cln-stats', 'data-fp-cln-stats': ''}, [
      statTile(t('cln_version'), s.version || '—', [el('span', {class: 'sig-hint sig-mono', text: s.name})], 'fp-cln-version'),
      load, disk,
      statTile(t('cln_accounts'), s.accounts.toLocaleString('en'), [el('span', {class: 'sig-hint', text: s.suspended ? t('cln_suspended', {n: s.suspended.toLocaleString('en')}) : t('cln_none_suspended')})], 'fp-cln-count')]);
  }
  function seenPill(n) {
    if (S.nodeError[n.id]) { return el('span', {class: 'sig-pill sig-pill--danger', 'data-fp-cln-state': 'error', text: t('cln_state_error')}); }
    if (!n.lastSeen) { return el('span', {class: 'sig-pill', 'data-fp-cln-state': 'never', text: t('cln_state_never')}); }
    return el('span', {class: 'sig-pill sig-pill--ok', 'data-fp-cln-state': 'ok', text: t('cln_state_seen', {when: when(n.lastSeen)})});
  }
  function runBlock(run) {
    if (!run) { return null; }
    var rows = run.accounts.map(function (a) {
      var ok = a.state === 'done';
      var bad = a.state === 'failed' || a.state === 'skipped';
      return el('li', {'data-fp-cln-run-account': a.username}, [el('span', {class: 'sig-mono', text: a.username}), ' ',
        el('span', {class: 'sig-pill' + (ok ? ' sig-pill--ok' : bad ? ' sig-pill--danger' : ' sig-pill--accent'), text: a.state || '—'}),
        a.error ? el('span', {class: 'sig-hint fp-cln-run-error', text: a.error}) : null]);
    });
    var head = run.ended ? t('cln_run_ended', {source: run.source, when: when(run.ended)}) : t('cln_run_going', {source: run.source, when: when(run.started)});
    return el('div', {class: 'fp-cln-run', 'data-fp-cln-run': run.ended ? 'ended' : 'going'}, [el('p', {class: 'fp-cln-run-head', text: head}),
      run.aborted ? el('p', {class: 'sig-hint', text: run.aborted}) : null, el('ul', {class: 'fp-cln-run-list'}, rows)]);
  }
  function accountsBlock(n) {
    var list = S.lists[n.id];
    if (!list) { return el('p', {class: 'fp-muted', text: t('loading')}); }
    if (!list.length) { return el('p', {class: 'fp-muted', 'data-fp-cln-noaccounts': '', text: t('cln_accounts_none', {name: n.name})}); }
    var shown = list.slice(0, S.shown[n.id] || SHOWN);
    var body = [el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-label': t('cln_accounts_of', {name: n.name})}, [el('table', {class: 'sig-table fp-cln-table'}, [
      el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('cln_col_user')}), el('th', {scope: 'col', text: t('cln_col_domain')}),
        el('th', {scope: 'col', text: t('cln_col_package')}), el('th', {scope: 'col', text: t('cln_col_status')})])]),
      el('tbody', null, shown.map(function (a) {
        return el('tr', {'data-fp-cln-account': a.username}, [el('th', {scope: 'row', class: 'sig-mono', text: a.username}), el('td', {text: a.domain}),
          el('td', {text: a.pkg}), el('td', null, [el('span', {class: 'sig-pill' + (a.status === 'suspended' ? ' sig-pill--warn' : ''), text: a.status})])]);
      }))])])];
    if (list.length > shown.length) {
      body.push(el('p', {class: 'sig-hint', text: t('cln_showing', {shown: String(shown.length), total: list.length.toLocaleString('en')})}),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'cln-more', 'data-fp-node': String(n.id), text: t('cln_more')}));
    }
    return el('div', {class: 'fp-cln-accounts', 'data-fp-cln-accounts': ''}, body);
  }
  function moveForm(n) {
    var s = n.status;
    var id = 'fp-cln-mv-' + n.id;
    var notes = [];
    if (!s) {
      notes.push(t('cln_move_ask_first'));
    } else if (!s.moving.allowed) {
      notes.push(t('cln_move_off', {name: n.name}));
    } else if (!s.moving.sources.length) {
      notes.push(t('cln_move_nosource', {name: n.name}));
    } else if (!s.moving.packages.length) {
      notes.push(t('cln_move_nopackage', {name: n.name}));
    } else if (!S.mine.length) {
      notes.push(t('cln_move_nothing'));
    }
    if (notes.length) {
      return el('div', {class: 'sig-banner sig-banner--warn fp-cln-move-note', role: 'note', 'data-fp-cln-move-note': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: notes[0]})]);
    }
    var acct = el('select', {class: 'sig-select', id: id + '-account', name: 'account'}, S.mine.map(function (u) { return el('option', {value: u, text: u}); }));
    /* the source that points at this server (the one this page is open on) comes first */
    var host = window.location.hostname;
    var srcs = s.moving.sources.slice().sort(function (a, b) { return (b.host === host) - (a.host === host); });
    var src = el('select', {class: 'sig-select', id: id + '-source', name: 'source_id'}, srcs.map(function (x) {
      return el('option', {value: String(x.id), text: x.host ? t('cln_source_opt', {name: x.name, host: x.host}) : x.name});
    }));
    var pkg = el('select', {class: 'sig-select', id: id + '-package', name: 'package'}, s.moving.packages.map(function (p) { return el('option', {value: p, text: p}); }));
    var form = el('form', {class: 'fp-form fp-cln-move', novalidate: '', 'data-fp-cln-move': String(n.id)}, [M.errorLine(), M.statusLine(),
      el('p', {class: 'fp-muted', text: t('cln_move_what', {name: n.name})}),
      el('div', {class: 'fp-cln-move-grid'}, [M.field(id + '-account', t('cln_move_account'), acct, t('cln_move_account_hint')),
        M.field(id + '-source', t('cln_move_source'), src, t('cln_move_source_hint', {name: n.name})),
        M.field(id + '-package', t('cln_move_package'), pkg, t('cln_move_package_hint', {name: n.name}))]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('cln_move_go', {name: n.name})})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || S.busy) { return; }
      var body = {source_id: parseInt(src.value, 10) || 0, accounts: [acct.value], package: pkg.value};
      if (!USER_RE.test(acct.value)) { M.fieldError(form, acct, t('cln_bad_account')); return; }
      var mine = S.page;
      S.busy = true;
      UI.setBusy(b, true);
      FP.call('post', 'clusterNodeTransfer', body, {id: String(n.id)}).then(function (r) {
        S.busy = false;
        if (!alive(mine)) { return; }
        var run = cleanRun(r && r.run);
        if (n.status && run) { n.status.moving.run = run; }
        S.open[n.id] = 'move';
        draw();
        var f = S.page.querySelector('[data-fp-cln-move="' + n.id + '"]');
        if (f) { M.say(f, t('cln_move_started', {account: body.accounts[0], name: n.name})); f.querySelector('.fp-submit').focus(); }
      }, function (err) {
        S.busy = false;
        if (!alive(mine)) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return form;
  }
  function nodeCard(n) {
    var open = S.open[n.id] || '';
    var acts = el('div', {class: 'fp-actions fp-cln-acts', 'data-fp-cln-acts': ''}, [
      el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'cln-refresh', 'data-fp-node': String(n.id), text: t('cln_refresh')}),
      el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'cln-accounts', 'data-fp-node': String(n.id), 'aria-expanded': open === 'accounts' ? 'true' : 'false',
        text: t('cln_show_accounts')}),
      el('button', {class: 'sig-btn sig-btn--soft sig-btn--sm', type: 'button', 'data-fp-act': 'cln-move', 'data-fp-node': String(n.id), 'aria-expanded': open === 'move' ? 'true' : 'false',
        text: t('cln_move', {name: n.name})}),
      el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'cln-settings', 'data-fp-node': String(n.id), text: t('cln_settings')}),
      el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-cln-remove', type: 'button', 'data-fp-act': 'cln-unlink', 'data-fp-node': String(n.id), text: t('cln_unlink')})]);
    var parts = [el('header', {class: 'fp-cln-node-head'}, [
      el('div', {class: 'fp-cln-node-id'}, [el('h3', {class: 'fp-cln-node-name', id: 'fp-cln-node-' + n.id, tabindex: '-1', text: n.name}),
        el('span', {class: 'sig-mono fp-cln-url', text: n.url}), n.private ? el('span', {class: 'sig-pill fp-cln-private', text: t('cln_private_pill')}) : null]),
      seenPill(n)])];
    if (S.nodeError[n.id]) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-cln-node-error': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: S.nodeError[n.id]})]));
    }
    parts.push(stats(n));
    if (n.status && n.status.moving.run) { parts.push(runBlock(n.status.moving.run)); }
    parts.push(el('div', {class: 'fp-cln-pin'}, [el('p', {class: 'fp-cln-cert-k', text: t('cln_pinned')}),
      el('p', {class: 'sig-mono fp-cln-fp', text: n.fingerprint}),
      el('p', {class: 'sig-hint', text: t('cln_pinned_hint', {prefix: n.keyPrefix, when: when(n.created)})})]));
    parts.push(acts);
    if (open === 'accounts') { parts.push(accountsBlock(n)); }
    if (open === 'move') { parts.push(moveForm(n)); }
    return el('article', {class: 'fp-cln-node', 'data-fp-cln-node': String(n.id), 'aria-labelledby': 'fp-cln-node-' + n.id}, parts);
  }
  function nodesCard() {
    var body = [el('p', {class: 'fp-muted', text: t('cln_nodes_what')}), M.statusLine()];
    if (!S.nodes.length) {
      body.push(el('div', {class: 'fp-cln-empty', 'data-fp-cln-empty': ''}, [el('p', {class: 'fp-cln-empty-t', text: t('cln_nodes_none')}),
        el('p', {class: 'fp-muted', text: t('cln_nodes_none_how')})]));
    } else {
      body.push(el('div', {class: 'fp-cln-nodes'}, S.nodes.map(nodeCard)));
    }
    return M.card('fp-cln-nodes-h', t('cln_nodes_title'), body, 'fp-cln-nodes-card');
  }

  /* ---------- linking a server ---------- */
  function linkCard() {
    var p = S.probe;
    var url = el('input', {class: 'sig-input sig-mono', id: 'fp-cln-url', name: 'url', type: 'text', inputmode: 'url', autocomplete: 'off', spellcheck: 'false',
      autocapitalize: 'none', maxlength: '300', placeholder: 'https://server2.example.com:7443', value: p ? p.url : ''});
    var priv = el('input', {type: 'checkbox', id: 'fp-cln-private', name: 'private', checked: p && p.private ? true : null, 'aria-describedby': 'fp-cln-private-hint'});
    var step1 = [M.field('fp-cln-url', t('cln_url'), url, t('cln_url_hint')),
      el('div', {class: 'sig-field'}, [el('label', {class: 'fp-check', for: 'fp-cln-private'}, [priv, el('span', {text: t('cln_private')})]),
        el('span', {class: 'sig-hint', id: 'fp-cln-private-hint', text: t('cln_private_hint')})])];
    var parts = [M.errorLine(), M.statusLine()];
    if (!p) {
      parts = parts.concat(step1, [el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', id: 'fp-cln-probe', text: t('cln_probe')})])]);
    } else {
      url.setAttribute('readonly', '');
      priv.setAttribute('disabled', '');
      var c = p.cert;
      var same = el('input', {type: 'checkbox', id: 'fp-cln-same', name: 'fingerprint', 'aria-describedby': 'fp-cln-same-hint'});
      var name = el('input', {class: 'sig-input', id: 'fp-cln-name', name: 'name', type: 'text', autocomplete: 'off', maxlength: '64', value: p.name || ''});
      var key = el('input', {class: 'sig-input sig-mono', id: 'fp-cln-key', name: 'key', type: 'password', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', maxlength: '60'});
      var pw = el('input', {class: 'sig-input', id: 'fp-cln-pw', name: 'current_password', type: 'password', autocomplete: 'current-password', maxlength: '1024'});
      parts = parts.concat(step1, [
        el('div', {class: 'fp-cln-cert', 'data-fp-cln-cert': ''}, [
          el('p', {class: 'fp-cln-cert-k', text: t('cln_cert_fp')}),
          el('p', {class: 'sig-mono fp-cln-fp fp-cln-fp--big', id: 'fp-cln-cert-fp', text: c.fingerprint}),
          el('dl', {class: 'fp-cln-cert-dl'}, [el('dt', {text: t('cln_cert_subject')}), el('dd', {text: c.subject || '—'}),
            el('dt', {text: t('cln_cert_names')}), el('dd', {text: c.names.join(', ') || '—'}),
            el('dt', {text: t('cln_cert_until')}), el('dd', {text: when(c.notAfter) || '—'}),
            el('dt', {text: t('cln_cert_issuer')}), el('dd', null, [c.selfSigned ? el('span', {class: 'sig-pill', text: t('cln_cert_self')}) : el('span', {text: c.issuer || '—'})])])]),
        el('div', {class: 'sig-field'}, [el('label', {class: 'fp-check', for: 'fp-cln-same'}, [same, el('span', {text: t('cln_same')})]),
          el('span', {class: 'sig-hint', id: 'fp-cln-same-hint', text: t('cln_same_hint')})]),
        M.field('fp-cln-name', t('cln_name'), name, t('cln_name_hint')),
        M.field('fp-cln-key', t('cln_key'), key, t('cln_key_hint')),
        M.field('fp-cln-pw', t('cln_password'), pw, t('cln_password_hint')),
        el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', id: 'fp-cln-link', text: t('cln_link')}),
          el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'cln-restart', text: t('cln_restart')})])]);
    }
    var form = el('form', {class: 'fp-form fp-cln-link-form', novalidate: '', 'data-fp-cln-link': p ? 'confirm' : 'address'}, parts);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || S.busy) { return; }
      var mine = S.page;
      if (!S.probe) {
        var u = url.value.trim();
        if (!u) { M.fieldError(form, url, t('cln_url_missing')); return; }
        S.busy = true;
        UI.setBusy(b, true);
        FP.call('post', 'clusterProbe', {url: u, private: priv.checked}).then(function (r) {
          S.busy = false;
          if (!alive(mine)) { return; }
          var cert = cleanCert(r);
          if (!cert) { UI.setBusy(b, false); M.fieldError(form, url, t('cln_unreadable')); return; }
          S.probe = {url: cert.url || u, private: priv.checked, cert: cert, name: ''};
          draw();
          var f = S.page.querySelector('#fp-cln-cert-fp');
          M.say(S.page.querySelector('[data-fp-cln-link]'), t('cln_probed'));
          if (f) { S.page.querySelector('#fp-cln-same').focus(); }
        }, function (err) {
          S.busy = false;
          if (!alive(mine)) { return; }
          UI.setBusy(b, false);
          M.failed(form, err);
        });
        return;
      }
      var same = form.querySelector('#fp-cln-same');
      var name = form.querySelector('#fp-cln-name');
      var key = form.querySelector('#fp-cln-key');
      var pw = form.querySelector('#fp-cln-pw');
      if (!same.checked) { M.fieldError(form, same, t('cln_same_missing')); return; }
      if (!NAME_RE.test(name.value.trim())) { M.fieldError(form, name, t('cln_name_bad')); return; }
      if (!KEY_RE.test(key.value.trim())) { M.fieldError(form, key, t('cln_key_bad')); return; }
      if (!pw.value) { M.fieldError(form, pw, t('cln_password_missing')); return; }
      var body = {name: name.value.trim(), url: S.probe.url, private: S.probe.private, key: key.value.trim(), fingerprint: S.probe.cert.fingerprint, current_password: pw.value};
      S.probe.name = body.name;
      S.busy = true;
      UI.setBusy(b, true);
      FP.call('post', 'clusterNodes', body).then(function (r) {
        S.busy = false;
        if (!alive(mine)) { return; }
        var n = cleanNode(r && r.node);
        S.probe = null;
        if (n) {
          S.nodes = S.nodes.filter(function (x) { return x.id !== n.id; }).concat([n]).sort(function (x, y) { return x.name < y.name ? -1 : 1; });
        }
        draw();
        M.say(S.page.querySelector('.fp-cln-nodes-card'), t('cln_linked', {name: body.name}));
        var h = n && S.page.querySelector('#fp-cln-node-' + n.id);
        (h || S.page.querySelector('#fp-cln-nodes-h')).focus();
      }, function (err) {
        S.busy = false;
        if (!alive(mine)) { return; }
        UI.setBusy(b, false);
        pw.value = '';
        M.failed(form, err);
      });
    });
    var body = [el('p', {class: 'fp-muted', text: t('cln_link_what')}),
      el('ol', {class: 'fp-cln-steps'}, [el('li', {class: p ? 'is-done' : 'is-now', text: t('cln_step_address')}), el('li', {class: p ? 'is-now' : '', text: t('cln_step_compare')}),
        el('li', {text: t('cln_step_link')})]), form];
    if (S.nodes.length >= MAX_NODES) {
      body = [el('p', {class: 'fp-muted', 'data-fp-cln-full': '', text: t('cln_nodes_full', {n: String(MAX_NODES)})})];
    }
    return M.card('fp-cln-link-h', t('cln_link_title'), body, 'fp-cln-link-card');
  }

  /* ---------- the keys this server gives ---------- */
  function keyRow(k) {
    return el('tr', {'data-fp-cln-key': String(k.id)}, [
      el('th', {scope: 'row'}, [el('span', {text: k.name}), el('span', {class: 'sig-hint sig-mono fp-cln-key-prefix', text: 'fpn_' + k.prefix + '…'})]),
      el('td', {text: k.addresses.length ? k.addresses.join(', ') : t('cln_key_anywhere')}),
      el('td', {'data-fp-cln-key-sources': '', text: k.sources.length ? k.sources.map(sourceName).join(', ') : t('cln_key_no_sources')}),
      el('td', null, [k.expired ? el('span', {class: 'sig-pill sig-pill--danger', text: t('cln_key_expired')}) : el('span', {text: when(k.expires)})]),
      el('td', {text: k.lastUsed ? t('cln_key_used', {when: when(k.lastUsed), from: k.lastIp}) : t('cln_key_unused')}),
      el('td', {class: 'fp-cln-key-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'cln-revoke',
        'data-fp-key': String(k.id), 'aria-label': t('cln_revoke_named', {name: k.name}), text: t('cln_revoke')})])]);
  }
  function keysCard() {
    var body = [el('p', {class: 'fp-muted', text: t('cln_keys_what')})];
    body.push(el('div', {class: 'fp-cln-own', 'data-fp-cln-own': ''}, [el('p', {class: 'fp-cln-cert-k', text: t('cln_own_fp')}),
      S.own ? el('p', {class: 'sig-mono fp-cln-fp', id: 'fp-cln-own-fp', text: S.own}) : el('p', {class: 'fp-muted', text: t('cln_own_fp_none')}),
      el('p', {class: 'sig-hint', text: t('cln_own_fp_hint')})]));
    if (S.newKey) {
      body.push(el('div', {class: 'fp-cln-fresh', 'data-fp-cln-fresh': '', role: 'group', 'aria-labelledby': 'fp-cln-fresh-h'}, [
        el('h3', {class: 'fp-h3', id: 'fp-cln-fresh-h', tabindex: '-1', text: t('cln_fresh_title', {name: S.newKey.name})}),
        el('p', {class: 'fp-muted', text: t('cln_fresh_what')}),
        el('p', {class: 'sig-mono fp-cln-secret', id: 'fp-cln-secret', text: S.newKey.key}), M.statusLine(),
        el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'cln-copy'}, [UI.icon(FP.ui, 'ui_copy'), t('cln_copy')]),
          el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'cln-copied', text: t('cln_fresh_done')})])]));
    }
    body.push(el('h3', {class: 'fp-h3', text: t('cln_keys_list')}));
    if (!S.keys.length) {
      body.push(el('p', {class: 'fp-muted', 'data-fp-cln-nokeys': '', text: t('cln_keys_none')}));
    } else {
      body.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-label': t('cln_keys_list')}, [el('table', {class: 'sig-table fp-cln-table fp-cln-keys'}, [
        el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('cln_col_key')}), el('th', {scope: 'col', text: t('cln_col_from')}),
          el('th', {scope: 'col', text: t('cln_col_sources')}), el('th', {scope: 'col', text: t('cln_col_expires')}), el('th', {scope: 'col', text: t('cln_col_used')}), el('th', {scope: 'col', text: t('cln_col_acts')})])]),
        el('tbody', null, S.keys.map(keyRow))])]));
    }
    if (S.keys.length < MAX_KEYS) { body.push(keyForm()); } else { body.push(el('p', {class: 'fp-muted', text: t('cln_keys_full', {n: String(MAX_KEYS)})})); }
    return M.card('fp-cln-keys-h', t('cln_keys_title'), body, 'fp-cln-keys-card');
  }
  function keyForm() {
    var name = el('input', {class: 'sig-input', id: 'fp-cln-kname', name: 'name', type: 'text', autocomplete: 'off', maxlength: '64'});
    var days = el('input', {class: 'sig-input fp-cln-days', id: 'fp-cln-kdays', name: 'expires_days', type: 'number', min: '1', max: '365', step: '1', value: '90'});
    var addrs = el('textarea', {class: 'sig-input fp-cln-addrs', id: 'fp-cln-kaddrs', name: 'addresses', rows: '2', spellcheck: 'false', autocapitalize: 'none'});
    var pw = el('input', {class: 'sig-input', id: 'fp-cln-kpw', name: 'current_password', type: 'password', autocomplete: 'current-password', maxlength: '1024'});
    /* the sources the key may move accounts from: this server's freePanel sources, none ticked */
    var boxes = S.sources.map(function (src, i) {
      var id = 'fp-cln-ksrc-' + i;
      return el('label', {class: 'fp-check', for: id}, [el('input', {type: 'checkbox', id: id, name: 'source_ids', value: String(src.id)}),
        el('span', {text: src.host ? t('cln_source_opt', {name: src.name, host: src.host}) : src.name})]);
    });
    var sources = el('fieldset', {class: 'sig-field fp-cln-ksources', 'aria-describedby': 'fp-cln-ksrc-hint'}, [el('legend', {class: 'sig-label', text: t('cln_key_sources')})]
      .concat(boxes.length ? boxes : [el('p', {class: 'fp-muted', 'data-fp-cln-nosources': '', text: t('cln_key_sources_none')})],
        [el('span', {class: 'sig-hint', id: 'fp-cln-ksrc-hint', text: t('cln_key_sources_hint')})]));
    var form = el('form', {class: 'fp-form fp-cln-key-form', novalidate: '', 'data-fp-cln-keyform': ''}, [el('h3', {class: 'fp-h3', text: t('cln_key_new')}), M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-cln-move-grid'}, [M.field('fp-cln-kname', t('cln_key_name'), name, t('cln_key_name_hint')),
        M.field('fp-cln-kdays', t('cln_key_days'), days, t('cln_key_days_hint'))]),
      sources,
      M.field('fp-cln-kaddrs', t('cln_key_addrs'), addrs, t('cln_key_addrs_hint')),
      M.field('fp-cln-kpw', t('cln_password'), pw, t('cln_key_password_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', id: 'fp-cln-kmake', text: t('cln_key_make')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || S.busy) { return; }
      var n = parseInt(days.value, 10);
      if (!NAME_RE.test(name.value.trim())) { M.fieldError(form, name, t('cln_name_bad')); return; }
      if (!(n >= 1 && n <= 365) || String(n) !== days.value.trim()) { M.fieldError(form, days, t('cln_key_days_bad')); return; }
      if (!pw.value) { M.fieldError(form, pw, t('cln_password_missing')); return; }
      var list = addrs.value.split(/[\s,]+/).filter(Boolean);
      var mine = S.page;
      S.busy = true;
      UI.setBusy(b, true);
      var picked = Array.prototype.filter.call(form.querySelectorAll('input[name="source_ids"]'), function (c) { return c.checked; })
        .map(function (c) { return parseInt(c.value, 10); });
      FP.call('post', 'clusterKeys', {name: name.value.trim(), expires_days: n, addresses: list, source_ids: picked, current_password: pw.value}).then(function (r) {
        S.busy = false;
        if (!alive(mine)) { return; }
        var k = cleanKey(r);
        var secret = r && typeof r.key === 'string' && KEY_RE.test(r.key) ? r.key : '';
        if (!k || !secret) { UI.setBusy(b, false); M.fieldError(form, null, t('cln_unreadable')); return; }
        S.keys = [k].concat(S.keys);
        S.newKey = {name: k.name, key: secret};
        draw();
        S.page.querySelector('#fp-cln-fresh-h').focus();
      }, function (err) {
        S.busy = false;
        if (!alive(mine)) { return; }
        UI.setBusy(b, false);
        pw.value = '';
        M.failed(form, err);
      });
    });
    return form;
  }

  /* ---------- drawing ---------- */
  function draw() {
    S.page.textContent = '';
    S.page.appendChild(el('div', {class: 'fp-cln-trust sig-banner', role: 'note'}, [UI.icon(FP.ui, 'ui_info'), el('span', {text: t('cln_trust')})]));
    S.page.appendChild(nodesCard());
    S.page.appendChild(linkCard());
    S.page.appendChild(keysCard());
    S.page.appendChild(receiveCard());
  }

  /* ---------- which key may set this server's panel settings ---------- */
  function receiveCard() {
    var pick = el('select', {class: 'sig-select', id: 'fp-cln-recv', name: 'key_id'}, [el('option', {value: '0', text: t('cln_recv_none')})].concat(S.keys.map(function (k) {
      return el('option', {value: String(k.id), text: k.name, selected: k.id === S.recv ? true : null});
    })));
    var form = el('form', {class: 'fp-form fp-mail-form fp-cln-recv-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-cln-recv', t('cln_recv'), pick, t('cln_recv_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary fp-submit', type: 'submit', text: t('cln_recv_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var mine = S.page;
      var id = parseInt(pick.value, 10) || 0;
      UI.setBusy(b, true);
      FP.call('put', 'clusterSettingsReceive', {key_id: id}).then(function (r) {
        if (!alive(mine)) { return; }
        S.recv = r && whole(r.key_id) ? r.key_id : 0;
        draw();
        M.say(S.page.querySelector('.fp-cln-recv-form'), t(S.recv ? 'cln_recv_on' : 'cln_recv_off'));
        S.page.querySelector('#fp-cln-recv').focus();
      }, function (err) {
        if (!alive(mine)) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return M.card('fp-cln-recv-h', t('cln_recv_title'), [el('p', {class: 'fp-muted', text: t('cln_recv_what')}), form], 'fp-cln-recv-card');
  }
  function copySettings(n, b) {
    var mine = S.page;
    UI.setBusy(b, true);
    FP.call('post', 'clusterNodeSettings', {}, {id: String(n.id)}).then(function () {
      if (!alive(mine)) { return; }
      delete S.nodeError[n.id];
      draw();
      M.say(S.page.querySelector('.fp-cln-nodes-card'), t('cln_settings_done', {name: n.name}));
      focusAct('cln-settings', n.id);
    }, function (err) {
      if (!alive(mine)) { return; }
      S.nodeError[n.id] = err.message;
      draw();
      focusAct('cln-settings', n.id);
    });
  }

  /* ---------- the buttons ---------- */
  function refresh(n, b) {
    var mine = S.page;
    S.busy = true;
    UI.setBusy(b, true);
    FP.call('get', 'clusterNodeStatus', null, {id: String(n.id)}).then(function (r) {
      S.busy = false;
      if (!alive(mine)) { return; }
      var fresh = cleanNode(r && r.node);
      delete S.nodeError[n.id];
      if (fresh) { S.nodes = S.nodes.map(function (x) { return x.id === fresh.id ? fresh : x; }); }
      draw();
      M.say(S.page.querySelector('.fp-cln-nodes-card'), t('cln_refreshed', {name: n.name}));
      focusAct('cln-refresh', n.id);
    }, function (err) {
      S.busy = false;
      if (!alive(mine)) { return; }
      S.nodeError[n.id] = err.message;
      draw();
      focusAct('cln-refresh', n.id);
    });
  }
  function loadAccounts(n) {
    var mine = S.page;
    FP.call('get', 'clusterNodeAccounts', null, {id: String(n.id)}).then(function (r) {
      if (!alive(mine)) { return; }
      S.lists[n.id] = cleanAccounts(r);
      if (S.open[n.id] === 'accounts') { draw(); focusAct('cln-accounts', n.id); }
    }, function (err) {
      if (!alive(mine)) { return; }
      S.open[n.id] = '';
      S.nodeError[n.id] = err.message;
      draw();
      focusAct('cln-accounts', n.id);
    });
  }
  function focusAct(act, id) {
    var b = S.page.querySelector('[data-fp-act="' + act + '"][data-fp-node="' + id + '"]');
    if (b) { b.focus(); }
  }
  function unlink(n, b) {
    var mine = S.page;
    S.busy = true;
    UI.setBusy(b, true);
    FP.call('del', 'clusterNode', null, {id: String(n.id)}).then(function (r) {
      S.busy = false;
      if (!alive(mine)) { return; }
      S.nodes = S.nodes.filter(function (x) { return x.id !== n.id; });
      draw();
      var revoked = r && r.revoked === true;
      M.say(S.page.querySelector('.fp-cln-nodes-card'), revoked ? t('cln_unlinked', {name: n.name}) : t('cln_unlinked_kept', {name: n.name, error: str(r && r.error, 300)}));
      S.page.querySelector('#fp-cln-nodes-h').focus();
    }, function (err) {
      S.busy = false;
      if (!alive(mine)) { return; }
      S.nodeError[n.id] = err.message;
      draw();
    });
  }
  function revoke(k, b) {
    var mine = S.page;
    S.busy = true;
    UI.setBusy(b, true);
    FP.call('del', 'clusterKey', null, {id: String(k.id)}).then(function () {
      S.busy = false;
      if (!alive(mine)) { return; }
      S.keys = S.keys.filter(function (x) { return x.id !== k.id; });
      if (S.newKey && S.newKey.name === k.name) { S.newKey = null; }
      draw();
      M.say(S.page.querySelector('[data-fp-cln-keyform]') || S.page.querySelector('.fp-cln-keys-card'), t('cln_revoked', {name: k.name}));
      S.page.querySelector('#fp-cln-keys-h').focus();
    }, function (err) {
      S.busy = false;
      if (!alive(mine)) { return; }
      draw();
      UI.showError(S.page.querySelector('[data-fp-cln-keyform]') || S.page.querySelector('.fp-cln-keys-card'), err.message);
    });
  }
  function copySecret(b) {
    var scope = S.page.querySelector('[data-fp-cln-fresh]');
    var node = S.page.querySelector('#fp-cln-secret');
    function selected() {
      var range = document.createRange();
      range.selectNodeContents(node);
      var sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
      M.say(scope, t('cln_selected'));
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(S.newKey.key).then(function () { M.say(scope, t('copied')); }, selected);
    } else {
      selected();
    }
    b.focus();
  }

  document.addEventListener('click', function (e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !S || !S.page || !S.page.contains(b) || S.busy) { return; }
    var act = b.getAttribute('data-fp-act');
    var n = nodeById(parseInt(b.getAttribute('data-fp-node'), 10) || 0);
    var k = S.keys.filter(function (x) { return String(x.id) === b.getAttribute('data-fp-key'); })[0] || null;
    var row = b.closest('[data-fp-cln-acts], .fp-cln-key-acts');
    if (act === 'cln-refresh' && n) {
      refresh(n, b);
    } else if (act === 'cln-accounts' && n) {
      S.open[n.id] = S.open[n.id] === 'accounts' ? '' : 'accounts';
      draw();
      focusAct('cln-accounts', n.id);
      if (S.open[n.id] === 'accounts' && !S.lists[n.id]) { loadAccounts(n); }
    } else if (act === 'cln-more' && n) {
      S.shown[n.id] = (S.shown[n.id] || SHOWN) + SHOWN;
      draw();
      focusAct('cln-accounts', n.id);
    } else if (act === 'cln-move' && n) {
      S.open[n.id] = S.open[n.id] === 'move' ? '' : 'move';
      draw();
      var f = S.page.querySelector('[data-fp-cln-move="' + n.id + '"] select');
      if (f) { f.focus(); } else { focusAct('cln-move', n.id); }
    } else if (act === 'cln-settings' && n && row) {
      row.setAttribute('data-fp-cln-for', String(n.id));
      M.confirmIn(row, t('cln_settings_ask', {name: n.name}), 'cln-settings-yes', t('cln_settings_yes'));
    } else if (act === 'cln-settings-yes' && row) {
      var to = nodeById(parseInt(row.getAttribute('data-fp-cln-for'), 10) || 0);
      if (to) { copySettings(to, b); }
    } else if (act === 'cln-unlink' && n && row) {
      row.setAttribute('data-fp-cln-for', String(n.id));
      M.confirmIn(row, t('cln_unlink_ask', {name: n.name}), 'cln-unlink-yes', t('cln_unlink_yes'));
    } else if (act === 'cln-unlink-yes' && row) {
      var target = nodeById(parseInt(row.getAttribute('data-fp-cln-for'), 10) || 0);
      if (target) { unlink(target, b); }
    } else if (act === 'cln-revoke' && k && row) {
      row.setAttribute('data-fp-cln-for', String(k.id));
      M.confirmIn(row, t('cln_revoke_ask', {name: k.name}), 'cln-revoke-yes', t('cln_revoke'));
    } else if (act === 'cln-revoke-yes' && row) {
      var key = S.keys.filter(function (x) { return String(x.id) === row.getAttribute('data-fp-cln-for'); })[0];
      if (key) { revoke(key, b); }
    } else if (act === 'confirm-no' && row) {
      var id = row.getAttribute('data-fp-cln-for');
      var isKey = row.classList.contains('fp-cln-key-acts');
      draw();
      var again = S.page.querySelector(isKey ? '[data-fp-act="cln-revoke"][data-fp-key="' + id + '"]' : '[data-fp-act="cln-unlink"][data-fp-node="' + id + '"]');
      if (again) { again.focus(); }
    } else if (act === 'cln-restart') {
      S.probe = null;
      draw();
      S.page.querySelector('#fp-cln-url').focus();
    } else if (act === 'cln-copy' && S.newKey) {
      copySecret(b);
    } else if (act === 'cln-copied') {
      S.newKey = null;
      draw();
      S.page.querySelector('#fp-cln-keys-h').focus();
    }
  });

  FP.view('tool:server_nodes', function () {
    var tool = FP.tools.server_nodes;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    S = fresh();
    var mine = FP.frame({title: tool.label, desc: t('cln_desc'), cls: 'fp-mail fp-srv fp-cln-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    S.page = mine;
    mine.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all([FP.call('get', 'clusterNodes'), FP.call('get', 'clusterKeys'),
      FP.call('get', 'accounts').catch(function () { return {accounts: []}; }),
      FP.call('get', 'transfers').catch(function () { return {sources: []}; }),
      FP.call('get', 'clusterSettingsReceive').catch(function () { return {key_id: 0}; })]).then(function (r) {
      if (!alive(mine)) { return; }
      S.nodes = (r[0] && Array.isArray(r[0].nodes) ? r[0].nodes : []).slice(0, MAX_NODES).map(cleanNode).filter(Boolean);
      S.keys = (r[1] && Array.isArray(r[1].keys) ? r[1].keys : []).slice(0, MAX_KEYS).map(cleanKey).filter(Boolean);
      S.own = fingerprint(r[1] && r[1].fingerprint);
      S.mine = (r[2] && Array.isArray(r[2].accounts) ? r[2].accounts : []).map(function (a) { return str(a && a.username, 16); })
        .filter(function (u) { return USER_RE.test(u); }).sort();
      S.sources = cleanSources(r[3]);
      S.recv = r[4] && whole(r[4].key_id) ? r[4].key_id : 0;
      draw();
    }, function (err) {
      if (!alive(mine)) { return; }
      mine.textContent = '';
      mine.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

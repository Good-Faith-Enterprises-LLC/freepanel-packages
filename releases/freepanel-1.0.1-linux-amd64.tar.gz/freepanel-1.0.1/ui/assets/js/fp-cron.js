/* freePanel scheduled tasks (#/tool/cron), the customer panel's page for the account's crontab (docs/api.md, "Scheduled
   tasks"): where cron mails a task's output, a form to add or change a task (a common schedule fills the five fields),
   and the list of tasks with change and remove. Tasks added over SSH show here too; the server keeps every line it
   does not show. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;

  var FIELDS = ['minute', 'hour', 'day', 'month', 'weekday'];
  var ID_RE = /^[0-9a-f]{16}$/;
  /* common schedules: the five fields each fills */
  var PRESETS = [
    ['every_minute', '* * * * *'], ['every_5_minutes', '*/5 * * * *'], ['every_15_minutes', '*/15 * * * *'],
    ['twice_hour', '0,30 * * * *'], ['once_hour', '0 * * * *'], ['twice_day', '0 0,12 * * *'], ['once_day', '0 0 * * *'],
    ['once_week', '0 0 * * 0'], ['twice_month', '0 0 1,15 * *'], ['once_month', '0 0 1 * *'], ['once_year', '0 0 1 1 *']
  ];
  /* what an @ schedule from a crontab means, as five fields; @reboot has none */
  var SPECIAL_FIELDS = {'@hourly': '0 * * * *', '@daily': '0 0 * * *', '@midnight': '0 0 * * *', '@weekly': '0 0 * * 0',
    '@monthly': '0 0 1 * *', '@yearly': '0 0 1 1 *', '@annually': '0 0 1 1 *'};

  var page = null;   /* the frame's body */
  var state = null;  /* the last Crontab the server sent */
  var editing = null; /* the task being changed, or null when adding */
  var account = '';

  function str(v) { return typeof v === 'string' ? v : ''; }
  function clean(v) {
    v = v && typeof v === 'object' ? v : {};
    var tasks = (Array.isArray(v.tasks) ? v.tasks : []).filter(function (k) { return k && ID_RE.test(str(k.id)); }).map(function (k) {
      return {id: k.id, minute: str(k.minute), hour: str(k.hour), day: str(k.day), month: str(k.month), weekday: str(k.weekday),
        special: str(k.special), command: str(k.command)};
    });
    return {email: str(v.email), emailSet: v.email_set === true, suspended: v.suspended === true, tasks: tasks};
  }

  function card(id, title, children) {
    return el('section', {class: 'sig-card fp-cron-card', 'aria-labelledby': id}, [el('div', {class: 'sig-card-body'},
      [el('h2', {class: 'fp-h2', id: id, tabindex: '-1', text: title})].concat(children))]);
  }
  function errorLine() { return el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': ''}); }
  function statusLine() { return el('p', {class: 'fp-ok-line', role: 'status', 'data-fp-status': ''}); }
  function say(scope, text) {
    var s = scope.querySelector('[data-fp-status]');
    if (s) { s.textContent = text || ''; }
  }
  function input(id, label, attrs, hint) {
    var hintId = hint ? id + '-hint' : null;
    return el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: id, text: label}),
      el('input', Object.assign({class: 'sig-input', id: id, 'aria-describedby': hintId}, attrs)),
      hint ? el('span', {class: 'sig-hint', id: hintId, text: hint}) : null]);
  }
  /* an error line and the field it is about: the field is marked and focused, and the page scrolls so the line above it
     shows too (focusing alone can leave the line under the top bar) */
  function fieldError(form, f, message) {
    UI.showError(form, message);
    if (!f) { return; }
    f.setAttribute('aria-invalid', 'true');
    f.focus({preventScroll: true});
    var line = form.querySelector('[data-fp-error]');
    if (line && line.scrollIntoView) { line.scrollIntoView({block: 'nearest'}); }
  }
  /* an error from the server: the message, and the field it names marked */
  function failed(form, err) {
    if (err && err.code === 'not_found' && editing) {
      /* the task changed meanwhile (over SSH, or in another tab): show the list as it is now */
      load(t('cron_changed_meanwhile'));
      return;
    }
    var f = err && err.field ? UI.fieldNamed(form, err.field) : null;
    var label = f ? form.querySelector('label[for="' + f.id + '"]') : null;
    fieldError(form, f, (label ? label.textContent + ': ' : '') + (err ? err.message : t('api_failed')));
  }
  function clearInvalid(form) {
    var bad = form.querySelectorAll('[aria-invalid]');
    for (var i = 0; i < bad.length; i++) { bad[i].removeAttribute('aria-invalid'); }
  }

  /* ---- output email ---- */
  function emailCard() {
    var box = input('fp-cron-email', t('cron_email_label'), {type: 'email', name: 'email', autocomplete: 'email', maxlength: '254',
      spellcheck: 'false', value: state.email}, t('cron_email_hint'));
    var form = el('form', {class: 'fp-form fp-cron-email', novalidate: ''}, [errorLine(), statusLine(),
      el('p', {class: 'fp-muted', 'data-fp-email-now': '', text: state.emailSet && state.email ? t('cron_email_now', {email: state.email}) : t('cron_email_none')}),
      box, el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('cron_email_save')})])]);
    var field = box.querySelector('input');
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = form.querySelector('.fp-submit');
      if (b.disabled) { return; }
      UI.showError(form, '');
      say(form, '');
      clearInvalid(form);
      var v = field.value.trim();
      if (v && !/^[^\s@,;"<>]+@[^\s@,;"<>]+\.[^\s@,;"<>]+$/.test(v)) {
        fieldError(form, field, t('cron_email_bad'));
        return;
      }
      UI.setBusy(b, true);
      FP.call('put', 'cronEmail', {email: v}, account).then(function (r) {
        UI.setBusy(b, false);
        state = clean(r);
        field.value = state.email;
        form.querySelector('[data-fp-email-now]').textContent = state.emailSet && state.email ? t('cron_email_now', {email: state.email}) : t('cron_email_none');
        say(form, v ? t('cron_email_saved') : t('cron_email_off'));
      }, function (err) {
        UI.setBusy(b, false);
        failed(form, err);
      });
    });
    return card('fp-cron-email-h', t('cron_email_title'), [el('p', {class: 'fp-muted', text: t('cron_email_desc')}), form]);
  }

  /* ---- add or change a task ---- */
  function taskCard() {
    var k = editing;
    var reboot = Boolean(k && k.special === '@reboot');
    var fields = k ? (k.special ? (SPECIAL_FIELDS[k.special] || '* * * * *').split(' ') : FIELDS.map(function (f) { return k[f]; })) : ['', '', '', '', ''];
    var preset = el('select', {class: 'sig-select', id: 'fp-cron-preset', 'aria-describedby': 'fp-cron-preset-hint'},
      [el('option', {value: '', text: t('cron_preset_pick')})].concat(PRESETS.map(function (p) { return el('option', {value: p[1], text: t('cron_' + p[0])}); })));
    var grid = el('div', {class: 'fp-cron-fields'}, FIELDS.map(function (f, i) {
      return input('fp-cron-' + f, t('cron_' + f), {type: 'text', name: f, value: fields[i], maxlength: '64', spellcheck: 'false',
        autocomplete: 'off', class: 'sig-input sig-mono'}, t('cron_' + f + '_hint'));
    }));
    var when = reboot ? el('p', {class: 'fp-muted', 'data-fp-reboot': '', text: t('cron_reboot_note')}) :
      el('div', null, [el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: 'fp-cron-preset', text: t('cron_preset')}), preset,
        el('span', {class: 'sig-hint', id: 'fp-cron-preset-hint', text: t('cron_preset_hint')})]), grid]);
    var cmd = input('fp-cron-command', t('cron_command'), {type: 'text', name: 'command', value: k ? k.command : '', maxlength: '4096',
      spellcheck: 'false', autocomplete: 'off', class: 'sig-input sig-mono'}, t('cron_command_hint'));
    var actions = el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: k ? t('cron_save') : t('cron_add')}),
      k ? el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'cancel-edit', text: t('cancel')}) : null]);
    var form = el('form', {class: 'fp-form fp-cron-task', novalidate: ''}, [errorLine(), statusLine(), when, cmd, actions]);
    preset.addEventListener('change', function () {
      if (!preset.value) { return; }
      preset.value.split(' ').forEach(function (v, i) {
        var f = form.querySelector('[name="' + FIELDS[i] + '"]');
        f.value = v;
        f.removeAttribute('aria-invalid');
      });
    });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = form.querySelector('.fp-submit');
      if (b.disabled) { return; }
      UI.showError(form, '');
      say(form, '');
      clearInvalid(form);
      var body = {command: form.querySelector('[name="command"]').value.trim()};
      if (reboot) {
        body.special = '@reboot';
      } else {
        for (var i = 0; i < FIELDS.length; i++) {
          var f = form.querySelector('[name="' + FIELDS[i] + '"]');
          body[FIELDS[i]] = f.value.replace(/\s+/g, '');
          if (!body[FIELDS[i]]) {
            fieldError(form, f, t('cron_need_field', {field: t('cron_' + FIELDS[i])}));
            return;
          }
        }
      }
      if (!body.command) {
        fieldError(form, form.querySelector('[name="command"]'), t('cron_need_command'));
        return;
      }
      UI.setBusy(b, true);
      var call = editing ? FP.call('put', 'cronTask', body, {name: account, id: editing.id}) : FP.call('post', 'cronTasks', body, account);
      call.then(function (r) {
        var changed = Boolean(editing);
        state = clean(r);
        editing = null;
        render();
        var list = page.querySelector('#fp-cron-list-h');
        say(page.querySelector('.fp-cron-list'), changed ? t('cron_saved') : t('cron_added'));
        if (changed && list) { list.focus(); }
      }, function (err) {
        UI.setBusy(b, false);
        failed(form, err);
      });
    });
    return card('fp-cron-task-h', k ? t('cron_edit_title') : t('cron_add_title'), [form]);
  }

  /* ---- the list ---- */
  function scheduleCells(k) {
    if (k.special) {
      var name = t('cron_special_' + k.special.slice(1));
      return [el('td', {colspan: '5'}, [el('span', {text: name === 'cron_special_' + k.special.slice(1) ? k.special : name}),
        el('span', {class: 'fp-muted sig-mono', text: ' ' + k.special})])];
    }
    return FIELDS.map(function (f) { return el('td', {class: 'sig-mono', 'data-label': t('cron_' + f), text: k[f]}); });
  }
  function row(k, n) {
    var label = t('cron_task_n', {n: n});
    return el('tr', {'data-fp-task': k.id}, scheduleCells(k).concat([
      el('td', {class: 'sig-mono fp-cron-cmd', text: k.command}),
      el('td', {class: 'fp-cron-acts'}, state.suspended ? [] : [
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'edit', 'aria-label': t('cron_edit') + ' ' + label, text: t('cron_edit')}),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'remove', 'aria-label': t('cron_remove') + ' ' + label, text: t('cron_remove')})])]));
  }
  function listCard() {
    var parts = [errorLine(), statusLine()];
    if (!state.tasks.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('cron_none')}));
    } else {
      var head = el('tr', null, FIELDS.map(function (f) { return el('th', {scope: 'col', text: t('cron_' + f)}); }).concat([
        el('th', {scope: 'col', text: t('cron_command')}), el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('cron_actions')})])]));
      var tbody = el('tbody', null, state.tasks.map(function (k, i) { return row(k, i + 1); }));
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-cron-list-h'}, [
        el('table', {class: 'sig-table fp-cron-table'}, [el('thead', null, [head]), tbody])]));
    }
    var node = card('fp-cron-list-h', t('cron_list_title'), parts);
    node.classList.add('fp-cron-list');
    return node;
  }

  function confirmRemove(tr) {
    var cell = tr.querySelector('.fp-cron-acts');
    var n = Array.prototype.indexOf.call(tr.parentNode.children, tr) + 1;
    cell.textContent = '';
    var yes = el('button', {class: 'sig-btn sig-btn--danger sig-btn--sm', type: 'button', 'data-fp-act': 'remove-yes', text: t('cron_remove_yes')});
    var id = 'fp-cron-confirm-' + tr.getAttribute('data-fp-task');
    cell.appendChild(el('span', {class: 'fp-cron-confirm', id: id, text: t('cron_remove_ask', {n: n})}));
    var no = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'remove-no', text: t('cancel')});
    cell.appendChild(yes);
    cell.appendChild(no);
    yes.setAttribute('aria-describedby', id);
    no.setAttribute('aria-describedby', id);
    /* Cancel takes focus, so a second Enter on Remove can't remove the task */
    no.focus();
  }
  function remove(tr, b) {
    var list = page.querySelector('.fp-cron-list');
    UI.showError(list, '');
    UI.setBusy(b, true);
    FP.call('del', 'cronTask', undefined, {name: account, id: tr.getAttribute('data-fp-task')}).then(function (r) {
      state = clean(r);
      if (editing && !state.tasks.some(function (k) { return k.id === editing.id; })) { editing = null; }
      render();
      say(page.querySelector('.fp-cron-list'), t('cron_removed'));
      page.querySelector('#fp-cron-list-h').focus();
    }, function (err) {
      if (err && err.code === 'not_found') { load(t('cron_changed_meanwhile')); return; }
      UI.setBusy(b, false);
      UI.showError(list, err.message);
    });
  }

  function onClick(e) {
    var target = e.target.closest ? e.target : null;
    if (!target || !page || !page.contains(target)) { return; }
    var act = target.closest('[data-fp-act]');
    if (!act) { return; }
    var a = act.getAttribute('data-fp-act');
    var tr = act.closest('tr');
    if (a === 'edit') {
      editing = state.tasks.filter(function (k) { return k.id === tr.getAttribute('data-fp-task'); })[0] || null;
      render();
      page.querySelector('#fp-cron-task-h').focus();
    } else if (a === 'cancel-edit') {
      /* back to the task's Change button, which is where the keys came from */
      var was = editing;
      editing = null;
      render();
      var opener = was ? page.querySelector('tr[data-fp-task="' + window.CSS.escape(String(was.id)) + '"] [data-fp-act="edit"]') : null;
      (opener || page.querySelector('#fp-cron-task-h')).focus();
    } else if (a === 'remove') {
      confirmRemove(tr);
    } else if (a === 'remove-no') {
      var id = tr.getAttribute('data-fp-task');
      render();
      var back = page.querySelector('tr[data-fp-task="' + id + '"] [data-fp-act="remove"]');
      if (back) { back.focus(); }
    } else if (a === 'remove-yes') {
      remove(tr, act);
    }
  }
  document.addEventListener('click', onClick);

  function render() {
    page.textContent = '';
    if (state.suspended) {
      page.appendChild(el('div', {class: 'sig-banner sig-banner--warn', role: 'note'}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('cron_suspended')})]));
    }
    page.appendChild(listCard());
    if (!state.suspended) {
      page.appendChild(taskCard());
      page.appendChild(emailCard());
    }
  }

  function load(note) {
    page.textContent = '';
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'cron', undefined, account).then(function (r) {
      state = clean(r);
      editing = null;
      render();
      if (note) {
        var list = page.querySelector('.fp-cron-list');
        UI.showError(list, note);
      }
    }, function (err) {
      page.textContent = '';
      page.appendChild(FP.empty(t('cron_title'), err.message));
    });
  }

  FP.view('tool:cron', function () {
    var tool = FP.tools.cron;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    account = FP.account();
    page = FP.frame({title: tool.label, desc: t('cron_desc'), cls: 'fp-cron',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    load('');
  });
})();

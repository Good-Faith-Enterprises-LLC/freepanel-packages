/* freePanel move accounts here (#/tool/transfer_in), the admin panel's page for taking accounts in from another server
   over SFTP (docs/api.md, "Moving accounts in"): the switch that allows it (off until the admin turns it on, and
   nothing connects out while it is off), the servers accounts are read from (another panel's full-account backups or
   another freePanel server), a server's host key checked and accepted by comparing its fingerprint, the accounts a
   server holds, and a run that takes the chosen accounts one after another. A run goes on in the background, so while
   one does the page asks the server every few seconds. Passwords and keys are typed in, sent, and never shown again:
   the page only knows that one is saved, leaving it empty keeps it, and a box removes it. Everything the server says
   is drawn as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var USER_RE = /^[a-z][a-z0-9]{0,15}$/;
  var FILE_RE = /^[A-Za-z0-9._-]{1,255}$/;
  var KINDS = ['other_panel', 'freepanel'];
  var STATES = ['queued', 'packing', 'pulling', 'reading', 'importing', 'restoring', 'done', 'failed', 'skipped'];
  var MAX_NAME = 60;
  var MAX_ITEMS = 50;
  var MAX_NOTES = 20;
  var POLL_MS = 3000;
  var UNITS = ['KB', 'MB', 'GB', 'TB', 'PB'];

  var X = null;

  /* ---------- what the server says, kept to the shapes the page draws ---------- */
  function str(v) { return typeof v === 'string' ? v : ''; }
  function clip(v, n) { return str(v).slice(0, n); }
  function int(v, d) { return typeof v === 'number' && isFinite(v) ? Math.floor(v) : d; }
  function count(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.floor(v) : 0; }
  function size(n) {
    if (n < 1024) { return t('size_bytes', {n: String(Math.round(n))}); }
    var u = -1;
    do { n /= 1024; u++; } while (n >= 1024 && u < UNITS.length - 1);
    return (n < 10 ? n.toFixed(1) : Math.round(n).toLocaleString('en')) + ' ' + UNITS[u];
  }
  function when(iso) {
    var d = iso ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString(undefined, {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }
  function cleanSource(s) {
    if (!s || typeof s !== 'object' || KINDS.indexOf(s.kind) < 0 || int(s.id, 0) < 1) { return null; }
    return {id: int(s.id, 0), name: clip(s.name, MAX_NAME), kind: s.kind, host: clip(s.host, 253), port: int(s.port, 22), user: clip(s.user, 64),
      dir: clip(s.dir, 255), host_key: clip(s.host_key, 2048), fingerprint: clip(s.host_key_fingerprint, 100), password_set: s.password_set === true,
      private_key_set: s.private_key_set === true, passphrase_set: s.passphrase_set === true, public_key: clip(s.public_key, 600),
      pack: s.pack === true, handoff: s.handoff === true, problem: clip(s.problem, 300)};
  }
  function cleanItem(i) {
    if (!i || typeof i !== 'object' || !USER_RE.test(str(i.username))) { return null; }
    return {username: i.username, file: FILE_RE.test(str(i.file)) ? i.file : '', state: STATES.indexOf(i.state) >= 0 ? i.state : 'queued',
      bytes: count(i.bytes), total: count(i.total), partial: i.partial === true,
      notes: (Array.isArray(i.notes) ? i.notes : []).slice(0, MAX_NOTES).map(function (n) { return clip(n, 600); }).filter(Boolean),
      error: clip(i.error, 600), started: str(i.started), ended: str(i.ended)};
  }
  function cleanRun(r) {
    if (!r || typeof r !== 'object' || !str(r.id)) { return null; }
    return {id: clip(r.id, 64), source: clip(r.source, MAX_NAME), kind: KINDS.indexOf(r.kind) >= 0 ? r.kind : 'other_panel', pkg: clip(r.package, 64),
      started: str(r.started), ended: str(r.ended), stopping: r.stopping === true, stopped: r.stopped === true, aborted: clip(r.aborted, 400),
      items: (Array.isArray(r.items) ? r.items : []).slice(0, MAX_ITEMS).map(cleanItem).filter(Boolean)};
  }
  function cleanAll(r) {
    r = r && typeof r === 'object' ? r : {};
    return {allowed: r.allowed === true, max: Math.min(Math.max(int(r.max, 10), 1), 100), maxAccounts: Math.min(Math.max(int(r.max_accounts, 50), 1), 1000),
      sources: (Array.isArray(r.sources) ? r.sources : []).map(cleanSource).filter(Boolean), run: cleanRun(r.run)};
  }
  function cleanAccounts(r) {
    r = r && typeof r === 'object' ? r : {};
    return {accounts: (Array.isArray(r.accounts) ? r.accounts : []).slice(0, 5000).filter(function (a) { return a && USER_RE.test(str(a.username)); }).map(function (a) {
      return {username: a.username, file: FILE_RE.test(str(a.file)) ? a.file : '', bytes: typeof a.bytes === 'number' && isFinite(a.bytes) && a.bytes >= 0 ? a.bytes : null,
        modified: str(a.modified), conflict: clip(a.conflict, 300)};
    }), truncated: r.truncated === true, skipped: count(r.skipped), error: clip(r.error, 600)};
  }
  function take(all) {
    X.allowed = all.allowed;
    X.max = all.max;
    X.maxAccounts = all.maxAccounts;
    X.sources = all.sources;
    X.run = all.run;
  }
  function find(id) { return X.sources.filter(function (s) { return s.id === id; })[0] || null; }
  function running() { return Boolean(X.run && !X.run.ended); }

  function where(s) { return t('xfr_where', {user: s.user, host: s.host, port: s.port, dir: s.dir || t('xfr_home')}); }
  function signin(s) {
    if (s.public_key) { return t('xfr_signin_made'); }
    if (s.private_key_set) { return t('xfr_signin_key'); }
    return s.password_set ? t('xfr_signin_password') : t('xfr_signin_none');
  }

  /* ---------- the switch ---------- */
  function switchCard() {
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t('xfr_switch_desc')}),
      el('p', {'data-fp-xfr-state': '', class: X.allowed ? '' : 'fp-muted', text: t(X.allowed ? 'xfr_on' : 'xfr_off')}),
      el('div', {class: 'fp-actions', 'data-fp-xfr-switch-acts': ''}, [el('button', {class: 'sig-btn ' + (X.allowed ? 'sig-btn--secondary' : 'sig-btn--primary'),
        type: 'button', 'data-fp-act': X.allowed ? 'switch-off' : 'switch-on', text: t(X.allowed ? 'xfr_turn_off' : 'xfr_turn_on')})])];
    return M.card('fp-xfr-switch-h', t('xfr_switch_title'), parts, 'fp-xfr-switch');
  }
  function askSwitch() {
    var acts = X.page.querySelector('[data-fp-xfr-switch-acts]');
    acts.textContent = '';
    var yes = el('button', {class: 'sig-btn sig-btn--danger', type: 'button', 'data-fp-act': 'switch-yes', text: t('xfr_turn_on_yes'), 'aria-describedby': 'fp-xfr-ask'});
    var no = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'switch-no', text: t('cancel'), 'aria-describedby': 'fp-xfr-ask'});
    acts.appendChild(el('p', {class: 'fp-mail-confirm', id: 'fp-xfr-ask', text: t('xfr_ask_on')}));
    acts.appendChild(yes);
    acts.appendChild(no);
    no.focus();
  }
  function setSwitch(allowed, button) {
    var card = X.page.querySelector('.fp-xfr-switch');
    UI.showError(card, '');
    M.say(card, '');
    UI.setBusy(button, true);
    var mine = X;
    FP.call('put', 'transferSwitch', {allowed: allowed}).then(function (r) {
      if (X !== mine) { return; }
      take(cleanAll(r));
      drawAll();
      M.say(X.page.querySelector('.fp-xfr-switch'), t(X.allowed ? 'xfr_now_on' : 'xfr_now_off'));
      X.page.querySelector('#fp-xfr-switch-h').focus();
    }, function (err) {
      if (X !== mine) { return; }
      UI.setBusy(button, false);
      UI.showError(card, err.message);
      button.focus();
    });
  }

  /* ---------- the servers ---------- */
  function sourcesCard() {
    var parts = [M.errorLine(), M.statusLine()];
    if (!X.allowed) { parts.push(el('p', {class: 'fp-muted', 'data-fp-xfr-offnote': '', text: t('xfr_off_note')})); }
    if (!X.sources.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('xfr_none')}));
    } else {
      var rows = [];
      X.sources.forEach(function (s) {
        rows.push(el('tr', {'data-fp-source': String(s.id)}, [
          el('th', {scope: 'row', class: 'fp-mail-name'}, [el('span', {text: s.name}),
            s.problem ? el('p', {class: 'fp-bk-bad', 'data-fp-xfr-problem': '', text: t('xfr_problem', {why: s.problem})}) : null]),
          el('td', null, [document.createTextNode(t('xfr_kind_' + s.kind)), s.pack ? el('span', {class: 'fp-xfr-sub', 'data-fp-xfr-packs': '', text: t('xfr_pack_on')}) : null]),
          el('td', {class: 'fp-xfr-where', text: where(s)}),
          el('td', {text: signin(s)}),
          el('td', {class: 'fp-mail-acts'}, [
            el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'choose', 'aria-label': t('xfr_choose_of', {name: s.name}), text: t('xfr_choose')}),
            el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'test', 'aria-label': t('xfr_test_of', {name: s.name}), text: t('xfr_test')}),
            el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'edit', 'aria-label': t('xfr_edit_of', {name: s.name}), text: t('xfr_edit')}),
            el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'delete', 'aria-label': t('xfr_delete_of', {name: s.name}), text: t('xfr_delete')})])]));
        if (s.public_key) {
          rows.push(el('tr', {class: 'fp-xfr-keyrow', 'data-fp-xfr-pub': String(s.id)}, [el('td', {colspan: '5'}, [el('p', {class: 'fp-muted', text: t('xfr_pub_note_of', {user: s.user, host: s.host})}),
            el('code', {class: 'sig-mono fp-xfr-key', text: s.public_key})])]));
        }
      });
      var tbody = el('tbody', null, rows);
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-xfr-list-h'}, [
        el('table', {class: 'sig-table fp-mail-table fp-bk-table'}, [el('thead', null, [el('tr', null, [
          el('th', {scope: 'col', text: t('xfr_name')}), el('th', {scope: 'col', text: t('xfr_type')}), el('th', {scope: 'col', text: t('xfr_where_h')}),
          el('th', {scope: 'col', text: t('xfr_signin_h')}), el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]), tbody])]));
    }
    var full = X.sources.length >= X.max;
    parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'add', disabled: full,
      'aria-describedby': full ? 'fp-xfr-full' : null, text: t('xfr_add')}), full ? el('span', {class: 'sig-hint', id: 'fp-xfr-full', text: t('xfr_full', {max: X.max})}) : null]));
    return M.card('fp-xfr-list-h', t('xfr_list_title'), parts, 'fp-xfr-list');
  }
  function rowButton(id, act) {
    return X.page.querySelector('[data-fp-source="' + id + '"] [data-fp-act="' + act + '"]');
  }
  function askDelete(row) {
    var s = find(parseInt(row.getAttribute('data-fp-source'), 10));
    if (!s) { return; }
    var cell = row.querySelector('.fp-mail-acts');
    cell.textContent = '';
    var yes = el('button', {class: 'sig-btn sig-btn--danger sig-btn--sm', type: 'button', 'data-fp-act': 'delete-yes', text: t('xfr_delete'), 'aria-describedby': 'fp-xfr-del-q'});
    var no = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'delete-no', text: t('cancel'), 'aria-describedby': 'fp-xfr-del-q'});
    cell.appendChild(el('span', {class: 'fp-mail-confirm', id: 'fp-xfr-del-q', text: t('xfr_ask_delete', {name: s.name})}));
    cell.appendChild(yes);
    cell.appendChild(no);
    no.focus();
  }
  function testSaved(id, button) {
    var s = find(id);
    var card = X.page.querySelector('.fp-xfr-list');
    UI.showError(card, '');
    M.say(card, '');
    UI.setBusy(button, true);
    var mine = X;
    FP.call('post', 'transferSourceTest', undefined, {id: String(id)}).then(function (r) {
      if (X !== mine) { return; }
      UI.setBusy(button, false);
      if (r && r.ok === true) { M.say(card, t('xfr_test_ok', {name: s ? s.name : '', n: count(r.accounts)})); } else {
        UI.showError(card, t('xfr_test_failed', {name: s ? s.name : '', error: clip(r && r.error, 600) || t('api_failed')}));
      }
      button.focus();
    }, function (err) {
      if (X !== mine) { return; }
      UI.setBusy(button, false);
      UI.showError(card, err.message);
      button.focus();
    });
  }
  function remove(id, button) {
    var s = find(id);
    var card = X.page.querySelector('.fp-xfr-list');
    UI.showError(card, '');
    M.say(card, '');
    UI.setBusy(button, true);
    var mine = X;
    FP.call('del', 'transferSource', undefined, {id: String(id)}).then(function () {
      if (X !== mine) { return; }
      X.sources = X.sources.filter(function (x) { return x.id !== id; });
      if (X.form && X.form.id === id) { X.form = null; }
      if (X.move.source === id) { resetMove(0); }
      drawAll();
      M.say(X.page.querySelector('.fp-xfr-list'), t('xfr_deleted', {name: s ? s.name : ''}));
      X.page.querySelector('#fp-xfr-list-h').focus();
    }, function (err) {
      if (X !== mine) { return; }
      drawAll();
      UI.showError(X.page.querySelector('.fp-xfr-list'), err.message);
      (rowButton(id, 'delete') || X.page.querySelector('#fp-xfr-list-h')).focus();
    });
  }

  /* ---------- the form ---------- */
  function check(id, name, label, checked, hint) {
    return el('div', {class: 'fp-xfr-check'}, [el('label', {class: 'fp-check', for: id}, [el('input', {type: 'checkbox', id: id, name: name, checked: checked,
      'aria-describedby': hint ? id + '-hint' : null}), el('span', {text: label})]), hint ? el('span', {class: 'sig-hint', id: id + '-hint', text: hint}) : null]);
  }
  function text(id, name, label, value, hint, extra) {
    var attrs = {class: 'sig-input', id: id, name: name, type: 'text', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', value: value};
    Object.keys(extra || {}).forEach(function (k) { attrs[k] = extra[k]; });
    return M.field(id, label, el('input', attrs), hint);
  }
  /* a secret: never filled in; empty keeps what is saved, a box removes it */
  function secret(id, name, label, saved, hint, multi) {
    var attrs = {class: 'sig-input', id: id, name: name, autocomplete: 'new-password', spellcheck: 'false', autocapitalize: 'none',
      placeholder: saved ? t('xfr_secret_saved') : null};
    var control = multi ? el('textarea', Object.assign({rows: '5'}, attrs)) : el('input', Object.assign({type: 'password'}, attrs));
    var nodes = [M.field(id, label, control, saved ? t('xfr_secret_keep') : hint)];
    if (saved) { nodes.push(check(id + '-clear', name + '_clear', t('xfr_secret_remove', {what: label.toLowerCase()}), false)); }
    return el('div', {class: 'fp-xfr-secret', 'data-fp-secret': name}, nodes);
  }
  function formCard() {
    var f = X.form;
    var s = f.id ? find(f.id) : null;
    var form = el('form', {class: 'fp-form fp-mail-form fp-xfr-form', novalidate: '', 'data-fp-form': 'source'}, [M.errorLine(), M.statusLine()]);
    form.appendChild(text('fp-xfr-name', 'name', t('xfr_name'), s ? s.name : '', t('xfr_name_hint'), {maxlength: String(MAX_NAME)}));
    if (s) {
      form.appendChild(el('p', {class: 'fp-xfr-fixed', text: t('xfr_kind_fixed', {kind: t('xfr_kind_' + s.kind)})}));
      form.appendChild(el('input', {type: 'hidden', name: 'kind', value: s.kind}));
    } else {
      var kind = el('select', {class: 'sig-select', id: 'fp-xfr-kind', name: 'kind'}, KINDS.map(function (k) {
        return el('option', {value: k, text: t('xfr_kind_' + k), selected: k === f.kind ? true : null});
      }));
      kind.addEventListener('change', function () {
        f.kind = kind.value;
        form.querySelector('[data-fp-xfr-dirhint]').textContent = t('xfr_dir_hint_' + kind.value);
        /* only another panel's server has anything to pack */
        var row = form.querySelector('[data-fp-xfr-packrow]');
        row.hidden = kind.value !== 'other_panel';
        if (row.hidden) { form.querySelector('[name="pack"]').checked = false; }
        /* and only a freePanel server has a hand-off command */
        var hrow = form.querySelector('[data-fp-xfr-handoffrow]');
        hrow.hidden = kind.value !== 'freepanel';
        if (hrow.hidden) { form.querySelector('[name="handoff"]').checked = false; }
      });
      form.appendChild(M.field('fp-xfr-kind', t('xfr_type'), kind, null));
    }
    form.appendChild(text('fp-xfr-host', 'host', t('xfr_host'), s ? s.host : '', t('xfr_host_hint'), {maxlength: '253'}));
    form.appendChild(M.field('fp-xfr-port', t('xfr_port'), el('input', {class: 'sig-input fp-xfr-port', id: 'fp-xfr-port', name: 'port', type: 'number', inputmode: 'numeric',
      min: '1', max: '65535', step: '1', value: String(s ? s.port : 22)}), null));
    form.appendChild(text('fp-xfr-user', 'user', t('xfr_user'), s ? s.user : '', t('xfr_user_hint'), {maxlength: '64'}));
    var dir = text('fp-xfr-dir', 'dir', t('xfr_dir'), s ? s.dir : '', t('xfr_dir_hint_' + (s ? s.kind : f.kind)), {maxlength: '255'});
    dir.querySelector('.sig-hint').setAttribute('data-fp-xfr-dirhint', '');
    form.appendChild(dir);
    form.appendChild(el('div', {class: 'fp-xfr-hostkey'}, [
      M.field('fp-xfr-hostkey', t('xfr_hostkey'), el('input', {class: 'sig-input sig-mono', id: 'fp-xfr-hostkey', name: 'host_key', type: 'text', autocomplete: 'off', spellcheck: 'false',
        autocapitalize: 'none', maxlength: '2048', value: s ? s.host_key : ''}), t('xfr_hostkey_hint')),
      el('p', {class: 'sig-mono fp-xfr-fp', 'data-fp-xfr-fp': '', hidden: s && s.fingerprint ? null : true, text: s && s.fingerprint ? t('xfr_fingerprint', {fingerprint: s.fingerprint}) : ''}),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'probe', text: t('xfr_probe')})]),
      el('div', {class: 'fp-xfr-probe', 'data-fp-xfr-probe': '', role: 'status'})]));
    var pack = check('fp-xfr-pack', 'pack', t('xfr_pack'), Boolean(s && s.pack), t('xfr_pack_hint'));
    pack.setAttribute('data-fp-xfr-packrow', '');
    pack.hidden = (s ? s.kind : f.kind) !== 'other_panel';
    form.appendChild(pack);
    var handoff = check('fp-xfr-handoff', 'handoff', t('xho_tick'), Boolean(s && s.handoff), t('xho_tick_hint'));
    handoff.setAttribute('data-fp-xfr-handoffrow', '');
    handoff.hidden = (s ? s.kind : f.kind) !== 'freepanel';
    form.appendChild(handoff);
    form.appendChild(el('h3', {class: 'fp-h3', text: t('xfr_signin')}));
    form.appendChild(el('p', {class: 'fp-muted', text: t(s ? 'xfr_signin_desc_edit' : 'xfr_signin_desc')}));
    form.appendChild(secret('fp-xfr-password', 'password', t('xfr_password'), s && s.password_set, null, false));
    form.appendChild(secret('fp-xfr-key', 'private_key', t('xfr_private_key'), s && s.private_key_set && !s.public_key, t('xfr_private_key_hint'), true));
    form.appendChild(secret('fp-xfr-passphrase', 'passphrase', t('xfr_passphrase'), s && s.passphrase_set, t('xfr_passphrase_hint'), false));
    form.appendChild(check('fp-xfr-genkey', 'generate_key', t(s && s.public_key ? 'xfr_genkey_again' : 'xfr_genkey'), false, t('xfr_genkey_hint')));
    form.appendChild(el('div', {class: 'fp-actions'}, [
      el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t(s ? 'xfr_save' : 'xfr_create')}),
      el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'form-test', text: t('xfr_test_form')}),
      el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'form-close', text: t('cancel')})]));
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      submit(form, s);
    });
    form.addEventListener('input', function (e) {
      if (e.target && e.target.name === 'host_key') {
        var fp = form.querySelector('[data-fp-xfr-fp]');
        fp.hidden = true;
        fp.textContent = '';
      }
    });
    return M.card('fp-xfr-form-h', s ? t('xfr_edit_title', {name: s.name}) : t('xfr_add_title'), [form], 'fp-xfr-formcard');
  }
  /* the form's values as the server takes them. A secret that is empty is left out (the saved one stays); a ticked box
     removes the saved one; text replaces it. A key made here replaces any key typed. A number or text that is wrong is
     for the server to say. */
  function read(form, s) {
    var val = function (n) { return form.querySelector('[name="' + n + '"]').value.trim(); };
    var port = val('port');
    var body = {name: val('name'), kind: s ? s.kind : val('kind'), host: val('host'), port: /^[0-9]{1,5}$/.test(port) ? parseInt(port, 10) : (port ? -1 : 22),
      user: val('user'), dir: val('dir'), host_key: val('host_key')};
    var secretOf = function (n) {
      var box = form.querySelector('[name="' + n + '_clear"]');
      var v = form.querySelector('[name="' + n + '"]').value;
      if (box && box.checked) { return ''; }
      return v ? v : undefined;
    };
    /* packing is sent when it is on, or when it was on and is now off; left out, the server keeps what it has */
    var ticked = body.kind === 'other_panel' && form.querySelector('[name="pack"]').checked;
    if (ticked || (s && s.pack)) { body.pack = ticked; }
    /* the hand-off tick the same way: sent when on, or when it was on and is now off */
    var handed = body.kind === 'freepanel' && form.querySelector('[name="handoff"]').checked;
    if (handed || (s && s.handoff)) { body.handoff = handed; }
    var made = form.querySelector('[name="generate_key"]').checked;
    body.password = secretOf('password');
    body.passphrase = secretOf('passphrase');
    if (made) { body.generate_key = true; } else { body.private_key = secretOf('private_key'); }
    return body;
  }
  function submit(form, s) {
    var b = M.start(form);
    if (!b) { return; }
    var body = read(form, s);
    var mine = X;
    UI.setBusy(b, true);
    FP.call(s ? 'put' : 'post', s ? 'transferSource' : 'transferSources', body, s ? {id: String(s.id)} : undefined).then(function (r) {
      if (X !== mine) { return; }
      var saved = cleanSource(r);
      if (saved) {
        X.sources = s ? X.sources.map(function (x) { return x.id === saved.id ? saved : x; }) : X.sources.concat([saved]);
      }
      X.form = null;
      drawAll();
      M.say(X.page.querySelector('.fp-xfr-list'), t(saved && saved.public_key && body.generate_key ? 'xfr_saved_key' : (s ? 'xfr_saved' : 'xfr_created'), {name: saved ? saved.name : body.name}));
      var again = saved ? rowButton(saved.id, 'edit') : null;
      (again || X.page.querySelector('#fp-xfr-list-h')).focus();
    }, function (err) {
      if (X !== mine) { return; }
      UI.setBusy(b, false);
      M.failed(form, err);
    });
  }
  function testForm(form, button) {
    var s = X.form.id ? find(X.form.id) : null;
    if (!M.start(form)) { return; }
    var body = read(form, s);
    if (s) { body.id = s.id; }
    var mine = X;
    UI.setBusy(button, true);
    FP.call('post', 'transferSourcesTest', body).then(function (r) {
      if (X !== mine) { return; }
      UI.setBusy(button, false);
      if (r && r.ok === true) { M.say(form, t('xfr_form_test_ok', {n: count(r.accounts)})); } else {
        UI.showError(form, t('xfr_form_test_failed', {error: clip(r && r.error, 600) || t('api_failed')}));
      }
      button.focus();
    }, function (err) {
      if (X !== mine) { return; }
      UI.setBusy(button, false);
      M.failed(form, err);
      if (!form.contains(document.activeElement)) { button.focus(); }
    });
  }
  function probe(form, button) {
    var box = form.querySelector('[data-fp-xfr-probe]');
    box.textContent = '';
    UI.showError(form, '');
    var body = {host: form.querySelector('[name="host"]').value.trim()};
    var port = form.querySelector('[name="port"]').value.trim();
    if (/^[0-9]{1,5}$/.test(port)) { body.port = parseInt(port, 10); }
    var mine = X;
    UI.setBusy(button, true);
    FP.call('post', 'transferSourcesProbe', body).then(function (r) {
      if (X !== mine) { return; }
      UI.setBusy(button, false);
      var key = r && r.key && typeof r.key === 'object' ? {type: clip(r.key.type, 40), fingerprint: clip(r.key.fingerprint, 100), line: clip(r.key.line, 2048)} : null;
      if (!key || !key.fingerprint || !key.line) {
        box.appendChild(el('p', {class: 'fp-bk-bad', text: t('xfr_probe_failed', {error: clip(r && r.error, 600) || t('api_failed')})}));
        button.focus();
        return;
      }
      var use = el('button', {class: 'sig-btn sig-btn--primary sig-btn--sm', type: 'button', 'data-fp-act': 'use-key', text: t('xfr_use_key')});
      use.addEventListener('click', function () {
        form.querySelector('[name="host_key"]').value = key.line;
        var fp = form.querySelector('[data-fp-xfr-fp]');
        fp.hidden = false;
        fp.textContent = t('xfr_fingerprint', {fingerprint: key.fingerprint});
        box.textContent = '';
        box.appendChild(el('p', {text: t('xfr_key_used')}));
        form.querySelector('[name="host_key"]').focus();
      });
      box.appendChild(el('p', {text: t('xfr_probe_found', {type: key.type, fingerprint: key.fingerprint})}));
      box.appendChild(el('p', {class: 'fp-muted', text: t('xfr_probe_compare')}));
      box.appendChild(use);
    }, function (err) {
      if (X !== mine) { return; }
      UI.setBusy(button, false);
      M.failed(form, err);
      if (!form.contains(document.activeElement)) { button.focus(); }
    });
  }

  /* ---------- choosing accounts ---------- */
  function resetMove(source) {
    X.move = {source: source, loading: false, list: null, checked: {}, files: {}, archives: {}, pkg: X.move ? X.move.pkg : ''};
  }
  function movedSource() { return find(X.move.source); }
  function pickedCount() {
    return X.move.list ? X.move.list.accounts.filter(function (a) { return X.move.checked[a.username]; }).length : 0;
  }
  function moveButtonText() {
    var n = pickedCount();
    return n ? t('xfr_move_n', {n: n}) : t('xfr_move');
  }
  function archiveCell(a, s) {
    if (s.kind === 'other_panel') {
      return [a.file ? el('span', {text: a.file}) : null, a.bytes !== null || a.modified ? el('span', {class: 'fp-muted fp-xfr-meta', text: [a.bytes !== null ? size(a.bytes) : '', when(a.modified)].filter(Boolean).join(', ')}) : null];
    }
    var list = X.move.archives[a.username];
    if (list) {
      var cur = X.move.files[a.username] || '';
      var sel = el('select', {class: 'sig-select', name: 'file-' + a.username, 'aria-label': t('xfr_archive_of', {name: a.username}), 'data-fp-file': a.username}, [
        el('option', {value: '', text: t('xfr_newest'), selected: cur === '' ? true : null})].concat(list.map(function (x) {
        return el('option', {value: x.file, selected: x.file === cur ? true : null,
          text: x.file + ' (' + [x.bytes !== null ? size(x.bytes) : '', when(x.modified)].filter(Boolean).join(', ') + ')'});
      })));
      sel.addEventListener('change', function () { X.move.files[a.username] = sel.value; });
      return [sel];
    }
    return [el('span', {text: t('xfr_newest')}), el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'archives',
      'aria-label': t('xfr_other_of', {name: a.username}), text: t('xfr_other')})];
  }
  function accountsTable(s) {
    var l = X.move.list;
    var rows = l.accounts.map(function (a) {
      var id = 'fp-xfr-pick-' + a.username;
      var cb = el('input', {type: 'checkbox', id: id, name: 'account', value: a.username, checked: X.move.checked[a.username] === true, disabled: a.conflict ? true : null,
        'aria-describedby': a.conflict ? id + '-why' : null});
      cb.addEventListener('change', function () {
        X.move.checked[a.username] = cb.checked;
        var b = X.page.querySelector('.fp-xfr-move .fp-submit');
        if (b) { b.textContent = moveButtonText(); }
      });
      return el('tr', {'data-fp-account': a.username}, [
        el('td', null, [el('label', {class: 'fp-check', for: id}, [cb, el('span', {class: 'sig-vh', text: t('xfr_pick_of', {name: a.username})})])]),
        el('th', {scope: 'row', class: 'fp-mail-name'}, [el('span', {text: a.username}), a.conflict ? el('p', {class: 'fp-bk-bad', id: id + '-why', text: a.conflict}) : null]),
        el('td', {class: 'fp-xfr-archive'}, archiveCell(a, s))]);
    });
    return el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-xfr-move-h'}, [
      el('table', {class: 'sig-table fp-mail-table fp-bk-table'}, [el('thead', null, [el('tr', null, [
        el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('xfr_pick')})]), el('th', {scope: 'col', text: t('xfr_account')}),
        el('th', {scope: 'col', text: t('xfr_archive')})])]), el('tbody', null, rows)])]);
  }
  function moveCard() {
    var parts = [M.errorLine(), M.statusLine()];
    if (!X.allowed) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-xfr-moveoff': '', text: t('xfr_move_off')}));
      return M.card('fp-xfr-move-h', t('xfr_move_title'), parts, 'fp-xfr-move');
    }
    if (!X.sources.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-xfr-movenone': '', text: t('xfr_move_none')}));
      return M.card('fp-xfr-move-h', t('xfr_move_title'), parts, 'fp-xfr-move');
    }
    parts.push(el('p', {class: 'fp-muted', text: t('xfr_move_desc')}));
    var pick = el('select', {class: 'sig-select', id: 'fp-xfr-source', name: 'source'}, [el('option', {value: '0', text: t('xfr_choose_source'), selected: X.move.source ? null : true})].concat(
      X.sources.map(function (s) { return el('option', {value: String(s.id), text: s.name, selected: s.id === X.move.source ? true : null}); })));
    pick.addEventListener('change', function () {
      resetMove(parseInt(pick.value, 10));
      drawMove();
    });
    parts.push(M.field('fp-xfr-source', t('xfr_source'), pick, null));
    var s = movedSource();
    parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'list', disabled: s ? null : true,
      text: t(X.move.list ? 'xfr_list_again' : 'xfr_list')})]));
    if (X.move.loading) { parts.push(el('p', {class: 'fp-muted', 'data-fp-xfr-loading': '', text: t('loading')})); }
    var l = X.move.list;
    if (s && l) {
      if (l.error) {
        parts.push(el('p', {class: 'fp-bk-bad', 'data-fp-xfr-listerror': '', text: t('xfr_list_failed', {error: l.error})}));
      } else if (!l.accounts.length) {
        parts.push(el('p', {class: 'fp-muted', 'data-fp-xfr-found': '', text: t(s.kind === 'freepanel' ? 'xfr_found_none_fp' : 'xfr_found_none')}));
        if (l.skipped) { parts.push(el('p', {class: 'fp-muted', text: t('xfr_skipped', {n: l.skipped})})); }
      } else {
        var form = el('form', {class: 'fp-form fp-mail-form fp-xfr-moveform', novalidate: '', 'data-fp-form': 'move'}, [M.errorLine(), M.statusLine()]);
        form.appendChild(el('p', {'data-fp-xfr-found': '', text: t('xfr_found', {n: l.accounts.length})}));
        if (l.truncated) { form.appendChild(el('p', {class: 'fp-muted', text: t('xfr_truncated')})); }
        if (l.skipped) { form.appendChild(el('p', {class: 'fp-muted', text: t('xfr_skipped', {n: l.skipped})})); }
        form.appendChild(accountsTable(s));
        var pkg = el('select', {class: 'sig-select', id: 'fp-xfr-package', name: 'package'}, [el('option', {value: '', text: t('xfr_choose_package'), selected: X.move.pkg ? null : true})].concat(
          X.packages.map(function (p) { return el('option', {value: p, text: p, selected: p === X.move.pkg ? true : null}); })));
        pkg.addEventListener('change', function () { X.move.pkg = pkg.value; });
        form.appendChild(M.field('fp-xfr-package', t('xfr_package'), pkg, t(X.packages.length ? 'xfr_package_hint' : 'xfr_package_none')));
        form.appendChild(el('p', {class: 'sig-hint', text: t('xfr_move_limit', {max: X.maxAccounts})}));
        var go = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', disabled: running() ? true : null,
          'aria-describedby': running() ? 'fp-xfr-busy' : null, text: moveButtonText()});
        form.appendChild(el('div', {class: 'fp-actions'}, [go, running() ? el('span', {class: 'sig-hint', id: 'fp-xfr-busy', text: t('xfr_move_busy')}) : null]));
        form.addEventListener('submit', function (e) {
          e.preventDefault();
          start(form, s);
        });
        parts.push(form);
      }
    }
    return M.card('fp-xfr-move-h', t('xfr_move_title'), parts, 'fp-xfr-move');
  }
  function drawMove() {
    var old = X.page.querySelector('.fp-xfr-move');
    var fresh = moveCard();
    var active = document.activeElement;
    var key = old && active && old.contains(active) ? {id: active.id, act: active.getAttribute('data-fp-act'), row: (active.closest('[data-fp-account]') || {getAttribute: function () { return ''; }}).getAttribute('data-fp-account')} : null;
    if (old) { old.replaceWith(fresh); } else { X.page.appendChild(fresh); }
    if (key) {
      var again = key.id ? fresh.querySelector('#' + window.CSS.escape(key.id)) :
        key.row && key.act ? fresh.querySelector('[data-fp-account="' + key.row + '"] [data-fp-act="' + key.act + '"]') :
          key.act ? fresh.querySelector('[data-fp-act="' + key.act + '"]') : null;
      (again || fresh.querySelector('#fp-xfr-move-h')).focus();
    }
  }
  function loadAccounts() {
    var s = movedSource();
    if (!s) { return; }
    var card = X.page.querySelector('.fp-xfr-move');
    UI.showError(card, '');
    M.say(card, '');
    X.move.loading = true;
    X.move.list = null;
    drawMove();
    var mine = X;
    var move = X.move;
    FP.call('get', 'transferAccounts', undefined, {id: String(s.id)}).then(function (r) {
      if (X !== mine || X.move !== move) { return; }
      move.loading = false;
      move.list = cleanAccounts(r);
      move.checked = {};
      move.files = {};
      move.archives = {};
      drawMove();
      (X.page.querySelector('.fp-xfr-move [data-fp-act="list"]') || X.page.querySelector('#fp-xfr-move-h')).focus();
    }, function (err) {
      if (X !== mine || X.move !== move) { return; }
      move.loading = false;
      drawMove();
      UI.showError(X.page.querySelector('.fp-xfr-move'), err.message);
      (X.page.querySelector('.fp-xfr-move [data-fp-act="list"]') || X.page.querySelector('#fp-xfr-move-h')).focus();
    });
  }
  function loadArchives(user, button) {
    var s = movedSource();
    if (!s) { return; }
    var card = X.page.querySelector('.fp-xfr-move');
    UI.showError(card, '');
    UI.setBusy(button, true);
    var mine = X;
    var move = X.move;
    FP.call('get', 'transferArchives', undefined, {id: String(s.id), account: user}).then(function (r) {
      if (X !== mine || X.move !== move) { return; }
      var list = cleanAccounts(r);
      if (list.error) {
        UI.setBusy(button, false);
        UI.showError(card, t('xfr_list_failed', {error: list.error}));
        button.focus();
        return;
      }
      move.archives[user] = list.accounts.filter(function (a) { return a.username === user && a.file; });
      drawMove();
      var sel = X.page.querySelector('[data-fp-file="' + user + '"]');
      if (sel) { sel.focus(); }
    }, function (err) {
      if (X !== mine || X.move !== move) { return; }
      UI.setBusy(button, false);
      UI.showError(card, err.message);
      button.focus();
    });
  }
  function start(form, s) {
    var b = M.start(form);
    if (!b) { return; }
    var picks = X.move.list.accounts.filter(function (a) { return X.move.checked[a.username] && !a.conflict; }).map(function (a) {
      var o = {username: a.username};
      if (s.kind === 'freepanel' && X.move.files[a.username]) { o.file = X.move.files[a.username]; }
      return o;
    });
    if (!picks.length) { M.fieldError(form, form.querySelector('input[name="account"]:not(:disabled)'), t('xfr_pick_some')); return; }
    if (picks.length > X.maxAccounts) { M.fieldError(form, null, t('xfr_pick_many', {max: X.maxAccounts})); return; }
    if (!X.move.pkg) { M.fieldError(form, form.querySelector('[name="package"]'), t('xfr_package_pick')); return; }
    var mine = X;
    UI.setBusy(b, true);
    FP.call('post', 'transferRuns', {source_id: s.id, accounts: picks, package: X.move.pkg}).then(function (r) {
      if (X !== mine) { return; }
      var run = cleanRun(r && r.run);
      if (run) { X.run = run; }
      X.move.checked = {};
      drawMove();
      drawRun();
      X.page.querySelector('#fp-xfr-run-h').focus();
      M.say(X.page.querySelector('.fp-xfr-run'), t('xfr_started'));
      poll();
    }, function (err) {
      if (X !== mine) { return; }
      UI.setBusy(b, false);
      M.failed(form, err);
    });
  }

  /* ---------- the run ---------- */
  function itemState(i) {
    if (i.state === 'done' && i.partial) { return t('xfr_state_partial'); }
    return t('xfr_state_' + i.state);
  }
  function itemDetail(i) {
    var out = [];
    if (i.state === 'pulling' && i.total) {
      out.push(el('p', {'data-fp-xfr-progress': '', text: t('xfr_progress', {done: size(i.bytes), total: size(i.total), percent: Math.min(100, Math.floor(i.bytes * 100 / i.total))})}));
    } else if (i.state === 'pulling') {
      out.push(el('p', {'data-fp-xfr-progress': '', text: t('xfr_progress_unknown', {done: size(i.bytes)})}));
    }
    if (i.state === 'packing') { out.push(el('p', {'data-fp-xfr-packing': '', text: t('xfr_packing_wait')})); }
    if (i.error) { out.push(el('p', {class: 'fp-bk-bad', 'data-fp-xfr-error': '', text: i.error})); }
    if (i.notes.length) { out.push(el('ul', {class: 'fp-xfr-notes'}, i.notes.map(function (n) { return el('li', {text: n}); }))); }
    return out;
  }
  function tally(run) {
    var n = {done: 0, failed: 0, skipped: 0};
    run.items.forEach(function (i) { if (n[i.state] !== undefined) { n[i.state]++; } });
    return n;
  }
  function runCard() {
    var run = X.run;
    var parts = [M.errorLine(), M.statusLine()];
    if (!run) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-xfr-run': '', text: t('xfr_run_none')}));
      return M.card('fp-xfr-run-h', t('xfr_run_title'), parts, 'fp-xfr-run');
    }
    var n = tally(run);
    var acts = el('div', {class: 'fp-actions'});
    if (!run.ended) {
      parts.push(el('p', {'data-fp-xfr-run': '', text: t('xfr_running', {source: run.source, done: n.done, total: run.items.length, failed: n.failed})}));
      if (run.stopping) {
        parts.push(el('p', {class: 'fp-muted', 'data-fp-xfr-stopping': '', text: t('xfr_stopping')}));
      } else {
        acts.appendChild(el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'stop', text: t('xfr_stop')}));
      }
    } else {
      parts.push(el('p', {'data-fp-xfr-run': '', class: n.failed || run.aborted ? 'fp-bk-bad' : '', text: t('xfr_ended', {source: run.source, when: when(run.ended) || run.ended,
        done: n.done, total: run.items.length, failed: n.failed})}));
      if (run.stopped) { parts.push(el('p', {class: 'fp-muted', text: t('xfr_ended_stopped')})); }
      if (run.aborted) { parts.push(el('p', {class: 'fp-bk-bad', text: t('xfr_ended_aborted', {why: run.aborted})})); }
    }
    parts.push(acts);
    parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-xfr-run-h'}, [
      el('table', {class: 'sig-table fp-mail-table fp-bk-table'}, [el('thead', null, [el('tr', null, [
        el('th', {scope: 'col', text: t('xfr_account')}), el('th', {scope: 'col', text: t('xfr_state')}), el('th', {scope: 'col', text: t('xfr_details')})])]),
      el('tbody', null, run.items.map(function (i) {
        return el('tr', {'data-fp-item': i.username, 'data-fp-state': i.state}, [el('th', {scope: 'row', class: 'fp-mail-name', text: i.username}),
          el('td', {class: i.state === 'failed' ? 'fp-bk-bad' : '', text: itemState(i)}), el('td', {class: 'fp-xfr-detail'}, itemDetail(i))]);
      }))])]));
    return M.card('fp-xfr-run-h', t('xfr_run_title'), parts, 'fp-xfr-run');
  }
  function drawRun() {
    var old = X.page.querySelector('.fp-xfr-run');
    var fresh = runCard();
    var active = document.activeElement;
    var act = old && active && old.contains(active) ? active.getAttribute('data-fp-act') : null;
    var said = old ? (old.querySelector('[data-fp-status]') || {}).textContent : '';
    if (old) { old.replaceWith(fresh); } else { X.page.appendChild(fresh); }
    M.say(fresh, said);
    if (act) { (fresh.querySelector('[data-fp-act="' + act + '"]') || fresh.querySelector('#fp-xfr-run-h')).focus(); }
  }
  /* while a run goes, asks how it is every few seconds; when it ends, says so and shows how it ended */
  function poll() {
    window.clearTimeout(X.timer);
    var mine = X;
    X.timer = window.setTimeout(function () {
      if (X !== mine || !document.body.contains(mine.page)) { return; }
      FP.call('get', 'transfers').then(function (r) {
        if (X !== mine) { return; }
        var was = mine.run && !mine.run.ended;
        var all = cleanAll(r);
        mine.run = all.run;
        mine.allowed = all.allowed;
        drawRun();
        if (running()) { poll(); return; }
        if (was) {
          M.say(mine.page.querySelector('.fp-xfr-run'), t('xfr_run_over'));
          drawMove();
        }
      }, function () { if (X === mine) { poll(); } });
    }, POLL_MS);
  }
  function stop(button) {
    var card = X.page.querySelector('.fp-xfr-run');
    UI.showError(card, '');
    M.say(card, '');
    UI.setBusy(button, true);
    var mine = X;
    FP.call('del', 'transferRuns').then(function (r) {
      if (X !== mine) { return; }
      var run = cleanRun(r && r.run);
      if (run) { X.run = run; }
      drawRun();
      X.page.querySelector('#fp-xfr-run-h').focus();
      M.say(X.page.querySelector('.fp-xfr-run'), t('xfr_stop_asked'));
      poll();
    }, function (err) {
      if (X !== mine) { return; }
      UI.setBusy(button, false);
      UI.showError(card, err.message);
      button.focus();
    });
  }

  /* ---------- page ---------- */
  /* every card drawn again except the run; the form stays as it is (what was typed in it too) unless a new one is asked for */
  function drawAll(freshForm) {
    var active = document.activeElement;
    var key = null;
    if (active && X.page.contains(active)) {
      var row = active.closest('[data-fp-source]');
      key = {id: active.id, act: active.getAttribute('data-fp-act'), row: row ? row.getAttribute('data-fp-source') : ''};
    }
    var keepForm = X.form && !freshForm ? X.page.querySelector('.fp-xfr-formcard') : null;
    var said = ['.fp-xfr-switch', '.fp-xfr-list'].map(function (c) {
      var n = X.page.querySelector(c + ' [data-fp-status]');
      return n ? n.textContent : '';
    });
    var runCardNode = X.page.querySelector('.fp-xfr-run');
    X.page.textContent = '';
    X.page.appendChild(switchCard());
    X.page.appendChild(sourcesCard());
    if (X.form) { X.page.appendChild(keepForm || formCard()); }
    X.page.appendChild(moveCard());
    X.page.appendChild(runCardNode || runCard());
    if (X.handoff) {
      X.handoff.refresh();
      X.page.appendChild(X.handoff.node);
    }
    M.say(X.page.querySelector('.fp-xfr-switch'), said[0]);
    M.say(X.page.querySelector('.fp-xfr-list'), said[1]);
    if (key) {
      var again = key.id ? X.page.querySelector('#' + window.CSS.escape(key.id)) :
        key.row && key.act ? rowButton(key.row, key.act) : (key.act ? X.page.querySelector('[data-fp-act="' + key.act + '"]') : null);
      if (again) { again.focus(); }
    }
  }
  function openForm(id) {
    X.form = {id: id, kind: 'other_panel'};
    X.back = id;
    drawAll(true);
    var h = X.page.querySelector('#fp-xfr-form-h');
    h.focus();
    if (h.scrollIntoView) { h.scrollIntoView({block: 'start'}); }
  }
  function onClick(e) {
    var target = e.target && e.target.closest ? e.target : null;
    var b = target && X && X.page && X.page.contains(target) ? target.closest('[data-fp-act]') : null;
    if (!b) { return; }
    var act = b.getAttribute('data-fp-act');
    var row = b.closest('[data-fp-source]');
    var id = row ? parseInt(row.getAttribute('data-fp-source'), 10) : 0;
    if (act === 'switch-on') {
      askSwitch();
    } else if (act === 'switch-off') {
      setSwitch(false, b);
    } else if (act === 'switch-yes') {
      setSwitch(true, b);
    } else if (act === 'switch-no') {
      drawAll();
      X.page.querySelector('[data-fp-act="switch-on"]').focus();
    } else if (act === 'add') {
      openForm(0);
    } else if (act === 'edit') {
      openForm(id);
    } else if (act === 'test') {
      testSaved(id, b);
    } else if (act === 'choose') {
      resetMove(id);
      drawMove();
      var pick = X.page.querySelector('#fp-xfr-source');
      if (pick) {
        pick.focus();
        if (pick.scrollIntoView) { pick.scrollIntoView({block: 'center'}); }
      }
    } else if (act === 'delete') {
      askDelete(row);
    } else if (act === 'delete-no') {
      drawAll();
      (rowButton(id, 'delete') || X.page.querySelector('#fp-xfr-list-h')).focus();
    } else if (act === 'delete-yes') {
      remove(id, b);
    } else if (act === 'form-close') {
      X.form = null;
      drawAll();
      var back = X.back ? rowButton(X.back, 'edit') : null;
      (back || X.page.querySelector('[data-fp-act="add"]')).focus();
    } else if (act === 'form-test') {
      testForm(b.closest('form'), b);
    } else if (act === 'probe') {
      probe(b.closest('form'), b);
    } else if (act === 'list') {
      loadAccounts();
    } else if (act === 'archives') {
      loadArchives(b.closest('[data-fp-account]').getAttribute('data-fp-account'), b);
    } else if (act === 'stop') {
      stop(b);
    }
  }
  document.addEventListener('click', onClick);

  FP.view('tool:transfer_in', function () {
    var tool = FP.tools.transfer_in;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('xfr_desc'), cls: 'fp-mail fp-bk fp-xfr',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    if (X) { window.clearTimeout(X.timer); }
    X = {page: body, allowed: false, max: 10, maxAccounts: 50, sources: [], run: null, packages: [], form: null, back: 0, move: null, timer: 0, handoff: null};
    resetMove(0);
    var mine = X;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all([FP.call('get', 'transfers'), FP.call('get', 'packages').then(function (r) {
      return (r && Array.isArray(r.packages) ? r.packages : []).map(function (p) { return p && str(p.name); }).filter(function (n) { return n && n.length <= 64; }).sort();
    }, function () { return []; })]).then(function (r) {
      if (X !== mine) { return; }
      take(cleanAll(r[0]));
      mine.packages = r[1];
      /* the hand-off card (fp-handoff.js) asks the page for the servers it may use and the accounts of the last move */
      mine.handoff = FP.handoff ? FP.handoff.card({
        allowed: function () { return mine.allowed; },
        any: function () { return mine.sources.some(function (s) { return s.kind === 'freepanel'; }); },
        sources: function () { return mine.sources.filter(function (s) { return s.kind === 'freepanel' && s.handoff; }).map(function (s) { return {id: s.id, name: s.name}; }); },
        accounts: function (id) {
          var s = find(id);
          return s && mine.run && mine.run.source === s.name ? mine.run.items.filter(function (i) { return i.state === 'done'; }).map(function (i) { return i.username; }) : [];
        }
      }) : null;
      body.textContent = '';
      drawAll();
      if (running()) { poll(); }
    }, function (err) {
      if (X !== mine) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

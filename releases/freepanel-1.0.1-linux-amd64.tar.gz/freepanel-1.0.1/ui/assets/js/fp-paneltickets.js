/* freePanel Tickets (#/tool/billing_panel_tickets, docs/api.md, "Billing: the hosting panel"): the support tickets of the billing customer this hosting
   account is linked to, read and answered from the account's own panel, and a new ticket to the host's own desk. A ticket opened here carries where it
   was opened from as fields beside it, never in the message: the account (the server sets it), one of the account's domains and the panel page, each
   shown on the form before it is sent and each one the customer may leave out. "Open a ticket" in the account menu, on the not-found page and on a
   page whose read failed opens the form with the page it came from. A support session reads the tickets and writes nothing. Everything the server sends is shown as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;
  var M = FP.mail;

  var TOOL = 'billing_panel_tickets';
  var PAGE_RE = /^(home|not-found|two-factor|group:[a-z0-9_]{1,40}|tool:[a-z0-9_]{1,40})$/;
  var STATUS = {open: 'warn', customer_reply: 'warn', answered: 'ok', on_hold: '', closed: ''};
  var S = {page: null, data: null, open: null, from: '', ask: false, busy: false};

  /* the page the panel is on, as a ticket's context names it */
  function here() {
    var r = FP.current || {};
    var key = r.view === 'tool' ? 'tool:' + r.id : r.view === 'group' ? 'group:' + r.id : r.view || 'home';
    return PAGE_RE.test(key) ? key : '';
  }
  function pageName(key) {
    var m = /^(tool|group):(.+)$/.exec(key || '');
    if (m && m[1] === 'tool' && FP.tools[m[2]]) { return FP.tools[m[2]].label; }
    if (m && m[1] === 'group' && FP.group(m[2])) { return FP.group(m[2]).label; }
    return key === 'home' ? t('menu_home') : key === 'not-found' ? t('not_found') : key;
  }
  /* opens the new-ticket form, noting the page it was asked from */
  function openFrom(key) {
    S.from = key || '';
    S.ask = true;
    if (window.location.hash === '#/tool/' + TOOL) { FP.route(true); } else { window.location.hash = '#/tool/' + TOOL; }
  }
  function offered() { return FP.realm === 'user' && Boolean(FP.tools[TOOL]); }
  FP.ticketAction = function (cls) {
    if (!offered()) { return null; }
    return el('button', {class: cls || 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-ticket-open': '', text: t('ptk_open_a')});
  };

  /* ---- the account menu: Open a ticket ---- */
  document.addEventListener('fp:ready', function () {
    var pop = document.getElementById('fp-account-pop');
    if (!offered() || !pop || pop.querySelector('[data-fp-ticket-open]')) { return; }
    var item = el('button', {class: 'sig-pop-item', type: 'button', 'data-fp-ticket-open': ''}, [UI.icon(FP.ui, 'ui_lifebuoy', 'sig-ico--16'), el('span', {text: t('ptk_open_a')})]);
    var out = pop.querySelector('[data-fp-logout]');
    pop.insertBefore(item, out);
  });

  /* ---- what the server sends ---- */
  function cleanTicket(v) {
    if (!v || typeof v !== 'object' || !B.id(v.id)) { return null; }
    var c = v.context && typeof v.context === 'object' ? {account: B.str(v.context.account, 32), domain: B.str(v.context.domain, 253), page: B.str(v.context.page, 60)} : null;
    return {id: v.id, subject: B.str(v.subject, 200), status: Object.prototype.hasOwnProperty.call(STATUS, v.status) ? v.status : '', last: B.str(v.last_reply, 40),
      lastBy: v.last_reply_by === 'staff' ? 'staff' : v.last_reply_by === 'customer' ? 'customer' : '', created: B.str(v.created, 40), context: c,
      messages: (Array.isArray(v.messages) ? v.messages.slice(0, 500) : []).filter(function (x) { return x && B.id(x.id); }).map(function (x) {
        return {id: x.id, staff: x.author_kind === 'staff', name: B.str(x.author_name, 64), body: B.str(x.body, 20000), created: B.str(x.created, 40)};
      })};
  }
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    return {linked: r.linked === true, support: r.support_session === true,
      tickets: (Array.isArray(r.tickets) ? r.tickets.slice(0, 200) : []).map(cleanTicket).filter(Boolean),
      departments: (Array.isArray(r.departments) ? r.departments.slice(0, 100) : []).filter(function (d) { return d && B.id(d.id); }).map(function (d) {
        return {id: d.id, name: B.str(d.name, 100)};
      }),
      domains: (Array.isArray(r.domains) ? r.domains.slice(0, 200) : []).filter(function (d) { return typeof d === 'string' && d.length <= 253; })};
  }
  function statusPill(s) { return s ? B.pill(t('ptk_st_' + s), STATUS[s], {'data-fp-status-of': s}) : B.pill('—', ''); }

  /* ---- the cards ---- */
  function listCard(d) {
    var parts = [M.errorLine(), M.statusLine()];
    if (!d.tickets.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('ptk_none')}));
    } else {
      parts.push(el('ul', {class: 'fp-mkt-list'}, d.tickets.map(function (k) {
        return el('li', {class: 'fp-mkt-item', 'data-fp-ticket': String(k.id)}, [
          el('div', {class: 'fp-mkt-item-text'}, [el('b', {text: k.subject}),
            el('span', {class: 'fp-muted', text: k.last ? t(k.lastBy === 'staff' ? 'ptk_last_staff' : 'ptk_last_you', {when: B.when(k.last)}) : ''})]),
          el('div', {class: 'fp-actions fp-mkt-acts'}, [statusPill(k.status),
            B.button('ptk-show', t('ptk_show'), 'sig-btn--secondary sig-btn--sm', {'data-fp-id': String(k.id), 'aria-label': t('ptk_show_of', {subject: k.subject})})])]);
      })));
    }
    parts.push(el('div', {class: 'fp-actions'}, [B.button('ptk-new', t('ptk_new'), 'sig-btn--primary', {disabled: d.support ? true : null})]));
    return M.card('fp-ptk-list-h', t('ptk_list_title'), parts, 'fp-ptk-list');
  }
  function contextBox(d) {
    var key = PAGE_RE.test(S.from) ? S.from : '';
    var domains = [['', t('ptk_ctx_no_domain')]].concat(d.domains.map(function (x) { return [x, x]; }));
    return el('fieldset', {class: 'fp-ptk-ctx'}, [el('legend', {class: 'sig-label', text: t('ptk_ctx_title')}),
      el('p', {class: 'fp-muted', id: 'fp-ptk-ctx-hint', text: t('ptk_ctx_hint')}),
      B.facts([[t('ptk_ctx_account'), FP.account()]]),
      M.field('fp-ptk-domain', t('ptk_ctx_domain'), B.select('fp-ptk-domain', 'domain', domains, d.domains[0] || '')),
      key ? el('label', {class: 'fp-bil-check'}, [el('input', {type: 'checkbox', name: 'page', value: key, checked: true}),
        el('span', {text: t('ptk_ctx_page', {page: pageName(key)})})]) : null]);
  }
  function newCard(d) {
    if (!d.departments.length) {
      return M.card('fp-ptk-new-h', t('ptk_new_title'), [el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('ptk_no_desk')})], 'fp-ptk-new');
    }
    var form = el('form', {class: 'fp-form fp-ptk-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-ptk-dep', t('ptk_f_dep'), B.select('fp-ptk-dep', 'department_id', d.departments.map(function (x) { return [String(x.id), x.name]; }), String(d.departments[0].id))),
      M.field('fp-ptk-subject', t('ptk_f_subject'), B.input('fp-ptk-subject', 'subject', '', {maxlength: '200'})),
      M.field('fp-ptk-body', t('ptk_f_body'), el('textarea', {class: 'sig-input fp-ptk-text', id: 'fp-ptk-body', name: 'body', rows: '6', maxlength: '20000'})),
      M.field('fp-ptk-prio', t('ptk_f_prio'), B.select('fp-ptk-prio', 'priority', [['low', t('ptk_prio_low')], ['medium', t('ptk_prio_medium')], ['high', t('ptk_prio_high')]], 'medium')),
      contextBox(d),
      el('div', {class: 'fp-actions'}, [B.button('ptk-send', t('ptk_send'), 'sig-btn--primary fp-submit', {type: 'submit'}),
        B.button('ptk-cancel', t('cancel'), 'sig-btn--secondary')])]);
    return M.card('fp-ptk-new-h', t('ptk_new_title'), [form], 'fp-ptk-new');
  }
  function ticketCard(k, d) {
    var parts = [B.back('ptk-back', t('ptk_back')), M.errorLine(), M.statusLine(), el('p', null, [statusPill(k.status)])];
    if (k.context) {
      parts.push(B.facts([[t('ptk_ctx_account'), k.context.account], k.context.domain ? [t('ptk_ctx_domain'), k.context.domain] : null,
        k.context.page ? [t('ptk_ctx_page_label'), pageName(k.context.page)] : null], 'fp-ptk-sent'));
    }
    parts.push(el('ol', {class: 'fp-ptk-msgs'}, k.messages.map(function (x) {
      return el('li', {class: 'fp-ptk-msg' + (x.staff ? ' fp-ptk-msg--staff' : '')}, [
        el('p', {class: 'fp-muted', text: t(x.staff ? 'ptk_by_staff' : 'ptk_by_you', {name: x.name, when: B.when(x.created)})}),
        el('p', {class: 'fp-ptk-body', text: x.body})]);
    })));
    if (!d.support) {
      parts.push(el('form', {class: 'fp-form fp-ptk-reply', novalidate: ''}, [
        M.field('fp-ptk-r', t('ptk_reply_label'), el('textarea', {class: 'sig-input fp-ptk-text', id: 'fp-ptk-r', name: 'body', rows: '4', maxlength: '20000'}),
          k.status === 'closed' ? t('ptk_reply_reopens') : ''),
        el('div', {class: 'fp-actions'}, [B.button('ptk-reply', t('ptk_reply'), 'sig-btn--primary fp-submit', {type: 'submit'})])]));
    }
    return M.card('fp-ptk-one-h', k.subject, parts, 'fp-ptk-one');
  }
  function noLinkCard() {
    return M.card('fp-ptk-none-h', t('ptk_nolink_title'), [el('p', {'data-fp-empty': '', text: t('ptk_nolink_text', {account: FP.account()})}),
      el('p', {class: 'fp-muted', text: t('mkt_none_how')})], 'fp-ptk-none');
  }
  function render(focus) {
    var d = S.data;
    S.page.textContent = '';
    if (!d.linked) { S.page.appendChild(noLinkCard()); return; }
    if (d.support) {
      S.page.appendChild(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-ptk-support': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('ptk_support_note')})]));
    }
    if (S.open && typeof S.open === 'object') {
      S.page.appendChild(ticketCard(S.open, d));
    } else {
      if (S.open === 'new' && !d.support) { S.page.appendChild(newCard(d)); }
      S.page.appendChild(listCard(d));
    }
    var h = focus && S.page.querySelector(focus);
    if (h) { h.focus(); }
  }
  function read() {
    return FP.call('get', 'panelTickets', undefined, FP.account()).then(function (r) { S.data = clean(r); });
  }
  function show(id, focus) {
    return FP.call('get', 'panelTicket', undefined, {name: FP.account(), id: String(id)}).then(function (r) {
      S.open = cleanTicket(r);
      render(focus || '#fp-ptk-one-h');
    });
  }

  function send(form) {
    var b = form.querySelector('[data-fp-act="ptk-send"]');
    if (S.busy || !B.begin(form, b)) { return; }
    var f = form.elements;
    if (!f.subject.value.trim()) { M.fieldError(form, f.subject, t('ptk_err_subject')); return; }
    if (!f.body.value.trim()) { M.fieldError(form, f.body, t('ptk_err_body')); return; }
    var page = form.querySelector('input[name="page"]');
    var body = {department_id: Number(f.department_id.value), subject: f.subject.value.trim(), body: f.body.value, priority: f.priority.value,
      domain: f.domain.value, page: page && page.checked ? page.value : ''};
    S.busy = true;
    UI.setBusy(b, true);
    var mine = S.page;
    FP.call('post', 'panelTickets', body, FP.account()).then(function (r) {
      S.busy = false;
      S.from = '';
      if (S.page !== mine) { return null; }
      var k = cleanTicket(r);
      return read().then(function () { return k ? show(k.id) : null; }).then(function () { if (S.page === mine) { M.say(S.page.querySelector('.fp-ptk-one'), t('ptk_sent')); } });
    }, function (err) {
      S.busy = false;
      if (S.page !== mine) { return; }
      UI.setBusy(b, false);
      B.failed(form, err);
    });
  }
  function reply(form) {
    var b = form.querySelector('[data-fp-act="ptk-reply"]');
    var card = S.page.querySelector('.fp-ptk-one');
    if (S.busy || !B.begin(card, b)) { return; }
    if (!form.elements.body.value.trim()) { M.fieldError(card, form.elements.body, t('ptk_err_body')); return; }
    S.busy = true;
    UI.setBusy(b, true);
    var mine = S.page;
    FP.call('post', 'panelTicketReply', {body: form.elements.body.value}, {name: FP.account(), id: String(S.open.id)}).then(function (r) {
      S.busy = false;
      if (S.page !== mine) { return; }
      S.open = cleanTicket(r && r.ticket) || S.open;
      render('#fp-ptk-one-h');
      M.say(S.page.querySelector('.fp-ptk-one'), t('ptk_replied'));
    }, function (err) {
      S.busy = false;
      if (S.page !== mine) { return; }
      UI.setBusy(b, false);
      UI.showError(card, err.message);
    });
  }

  document.addEventListener('submit', function (e) {
    if (!S.page || !S.page.contains(e.target)) { return; }
    e.preventDefault();
    if (e.target.classList.contains('fp-ptk-form')) { send(e.target); } else if (e.target.classList.contains('fp-ptk-reply')) { reply(e.target); }
  });
  document.addEventListener('click', function (e) {
    var node = e.target.closest ? e.target : null;
    var go = node && node.closest('[data-fp-ticket-open]');
    if (go) { openFrom(here()); return; }
    var b = node && node.closest('[data-fp-act]');
    if (!b || !S.page || !S.page.contains(b)) { return; }
    var a = b.getAttribute('data-fp-act');
    if (a === 'ptk-new') { S.open = 'new'; render('#fp-ptk-subject'); } else if (a === 'ptk-cancel') { S.open = null; S.from = ''; render('#fp-ptk-list-h'); } else if (a === 'ptk-show') {
      UI.setBusy(b, true);
      show(b.getAttribute('data-fp-id')).then(null, function (err) {
        UI.setBusy(b, false);
        UI.showError(S.page.querySelector('.fp-ptk-list'), err.message);
      });
    } else if (a === 'ptk-back') {
      var was = S.open && S.open.id;
      S.open = null;
      read().then(function () { render(was ? '[data-fp-ticket="' + was + '"] button' : '#fp-ptk-list-h'); }, function (err) { render(); UI.showError(S.page.querySelector('.fp-ptk-list'), err.message); });
    }
  });

  /* a page whose read failed offers a ticket too: the words of a call that failed on this page are noted, and the card a page shows with
     those words (FP.empty, with no action of its own) gets "Open a ticket", which names the page */
  var failed = {route: null, words: []};
  var call = FP.call;
  FP.call = function () {
    var r = FP.current;
    return call.apply(null, arguments).then(null, function (err) {
      if (err && err.status !== 401 && typeof err.message === 'string' && err.message) {
        if (failed.route !== r) { failed.route = r; failed.words = []; }
        failed.words.push(err.message);
      }
      throw err;
    });
  };
  var empty = FP.empty;
  FP.empty = function (title, text, action) {
    var card = empty(title, text, action);
    var r = FP.current || {};
    if (!action && failed.route === FP.current && failed.words.indexOf(text) >= 0 && !(r.view === 'tool' && r.id === TOOL)) {
      var a = FP.ticketAction();
      if (a) { card.appendChild(el('div', {class: 'fp-actions'}, [a])); }
    }
    return card;
  };

  /* the not-found page offers a ticket too */
  var notFound = FP.views['not-found'];
  FP.view('not-found', function (r) {
    notFound(r);
    var a = FP.ticketAction();
    var row = document.querySelector('#sig-main .sig-frame-body p');
    if (a && row) { row.appendChild(document.createTextNode(' ')); row.appendChild(a); }
  });

  FP.view('tool:' + TOOL, function () {
    var tool = FP.tools[TOOL];
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    S.data = null;
    S.busy = false;
    var opening = S.ask;
    S.ask = false;
    S.open = opening ? 'new' : null;
    if (!opening) { S.from = ''; }
    var body = FP.frame({title: tool.label, desc: t('ptk_desc'), cls: 'fp-mail fp-ptk-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    S.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    read().then(function () {
      if (S.page !== body) { return; }
      render(opening ? '#fp-ptk-subject' : null);
    }, function (err) {
      if (S.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

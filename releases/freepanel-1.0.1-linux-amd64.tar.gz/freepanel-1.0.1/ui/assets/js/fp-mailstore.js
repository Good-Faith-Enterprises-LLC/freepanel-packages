/* freePanel mailbox storage format (#/tool/mail_storage), the admin panel's page for converting mailboxes between Maildir and
   mdbox (docs/api.md, "Mailbox storage format"): an account's mailboxes with their format; a dry run of a conversion (each
   folder's messages and size, the space it needs and the space there is); the conversion, which runs on the server as a job
   and is followed here; the old copies a conversion leaves, kept until removed here or until their days have passed; and the
   last conversions. Where mail is not set up the page says so. Folder names, notes and errors come from Dovecot and are shown
   as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var POLL_MS = 3000;
  var FORMATS = ['maildir', 'mdbox'];
  var BOX_STATES = ['pending', 'copying', 'verifying', 'switching', 'done', 'failed', 'skipped'];
  var JOB_STATES = ['running', 'succeeded', 'failed'];
  var USER_RE = /^[a-z][a-z0-9]{0,15}$/;
  var ADDR_RE = /^[a-z0-9_+.-]{1,64}@[a-z0-9.-]{1,253}$/;
  var UNITS = ['KB', 'MB', 'GB', 'TB'];
  var CARDS = ['fp-mst-status', 'fp-mst-pick', 'fp-mst-plan', 'fp-mst-job', 'fp-mst-kept', 'fp-mst-recent'];
  var S = null;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 400) : ''; }
  function obj(v) { return v && typeof v === 'object' ? v : {}; }
  function num(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.floor(v) : 0; }
  function list(v) { return Array.isArray(v) ? v : []; }
  function fmt(v) { return FORMATS.indexOf(v) >= 0 ? v : ''; }
  function when(iso) {
    var d = typeof iso === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(iso) ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }
  function size(n) {
    if (!n) { return t('size_bytes', {n: '0'}); }
    if (n < 1024) { return t('size_bytes', {n: String(n)}); }
    var u = -1;
    do { n /= 1024; u++; } while (n >= 1024 && u < UNITS.length - 1);
    return (n < 10 ? n.toFixed(1) : Math.round(n).toLocaleString('en')) + ' ' + UNITS[u];
  }

  /* ---------- what the server says, kept to the shapes the page draws ---------- */
  function cleanBox(b) {
    b = obj(b);
    return {address: str(b.address, 320), from: fmt(b.from), to: fmt(b.to), state: BOX_STATES.indexOf(b.state) >= 0 ? b.state : 'pending',
      messages: num(b.messages), vsize: num(b.vsize), copied: num(b.copied), error: str(b.error), note: str(b.note, 600), late: num(b.late)};
  }
  function cleanJob(j) {
    j = obj(j);
    if (JOB_STATES.indexOf(j.state) < 0) { return null; }
    return {id: num(j.id), state: j.state, username: str(j.username, 32), address: str(j.address, 320), to: fmt(j.to), keepDays: num(j.keep_days),
      by: str(j.by, 64), started: str(j.started), ended: str(j.ended), boxes: list(j.mailboxes).slice(0, 10000).map(cleanBox)};
  }
  function cleanKept(k) {
    k = obj(k);
    return {id: num(k.id), username: str(k.username, 32), address: str(k.address, 320), format: fmt(k.format), path: str(k.path, 600), made: str(k.made), until: str(k.until)};
  }
  function cleanStatus(r) {
    r = obj(r);
    return {enabled: r.enabled === true, reason: str(r.reason, 600), job: cleanJob(r.job), recent: list(r.recent).slice(0, 20).map(cleanJob).filter(Boolean),
      kept: list(r.kept).slice(0, 1000).map(cleanKept).filter(function (k) { return k.id > 0; })};
  }
  function cleanPlan(p) {
    p = obj(p);
    /* what the account's disk limit leaves: -1 (or anything not a count) is no limit */
    function room(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.floor(v) : -1; }
    return {username: str(p.username, 32), to: fmt(p.to), messages: num(p.messages), need: num(p.need_bytes), free: num(p.free_bytes), enough: p.enough === true,
      needFiles: num(p.need_files), quotaBytes: room(p.quota_free_bytes), quotaFiles: room(p.quota_free_files), quotaEnough: p.quota_enough === true,
      boxes: list(p.mailboxes).slice(0, 10000).map(function (b) {
        b = obj(b);
        return {address: str(b.address, 320), from: fmt(b.from), skip: str(b.skip), messages: num(b.messages), vsize: num(b.vsize),
          folders: list(b.folders).slice(0, 2000).map(function (f) { f = obj(f); return {name: str(f.name, 200), messages: num(f.messages), vsize: num(f.vsize)}; })};
      })};
  }
  function running() { return Boolean(S.status.job && S.status.job.state === 'running'); }

  /* ---------- the cards ---------- */
  function statusCard() {
    var d = S.status;
    var parts = [M.errorLine(), M.statusLine()];
    if (!d.enabled) {
      parts.push(el('p', {'data-fp-off': '', text: d.reason || t('mst_off')}));
      return M.card('fp-mst-status-h', t('mst_title'), parts, 'fp-mst-status');
    }
    parts.push(el('p', {text: t('mst_about')}));
    parts.push(el('ul', {class: 'fp-mst-formats'}, FORMATS.map(function (f) {
      return el('li', {text: t('mst_fmt_about_' + f)});
    })));
    parts.push(el('p', {class: 'fp-muted sig-hint', text: t('mst_safety')}));
    if (running()) { parts.push(el('p', {class: 'fp-muted', 'data-fp-busy': '', text: t('mst_busy')})); }
    return M.card('fp-mst-status-h', t('mst_title'), parts, 'fp-mst-status');
  }
  function formatSelect(id, value) {
    return el('select', {class: 'sig-input', id: id}, FORMATS.map(function (f) {
      var o = el('option', {value: f, text: t('mst_fmt_' + f)});
      if (f === value) { o.selected = true; }
      return o;
    }));
  }
  function pickCard() {
    if (!S.status.enabled) { return null; }
    var input = el('input', {class: 'sig-input', id: 'fp-mst-user', type: 'text', maxlength: '16', autocomplete: 'off', spellcheck: 'false', value: S.user || ''});
    var parts = [M.errorLine(), M.statusLine(),
      el('form', {class: 'fp-mst-find', 'data-fp-form': 'boxes', novalidate: ''}, [M.field('fp-mst-user', t('mst_user_label'), input, t('mst_user_hint')),
        el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary', type: 'submit', text: t('mst_show')})])])];
    if (S.boxes) {
      if (!S.boxes.length) {
        parts.push(el('p', {'data-fp-boxes': '0', text: t('mst_no_boxes', {user: S.user})}));
      } else {
        parts.push(M.field('fp-mst-to', t('mst_to_label'), formatSelect('fp-mst-to', S.to || 'mdbox'), t('mst_to_hint')));
        var head = el('tr', null, ['mst_col_mailbox', 'mst_col_format', 'mst_col_actions'].map(function (k) { return el('th', {scope: 'col', text: t(k)}); }));
        var rows = S.boxes.map(function (b) {
          var state = b.converting ? el('span', {class: 'sig-pill sig-pill--accent', text: t('mst_converting')}) : (!b.served ? el('span', {class: 'sig-pill sig-pill--warn', text: t('mst_not_served')}) : null);
          return el('tr', {'data-fp-box': b.address}, [el('th', {scope: 'row'}, [el('span', {class: 'sig-mono', text: b.address}), state]),
            el('td', {text: t('mst_fmt_' + (b.format || 'maildir'))}),
            el('td', null, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'plan', 'data-fp-addr': b.address,
              text: t('mst_plan_one'), 'aria-label': t('mst_plan_of', {address: b.address}), disabled: running() || b.converting})])]);
        });
        parts.push(el('p', {'data-fp-boxes': String(S.boxes.length), text: t(S.boxes.length === 1 ? 'mst_boxes_one' : 'mst_boxes_many', {n: String(S.boxes.length), user: S.user})}));
        parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-label': t('mst_boxes_label')},
          [el('table', {class: 'sig-table fp-mail-table fp-upd-table'}, [el('thead', null, [head]), el('tbody', null, rows)])]));
        parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'plan', 'data-fp-addr': '',
          text: t('mst_plan_all'), disabled: running()})]));
      }
    }
    return M.card('fp-mst-pick-h', t('mst_pick_title'), parts, 'fp-mst-pick');
  }
  function planCard() {
    var p = S.plan;
    if (!S.status.enabled || !p) { return null; }
    var parts = [M.errorLine(), M.statusLine()];
    var todo = p.boxes.filter(function (b) { return !b.skip; });
    parts.push(el('p', {'data-fp-plan': String(todo.length), text: t('mst_plan_intro', {n: String(todo.length), messages: p.messages.toLocaleString('en'), to: t('mst_fmt_' + p.to)})}));
    p.boxes.forEach(function (b) {
      var box = el('div', {class: 'fp-mst-planbox', 'data-fp-planbox': b.address}, [el('h3', {class: 'fp-h3'}, [el('span', {class: 'sig-mono', text: b.address})])]);
      if (b.skip) {
        box.appendChild(el('p', {class: 'fp-muted', 'data-fp-skip': '', text: t('mst_skip', {why: b.skip})}));
      } else {
        box.appendChild(el('p', {text: t('mst_box_line', {from: t('mst_fmt_' + b.from), messages: b.messages.toLocaleString('en'), size: size(b.vsize)})}));
        var head = el('tr', null, ['mst_col_folder', 'mst_col_messages', 'mst_col_size'].map(function (k) { return el('th', {scope: 'col', text: t(k)}); }));
        box.appendChild(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-label': t('mst_folders_of', {address: b.address})},
          [el('table', {class: 'sig-table fp-mail-table fp-upd-table'}, [el('thead', null, [head]), el('tbody', null, b.folders.map(function (f) {
            return el('tr', null, [el('th', {scope: 'row'}, [el('span', {class: 'sig-mono', text: f.name})]), el('td', {text: f.messages.toLocaleString('en')}), el('td', {text: size(f.vsize)})]);
          }))])]));
      }
      parts.push(box);
    });
    var disk = p.free >= p.need;
    parts.push(el('p', {'data-fp-space': disk ? 'ok' : 'short', class: disk ? '' : 'fp-bk-bad', text: t(disk ? 'mst_space_ok' : 'mst_space_short', {need: size(p.need), free: size(p.free)})}));
    if (p.quotaBytes >= 0 || p.quotaFiles >= 0) {
      var left = p.quotaBytes >= 0 && p.quotaFiles >= 0 ? t('mst_quota_left_both', {size: size(p.quotaBytes), files: p.quotaFiles.toLocaleString('en')}) :
        (p.quotaBytes >= 0 ? size(p.quotaBytes) : t('mst_quota_left_files', {files: p.quotaFiles.toLocaleString('en')}));
      parts.push(el('p', {'data-fp-quota': p.quotaEnough ? 'ok' : 'short', class: p.quotaEnough ? '' : 'fp-bk-bad',
        text: t(p.quotaEnough ? 'mst_quota_ok' : 'mst_quota_short', {left: left, need: size(p.need), files: p.needFiles.toLocaleString('en')})}));
    }
    parts.push(el('p', {class: 'fp-muted sig-hint', text: t('mst_plan_note')}));
    if (todo.length && p.enough) {
      var keep = el('input', {class: 'sig-input fp-mst-keep', id: 'fp-mst-keep', type: 'number', min: '0', max: '365', step: '1', inputmode: 'numeric', value: String(S.keep)});
      parts.push(M.field('fp-mst-keep', t('mst_keep_label'), keep, t('mst_keep_hint')));
      parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'convert', text: t('mst_convert'), disabled: running()}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'plan-close', text: t('cancel')})]));
    } else {
      parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'plan-close', text: t('mst_close')})]));
    }
    return M.card('fp-mst-plan-h', t('mst_plan_title'), parts, 'fp-mst-plan');
  }
  function boxRow(b) {
    var pct = b.state === 'copying' && b.vsize ? Math.min(99, Math.round(b.copied * 100 / b.vsize)) : null;
    var what = [el('span', {class: 'sig-pill ' + (b.state === 'done' ? 'sig-pill--ok' : (b.state === 'failed' ? 'sig-pill--danger' : (b.state === 'skipped' ? 'sig-pill--warn' : 'sig-pill--accent'))),
      text: t('mst_state_' + b.state)})];
    if (pct !== null) { what.push(el('span', {class: 'fp-muted fp-mst-pct', text: t('mst_copied', {pct: String(pct), size: size(b.copied)})})); }
    var notes = [];
    if (b.error) { notes.push(el('span', {class: 'fp-bk-bad fp-mst-note', text: b.error})); }
    if (b.late) { notes.push(el('span', {class: 'fp-muted fp-mst-note', text: t('mst_late', {n: String(b.late)})})); }
    if (b.note) { notes.push(el('span', {class: 'fp-muted fp-mst-note', text: b.note})); }
    return el('tr', {'data-fp-jobbox': b.address, 'data-fp-state': b.state}, [el('th', {scope: 'row'}, [el('span', {class: 'sig-mono', text: b.address})]),
      el('td', {text: (b.from ? t('mst_fmt_' + b.from) : '—') + ' → ' + (b.to ? t('mst_fmt_' + b.to) : '—')}), el('td', null, what), el('td', null, notes)]);
  }
  function jobTable(j, label) {
    var head = el('tr', null, ['mst_col_mailbox', 'mst_col_change', 'mst_col_state', 'mst_col_notes'].map(function (k) { return el('th', {scope: 'col', text: t(k)}); }));
    return el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-label': label},
      [el('table', {class: 'sig-table fp-mail-table fp-upd-table'}, [el('thead', null, [head]), el('tbody', null, j.boxes.map(boxRow))])]);
  }
  function jobCard() {
    if (!S.status.enabled) { return null; }
    var j = S.status.job || S.status.recent[0] || null;
    var parts = [M.errorLine(), M.statusLine()];
    if (!j) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-job': 'none', text: t('mst_job_none')}));
      return M.card('fp-mst-job-h', t('mst_job_title'), parts, 'fp-mst-job');
    }
    var done = j.boxes.filter(function (b) { return b.state === 'done'; }).length;
    var key = j.state === 'running' ? 'mst_job_running' : (j.state === 'succeeded' ? 'mst_job_ok' : 'mst_job_failed');
    parts.push(el('p', {'data-fp-job': j.state, class: j.state === 'failed' ? 'fp-bk-bad' : '', text: t(key, {user: j.username, to: t('mst_fmt_' + (j.to || 'maildir')),
      when: when(j.state === 'running' ? j.started : j.ended) || '—', done: String(done), n: String(j.boxes.length)})}));
    if (j.by) { parts.push(el('p', {class: 'fp-muted', text: t('mst_job_by', {by: j.by})})); }
    parts.push(jobTable(j, t('mst_job_label')));
    return M.card('fp-mst-job-h', t('mst_job_title'), parts, 'fp-mst-job');
  }
  function keptCard() {
    if (!S.status.enabled) { return null; }
    var parts = [M.errorLine(), M.statusLine()];
    var k = S.status.kept;
    if (!k.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-kept': '0', text: t('mst_kept_none')}));
    } else {
      parts.push(el('p', {class: 'fp-muted', text: t('mst_kept_about')}));
      var head = el('tr', null, ['mst_col_mailbox', 'mst_col_format', 'mst_col_until', 'mst_col_actions'].map(function (c) { return el('th', {scope: 'col', text: t(c)}); }));
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-label': t('mst_kept_label'), 'data-fp-kept': String(k.length)},
        [el('table', {class: 'sig-table fp-mail-table fp-upd-table'}, [el('thead', null, [head]), el('tbody', null, k.map(function (e) {
          return el('tr', {'data-fp-keptrow': String(e.id)}, [el('th', {scope: 'row'}, [el('span', {class: 'sig-mono', text: e.address}), el('span', {class: 'fp-muted fp-upd-arch sig-mono', text: e.path})]),
            el('td', {text: e.format ? t('mst_fmt_' + e.format) : '—'}), el('td', {text: e.until ? (when(e.until) || e.until) : t('mst_until_removed')}),
            el('td', null, [el('div', {class: 'fp-actions fp-mst-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'drop',
              'data-fp-id': String(e.id), text: t('mst_drop'), 'aria-label': t('mst_drop_of', {address: e.address})})])])]);
        }))])]));
    }
    return M.card('fp-mst-kept-h', t('mst_kept_title'), parts, 'fp-mst-kept');
  }
  function recentCard() {
    if (!S.status.enabled) { return null; }
    var r = S.status.recent.slice(S.status.job ? 0 : 1);
    if (!r.length) { return null; }
    var parts = r.map(function (j) {
      return el('div', {class: 'fp-mst-planbox', 'data-fp-recent': String(j.id)}, [el('p', {text: t(j.state === 'succeeded' ? 'mst_job_ok' : 'mst_job_failed', {user: j.username,
        to: t('mst_fmt_' + (j.to || 'maildir')), when: when(j.ended) || '—', done: String(j.boxes.filter(function (b) { return b.state === 'done'; }).length), n: String(j.boxes.length)})}),
      jobTable(j, t('mst_recent_label', {n: String(j.id)}))]);
    });
    return M.card('fp-mst-recent-h', t('mst_recent_title'), parts, 'fp-mst-recent');
  }
  var MAKERS = {'fp-mst-status': statusCard, 'fp-mst-pick': pickCard, 'fp-mst-plan': planCard, 'fp-mst-job': jobCard, 'fp-mst-kept': keptCard, 'fp-mst-recent': recentCard};

  function draw(cls, focusHeading) {
    var old = S.page.querySelector('.' + cls);
    var fresh = MAKERS[cls]();
    var focused = document.activeElement;
    var key = old && focused && old.contains(focused) && focused.id ? '#' + focused.id : '';
    if (!fresh) { if (old) { old.remove(); } return null; }
    if (old) {
      old.replaceWith(fresh);
    } else {
      var later = null;
      for (var i = CARDS.indexOf(cls) + 1; i < CARDS.length && !later; i++) { later = S.page.querySelector('.' + CARDS[i]); }
      S.page.insertBefore(fresh, later);
    }
    var back = focusHeading ? fresh.querySelector('.fp-h2') : (key ? fresh.querySelector(key) : null);
    if (back) { back.focus(); }
    return fresh;
  }
  function drawAll() { CARDS.forEach(function (c) { draw(c, false); }); }
  function cardOf(node) { return CARDS.filter(function (c) { return node.closest('.' + c); })[0] || ''; }
  function say(cls, text) { var c = S.page.querySelector('.' + cls); if (c) { M.say(c, text); } }
  function fail(cls, err) {
    var c = S.page.querySelector('.' + cls);
    if (c) { UI.showError(c, err && err.message ? err.message : t('api_failed')); }
  }

  /* ---------- asking the server ---------- */
  function loadBoxes(user, b) {
    var mine = S;
    if (b) { UI.setBusy(b, true); }
    FP.call('get', 'mailStorageBoxes', null, {username: user}).then(function (r) {
      if (S !== mine) { return; }
      mine.user = user;
      mine.boxes = list(obj(r).mailboxes).slice(0, 10000).map(function (x) {
        x = obj(x);
        return {address: str(x.address, 320), format: fmt(x.format), served: x.served === true, converting: x.converting === true};
      }).filter(function (x) { return ADDR_RE.test(x.address); });
      var fresh = draw('fp-mst-pick', false);
      var line = fresh && fresh.querySelector('[data-fp-boxes]');
      if (line && b) { line.setAttribute('tabindex', '-1'); line.focus(); }
    }, function (err) {
      if (S !== mine) { return; }
      if (b) { UI.setBusy(b, false); }
      fail('fp-mst-pick', err);
    });
  }
  function plan(addr, b) {
    var mine = S;
    var sel = S.page.querySelector('#fp-mst-to');
    S.to = sel ? fmt(sel.value) || 'mdbox' : 'mdbox';
    UI.setBusy(b, true);
    FP.call('post', 'mailStoragePlan', {username: S.user, address: addr, to: S.to}).then(function (r) {
      if (S !== mine) { return; }
      mine.plan = cleanPlan(r);
      mine.planAddr = addr;
      draw('fp-mst-pick', false);
      draw('fp-mst-plan', true);
    }, function (err) {
      if (S !== mine) { return; }
      UI.setBusy(b, false);
      fail('fp-mst-pick', err);
    });
  }
  function convert(b) {
    var mine = S;
    UI.setBusy(b, true);
    FP.call('post', 'mailStorageConvert', {username: S.plan.username, address: S.planAddr, to: S.plan.to, keep_days: S.keep}).then(function (r) {
      if (S !== mine) { return; }
      mine.plan = null;
      mine.status.job = cleanJob(obj(r).job);
      mine.watching = true;
      drawAll();
      var h = S.page.querySelector('.fp-mst-job .fp-h2');
      if (h) { h.focus(); }
      say('fp-mst-job', t('mst_started'));
      poll();
    }, function (err) {
      if (S !== mine) { return; }
      UI.setBusy(b, false);
      fail('fp-mst-plan', err);
    });
  }
  function reload(after) {
    var mine = S;
    return FP.call('get', 'mailStorage').then(function (r) {
      if (S !== mine) { return; }
      mine.status = cleanStatus(r);
      if (after) { after(); }
    });
  }
  function poll() {
    window.clearTimeout(S.timer);
    var mine = S;
    mine.timer = window.setTimeout(function () {
      if (S !== mine || !document.body.contains(mine.page)) { return; }
      reload(function () {
        if (running()) { draw('fp-mst-job', false); draw('fp-mst-status', false); poll(); return; }
        drawAll();
        if (mine.watching) {
          var j = mine.status.recent[0];
          say('fp-mst-job', t(j && j.state === 'succeeded' ? 'mst_ended_ok' : 'mst_ended_bad'));
        }
        mine.watching = false;
        if (mine.user) { loadBoxes(mine.user, null); }
      }).catch(function () { if (S === mine) { poll(); } });
    }, POLL_MS);
  }
  function drop(b) {
    var mine = S;
    var id = b.getAttribute('data-fp-id');
    UI.setBusy(b, true);
    FP.call('del', 'mailStorageKept', null, {id: id}).then(function () {
      if (S !== mine) { return; }
      reload(function () {
        draw('fp-mst-kept', true);
        say('fp-mst-kept', t('mst_dropped'));
      });
    }, function (err) {
      if (S !== mine) { return; }
      draw('fp-mst-kept', false);
      fail('fp-mst-kept', err);
    });
  }

  function onClick(e) {
    var target = e.target && e.target.closest ? e.target : null;
    var b = target && S && S.page && S.page.contains(target) ? target.closest('[data-fp-act]') : null;
    if (!b || b.disabled) { return; }
    var act = b.getAttribute('data-fp-act');
    var from = cardOf(b);
    if (from) { UI.showError(S.page.querySelector('.' + from), ''); }
    if (act === 'plan') {
      var addr = b.getAttribute('data-fp-addr') || '';
      if (addr === '' || ADDR_RE.test(addr)) { plan(addr, b); }
    } else if (act === 'plan-close') {
      S.plan = null;
      draw('fp-mst-plan', false);
      var h = S.page.querySelector('.fp-mst-pick .fp-h2');
      if (h) { h.focus(); }
    } else if (act === 'convert' && S.plan) {
      /* the days are read before the question, and kept while it is asked */
      var input = S.page.querySelector('#fp-mst-keep');
      var v = String(input.value || '').trim();
      if (!/^\d{1,3}$/.test(v) || Number(v) > 365) {
        UI.showError(S.page.querySelector('.fp-mst-plan'), t('mst_keep_bad'));
        input.focus();
        return;
      }
      S.keep = Number(v);
      M.confirmIn(b.parentNode, t('mst_ask_convert', {n: String(S.plan.boxes.filter(function (x) { return !x.skip; }).length), to: t('mst_fmt_' + S.plan.to)}), 'convert-yes', t('mst_convert_yes'));
    } else if (act === 'convert-yes' && S.plan) {
      convert(b);
    } else if (act === 'drop') {
      var id = b.getAttribute('data-fp-id');
      var holder = b.parentNode;
      M.confirmIn(holder, t('mst_ask_drop'), 'drop-yes', t('mst_drop_yes'));
      holder.querySelector('[data-fp-act="drop-yes"]').setAttribute('data-fp-id', id);
    } else if (act === 'drop-yes') {
      drop(b);
    } else if (act === 'confirm-no') {
      draw(from, false);
      var back = S.page.querySelector('.' + from + ' .fp-h2');
      if (back) { back.focus(); }
    }
  }
  function onSubmit(e) {
    var form = e.target;
    if (!S || !S.page || !S.page.contains(form) || form.getAttribute('data-fp-form') !== 'boxes') { return; }
    e.preventDefault();
    var card = S.page.querySelector('.fp-mst-pick');
    var u = String(form.querySelector('#fp-mst-user').value || '').trim().toLowerCase();
    UI.showError(card, '');
    if (!USER_RE.test(u)) { UI.showError(card, t('mst_user_bad')); form.querySelector('#fp-mst-user').focus(); return; }
    loadBoxes(u, form.querySelector('button[type="submit"]'));
  }
  document.addEventListener('click', onClick);
  document.addEventListener('submit', onSubmit);

  FP.view('tool:mail_storage', function () {
    var tool = FP.tools.mail_storage;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('mst_desc'), cls: 'fp-mail fp-upd fp-mst',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    if (S) { window.clearTimeout(S.timer); }
    S = {page: body, status: null, user: '', boxes: null, plan: null, planAddr: '', to: 'mdbox', keep: 7, timer: 0, watching: false};
    var mine = S;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'mailStorage').then(function (r) {
      if (S !== mine) { return; }
      mine.status = cleanStatus(r);
      body.textContent = '';
      drawAll();
      if (running()) { mine.watching = true; poll(); }
    }, function (err) {
      if (S !== mine) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

/* freePanel WordPress manager (docs/api.md, "Domains and sites": the WordPress manager): the customer's page for the WordPress
   sites the App installer made (#/tool/wordpress_manager). For the site chosen it shows which release it is and whether the server
   holds a newer one, updates it and puts the old files back, changes the four settings the server offers (debug, the file editor in
   WordPress's admin, automatic updates and maintenance mode) and checks WordPress's own files against the release. Nothing is sent
   by opening the page; an update and an undo ask first. What the server sends is cleaned to the shapes drawn here and shown as
   text; an address becomes a link only when it is an http or https one. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var ID_RE = /^[0-9a-f]{16}$/;
  var VERSION_RE = /^[0-9]{1,3}\.[0-9]{1,3}(\.[0-9]{1,3})?$/;
  var URL_RE = /^https?:\/\/[^\s<>"]{1,2040}$/i;
  var AUTO = ['minor', 'all', 'off'];
  var MAX_NAMES = 200;
  var PREFIX = /^server operation failed: /i;
  var CUR = null; /* {page, account, installs, id, status, scan, note, ask, busy} while the page is open */

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  function whole(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.floor(v) : 0; }
  function link(v) { v = str(v, 2048); return URL_RE.test(v) ? v : ''; }
  function version(v) { v = str(v, 16); return VERSION_RE.test(v) ? v : ''; }
  function names(v) {
    return (Array.isArray(v) ? v : []).filter(function (x) { return typeof x === 'string' && x; }).slice(0, MAX_NAMES).map(function (x) { return x.slice(0, 200); });
  }
  function when(iso) { return iso ? (FP.bk ? FP.bk.when(iso) : '') || iso : ''; }
  function count(n) { return n.toLocaleString('en'); }
  /* a refusal says what went wrong; the words every failed operation of the server starts with are not for the customer */
  function plain(message) { return str(message, 600).replace(PREFIX, ''); }

  function cleanInstalls(r) {
    return (r && Array.isArray(r.installs) ? r.installs : []).filter(function (x) {
      return x && typeof x === 'object' && x.app === 'wordpress' && ID_RE.test(str(x.id, 20));
    }).map(function (x) {
      var url = link(x.url);
      return {id: x.id, url: url, address: url ? url.replace(/^https?:\/\//i, '') : str(x.domain, 253), adminUrl: link(x.admin_url)};
    });
  }
  function cleanStatus(r) {
    r = r && typeof r === 'object' ? r : {};
    var u = r.undo && typeof r.undo === 'object' ? r.undo : null;
    return {version: version(r.version), latest: version(r.latest), update: r.update_available === true, config: r.config === true, debug: r.debug === true,
      fileEdit: r.file_edit === true, auto: AUTO.indexOf(r.auto_updates) >= 0 ? r.auto_updates : 'minor', maintenance: r.maintenance === true,
      plugins: names(r.plugins), pluginCount: whole(r.plugin_count), themes: names(r.themes), themeCount: whole(r.theme_count),
      undo: u && version(u.version) ? {version: version(u.version), created: str(u.created, 40)} : null};
  }
  function cleanScan(r) {
    r = r && typeof r === 'object' ? r : {};
    var out = {release: version(r.release), compared: whole(r.compared), changed: names(r.changed), missing: names(r.missing), extra: names(r.extra), uploads: names(r.uploads),
      configOpen: r.config_open === true, truncated: r.truncated === true};
    out.clean = out.changed.length + out.missing.length + out.extra.length + out.uploads.length === 0 && !out.configOpen;
    return out;
  }
  function current() {
    for (var i = 0; i < CUR.installs.length; i++) { if (CUR.installs[i].id === CUR.id) { return CUR.installs[i]; } }
    return null;
  }
  function params() { return {name: CUR.account, id: CUR.id}; }

  function fact(label, content, key) {
    return el('div', key ? {'data-fp-fact': key} : null, [el('dt', {text: label}), el('dd', null, content)]);
  }
  function addrLink(i) {
    return i.url ? el('a', {href: i.url, target: '_blank', rel: 'noopener noreferrer', text: i.address}) : el('span', {text: i.address});
  }
  /* the page says what an action did after the page is drawn again */
  function say(card, text) { M.say(card, text); }
  function cardOf(cls) { return CUR.page.querySelector('.' + cls); }
  function focusHead(cls) { var c = cardOf(cls); if (c) { c.querySelector('h2').focus(); } }

  /* ---------------- the release ---------------- */
  function stateLine(s) {
    var pill = 'sig-pill';
    var label = 'wpm_pill_none';
    var text = 'wpm_state_none';
    var args = {latest: s.latest, version: s.version};
    if (!s.version) {
      label = 'wpm_pill_unknown'; text = 'wpm_state_unknown';
    } else if (s.update) {
      pill += ' sig-pill--warn'; label = 'wpm_pill_update'; text = 'wpm_state_update';
    } else if (s.latest) {
      pill += ' sig-pill--ok'; label = 'wpm_pill_current'; text = 'wpm_state_current';
    }
    return el('p', {class: 'fp-ap-state fp-wm-state', 'data-fp-wm-state': s.version ? (s.update ? 'update' : (s.latest ? 'current' : 'none')) : 'unknown'}, [
      el('span', {class: pill, text: t(label)}), el('span', {text: t(text, args)})]);
  }
  function releaseCard() {
    var s = CUR.status;
    var i = current();
    var parts = [M.errorLine(), M.statusLine(), el('dl', {class: 'fp-ap-facts fp-wm-facts'}, [
      fact(t('wpm_f_site'), [addrLink(i)], 'site'),
      fact(t('wpm_f_have'), [el('span', {class: 'sig-mono', 'data-fp-wm-have': '', text: s.version || '—'})], 'have'),
      fact(t('wpm_f_newest'), [el('span', {class: 'sig-mono', 'data-fp-wm-newest': '', text: s.latest || '—'})], 'newest')]), stateLine(s)];
    if (CUR.ask === 'update' || CUR.ask === 'undo') {
      parts.push(askBlock());
    } else {
      var acts = [];
      if (s.update) { acts.push(el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'update-ask', text: t('wpm_update_to', {latest: s.latest})})); }
      if (i.adminUrl) { acts.push(el('a', {class: 'sig-btn sig-btn--secondary', href: i.adminUrl, target: '_blank', rel: 'noopener noreferrer', text: t('wpm_open_admin')})); }
      if (acts.length) { parts.push(el('div', {class: 'fp-actions'}, acts)); }
    }
    if (s.undo) {
      parts.push(el('div', {class: 'fp-wm-undo', 'data-fp-wm-undo': ''}, [el('h3', {class: 'fp-h3', text: t('wpm_undo_title')}),
        el('p', {class: 'fp-muted', text: t('wpm_undo_lead', {version: s.undo.version, when: when(s.undo.created)})}),
        CUR.ask === 'undo' ? null : el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'undo-ask',
          text: t('wpm_undo_to', {version: s.undo.version})})])]));
    }
    return M.card('fp-wm-release-h', t('wpm_release_title'), parts, 'fp-wm-release');
  }
  /* the question that stands in place of the buttons; Cancel takes the focus, so a second Enter cannot confirm it */
  function askBlock() {
    var s = CUR.status;
    var updating = CUR.ask === 'update';
    var q = el('p', {class: 'fp-mail-confirm', id: 'fp-wm-ask', text: updating ? t('wpm_update_ask', {version: s.version, latest: s.latest}) : t('wpm_undo_ask', {version: s.undo.version, current: s.version})});
    var yes = el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': updating ? 'update-yes' : 'undo-yes', text: updating ? t('wpm_update_yes') : t('wpm_undo_yes'),
      'aria-describedby': 'fp-wm-ask'});
    var no = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'ask-no', text: t('cancel'), 'aria-describedby': 'fp-wm-ask'});
    return el('div', {class: 'fp-ap-ask fp-wm-ask', role: 'group', 'aria-labelledby': 'fp-wm-ask'}, [q, el('p', {class: 'sig-hint', text: t(updating ? 'wpm_update_hint' : 'wpm_undo_hint')}),
      el('div', {class: 'fp-actions'}, [yes, no])]);
  }

  /* ---------------- the settings ---------------- */
  function settingsCard() {
    var s = CUR.status;
    var dis = s.config ? null : '';
    function box(id, label, hint, on) {
      var b = el('input', {type: 'checkbox', id: 'fp-wm-' + id, name: id, 'aria-describedby': 'fp-wm-' + id + '-hint', disabled: id === 'maintenance' ? null : dis});
      b.checked = on;
      return el('div', {class: 'sig-field'}, [el('label', {class: 'fp-check', for: 'fp-wm-' + id}, [b, el('span', {text: label})]), el('span', {class: 'sig-hint', id: 'fp-wm-' + id + '-hint', text: hint})]);
    }
    var auto = el('select', {class: 'sig-select', id: 'fp-wm-auto_updates', name: 'auto_updates', 'aria-describedby': 'fp-wm-auto-hint', disabled: dis}, AUTO.map(function (v) {
      return el('option', {value: v, text: t('wpm_auto_' + v)});
    }));
    auto.value = s.auto;
    var form = el('form', {class: 'fp-form fp-mail-form fp-wm-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      s.config ? null : el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-wm-noconfig': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('wpm_no_config')})]),
      box('debug', t('wpm_debug'), t('wpm_debug_hint'), s.debug),
      box('file_edit', t('wpm_file_edit'), t('wpm_file_edit_hint'), s.fileEdit),
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: 'fp-wm-auto_updates', text: t('wpm_auto')}), auto, el('span', {class: 'sig-hint', id: 'fp-wm-auto-hint', text: t('wpm_auto_hint')})]),
      box('maintenance', t('wpm_maintenance'), t('wpm_maintenance_hint'), s.maintenance),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('wpm_save')})])]);
    form.addEventListener('submit', function (e) { e.preventDefault(); saveSettings(form); });
    return M.card('fp-wm-settings-h', t('wpm_settings_title'), [form], 'fp-wm-settings');
  }
  function saveSettings(form) {
    var b = M.start(form);
    if (!b) { return; }
    var s = CUR.status;
    var body = {};
    var got = {debug: form.querySelector('[name="debug"]').checked, file_edit: form.querySelector('[name="file_edit"]').checked,
      auto_updates: form.querySelector('[name="auto_updates"]').value, maintenance: form.querySelector('[name="maintenance"]').checked};
    if (s.config) {
      if (got.debug !== s.debug) { body.debug = got.debug; }
      if (got.file_edit !== s.fileEdit) { body.file_edit = got.file_edit; }
      if (got.auto_updates !== s.auto) { body.auto_updates = got.auto_updates; }
    }
    if (got.maintenance !== s.maintenance) { body.maintenance = got.maintenance; }
    if (!Object.keys(body).length) { M.say(form, t('wpm_nothing_to_save')); return; }
    var mine = CUR;
    var id = CUR.id;
    UI.setBusy(b, true);
    FP.call('put', 'wpSettings', body, params()).then(function (r) {
      if (CUR !== mine || CUR.id !== id) { return; }
      mine.status = cleanStatus(r);
      mine.ask = '';
      render();
      say(cardOf('fp-wm-settings'), t('wpm_saved'));
      focusHead('fp-wm-settings');
    }, function (err) {
      UI.setBusy(b, false);
      if (CUR === mine && CUR.id === id) { M.failed(form, {message: plain(err.message), field: err.field}); }
    });
  }

  /* ---------------- plugins and themes ---------------- */
  function namesList(label, list, total, key) {
    var more = total > list.length ? total - list.length : 0;
    return el('div', {class: 'fp-wm-names-block', 'data-fp-wm-list': key}, [el('h3', {class: 'fp-h3', text: t('wpm_list_title', {what: label, n: count(total)})}),
      list.length ? el('ul', {class: 'fp-wm-names'}, list.map(function (n) { return el('li', {class: 'sig-mono', text: n}); })) : el('p', {class: 'fp-muted', text: t('wpm_list_none')}),
      more ? el('p', {class: 'fp-muted', text: t('wpm_list_more', {n: count(more)})}) : null]);
  }
  function listsCard() {
    var s = CUR.status;
    return M.card('fp-wm-lists-h', t('wpm_lists_title'), [el('p', {class: 'fp-muted', text: t('wpm_lists_lead')}),
      namesList(t('wpm_plugins'), s.plugins, s.pluginCount || s.plugins.length, 'plugins'), namesList(t('wpm_themes'), s.themes, s.themeCount || s.themes.length, 'themes')], 'fp-wm-lists');
  }

  /* ---------------- the check of the files ---------------- */
  function canScan() { var s = CUR.status; return Boolean(s.version && s.latest && !s.update && s.version === s.latest); }
  function scanWhy() {
    var s = CUR.status;
    if (!s.version) { return 'wpm_scan_unknown'; }
    if (!s.latest) { return 'wpm_scan_nolatest'; }
    if (s.update) { return 'wpm_scan_update'; }
    return '';
  }
  function scanList(key, list, titleKey) {
    if (!list.length) { return null; }
    return el('div', {class: 'fp-wm-names-block', 'data-fp-wm-found': key}, [el('h3', {class: 'fp-h3', text: t(titleKey, {n: count(list.length) + (CUR.scan.truncated && list.length >= MAX_NAMES ? '+' : '')})}),
      el('p', {class: 'fp-muted', text: t(titleKey + '_hint')}), el('ul', {class: 'fp-wm-names'}, list.map(function (n) { return el('li', {class: 'sig-mono', text: n}); }))]);
  }
  function scanResult() {
    var r = CUR.scan;
    var parts = [];
    parts.push(el('p', r.clean ? {class: 'fp-ap-state fp-wm-state', 'data-fp-wm-scan': 'clean'} : {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-wm-scan': 'found'},
      r.clean ? [el('span', {class: 'sig-pill sig-pill--ok', text: t('wpm_scan_ok_pill')}), el('span', {text: t('wpm_scan_ok', {release: r.release, n: count(r.compared)})})] :
        [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('wpm_scan_found', {release: r.release, n: count(r.compared)})})]));
    if (r.configOpen) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-wm-config-open': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('wpm_scan_config_open')})]));
    }
    [scanList('changed', r.changed, 'wpm_found_changed'), scanList('missing', r.missing, 'wpm_found_missing'), scanList('extra', r.extra, 'wpm_found_extra'),
      scanList('uploads', r.uploads, 'wpm_found_uploads')].forEach(function (x) { if (x) { parts.push(x); } });
    if (r.truncated) { parts.push(el('p', {class: 'fp-muted', 'data-fp-wm-truncated': '', text: t('wpm_scan_truncated')})); }
    if (!r.clean) { parts.push(el('p', {class: 'fp-muted', text: t('wpm_scan_advice')})); }
    return el('div', {class: 'fp-wm-scan-result', 'data-fp-wm-result': ''}, parts);
  }
  function scanCard() {
    var why = scanWhy();
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t('wpm_scan_lead')})];
    if (why) { parts.push(el('p', {class: 'sig-hint', 'data-fp-wm-scan-why': '', id: 'fp-wm-scan-why', text: t(why, {latest: CUR.status.latest})})); }
    var btn = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'scan', disabled: canScan() ? null : '', text: t('wpm_scan_run')});
    if (why) { btn.setAttribute('aria-describedby', 'fp-wm-scan-why'); }
    parts.push(el('div', {class: 'fp-actions'}, [btn]));
    if (CUR.scan) { parts.push(scanResult()); }
    return M.card('fp-wm-scan-h', t('wpm_scan_title'), parts, 'fp-wm-scan');
  }

  /* ---------------- the page ---------------- */
  function pickCard() {
    var sel = el('select', {class: 'sig-select', id: 'fp-wm-site', name: 'site'}, CUR.installs.map(function (i) { return el('option', {value: i.id, text: i.address}); }));
    sel.value = CUR.id;
    sel.addEventListener('change', function () { CUR.id = sel.value; CUR.status = null; CUR.scan = null; CUR.ask = ''; load(); });
    return el('section', {class: 'sig-card fp-mail-card fp-wm-pick', 'aria-label': t('wpm_pick_label')}, [el('div', {class: 'sig-card-body'}, [
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: 'fp-wm-site', text: t('wpm_pick')}), sel])])]);
  }
  function emptyCard() {
    return M.card('fp-wm-none-h', t('wpm_none_title'), [el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('wpm_none')}),
      el('div', {class: 'fp-actions'}, [el('a', {class: 'sig-btn sig-btn--primary', href: '#/tool/app_installer', text: t('wpm_to_installer')})])], 'fp-wm-none');
  }
  function render() {
    var keep = CUR.page.querySelector('#fp-wm-site');
    var hadFocus = keep && document.activeElement === keep;
    CUR.page.textContent = '';
    if (!CUR.installs.length) { CUR.page.appendChild(emptyCard()); return; }
    if (CUR.installs.length > 1) { CUR.page.appendChild(pickCard()); }
    if (CUR.error) {
      CUR.page.appendChild(M.card('fp-wm-error-h', t('wpm_error_title'), [el('div', {class: 'fp-alert', role: 'alert', 'data-fp-wm-load-error': '', text: CUR.error}),
        el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'retry', text: t('wpm_retry')})])], 'fp-wm-error'));
    } else if (!CUR.status) {
      CUR.page.appendChild(el('p', {class: 'fp-muted', 'data-fp-wm-loading': '', text: t('loading')}));
    } else {
      [releaseCard(), settingsCard(), listsCard(), scanCard()].forEach(function (c) { CUR.page.appendChild(c); });
    }
    if (hadFocus) { CUR.page.querySelector('#fp-wm-site').focus(); }
  }
  function load() {
    var mine = CUR;
    var id = CUR.id;
    CUR.error = '';
    render();
    FP.call('get', 'wpStatus', undefined, params()).then(function (r) {
      if (CUR !== mine || CUR.id !== id) { return; }
      mine.status = cleanStatus(r);
      render();
    }, function (err) {
      if (CUR !== mine || CUR.id !== id) { return; }
      mine.error = plain(err.message);
      render();
    });
  }

  /* ---------------- update and undo ---------------- */
  function run(b, action) {
    var mine = CUR;
    var id = CUR.id;
    var card = cardOf('fp-wm-release');
    var update = action === 'update';
    UI.setBusy(b, true);
    M.say(card, t(update ? 'wpm_updating' : 'wpm_undoing'));
    FP.call('post', update ? 'wpUpdate' : 'wpUndo', undefined, params()).then(function (r) {
      if (CUR !== mine || CUR.id !== id) { return; }
      mine.status = cleanStatus(r && r.status);
      mine.scan = null;
      mine.ask = '';
      render();
      say(cardOf('fp-wm-release'), t(update ? 'wpm_updated' : 'wpm_undone', {from: version(r && r.from), to: version(r && r.to)}));
      focusHead('fp-wm-release');
    }, function (err) {
      if (CUR !== mine || CUR.id !== id) { return; }
      mine.ask = '';
      render();
      UI.showError(cardOf('fp-wm-release'), plain(err.message));
      focusHead('fp-wm-release');
    });
  }
  function runScan(b) {
    var mine = CUR;
    var id = CUR.id;
    var card = cardOf('fp-wm-scan');
    UI.setBusy(b, true);
    UI.showError(card, '');
    M.say(card, t('wpm_scanning'));
    FP.call('post', 'wpScan', undefined, params()).then(function (r) {
      if (CUR !== mine || CUR.id !== id) { return; }
      mine.scan = cleanScan(r);
      render();
      say(cardOf('fp-wm-scan'), t('wpm_scan_done'));
      focusHead('fp-wm-scan');
    }, function (err) {
      if (CUR !== mine || CUR.id !== id) { return; }
      render();
      UI.showError(cardOf('fp-wm-scan'), plain(err.message));
      focusHead('fp-wm-scan');
    });
  }
  function click(b) {
    var act = b.getAttribute('data-fp-act');
    if (act === 'update-ask' || act === 'undo-ask') {
      CUR.ask = act === 'update-ask' ? 'update' : 'undo';
      render();
      var no = CUR.page.querySelector('[data-fp-act="ask-no"]');
      if (no) { no.focus(); }
    } else if (act === 'ask-no') {
      var was = CUR.ask;
      CUR.ask = '';
      render();
      var back = CUR.page.querySelector('[data-fp-act="' + was + '-ask"]');
      if (back) { back.focus(); }
    } else if (act === 'update-yes') {
      run(b, 'update');
    } else if (act === 'undo-yes') {
      run(b, 'undo');
    } else if (act === 'scan') {
      runScan(b);
    } else if (act === 'retry') {
      load();
    }
  }
  document.addEventListener('click', function (e) {
    var target = e.target && e.target.closest ? e.target : null;
    var b = target ? target.closest('[data-fp-act]') : null;
    if (b && CUR && CUR.page && CUR.page.contains(b) && !b.disabled) { click(b); }
  });
  /* Escape closes the question as Cancel does (nothing was sent), from wherever the focus is on the page */
  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Escape' || e.defaultPrevented || !CUR || !CUR.page || !CUR.ask || !CUR.page.contains(e.target)) { return; }
    var no = CUR.page.querySelector('[data-fp-act="ask-no"]');
    if (no && !no.disabled) {
      e.preventDefault();
      click(no);
    }
  });

  FP.view('tool:wordpress_manager', function () {
    CUR = null;
    var body = M.frame('wordpress_manager', 'fp-ap fp-wm fp-wm-page');
    if (!body) { return; }
    CUR = {page: body, account: FP.account(), installs: [], id: '', status: null, scan: null, ask: '', error: ''};
    var mine = CUR;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'appInstalls', undefined, CUR.account).then(function (r) {
      if (CUR !== mine) { return; }
      mine.installs = cleanInstalls(r);
      if (!mine.installs.length) { render(); return; }
      mine.id = mine.installs[0].id;
      load();
    }, function (err) {
      if (CUR !== mine) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(FP.tools.wordpress_manager.label, plain(err.message)));
    });
  });
})();

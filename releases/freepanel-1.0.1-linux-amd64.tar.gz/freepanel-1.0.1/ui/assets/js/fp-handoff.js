/* freePanel hand-off of a moved account's DNS (docs/api.md, "Moving accounts in": "Cutting an account over"; POST /transfers/handoffs): the card of the
   Move accounts here page (fp-transfers.js) that points the names of an account moved here from another freePanel server at this one. An account's names keep
   pointing at the old server until its DNS is changed, so the card does that on the old server in steps the admin takes one at a time: look at the records
   that name that server, lower their time to live, point them at this server, and undo it. Each step that writes asks first. What the question lists (the
   server, the account and the step) is a copy taken when the button was pressed, the boxes are switched off while it is open, and a Yes sends that copy and
   shows its result, never what the boxes say by then. The server and the answer are drawn as text: the source's own words are only ever shown, cut and
   cleaned by the panel's server. Declares only FP.handoff.card. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var USER_RE = /^[a-z][a-z0-9]{0,15}$/;
  var ACTIONS = ['status', 'lower-ttl', 'repoint', 'undo'];
  var PHASES = ['', 'lowered', 'repointed'];
  var TYPE_RE = /^[A-Za-z0-9]{1,10}$/;
  var MAX_RECORDS = 1000;
  var MAX_NOTES = 20;
  var SHOWN = 50;
  var WRITES = ['lower-ttl', 'repoint', 'undo'];

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  function whole(v) { return typeof v === 'number' && isFinite(v) && Math.floor(v) === v && v >= 0 ? v : null; }
  function when(iso) {
    var d = iso ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString(undefined, {dateStyle: 'medium', timeStyle: 'short'}) : str(iso, 40);
  }
  function seconds(n) { return n === null ? '—' : t('xho_seconds', {n: n.toLocaleString('en')}); }

  /* the answer of a step, kept to the shapes the card draws */
  function clean(r) {
    var h = r && typeof r === 'object' && r.handoff && typeof r.handoff === 'object' ? r.handoff : null;
    if (!h || ACTIONS.indexOf(h.action) < 0 || !USER_RE.test(str(h.account, 16))) { return null; }
    var records = (Array.isArray(h.records) ? h.records : []).slice(0, MAX_RECORDS).filter(function (x) {
      return x && typeof x === 'object' && TYPE_RE.test(str(x.type, 10)) && str(x.name, 255);
    }).map(function (x) {
      return {zone: str(x.zone, 255), name: str(x.name, 255), type: x.type.toUpperCase(), ttl: whole(x.ttl), content: str(x.content, 255),
        wasTtl: whole(x.was_ttl), wasContent: str(x.was_content, 255)};
    });
    return {action: h.action, account: h.account, phase: PHASES.indexOf(h.phase) >= 0 ? h.phase : '', to: (Array.isArray(h.to) ? h.to : []).filter(function (a) {
      return typeof a === 'string' && a.length <= 45;
    }).slice(0, 4), since: str(h.since, 40), records: records, total: Math.max(whole(h.total) || 0, records.length), left: whole(h.left) || 0,
    notes: (Array.isArray(h.notes) ? h.notes : []).filter(function (n) { return typeof n === 'string' && n; }).slice(0, MAX_NOTES).map(function (n) { return n.slice(0, 255); }),
    error: str(h.error, 600)};
  }

  /* the card: api {sources(): the freePanel servers ticked for hand-off as {id, name}, any(): whether there is a freePanel server at all, allowed(): moving is on,
     accounts(id): the names moved from that server this panel knows of}; returns {node, refresh()} */
  function card(api) {
    var H = {source: 0, account: '', result: null, ask: null, busy: false, shown: SHOWN};
    var node = el('section', {class: 'sig-card fp-mail-card fp-xho', 'aria-labelledby': 'fp-xho-h'});
    var seq = 0;
    var drawn = '';
    /* what the card's drawing depends on from the page: its switch and its servers */
    function signature() {
      return [api.allowed(), api.any(), api.sources().map(function (x) { return x.id + ':' + x.name; }).join(',')].join('|');
    }

    function sourceName(id) {
      var s = api.sources().filter(function (x) { return x.id === id; })[0];
      return s ? s.name : '';
    }
    function ready() { return api.allowed() && api.sources().length > 0; }

    /* ---------- what a step does, in words ---------- */
    function question(snap) {
      return t('xho_ask_' + snap.action.replace('-', '_'), {account: snap.account, source: snap.sourceName});
    }
    function yesLabel(action) { return t('xho_yes_' + action.replace('-', '_')); }

    /* ---------- drawing ---------- */
    function recordsTable(r) {
      var shown = r.records.slice(0, H.shown);
      var changed = r.phase !== '';
      var head = [el('th', {scope: 'col', text: t('xho_col_name')}), el('th', {scope: 'col', text: t('xho_col_type')}), el('th', {scope: 'col', text: t('xho_col_points')}),
        el('th', {scope: 'col', text: t('xho_col_ttl')})];
      var rows = shown.map(function (x) {
        var was = x.wasContent && x.wasContent !== x.content;
        return el('tr', {'data-fp-record': x.name + ' ' + x.type}, [
          el('th', {scope: 'row', class: 'fp-xho-name'}, [el('span', {class: 'sig-mono', text: x.name}), x.zone && x.zone !== x.name ? el('span', {class: 'sig-hint fp-xho-zone', text: x.zone}) : null]),
          el('td', {class: 'fp-xho-type', text: x.type}),
          el('td', {class: 'fp-xho-content'}, [el('span', {class: 'sig-mono', text: x.content}), was ? el('span', {class: 'sig-hint fp-xho-was', text: t('xho_was', {value: x.wasContent})}) : null]),
          el('td', {class: 'fp-num fp-xho-ttl'}, [el('span', {text: seconds(x.ttl)}), changed && x.wasTtl !== null && x.wasTtl !== x.ttl ?
            el('span', {class: 'sig-hint fp-xho-was', text: t('xho_was', {value: seconds(x.wasTtl)})}) : null])]);
      });
      var out = [el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-xho-rec-h'}, [el('table', {class: 'sig-table fp-mail-table fp-xho-table'},
        [el('thead', null, [el('tr', null, head)]), el('tbody', null, rows)])])];
      if (r.total > shown.length) {
        out.push(el('p', {class: 'sig-hint', 'data-fp-xho-showing': '', text: t('xho_showing', {shown: shown.length, total: r.total})}));
        if (r.records.length > shown.length) {
          out.push(el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', id: 'fp-xho-more', 'data-fp-act': 'xho-more', text: t('xho_more')}));
        }
      }
      return out;
    }
    function resultBlock() {
      var r = H.result;
      if (!r) { return null; }
      var blocks = [el('h3', {class: 'fp-h3', id: 'fp-xho-rec-h', tabindex: '-1', text: t('xho_records_of', {account: r.account, source: r.sourceName})}),
        el('p', {class: 'fp-xho-phase', 'data-fp-xho-phase': r.phase || 'none'}, [el('span', {class: 'sig-pill ' + (r.phase === 'repointed' ? 'sig-pill--ok' : r.phase === 'lowered' ? 'sig-pill--warn' : ''),
          text: t('xho_phase_' + (r.phase || 'none'))}), r.since && r.phase ? ' ' + t('xho_since', {when: when(r.since)}) : ''])];
      if (r.to.length && r.phase === 'repointed') { blocks.push(el('p', {class: 'fp-muted', 'data-fp-xho-to': '', text: t('xho_to', {addresses: r.to.join(', ')})})); }
      if (r.error) {
        blocks.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-xho-error': ''}, [UI.icon(FP.ui, 'ui_warning'),
          el('span', {text: t('xho_source_error', {source: r.sourceName, error: r.error})})]));
      } else if (!r.records.length) {
        blocks.push(el('p', {class: 'fp-muted', 'data-fp-xho-none': '', text: t('xho_no_records', {account: r.account})}));
      } else {
        blocks = blocks.concat(recordsTable(r));
      }
      if (r.left) { blocks.push(el('p', {class: 'fp-muted', 'data-fp-xho-left': '', text: t('xho_left', {n: r.left})})); }
      if (r.notes.length) {
        blocks.push(el('ul', {class: 'fp-xho-notes', 'data-fp-xho-notes': ''}, r.notes.map(function (n) { return el('li', {text: n}); })));
      }
      return el('div', {class: 'fp-xho-result', 'data-fp-xho-result': r.account}, blocks);
    }
    function stepButtons() {
      var r = H.result;
      var acts = el('div', {class: 'fp-actions', 'data-fp-xho-acts': ''});
      if (!r || r.error) { return acts; }
      function button(act, label, kind) {
        return el('button', {class: 'sig-btn sig-btn--' + kind, type: 'button', 'data-fp-act': 'xho-' + act, id: 'fp-xho-' + act, text: label});
      }
      if (r.phase === '') {
        acts.appendChild(button('lower-ttl', t('xho_lower'), 'primary'));
        acts.appendChild(button('repoint', t('xho_repoint'), 'secondary'));
      } else if (r.phase === 'lowered') {
        acts.appendChild(button('repoint', t('xho_repoint'), 'primary'));
        acts.appendChild(button('undo', t('xho_undo'), 'secondary'));
      } else {
        acts.appendChild(button('undo', t('xho_undo'), 'secondary'));
      }
      acts.appendChild(button('status', t('xho_refresh'), 'secondary'));
      return acts;
    }
    function lookForm() {
      var sources = api.sources();
      if (!H.source || !sources.some(function (s) { return s.id === H.source; })) { H.source = sources.length ? sources[0].id : 0; }
      var pick = el('select', {class: 'sig-select', id: 'fp-xho-source', name: 'source'}, sources.map(function (s) {
        return el('option', {value: String(s.id), text: s.name, selected: s.id === H.source ? true : null});
      }));
      var names = api.accounts(H.source);
      var list = el('datalist', {id: 'fp-xho-accounts'}, names.map(function (u) { return el('option', {value: u}); }));
      var account = el('input', {class: 'sig-input sig-mono', id: 'fp-xho-account', name: 'username', type: 'text', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none',
        maxlength: '16', value: H.account, list: names.length ? 'fp-xho-accounts' : null, 'aria-describedby': 'fp-xho-account-hint'});
      var form = el('form', {class: 'fp-form fp-xho-form', novalidate: '', 'data-fp-xho-form': ''}, [M.errorLine(), M.statusLine(),
        M.field('fp-xho-source', t('xho_source'), pick, t('xho_source_hint')), M.field('fp-xho-account', t('xho_account'), account, t('xho_account_hint')), list,
        el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', id: 'fp-xho-look', type: 'submit', text: t('xho_look')})])]);
      pick.addEventListener('change', function () {
        H.source = parseInt(pick.value, 10) || 0;
        var dl = form.querySelector('#fp-xho-accounts');
        if (dl) {
          dl.textContent = '';
          api.accounts(H.source).forEach(function (u) { dl.appendChild(el('option', {value: u})); });
        }
      });
      account.addEventListener('input', function () { H.account = account.value; });
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var b = M.start(form);
        if (!b || H.busy || H.ask) { return; }
        var name = account.value.trim().toLowerCase();
        if (!USER_RE.test(name)) { M.fieldError(form, account, t('xho_bad_account')); return; }
        if (!H.source) { M.fieldError(form, pick, t('xho_pick_source')); return; }
        step({source: H.source, sourceName: sourceName(H.source), account: name, action: 'status'}, b, form);
      });
      return form;
    }
    function draw() {
      drawn = signature();
      node.textContent = '';
      var body = [el('h2', {class: 'fp-h2', id: 'fp-xho-h', tabindex: '-1', text: t('xho_title')}), el('p', {class: 'fp-muted', text: t('xho_what')})];
      if (!api.allowed()) {
        body.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-xho-off': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('xho_off')})]));
      } else if (!api.sources().length) {
        body.push(el('p', {class: 'fp-muted', 'data-fp-xho-nosource': '', text: t(api.any() ? 'xho_none_ticked' : 'xho_none_source')}));
      }
      if (ready()) {
        body.push(lookForm());
        var result = resultBlock();
        if (result) { body.push(result, stepButtons()); }
      }
      node.appendChild(el('div', {class: 'sig-card-body'}, body));
    }

    /* ---------- the question ---------- */
    function ask(snap) {
      var acts = node.querySelector('[data-fp-xho-acts]');
      var form = node.querySelector('[data-fp-xho-form]');
      if (!acts || !form) { return; }
      H.ask = snap;
      seq += 1;
      form.setAttribute('inert', '');
      acts.textContent = '';
      var id = 'fp-xho-ask-' + seq;
      var yes = el('button', {class: 'sig-btn sig-btn--danger', type: 'button', id: 'fp-xho-yes', 'aria-describedby': id, text: yesLabel(snap.action)});
      var no = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', id: 'fp-xho-no', 'aria-describedby': id, text: t('cancel')});
      acts.appendChild(el('p', {class: 'fp-mail-confirm fp-xho-ask', id: id, 'data-fp-xho-ask': '', text: question(snap)}));
      acts.appendChild(yes);
      acts.appendChild(no);
      no.addEventListener('click', function () {
        H.ask = null;
        draw();
        (node.querySelector('#fp-xho-' + snap.action) || node.querySelector('#fp-xho-look')).focus();
      });
      yes.addEventListener('click', function () { step(snap, yes, node.querySelector('[data-fp-xho-form]')); });
      no.focus();
    }

    /* ---------- one step ---------- */
    function step(snap, b, form) {
      H.busy = true;
      UI.setBusy(b, true);
      var body = {source_id: snap.source, username: snap.account, action: snap.action};
      FP.call('post', 'transferHandoff', body).then(function (r) {
        H.busy = false;
        var res = clean(r);
        if (!res || res.account !== snap.account || res.action !== snap.action) {
          H.ask = null;
          draw();
          var f = node.querySelector('[data-fp-xho-form]');
          M.fieldError(f, null, t('xho_unreadable'));
          return;
        }
        res.sourceId = snap.source;
        res.sourceName = snap.sourceName;
        H.ask = null;
        H.result = res;
        H.account = snap.account;
        H.shown = SHOWN;
        draw();
        var said = res.error ? '' : t('xho_done_' + snap.action.replace('-', '_'), {account: res.account, source: snap.sourceName});
        M.say(node.querySelector('[data-fp-xho-form]'), said);
        var next = node.querySelector('#fp-xho-rec-h');
        if (next) { next.focus(); }
      }, function (err) {
        H.busy = false;
        UI.setBusy(b, false);
        if (H.ask) {
          H.ask = null;
          draw();
          form = node.querySelector('[data-fp-xho-form]');
        }
        M.failed(form, err);
        var again = node.querySelector('#fp-xho-' + snap.action) || node.querySelector('#fp-xho-look');
        if (again) { again.focus(); }
      });
    }

    /* ---------- events ---------- */
    node.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
      if (!b || !node.contains(b) || H.busy || H.ask) { return; }
      var act = b.getAttribute('data-fp-act');
      if (act === 'xho-more') {
        var was = H.shown;
        H.shown += SHOWN;
        draw();
        var rows = node.querySelectorAll('.fp-xho-table tbody tr');
        (rows[was] ? rows[was].querySelector('th') : node.querySelector('#fp-xho-rec-h')).setAttribute('tabindex', '-1');
        (rows[was] ? rows[was].querySelector('th') : node.querySelector('#fp-xho-rec-h')).focus();
        return;
      }
      var m = /^xho-(status|lower-ttl|repoint|undo)$/.exec(act);
      if (!m || !H.result) { return; }
      var snap = {source: H.result.sourceId, sourceName: H.result.sourceName, account: H.result.account, action: m[1]};
      if (WRITES.indexOf(snap.action) >= 0) {
        ask(snap);
      } else {
        step(snap, b, node.querySelector('[data-fp-xho-form]'));
      }
    });

    draw();
    return {node: node, refresh: function () {
      /* the page's list of servers or its switch changed: draw again, keeping what was typed and the answer shown */
      if (H.ask || H.busy || signature() === drawn) { return; }
      draw();
    }};
  }

  FP.handoff = {card: card};
})();

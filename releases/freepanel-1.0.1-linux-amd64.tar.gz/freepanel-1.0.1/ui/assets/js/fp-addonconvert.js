/* freePanel's page for making an addon domain an account of its own, in the administrators' panel (#/tool/addon_to_account, docs/api.md,
   "Making an addon domain into an account"). The admin picks an account and one of its addon domains, a username, a package and the new owner's
   address; the page asks the server what would move and shows it, and only after a second yes starts the job. While the job runs the page asks
   how it goes every few seconds and shows each of its four steps; a job that stopped part-way can be tried again from that step, undone or
   dismissed, each undo and dismiss asked about first. Admins only. What the server sends is cleaned to the shapes drawn and shown as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var TOOL = 'addon_to_account';
  var POLL_MS = 2500;
  var STEPS = ['backup', 'detach', 'create', 'move'];
  var STATES = ['running', 'failed', 'done', 'undoing', 'undo_failed', 'undone', 'dismissed'];
  var USER_RE = /^[a-z][a-z0-9]{0,15}$/;
  var DOMAIN_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var NAME_RE = /^[A-Za-z0-9][A-Za-z0-9_. -]{0,63}$/;

  var A = null;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function whole(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.floor(v) : 0; }
  function sentence(m) { return typeof m === 'string' && m ? m.charAt(0).toUpperCase() + m.slice(1) : m; }
  function stamp(iso) {
    var d = typeof iso === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(iso) ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }
  function pill(kind, text) { return el('span', {class: 'sig-pill' + (kind ? ' sig-pill--' + kind : ''), text: text}); }

  function cleanAccounts(r) {
    return (r && Array.isArray(r.accounts) ? r.accounts : []).filter(function (a) {
      return a && USER_RE.test(str(a.username, 20)) && a.status === 'active';
    }).map(function (a) { return {username: a.username, domain: DOMAIN_RE.test(str(a.domain, 260)) ? a.domain : '', owner: USER_RE.test(str(a.owner, 20)) ? a.owner : ''}; })
      .sort(function (x, y) { return x.username < y.username ? -1 : 1; });
  }
  function cleanPackages(r) {
    return (r && Array.isArray(r.packages) ? r.packages : []).map(function (p) { return {name: str(p && p.name, 70), owner: str(p && p.owner, 20)}; })
      .filter(function (p) { return NAME_RE.test(p.name); });
  }
  /* the account's addon sites, the only ones that can be made an account */
  function cleanAddons(r) {
    return (r && Array.isArray(r.sites) ? r.sites : []).filter(function (s) { return s && s.kind === 'addon' && DOMAIN_RE.test(str(s.domain, 260)); })
      .map(function (s) { return s.domain; }).sort();
  }
  function names(v) { return (Array.isArray(v) ? v : []).slice(0, 50).map(function (n) { return str(n, 80); }).filter(Boolean); }
  function cleanPlan(p) {
    if (!p || typeof p !== 'object' || !DOMAIN_RE.test(str(p.domain, 260)) || !USER_RE.test(str(p.username, 20))) { return null; }
    return {account: str(p.account, 20), domain: p.domain, username: p.username, pkg: str(p.package, 70), owner: str(p.owner, 20), docroot: str(p.docroot, 300),
      mailboxes: whole(p.mailboxes), forwarders: whole(p.forwarders), certificate: str(p.certificate, 20),
      databases: names(p.databases), dbUsers: names(p.database_users)};
  }
  function cleanJob(c) {
    if (!c || typeof c !== 'object' || STATES.indexOf(c.state) < 0 || !DOMAIN_RE.test(str(c.domain, 260))) { return null; }
    return {state: c.state, step: STEPS.indexOf(c.step) >= 0 ? c.step : 'backup', done: (Array.isArray(c.done) ? c.done : []).filter(function (s) { return STEPS.indexOf(s) >= 0; }),
      account: str(c.account, 20), domain: c.domain, username: str(c.username, 20), pkg: str(c.package, 70), docroot: str(c.docroot, 300),
      error: str(c.error, 600), notes: (Array.isArray(c.notes) ? c.notes : []).slice(0, 20).map(function (n) { return str(n, 300); }).filter(Boolean),
      started: str(c.started, 40), ended: str(c.ended, 40), created: c.created === true};
  }
  function cleanHeld(r) {
    return (r && Array.isArray(r.held) ? r.held : []).filter(function (h) { return h && DOMAIN_RE.test(str(h.domain, 260)); }).slice(0, 200)
      .map(function (h) { return {domain: h.domain, account: USER_RE.test(str(h.account, 20)) ? h.account : '', since: str(h.since, 40)}; });
  }
  function going(j) { return j && (j.state === 'running' || j.state === 'undoing'); }
  function stopped(j) { return j && (j.state === 'failed' || j.state === 'undo_failed'); }

  /* ---------- the job ---------- */
  function stepState(j, s) {
    if (j.done.indexOf(s) >= 0) { return j.state === 'undone' && s !== 'backup' ? 'undone' : 'done'; }
    if (s !== j.step) { return 'waiting'; }
    if (j.state === 'running') { return 'working'; }
    if (j.state === 'failed' || j.state === 'undo_failed' || j.state === 'dismissed') { return 'stopped'; }
    return 'waiting';
  }
  var STEP_PILL = {done: 'ok', undone: '', working: 'accent', stopped: 'danger', waiting: ''};
  function stepRow(j, s, i) {
    var st = stepState(j, s);
    return el('li', {class: 'fp-adc-step is-' + st, 'data-fp-step': s, 'data-fp-state': st}, [
      el('span', {class: 'fp-adc-num', 'aria-hidden': 'true', text: String(i + 1)}),
      el('span', {class: 'fp-adc-step-text'}, [el('span', {class: 'fp-adc-step-name', text: t('adc_step_' + s)}),
        el('span', {class: 'fp-muted fp-adc-step-what', text: t('adc_step_' + s + '_what', {account: j.account, domain: j.domain, username: j.username})})]),
      st === 'waiting' ? el('span', {class: 'fp-muted fp-adc-step-pill', text: t('adc_st_waiting')}) : pill(STEP_PILL[st], t('adc_st_' + st))]);
  }
  function headline(j) {
    var when = stamp(j.ended) || stamp(j.started);
    return t('adc_job_' + j.state, {domain: j.domain, account: j.account, username: j.username, step: t('adc_step_' + j.step), when: when});
  }
  function jobCard() {
    var j = A.job;
    var parts = [M.errorLine(), M.statusLine(),
      el('p', {class: 'fp-adc-head' + (stopped(j) ? ' fp-bk-bad' : ''), 'data-fp-job': j.state, text: headline(j)})];
    if (j.state === 'undoing') { parts.push(el('p', {class: 'fp-muted', 'data-fp-undoing': '', text: t('adc_undoing_what')})); }
    else { parts.push(el('ol', {class: 'fp-adc-steps', 'aria-label': t('adc_steps_label')}, STEPS.map(function (s, i) { return stepRow(j, s, i); }))); }
    if (j.error) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-job-error': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: sentence(j.error)})]));
    }
    if (j.state === 'failed') { parts.push(el('p', {class: 'fp-muted', text: t('adc_failed_what')})); }
    if (j.notes.length) {
      parts.push(el('h3', {class: 'fp-h3', text: t('adc_notes')}));
      parts.push(el('ul', {class: 'fp-adc-notes'}, j.notes.map(function (n) { return el('li', {text: sentence(n)}); })));
    }
    var acts = el('div', {class: 'fp-actions fp-adc-acts'});
    if (j.state === 'failed') {
      acts.appendChild(el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'adc-retry', text: t('adc_retry', {step: t('adc_step_' + j.step)})}));
      acts.appendChild(el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'adc-undo', text: t('adc_undo')}));
    }
    if (j.state === 'undo_failed') { acts.appendChild(el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'adc-undo', text: t('adc_undo_again')})); }
    if (stopped(j)) { acts.appendChild(el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'adc-dismiss', text: t('adc_dismiss')})); }
    if (j.state === 'done' && FP.tools.account_list) { acts.appendChild(el('a', {class: 'sig-btn sig-btn--secondary', href: '#/tool/account_list', text: t('adc_open_accounts')})); }
    if (acts.childNodes.length) { parts.push(acts); }
    var ask = el('div', {class: 'fp-adc-ask'});
    parts.push(ask);
    var card = M.card('fp-adc-job-h', t('adc_job_title'), parts, 'fp-adc-job');
    card.setAttribute('aria-busy', going(j) ? 'true' : 'false');
    card.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
      if (!b || b.disabled) { return; }
      var act = b.getAttribute('data-fp-act');
      if (act === 'adc-retry') { act3(card, b, 'addonConvertRetry', t('adc_retrying')); }
      else if (act === 'adc-undo') { M.confirmIn(ask, t('adc_undo_ask', {username: j.username, domain: j.domain, account: j.account}), 'adc-undo-yes', t('adc_undo_yes')); }
      else if (act === 'adc-dismiss') { M.confirmIn(ask, t('adc_dismiss_ask', {domain: j.domain}), 'adc-dismiss-yes', t('adc_dismiss_yes')); }
      else if (act === 'adc-undo-yes') { ask.textContent = ''; act3(card, card.querySelector('[data-fp-act="adc-undo"]'), 'addonConvertUndo', t('adc_undo_started')); }
      else if (act === 'adc-dismiss-yes') { ask.textContent = ''; act3(card, card.querySelector('[data-fp-act="adc-dismiss"]'), 'addonConvertDismiss', t('adc_dismissed')); }
      else if (act === 'confirm-no') { ask.textContent = ''; (card.querySelector('[data-fp-act="adc-undo"]') || card.querySelector('[data-fp-act="adc-dismiss"]') || card).focus(); }
    });
    return card;
  }
  /* a retry, an undo or a dismiss: the answer is the job as it is now */
  function act3(card, button, key, said) {
    var mine = A;
    UI.showError(card, '');
    M.say(card, '');
    UI.setBusy(button, true);
    FP.call('post', key, {}).then(function (r) {
      if (A !== mine) { return; }
      A.job = cleanJob(r && r.conversion) || A.job;
      if (key === 'addonConvertDismiss') {
        FP.call('get', 'addonConversions').then(function (g) {
          if (A !== mine) { return; }
          A.held = cleanHeld(g);
          draw('', said);
        }, function () {});
      }
      draw('#fp-adc-job-h', said);
      if (going(A.job)) { poll(); }
    }, function (err) {
      if (A !== mine) { return; }
      UI.setBusy(button, false);
      UI.showError(card, sentence(err.message));
      if (button) { button.focus(); }
    });
  }
  function poll() {
    window.clearTimeout(A.timer);
    var mine = A;
    A.timer = window.setTimeout(function () {
      if (A !== mine || !document.body.contains(mine.page)) { return; }
      FP.call('get', 'addonConversions').then(function (r) {
        if (A !== mine) { return; }
        var before = A.job;
        A.job = cleanJob(r && r.conversion);
        A.held = cleanHeld(r);
        if (!going(A.job)) { draw('', t('adc_ended_' + (A.job ? A.job.state : 'done'))); return; }
        if (!before || before.state !== A.job.state || before.step !== A.job.step || before.done.length !== A.job.done.length) { redrawJob(''); }
        poll();
      }, function () { if (A === mine) { poll(); } });
    }, POLL_MS);
  }
  /* the job's card again, keeping the focus where it was; a job that has ended draws the whole page */
  function redrawJob(said) {
    var old = A.page.querySelector('.fp-adc-job');
    if (!old || !A.job) { draw('', said); return; }
    var hadFocus = old.contains(document.activeElement);
    var fresh = jobCard();
    old.replaceWith(fresh);
    if (said) { M.say(fresh, said); }
    if (hadFocus) { fresh.querySelector('#fp-adc-job-h').focus(); }
  }

  /* ---------- the choice ---------- */
  function select(id, name, options, first) {
    return el('select', {class: 'sig-select', id: id, name: name}, [el('option', {value: '', text: first})].concat(options.map(function (o) {
      return el('option', {value: o.value, text: o.text});
    })));
  }
  function formCard() {
    var acct = select('fp-adc-account', 'account', A.accounts.map(function (a) { return {value: a.username, text: a.domain ? a.username + ' (' + a.domain + ')' : a.username}; }), t('adc_account_pick'));
    var dom = select('fp-adc-domain', 'domain', [], t('adc_domain_first'));
    dom.disabled = true;
    var user = el('input', {class: 'sig-input', id: 'fp-adc-username', name: 'username', type: 'text', maxlength: '16', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none'});
    var pkg = select('fp-adc-package', 'package', A.packages.map(function (p) { return {value: p.name, text: p.owner && p.owner !== FP.session.user.username ? p.name + ' (' + p.owner + ')' : p.name}; }), t('adc_package_pick'));
    var mail = el('input', {class: 'sig-input', id: 'fp-adc-email', name: 'contact_email', type: 'email', maxlength: '254', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none'});
    var plan = el('div', {class: 'fp-adc-plan', 'data-fp-plan': ''});
    var form = el('form', {class: 'fp-form fp-mail-form fp-adc-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-adc-account', t('adc_account'), acct, t('adc_account_hint')),
      M.field('fp-adc-domain', t('adc_domain'), dom, t('adc_domain_hint')),
      M.field('fp-adc-username', t('adc_username'), user, t('adc_username_hint')),
      M.field('fp-adc-package', t('adc_package'), pkg, t('adc_package_hint')),
      M.field('fp-adc-email', t('adc_email'), mail, t('adc_email_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('adc_check')})]), plan]);
    var asked = 0;
    acct.addEventListener('change', function () {
      plan.textContent = '';
      var name = acct.value;
      var mine = ++asked;
      dom.textContent = '';
      dom.disabled = true;
      if (!name) { dom.appendChild(el('option', {value: '', text: t('adc_domain_first')})); return; }
      dom.appendChild(el('option', {value: '', text: t('adc_domain_loading')}));
      FP.call('get', 'domains', undefined, name).then(function (r) {
        if (mine !== asked || !document.body.contains(form)) { return; }
        var addons = cleanAddons(r);
        dom.textContent = '';
        dom.appendChild(el('option', {value: '', text: addons.length ? t('adc_domain_pick') : t('adc_domain_none')}));
        addons.forEach(function (d) { dom.appendChild(el('option', {value: d, text: d})); });
        dom.disabled = !addons.length;
      }, function (err) {
        if (mine !== asked || !document.body.contains(form)) { return; }
        dom.textContent = '';
        dom.appendChild(el('option', {value: '', text: t('adc_domain_none')}));
        M.fieldError(form, acct, sentence(err.message));
      });
    });
    [dom, user, pkg, mail].forEach(function (f) { f.addEventListener('input', function () { plan.textContent = ''; }); });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      plan.textContent = '';
      var body = {account: acct.value, domain: dom.value, username: user.value.trim().toLowerCase(), package: pkg.value, contact_email: mail.value.trim()};
      if (!body.account) { M.fieldError(form, acct, t('adc_need_account')); return; }
      if (!body.domain) { M.fieldError(form, dom.disabled ? acct : dom, t('adc_need_domain')); return; }
      if (!USER_RE.test(body.username)) { M.fieldError(form, user, t('adc_need_username')); return; }
      if (!body.package) { M.fieldError(form, pkg, t('adc_need_package')); return; }
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(body.contact_email)) { M.fieldError(form, mail, t('adc_need_email')); return; }
      var mine = A;
      UI.setBusy(b, true);
      M.say(form, t('adc_checking'));
      FP.call('post', 'addonConvertCheck', body).then(function (r) {
        if (A !== mine) { return; }
        UI.setBusy(b, false);
        M.say(form, '');
        var p = cleanPlan(r && r.plan);
        if (!p) { M.fieldError(form, null, t('api_failed')); return; }
        drawPlan(form, plan, p, body);
      }, function (err) {
        if (A !== mine) { return; }
        UI.setBusy(b, false);
        M.say(form, '');
        M.failed(form, err);
      });
    });
    var parts = [el('p', {class: 'fp-muted', text: t('adc_intro')}), form];
    if (stopped(A.job) || going(A.job)) {
      parts = [el('p', {class: 'fp-muted', 'data-fp-wait': '', text: t('adc_one_at_a_time')})];
    }
    return M.card('fp-adc-form-h', t('adc_form_title'), parts, 'fp-adc-choose');
  }
  function planRow(label, value, mono) {
    return [el('dt', {class: 'fp-adc-k', text: label}), el('dd', {class: 'fp-adc-v' + (mono ? ' sig-mono' : ''), text: value})];
  }
  function drawPlan(form, box, p, body) {
    box.textContent = '';
    var cert = p.certificate === 'installed' ? t('adc_cert_installed') : p.certificate ? t('adc_cert_free') : t('adc_cert_none');
    var rows = [].concat(
      planRow(t('adc_plan_new'), t('adc_plan_new_v', {username: p.username, domain: p.domain, pkg: p.pkg, owner: p.owner})),
      planRow(t('adc_plan_files'), t('adc_plan_files_v', {docroot: '~' + p.account + '/' + p.docroot}), true),
      planRow(t('adc_plan_mail'), t('adc_plan_mail_v', {mailboxes: String(p.mailboxes), forwarders: String(p.forwarders)})),
      planRow(t('adc_plan_dns'), t('adc_plan_dns_v', {domain: p.domain})),
      planRow(t('adc_plan_cert'), cert),
      planRow(t('adc_plan_stays'), t('adc_plan_stays_v', {account: p.account})));
    var dbs = p.databases.concat(p.dbUsers);
    if (dbs.length) {
      rows = rows.concat(planRow(t('adc_plan_db'), t('adc_plan_db_v', {account: p.account, names: dbs.join(', ')})));
    }
    var ack = dbs.length ? el('input', {type: 'checkbox', id: 'fp-adc-dbask', name: 'databases_ack'}) : null;
    var ackRow = ack ? el('label', {class: 'fp-check fp-adc-dbask', for: 'fp-adc-dbask'}, [ack, el('span', {text: t('adc_db_ack', {account: p.account})})]) : null;
    var go = el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'adc-go', text: t('adc_go', {domain: p.domain})});
    var no = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'adc-change', text: t('adc_change')});
    box.appendChild(el('section', {class: 'fp-adc-confirm', 'aria-labelledby': 'fp-adc-plan-h'}, [
      el('h3', {class: 'fp-h3', id: 'fp-adc-plan-h', tabindex: '-1', text: t('adc_plan_title', {domain: p.domain})}),
      el('dl', {class: 'fp-adc-vals'}, rows),
      el('div', {class: 'sig-banner sig-banner--warn', role: 'note'}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('adc_plan_warn', {domain: p.domain, account: p.account})})]),
      el('p', {class: 'fp-muted', text: t('adc_plan_left_out')}), ackRow,
      el('div', {class: 'fp-actions'}, [go, no])]));
    box.querySelector('#fp-adc-plan-h').focus();
    no.addEventListener('click', function () { box.textContent = ''; form.querySelector('[name="account"]').focus(); });
    go.addEventListener('click', function () {
      if (go.disabled) { return; }
      if (ack && !ack.checked) { M.fieldError(form, ack, t('adc_db_need')); return; }
      if (ack) { body.databases_ack = true; }
      var mine = A;
      UI.setBusy(go, true);
      UI.setBusy(no, true);
      UI.showError(form, '');
      FP.call('post', 'addonConversions', body).then(function (r) {
        if (A !== mine) { return; }
        A.job = cleanJob(r && r.conversion);
        draw('#fp-adc-job-h', t('adc_started'));
        if (going(A.job)) { poll(); }
      }, function (err) {
        if (A !== mine) { return; }
        UI.setBusy(go, false);
        UI.setBusy(no, false);
        M.failed(form, err);
      });
    });
  }

  /* ---------- names held for a conversion that no job holds ---------- */
  function heldCard() {
    var held = A.held.filter(function (h) { return !(A.job && h.domain === A.job.domain && (going(A.job) || stopped(A.job))); });
    if (!held.length) { return null; }
    var ask = el('div', {class: 'fp-adc-ask'});
    var asked = '';
    var list = el('ul', {class: 'fp-adc-held', 'aria-label': t('adc_held_title')}, held.map(function (h) {
      return el('li', {class: 'fp-adc-held-row', 'data-fp-held': h.domain}, [
        el('span', {class: 'fp-adc-held-name'}, [el('span', {class: 'sig-mono', text: h.domain}),
          el('span', {class: 'fp-muted fp-row-note', text: t('adc_held_on', {account: h.account, when: stamp(h.since)})})]),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'adc-free', 'data-fp-domain': h.domain,
          text: t('adc_free'), 'aria-label': t('adc_free_label', {domain: h.domain})})]);
    }));
    var card = M.card('fp-adc-held-h', t('adc_held_title'), [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t('adc_held_what')}), list, ask], 'fp-adc-holds');
    card.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
      if (!b || b.disabled) { return; }
      var act = b.getAttribute('data-fp-act');
      if (act === 'adc-free') {
        asked = b.getAttribute('data-fp-domain');
        M.confirmIn(ask, t('adc_free_ask', {domain: asked}), 'adc-free-yes', t('adc_free_yes'));
      } else if (act === 'confirm-no') {
        ask.textContent = '';
        var back = card.querySelector('[data-fp-domain="' + asked + '"]');
        asked = '';
        if (back) { back.focus(); }
      } else if (act === 'adc-free-yes' && asked) {
        var d = asked;
        var mine = A;
        ask.textContent = '';
        UI.showError(card, '');
        UI.setBusy(b, true);
        FP.call('post', 'addonConvertFree', {domain: d}).then(function (r) {
          if (A !== mine) { return; }
          A.held = cleanHeld(r);
          draw('', '');
          var fresh = A.page.querySelector('.fp-adc-holds');
          if (fresh) { M.say(fresh, t('adc_freed', {domain: d})); fresh.querySelector('#fp-adc-held-h').focus(); }
          else { M.say(A.page, t('adc_freed', {domain: d})); }
        }, function (err) {
          if (A !== mine) { return; }
          UI.setBusy(b, false);
          UI.showError(card, sentence(err.message));
        });
      }
    });
    return card;
  }

  function draw(focus, said) {
    var page = A.page;
    page.textContent = '';
    if (A.job && A.job.state !== 'dismissed') { page.appendChild(jobCard()); }
    if (!A.accounts.length && !going(A.job) && !stopped(A.job)) {
      page.appendChild(FP.empty(t('adc_empty_title'), t('adc_empty_text')));
    } else {
      page.appendChild(formCard());
    }
    var hc = heldCard();
    if (hc) { page.appendChild(hc); }
    if (said) { M.say(page.querySelector('.fp-adc-job') || page, said); }
    var target = focus ? page.querySelector(focus) : null;
    if (target) { target.focus(); }
  }

  FP.view('tool:' + TOOL, function () {
    if (A) { window.clearTimeout(A.timer); }
    A = null;
    var tool = FP.tools[TOOL];
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('adc_desc'), cls: 'fp-mail fp-adc',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    if (!page) { return; }
    A = {page: page, accounts: [], packages: [], job: null, held: [], timer: 0};
    var mine = A;
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all([FP.call('get', 'addonConversions'), FP.call('get', 'accounts'), FP.call('get', 'packages').then(cleanPackages, function () { return []; })]).then(function (r) {
      if (A !== mine) { return; }
      A.job = cleanJob(r[0] && r[0].conversion);
      A.held = cleanHeld(r[0]);
      A.accounts = cleanAccounts(r[1]);
      A.packages = r[2];
      draw('', '');
      if (going(A.job)) { poll(); }
    }, function (err) {
      if (A !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, sentence(err && err.message) || t('api_failed')));
    });
  });
})();

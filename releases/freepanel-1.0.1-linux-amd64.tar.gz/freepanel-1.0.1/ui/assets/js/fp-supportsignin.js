/* freePanel log in as customer (docs/api.md, "Support sign-in"): the server panel's Open an account's panel page (#/tool/account_login). The server admin, or the
   reseller who owns the account, chooses one of their accounts, types their own password again and gets a link that opens the customer's panel as the customer,
   in a marked support session. The link works once, for one minute, and only from the address that asked for it; it is shown as text with a button to open it and one
   to copy it, and is never kept: making another link or choosing another account drops it. The page also lists who is in the account's panel now and ends them all.
   A reseller's own account, a suspended account and a login that is turned off cannot be signed in to, and the page says so. Everything the server sends is shown
   as text. The page pieces come from FP.mail (fp-mail.js) and FP.support (fp-support.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  /* the link as the server makes it: https, ending in /support/# and the code; anything else is shown as text and never made a link */
  var LINK_RE = /^https:\/\/[^\s"'<>]+\/support\/#[A-Za-z0-9_\-.~%+=]{16,512}$/;
  var MAX_LINK = 700;
  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  function link(r) {
    var url = str(r && r.url, MAX_LINK);
    return url ? {url: url, ok: LINK_RE.test(url), ends: FP.support.iso(r.expires_at)} : null;
  }

  var seq = 0;
  function card(user, options) {
    var o = options || {};
    var id = 'fp-ssi' + (++seq);
    var holder = el('div', {class: 'fp-ssi'});
    var S = {link: null, list: null, listError: '', busy: false, said: ''};
    var staff = FP.session.user.role === 'admin' ? t('ssi_you_admin') : t('ssi_you_reseller', {name: FP.session.user.username});

    function why() { return o.reseller ? t('ssi_reseller_own') : o.suspended ? t('ssi_suspended') : ''; }

    function form() {
      var password = el('input', {class: 'sig-input', id: id + '-password', name: 'password', type: 'password', autocomplete: 'current-password', maxlength: '1024',
        'aria-describedby': id + '-password-hint'});
      var f = el('form', {class: 'fp-form fp-ssi-form', novalidate: ''}, [M.errorLine(),
        el('ul', {class: 'fp-ssi-facts'}, ['ssi_fact_link', 'ssi_fact_time', 'ssi_fact_limits'].map(function (k) { return el('li', {text: t(k, {user: user})}); })
          .concat([el('li', {text: t('ssi_fact_who', {user: user, who: staff})})])),
        M.field(id + '-password', t('ssi_password'), password, t('ssi_password_hint')),
        el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('ssi_make')})])]);
      f.addEventListener('submit', function (e) {
        e.preventDefault();
        var b = M.start(f);
        if (!b || S.busy) { return; }
        if (!password.value) { M.fieldError(f, password, t('ssi_password_needed')); return; }
        S.busy = true;
        UI.setBusy(b, true);
        var typed = password.value;
        password.value = '';
        FP.call('post', 'accountSupportSignin', {password: typed}, user).then(function (r) {
          S.busy = false;
          var l = link(r);
          if (!l) { UI.setBusy(b, false); M.fieldError(f, null, t('api_failed')); return; }
          S.link = l;
          draw();
          holder.querySelector('#' + id + '-link-h').focus();
        }, function (err) {
          S.busy = false;
          UI.setBusy(b, false);
          if (err && err.status === 403) { M.fieldError(f, password, t('ssi_wrong_password')); return; }
          M.failed(f, err);
        });
      });
      return f;
    }

    function linkView() {
      var l = S.link;
      var a = l.ok ? el('a', {class: 'sig-btn sig-btn--primary', href: l.url, target: '_blank', rel: 'noopener noreferrer', 'data-fp-ssi-open': '', text: t('ssi_open_panel', {user: user})}) : null;
      return el('div', {class: 'fp-ssi-link', 'data-fp-ssi-link': l.ok ? 'ok' : 'odd'}, [
        el('h3', {class: 'fp-h3', id: id + '-link-h', tabindex: '-1', text: t('ssi_link_ready')}),
        el('p', {class: 'fp-muted', text: l.ends ? t('ssi_link_until', {until: FP.support.clock(l.ends)}) : t('ssi_link_once')}),
        el('pre', {class: 'sig-mono fp-ssi-url', tabindex: '0', id: id + '-url', 'aria-label': t('ssi_link_label'), text: l.url}),
        l.ok ? null : el('p', {class: 'fp-muted', text: t('ssi_link_odd')}),
        el('div', {class: 'fp-actions'}, [a, el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'ssi-copy', text: t('ssi_copy')}),
          el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'ssi-again', text: t('ssi_another')})]),
        el('p', {class: 'fp-ok-line', role: 'status', 'data-fp-ssi-copied': ''}),
        el('p', {class: 'fp-muted sig-hint', text: t('ssi_link_note')})]);
    }

    function listView() {
      var parts = [el('h3', {class: 'fp-h3', id: id + '-in-h', text: t('ssi_in_title', {user: user})})];
      if (S.listError) {
        parts.push(el('p', {class: 'fp-alert is-shown', 'data-fp-ssi-list-error': '', text: S.listError}));
      } else if (S.list === null) {
        parts.push(el('p', {class: 'fp-muted', text: t('loading')}));
      } else if (!S.list.length) {
        parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('ssi_in_none', {user: user})}));
      } else {
        parts.push(el('ul', {class: 'fp-sup-list', 'aria-labelledby': id + '-in-h'}, S.list.map(FP.support.sessionRow)));
      }
      parts.push(el('div', {class: 'fp-actions fp-ssi-acts'}, [
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'ssi-check', text: t('sup_check')}),
        S.list && S.list.length ? el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'ssi-end',
          text: t('ssi_end')}) : null]));
      parts.push(el('p', {class: 'fp-ok-line', role: 'status', 'data-fp-ssi-said': '', text: S.said}));
      return el('div', {class: 'fp-ssi-in'}, parts);
    }

    function draw() {
      var parts = [el('p', {class: 'fp-muted', text: t('ssi_what', {user: user})})];
      var blocked = why();
      if (blocked) {
        parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-ssi-blocked': o.reseller ? 'reseller' : 'suspended'},
          [UI.icon(FP.ui, 'ui_warning'), el('span', {text: blocked})]));
      } else {
        parts.push(S.link ? linkView() : form());
      }
      parts.push(listView());
      holder.textContent = '';
      holder.appendChild(M.card(id + '-h', t('ssi_title', {user: user}), parts, 'fp-ssi-card'));
    }

    function readList(focus) {
      return FP.call('get', 'accountSupportSessions', undefined, user).then(function (r) {
        S.list = FP.support.sessions(r);
        S.listError = '';
      }, function (err) {
        S.listError = err && err.message ? err.message : t('api_failed');
      }).then(function () {
        /* only the list is drawn again: the answer comes while the admin may be typing the password or reading the card, and the form, the heading with the
           focus and what was typed must stay as they are */
        var old = holder.querySelector('.fp-ssi-in');
        if (old) { old.parentNode.replaceChild(listView(), old); } else { draw(); }
        var f = focus && holder.querySelector(focus);
        if (f) { f.focus(); }
      });
    }

    holder.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
      if (!b) { return; }
      var a = b.getAttribute('data-fp-act');
      if (a === 'ssi-again') {
        S.link = null;
        draw();
        holder.querySelector('#' + id + '-password').focus();
      } else if (a === 'ssi-copy') {
        var said = holder.querySelector('[data-fp-ssi-copied]');
        var done = function (ok) { said.textContent = ok ? t('ssi_copied') : t('ssi_copy_failed'); if (!ok) { holder.querySelector('#' + id + '-url').focus(); } };
        if (window.navigator.clipboard && window.navigator.clipboard.writeText) { window.navigator.clipboard.writeText(S.link.url).then(function () { done(true); }, function () { done(false); }); } else { done(false); }
      } else if (a === 'ssi-check') {
        UI.setBusy(b, true);
        S.said = '';
        readList('[data-fp-act="ssi-check"]');
      } else if (a === 'ssi-end') {
        M.confirmIn(b.closest('.fp-ssi-acts'), t('ssi_end_ask', {user: user}), 'ssi-end-yes', t('sup_end_yes'));
      } else if (a === 'confirm-no') {
        draw();
        holder.querySelector('[data-fp-act="ssi-end"]').focus();
      } else if (a === 'ssi-end-yes') {
        if (S.busy) { return; }
        S.busy = true;
        UI.setBusy(b, true);
        FP.call('del', 'accountSupportSessions', undefined, user).then(function () {
          S.busy = false;
          S.list = [];
          S.listError = '';
          S.said = t('sup_ended_all');
          draw();
          holder.querySelector('[data-fp-act="ssi-check"]').focus();
        }, function (err) {
          S.busy = false;
          S.listError = err && err.message ? err.message : t('api_failed');
          draw();
        });
      }
    });

    draw();
    readList();
    return {node: holder, stop: function () { S.link = null; }};
  }

  /* ---- the page: choose an account, then its card ---- */
  var P = {page: null, accounts: [], resellers: [], card: null};
  function accountsOf(r) {
    return (r && Array.isArray(r.accounts) ? r.accounts : []).map(function (a) {
      return {name: str(a && a.username, 64), suspended: !!a && a.status !== 'active'};
    }).filter(function (a) { return /^[a-z][a-z0-9]{0,15}$/.test(a.name); }).sort(function (x, y) { return x.name < y.name ? -1 : x.name > y.name ? 1 : 0; });
  }
  function resellersOf(r) { return (r && Array.isArray(r.resellers) ? r.resellers : []).map(function (x) { return str(x && x.username, 64); }); }
  function optionText(a) {
    return P.resellers.indexOf(a.name) >= 0 ? t('ssi_option_reseller', {name: a.name}) : a.suspended ? t('ssi_option_suspended', {name: a.name}) : a.name;
  }
  function pickCard() {
    var select = el('select', {class: 'sig-select', id: 'fp-ssi-account', name: 'account'}, P.accounts.map(function (a) { return el('option', {value: a.name, text: optionText(a)}); }));
    var f = el('form', {class: 'fp-form fp-ssi-pick', novalidate: ''}, [M.errorLine(), M.field('fp-ssi-account', t('ssi_account'), select, t('ssi_account_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('ssi_continue')})])]);
    f.addEventListener('submit', function (e) {
      e.preventDefault();
      var name = select.value;
      var a = P.accounts.filter(function (x) { return x.name === name; })[0];
      if (!a) { return; }
      if (P.card) { P.card.stop(); }
      P.card = card(a.name, {suspended: a.suspended, reseller: P.resellers.indexOf(a.name) >= 0});
      var old = P.page.querySelector('.fp-ssi');
      if (old) { old.parentNode.removeChild(old); }
      P.page.appendChild(P.card.node);
      P.card.node.querySelector('h2').focus();
    });
    return M.card('fp-ssi-pick-h', t('ssi_pick_title'), [f], 'fp-ssi-pickcard');
  }

  FP.view('tool:account_login', function () {
    var tool = FP.tools.account_login;
    if (!tool || FP.realm !== 'admin' || (FP.session.user.role !== 'admin' && FP.session.user.role !== 'reseller')) { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    if (P.card) { P.card.stop(); }
    P.card = null;
    var body = FP.frame({title: tool.label, desc: t('ssi_desc'), cls: 'fp-mail fp-srv fp-ssi-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    P.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all([FP.call('get', 'accounts'), FP.session.user.role === 'admin' ? FP.call('get', 'resellers').then(resellersOf, function () { return []; }) : Promise.resolve([])]).then(function (r) {
      if (P.page !== body) { return; }
      P.accounts = accountsOf(r[0]);
      P.resellers = r[1];
      body.textContent = '';
      if (!P.accounts.length) { body.appendChild(FP.empty(tool.label, t('ssi_no_accounts'))); return; }
      body.appendChild(pickCard());
    }, function (err) {
      if (P.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
  FP.supportSignin = {card: card};
})();

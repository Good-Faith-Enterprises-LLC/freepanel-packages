/* freePanel billing invoices (#/tool/billing_invoices), the admin panel's bills to clients (docs/api.md, "Billing: invoices" and "Billing:
   payments", docs/billing/navigation-map.md, "Invoices"): the invoices filtered by status, client and overdue; a form to make one, kept as a
   draft or issued at once; and an invoice's own page, opened from the list on this same page, with its lines (changed while it is a draft),
   its totals, the payments taken and given back, credit put towards it, its note, and Issue, Download PDF and Cancel. Amounts are whole
   cents; what is typed is read digit by digit, never as a floating point number. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;
  var M = FP.mail;

  var PAGE = 50;
  var STATUSES = ['draft', 'unpaid', 'paid', 'cancelled', 'refunded'];
  var METHODS = ['bank_transfer', 'cash', 'cheque', 'other'];
  var I = null;

  function clientName(cid) { return cid && I.names[cid] ? I.names[cid] : cid ? t('binv_client_n', {id: String(cid)}) : '—'; }
  function screen(nodes, focus) {
    I.page.textContent = '';
    nodes.forEach(function (n) { if (n) { I.page.appendChild(n); } });
    var target = focus ? I.page.querySelector(focus) : null;
    if (target) { target.focus(); }
  }
  function card(name) { return I.page.querySelector('[data-fp-card="' + name + '"]'); }
  function named(id, title, parts, cls, name) {
    var c = M.card(id, title, parts, cls);
    c.setAttribute('data-fp-card', name);
    return c;
  }

  /* the clients, for their names and the client list of the filter and the new invoice form; the names of clients beyond the first
     two hundred are read one by one as invoices name them */
  function loadClients() {
    return FP.call('get', 'billingCustomers', undefined, {limit: '200', offset: '0'}).then(function (r) {
      var list = (r && Array.isArray(r.customers) ? r.customers : []).map(B.cleanCustomer).filter(Boolean);
      list.sort(function (a, b) { return a.name.localeCompare(b.name, 'en'); });
      I.clients = list;
      list.forEach(function (c) { I.names[c.id] = c.name; });
    }, function () { I.clients = []; });
  }
  function nameMissing(ids) {
    var mine = I;
    var want = ids.filter(function (cid, i) { return cid && !I.names[cid] && ids.indexOf(cid) === i; }).slice(0, 20);
    return Promise.all(want.map(function (cid) {
      return FP.call('get', 'billingCustomer', undefined, {id: String(cid)}).then(function (r) {
        var c = B.cleanCustomer(r);
        if (c && I === mine) { I.names[c.id] = c.name; }
      }, function () { /* the id stands in for the name */ });
    }));
  }

  /* ================= the list ================= */
  function filterForm() {
    var f = I.filters;
    var status = B.select('fp-binv-status', 'status', [['', t('bil_any')]].concat(STATUSES.map(function (s) { return [s, t('bil_inv_' + s)]; })), f.status,
      {disabled: f.overdue ? true : null});
    var picker = B.clientPicker('fp-binv-client', {name: 'customer', label: t('binv_f_client'), placeholder: t('bil_any'), clients: I.clients, value: f.client,
      valueName: f.client ? I.names[f.client] : ''});
    var client = picker.select;
    var overdue = el('input', {type: 'checkbox', id: 'fp-binv-overdue', name: 'overdue', checked: f.overdue ? true : null});
    overdue.addEventListener('change', function () { status.disabled = overdue.checked; });
    var form = el('form', {class: 'fp-form fp-bil-filters', novalidate: '', role: 'search', 'aria-label': t('binv_find')}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-bil-filter-row'}, [M.field('fp-binv-status', t('binv_f_status'), status), picker.node,
        el('div', {class: 'sig-field fp-bil-check-field'}, [el('span', {class: 'sig-label', 'aria-hidden': 'true', text: t('binv_f_overdue_head')}),
          el('label', {class: 'fp-bil-check', for: 'fp-binv-overdue'}, [overdue, el('span', {text: t('binv_f_overdue')})])])]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bil_show')}),
        B.button('clear', t('bil_clear'), 'sig-btn--secondary', {hidden: f.status || f.client || f.overdue ? null : true})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = form.querySelector('.fp-submit');
      if (!B.begin(form, b)) { return; }
      I.filters = {status: status.value, client: client.value, overdue: overdue.checked};
      I.offset = 0;
      refreshList(b, '#fp-binv-status:not([disabled]), #fp-binv-client');
    });
    return form;
  }
  function listCard() {
    return named('fp-binv-list-h', t('binv_list_title'), [el('div', {class: 'fp-bil-toolbar'}, [B.button('create', t('binv_create'), 'sig-btn--primary'),
      B.button('generate', t('binv_generate'))]), el('p', {class: 'fp-muted fp-row-note', text: t('binv_generate_what')}), filterForm(), el('div', {'data-fp-results': ''})], 'fp-binv-list', 'list');
  }
  function row(v) {
    var name = B.invoiceName(v);
    return el('tr', {'data-fp-invoice': String(v.id)}, [
      el('th', {scope: 'row', class: 'fp-bil-name'}, [B.button('open', name, 'sig-btn--link fp-bil-link', {'data-fp-id': String(v.id), 'aria-label': t('bil_open_invoice', {name: name})})]),
      el('td', {class: 'fp-bil-wrap', text: clientName(v.customer_id)}),
      el('td', {class: 'fp-bil-nowrap', text: B.day(v.issued) || '—'}), el('td', {class: 'fp-bil-nowrap', text: B.day(v.due_on) || '—'}),
      el('td', {class: 'fp-bil-num', text: B.money(v.total_cents, v.currency)}), el('td', {class: 'fp-bil-num', text: B.money(v.balance_cents, v.currency)}),
      el('td', null, [B.invoicePill(v)])]);
  }
  function filtered() { return Boolean(I.filters.status || I.filters.client || I.filters.overdue); }
  function results() {
    var d = I.data;
    var out = [];
    if (!d.invoices.length) {
      out.push(el('p', {class: 'fp-muted fp-bil-empty', 'data-fp-empty': '', text: t(filtered() ? 'binv_none_match' : 'binv_none')}));
      return out;
    }
    out.push(el('p', {class: 'fp-muted', 'data-fp-count': '', text: d.total === 1 ? t('bil_range_1') :
      t('bil_range', {from: B.num(I.offset + 1), to: B.num(I.offset + d.invoices.length), total: B.num(d.total)})}));
    out.push(B.table('fp-binv-list-h', 'fp-binv-table', [B.th(t('binv_col_number')), B.th(t('binv_col_client')), B.th(t('binv_col_issued')), B.th(t('binv_col_due')),
      B.th(t('binv_col_total'), 'fp-bil-num'), B.th(t('binv_col_balance'), 'fp-bil-num'), B.th(t('binv_col_status'))], d.invoices.map(row)));
    if (d.total > PAGE) {
      var prev = B.button('prev', t('bil_prev'));
      var next = B.button('next', t('bil_next'));
      prev.disabled = I.offset === 0;
      next.disabled = I.offset + PAGE >= d.total;
      out.push(el('div', {class: 'fp-actions'}, [prev, next]));
    }
    return out;
  }
  function drawResults(focus) {
    var box = I.page.querySelector('[data-fp-results]');
    if (!box) { return; }
    box.textContent = '';
    results().forEach(function (n) { box.appendChild(n); });
    var clear = I.page.querySelector('[data-fp-act="clear"]');
    if (clear) { clear.hidden = !filtered(); }
    var target = focus ? I.page.querySelector(focus) : null;
    if (target) { target.focus(); }
  }
  function loadList() {
    var mine = I;
    var f = I.filters;
    return FP.call('get', 'billingInvoices', undefined, {limit: String(PAGE), offset: String(I.offset), status: f.overdue ? 'overdue' : f.status, customer: f.client}).then(function (r) {
      if (I !== mine) { return null; }
      var list = (r && Array.isArray(r.invoices) ? r.invoices : []).map(B.cleanInvoice).filter(Boolean);
      var total = B.whole(r && r.total);
      if (!list.length && I.offset > 0 && total) {
        I.offset = Math.floor((total - 1) / PAGE) * PAGE;
        return loadList();
      }
      return nameMissing(list.map(function (v) { return v.customer_id; })).then(function () {
        if (I !== mine) { return null; }
        I.data = {invoices: list, total: total === null ? list.length : total};
        return I.data;
      });
    });
  }
  function refreshList(b, focus, said) {
    var mine = I;
    if (b) { UI.setBusy(b, true); }
    return loadList().then(function (d) {
      if (I !== mine || !d) { return; }
      if (b) { UI.setBusy(b, false); }
      drawResults(focus);
      var form = I.page.querySelector('.fp-bil-filters');
      if (said) { M.say(form, said); } else if (b && b.classList.contains('fp-submit')) { M.say(form, d.total === 1 ? t('binv_found_1') : t('binv_found', {n: B.num(d.total)})); }
    }, function (err) {
      if (I !== mine) { return; }
      if (b) { UI.setBusy(b, false); }
      B.failed(I.page.querySelector('.fp-bil-filters'), err);
    });
  }
  function showList(focus, said) {
    I.view = 'list';
    I.inv = null;
    var mine = I;
    screen([el('p', {class: 'fp-muted', text: t('loading')})]);
    return loadList().then(function (d) {
      if (I !== mine || !d) { return; }
      screen([listCard()]);
      drawResults();
      if (focus) { (I.page.querySelector(focus) || I.page.querySelector('#fp-binv-list-h')).focus(); }
      if (said) { M.say(I.page.querySelector('.fp-bil-filters'), said); }
    }, function (err) {
      if (I !== mine) { return; }
      screen([FP.empty(t('binv_list_title'), err.message, B.button('reload', t('bil_try_again')))]);
    });
  }
  function generate(b) {
    var mine = I;
    var form = I.page.querySelector('.fp-bil-filters');
    UI.showError(form, '');
    M.say(form, '');
    UI.setBusy(b, true);
    FP.call('post', 'billingInvoicesGenerate', {}).then(function (r) {
      if (I !== mine) { return; }
      UI.setBusy(b, false);
      var made = r && Array.isArray(r.invoices) ? r.invoices.length : 0;
      var skipped = r && Array.isArray(r.skipped) ? r.skipped.length : 0;
      var said = [t(made === 1 ? 'binv_generated_1' : 'binv_generated', {n: B.num(made)})];
      if (skipped) { said.push(t(skipped === 1 ? 'binv_skipped_1' : 'binv_skipped', {n: B.num(skipped)})); }
      refreshList(null, '[data-fp-act="generate"]', said.join(' '));
    }, function (err) {
      if (I !== mine) { return; }
      UI.setBusy(b, false);
      B.failed(form, err);
      b.focus();
    });
  }

  /* ================= a new invoice ================= */
  function showCreate(clientId) {
    I.view = 'create';
    I.inv = null;
    var active = I.clients.filter(function (c) { return c.status === 'active'; });
    var picker = B.clientPicker('fp-binv-n-client', {label: t('binv_client'), placeholder: t('binv_pick_client'), clients: I.clients, active: true, required: true,
      value: clientId || '', valueName: clientId ? I.names[clientId] : '', hint: active.length ? null : t('binv_no_active')});
    var pick = picker.select;
    var box = B.lines.box('fp-binv-n', []);
    var note = el('textarea', {class: 'sig-input fp-bil-text', id: 'fp-binv-n-note', name: 'note', rows: '3', maxlength: '500'});
    var due = el('input', {class: 'sig-input fp-binv-date', type: 'date', id: 'fp-binv-n-due', name: 'due_on'});
    var draft = el('button', {class: 'sig-btn sig-btn--secondary fp-submit', type: 'submit', value: 'draft', text: t('binv_save_draft')});
    var issue = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', value: 'issue', text: t('binv_issue_now')});
    var form = el('form', {class: 'fp-form fp-binv-new', novalidate: '', 'aria-labelledby': 'fp-binv-new-h'}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-binv-client-pick'}, [picker.node]),
      el('fieldset', {class: 'fp-bil-set'}, [el('legend', {class: 'fp-bil-legend', text: t('binv_lines')}), el('p', {class: 'fp-muted fp-row-note', text: t('binv_lines_hint')}), box]),
      M.field('fp-binv-n-note', t('binv_note'), note, t('binv_note_hint')),
      el('div', {class: 'fp-binv-due'}, [M.field('fp-binv-n-due', t('binv_due'), due, t('binv_due_hint'))]),
      el('div', {class: 'fp-actions'}, [issue, draft, B.button('create-cancel', t('cancel'))])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = e.submitter && e.submitter.classList.contains('fp-submit') ? e.submitter : issue;
      if (!B.begin(form, b)) { return; }
      if (!pick.value) { M.fieldError(form, pick, t('binv_client_needed')); return; }
      var lines = B.lines.read(form, box);
      if (!lines) { return; }
      var toIssue = b === issue;
      if (toIssue && !lines.length) { M.fieldError(form, form.querySelector('[name="lines.1.description"]'), t('binv_lines_needed')); return; }
      if (due.value && !/^\d{4}-\d{2}-\d{2}$/.test(due.value)) { M.fieldError(form, due, t('binv_due_bad')); return; }
      var body = {customer_id: Number(pick.value), lines: lines};
      if (note.value.trim()) { body.note = note.value; }
      var mine = I;
      UI.setBusy(draft, true);
      UI.setBusy(issue, true);
      FP.call('post', 'billingInvoiceNew', body).then(function (r) {
        if (I !== mine) { return null; }
        var v = B.cleanInvoice(r);
        if (!v) { throw {message: t('api_failed')}; }
        if (!toIssue) { openInvoice(v.id, {say: t('binv_draft_saved'), focus: '#fp-binv-h'}); return null; }
        return FP.call('post', 'billingInvoiceIssue', due.value ? {due_on: due.value} : {}, {id: String(v.id)}).then(function (r2) {
          if (I !== mine) { return; }
          var w = B.cleanInvoice(r2);
          openInvoice(v.id, {say: t('binv_issued', {name: w ? B.invoiceName(w) : ''}), focus: '#fp-binv-h'});
        }, function (err) {
          /* the draft is kept: its page says why it was not issued, with the due day to try again */
          if (I !== mine) { return; }
          openInvoice(v.id, {err: err, due: due.value, focus: '#fp-binv-h'});
        });
      }).catch(function (err) {
        if (I !== mine) { return; }
        UI.setBusy(draft, false);
        UI.setBusy(issue, false);
        if (err && err.field === 'customer_id') { M.fieldError(form, pick, t('binv_client') + ': ' + err.message); return; }
        B.lines.failed(form, box, err);
      });
    });
    screen([B.back('to-list', t('binv_back')), named('fp-binv-new-h', t('binv_create_title'), [el('p', {class: 'fp-muted', text: t('binv_create_what')}), form], 'fp-binv-create', 'create')],
      clientId ? '#fp-binv-n-l1-d' : '#fp-binv-n-client');
  }

  /* ================= an invoice ================= */
  function cleanTx(x) {
    if (!x || !B.id(x.id) || ['payment', 'refund'].indexOf(x.kind) < 0) { return null; }
    return {id: x.id, kind: x.kind, gateway: B.str(x.gateway, 40), method: B.str(x.method, 40), status: B.str(x.status, 20), currency: B.str(x.currency, 3) || 'USD',
      amount_cents: B.cents(x.amount_cents) || 0, refunded_cents: B.cents(x.refunded_cents) || 0, reference: B.str(x.reference, 100), note: B.str(x.note, 200),
      by: B.str(x.by, 64), created: B.str(x.created, 40)};
  }
  /* reads the invoice, its payments and its client's credit, then draws its page; opts: say (what the header says), err (a refusal it shows),
     due (the due day to offer again), focus (what takes focus), sayIn ([card, text]) */
  function openInvoice(vid, opts) {
    opts = opts || {};
    var mine = I;
    var b = I.page.querySelector('[data-fp-act="open"][data-fp-id="' + vid + '"]');
    if (b) { UI.setBusy(b, true); }
    return FP.call('get', 'billingInvoice', undefined, {id: String(vid)}).then(function (r) {
      var v = B.cleanInvoice(r);
      if (!v) { throw {message: t('api_failed')}; }
      return Promise.all([v, v.status === 'draft' ? [] : FP.call('get', 'billingTransactions', undefined, {limit: '100', offset: '0', invoice: String(v.id)}).then(function (x) {
        return (x && Array.isArray(x.transactions) ? x.transactions : []).map(cleanTx).filter(Boolean);
      }, function () { return null; }), v.status === 'unpaid' && v.customer_id ? FP.call('get', 'billingCredit', undefined, {id: String(v.customer_id)}).then(function (c) {
        return c && B.cents(c.balance_cents) !== null ? c.balance_cents : null;
      }, function () { return null; }) : null, nameMissing([v.customer_id]),
      v.status === 'unpaid' && v.customer_id ? FP.call('get', 'billingMethods', undefined, {id: String(v.customer_id)}).then(function (m) {
        return B.pickAll(m && m.methods, {id: 'id', gateway: [40], status: [20], label: [100], default: 'b'}, 'id').filter(function (x) { return x.status === 'active'; });
      }, function () { return null; }) : [],
      v.status === 'paid' || v.status === 'refunded' ? B.listOf('billingCreditNotes', {limit: '50', offset: '0', invoice: String(v.id)}, 'credit_notes', cleanCreditNote).then(function (x) { return x.items; }, function () { return null; }) : [],
      v.status === 'unpaid' && v.customer_id && !v.paid_cents ? B.allPages('billingInvoices', {customer: String(v.customer_id), status: 'unpaid'}, 'invoices', 1).then(function (x) {
        return x.items.map(B.cleanInvoice).filter(function (w) { return w && w.id !== v.id && w.status === 'unpaid' && !w.paid_cents; });
      }, function () { return []; }) : []]);
    }).then(function (r) {
      if (I !== mine) { return; }
      I.view = 'invoice';
      I.inv = {v: r[0], txs: r[1], credit: r[2], due: opts.due || '', methods: r[4], notes: r[5], mergeable: r[6]};
      drawInvoice();
      if (opts.say) { M.say(card('head'), opts.say); }
      if (opts.err) { B.failed(card('head').querySelector('form') || card('head'), opts.err); }
      if (opts.sayIn) { M.say(card(opts.sayIn[0]), opts.sayIn[1]); }
      var f = opts.focus && I.page.querySelector(opts.focus);
      /* a refusal about a field has focused it; anything else puts focus where it was asked */
      if (!(opts.err && document.activeElement && document.activeElement !== document.body && I.page.contains(document.activeElement))) { (f || I.page.querySelector('#fp-binv-h')).focus(); }
    }, function (err) {
      if (I !== mine) { return; }
      if (b && b.isConnected) { UI.setBusy(b, false); }
      var form = I.page.querySelector('.fp-bil-filters');
      if (form) { UI.showError(form, err.message); if (b && b.isConnected) { b.focus(); } return; }
      if (I.view === 'invoice' && card('head')) { UI.showError(card('head'), err.message); return; }
      showList().then(function () { var g = I.page.querySelector('.fp-bil-filters'); if (g) { UI.showError(g, err.message); } });
    });
  }
  function reopen(opts) { return openInvoice(I.inv.v.id, opts); }

  function drawInvoice() {
    var v = I.inv.v;
    screen([B.back('to-list', t('binv_back')), headCard(v), linesCard(v), v.status !== 'draft' ? paymentsCard(v) : null, v.status === 'unpaid' ? creditCard(v) : null,
      v.status === 'paid' || v.status === 'refunded' ? creditNotesCard(v) : null, notesCard(v)]);
  }
  function headCard(v) {
    var clientBit = FP.tools.billing_clients && v.customer_id ? [B.button('open-client', clientName(v.customer_id), 'sig-btn--link fp-bil-link', {'data-fp-id': String(v.customer_id),
      'aria-label': t('binv_open_client', {name: clientName(v.customer_id)})})] : clientName(v.customer_id);
    var pairs = [[t('binv_client'), clientBit], [t('binv_col_issued'), B.day(v.issued)], [t('binv_col_due'), B.day(v.due_on)]];
    if (v.paid && v.status !== 'unpaid') { pairs.push([t('binv_paid_on'), B.day(v.paid)]); }
    if (v.status === 'cancelled') { pairs.push([t('binv_cancelled_on'), B.day(v.cancelled)], [t('binv_reason'), v.merged_into ? t('binv_merged_reason') : v.reason]); }
    if (v.merged_into) { pairs.push([t('binv_merged_into'), [B.button('open', t('binv_invoice_ref', {id: String(v.merged_into)}), 'sig-btn--link fp-bil-link', {'data-fp-id': String(v.merged_into), 'aria-label': t('binv_open_merged')})]]); }
    var parts = [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-bil-head-row'}, [el('div', {class: 'fp-bil-head-name'}, [el('h2', {class: 'fp-h2', id: 'fp-binv-h', tabindex: '-1', text: v.number ? t('binv_invoice_n', {number: v.number}) : t('binv_draft_title', {id: String(v.id)})})]),
        B.invoicePill(v)]), B.facts(pairs)];
    if (v.status === 'draft') {
      var due = el('input', {class: 'sig-input fp-binv-date', type: 'date', id: 'fp-binv-i-due', name: 'due_on', value: I.inv.due});
      var go = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('binv_issue')});
      var form = el('form', {class: 'fp-form fp-binv-issue', novalidate: '', 'aria-label': t('binv_issue_label')}, [M.errorLine(),
        M.field('fp-binv-i-due', t('binv_due'), due, t('binv_due_hint')), el('div', {class: 'fp-actions'}, [go])]);
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!B.begin(form, go)) { return; }
        UI.showError(card('head'), '');
        if (due.value && !/^\d{4}-\d{2}-\d{2}$/.test(due.value)) { M.fieldError(form, due, t('binv_due_bad')); return; }
        var mine = I;
        UI.setBusy(go, true);
        FP.call('post', 'billingInvoiceIssue', due.value ? {due_on: due.value} : {}, {id: String(v.id)}).then(function (r) {
          if (I !== mine) { return; }
          var w = B.cleanInvoice(r);
          reopen({say: t('binv_issued', {name: w ? B.invoiceName(w) : ''}), focus: '#fp-binv-h'});
        }, function (err) {
          if (I !== mine) { return; }
          UI.setBusy(go, false);
          B.failed(form, err);
        });
      });
      parts.push(form);
    }
    var acts = [];
    var pdf = el('a', {class: 'sig-btn sig-btn--secondary', href: '/api/v1/billing/invoices/' + v.id + '/pdf', download: '', 'data-fp-pdf': ''}, [UI.icon(FP.ui, 'ui_download'),
      el('span', {text: t('binv_pdf')})]);
    acts.push(pdf);
    if (v.status === 'draft') { acts.push(B.button('remove', t('binv_remove_draft'), 'sig-btn--secondary fp-btn-danger-text')); }
    if (v.status === 'unpaid' && I.inv.mergeable && I.inv.mergeable.length) { acts.push(B.button('merge', t('binv_merge'))); }
    if (v.status === 'unpaid') { acts.push(B.button('cancel', t('binv_cancel'), 'sig-btn--secondary fp-btn-danger-text')); }
    parts.push(el('div', {class: 'fp-actions fp-binv-acts', 'data-fp-acts': ''}, acts));
    /* the head's own error line shows refusals of Issue too: the issue form sits inside the head card, not inside a form of its own error line */
    var c = el('section', {class: 'sig-card fp-bil-head fp-binv-head', 'aria-labelledby': 'fp-binv-h', 'data-fp-card': 'head'}, [el('div', {class: 'sig-card-body'}, parts)]);
    return c;
  }
  function totals(v) {
    var pairs = [[t('binv_subtotal'), B.money(v.subtotal_cents, v.currency)]];
    if (v.tax_cents || v.tax_name) { pairs.push([v.tax_name ? t('binv_tax_named', {name: v.tax_name}) : t('binv_tax'), B.money(v.tax_cents, v.currency)]); }
    pairs.push([t('binv_total'), B.money(v.total_cents, v.currency)], [t('binv_paid'), B.money(v.paid_cents, v.currency)], [t('binv_credited'), B.money(v.credited_cents, v.currency)],
      [t('binv_to_pay'), B.money(v.balance_cents, v.currency)]);
    var items = pairs.map(function (p, i) {
      return el('div', {class: 'fp-binv-total' + (i === pairs.length - 1 ? ' is-due' : '')}, [el('dt', {text: p[0]}), el('dd', {text: p[1]})]);
    });
    return el('dl', {class: 'fp-binv-totals', 'data-fp-totals': ''}, items);
  }
  function linesCard(v) {
    var parts = [M.statusLine()];
    if (v.status === 'draft') {
      var box = B.lines.box('fp-binv-e', v.lines.map(B.lines.typedOf));
      var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('binv_save_lines')});
      var form = el('form', {class: 'fp-form fp-binv-edit', novalidate: '', 'aria-label': t('binv_lines_form')}, [M.errorLine(), el('p', {class: 'fp-muted fp-row-note', text: t('binv_lines_hint')}), box,
        el('div', {class: 'fp-actions'}, [save])]);
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!B.begin(form, save)) { return; }
        M.say(card('lines'), '');
        var lines = B.lines.read(form, box);
        if (!lines) { return; }
        var mine = I;
        UI.setBusy(save, true);
        FP.call('patch', 'billingInvoice', {lines: lines}, {id: String(v.id)}).then(function () {
          if (I !== mine) { return; }
          reopen({sayIn: ['lines', t('binv_lines_saved')], focus: '#fp-binv-lines-h'});
        }, function (err) {
          if (I !== mine) { return; }
          UI.setBusy(save, false);
          B.lines.failed(form, box, err);
        });
      });
      parts.push(form);
    } else if (!v.lines.length) {
      parts.push(el('p', {class: 'fp-muted', text: t('binv_no_lines')}));
    } else {
      parts.push(B.table('fp-binv-lines-h', 'fp-binv-lines-table', [B.th(t('binv_col_desc')), B.th(t('binv_col_qty'), 'fp-bil-num'), B.th(t('binv_col_unit'), 'fp-bil-num'),
        B.th(t('binv_col_amount'), 'fp-bil-num')], v.lines.map(function (l) {
        return el('tr', null, [el('td', {class: 'fp-bil-wrap fp-binv-desc', text: l.description + (l.no_tax ? ' ' + t('binv_no_tax_mark') : '')}), el('td', {class: 'fp-bil-num', text: B.num(l.quantity)}),
          el('td', {class: 'fp-bil-num', text: B.money(l.unit_cents, v.currency)}), el('td', {class: 'fp-bil-num', text: B.money(l.amount_cents, v.currency)})]);
      })));
    }
    parts.push(totals(v));
    return named('fp-binv-lines-h', t('binv_lines'), parts, 'fp-binv-lines-card', 'lines');
  }

  function txRow(x, v) {
    var refundable = x.kind === 'payment' && x.status === 'succeeded' && x.amount_cents > x.refunded_cents && v.status !== 'cancelled';
    var kind = t('binv_tx_' + x.kind);
    var method = x.method ? (t('binv_method_' + x.method) === 'binv_method_' + x.method ? x.method : t('binv_method_' + x.method)) : '—';
    return el('tr', {'data-fp-tx': String(x.id)}, [el('td', {class: 'fp-bil-nowrap', text: B.when(x.created) || '—'}), el('td', {text: kind}), el('td', {text: method}),
      el('td', {class: 'fp-bil-num', text: (x.kind === 'refund' ? '−' : '') + B.money(x.amount_cents, x.currency)}),
      el('td', null, [B.pill(t('binv_txs_' + x.status) === 'binv_txs_' + x.status ? x.status : t('binv_txs_' + x.status), x.status === 'succeeded' ? 'ok' : x.status === 'failed' ? 'danger' : 'warn')]),
      el('td', {class: 'fp-bil-wrap', text: [x.reference, x.note].filter(Boolean).join(' · ') || '—'}),
      el('td', {class: 'fp-bil-num', text: x.refunded_cents ? B.money(x.refunded_cents, x.currency) : '—'}),
      el('td', {class: 'fp-bil-acts'}, refundable ? [B.button('refund', t('binv_refund'), 'sig-btn--secondary sig-btn--sm', {'data-fp-id': String(x.id), 'aria-label': t('binv_refund_of', {amount: B.money(x.amount_cents, x.currency), when: B.day(x.created)})})] : [])]);
  }
  function refundRow(x) {
    var pre = 'fp-binv-rf-' + x.id;
    var left = x.amount_cents - x.refunded_cents;
    var amount = B.input(pre + '-a', 'amount_cents', B.amountText(left), {inputmode: 'decimal', maxlength: '16', class: 'sig-input fp-bil-amount'});
    var reason = B.input(pre + '-r', 'reason', '', {maxlength: '200', 'aria-required': 'true'});
    var go = el('button', {class: 'sig-btn sig-btn--danger sig-btn--sm fp-submit', type: 'submit', text: t('binv_refund_go')});
    var form = el('form', {class: 'fp-form fp-binv-refund', novalidate: '', 'aria-label': t('binv_refund_label')}, [M.errorLine(),
      el('p', {class: 'fp-muted fp-row-note', text: t('binv_refund_what', {amount: B.money(left, x.currency)})}),
      el('div', {class: 'fp-bil-grid'}, [M.field(pre + '-a', t('binv_refund_amount'), amount, t('bil_amount_hint')), M.field(pre + '-r', t('binv_refund_reason'), reason, t('binv_refund_reason_hint'))]),
      el('div', {class: 'fp-actions'}, [go, B.button('refund-no', t('binv_refund_keep'), 'sig-btn--secondary sig-btn--sm', {'data-fp-id': String(x.id)})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!B.begin(form, go)) { return; }
      var c = B.parseAmount(amount.value, false);
      if (!c) { M.fieldError(form, amount, t('bil_amount_bad')); return; }
      if (!reason.value.trim()) { M.fieldError(form, reason, t('binv_refund_reason_needed')); return; }
      var mine = I;
      UI.setBusy(go, true);
      var body = {reason: reason.value.trim()};
      if (c !== left) { body.amount_cents = c; }
      FP.call('post', 'billingRefund', body, {id: String(x.id)}).then(function () {
        if (I !== mine) { return; }
        reopen({sayIn: ['payments', t('binv_refunded', {amount: B.money(c, x.currency)})], focus: '#fp-binv-pay-h'});
      }, function (err) {
        if (I !== mine) { return; }
        UI.setBusy(go, false);
        B.failed(form, err);
      });
    });
    return el('tr', {class: 'fp-binv-refund-row', 'data-fp-refund': String(x.id)}, [el('td', {colspan: '8'}, [form])]);
  }
  function paymentsCard(v) {
    var parts = [M.statusLine()];
    var txs = I.inv.txs;
    if (txs === null) {
      parts.push(el('p', {class: 'fp-muted', text: t('binv_txs_unread')}));
    } else if (!txs.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('binv_no_payments')}));
    } else {
      parts.push(B.table('fp-binv-pay-h', 'fp-binv-tx-table', [B.th(t('binv_col_when')), B.th(t('binv_col_kind')), B.th(t('binv_col_method')), B.th(t('binv_col_amount'), 'fp-bil-num'),
        B.th(t('binv_col_txstatus')), B.th(t('binv_col_ref')), B.th(t('binv_col_refunded'), 'fp-bil-num'), el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('acct_actions')})])],
      txs.map(function (x) { return txRow(x, v); })));
    }
    if (v.status === 'unpaid') {
      var amount = B.input('fp-binv-p-amount', 'amount_cents', B.amountText(v.balance_cents), {inputmode: 'decimal', maxlength: '16', class: 'sig-input fp-bil-amount'});
      var method = B.select('fp-binv-p-method', 'method', METHODS.map(function (m) { return [m, t('binv_method_' + m)]; }), 'bank_transfer');
      var ref = B.input('fp-binv-p-ref', 'reference', '', {maxlength: '100', spellcheck: 'false'});
      var note = B.input('fp-binv-p-note', 'note', '', {maxlength: '200'});
      var go = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('binv_record')});
      var form = el('form', {class: 'fp-form fp-binv-pay', novalidate: '', 'aria-labelledby': 'fp-binv-pay-form-h'}, [M.errorLine(),
        el('h3', {class: 'fp-h3', id: 'fp-binv-pay-form-h', text: t('binv_record_title')}), el('p', {class: 'fp-muted fp-row-note', text: t('binv_record_what')}),
        el('div', {class: 'fp-bil-grid'}, [M.field('fp-binv-p-amount', t('binv_pay_amount'), amount, t('bil_amount_hint')), M.field('fp-binv-p-method', t('binv_pay_method'), method),
          M.field('fp-binv-p-ref', t('binv_pay_ref'), ref, t('binv_pay_ref_hint')), M.field('fp-binv-p-note', t('binv_pay_note'), note)]),
        el('div', {class: 'fp-actions'}, [go])]);
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!B.begin(form, go)) { return; }
        var c = B.parseAmount(amount.value, false);
        if (!c) { M.fieldError(form, amount, t('bil_amount_bad')); return; }
        var body = {amount_cents: c, method: method.value};
        if (ref.value.trim()) { body.reference = ref.value.trim(); }
        if (note.value.trim()) { body.note = note.value.trim(); }
        var mine = I;
        UI.setBusy(go, true);
        FP.call('post', 'billingInvoicePayments', body, {id: String(v.id)}).then(function (r) {
          if (I !== mine) { return; }
          var extra = r && B.cents(r.credit_cents) ? r.credit_cents : 0;
          var said = t('binv_recorded', {amount: B.money(c, v.currency)}) + (extra ? ' ' + t('binv_recorded_extra', {amount: B.money(extra, v.currency)}) : '');
          reopen({sayIn: ['payments', said], focus: '#fp-binv-pay-h'});
        }, function (err) {
          if (I !== mine) { return; }
          UI.setBusy(go, false);
          B.failed(form, err);
        });
      });
      parts.push(form);
      parts.push(chargeForm(v));
    }
    return named('fp-binv-pay-h', t('binv_payments'), parts, 'fp-binv-payments', 'payments');
  }
  function creditCard(v) {
    var parts = [M.statusLine()];
    var credit = I.inv.credit;
    if (credit === null) {
      parts.push(el('p', {class: 'fp-muted', text: t('binv_credit_unread')}));
    } else if (!credit) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-no-credit': '', text: t('binv_credit_none')}));
    } else {
      var use = Math.min(credit, v.balance_cents);
      var amount = B.input('fp-binv-c-amount', 'amount_cents', B.amountText(use), {inputmode: 'decimal', maxlength: '16', class: 'sig-input fp-bil-amount'});
      var go = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('binv_apply')});
      var form = el('form', {class: 'fp-form fp-binv-apply', novalidate: '', 'aria-labelledby': 'fp-binv-credit-h'}, [M.errorLine(),
        el('p', {'data-fp-credit': '', text: t('binv_credit_held', {amount: B.money(credit, v.currency)})}),
        M.field('fp-binv-c-amount', t('binv_apply_amount'), amount, t('binv_apply_hint')), el('div', {class: 'fp-actions'}, [go])]);
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!B.begin(form, go)) { return; }
        var body = {};
        if (amount.value.trim()) {
          var c = B.parseAmount(amount.value, false);
          if (!c) { M.fieldError(form, amount, t('bil_amount_bad')); return; }
          body.amount_cents = c;
        }
        var mine = I;
        var before = v.paid_cents;
        UI.setBusy(go, true);
        FP.call('post', 'billingInvoiceApplyCredit', body, {id: String(v.id)}).then(function (r) {
          if (I !== mine) { return; }
          var w = B.cleanInvoice(r);
          var used = w ? w.paid_cents - before : 0;
          reopen({sayIn: [w && w.status === 'unpaid' ? 'credit' : 'head', t('binv_applied', {amount: B.money(used, v.currency)})], focus: w && w.status === 'unpaid' ? '#fp-binv-credit-h' : '#fp-binv-h'});
        }, function (err) {
          if (I !== mine) { return; }
          UI.setBusy(go, false);
          B.failed(form, err);
        });
      });
      parts.push(form);
    }
    return named('fp-binv-credit-h', t('binv_apply_title'), parts, 'fp-binv-credit', 'credit');
  }
  /* ---- charging a saved method: all that is owed, from the method chosen (the default first), asked first ---- */
  function chargeForm(v) {
    var ms = I.inv.methods;
    var head = el('h3', {class: 'fp-h3', id: 'fp-binv-charge-h', text: t('binv_charge_title')});
    if (ms === null) { return el('div', {class: 'fp-binv-charge'}, [head, el('p', {class: 'fp-muted', text: t('binv_methods_unread')})]); }
    if (!ms.length) { return el('div', {class: 'fp-binv-charge'}, [head, el('p', {class: 'fp-muted', 'data-fp-no-method': '', text: t('binv_no_methods')})]); }
    var sorted = ms.slice().sort(function (a, b) { return Number(b.default) - Number(a.default); });
    var label = function (m) { return (m.label || B.gatewayText(m.gateway)) + (m.default ? ' ' + t('binv_method_default_mark') : ''); };
    var pick = B.select('fp-binv-ch-method', 'method_id', sorted.map(function (m) { return [String(m.id), label(m)]; }), String(sorted[0].id));
    var go = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('binv_charge', {amount: B.money(v.balance_cents, v.currency)})});
    var form = el('form', {class: 'fp-form fp-binv-charge', novalidate: '', 'aria-labelledby': 'fp-binv-charge-h'}, [M.errorLine(), head,
      el('p', {class: 'fp-muted fp-row-note', text: t('binv_charge_what')}), el('div', {class: 'fp-bil-grid'}, [M.field('fp-binv-ch-method', t('binv_charge_method'), pick)]),
      el('div', {class: 'fp-actions', 'data-fp-charge-acts': ''}, [go])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!B.begin(form, go)) { return; }
      var m = sorted.filter(function (x) { return String(x.id) === pick.value; })[0];
      /* asked first, in place of the button: money is taken at once */
      var box = form.querySelector('[data-fp-charge-acts]');
      box.textContent = '';
      var qid = 'fp-binv-ch-q';
      var yes = el('button', {class: 'sig-btn sig-btn--danger', type: 'button', 'data-fp-act': 'charge-yes', text: t('binv_charge_yes'), 'aria-describedby': qid});
      var no = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'charge-no', text: t('binv_charge_keep'), 'aria-describedby': qid});
      box.appendChild(el('p', {class: 'fp-mail-confirm', id: qid, text: t('binv_charge_ask', {amount: B.money(v.balance_cents, v.currency), method: m ? m.label || B.gatewayText(m.gateway) : ''})}));
      box.appendChild(yes);
      box.appendChild(no);
      no.focus();
    });
    form.addEventListener('click', function (e) {
      var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
      if (!b || b.disabled) { return; }
      var a = b.getAttribute('data-fp-act');
      if (a === 'charge-no') {
        var fresh = chargeForm(v);
        form.replaceWith(fresh);
        fresh.querySelector('.fp-submit').focus();
      } else if (a === 'charge-yes') {
        var mine = I;
        UI.setBusy(b, true);
        FP.call('post', 'billingInvoiceCharge', {method_id: Number(pick.value)}, {id: String(v.id)}).then(function (r) {
          if (I !== mine) { return; }
          var tx = B.cleanTx(r && r.transaction);
          var w = B.cleanInvoice(r && r.invoice);
          var said = !tx ? t('binv_charged_unknown') : tx.status === 'succeeded' ? t('binv_charged', {amount: B.money(tx.amount_cents, tx.currency)}) :
            tx.status === 'pending' ? t('binv_charge_pending') : t('binv_charge_failed', {why: tx.error || t('binv_charge_no_reason')});
          reopen({sayIn: [w && w.status !== 'unpaid' ? 'head' : 'payments', said], focus: w && w.status !== 'unpaid' ? '#fp-binv-h' : '#fp-binv-pay-h'});
        }, function (err) {
          if (I !== mine) { return; }
          var fresh = chargeForm(v);
          form.replaceWith(fresh);
          B.failed(fresh, err);
          var marked = fresh.querySelector('[aria-invalid]');
          if (!marked) { fresh.querySelector('.fp-submit').focus(); }
        });
      }
    });
    return form;
  }

  /* ---- credit notes: money paid on a paid invoice taken back, as credit or as paid back outside the panel, asked first ---- */
  function cleanCreditNote(x) {
    var n = B.pick(x, {id: 'id', number: [40], invoice_id: 'id', amount_cents: 'c', currency: [3], method: ['=', ['credit', 'refund']], reason: [200], by: [64], created: 'w'});
    return n && n.id ? n : null;
  }
  function creditNotesCard(v) {
    var parts = [M.statusLine()];
    var notes = I.inv.notes;
    if (notes === null) {
      parts.push(el('p', {class: 'fp-muted', text: t('binv_cn_unread')}));
    } else if (!notes.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('binv_cn_none')}));
    } else {
      parts.push(B.table('fp-binv-cn-h', 'fp-binv-cn-table', [B.th(t('binv_cn_col_number')), B.th(t('binv_col_when')), B.th(t('binv_cn_col_method')), B.th(t('binv_col_amount'), 'fp-bil-num'),
        B.th(t('binv_cn_col_reason')), B.th(t('binv_cn_col_by'))], notes.map(function (n) {
        return el('tr', {'data-fp-cn': String(n.id)}, [el('th', {scope: 'row', text: n.number || '—'}), el('td', {class: 'fp-bil-nowrap', text: B.when(n.created) || '—'}),
          el('td', {text: t('binv_cn_' + (n.method || 'credit'))}), el('td', {class: 'fp-bil-num', text: B.money(n.amount_cents, n.currency || v.currency)}),
          el('td', {class: 'fp-bil-wrap', text: n.reason || '—'}), el('td', {text: n.by || '—'})]);
      })));
    }
    var left = v.paid_cents - v.credited_cents;
    if (v.status === 'paid' && left > 0) { parts.push(creditNoteForm(v, left)); }
    return named('fp-binv-cn-h', t('binv_cn_title'), parts, 'fp-binv-cn', 'credit-notes');
  }
  function creditNoteForm(v, left) {
    var how = B.select('fp-binv-cn-method', 'method', [['credit', t('binv_cn_credit_long')], ['refund', t('binv_cn_refund_long')]], 'credit');
    var amount = B.input('fp-binv-cn-amount', 'amount_cents', B.amountText(left), {inputmode: 'decimal', maxlength: '16', class: 'sig-input fp-bil-amount'});
    var reason = B.input('fp-binv-cn-reason', 'reason', '', {maxlength: '200', 'aria-required': 'true'});
    var go = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('binv_cn_make')});
    var asked = null;
    var form = el('form', {class: 'fp-form fp-binv-cn-form', novalidate: '', 'aria-labelledby': 'fp-binv-cn-form-h'}, [M.errorLine(),
      el('h3', {class: 'fp-h3', id: 'fp-binv-cn-form-h', text: t('binv_cn_form_title')}), el('p', {class: 'fp-muted fp-row-note', text: t('binv_cn_what', {amount: B.money(left, v.currency)})}),
      el('div', {class: 'fp-bil-grid'}, [M.field('fp-binv-cn-method', t('binv_cn_method'), how), M.field('fp-binv-cn-amount', t('binv_cn_amount'), amount, t('bil_amount_hint')),
        M.field('fp-binv-cn-reason', t('binv_cn_reason'), reason, t('binv_cn_reason_hint'))]),
      el('div', {class: 'fp-actions', 'data-fp-cn-acts': ''}, [go])]);
    function restore(focus) {
      asked = null;
      var box = form.querySelector('[data-fp-cn-acts]');
      box.textContent = '';
      box.appendChild(go);
      UI.setBusy(go, false);
      if (focus) { go.focus(); }
    }
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!B.begin(form, go)) { return; }
      var c = B.parseAmount(amount.value, false);
      if (!c) { M.fieldError(form, amount, t('bil_amount_bad')); return; }
      if (!reason.value.trim()) { M.fieldError(form, reason, t('binv_cn_reason_needed')); return; }
      asked = {method: how.value, amount: c, reason: reason.value.trim()};
      var box = form.querySelector('[data-fp-cn-acts]');
      box.textContent = '';
      var qid = 'fp-binv-cn-q';
      var yes = el('button', {class: 'sig-btn sig-btn--danger', type: 'button', 'data-fp-act': 'cn-yes', text: t('binv_cn_yes'), 'aria-describedby': qid});
      var no = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'cn-no', text: t('binv_cn_keep'), 'aria-describedby': qid});
      box.appendChild(el('p', {class: 'fp-mail-confirm', id: qid, text: t(asked.method === 'refund' ? 'binv_cn_ask_refund' : 'binv_cn_ask_credit', {amount: B.money(c, v.currency)})}));
      box.appendChild(yes);
      box.appendChild(no);
      no.focus();
    });
    form.addEventListener('click', function (e) {
      var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
      if (!b || b.disabled) { return; }
      var a = b.getAttribute('data-fp-act');
      if (a === 'cn-no') {
        restore(true);
      } else if (a === 'cn-yes' && asked) {
        var mine = I;
        var body = {method: asked.method, reason: asked.reason};
        if (asked.amount !== left) { body.amount_cents = asked.amount; }
        var sent = asked;
        UI.setBusy(b, true);
        FP.call('post', 'billingInvoiceCreditNotes', body, {id: String(v.id)}).then(function (r) {
          if (I !== mine) { return; }
          var n = cleanCreditNote(r && r.credit_note);
          reopen({sayIn: ['credit-notes', t(sent.method === 'refund' ? 'binv_cn_made_refund' : 'binv_cn_made_credit', {number: n ? n.number : '', amount: B.money(sent.amount, v.currency)})],
            focus: '#fp-binv-cn-h'});
        }, function (err) {
          if (I !== mine) { return; }
          restore(false);
          B.failed(form, err);
          if (!form.querySelector('[aria-invalid]')) { go.focus(); }
        });
      }
    });
    return form;
  }

  /* ---- Merge: this invoice and others of the same client, all unpaid with nothing paid, onto one new invoice; asked in place of the
     head's buttons ---- */
  function askMerge() {
    var v = I.inv.v;
    var box = card('head').querySelector('[data-fp-acts]');
    box.textContent = '';
    var others = I.inv.mergeable;
    var checks = others.map(function (w) {
      var fid = 'fp-binv-m-' + w.id;
      return el('label', {class: 'fp-bil-check', for: fid}, [el('input', {type: 'checkbox', id: fid, name: 'invoice_ids', value: String(w.id)}),
        el('span', {text: t('binv_merge_item', {name: B.invoiceName(w), amount: B.money(w.total_cents, w.currency), due: B.day(w.due_on) || '—'})})]);
    });
    var yes = el('button', {class: 'sig-btn sig-btn--danger fp-submit', type: 'submit', text: t('binv_merge_yes'), 'aria-describedby': 'fp-binv-m-q'});
    var no = B.button('merge-no', t('binv_merge_keep'), 'sig-btn--secondary', {'aria-describedby': 'fp-binv-m-q'});
    var form = el('form', {class: 'fp-form fp-binv-merge', novalidate: '', 'aria-label': t('binv_merge_label')}, [M.errorLine(),
      el('p', {class: 'fp-mail-confirm', id: 'fp-binv-m-q', text: t('binv_merge_ask', {name: B.invoiceName(v)})}),
      el('fieldset', {class: 'fp-bil-set'}, [el('legend', {class: 'sig-label', text: t('binv_merge_with')}), el('div', {class: 'fp-bil-checks fp-binv-merge-list'}, checks)]),
      el('div', {class: 'fp-actions'}, [yes, no])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!B.begin(form, yes)) { return; }
      var ids = Array.prototype.filter.call(form.querySelectorAll('[name="invoice_ids"]'), function (c) { return c.checked; }).map(function (c) { return Number(c.value); });
      if (!ids.length) { M.fieldError(form, form.querySelector('[name="invoice_ids"]'), t('binv_merge_none')); return; }
      var mine = I;
      UI.setBusy(yes, true);
      FP.call('post', 'billingInvoicesMerge', {invoice_ids: [v.id].concat(ids).sort(function (a, b) { return a - b; })}).then(function (r) {
        if (I !== mine) { return; }
        var w = B.cleanInvoice(r);
        if (!w) { throw {message: t('api_failed')}; }
        openInvoice(w.id, {say: t('binv_merged', {name: B.invoiceName(w), n: B.num(ids.length + 1)}), focus: '#fp-binv-h'});
      }).catch(function (err) {
        if (I !== mine) { return; }
        UI.setBusy(yes, false);
        B.failed(form, err.field === 'invoice_ids' ? Object.assign({}, err, {field: ''}) : err);
        no.focus();
      });
    });
    box.appendChild(form);
    no.focus();
  }

  function notesCard(v) {
    var parts = [M.statusLine()];
    if (v.status === 'draft') {
      var note = el('textarea', {class: 'sig-input fp-bil-text', id: 'fp-binv-e-note', name: 'note', rows: '3', maxlength: '500'});
      note.value = v.note;
      var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('binv_save_note')});
      var form = el('form', {class: 'fp-form fp-binv-note', novalidate: '', 'aria-labelledby': 'fp-binv-notes-h'}, [M.errorLine(),
        M.field('fp-binv-e-note', t('binv_note'), note, t('binv_note_hint')), el('div', {class: 'fp-actions'}, [save])]);
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!B.begin(form, save)) { return; }
        if (note.value.trim() === v.note) { M.say(card('notes'), t('bil_nothing_changed')); return; }
        var mine = I;
        UI.setBusy(save, true);
        FP.call('patch', 'billingInvoice', {note: note.value}, {id: String(v.id)}).then(function () {
          if (I !== mine) { return; }
          reopen({sayIn: ['notes', t('binv_note_saved')], focus: '#fp-binv-e-note'});
        }, function (err) {
          if (I !== mine) { return; }
          UI.setBusy(save, false);
          B.failed(form, err);
        });
      });
      parts.push(form);
    } else {
      parts.push(el('p', {class: 'fp-muted fp-row-note', text: t('binv_note_fixed')}));
      parts.push(v.note ? el('p', {class: 'fp-bil-note-body', 'data-fp-note': '', text: v.note}) : el('p', {class: 'fp-muted', text: t('binv_no_note')}));
    }
    return named('fp-binv-notes-h', t('binv_notes'), parts, 'fp-binv-notes', 'notes');
  }

  /* ---- Cancel and Remove draft, asked in place of the head's buttons ---- */
  function askCancel() {
    var box = card('head').querySelector('[data-fp-acts]');
    box.textContent = '';
    var reason = B.input('fp-binv-x-reason', 'reason', '', {maxlength: '200'});
    var yes = el('button', {class: 'sig-btn sig-btn--danger fp-submit', type: 'submit', text: t('binv_cancel_yes'), 'aria-describedby': 'fp-binv-x-q'});
    var no = B.button('cancel-no', t('binv_cancel_keep'), 'sig-btn--secondary', {'aria-describedby': 'fp-binv-x-q'});
    var form = el('form', {class: 'fp-form fp-binv-cancel', novalidate: '', 'aria-label': t('binv_cancel_label')}, [M.errorLine(),
      el('p', {class: 'fp-mail-confirm', id: 'fp-binv-x-q', text: t('binv_cancel_ask')}), M.field('fp-binv-x-reason', t('binv_cancel_reason'), reason, t('binv_cancel_reason_hint')),
      el('div', {class: 'fp-actions'}, [yes, no])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!B.begin(form, yes)) { return; }
      var mine = I;
      UI.setBusy(yes, true);
      FP.call('post', 'billingInvoiceCancel', reason.value.trim() ? {reason: reason.value.trim()} : {}, {id: String(I.inv.v.id)}).then(function () {
        if (I !== mine) { return; }
        reopen({say: t('binv_cancelled'), focus: '#fp-binv-h'});
      }, function (err) {
        if (I !== mine) { return; }
        UI.setBusy(yes, false);
        B.failed(form, err);
      });
    });
    box.appendChild(form);
    no.focus();
  }
  function removeDraft(b) {
    var mine = I;
    var v = I.inv.v;
    UI.setBusy(b, true);
    UI.showError(card('head'), '');
    FP.call('del', 'billingInvoice', undefined, {id: String(v.id)}).then(function () {
      if (I !== mine) { return; }
      showList('#fp-binv-list-h', t('binv_removed', {name: B.invoiceName(v)}));
    }, function (err) {
      if (I !== mine) { return; }
      UI.setBusy(b, false);
      UI.showError(card('head'), err.message);
      b.focus();
    });
  }
  function restoreHead(focus) {
    var old = card('head');
    var keep = old.querySelector('[data-fp-status]').textContent;
    var made = headCard(I.inv.v);
    old.replaceWith(made);
    M.say(made, keep);
    var f = made.querySelector(focus);
    if (f) { f.focus(); }
  }

  function onClick(e) {
    var target = e.target && e.target.closest ? e.target : null;
    if (!target || !I || !I.page.isConnected || !I.page.contains(target)) { return; }
    var b = target.closest('[data-fp-act]');
    if (!b || b.disabled) { return; }
    var a = b.getAttribute('data-fp-act');
    var xid = Number(b.getAttribute('data-fp-id')) || 0;
    if (a === 'create') {
      showCreate(I.filters.client ? Number(I.filters.client) : 0);
    } else if (a === 'create-cancel' || a === 'to-list') {
      var from = I.inv ? I.inv.v.id : 0;
      showList(from ? '[data-fp-act="open"][data-fp-id="' + from + '"]' : '#fp-binv-list-h');
    } else if (a === 'generate') {
      generate(b);
    } else if (a === 'clear') {
      I.filters = {status: '', client: '', overdue: false};
      I.offset = 0;
      var form = I.page.querySelector('.fp-bil-filters');
      form.querySelector('[name="status"]').value = '';
      form.querySelector('[name="status"]').disabled = false;
      form.querySelector('[name="customer"]').value = '';
      form.querySelector('[name="find_client"]').value = '';
      form.querySelector('[name="overdue"]').checked = false;
      refreshList(null, '#fp-binv-status');
    } else if (a === 'prev' || a === 'next') {
      I.offset = Math.max(0, I.offset + (a === 'next' ? PAGE : -PAGE));
      refreshList(b, '#fp-binv-list-h');
    } else if (a === 'reload') {
      showList();
    } else if (a === 'open' && xid) {
      openInvoice(xid);
    } else if (a === 'open-client' && xid) {
      B.go('billing_clients', {client: xid});
    } else if (a === 'refund') {
      var tr = b.closest('tr');
      var open = I.page.querySelector('[data-fp-refund]');
      if (open) { open.remove(); }
      var x = (I.inv.txs || []).filter(function (y) { return y.id === xid; })[0];
      if (!x) { return; }
      var rr = refundRow(x);
      tr.after(rr);
      rr.querySelector('input[name="reason"]').focus();
    } else if (a === 'refund-no') {
      var row = b.closest('tr');
      row.remove();
      var back = I.page.querySelector('[data-fp-act="refund"][data-fp-id="' + xid + '"]');
      if (back) { back.focus(); }
    } else if (a === 'merge') {
      askMerge();
    } else if (a === 'merge-no') {
      restoreHead('[data-fp-act="merge"]');
    } else if (a === 'cancel') {
      askCancel();
    } else if (a === 'cancel-no') {
      restoreHead('[data-fp-act="cancel"]');
    } else if (a === 'remove') {
      M.confirmIn(b.closest('[data-fp-acts]'), t('binv_remove_ask'), 'remove-yes', t('binv_remove_yes'));
    } else if (a === 'remove-yes') {
      removeDraft(b);
    } else if (a === 'confirm-no') {
      restoreHead('[data-fp-act="remove"]');
    }
  }
  document.addEventListener('click', onClick);

  FP.view('tool:billing_invoices', function () {
    var page = B.frame('billing_invoices', 'fp-binv');
    if (!page) { return; }
    I = {page: page, view: 'list', filters: {status: '', client: '', overdue: false}, offset: 0, data: null, names: {}, clients: [], inv: null};
    var mine = I;
    var handed = B.take('billing_invoices');
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    loadClients().then(function () {
      if (I !== mine) { return; }
      if (handed && B.id(handed.invoice)) {
        openInvoice(handed.invoice);
      } else if (handed && B.id(handed.create)) {
        showCreate(handed.create);
      } else {
        showList();
      }
    });
  });
})();

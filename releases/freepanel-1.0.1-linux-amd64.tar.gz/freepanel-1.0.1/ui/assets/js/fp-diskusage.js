/* freePanel disk usage (#/tool/disk_usage), the customer panel's page for where the account's disk space goes (docs/api.md,
   "File manager", GET .../files/usage): the folder being looked at with its total, and what is in it, the biggest first,
   each with the files and folders under it. Opening a folder measures that one. Measuring a big home can take up to a
   minute, so the call keeps waiting; the server keeps an answer for 30 seconds. Names and the server's words are shown
   as text only. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;

  var TYPES = {file: true, folder: true, link: true, other: true};
  var UNITS = ['KB', 'MB', 'GB', 'TB', 'PB'];

  var page = null;      /* the frame's body */
  var account = '';
  var cwd = '';         /* the folder looked at, relative to the home; '' is the home */
  var data = null;      /* what was last measured, cleaned */
  var loading = false;  /* a measurement is going: the server allows one per account */

  function str(v) { return typeof v === 'string' ? v : ''; }
  function num(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? v : 0; }
  function whole(v) { return Math.round(num(v)); }
  function count(n) { return Math.round(n).toLocaleString('en'); }
  function join(a, b) { return a ? a + '/' + b : b; }
  function parent(p) { return p.indexOf('/') >= 0 ? p.slice(0, p.lastIndexOf('/')) : ''; }
  /* a path for the API: the home is '.', since a path can't be empty in a call */
  function apiPath(p) { return p || '.'; }
  function where(p) { return p ? '/' + p : t('fm_home'); }
  /* sizes the way hosting panels show them: binary steps named KB, MB, GB, TB */
  function size(n) {
    if (n < 1024) { return t('size_bytes', {n: String(Math.round(n))}); }
    var u = -1;
    do { n /= 1024; u++; } while (n >= 1024 && u < UNITS.length - 1);
    return (n < 10 ? n.toFixed(1) : count(n)) + ' ' + UNITS[u];
  }
  function when(sec) {
    var d = new Date(sec * 1000);
    return isNaN(d.getTime()) ? '' : d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'});
  }
  function plural(n, one, many) { return t(n === 1 ? one : many, {n: count(n)}); }

  function entryOf(e) {
    if (!e || typeof e !== 'object' || !TYPES[e.type]) { return null; }
    var name = str(e.name);
    if (!name || name.indexOf('/') >= 0 || name === '.' || name === '..' || name.length > 1024) { return null; }
    return {name: name, type: e.type, bytes: num(e.bytes), files: whole(e.files), folders: whole(e.folders)};
  }
  /* the reply with what can't be drawn left out, the biggest first as the server sends it */
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var entries = (Array.isArray(r.entries) ? r.entries : []).map(entryOf).filter(Boolean);
    entries.sort(function (a, b) { return b.bytes - a.bytes || (a.name < b.name ? -1 : a.name > b.name ? 1 : 0); });
    return {bytes: num(r.bytes), files: whole(r.files), folders: whole(r.folders), unreadable: whole(r.unreadable), partial: r.partial === true,
      truncated: r.truncated === true, measured: num(r.measured_at), entries: entries};
  }

  /* the server's words, with ours for being busy and, when a folder was asked for, for it having gone */
  function message(err, folder) {
    if (err && err.code === 'rate_limited') { return t('du_busy'); }
    if (folder && err && err.code === 'not_found') { return t('du_gone'); }
    return err && err.message ? err.message : t('api_failed');
  }

  /* ---- page pieces ---- */
  function card(id, title, children, cls) {
    return el('section', {class: 'sig-card fp-du-card' + (cls ? ' ' + cls : ''), 'aria-labelledby': id}, [el('div', {class: 'sig-card-body'},
      [el('h2', {class: 'fp-h2', id: id, tabindex: '-1', text: title})].concat(children))]);
  }
  function errorLine() { return el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': ''}); }
  function statusLine() { return el('p', {class: 'fp-ok-line', role: 'status', 'data-fp-status': ''}); }
  function say(scope, text) {
    var s = scope && scope.querySelector('[data-fp-status]');
    if (s) { s.textContent = text || ''; }
  }
  function button(text, act, extra) {
    return el('button', Object.assign({class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': act, text: text}, extra || {}));
  }
  function icon(e) {
    return UI.icon(FP.ui, e.type === 'folder' ? 'ui_folder' : e.type === 'link' ? 'ui_link' : e.type === 'file' ? 'ui_file' : 'ui_other', 'fp-fm-ico');
  }

  /* ---- where we are ---- */
  function placeCard() {
    var parts = cwd ? cwd.split('/') : [];
    var ol = el('ol', {class: 'fp-fm-path'});
    ol.appendChild(el('li', null, [parts.length ? button(t('fm_home'), 'go', {'data-fp-path': ''}) : el('span', {'aria-current': 'location', text: t('fm_home')})]));
    parts.forEach(function (p, i) {
      var to = parts.slice(0, i + 1).join('/');
      ol.appendChild(el('li', null, [i === parts.length - 1 ? el('span', {'aria-current': 'location', text: p}) : button(p, 'go', {'data-fp-path': to})]));
    });
    return card('fp-du-place-h', t('du_place_title'), [
      el('nav', {'aria-label': t('fm_path_label')}, [ol]),
      el('div', {class: 'fp-fm-tools'}, [button(t('fm_up'), 'up', {disabled: !cwd}), button(t('du_again'), 'again')])]);
  }

  /* ---- what is in the folder ---- */
  function nameCell(e) {
    var parts = [icon(e)];
    if (e.type === 'folder') {
      parts.push(el('button', {class: 'fp-fm-name fp-linkbtn', type: 'button', 'data-fp-act': 'go', 'data-fp-path': join(cwd, e.name), text: e.name}),
        el('span', {class: 'sig-vh', text: ' (' + t('fm_type_folder') + ')'}),
        el('span', {class: 'fp-muted fp-du-tag', 'data-fp-inside': '', text: e.files || e.folders ? t('du_inside', {files: plural(e.files, 'du_files_one', 'du_files'),
          folders: plural(e.folders, 'du_folders_one', 'du_folders')}) : t('du_empty_folder')}));
    } else {
      parts.push(el('span', {class: 'fp-fm-name', text: e.name}));
      if (e.type === 'link') {
        parts.push(el('span', {class: 'sig-vh', text: ' (' + t('fm_type_link') + ')'}), el('span', {class: 'fp-muted fp-du-tag', 'aria-hidden': 'true', text: t('du_link_note')}));
      } else if (e.type === 'other') {
        parts.push(el('span', {class: 'fp-muted fp-du-tag', text: t('fm_type_other')}));
      }
    }
    return el('th', {scope: 'row', class: 'fp-du-namecell'}, parts);
  }
  /* the space an entry takes, as a size, its share of the folder in words, and as a bar for the eye */
  function shareCell(e) {
    var pct = data.bytes > 0 ? Math.round(e.bytes / data.bytes * 100) : 0;
    var bar = el('i');
    bar.style.width = Math.min(100, Math.max(e.bytes > 0 ? 1 : 0, pct)) + '%';
    return el('td', {class: 'fp-num'}, [el('span', {text: size(e.bytes)}),
      el('span', {class: 'fp-muted fp-du-pct', text: ' (' + (e.bytes > 0 && pct === 0 ? t('du_pct_small') : t('du_pct', {n: String(pct)})) + ')'}),
      el('div', {class: 'sig-meter', 'aria-hidden': 'true'}, [bar])]);
  }
  function row(e) {
    return el('tr', {'data-fp-entry': e.name}, [nameCell(e), shareCell(e)]);
  }
  function banner(text, attr) {
    var b = el('div', {class: 'sig-banner sig-banner--warn', role: 'note'}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: text})]);
    b.setAttribute(attr, '');
    return b;
  }
  function listCard() {
    var parts = [errorLine(), statusLine(),
      el('p', {class: 'fp-du-summary', 'data-fp-summary': '', text: t('du_summary', {where: where(cwd), size: size(data.bytes),
        files: plural(data.files, 'du_files_one', 'du_files'), folders: plural(data.folders, 'du_folders_one', 'du_folders')})})];
    if (data.measured && when(data.measured)) { parts.push(el('p', {class: 'fp-muted fp-du-when', 'data-fp-measured': '', text: t('du_measured', {when: when(data.measured)})})); }
    if (data.partial) { parts.push(banner(t('du_partial'), 'data-fp-partial')); }
    if (data.unreadable) { parts.push(banner(plural(data.unreadable, 'du_unreadable_one', 'du_unreadable'), 'data-fp-unreadable')); }
    if (!data.entries.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('du_none')}));
    } else {
      var head = el('tr', null, [el('th', {scope: 'col', text: t('du_col_name')}), el('th', {scope: 'col', class: 'fp-num', text: t('du_col_size')})]);
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-du-list-h'}, [
        el('table', {class: 'sig-table fp-du-table'}, [el('thead', null, [head]), el('tbody', null, data.entries.map(row))])]));
    }
    if (data.truncated) { parts.push(el('p', {class: 'fp-muted', 'data-fp-truncated': '', text: t('du_truncated', {n: count(data.entries.length)})})); }
    parts.push(el('p', {class: 'fp-muted fp-du-note', text: t('du_note')}));
    var tool = FP.tools.file_manager;
    if (tool) {
      parts.push(el('p', {class: 'fp-muted fp-du-free'}, [document.createTextNode(t('du_free') + ' '), el('a', {href: '#/tool/file_manager', text: tool.label}),
        document.createTextNode('.')]));
    }
    return card('fp-du-list-h', t('du_list_title', {where: where(cwd)}), parts, 'fp-du-list');
  }

  function render() {
    page.textContent = '';
    page.appendChild(placeCard());
    page.appendChild(listCard());
  }

  /* measure a folder; on success it becomes the one looked at. note goes in the list's status line */
  function load(to, note) {
    if (loading) { return; }
    var view = page;
    var first = data === null;
    var list = page.querySelector('.fp-du-list');
    loading = true;
    if (first) {
      page.textContent = '';
      page.appendChild(el('p', {class: 'fp-muted', role: 'status', 'data-fp-measuring': '', text: t('du_measuring', {where: where(to)})}));
    } else if (list) {
      list.setAttribute('aria-busy', 'true');
      UI.showError(list, '');
      say(list, t('du_measuring', {where: where(to)}));
    }
    FP.call('get', 'fileUsage', undefined, {name: account, path: apiPath(to)}).then(function (r) {
      if (page !== view) { return; }
      loading = false;
      cwd = to;
      data = clean(r);
      render();
      say(page.querySelector('.fp-du-list'), note || '');
      if (!first) { page.querySelector('#fp-du-list-h').focus(); }
    }, function (err) {
      if (page !== view) { return; }
      loading = false;
      if (first) {
        page.textContent = '';
        page.appendChild(FP.empty(FP.tools.disk_usage.label, message(err), button(t('du_retry'), 'retry')));
        return;
      }
      /* stay where we were, saying why the folder wasn't measured */
      if (list) {
        list.removeAttribute('aria-busy');
        say(list, '');
        UI.showError(list, message(err, true));
      }
    });
  }

  function onClick(e) {
    var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !page || !page.contains(b) || b.disabled) { return; }
    var act = b.getAttribute('data-fp-act');
    if (act === 'go') {
      load(b.getAttribute('data-fp-path') || '', '');
    } else if (act === 'up') {
      load(parent(cwd), '');
    } else if (act === 'again') {
      load(cwd, t('du_again_done'));
    } else if (act === 'retry') {
      load('', '');
    }
  }

  FP.view('tool:disk_usage', function () {
    var tool = FP.tools.disk_usage;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    account = FP.account();
    cwd = '';
    data = null;
    loading = false;
    page = FP.frame({title: tool.label, desc: t('du_desc'), cls: 'fp-du',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    page.addEventListener('click', onClick);
    load('', '');
  });
})();

/* freePanel IPv6 for sites (docs/api.md, "DNS zones", IPv6 on sites): the admin panel's page (#/tool/dns_ipv6) for the server's IPv6 address, the address new
   zones get an AAAA record for beside the A record. It shows the address, chooses one of the server's own global addresses (or none), and shows
   which of the server's services accept connections over IPv6 at ::1 and at that address. A second step gives every zone that exists AAAA records for it
   (or takes them away); the server stops when it runs out of time and the page says to run it again. Admin only: the server refuses these calls to
   anyone else. Everything the server sends is shown as text. The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var IP6_RE = /^[0-9A-Fa-f:]{2,39}$/;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  function v6(v) { v = str(v, 45); return v.indexOf(':') > 0 && IP6_RE.test(v) ? v : ''; }
  function whole(v) { return typeof v === 'number' && isFinite(v) && v >= 0 && Math.floor(v) === v ? v : 0; }
  function clean(v) {
    v = v && typeof v === 'object' ? v : {};
    var seen = {};
    return {address: v6(v.address), onServer: v.on_server === true,
      addresses: (Array.isArray(v.addresses) ? v.addresses : []).map(v6).filter(function (a) {
        if (!a || seen[a]) { return false; }
        seen[a] = true;
        return true;
      }).slice(0, 32),
      listeners: (Array.isArray(v.listeners) ? v.listeners : []).filter(function (l) { return l && typeof l === 'object' && str(l.service, 60); }).slice(0, 40).map(function (l) {
        return {service: str(l.service, 60), port: whole(l.port), address: str(l.address, 45), open: l.open === true};
      })};
  }
  function bulk(r) {
    r = r && typeof r === 'object' ? r : {};
    return {zones: whole(r.zones), changed: whole(r.changed), names: whole(r.names), done: r.done !== false,
      errors: (Array.isArray(r.errors) ? r.errors : []).filter(function (e) { return typeof e === 'string' && e; }).map(function (e) { return e.slice(0, 300); }).slice(0, 50)};
  }

  var V = {page: null, S: null, busy: false, last: null};

  function addressCard() {
    var S = V.S;
    var parts = [M.statusLine()];
    parts.push(el('p', {class: 'fp-v6s-now', 'data-fp-address': S.address ? 'set' : 'none'}, [el('span', {class: 'sig-pill' + (S.address ? ' sig-pill--accent' : ''), text: S.address ? t('v6s_pill_set') : t('v6s_pill_none')}),
      ' ', S.address ? el('span', {class: 'sig-mono', text: S.address}) : el('span', {text: t('v6s_none')})]));
    if (S.address && !S.onServer) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-v6s-gone': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('v6s_gone', {address: S.address})})]));
    }
    parts.push(el('p', {class: 'fp-muted', text: t('v6s_what')}));
    if (!S.addresses.length && !S.address) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-v6s-no-global': '', text: t('v6s_no_global')}));
      return M.card('fp-v6s-addr-h', t('v6s_title'), parts, 'fp-v6s-addr');
    }
    var options = [el('option', {value: '', text: t('v6s_option_none')})];
    var list = S.addresses.slice();
    if (S.address && list.indexOf(S.address) < 0) { list.unshift(S.address); }
    list.forEach(function (a) { options.push(el('option', {value: a, text: a + (S.addresses.indexOf(a) < 0 ? ' ' + t('v6s_option_gone') : '')})); });
    var sel = el('select', {class: 'sig-select sig-mono', id: 'fp-v6s-address', name: 'address', 'aria-describedby': 'fp-v6s-address-hint'}, options);
    sel.value = S.address;
    var form = el('form', {class: 'fp-form fp-v6s-form', novalidate: ''}, [M.errorLine(), M.field('fp-v6s-address', t('v6s_choose'), sel, t('v6s_choose_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('v6s_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || V.busy) { return; }
      V.busy = true;
      UI.setBusy(b, true);
      var mine = V.page;
      FP.call('put', 'dnsIpv6', {address: sel.value}).then(function (r) {
        V.busy = false;
        if (V.page !== mine) { return; }
        V.S = clean(r);
        V.last = null; /* what the last run did was for the address before this one */
        render();
        M.say(V.page.querySelector('.fp-v6s-addr'), V.S.address ? t('v6s_saved', {address: V.S.address}) : t('v6s_saved_none'));
        /* the form is gone when the server has no global address left to choose, and the card's heading has the focus then */
        (V.page.querySelector('#fp-v6s-address') || V.page.querySelector('#fp-v6s-addr-h')).focus();
      }, function (err) {
        V.busy = false;
        if (V.page !== mine) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    parts.push(form);
    return M.card('fp-v6s-addr-h', t('v6s_title'), parts, 'fp-v6s-addr');
  }
  function listenersCard() {
    var S = V.S;
    var by = Object.create(null); /* keyed by the server's text, so a key such as __proto__ is only a key */
    var order = [];
    S.listeners.forEach(function (l) {
      if (!by[l.address]) { by[l.address] = []; order.push(l.address); }
      by[l.address].push(l);
    });
    var parts = [el('p', {class: 'fp-muted', text: t('v6s_listen_what')})];
    if (!order.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('v6s_listen_none')}));
    } else {
      order.forEach(function (a, i) {
        var h = 'fp-v6s-l' + i + '-h';
        parts.push(el('h3', {class: 'fp-h3 sig-mono', id: h, text: a === '::1' ? t('v6s_loopback', {address: a}) : t('v6s_server_address', {address: a})}));
        parts.push(el('ul', {class: 'fp-v6s-listen', 'aria-labelledby': h, 'data-fp-listeners': a}, by[a].map(function (l) {
          return el('li', {class: 'fp-v6s-svc'}, [el('span', {class: 'fp-v6s-svc-name', text: l.service + ' · ' + l.port}),
            el('span', {class: 'sig-pill ' + (l.open ? 'sig-pill--ok' : 'sig-pill--warn'), text: l.open ? t('v6s_open') : t('v6s_closed')})]);
        })));
      });
      parts.push(el('p', {class: 'fp-muted', text: t('v6s_closed_what')}));
    }
    return M.card('fp-v6s-listen-h', t('v6s_listen_title'), parts, 'fp-v6s-listencard');
  }
  function resultView() {
    var r = V.last;
    if (!r) { return null; }
    var out = [el('p', {class: 'fp-v6s-summary', 'data-fp-summary': r.done ? 'done' : 'partial', text: t(r.done ? 'v6s_summary' : 'v6s_summary_partial', {zones: r.zones, changed: r.changed, names: r.names})})];
    if (!r.done) { out.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-v6s-again': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('v6s_again')})])); }
    if (r.errors.length) {
      out.push(el('p', {class: 'fp-v6s-errs-h', text: t('v6s_errors')}));
      out.push(el('ul', {class: 'fp-v6s-errors', 'data-fp-errors': ''}, r.errors.map(function (e) { return el('li', {text: e}); })));
    }
    return el('div', {class: 'fp-v6s-result', role: 'region', 'aria-label': t('v6s_result')}, out);
  }
  function zonesCard() {
    var S = V.S;
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t('v6s_zones_what')}), el('p', {class: 'fp-muted', text: t('v6s_zones_each')})];
    var acts = el('div', {class: 'fp-actions fp-v6s-acts'}, [
      el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'v6s-on', disabled: S.address ? null : true, text: t('v6s_all_on')}),
      el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'v6s-off', text: t('v6s_all_off')})]);
    parts.push(acts);
    if (!S.address) { parts.push(el('p', {class: 'fp-muted sig-hint', 'data-fp-v6s-needs': '', text: t('v6s_needs_address')})); }
    var res = resultView();
    if (res) { parts.push(res); }
    return M.card('fp-v6s-zones-h', t('v6s_zones_title'), parts, 'fp-v6s-zonescard');
  }
  function render() {
    V.page.textContent = '';
    V.page.appendChild(addressCard());
    V.page.appendChild(listenersCard());
    V.page.appendChild(zonesCard());
  }

  function runAll(b, enabled) {
    if (V.busy) { return; }
    V.busy = true;
    UI.setBusy(b, true);
    var mine = V.page;
    FP.call('post', 'dnsIpv6Zones', {enabled: enabled}).then(function (r) {
      V.busy = false;
      if (V.page !== mine) { return; }
      V.last = bulk(r);
      render();
      M.say(V.page.querySelector('.fp-v6s-zonescard'), t(V.last.done ? 'v6s_all_done' : 'v6s_all_partial'));
      V.page.querySelector('[data-fp-act="' + (enabled ? 'v6s-on' : 'v6s-off') + '"]').focus();
    }, function (err) {
      V.busy = false;
      if (V.page !== mine) { return; }
      render();
      UI.showError(V.page.querySelector('.fp-v6s-zonescard'), err.message);
      V.page.querySelector('[data-fp-act="' + (enabled ? 'v6s-on' : 'v6s-off') + '"]').focus();
    });
  }
  document.addEventListener('click', function (e) {
    var node = e.target.closest ? e.target : null;
    var b = node && node.closest('[data-fp-act]');
    if (!b || !V.page || !V.page.contains(b) || !V.S) { return; }
    var a = b.getAttribute('data-fp-act');
    if (a === 'v6s-on') {
      M.confirmIn(b.parentNode, t('v6s_ask_on', {address: V.S.address}), 'v6s-on-yes', t('v6s_ask_on_yes'));
    } else if (a === 'v6s-off') {
      M.confirmIn(b.parentNode, t('v6s_ask_off', {address: V.S.address || t('v6s_the_address')}), 'v6s-off-yes', t('v6s_ask_off_yes'));
    } else if (a === 'confirm-no') {
      render();
      var back = V.page.querySelector('[data-fp-act="v6s-on"]:not([disabled]), [data-fp-act="v6s-off"]');
      if (back) { back.focus(); }
    } else if (a === 'v6s-on-yes') {
      runAll(b, true);
    } else if (a === 'v6s-off-yes') {
      runAll(b, false);
    }
  });

  FP.view('tool:dns_ipv6', function () {
    var tool = FP.tools.dns_ipv6;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    V.S = null;
    V.busy = false;
    V.last = null;
    var body = FP.frame({title: tool.label, desc: t('v6s_desc'), cls: 'fp-mail fp-srv fp-v6s-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    V.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'dnsIpv6').then(function (r) {
      if (V.page !== body) { return; }
      V.S = clean(r);
      render();
    }, function (err) {
      if (V.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

/* freePanel's own settings in the admin panel (docs/api.md, "Panel settings"): #/tool/server_settings shows every server-wide
   option the server lists, in its sections, each with its value now, its default, its bounds and whether it was changed, and
   saves a section at a time with PUT /server/panel-settings: the options that changed, and null for one put back to its default.
   Admin only: the server refuses these calls to anyone else.
   The list, the bounds and the defaults come from the server; an option this page has no words for is still shown, by its id.
   Every value is checked here and again by the server, which also holds the pairs (an idle time never longer than its session,
   a token's default never longer than its most) and names the option it refuses. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var SECTIONS = ['sign_in', 'support', 'integrations', 'customers'];
  var ID_RE = /^[a-z][a-z0-9_]{0,63}$/;
  var WORD_RE = /^[a-z][a-z0-9_]{0,31}$/;
  var MOST = 999999999; /* nine digits, the most the server reads */

  function has(key) { return Object.prototype.hasOwnProperty.call(window.FPSTRINGS || {}, key); }
  function whole(v) { return typeof v === 'number' && isFinite(v) && Math.floor(v) === v && Math.abs(v) <= MOST ? v : null; }

  /* one setting as the server sends it, or null when it is not one this page can show */
  function cleanSetting(x) {
    if (!x || typeof x !== 'object' || typeof x.id !== 'string' || !ID_RE.test(x.id)) { return null; }
    var s = {id: x.id, section: SECTIONS.indexOf(x.section) >= 0 ? x.section : 'other', custom: x.custom === true};
    if (x.kind === 'choice') {
      var choices = (Array.isArray(x.choices) ? x.choices : []).filter(function (w) { return typeof w === 'string' && WORD_RE.test(w); });
      if (!choices.length || choices.indexOf(x.value) < 0 || choices.indexOf(x['default']) < 0) { return null; }
      s.kind = 'choice';
      s.choices = choices;
      s.value = x.value;
      s.def = x['default'];
      return s;
    }
    if (x.kind !== 'number' || typeof x.unit !== 'string' || !WORD_RE.test(x.unit)) { return null; }
    var v = whole(x.value), d = whole(x['default']), lo = whole(x.min === undefined ? 0 : x.min), hi = whole(x.max);
    if (v === null || d === null || lo === null || hi === null || lo > hi) { return null; }
    s.kind = 'number';
    s.unit = x.unit;
    s.value = v;
    s.def = d;
    s.min = lo;
    s.max = hi;
    return s;
  }
  function clean(r) {
    var list = r && Array.isArray(r.settings) ? r.settings : [];
    var seen = {};
    return list.map(cleanSetting).filter(function (s) {
      if (!s || seen[s.id]) { return false; }
      seen[s.id] = true;
      return true;
    });
  }

  /* ---- words ---- */
  function name(s) { return has('pset_' + s.id) ? t('pset_' + s.id) : s.id; }
  function what(s) { return has('pset_' + s.id + '_what') ? t('pset_' + s.id + '_what') : ''; }
  function amount(unit, n) {
    var key = 'pset_u_' + unit + (n === 1 ? '_1' : '');
    var num = n.toLocaleString('en');
    return has(key) ? t(key, {n: num}) : num + ' ' + unit;
  }
  function unitWord(unit) { return has('pset_unit_' + unit) ? t('pset_unit_' + unit) : unit; }
  function choiceWord(s, w) { return has('pset_' + s.id + '_' + w) ? t('pset_' + s.id + '_' + w) : w; }
  function valueWords(s, v) { return s.kind === 'choice' ? choiceWord(s, v) : amount(s.unit, v); }
  function sectionWord(sec, part) {
    var key = 'pset_' + part + '_' + sec;
    return has(key) ? t(key) : '';
  }

  /* ---- the page's state ---- */
  var page = null;
  var LIST = null;    /* the settings, cleaned */
  var marks = {};     /* settings the admin put back to the default, to be sent as null */

  function byId(id) {
    for (var i = 0; i < LIST.length; i++) { if (LIST[i].id === id) { return LIST[i]; } }
    return null;
  }
  function sectionsShown() {
    var out = SECTIONS.filter(function (sec) { return LIST.some(function (s) { return s.section === sec; }); });
    if (LIST.some(function (s) { return s.section === 'other'; })) { out.push('other'); }
    return out;
  }

  /* ---- one option ---- */
  function pill(s) {
    if (marks[s.id]) { return el('span', {class: 'sig-pill fp-pset-pill', 'data-fp-pill': 'default', text: t('pset_to_default')}); }
    if (s.custom) { return el('span', {class: 'sig-pill sig-pill--accent fp-pset-pill', 'data-fp-pill': 'changed', text: t('pset_changed')}); }
    return null;
  }
  function control(s, id, describedBy) {
    if (s.kind === 'choice') {
      return el('select', {class: 'sig-select fp-pset-select', id: id, name: 'values.' + s.id, 'aria-describedby': describedBy},
        s.choices.map(function (w) { return el('option', {value: w, selected: w === s.value ? true : null, text: choiceWord(s, w)}); }));
    }
    var input = el('input', {class: 'sig-input fp-num-input', id: id, name: 'values.' + s.id, type: 'number', inputmode: 'numeric', step: '1',
      min: String(s.min), max: String(s.max), value: String(s.value), 'aria-describedby': describedBy});
    return el('div', {class: 'fp-pset-input'}, [input, el('span', {class: 'fp-pset-unit', 'aria-hidden': 'true', text: unitWord(s.unit)})]);
  }
  function row(s) {
    var id = 'fp-pset-' + s.id;
    var about = what(s);
    var describedBy = (about ? id + '-what ' : '') + id + '-hint';
    var hint = (s.kind === 'number' ? t('pset_range', {min: amount(s.unit, s.min), max: amount(s.unit, s.max)}) + ' ' : '') +
      t('pset_default', {value: valueWords(s, s.def)});
    var showDefault = s.custom || s.value !== s.def;
    return el('div', {class: 'fp-pset-row', 'data-fp-setting': s.id}, [
      el('div', {class: 'fp-pset-about'}, [
        el('div', {class: 'fp-pset-head'}, [el('label', {class: 'sig-label fp-pset-label', for: id, text: name(s)}), pill(s)]),
        about ? el('p', {class: 'fp-muted fp-pset-what', id: id + '-what', text: about}) : null]),
      el('div', {class: 'fp-pset-control'}, [control(s, id, describedBy),
        el('span', {class: 'sig-hint', id: id + '-hint', text: hint}),
        showDefault ? el('div', {class: 'fp-pset-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'default',
          'aria-label': t('pset_use_default_of', {name: name(s)}), text: t('pset_use_default')})]) : null])]);
  }

  /* ---- a section ---- */
  function sectionCard(sec) {
    var items = LIST.filter(function (s) { return s.section === sec; });
    var form = el('form', {class: 'fp-form fp-pset-form', novalidate: '', 'data-fp-section': sec}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-pset-rows'}, items.map(row)),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: sectionWord(sec, 'save')})])]);
    form.addEventListener('submit', function (e) { e.preventDefault(); save(form, sec, items); });
    var node = M.card('fp-pset-' + sec + '-h', sectionWord(sec, 'sec'), [el('p', {class: 'fp-muted fp-pset-sec-what', text: sectionWord(sec + '_what', 'sec')}), form], 'fp-pset-card');
    node.setAttribute('data-fp-card', sec);
    return node;
  }

  /* reads the section's fields: {values} to send, or null after marking the field that is wrong */
  function read(form, items) {
    var values = {};
    var n = 0;
    for (var i = 0; i < items.length; i++) {
      var s = items[i];
      var f = UI.fieldNamed(form, 'values.' + s.id);
      if (!f) { continue; }
      if (marks[s.id]) {
        if (s.custom) { values[s.id] = null; n++; }
        continue;
      }
      if (s.kind === 'choice') {
        if (f.value !== s.value && s.choices.indexOf(f.value) >= 0) { values[s.id] = f.value; n++; }
        continue;
      }
      var v = f.value.trim();
      if (!/^[0-9]{1,9}$/.test(v)) { M.fieldError(form, f, t('pset_bad_number', {name: name(s)})); return null; }
      var num = Number(v);
      if (num < s.min || num > s.max) {
        M.fieldError(form, f, t('pset_bad_range', {name: name(s), min: amount(s.unit, s.min), max: amount(s.unit, s.max)}));
        return null;
      }
      if (num !== s.value) { values[s.id] = num; n++; }
    }
    return {values: values, n: n};
  }
  function save(form, sec, items) {
    var b = M.start(form);
    if (!b) { return; }
    var got = read(form, items);
    if (!got) { return; }
    if (!got.n) { M.say(form, t('pset_nothing')); return; }
    var mine = page;
    UI.setBusy(b, true);
    FP.call('put', 'panelSettings', {values: got.values}).then(function (r) {
      if (page !== mine) { return; }
      var next = clean(r);
      if (next.length) { LIST = next; }
      items.forEach(function (s) { delete marks[s.id]; });
      redraw(sec, got.n === 1 ? t('pset_saved_1') : t('pset_saved', {n: got.n}));
    }, function (err) {
      if (page !== mine) { return; }
      UI.setBusy(b, false);
      M.failed(form, err);
    });
  }

  /* ---- drawing ---- */
  function summary() {
    var n = LIST.filter(function (s) { return s.custom; }).length;
    return el('p', {class: 'fp-pset-summary', 'data-fp-summary': '', text: n === 0 ? t('pset_summary_none') : n === 1 ? t('pset_summary_1') : t('pset_summary', {n: n})});
  }
  function drawAll() {
    page.textContent = '';
    page.appendChild(el('div', {class: 'fp-pset-intro'}, [el('p', {class: 'fp-muted', text: t('pset_lead')}), summary()]));
    sectionsShown().forEach(function (sec) { page.appendChild(sectionCard(sec)); });
  }
  /* the saved section is drawn again with the server's answer, the others keep what is typed in them */
  function redraw(sec, said) {
    var old = page.querySelector('[data-fp-card="' + sec + '"]');
    var next = sectionCard(sec);
    if (old) { old.replaceWith(next); }
    var sum = page.querySelector('[data-fp-summary]');
    if (sum) { sum.replaceWith(summary()); }
    M.say(next, said);
    next.querySelector('.fp-submit').focus();
  }

  function onClick(e) {
    var node = e.target && e.target.closest ? e.target : null;
    var b = node && node.closest('[data-fp-act="default"]');
    if (!b || !page || !page.contains(b) || !LIST) { return; }
    var r = b.closest('[data-fp-setting]');
    var s = r ? byId(r.getAttribute('data-fp-setting')) : null;
    var form = b.closest('form');
    if (!s || !form) { return; }
    var f = UI.fieldNamed(form, 'values.' + s.id);
    if (!f) { return; }
    M.start(form);
    f.value = String(s.def);
    marks[s.id] = true;
    var old = r.querySelector('.fp-pset-pill');
    var now = pill(s);
    var head = r.querySelector('.fp-pset-head');
    if (old) { old.replaceWith(now); } else { head.appendChild(now); }
    M.say(form, t('pset_default_filled', {name: name(s)}));
  }
  /* a value typed after "Use the default" is the admin's again */
  function onInput(e) {
    var f = e.target;
    if (!page || !f || !f.name || f.name.indexOf('values.') !== 0 || !page.contains(f)) { return; }
    var id = f.name.slice(7);
    if (!marks[id]) { return; }
    delete marks[id];
    var s = byId(id);
    var r = f.closest('[data-fp-setting]');
    var old = r && r.querySelector('.fp-pset-pill');
    if (old) {
      var now = s && pill(s);
      if (now) { old.replaceWith(now); } else { old.remove(); }
    }
  }
  document.addEventListener('click', onClick);
  document.addEventListener('input', onInput);
  document.addEventListener('change', onInput);

  FP.view('tool:server_settings', function () {
    var tool = FP.tools.server_settings;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    LIST = null;
    marks = {};
    var mine = FP.frame({title: tool.label, desc: t('pset_desc'), cls: 'fp-mail fp-srv fp-pset-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    page = mine;
    mine.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'panelSettings').then(function (r) {
      if (page !== mine) { return; }
      LIST = clean(r);
      if (!LIST.length) {
        mine.textContent = '';
        mine.appendChild(FP.empty(tool.label, t('api_failed')));
        return;
      }
      drawAll();
    }, function (err) {
      if (page !== mine) { return; }
      mine.textContent = '';
      mine.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

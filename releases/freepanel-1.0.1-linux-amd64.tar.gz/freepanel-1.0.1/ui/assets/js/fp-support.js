/* freePanel support sessions (docs/api.md, "Support sign-in"): the banner a support session shows on every screen of the panel (the session says it is one in
   `support`: who opened it and when it ends), and the customer panel's Support sessions page (#/tool/support_sessions), which lists who from support is in the
   account's panel now and ends them all. A support session is the customer's own account with a mark on it; it cannot change how the customer signs in, ends by
   itself and ends with the login that opened it. The page pieces come from FP.mail (fp-mail.js); what the staff card in the accounts page needs is in FP.support.
   Everything the server sends is shown as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var ISO_RE = /^\d{4}-\d{2}-\d{2}T[0-9:.]+(Z|[+-]\d{2}:\d{2})$/;
  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  function iso(v) { v = str(v, 40); return ISO_RE.test(v) && !isNaN(new Date(v).getTime()) ? v : ''; }
  /* {by, by_role, started_at, expires_at} as the session and the lists send it; null when it names no one */
  function mark(v) {
    if (!v || typeof v !== 'object' || !str(v.by, 64)) { return null; }
    return {by: str(v.by, 64), admin: v.by_role === 'admin', started: iso(v.started_at), ends: iso(v.expires_at)};
  }
  function clock(s) {
    var d = new Date(s);
    return s && !isNaN(d.getTime()) ? d.toLocaleTimeString(undefined, {hour: 'numeric', minute: '2-digit'}) : '';
  }
  function stamp(s) {
    var d = new Date(s);
    return s && !isNaN(d.getTime()) ? d.toLocaleString(undefined, {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }
  function sessions(r) { return (r && Array.isArray(r.sessions) ? r.sessions : []).map(mark).filter(Boolean).slice(0, 20); }
  function whoRow(m) {
    if (!m.admin) { return t('sup_row_reseller', {name: m.by}); }
    return m.by === 'host admin' ? t('sup_row_host_admin') : t('sup_row_admin', {name: m.by});
  }
  function sessionRow(m) {
    var when = [m.started ? t('sup_since', {when: stamp(m.started)}) : '', m.ends ? t('sup_until', {when: stamp(m.ends)}) : ''].filter(Boolean).join(' · ');
    return el('li', {class: 'fp-sup-item', 'data-fp-who': m.by}, [el('span', {class: 'fp-sup-who', text: whoRow(m)}), when ? el('span', {class: 'fp-muted fp-sup-when', text: when}) : null]);
  }
  FP.support = {mark: mark, sessions: sessions, sessionRow: sessionRow, stamp: stamp, clock: clock, iso: iso};

  /* ---- the banner ---- */
  function bannerFor(m) {
    var over = m.ends && new Date(m.ends).getTime() <= Date.now();
    var who = m.admin ? t('sup_who_admin') : t('sup_who_reseller', {name: m.by});
    var user = FP.session && FP.session.user ? FP.account() : '';
    var text = over ? t('sup_ended') : t(m.ends ? 'sup_banner' : 'sup_banner_noend', {user: user, who: who, until: clock(m.ends)});
    return el('div', {class: 'sig-banner sig-banner--warn fp-sup-banner', role: 'note', 'data-fp-support': over ? 'ended' : 'open'}, [UI.icon(FP.ui, 'ui_warning'),
      el('div', {class: 'fp-sup-banner-body'}, [el('strong', {text: t('sup_banner_title')}), ' ' + text, el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': ''})]),
      el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-sup-leave', type: 'button', 'data-fp-act': 'sup-leave', 'aria-label': t('sup_leave_label'), text: t('sup_leave')})]);
  }
  var timer = null;
  /* when the session's time is up the banner on screen says so, without waiting for the next call to be refused */
  function watch(m) {
    if (timer) { window.clearTimeout(timer); timer = null; }
    var ms = m.ends ? new Date(m.ends).getTime() - Date.now() : 0;
    if (ms <= 0 || ms > 2147000000) { return; }
    timer = window.setTimeout(function () {
      var shown = document.querySelectorAll('[data-fp-support]');
      for (var i = 0; i < shown.length; i++) { shown[i].parentNode.replaceChild(bannerFor(m), shown[i]); }
    }, ms + 50);
  }
  var prior = FP.beforeStart;
  FP.beforeStart = function (session) {
    var m = FP.realm === 'user' ? mark(session && session.support) : null;
    if (m) {
      FP.notice = function () { return bannerFor(m); };
      watch(m);
    }
    return prior ? prior(session) : null;
  };
  function leave(b) {
    var banner = b.closest('[data-fp-support]');
    var done = function () { window.location.replace(UI.panel[FP.realm].login + '?signed_out=1'); };
    UI.showError(banner, '');
    UI.setBusy(b, true);
    FP.signOutReady().then(function () { return FP.call('post', 'logout', {}); }).then(done, function (err) {
      if (err && err.code === 'unauthorized') { done(); return; }
      UI.setBusy(b, false);
      UI.showError(banner, UI.t('signout_failed'));
    });
  }

  /* ---- the customer's page ---- */
  var S = {page: null, list: [], busy: false};

  function listCard() {
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t('sup_intro')})];
    if (FP.session.support) { parts.push(el('p', {class: 'fp-muted', 'data-fp-sup-self': '', text: t('sup_self_note')})); }
    if (!S.list.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('sup_none')}));
    } else {
      parts.push(el('p', {'data-fp-count': '', text: t(S.list.length === 1 ? 'sup_count_1' : 'sup_count', {n: S.list.length})}));
      parts.push(el('ul', {class: 'fp-sup-list', 'aria-labelledby': 'fp-sup-now-h'}, S.list.map(sessionRow)));
    }
    parts.push(el('div', {class: 'fp-actions fp-sup-acts'}, [
      el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'sup-check', text: t('sup_check')}),
      S.list.length ? el('button', {class: 'sig-btn sig-btn--secondary fp-btn-danger-text', type: 'button', 'data-fp-act': 'sup-end', text: t('sup_end')}) : null]));
    return M.card('fp-sup-now-h', t('sup_now_title'), parts, 'fp-sup-now');
  }
  function howCard() {
    return M.card('fp-sup-how-h', t('sup_how_title'), [el('p', {class: 'fp-muted', text: t('sup_how_1')}), el('p', {class: 'fp-muted', text: t('sup_how_2')}),
      el('p', {class: 'fp-muted', text: t('sup_how_3')})], 'fp-sup-how');
  }
  function render() {
    S.page.textContent = '';
    S.page.appendChild(listCard());
    S.page.appendChild(howCard());
  }
  function read(focus) {
    return FP.call('get', 'accountSupportSessions', undefined, FP.account()).then(function (r) {
      S.list = sessions(r);
      render();
      if (focus) { S.page.querySelector(focus).focus(); }
    });
  }
  function end(b) {
    if (S.busy) { return; }
    S.busy = true;
    UI.setBusy(b, true);
    var mine = S.page;
    FP.call('del', 'accountSupportSessions', undefined, FP.account()).then(function () {
      S.busy = false;
      if (S.page !== mine) { return; }
      if (FP.session.support) { window.location.replace(UI.panel[FP.realm].login + '?signed_out=1'); return; }
      S.list = [];
      render();
      M.say(S.page.querySelector('.fp-sup-now'), t('sup_ended_all'));
      S.page.querySelector('[data-fp-act="sup-check"]').focus();
    }, function (err) {
      S.busy = false;
      if (S.page !== mine) { return; }
      render();
      UI.showError(S.page.querySelector('.fp-sup-now'), err.message);
      S.page.querySelector('#fp-sup-now-h').focus();
    });
  }

  document.addEventListener('click', function (e) {
    var node = e.target.closest ? e.target : null;
    var b = node && node.closest('[data-fp-act]');
    if (!b) { return; }
    var a = b.getAttribute('data-fp-act');
    if (a === 'sup-leave') { leave(b); return; }
    if (!S.page || !S.page.contains(b)) { return; }
    if (a === 'sup-check') {
      UI.setBusy(b, true);
      read('[data-fp-act="sup-check"]').then(null, function (err) {
        UI.setBusy(b, false);
        UI.showError(S.page.querySelector('.fp-sup-now'), err.message);
      });
    } else if (a === 'sup-end') {
      M.confirmIn(b.closest('.fp-sup-acts'), t('sup_end_ask'), 'sup-end-yes', t('sup_end_yes'));
    } else if (a === 'confirm-no') {
      render();
      S.page.querySelector('[data-fp-act="sup-end"]').focus();
    } else if (a === 'sup-end-yes') {
      end(b);
    }
  });

  FP.view('tool:support_sessions', function () {
    var tool = FP.tools.support_sessions;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    S.list = [];
    S.busy = false;
    var body = FP.frame({title: tool.label, desc: t('sup_desc'), cls: 'fp-mail fp-sup-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    S.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    read().then(null, function (err) {
      if (S.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

/* freePanel demo logins (docs/api.md, "Demo logins"): the banner a demo login's session shows on every screen of either panel (the session says it is
   one in `demo`), and the admin's Demo logins page (#/tool/demo_logins): which hosting accounts' and resellers' logins are open to the public as a demo,
   the backup each is put back to, putting one back now, and making a login a demo one or an ordinary one again. A demo login looks and changes nothing;
   the server refuses every change it asks for and says why, and the pages show those words where the change was asked. The page pieces come from
   FP.mail (fp-mail.js). Everything the server sends is shown as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var USER_RE = /^[a-z][a-z0-9]{0,15}$/;
  var ARCHIVE_RE = /^[a-z][a-z0-9]{0,15}-[0-9A-Za-z._-]{1,100}\.tar\.gz$/;
  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  function when(iso) {
    var d = iso ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString(undefined, {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }

  /* ---- the banner ---- */
  function banner() {
    return el('div', {class: 'sig-banner sig-banner--warn fp-demo-banner', role: 'note', 'data-fp-demo': ''}, [UI.icon(FP.ui, 'ui_warning'),
      el('div', {class: 'fp-demo-banner-body'}, [el('strong', {text: t('demo_banner_title')}), el('span', {text: t('demo_banner')})])]);
  }
  var prior = FP.beforeStart;
  FP.beforeStart = function (session) {
    var out = prior ? prior(session) : null;
    if (session && session.demo && typeof session.demo === 'object') {
      var other = FP.notice;
      FP.notice = function () {
        var b = banner();
        var o = other ? other() : null;
        if (!o) { return b; }
        var both = el('div', {class: 'fp-demo-notices'}, [b, o]);
        return both;
      };
    }
    return out;
  };

  /* ---- the admin's page ---- */
  var D = {page: null, logins: [], accounts: [], archives: {}};

  function cleanLogins(r) {
    return (r && Array.isArray(r.logins) ? r.logins : []).filter(function (d) { return d && USER_RE.test(str(d.username, 16)); }).slice(0, 50).map(function (d) {
      return {username: d.username, role: d.role === 'reseller' ? 'reseller' : 'user', since: str(d.since, 40), snapshot: ARCHIVE_RE.test(str(d.snapshot, 130)) ? d.snapshot : '',
        reset: str(d.reset_at, 40), gone: d.gone === true};
    });
  }
  function cleanAccounts(r) {
    return (r && Array.isArray(r.accounts) ? r.accounts : []).map(function (a) { return a && str(a.username, 16); }).filter(function (u) { return USER_RE.test(u); }).sort();
  }
  function cleanArchives(r) {
    var out = {};
    (r && Array.isArray(r.backups) ? r.backups : []).forEach(function (b) {
      if (!b || !USER_RE.test(str(b.username, 16)) || !ARCHIVE_RE.test(str(b.name, 130)) || b.name.indexOf(b.username + '-') !== 0 || b.removed === true) { return; }
      (out[b.username] = out[b.username] || []).push(b.name);
    });
    Object.keys(out).forEach(function (k) { out[k].sort().reverse(); });
    return out;
  }
  function snapshotPick(d, id) {
    var names = (D.archives[d.username] || []).slice();
    if (d.snapshot && names.indexOf(d.snapshot) < 0) { names.unshift(d.snapshot); }
    var pick = el('select', {class: 'sig-select fp-demo-snap', id: id, 'aria-label': t('demo_snapshot_for', {name: d.username})},
      [el('option', {value: '', text: t('demo_snapshot_none')})].concat(names.map(function (n) { return el('option', {value: n, text: n}); })));
    pick.value = d.snapshot;
    return pick;
  }
  function row(d, i) {
    var facts = [t(d.role === 'reseller' ? 'demo_role_reseller' : 'demo_role_user'), d.since ? t('demo_since', {when: when(d.since)}) : '',
      d.reset ? t('demo_reset_at', {when: when(d.reset)}) : t('demo_reset_never')].filter(Boolean).join(' · ');
    return el('tr', {'data-fp-demo-login': d.username}, [
      el('th', {scope: 'row', class: 'fp-demo-name'}, [el('span', {class: 'sig-mono', text: d.username}), el('span', {class: 'fp-muted fp-row-note', text: facts}),
        d.gone ? el('span', {class: 'sig-pill sig-pill--warn', text: t('demo_gone')}) : null]),
      el('td', {class: 'fp-demo-snapcell'}, [el('div', {class: 'fp-demo-snaprow'}, [snapshotPick(d, 'fp-demo-snap-' + i),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'demo-snap', 'aria-label': t('demo_snapshot_save_for', {name: d.username}), text: t('demo_snapshot_save')})])]),
      el('td', {class: 'fp-mail-acts'}, [
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'demo-reset', 'aria-label': t('demo_reset_for', {name: d.username}), text: t('demo_reset'),
          disabled: d.snapshot ? null : ''}),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'demo-stop', 'aria-label': t('demo_stop_for', {name: d.username}), text: t('demo_stop')})])]);
  }
  function listCard() {
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t('demo_note')})];
    if (!D.logins.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('demo_none')}));
    } else {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-demo-list-h'}, [
        el('table', {class: 'sig-table fp-mail-table fp-demo-table'}, [el('thead', null, [el('tr', null, [
          el('th', {scope: 'col', text: t('demo_login')}), el('th', {scope: 'col', text: t('demo_snapshot')}),
          el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]),
        el('tbody', null, D.logins.map(row))])]));
    }
    return M.card('fp-demo-list-h', t('demo_list_title'), parts, 'fp-demo-list');
  }
  function addCard() {
    var free = D.accounts.filter(function (a) { return !D.logins.some(function (d) { return d.username === a; }); });
    var pick = el('select', {class: 'sig-select', id: 'fp-demo-add', name: 'username'}, free.map(function (a) { return el('option', {value: a, text: a}); }));
    var form = el('form', {class: 'fp-form fp-mail-form fp-demo-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-demo-add', t('demo_add_login'), pick, t('demo_add_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('demo_add'), disabled: free.length ? null : ''})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || !pick.value) { return; }
      var name = pick.value;
      UI.setBusy(b, true);
      FP.call('put', 'demoLogin', {}, {name: name}).then(function () {
        return reload();
      }).then(function () {
        M.say(D.page.querySelector('.fp-demo-list'), t('demo_added', {name: name}));
        var again = D.page.querySelector('tr[data-fp-demo-login="' + window.CSS.escape(name) + '"] select');
        if (again) { again.focus(); }
      }, function (err) {
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return M.card('fp-demo-add-h', t('demo_add_title'), [form], 'fp-demo-add-card');
  }
  function render() {
    D.page.textContent = '';
    D.page.appendChild(listCard());
    D.page.appendChild(addCard());
  }
  function load() {
    return Promise.all([FP.call('get', 'demoLogins'), FP.call('get', 'accounts'), FP.call('get', 'backups')]).then(function (r) {
      D.logins = cleanLogins(r[0]);
      D.accounts = cleanAccounts(r[1]);
      D.archives = cleanArchives(r[2]);
    });
  }
  function reload() { return load().then(render); }
  function act(b, a, tr) {
    var name = tr ? tr.getAttribute('data-fp-demo-login') : '';
    var card = D.page.querySelector('.fp-demo-list');
    var refocus = function (sel) {
      var x = D.page.querySelector('tr[data-fp-demo-login="' + window.CSS.escape(name) + '"] ' + sel);
      (x || D.page.querySelector('#fp-demo-list-h')).focus();
    };
    var done = function (text, sel) { return function () { return reload().then(function () { M.say(D.page.querySelector('.fp-demo-list'), text); refocus(sel); }); }; };
    var failed = function (sel) { return function (err) { render(); UI.showError(D.page.querySelector('.fp-demo-list'), err.message); refocus(sel); }; };
    UI.showError(card, '');
    M.say(card, '');
    if (a === 'demo-snap') {
      var snap = tr.querySelector('select').value;
      UI.setBusy(b, true);
      FP.call('put', 'demoLogin', {snapshot: snap}, {name: name}).then(done(snap ? t('demo_snapshot_saved', {name: name, snapshot: snap}) : t('demo_snapshot_cleared', {name: name}), 'select'), failed('select'));
    } else if (a === 'demo-reset') {
      M.confirmIn(tr.querySelector('.fp-mail-acts'), t('demo_reset_ask', {name: name}), 'demo-reset-yes', t('demo_reset'));
    } else if (a === 'demo-stop') {
      M.confirmIn(tr.querySelector('.fp-mail-acts'), t('demo_stop_ask', {name: name}), 'demo-stop-yes', t('demo_stop'));
    } else if (a === 'confirm-no') {
      render();
      refocus('[data-fp-act="demo-reset"]');
    } else if (a === 'demo-reset-yes') {
      UI.setBusy(b, true);
      FP.call('post', 'demoLoginReset', {}, {name: name}).then(done(t('demo_reset_started', {name: name}), '[data-fp-act="demo-reset"]'), failed('[data-fp-act="demo-reset"]'));
    } else if (a === 'demo-stop-yes') {
      UI.setBusy(b, true);
      FP.call('del', 'demoLogin', undefined, {name: name}).then(function () {
        return reload().then(function () {
          M.say(D.page.querySelector('.fp-demo-list'), t('demo_stopped', {name: name}));
          D.page.querySelector('#fp-demo-list-h').focus();
        });
      }, failed('[data-fp-act="demo-stop"]'));
    }
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !D.page || !D.page.contains(b)) { return; }
    var a = b.getAttribute('data-fp-act');
    if (/^demo-|^confirm-no$/.test(a)) { act(b, a, b.closest('tr')); }
  });

  FP.view('tool:demo_logins', function () {
    var tool = FP.tools.demo_logins;
    if (!tool || FP.realm !== 'admin' || !FP.session || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('demo_logins_desc'), cls: 'fp-mail fp-demo-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    D.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    load().then(function () {
      if (D.page !== body) { return; }
      render();
    }, function (err) {
      if (D.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

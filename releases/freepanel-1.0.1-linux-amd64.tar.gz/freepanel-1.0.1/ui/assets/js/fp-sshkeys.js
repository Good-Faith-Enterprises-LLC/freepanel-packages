/* freePanel SSH keys (#/tool/ssh_keys), the customer panel's page for the keys in the account's ~/.ssh (docs/api.md,
   "SSH keys"): the list with authorize, deauthorize, view and delete, a form to make a key pair and one to import a
   key. Keys added over SSH show here too. Key names, problems, the authorized_keys error and the key files are shown as
   text, never as markup: they come from files in the home folder. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var NAME_RE = /^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/;
  var MAX_KEYS = 500;
  var MAX_TEXT = 64 * 1024;
  var MAX_PASSPHRASE = 1024;

  var S = null;

  function str(v) { return typeof v === 'string' ? v : ''; }
  function goodName(n) { return NAME_RE.test(n) && !/\.pub$/.test(n); }
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var keys = (Array.isArray(r.keys) ? r.keys : []).filter(function (k) { return k && goodName(str(k.name)); }).slice(0, MAX_KEYS).map(function (k) {
      return {name: k.name, pub: k.public === true, priv: k.private === true, type: str(k.type).slice(0, 64),
        bits: typeof k.bits === 'number' && isFinite(k.bits) && k.bits > 0 ? Math.floor(k.bits) : 0, fingerprint: str(k.fingerprint).slice(0, 128),
        usable: k.usable === true, problem: str(k.problem).slice(0, 300), authorized: k.authorized === true};
    });
    keys.sort(function (a, b) { return a.name < b.name ? -1 : a.name > b.name ? 1 : 0; });
    return {keys: keys, authError: str(r.authorized_error).slice(0, 300), more: r.more === true};
  }
  function byName(n) {
    for (var i = 0; i < S.list.keys.length; i++) { if (S.list.keys[i].name === n) { return S.list.keys[i]; } }
    return null;
  }

  /* ---------- the list ---------- */
  function stateCell(k) {
    if (!k.pub) { return el('td', null, [el('span', {class: 'sig-pill', text: t('sk_no_public')})]); }
    if (!k.usable) {
      return el('td', null, [el('span', {class: 'fp-sk-state'}, [el('span', {class: 'sig-pill sig-pill--warn', text: t('sk_unusable')}),
        el('span', {class: 'fp-muted fp-row-note', 'data-fp-sk-problem': '', text: k.problem || t('sk_unusable_why')})])]);
    }
    return el('td', null, [k.authorized ? el('span', {class: 'sig-pill sig-pill--ok', text: t('sk_authorized')}) :
      el('span', {class: 'sig-pill', text: t('sk_not_authorized')})]);
  }
  function actsFor(k) {
    var b = [];
    function btn(act, label, aria, cls) {
      b.push(el('button', {class: 'sig-btn sig-btn--' + (cls || 'secondary') + ' sig-btn--sm', type: 'button', 'data-fp-act': act, 'aria-label': aria, text: label}));
    }
    if (k.pub && k.usable) {
      if (k.authorized) { btn('deauthorize', t('sk_deauthorize'), t('sk_deauthorize_of', {name: k.name})); } else { btn('authorize', t('sk_authorize'), t('sk_authorize_of', {name: k.name})); }
    }
    if (k.pub) { btn('view-public', t('sk_view_public'), t('sk_view_public_of', {name: k.name})); }
    if (k.priv) { btn('view-private', t('sk_view_private'), t('sk_view_private_of', {name: k.name})); }
    btn('delete', t('sk_delete'), t('sk_delete_of', {name: k.name}), 'danger');
    return b;
  }
  function listCard() {
    var L = S.list;
    var parts = [M.errorLine(), M.statusLine()];
    if (S.suspended) { parts.push(M.suspendedBanner(t('sk_suspended'))); }
    if (L.authError) { parts.push(el('p', {class: 'fp-sk-bad', 'data-fp-sk-autherror': '', text: t('sk_auth_error') + ' ' + L.authError})); }
    if (!L.keys.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('sk_none')}));
    } else {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-sk-list-h'}, [
        el('table', {class: 'sig-table fp-mail-table fp-sk-table'}, [el('thead', null, [el('tr', null, [
          el('th', {scope: 'col', text: t('sk_name')}), el('th', {scope: 'col', text: t('sk_type')}), el('th', {scope: 'col', text: t('sk_fingerprint')}),
          el('th', {scope: 'col', text: t('sk_state')}), el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]),
        el('tbody', null, L.keys.map(function (k) {
          var kind = k.type ? k.type + (k.bits ? ' · ' + t('sk_bits', {n: String(k.bits)}) : '') : '—';
          return el('tr', {'data-fp-key': k.name}, [
            el('th', {scope: 'row', class: 'fp-sk-name'}, [el('span', {class: 'sig-mono', text: k.name}),
              !k.priv ? null : el('span', {class: 'fp-muted fp-row-note', text: t('sk_has_private')})]),
            el('td', {class: 'fp-sk-type', text: kind}),
            el('td', {class: 'fp-sk-fp'}, [el('span', {class: 'sig-mono', text: k.fingerprint || '—'})]),
            stateCell(k),
            el('td', {class: 'fp-mail-acts fp-sk-acts'}, actsFor(k))]);
        }))])]));
    }
    if (L.more) { parts.push(el('p', {class: 'fp-muted', text: t('sk_more')})); }
    parts.push(el('p', {class: 'fp-muted', text: t('sk_shell_note')}));
    return M.card('fp-sk-list-h', t('sk_list_title'), parts, 'fp-sk-list');
  }
  function viewCard() {
    var v = S.view;
    if (!v) { return null; }
    var title = t(v.part === 'private' ? 'sk_view_private_title' : 'sk_view_public_title', {name: v.name});
    var parts = [];
    if (v.part === 'private') { parts.push(el('p', {class: 'fp-sk-bad', text: t('sk_private_warn')})); }
    parts.push(el('pre', {class: 'fp-sk-text sig-mono', tabindex: '0', 'aria-label': title, 'data-fp-sk-text': '', text: v.text}));
    parts.push(el('div', {class: 'fp-actions'}, [
      el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'copy'}, [UI.icon(FP.ui, 'ui_copy'), t('sk_copy')]),
      el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'close-view', text: t('sk_close')})]));
    parts.push(el('p', {class: 'fp-copy-status', role: 'status', 'data-fp-copy-status': ''}));
    return M.card('fp-sk-view-h', title, parts, 'fp-sk-view');
  }

  /* ---------- the forms ---------- */
  function text(id, name, attrs) {
    return el('input', Object.assign({class: 'sig-input', id: id, name: name, type: 'text', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none'}, attrs || {}));
  }
  function passphraseFields(prefix, hint) {
    return [M.field(prefix + '-pass', t('sk_passphrase'), el('input', {class: 'sig-input', id: prefix + '-pass', name: 'passphrase', type: 'password',
      autocomplete: 'new-password', maxlength: String(MAX_PASSPHRASE)}), hint),
    M.field(prefix + '-again', t('sk_passphrase_again'), el('input', {class: 'sig-input', id: prefix + '-again', name: 'again', type: 'password',
      autocomplete: 'new-password', maxlength: String(MAX_PASSPHRASE)}))];
  }
  function makeCard() {
    var type = el('select', {class: 'sig-select', id: 'fp-sk-type', name: 'type'}, [el('option', {value: 'ed25519', text: t('sk_type_ed25519')}),
      el('option', {value: 'rsa', text: t('sk_type_rsa')})]);
    var bits = el('select', {class: 'sig-select', id: 'fp-sk-bits', name: 'bits'}, ['4096', '3072', '2048'].map(function (b) { return el('option', {value: b, text: t('sk_bits', {n: b})}); }));
    var bitsField = M.field('fp-sk-bits', t('sk_size'), bits, t('sk_size_hint'));
    bitsField.hidden = true;
    type.addEventListener('change', function () { bitsField.hidden = type.value !== 'rsa'; });
    var form = el('form', {class: 'fp-form fp-mail-form fp-sk-make', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-sk-name', t('sk_name'), text('fp-sk-name', 'name', {maxlength: '64', value: 'id_ed25519'}), t('sk_name_hint')),
      M.field('fp-sk-type', t('sk_type'), type, t('sk_type_hint')), bitsField]
      .concat(passphraseFields('fp-sk', t('sk_passphrase_hint')))
      .concat([M.field('fp-sk-comment', t('sk_comment'), text('fp-sk-comment', 'comment', {maxlength: '255'}), t('sk_comment_hint', {name: S.account})),
        el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('sk_make')})])]));
    type.addEventListener('change', function () {
      var n = form.querySelector('[name="name"]');
      if (n.value === 'id_ed25519' || n.value === 'id_rsa') { n.value = type.value === 'rsa' ? 'id_rsa' : 'id_ed25519'; }
    });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var name = readName(form);
      if (name === null) { return; }
      var pass = readPassphrase(form);
      if (pass === null) { return; }
      var body = {name: name, type: type.value};
      if (type.value === 'rsa') { body.bits = Number(bits.value); }
      if (pass) { body.passphrase = pass; }
      var comment = form.querySelector('[name="comment"]').value.trim();
      if (comment) { body.comment = comment; }
      send(form, b, 'sshKeys', body, t(type.value === 'rsa' ? 'sk_making_rsa' : 'sk_making'), t('sk_made', {name: name}));
    });
    return M.card('fp-sk-make-h', t('sk_make_title'), [el('p', {class: 'fp-muted', text: t('sk_make_desc')}), form], 'fp-sk-make-card');
  }
  function importCard() {
    var form = el('form', {class: 'fp-form fp-mail-form fp-sk-import', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-sk-iname', t('sk_name'), text('fp-sk-iname', 'name', {maxlength: '64'}), t('sk_name_hint')),
      M.field('fp-sk-public', t('sk_public'), el('textarea', {class: 'sig-input fp-sk-area', id: 'fp-sk-public', name: 'public', rows: '3', spellcheck: 'false',
        autocapitalize: 'none', autocomplete: 'off'}), t('sk_public_hint')),
      M.field('fp-sk-private', t('sk_private'), el('textarea', {class: 'sig-input fp-sk-area', id: 'fp-sk-private', name: 'private', rows: '6', spellcheck: 'false',
        autocapitalize: 'none', autocomplete: 'off'}), t('sk_private_hint')),
      M.field('fp-sk-ipass', t('sk_passphrase'), el('input', {class: 'sig-input', id: 'fp-sk-ipass', name: 'passphrase', type: 'password', autocomplete: 'off',
        maxlength: String(MAX_PASSPHRASE)}), t('sk_ipassphrase_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('sk_import')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var name = readName(form);
      if (name === null) { return; }
      var pub = form.querySelector('[name="public"]').value.trim();
      var priv = form.querySelector('[name="private"]').value.trim();
      if (!pub && !priv) { M.fieldError(form, form.querySelector('[name="public"]'), t('sk_import_need')); return; }
      if (pub.length > MAX_TEXT) { M.fieldError(form, form.querySelector('[name="public"]'), t('sk_too_long')); return; }
      if (priv.length > MAX_TEXT) { M.fieldError(form, form.querySelector('[name="private"]'), t('sk_too_long')); return; }
      var pass = form.querySelector('[name="passphrase"]');
      if (new window.TextEncoder().encode(pass.value).length > MAX_PASSPHRASE) { M.fieldError(form, pass, t('sk_passphrase_long')); return; }
      var body = {name: name};
      if (pub) { body.public = pub + '\n'; }
      if (priv) { body.private = priv + '\n'; }
      if (pass.value) { body.passphrase = pass.value; }
      send(form, b, 'sshKeyImport', body, t('sk_importing'), t('sk_imported', {name: name}));
    });
    return M.card('fp-sk-import-h', t('sk_import_title'), [el('p', {class: 'fp-muted', text: t('sk_import_desc')}), form], 'fp-sk-import-card');
  }
  function readName(form) {
    var f = form.querySelector('[name="name"]');
    var v = f.value.trim();
    if (!goodName(v)) { M.fieldError(form, f, t('sk_name_bad')); return null; }
    if (byName(v)) { M.fieldError(form, f, t('sk_name_taken')); return null; }
    return v;
  }
  /* '' for none, null when the two don't match or it is too long */
  function readPassphrase(form) {
    var p = form.querySelector('[name="passphrase"]');
    var a = form.querySelector('[name="again"]');
    if (new window.TextEncoder().encode(p.value).length > MAX_PASSPHRASE) { M.fieldError(form, p, t('sk_passphrase_long')); return null; }
    if (p.value !== a.value) { M.fieldError(form, a, t('sk_passphrase_mismatch')); return null; }
    return p.value;
  }
  function send(form, b, path, body, waiting, done) {
    UI.setBusy(b, true);
    M.say(form, waiting);
    FP.call('post', path, body, S.account).then(function (r) {
      S.list = clean(r);
      S.view = null;
      render();
      var list = S.page.querySelector('.fp-sk-list');
      M.say(list, done);
      var row = S.page.querySelector('[data-fp-key="' + window.CSS.escape(body.name) + '"] [data-fp-act]');
      (row || S.page.querySelector('#fp-sk-list-h')).focus();
    }, function (err) {
      UI.setBusy(b, false);
      M.say(form, '');
      M.failed(form, err);
      if (!form.contains(document.activeElement)) { b.focus(); }
    });
  }

  /* ---------- page ---------- */
  function render() {
    S.page.textContent = '';
    S.page.appendChild(listCard());
    var v = viewCard();
    if (v) { S.page.appendChild(v); }
    S.page.appendChild(makeCard());
    S.page.appendChild(importCard());
  }
  /* after a change to a key: the list as the server now has it, focus on the same row's button when it is still there */
  function changed(r, name, act, said) {
    S.list = clean(r);
    if (S.view && !byName(S.view.name)) { S.view = null; }
    render();
    var list = S.page.querySelector('.fp-sk-list');
    M.say(list, said);
    var row = S.page.querySelector('[data-fp-key="' + window.CSS.escape(name) + '"]');
    var again = row && (row.querySelector('[data-fp-act="' + act + '"]') || row.querySelector('[data-fp-act]'));
    (again || S.page.querySelector('#fp-sk-list-h')).focus();
  }
  function rowError(b, err) {
    var list = S.page.querySelector('.fp-sk-list');
    UI.setBusy(b, false);
    UI.showError(list, err.message);
    b.focus();
  }

  function onClick(e) {
    var target = e.target.closest ? e.target : null;
    var b = target && S && S.page && S.page.contains(target) ? target.closest('[data-fp-act]') : null;
    if (!b) { return; }
    var a = b.getAttribute('data-fp-act');
    var row = b.closest('[data-fp-key]');
    var name = row ? row.getAttribute('data-fp-key') : '';
    var arg = {name: S.account, key: name};
    var list = S.page.querySelector('.fp-sk-list');
    if (a === 'copy') {
      var status = S.page.querySelector('[data-fp-copy-status]');
      var say = function (s) { status.textContent = s; };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(S.view.text).then(function () { say(t('copied')); }, function () { say(t('copy_failed')); });
      } else {
        say(t('copy_failed'));
      }
      return;
    }
    if (a === 'close-view') {
      var was = S.view;
      S.view = null;
      render();
      var back = was && S.page.querySelector('[data-fp-key="' + window.CSS.escape(was.name) + '"] [data-fp-act="view-' + was.part + '"]');
      (back || S.page.querySelector('#fp-sk-list-h')).focus();
      return;
    }
    if (!name || !byName(name)) { return; }
    UI.showError(list, '');
    M.say(list, '');
    if (a === 'authorize' || a === 'deauthorize') {
      UI.setBusy(b, true);
      FP.call('post', a === 'authorize' ? 'sshKeyAuthorize' : 'sshKeyDeauthorize', {}, arg).then(function (r) {
        changed(r, name, a === 'authorize' ? 'deauthorize' : 'authorize', t(a === 'authorize' ? 'sk_authorized_now' : 'sk_deauthorized_now', {name: name}));
      }, function (err) { rowError(b, err); });
    } else if (a === 'view-public' || a === 'view-private') {
      var part = a === 'view-public' ? 'public' : 'private';
      UI.setBusy(b, true);
      FP.call('get', part === 'public' ? 'sshKeyPublic' : 'sshKeyPrivate', undefined, arg).then(function (r) {
        S.view = {name: name, part: part, text: str(r && r.text).slice(0, MAX_TEXT)};
        render();
        S.page.querySelector('#fp-sk-view-h').focus();
      }, function (err) { rowError(b, err); });
    } else if (a === 'delete') {
      M.confirmIn(b.parentNode, t('sk_delete_ask', {name: name}), 'delete-yes', t('sk_delete'));
    } else if (a === 'confirm-no') {
      var cell = b.parentNode;
      cell.textContent = '';
      actsFor(byName(name)).forEach(function (x) { cell.appendChild(x); });
      cell.querySelector('[data-fp-act="delete"]').focus();
    } else if (a === 'delete-yes') {
      UI.setBusy(b, true);
      FP.call('del', 'sshKey', undefined, arg).then(function (r) {
        changed(r, name, 'delete', t('sk_deleted', {name: name}));
      }, function (err) { rowError(b, err); });
    }
  }
  document.addEventListener('click', onClick);

  FP.view('tool:ssh_keys', function () {
    var tool = FP.tools.ssh_keys;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('sk_desc'), cls: 'fp-mail fp-sk',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    S = {page: body, account: FP.account(), list: null, view: null, suspended: false};
    var mine = S;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all([FP.call('get', 'sshKeys', undefined, S.account), FP.summary().then(function (a) { return a; }, function () { return null; })]).then(function (r) {
      if (S !== mine) { return; }
      S.list = clean(r[0]);
      S.suspended = !!(r[1] && r[1].status === 'suspended');
      render();
    }, function (err) {
      if (S !== mine) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

/* freePanel certificate guide (#/tool/ssl_guide), the customer panel's step-by-step way to a certificate for one website
   (docs/api.md, "Domains and sites" and "Private keys and certificate requests"). Step 1 picks the website and says what
   it has now; step 2 picks how: the server's free certificate, buying one (when the host sells them), or one from an
   authority of the customer's choice, for which the guide makes the key and the request (POST .../ssl/keys, POST
   .../ssl/csrs), shows the request to copy, and installs what the authority sends back with that key (PUT
   .../certificate with key_id). The key never leaves the server. Page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var DOMAIN_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var CERT_BEGIN = '-----BEGIN CERTIFICATE-----';
  var MAX_CHAIN = 64 * 1024;
  var G = null;

  function str(v) { return typeof v === 'string' ? v : ''; }
  function clean(v) {
    v = v && typeof v === 'object' ? v : {};
    return (Array.isArray(v.sites) ? v.sites : []).filter(function (s) { return s && DOMAIN_RE.test(str(s.domain)); }).map(function (s) {
      var c = s.certificate && typeof s.certificate === 'object' && (s.certificate.source === 'free' || s.certificate.source === 'installed') ? s.certificate : null;
      var end = c ? new Date(str(c.not_after)) : null;
      return {domain: s.domain, aliases: (Array.isArray(s.aliases) ? s.aliases : []).filter(function (a) { return DOMAIN_RE.test(str(a)); }).slice(0, 19),
        cert: c ? {source: c.source, expired: c.expired === true, end: end && !isNaN(end.getTime()) ? end : null} : null};
    }).sort(function (a, b) { return a.domain < b.domain ? -1 : 1; });
  }
  function site() { return G.sites.filter(function (s) { return s.domain === G.domain; })[0] || null; }
  function day(d) { return d ? d.toLocaleDateString('en', {dateStyle: 'medium'}) : ''; }
  function nowLine(s) {
    if (!s.cert) { return t('sslg_now_none', {domain: s.domain}); }
    if (s.cert.expired) { return t('sslg_now_expired', {domain: s.domain, date: day(s.cert.end)}); }
    return t(s.cert.source === 'free' ? 'sslg_now_free' : 'sslg_now_installed', {domain: s.domain, date: day(s.cert.end)});
  }

  function stepCard(id, n, title, parts) {
    return M.card(id, t('sslg_step', {n: n, title: title}), parts, 'fp-sslg-step');
  }

  /* step 3 for a certificate from an authority: make the key and the request, then install what comes back */
  function authorityCards() {
    var s = site();
    var out = [];
    var make = el('form', {class: 'fp-form fp-mail-form fp-sslg-make', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('p', {class: 'fp-muted', text: t('sslg_make_what', {names: [s.domain].concat(s.aliases).join(', ')})}),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('sslg_make')})])]);
    if (G.csr) {
      var csr = el('textarea', {class: 'sig-input sig-mono fp-sslg-csr', id: 'fp-sslg-csr', rows: '10', readonly: '', spellcheck: 'false', wrap: 'off'});
      csr.value = G.csr;
      make.appendChild(M.field('fp-sslg-csr', t('sslg_csr'), csr, t('sslg_csr_hint')));
    }
    make.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(make);
      if (!b) { return; }
      var mine = G;
      var domain = G.domain;
      UI.setBusy(b, true);
      M.say(make, t('sslg_making'));
      FP.call('post', 'sslKeyNew', {label: domain.slice(0, 64)}, mine.account).then(function (k) {
        if (G !== mine || !k || typeof k.id !== 'string') { throw new Error(t('api_failed')); }
        mine.keyId = k.id;
        return FP.call('post', 'sslCsrs', {key_id: k.id, names: [domain].concat(site().aliases)}, mine.account);
      }).then(function (r) {
        if (G !== mine) { return; }
        mine.csr = r && typeof r.csr === 'string' ? r.csr.slice(0, 16384) : '';
        draw('#fp-sslg-csr');
        M.say(G.page.querySelector('.fp-sslg-make'), t('sslg_made'));
      }, function (err) {
        if (G !== mine) { return; }
        UI.setBusy(b, false);
        M.say(make, '');
        M.failed(make, err);
      });
    });
    out.push(stepCard('fp-sslg-3-h', 3, t('sslg_step3'), [make]));
    if (G.keyId) {
      var cert = el('textarea', {class: 'sig-input sig-mono fp-sslg-cert', id: 'fp-sslg-cert', rows: '10', spellcheck: 'false', wrap: 'off'});
      var inst = el('form', {class: 'fp-form fp-mail-form fp-sslg-install', novalidate: ''}, [M.errorLine(), M.statusLine(),
        M.field('fp-sslg-cert', t('sslg_cert'), cert, t('sslg_cert_hint')),
        el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('sslg_install')})])]);
      inst.addEventListener('submit', function (e) {
        e.preventDefault();
        var b = M.start(inst);
        if (!b) { return; }
        var c = cert.value.trim();
        if (!c) { M.fieldError(inst, cert, t('sslg_cert_empty')); return; }
        if (c.indexOf(CERT_BEGIN) < 0) { M.fieldError(inst, cert, t('sslg_cert_bad')); return; }
        if (c.length > MAX_CHAIN) { M.fieldError(inst, cert, t('sslg_cert_long')); return; }
        var mine = G;
        UI.setBusy(b, true);
        FP.call('put', 'siteCertificate', {certificate: c + '\n', key_id: mine.keyId}, {name: mine.account, domain: mine.domain}).then(function (r) {
          if (G !== mine) { return; }
          mine.sites = clean(r);
          UI.setBusy(b, false);
          cert.value = '';
          M.say(inst, t('sslg_installed', {domain: mine.domain}));
          var now = G.page.querySelector('[data-fp-now]');
          if (now && site()) { now.textContent = nowLine(site()); }
        }, function (err) {
          if (G !== mine) { return; }
          UI.setBusy(b, false);
          M.failed(inst, err);
        });
      });
      out.push(stepCard('fp-sslg-4-h', 4, t('sslg_step4'), [inst]));
    }
    return out;
  }

  function draw(focus) {
    var page = G.page;
    page.textContent = '';
    if (!G.sites.length) { page.appendChild(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('php_no_sites')})); return; }
    var pick = el('select', {class: 'sig-select', id: 'fp-sslg-site', name: 'domain'}, G.sites.map(function (s) {
      return el('option', {value: s.domain, text: s.domain, selected: s.domain === G.domain ? true : null});
    }));
    pick.addEventListener('change', function () { G.domain = pick.value; G.how = ''; G.keyId = ''; G.csr = ''; draw('#fp-sslg-site'); });
    var s = site();
    page.appendChild(stepCard('fp-sslg-1-h', 1, t('sslg_step1'), [el('div', {class: 'fp-form'}, [M.field('fp-sslg-site', t('sslg_site'), pick, t('sslg_site_hint'))]),
      el('p', {class: 'fp-sslg-now', role: 'status', 'data-fp-now': '', text: nowLine(s)})]));
    var ways = ['free'];
    if (FP.tools.ssl_buy) { ways.push('buy'); }
    ways.push('authority');
    var radios = ways.map(function (w) {
      var id = 'fp-sslg-how-' + w;
      return el('div', {class: 'fp-radio-row'}, [el('label', {class: 'fp-check', for: id}, [
        el('input', {type: 'radio', name: 'sslg-how', id: id, value: w, checked: G.how === w ? true : null, 'aria-describedby': id + '-note'}),
        el('span', {text: t('sslg_how_' + w)})]), el('span', {class: 'fp-muted fp-row-note', id: id + '-note', text: t('sslg_how_' + w + '_note')})]);
    });
    var set = el('fieldset', {class: 'fp-fieldset fp-sslg-how'}, [el('legend', {text: t('sslg_how')})].concat(radios));
    set.addEventListener('change', function (e) {
      if (e.target && e.target.name === 'sslg-how') { G.how = e.target.value; draw('#fp-sslg-how-' + G.how); }
    });
    page.appendChild(stepCard('fp-sslg-2-h', 2, t('sslg_step2'), [set]));
    if (G.how === 'free') {
      var has = s.cert && s.cert.source === 'free' && !s.cert.expired;
      page.appendChild(stepCard('fp-sslg-3-h', 3, t('sslg_step3_free'), [el('p', {text: t(has ? 'sslg_free_has' : 'sslg_free_wait', {domain: s.domain})}),
        el('p', null, [el('a', {class: 'sig-link', href: '#/tool/ssl', text: t('sslg_open_ssl')})])]));
    } else if (G.how === 'buy') {
      page.appendChild(stepCard('fp-sslg-3-h', 3, t('sslg_step3_buy'), [el('p', {text: t('sslg_buy_what')}),
        el('p', null, [el('a', {class: 'sig-link', href: '#/tool/ssl_buy', text: t('sslg_open_buy')})])]));
    } else if (G.how === 'authority') {
      authorityCards().forEach(function (c) { page.appendChild(c); });
    }
    var target = focus ? page.querySelector(focus) : null;
    if (target) { target.focus(); }
  }

  FP.view('tool:ssl_guide', function () {
    G = null;
    var tool = FP.tools.ssl_guide;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('sslg_desc'), cls: 'fp-mail fp-site fp-sslg-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    var mine = G = {page: body, account: FP.account(), sites: [], domain: '', how: '', keyId: '', csr: ''};
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'domains', undefined, mine.account).then(function (r) {
      if (G !== mine) { return; }
      mine.sites = clean(r);
      mine.domain = mine.sites.length ? mine.sites[0].domain : '';
      draw();
    }, function (err) {
      if (G !== mine) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

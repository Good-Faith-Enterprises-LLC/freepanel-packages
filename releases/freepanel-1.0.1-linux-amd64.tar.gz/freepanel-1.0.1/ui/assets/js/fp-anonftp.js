/* freePanel anonymous FTP (#/tool/anonymous_ftp), the customer panel's page for the account's own anonymous FTP
   (docs/api.md, "Anonymous FTP"): a folder anyone may download from without a password, and optionally a drop folder
   anyone may upload to but not read. The server's admin turns each side on for the server first; uploads need the
   account to accept the risk. What the server sends (its refusals, why the account isn't served) is drawn as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var V = null;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function clean(r) {
    if (!r || typeof r !== 'object' || !r.account || typeof r.account !== 'object') { return null; }
    var a = r.account;
    return {server: r.server_enabled === true, serverUploads: r.server_uploads === true,
      enabled: a.enabled === true, uploads: a.uploads === true, ownIP: a.own_ip === true,
      serving: a.serving === true, uploadsOpen: a.uploads_open === true, problem: str(a.problem)};
  }

  /* where the account stands, in one line and a pill */
  function stateOf(s) {
    if (!s.server) { return {pill: 'aftp_pill_unavailable', tone: '', line: 'aftp_state_server_off'}; }
    if (!s.ownIP && !s.enabled) { return {pill: 'aftp_pill_unavailable', tone: '', line: 'aftp_state_no_ip'}; }
    if (!s.enabled) { return {pill: 'aftp_pill_off', tone: '', line: 'aftp_state_off'}; }
    if (!s.serving) { return {pill: 'aftp_pill_held', tone: ' sig-pill--warn', line: 'aftp_state_held'}; }
    return {pill: s.uploadsOpen ? 'aftp_pill_on_uploads' : 'aftp_pill_on', tone: ' sig-pill--ok', line: s.uploadsOpen ? 'aftp_state_on_uploads' : 'aftp_state_on'};
  }

  function statusCard() {
    var s = V.s;
    var st = stateOf(s);
    var parts = [el('p', {class: 'fp-aftp-state'}, [el('span', {class: 'sig-pill' + st.tone, 'data-fp-aftp-pill': '', text: t(st.pill)}),
      el('span', {'data-fp-aftp-line': '', text: t(st.line)})])];
    if (s.enabled && !s.serving && s.problem) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-aftp-problem': ''}, [UI.icon(FP.ui, 'ui_warning'),
        el('span', {text: t('aftp_problem', {why: s.problem})})]));
    }
    if (s.enabled && s.serving) {
      parts.push(el('dl', {class: 'fp-aftp-how'}, [
        el('dt', {text: t('aftp_how_connect')}), el('dd', {text: t('aftp_how_connect_v')}),
        el('dt', {text: t('aftp_how_login')}), el('dd', {}, [el('span', {class: 'sig-mono', text: 'anonymous'}), el('span', {text: ' ' + t('aftp_how_login_v')})]),
        el('dt', {text: t('aftp_how_pub')}), el('dd', {}, [el('span', {text: t('aftp_how_pub_v') + ' '}), el('span', {class: 'sig-mono', text: '~/public_ftp'})]),
        s.uploadsOpen ? el('dt', {text: t('aftp_how_incoming')}) : null,
        s.uploadsOpen ? el('dd', {}, [el('span', {text: t('aftp_how_incoming_v') + ' '}), el('span', {class: 'sig-mono', text: '~/.anonftp-incoming'})]) : null]));
    }
    return M.card('fp-aftp-state-h', t('aftp_state_title'), parts, 'fp-aftp-status');
  }

  function settingsCard() {
    var s = V.s;
    var parts = [];
    var available = s.server && (s.ownIP || s.enabled);
    var on = el('input', {type: 'checkbox', id: 'fp-aftp-on', name: 'enabled', checked: s.enabled ? true : null,
      disabled: available ? null : true, 'aria-describedby': 'fp-aftp-on-hint'});
    var up = el('input', {type: 'checkbox', id: 'fp-aftp-up', name: 'uploads', checked: s.uploads ? true : null,
      disabled: available && s.serverUploads && s.enabled ? null : true, 'aria-describedby': 'fp-aftp-up-hint'});
    var risk = el('input', {type: 'checkbox', id: 'fp-aftp-risk', name: 'accept_upload_risk', checked: s.uploads ? true : null,
      'aria-describedby': 'fp-aftp-risk-text'});
    var riskBox = el('div', {class: 'fp-aftp-risk', 'data-fp-aftp-risk': '', hidden: up.checked && !up.disabled ? null : true}, [
      el('div', {class: 'sig-banner sig-banner--warn', role: 'note'}, [UI.icon(FP.ui, 'ui_warning'), el('span', {id: 'fp-aftp-risk-text', text: t('aftp_risk')})]),
      el('label', {class: 'fp-check', for: 'fp-aftp-risk'}, [risk, el('span', {text: t('aftp_risk_accept')})])]);
    var upHint = !s.serverUploads ? t('aftp_uploads_server_off') : t('aftp_uploads_hint');
    var form = el('form', {class: 'fp-form fp-aftp-form', novalidate: ''}, [
      M.errorLine(), M.statusLine(),
      el('label', {class: 'fp-check', for: 'fp-aftp-on'}, [on, el('span', {text: t('aftp_on')})]),
      el('span', {class: 'sig-hint', id: 'fp-aftp-on-hint', text: t('aftp_on_hint')}),
      el('label', {class: 'fp-check', for: 'fp-aftp-up'}, [up, el('span', {text: t('aftp_uploads')})]),
      el('span', {class: 'sig-hint', id: 'fp-aftp-up-hint', text: upHint}),
      riskBox,
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', disabled: available ? null : true,
        text: t('aftp_save')})])]);
    on.addEventListener('change', function () {
      up.disabled = !(on.checked && s.serverUploads);
      if (!on.checked) { up.checked = false; }
      riskBox.hidden = !(up.checked && !up.disabled);
    });
    up.addEventListener('change', function () {
      riskBox.hidden = !up.checked;
      if (up.checked) { risk.checked = false; }
    });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      if (up.checked && !risk.checked) { M.fieldError(form, UI.fieldNamed(form, 'accept_upload_risk'), t('aftp_risk_needed')); return; }
      var body = {enabled: on.checked, uploads: on.checked && up.checked};
      if (body.uploads) { body.accept_upload_risk = true; }
      var mine = V;
      UI.setBusy(b, true);
      M.say(form, t('aftp_saving'));
      FP.call('put', 'anonFtp', body, V.account).then(function (r) {
        if (V !== mine) { return; }
        var next = clean(r);
        if (next) { V.s = next; }
        render();
        var card = V.page.querySelector('.fp-aftp-settings');
        card.querySelector('.fp-submit').focus();
        M.say(card, t(!V.s.enabled ? 'aftp_saved_off' : V.s.serving ? 'aftp_saved_on' : 'aftp_saved_held'));
      }, function (err) {
        if (V !== mine) { return; }
        UI.setBusy(b, false);
        M.say(form, '');
        M.failed(form, err);
      });
    });
    parts.push(form);
    parts.push(el('p', {class: 'fp-muted', text: t('aftp_note')}));
    return M.card('fp-aftp-set-h', t('aftp_set_title'), parts, 'fp-aftp-settings');
  }

  function render() {
    V.page.textContent = '';
    V.page.appendChild(statusCard());
    V.page.appendChild(settingsCard());
  }

  FP.view('tool:anonymous_ftp', function () {
    var tool = FP.tools.anonymous_ftp;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('aftp_desc'), cls: 'fp-mail fp-aftp',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    V = {page: body, account: FP.account(), s: null};
    var mine = V;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'anonFtp', undefined, V.account).then(function (r) {
      if (V !== mine) { return; }
      var s = clean(r);
      body.textContent = '';
      if (!s) { body.appendChild(FP.empty(tool.label, t('api_failed'))); return; }
      V.s = s;
      render();
    }, function (err) {
      if (V !== mine) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

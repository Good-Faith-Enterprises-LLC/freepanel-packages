/* freePanel support sign-in, /support/#TOKEN (docs/api.md, "Support sign-in"): the page a link made in the server panel opens. It reads the one-time token from the
   fragment, removes it from the address bar at once, posts it to the customer panel and, when the server answers with a session, goes to the panel, where
   a banner says on every screen that this is a support session. The link is good once, for a minute and only from the address that asked, so a link that
   is refused is not tried again; a refusal for too many tries or a failed connection may be (the token is kept in this page only). The server's words are
   shown as text. */
(function () {
  'use strict';
  var UI = window.FPUI;
  var API = window.FPAPI;
  var t = UI.t;
  var TOKEN_RE = /^[A-Za-z0-9_\-.~%+=]{16,512}$/;

  var token = window.location.hash.replace(/^#/, '');
  if (window.location.hash && window.history && window.history.replaceState) {
    window.history.replaceState(null, '', window.location.pathname + window.location.search);
  }

  function $(sel) { return document.querySelector(sel); }
  var title = $('#fp-h-support');
  var working = $('[data-fp-working]');
  var why = $('[data-fp-why]');
  var how = $('[data-fp-how]');
  var retry = $('[data-fp-retry]');
  var busy = false;

  function stop(reason, advice, again) {
    working.hidden = true;
    title.textContent = t('spl_title_failed');
    why.textContent = reason;
    why.hidden = false;
    how.textContent = advice;
    how.hidden = false;
    retry.hidden = !again;
    document.title = t('spl_title_failed') + ' · ' + UI.brand.name;
    title.focus();
  }

  function refused(err) {
    var status = err && typeof err.status === 'number' ? err.status : 0;
    if (status === 401) { token = ''; stop(t('spl_bad'), t('spl_bad_how'), false); return; }
    if (status === 409) { token = ''; stop(t('spl_unavailable', {reason: err.message}), t('spl_unavailable_how'), false); return; }
    if (status === 404) { token = ''; stop(t('spl_wrong_panel'), t('spl_wrong_panel_how'), false); return; }
    /* too many tries, a server that failed, a connection that did not hold: the link may still be good, so it can be tried again */
    stop(err && err.message ? err.message : t('spl_failed'), t('spl_again_how'), true);
  }

  function go() {
    if (busy) { return; }
    busy = true;
    title.textContent = t('spl_title');
    why.hidden = true;
    how.hidden = true;
    retry.hidden = true;
    working.hidden = false;
    working.textContent = t('spl_working');
    API.post('supportSignin', {token: token}).then(function () {
      token = '';
      working.textContent = t('spl_in');
      window.location.replace('/');
    }, function (err) {
      busy = false;
      refused(err);
    });
  }

  retry.addEventListener('click', go);
  UI.loadBrand();
  if (!TOKEN_RE.test(token)) { token = ''; stop(t('spl_missing'), t('spl_missing_how'), false); } else { go(); }
})();

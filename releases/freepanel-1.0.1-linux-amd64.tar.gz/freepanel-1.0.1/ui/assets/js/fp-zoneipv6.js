/* freePanel IPv6 for a zone (docs/api.md, "DNS zones", IPv6 for a zone that exists): the customer panel's page (#/tool/zone_ipv6) for giving the names of a
   zone that point at this server over IPv4 an AAAA record for the server's IPv6 address, or taking those records away. A name that already has an AAAA
   record for another address is left alone. The zone is read with its serial and the change sends it, so a zone that changed meanwhile is read again
   (the server answers 409). The page needs the server's IPv6 address to be set and says so when it is not. Everything the server sends is shown as
   text. The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  /* the address a page's paths are built from; FP.account() is the member-aware name (#329), the login until that is on the panel */
  function accountName() { return typeof FP.account === 'function' ? FP.account() : FP.session.user['username']; }

  var ZONE_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var NAME_RE = /^(?=.{1,253}$)(\*\.|[a-z0-9_]([a-z0-9_-]{0,61}[a-z0-9_])?\.)*[a-z0-9_]([a-z0-9_-]{0,61}[a-z0-9_])?\.[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var STATES = ['missing', 'ok', 'other'];

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  function clean(v) {
    v = v && typeof v === 'object' ? v : {};
    return {zone: ZONE_RE.test(str(v.zone, 253)) ? v.zone : '', serial: typeof v.serial === 'number' && isFinite(v.serial) ? v.serial : null, address: str(v.address, 45),
      available: v.available === true, reason: str(v.reason, 400), enabled: v.enabled === true,
      names: (Array.isArray(v.names) ? v.names : []).filter(function (n) { return n && typeof n === 'object' && NAME_RE.test(str(n.name, 253)) && STATES.indexOf(n.state) >= 0; }).slice(0, 1000)
        .map(function (n) { return {name: n.name, state: n.state}; })};
  }

  var Z = {page: null, account: '', zones: [], cur: null, busy: false, out: null};

  function nameRow(n) {
    var pillClass = n.state === 'ok' ? ' sig-pill--ok' : n.state === 'other' ? '' : ' sig-pill--warn';
    return el('li', {class: 'fp-v6z-name', 'data-fp-state': n.state}, [el('span', {class: 'sig-mono fp-v6z-n', text: n.name}), el('span', {class: 'sig-pill' + pillClass, text: t('v6z_state_' + n.state)})]);
  }
  function showZone() {
    var c = Z.cur;
    Z.out.textContent = '';
    var parts = [M.errorLine(), M.statusLine()];
    if (!c.available) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-v6z-unavailable': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('v6z_unavailable', {reason: c.reason || t('v6z_no_reason')})})]));
    } else {
      parts.push(el('p', {class: 'fp-v6z-now', 'data-fp-enabled': c.enabled ? 'yes' : 'no'}, [el('span', {class: 'sig-pill' + (c.enabled ? ' sig-pill--ok' : ''), text: c.enabled ? t('v6z_on') : t('v6z_off')}), ' ',
        el('span', {text: t('v6z_address', {address: c.address})})]));
    }
    parts.push(el('p', {class: 'fp-muted', text: t('v6z_what')}));
    if (!c.names.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('v6z_none')}));
    } else {
      parts.push(el('ul', {class: 'fp-v6z-list', 'aria-labelledby': 'fp-v6z-zone-h'}, c.names.map(nameRow)));
    }
    /* what is offered follows the names, not the zone's on or off: records can be given to the names that lack one while the server's address is on the
       server, and taken away from the names that have one whether it is or not (the server refuses only turning them on then) */
    var acts = [];
    if (c.available && c.names.some(function (n) { return n.state === 'missing'; })) {
      acts.push(el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'v6z-on', text: t('v6z_turn_on')}));
    }
    if (c.names.some(function (n) { return n.state === 'ok'; })) {
      acts.push(el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'v6z-off', text: t('v6z_turn_off')}));
    }
    if (acts.length) { parts.push(el('div', {class: 'fp-actions fp-v6z-acts'}, acts)); }
    if (c.available && c.names.length) { parts.push(el('p', {class: 'fp-muted sig-hint', text: t('v6z_mail_note')})); }
    var card = M.card('fp-v6z-zone-h', t('v6z_zone_title', {zone: c.zone}), parts, 'fp-v6z-card');
    Z.out.appendChild(card);
  }
  function load(zone, focus) {
    var mine = Z.page;
    return FP.call('get', 'zoneIpv6', undefined, {name: Z.account, zone: zone}).then(function (r) {
      if (Z.page !== mine) { return; }
      Z.cur = clean(r);
      if (!Z.cur.zone) { Z.cur.zone = zone; }
      showZone();
      if (focus) { Z.out.querySelector('#fp-v6z-zone-h').focus(); }
    }, function (err) {
      if (Z.page !== mine) { return; }
      Z.out.textContent = '';
      Z.cur = null;
      Z.out.appendChild(el('div', {class: 'fp-alert is-shown', role: 'alert', 'data-fp-v6z-load-error': '', text: err.message}));
    });
  }
  function change(b, enabled) {
    if (Z.busy || !Z.cur || Z.cur.serial === null) { return; }
    Z.busy = true;
    UI.setBusy(b, true);
    var mine = Z.page;
    var zone = Z.cur.zone;
    FP.call('put', 'zoneIpv6', {serial: Z.cur.serial, enabled: enabled}, {name: Z.account, zone: zone}).then(function (r) {
      Z.busy = false;
      if (Z.page !== mine) { return; }
      Z.cur = clean(r);
      if (!Z.cur.zone) { Z.cur.zone = zone; }
      showZone();
      M.say(Z.out.querySelector('.fp-v6z-card'), t(enabled ? 'v6z_turned_on' : 'v6z_turned_off', {zone: zone}));
      Z.out.querySelector('#fp-v6z-zone-h').focus();
    }, function (err) {
      Z.busy = false;
      if (Z.page !== mine) { return; }
      if (err && err.status === 409 && /changed since it was loaded/i.test(err.message)) {
        /* the zone changed meanwhile (the stale serial; every other 409 is the server's own reason, such as an address that is not on the server): read it
           again, and say so */
        load(zone, true).then(function () { if (Z.cur) { UI.showError(Z.out.querySelector('.fp-v6z-card'), t('v6z_changed')); } });
        return;
      }
      showZone();
      UI.showError(Z.out.querySelector('.fp-v6z-card'), err.message);
      Z.out.querySelector('#fp-v6z-zone-h').focus();
    });
  }

  document.addEventListener('click', function (e) {
    var node = e.target.closest ? e.target : null;
    var b = node && node.closest('[data-fp-act]');
    if (!b || !Z.page || !Z.page.contains(b) || !Z.cur) { return; }
    var a = b.getAttribute('data-fp-act');
    if (a === 'v6z-on') {
      change(b, true);
    } else if (a === 'v6z-off') {
      M.confirmIn(b.parentNode, t('v6z_ask_off', {zone: Z.cur.zone}), 'v6z-off-yes', t('v6z_ask_off_yes'));
    } else if (a === 'confirm-no') {
      showZone();
      var back = Z.out.querySelector('[data-fp-act="v6z-off"]');
      if (back) { back.focus(); }
    } else if (a === 'v6z-off-yes') {
      change(b, false);
    }
  });

  function chooser() {
    var sel = el('select', {class: 'sig-select', id: 'fp-v6z-zone', name: 'zone'}, Z.zones.map(function (z) { return el('option', {value: z, text: z}); }));
    var form = el('form', {class: 'fp-form fp-v6z-form', novalidate: ''}, [M.errorLine(), M.field('fp-v6z-zone', t('v6z_zone'), sel, t('v6z_zone_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('v6z_show')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || Z.busy) { return; }
      UI.setBusy(b, true);
      load(sel.value, true).then(function () { UI.setBusy(b, false); });
    });
    return form;
  }

  FP.view('tool:zone_ipv6', function () {
    var tool = FP.tools.zone_ipv6;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    Z.busy = false;
    Z.cur = null;
    Z.zones = [];
    Z.account = accountName();
    var body = FP.frame({title: tool.label, desc: t('v6z_desc'), cls: 'fp-mail fp-v6z-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    Z.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'accountZones', undefined, Z.account).then(function (r) {
      if (Z.page !== body) { return; }
      var list = (r && Array.isArray(r.zones) ? r.zones : []).filter(function (z) { return z && ZONE_RE.test(str(z.zone, 253)); });
      list.sort(function (a, b) { return (b.primary === true) - (a.primary === true) || (a.zone < b.zone ? -1 : 1); });
      Z.zones = list.map(function (z) { return z.zone; });
      body.textContent = '';
      if (!Z.zones.length) {
        body.appendChild(M.card('fp-v6z-ask-h', t('v6z_title'), [el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('v6z_no_zone')})], 'fp-v6z-ask'));
        return;
      }
      body.appendChild(M.card('fp-v6z-ask-h', t('v6z_title'), [el('p', {class: 'fp-muted', text: t('v6z_intro')}), chooser()], 'fp-v6z-ask'));
      Z.out = el('div', {class: 'fp-v6z-out', role: 'region', 'aria-label': t('v6z_result'), 'data-fp-out': ''});
      body.appendChild(Z.out);
      load(Z.zones[0], false);
    }, function (err) {
      if (Z.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

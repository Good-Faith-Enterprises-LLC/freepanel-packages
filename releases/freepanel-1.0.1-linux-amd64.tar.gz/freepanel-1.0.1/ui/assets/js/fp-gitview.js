/* freePanel Git viewer (#/tool/git_view), the customer panel's read only look at the account's own repositories (docs/api.md, "Git
   repositories", "Viewer"): the branches and tags, the history of one, a commit with the files it changed and its patch, and the
   folders and files of a commit. It changes nothing. Everything the server sends is drawn as text (textContent), never as markup:
   names, messages, patches and the content of files are the repository's, which is the account's to write. A long patch or file is cut by
   the server, and this page draws at most MAX_LINES lines of what it gets. It shares the mail pages' look and helpers (FP.mail). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var NAME_RE = /^[a-z0-9][a-z0-9._-]{0,63}$/;
  var REF_RE = /^[A-Za-z0-9][A-Za-z0-9._/-]{0,99}$/;
  var SHA_RE = /^[0-9a-f]{40}([0-9a-f]{24})?$/;
  var VIEWABLE = {ready: true, updating: true, deploying: true};
  var TYPES = {folder: 'gv_type_folder', file: 'gv_type_file', link: 'gv_type_link', submodule: 'gv_type_submodule'};
  var PAGE = 30;
  var MAX_LINES = 5000;
  var TABS = [['files', 'gv_tab_files'], ['history', 'gv_tab_history'], ['branches', 'gv_tab_branches']];
  var TAB_OF = {files: 'files', file: 'files', history: 'history', commit: 'history', branches: 'branches'};
  var G = {page: null, account: '', repos: [], repo: '', ref: '', view: 'files', path: '', skip: 0, sha: '', branches: null, seq: 0};

  /* the marks that turn text around (U+202E and the like) are taken out of everything the repository wrote, whatever the server did: a
     name or a patch could use them to show other words than the ones it holds */
  var TURNERS = /[؜‎‏‪-‮⁦-⁩]/g;
  function str(v, n) { return typeof v === 'string' ? v.replace(TURNERS, '').slice(0, n || 300) : ''; }
  function text(v, n) { return typeof v === 'string' ? v.replace(TURNERS, '').slice(0, n) : ''; }
  function num(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.floor(v) : 0; }
  function sha(v) { return typeof v === 'string' && SHA_RE.test(v) ? v : ''; }
  function when(iso) {
    var d = iso ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString(undefined, {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }
  function size(n) {
    if (n === 1) { return t('gv_size_one'); }
    if (n < 1024) { return t('gv_size_bytes', {n: n.toLocaleString('en')}); }
    if (n < 1048576) { return t('gv_size_kb', {n: (Math.round(n / 102.4) / 10).toLocaleString('en')}); }
    return t('gv_size_mb', {n: (Math.round(n / 104857.6) / 10).toLocaleString('en')});
  }

  /* ---- what the server sends, checked before it is drawn ---- */
  function cleanRepos(v) {
    var list = v && typeof v === 'object' && Array.isArray(v.repos) ? v.repos : null;
    if (!list) { return null; }
    return list.filter(function (r) { return r && typeof r === 'object' && NAME_RE.test(str(r.name, 80)) && VIEWABLE[r.status]; })
      .map(function (r) { return r.name; }).sort().slice(0, 60);
  }
  function cleanBranches(v) {
    if (!v || typeof v !== 'object' || !Array.isArray(v.branches) || !Array.isArray(v.tags)) { return null; }
    var branches = v.branches.filter(function (b) { return b && REF_RE.test(str(b.name, 110)) && sha(b.sha); }).slice(0, 500).map(function (b) {
      return {name: b.name, sha: b.sha, subject: str(b.subject, 300), when: str(b.when, 40), current: b.current === true};
    });
    var tags = v.tags.filter(function (g) { return g && REF_RE.test(str(g.name, 110)) && sha(g.sha); }).slice(0, 500).map(function (g) {
      return {name: g.name, sha: g.sha};
    });
    return {branches: branches, tags: tags, skipped: num(v.skipped), truncated: v.truncated === true};
  }
  function cleanLog(v) {
    if (!v || typeof v !== 'object' || !Array.isArray(v.commits)) { return null; }
    return {skip: num(v.skip), more: v.more === true, commits: v.commits.slice(0, 100).filter(function (c) { return c && sha(c.sha); }).map(function (c) {
      return {sha: c.sha, parents: Array.isArray(c.parents) ? c.parents.filter(sha).slice(0, 8) : [], author: str(c.author, 120), when: str(c.when, 40),
        subject: str(c.subject, 320)};
    })};
  }
  function cleanShow(v) {
    var c = v && typeof v === 'object' && v.commit && typeof v.commit === 'object' ? v.commit : null;
    if (!c || !sha(c.sha) || !Array.isArray(v.files)) { return null; }
    return {
      commit: {sha: c.sha, parents: Array.isArray(c.parents) ? c.parents.filter(sha).slice(0, 8) : [], author: str(c.author, 120), when: str(c.when, 40),
        subject: str(c.subject, 320), message: str(c.message, 17000), cut: c.message_truncated === true},
      files: v.files.slice(0, 500).filter(function (f) { return f && typeof f.path === 'string' && f.path; }).map(function (f) {
        return {path: str(f.path, 1100), old: str(f.old_path, 1100), added: num(f.added), deleted: num(f.deleted), binary: f.binary === true};
      }),
      filesCut: v.files_truncated === true, diff: str(v.diff, 270000), diffCut: v.diff_truncated === true, merge: v.merge === true};
  }
  function cleanTree(v) {
    if (!v || typeof v !== 'object' || !Array.isArray(v.entries)) { return null; }
    return {path: str(v.path, 1100), cut: v.truncated === true,
      entries: v.entries.slice(0, 2000).filter(function (e) { return e && TYPES[e.type] && typeof e.name === 'string' && e.name; }).map(function (e) {
        return {name: str(e.name, 300), type: e.type, size: num(e.size)};
      })};
  }
  function cleanBlob(v) {
    if (!v || typeof v !== 'object' || !sha(v.commit)) { return null; }
    return {commit: v.commit, path: str(v.path, 1100), size: num(v.size), binary: v.binary === true, link: v.link === true, cut: v.truncated === true,
      content: text(v.content, 270000)};
  }

  /* ---- page pieces ---- */
  function here() { return Boolean(G.page && G.page.isConnected); }
  function stale(my) { return my !== G.seq || !here(); }
  function viewCard() { return G.page.querySelector('.fp-gv-view'); }
  function content() { return G.page.querySelector('.fp-gv-content'); }
  function heading() { return G.page.querySelector('#fp-gv-h'); }
  function focusHeading() { var h = heading(); if (h) { h.focus(); } }
  function begin(title) {
    var my = ++G.seq;
    heading().textContent = title;
    UI.showError(viewCard(), '');
    M.say(viewCard(), '');
    var c = content();
    c.textContent = '';
    c.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    return my;
  }
  function fail(err) { content().textContent = ''; UI.showError(viewCard(), err && err.message ? err.message : t('api_failed')); }
  function refLabel() {
    if (SHA_RE.test(G.ref)) { return t('gv_ref_commit', {sha: G.ref.slice(0, 7)}); }
    return G.ref;
  }
  function note(text) { return el('p', {class: 'fp-muted', text: text}); }
  function pill(text, cls) { return el('span', {class: 'sig-pill' + (cls ? ' sig-pill--' + cls : ''), text: text}); }
  function action(act, label, extra) {
    var b = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': act, text: label});
    Object.keys(extra || {}).forEach(function (k) { b.setAttribute(k, extra[k]); });
    return b;
  }
  function linkButton(act, label, extra) {
    var b = el('button', {class: 'fp-linkbtn', type: 'button', 'data-fp-act': act, text: label});
    Object.keys(extra || {}).forEach(function (k) { b.setAttribute(k, extra[k]); });
    return b;
  }
  /* num is the index of a column of numbers, which is set at the end of its cell */
  function table(label, head, rows, cls, num) {
    return el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-label': label}, [
      el('table', {class: 'sig-table fp-mail-table ' + (cls || '')}, [el('thead', null, [el('tr', null, head.map(function (h, i) {
        return el('th', {scope: 'col', class: i === num ? 'fp-gv-num' : '', text: h});
      }))]), el('tbody', null, rows)])]);
  }

  /* ---- the picker: which repository, which branch, tag or commit, and which view ---- */
  function pickCard() {
    var repo = el('select', {class: 'sig-select', id: 'fp-gv-repo', name: 'repo'}, G.repos.map(function (n) { return el('option', {value: n, text: n}); }));
    repo.value = G.repo;
    var ref = el('select', {class: 'sig-select', id: 'fp-gv-ref', name: 'ref', disabled: true});
    var tabs = el('div', {class: 'fp-gv-tabs', role: 'group', 'aria-label': t('gv_views'), hidden: true});
    repo.addEventListener('change', function () {
      G.repo = repo.value;
      G.ref = '';
      G.path = '';
      G.skip = 0;
      G.sha = '';
      G.view = 'files';
      loadRepo();
    });
    ref.addEventListener('change', function () {
      G.ref = ref.value;
      G.skip = 0;
      G.sha = '';
      toFolder();
      if (G.view === 'commit') { G.view = 'history'; }
      showView(false);
    });
    return M.card('fp-gv-pick-h', t('gv_pick_title'), [
      el('div', {class: 'fp-gv-pickrow'}, [M.field('fp-gv-repo', t('gv_repo'), repo), M.field('fp-gv-ref', t('gv_ref'), ref)]),
      el('p', {class: 'fp-gv-now', 'data-fp-now': ''}), tabs], 'fp-gv-pick');
  }
  function viewShell() {
    return M.card('fp-gv-h', '', [M.errorLine(), M.statusLine(), el('div', {class: 'fp-gv-content'})], 'fp-gv-view');
  }
  /* the branch, tag and commit choices, with the one in use selected; a commit that is neither is added on top */
  function fillRefs() {
    var ref = G.page.querySelector('#fp-gv-ref');
    var b = G.branches;
    ref.textContent = '';
    if (!b.branches.length && !b.tags.length) {
      ref.appendChild(el('option', {value: '', text: t('gv_no_branches')}));
      ref.disabled = true;
      return;
    }
    var known = b.branches.concat(b.tags).some(function (x) { return x.name === G.ref; });
    if (G.ref && !known) { ref.appendChild(el('option', {value: G.ref, text: refLabel()})); }
    if (b.branches.length) {
      ref.appendChild(el('optgroup', {label: t('gv_ref_branches')}, b.branches.map(function (x) {
        return el('option', {value: x.name, text: x.current ? t('gv_ref_checked_out', {name: x.name}) : x.name});
      })));
    }
    if (b.tags.length) {
      ref.appendChild(el('optgroup', {label: t('gv_ref_tags')}, b.tags.map(function (x) { return el('option', {value: x.name, text: x.name}); })));
    }
    ref.value = G.ref;
    ref.disabled = false;
  }
  function fillNow() {
    var line = G.page.querySelector('[data-fp-now]');
    var b = G.branches;
    var found = b ? b.branches.filter(function (x) { return x.name === G.ref; })[0] : null;
    var tag = !found && b ? b.tags.filter(function (x) { return x.name === G.ref; })[0] : null;
    if (found) {
      line.textContent = t('gv_now', {ref: G.ref, sha: found.sha.slice(0, 7), subject: found.subject, date: when(found.when)});
    } else if (tag) {
      line.textContent = t('gv_now_short', {ref: G.ref, sha: tag.sha.slice(0, 7)});
    } else if (SHA_RE.test(G.ref)) {
      line.textContent = t('gv_now_short', {ref: refLabel(), sha: G.ref.slice(0, 7)});
    } else {
      line.textContent = '';
    }
  }
  /* a file is shown from the folder it is in when the view goes back to the files */
  function toFolder() {
    if (G.view !== 'file') { return; }
    G.view = 'files';
    G.path = G.path.indexOf('/') >= 0 ? G.path.slice(0, G.path.lastIndexOf('/')) : '';
  }
  function fillTabs() {
    var tabs = G.page.querySelector('.fp-gv-tabs');
    tabs.textContent = '';
    TABS.forEach(function (x) {
      var on = TAB_OF[G.view] === x[0];
      var b = el('button', {class: 'sig-btn sig-btn--sm ' + (on ? 'sig-btn--primary' : 'sig-btn--secondary'), type: 'button', 'data-fp-act': 'show-' + x[0], text: t(x[1])});
      if (on) { b.setAttribute('aria-current', 'page'); }
      tabs.appendChild(b);
    });
    tabs.hidden = false;
  }

  /* ---- a repository: its branches and tags first, then the view ---- */
  function loadRepo() {
    var my = begin(t('gv_files_title'));
    G.page.querySelector('#fp-gv-ref').disabled = true;
    G.page.querySelector('.fp-gv-tabs').hidden = true;
    G.page.querySelector('[data-fp-now]').textContent = '';
    FP.call('get', 'gitBranches', undefined, {name: G.account, repo: G.repo}).then(function (r) {
      if (stale(my)) { return; }
      var b = cleanBranches(r);
      if (!b) { fail(); return; }
      G.branches = b;
      if (!b.branches.length && !b.tags.length) {
        fillRefs();
        content().textContent = '';
        heading().textContent = t('gv_files_title');
        content().appendChild(note(t('gv_empty_repo', {name: G.repo})));
        return;
      }
      var cur = b.branches.filter(function (x) { return x.current; })[0] || b.branches[0];
      if (!G.ref) { G.ref = cur ? cur.name : b.tags[0].name; }
      showView(false);
    }, function (err) {
      if (stale(my)) { return; }
      fail(err);
    });
  }
  function showView(focus) {
    fillRefs();
    fillNow();
    fillTabs();
    var v = G.view;
    if (v === 'history') { showHistory(focus); } else if (v === 'commit') { showCommit(focus); } else if (v === 'branches') { showBranches(focus); } else if (v === 'file') { showFile(focus); } else { showFiles(focus); }
  }
  function ready(focus) { if (focus) { focusHeading(); } }

  /* ---- Files: a folder of the commit ---- */
  function crumbs(path) {
    var parts = path ? path.split('/') : [];
    var items = [el('li', null, [parts.length ? linkButton('show-dir', G.repo, {'data-fp-path': ''}) : el('span', {'aria-current': 'location', text: G.repo})])];
    parts.forEach(function (p, i) {
      var upTo = parts.slice(0, i + 1).join('/');
      var last = i === parts.length - 1;
      items.push(el('li', null, [last ? el('span', {'aria-current': 'location', text: p}) : linkButton('show-dir', p, {'data-fp-path': upTo})]));
    });
    return el('nav', {class: 'fp-gv-crumbs', 'aria-label': t('gv_folder_nav')}, [el('ol', null, items)]);
  }
  function showFiles(focus) {
    var my = begin(t('gv_files_title'));
    FP.call('get', 'gitTree', undefined, {name: G.account, repo: G.repo, ref: G.ref, path: G.path}).then(function (r) {
      if (stale(my)) { return; }
      var tr = cleanTree(r);
      if (!tr) { fail(); return; }
      drawTree(tr);
      ready(focus);
    }, function (err) {
      if (stale(my)) { return; }
      if (err && err.status === 404 && G.path) {
        var gone = G.path;
        G.path = '';
        showFiles(focus);
        M.say(viewCard(), t('gv_ref_gone', {path: gone, ref: refLabel()}));
        return;
      }
      fail(err);
    });
  }
  function drawTree(tr) {
    var c = content();
    c.textContent = '';
    c.appendChild(crumbs(G.path));
    if (!tr.entries.length) {
      c.appendChild(note(t('gv_folder_empty')));
      return;
    }
    var rows = tr.entries.map(function (e) {
      var full = (G.path ? G.path + '/' : '') + e.name;
      var name;
      if (e.type === 'folder') {
        name = linkButton('show-dir', e.name + '/', {'data-fp-path': full});
      } else if (e.type === 'submodule') {
        name = el('span', null, [el('span', {class: 'fp-gv-name', text: e.name}), el('span', {class: 'fp-muted fp-row-note', text: t('gv_submodule_note')})]);
      } else {
        name = linkButton('show-file', e.name, {'data-fp-path': full});
      }
      return el('tr', null, [el('td', {class: 'fp-gv-namecell'}, [name]), el('td', {text: t(TYPES[e.type])}),
        el('td', {class: 'fp-gv-num', text: e.type === 'file' || e.type === 'link' ? size(e.size) : ''})]);
    });
    c.appendChild(table(t('gv_files_list'), [t('gv_col_name'), t('gv_col_type'), t('gv_col_size')], rows, 'fp-gv-table', 2));
    if (tr.cut) { c.appendChild(note(t('gv_tree_cut', {n: tr.entries.length.toLocaleString('en')}))); }
  }

  /* ---- File: the text of one file ---- */
  function lines(text, cap) {
    var all = text.split('\n');
    if (all.length && all[all.length - 1] === '') { all.pop(); }
    return {list: all.slice(0, cap), cut: all.length > cap};
  }
  function showFile(focus) {
    var name = G.path.split('/').pop();
    var my = begin(name);
    FP.call('get', 'gitFile', undefined, {name: G.account, repo: G.repo, ref: G.ref, path: G.path}).then(function (r) {
      if (stale(my)) { return; }
      var f = cleanBlob(r);
      if (!f) { fail(); return; }
      var c = content();
      c.textContent = '';
      c.appendChild(crumbs(G.path));
      c.appendChild(el('p', {class: 'fp-muted fp-gv-meta', text: t('gv_file_meta', {size: size(f.size), sha: f.commit.slice(0, 7)})}));
      if (f.binary) {
        c.appendChild(note(t('gv_file_binary', {size: size(f.size)})));
      } else if (f.link) {
        c.appendChild(el('p', {class: 'fp-gv-linkto', text: t('gv_file_link', {target: f.content})}));
      } else if (!f.content) {
        c.appendChild(note(t('gv_file_empty')));
      } else {
        var l = lines(f.content, MAX_LINES);
        var code = el('pre', {class: 'fp-gv-code fp-gv-file', 'data-overflow-ok': '', 'data-overlap-ok': '', tabindex: '0', role: 'region', 'aria-label': t('gv_file_label', {path: G.path})},
          l.list.map(function (line) { return el('span', {class: 'fp-gv-l', text: line}); }));
        c.appendChild(code);
        if (f.cut) { c.appendChild(note(t('gv_file_cut', {size: size(f.size)}))); }
        if (l.cut) { c.appendChild(note(t('gv_lines_cut', {n: MAX_LINES.toLocaleString('en')}))); }
      }
      ready(focus);
    }, function (err) {
      if (stale(my)) { return; }
      fail(err);
    });
  }

  /* ---- History: the commits that lead to the branch, tag or commit ---- */
  function showHistory(focus) {
    var my = begin(t('gv_history_title'));
    FP.call('get', 'gitLog', undefined, {name: G.account, repo: G.repo, ref: G.ref, limit: String(PAGE), skip: String(G.skip)}).then(function (r) {
      if (stale(my)) { return; }
      var l = cleanLog(r);
      if (!l) { fail(); return; }
      var c = content();
      c.textContent = '';
      if (!l.commits.length) {
        c.appendChild(note(t('gv_log_none')));
        if (G.skip > 0) { c.appendChild(el('div', {class: 'fp-gv-acts'}, [action('prev-page', t('gv_newer'))])); }
        ready(focus);
        return;
      }
      c.appendChild(note(t('gv_log_page', {from: G.skip + 1, to: G.skip + l.commits.length})));
      c.appendChild(el('ol', {class: 'fp-gv-log'}, l.commits.map(function (x) {
        var top = [linkButton('show-commit', x.subject || x.sha.slice(0, 7), {'data-fp-sha': x.sha})];
        if (x.parents.length > 1) { top.push(pill(t('gv_merge'))); }
        return el('li', {class: 'fp-gv-commit'}, [el('div', {class: 'fp-gv-subject'}, top),
          el('div', {class: 'fp-muted fp-gv-by'}, [el('span', {text: t('gv_log_by', {author: x.author, date: when(x.when)})}),
            el('code', {class: 'sig-mono fp-gv-sha', text: x.sha.slice(0, 7)})])]);
      })));
      var acts = [];
      if (G.skip > 0) { acts.push(action('prev-page', t('gv_newer'))); }
      if (l.more) { acts.push(action('next-page', t('gv_older'))); }
      if (acts.length) { c.appendChild(el('div', {class: 'fp-gv-acts'}, acts)); }
      ready(focus);
    }, function (err) {
      if (stale(my)) { return; }
      fail(err);
    });
  }

  /* ---- Commit: its message, the files it changed and the patch ---- */
  function diffLines(text) {
    var out = [];
    var inHunk = false;
    text.split('\n').forEach(function (line) {
      var cls = 'meta';
      if (line.indexOf('diff --git ') === 0) { inHunk = false; cls = 'file'; } else if (line.indexOf('@@') === 0) { inHunk = true; cls = 'hunk'; } else if (inHunk) {
        var c = line.charAt(0);
        cls = c === '+' ? 'add' : c === '-' ? 'del' : c === '\\' ? 'meta' : 'ctx';
      }
      out.push({text: line, cls: cls});
    });
    if (out.length && out[out.length - 1].text === '') { out.pop(); }
    return out;
  }
  function showCommit(focus) {
    var my = begin('…');
    FP.call('get', 'gitCommit', undefined, {name: G.account, repo: G.repo, ref: G.sha || G.ref}).then(function (r) {
      if (stale(my)) { return; }
      var s = cleanShow(r);
      if (!s) { fail(); return; }
      drawCommit(s);
      ready(focus);
    }, function (err) {
      if (stale(my)) { return; }
      fail(err);
    });
  }
  function fact(list, key, node) { list.push(el('dt', {class: 'fp-git-k', text: t(key)}), el('dd', {class: 'fp-git-v'}, [node])); }
  function drawCommit(s) {
    var c = content();
    var cm = s.commit;
    heading().textContent = cm.subject || cm.sha.slice(0, 7);
    c.textContent = '';
    var facts = [];
    fact(facts, 'gv_f_commit', el('code', {class: 'sig-mono', text: cm.sha}));
    fact(facts, 'gv_f_author', document.createTextNode(cm.author));
    fact(facts, 'gv_f_date', document.createTextNode(when(cm.when)));
    var parents = cm.parents.length ? el('span', null, cm.parents.map(function (p, i) {
      return el('span', null, [i ? document.createTextNode(' ') : null, linkButton('show-commit', p.slice(0, 7), {'data-fp-sha': p, 'data-fp-mono': ''})]);
    })) : document.createTextNode(t('gv_no_parent'));
    fact(facts, 'gv_f_parents', parents);
    c.appendChild(el('div', {class: 'fp-gv-acts'}, [action('up-history', t('gv_back_history')), action('show-at-commit', t('gv_files_at'), {'data-fp-sha': cm.sha})]));
    c.appendChild(el('dl', {class: 'fp-git-vals fp-gv-facts'}, facts));
    if (s.merge) { c.appendChild(note(t('gv_merge_note'))); }
    var body = cm.message.replace(/^[^\n]*\n?/, '').replace(/^\n+/, '');
    if (body) { c.appendChild(el('p', {class: 'fp-gv-msg', text: body})); }
    if (cm.cut) { c.appendChild(note(t('gv_message_cut'))); }
    c.appendChild(el('h3', {class: 'fp-h3', text: t('gv_changed_title')}));
    if (!s.files.length) {
      c.appendChild(note(t('gv_changed_none')));
    } else {
      var rows = s.files.map(function (f) {
        var path = [el('span', {class: 'sig-mono fp-gv-path', text: f.path})];
        if (f.old) { path.push(el('span', {class: 'fp-muted fp-row-note', text: t('gv_renamed_from', {old: f.old})})); }
        var changes = f.binary ? t('gv_changes_binary') : t('gv_changes_counts', {added: '+' + f.added, deleted: '−' + f.deleted});
        return el('tr', null, [el('td', {class: 'fp-gv-namecell'}, path), el('td', {class: 'fp-gv-num', text: changes})]);
      });
      c.appendChild(table(t('gv_changed_title'), [t('gv_col_name'), t('gv_col_changes')], rows, 'fp-gv-table', 1));
      if (s.filesCut) { c.appendChild(note(t('gv_files_cut', {n: s.files.length.toLocaleString('en')}))); }
    }
    if (s.diff) {
      c.appendChild(el('h3', {class: 'fp-h3', text: t('gv_diff_title')}));
      var d = diffLines(s.diff);
      var shown = d.slice(0, MAX_LINES);
      c.appendChild(el('pre', {class: 'fp-gv-code fp-gv-diff', 'data-overflow-ok': '', 'data-overlap-ok': '', tabindex: '0', role: 'region', 'aria-label': t('gv_diff_label', {sha: cm.sha.slice(0, 7)})},
        shown.map(function (x) { return el('span', {class: 'fp-gv-l fp-gv-d-' + x.cls, text: x.text}); })));
      if (s.diffCut) { c.appendChild(note(t('gv_diff_cut'))); }
      if (d.length > MAX_LINES) { c.appendChild(note(t('gv_lines_cut', {n: MAX_LINES.toLocaleString('en')}))); }
    }
  }

  /* ---- Branches and tags ---- */
  function showBranches(focus) {
    var my = begin(t('gv_branches_title'));
    FP.call('get', 'gitBranches', undefined, {name: G.account, repo: G.repo}).then(function (r) {
      if (stale(my)) { return; }
      var b = cleanBranches(r);
      if (!b) { fail(); return; }
      G.branches = b;
      fillRefs();
      var c = content();
      c.textContent = '';
      c.appendChild(el('h3', {class: 'fp-h3 fp-gv-first', text: t('gv_branches_h')}));
      if (!b.branches.length) {
        c.appendChild(note(t('gv_no_branch_list')));
      } else {
        c.appendChild(table(t('gv_branches_h'), [t('gv_col_branch'), t('gv_col_commit')], b.branches.map(function (x) {
          var name = [linkButton('show-branch', x.name, {'data-fp-ref': x.name})];
          if (x.current) { name.push(pill(t('gv_checked_out'), 'ok')); }
          return el('tr', null, [el('td', {class: 'fp-gv-namecell'}, name),
            el('td', {class: 'fp-gv-namecell'}, [el('span', {text: x.subject}), el('span', {class: 'fp-muted fp-row-note', text: x.sha.slice(0, 7) + ', ' + when(x.when)})])]);
        }), 'fp-gv-table'));
      }
      c.appendChild(el('h3', {class: 'fp-h3', text: t('gv_tags_h')}));
      if (!b.tags.length) {
        c.appendChild(note(t('gv_no_tag_list')));
      } else {
        c.appendChild(table(t('gv_tags_h'), [t('gv_col_tag'), t('gv_col_sha')], b.tags.map(function (x) {
          return el('tr', null, [el('td', {class: 'fp-gv-namecell'}, [linkButton('show-branch', x.name, {'data-fp-ref': x.name})]),
            el('td', null, [el('code', {class: 'sig-mono', text: x.sha.slice(0, 7)})])]);
        }), 'fp-gv-table'));
      }
      if (b.skipped) { c.appendChild(note(t('gv_refs_skipped', {n: b.skipped}))); }
      if (b.truncated) { c.appendChild(note(t('gv_refs_cut', {n: 500}))); }
      ready(focus);
    }, function (err) {
      if (stale(my)) { return; }
      fail(err);
    });
  }

  /* ---- clicks ---- */
  document.addEventListener('click', function (e) {
    var link = e.target && e.target.closest ? e.target.closest('a[data-fp-view]') : null;
    if (link) { FP.gitView = link.getAttribute('data-fp-view') || ''; return; }
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !G.page || !G.page.contains(b) || !G.branches) { return; }
    var a = b.getAttribute('data-fp-act');
    var p = b.getAttribute('data-fp-path');
    if (a === 'show-files') {
      toFolder();
      G.view = 'files';
      showView(true);
    } else if (a === 'show-history') {
      G.view = 'history';
      G.skip = 0;
      showView(true);
    } else if (a === 'show-branches') {
      G.view = 'branches';
      showView(true);
    } else if (a === 'show-dir') {
      G.view = 'files';
      G.path = p || '';
      showFiles(true);
    } else if (a === 'show-file') {
      G.view = 'file';
      G.path = p || '';
      showFile(true);
    } else if (a === 'show-commit') {
      G.view = 'commit';
      G.sha = b.getAttribute('data-fp-sha') || '';
      fillTabs();
      showCommit(true);
    } else if (a === 'up-history') {
      G.view = 'history';
      G.sha = '';
      fillTabs();
      showHistory(true);
    } else if (a === 'show-at-commit') {
      G.ref = b.getAttribute('data-fp-sha') || G.ref;
      G.sha = '';
      G.view = 'files';
      G.path = '';
      showView(true);
    } else if (a === 'next-page' || a === 'prev-page') {
      G.skip = Math.max(0, G.skip + (a === 'next-page' ? PAGE : -PAGE));
      showHistory(true);
    } else if (a === 'show-branch') {
      G.ref = b.getAttribute('data-fp-ref') || G.ref;
      G.view = 'files';
      G.path = '';
      G.skip = 0;
      showView(true);
    }
  });

  FP.view('tool:git_view', function () {
    G.seq++;
    G.page = null;
    var body = M.frame('git_view', 'fp-gv');
    if (!body) { return; }
    G.page = body;
    G.account = FP.account();
    G.repo = '';
    G.ref = '';
    G.view = 'files';
    G.path = '';
    G.skip = 0;
    G.sha = '';
    G.branches = null;
    var want = typeof FP.gitView === 'string' ? FP.gitView : '';
    FP.gitView = '';
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'git', undefined, G.account).then(function (r) {
      if (G.page !== body) { return; }
      var repos = cleanRepos(r);
      body.textContent = '';
      if (!repos) { body.appendChild(FP.empty(FP.tools.git_view.label, t('api_failed'))); return; }
      G.repos = repos;
      if (!repos.length) {
        body.appendChild(M.card('fp-gv-none-h', t('gv_pick_title'), [el('p', {class: 'fp-muted'}, [document.createTextNode(t('gv_none') + ' '),
          el('a', {href: '#/tool/git_repos', text: t('gv_none_link')}), document.createTextNode('.')])], 'fp-gv-none'));
        return;
      }
      G.repo = repos.indexOf(want) >= 0 ? want : repos[0];
      body.appendChild(pickCard());
      body.appendChild(viewShell());
      body.querySelector('#fp-gv-repo').value = G.repo;
      loadRepo();
    }, function (err) {
      if (G.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(FP.tools.git_view.label, err.message));
    });
  });
})();

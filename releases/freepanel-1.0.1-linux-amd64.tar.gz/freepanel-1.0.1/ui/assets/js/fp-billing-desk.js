/* freePanel billing support desk lists (docs/api.md, "Billing: support desk"; docs/billing/navigation-map.md, "Support"): Departments
   (#/tool/billing_departments), the departments tickets are sorted into, and Canned replies (#/tool/billing_canned), the answers staff give
   often. Each is a table with a form to add or change a row; a removal is asked first on its row. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;

  function cleanDepartments(r) { return B.pickAll(r && r.departments, {id: 'id', name: [60], description: [200], hidden: 'b', tickets: 'n'}, 'id'); }
  function cleanCanned(r) { return B.pickAll(r && r.canned, {id: 'id', title: [80], body: [20000], department_id: 'id'}, 'id'); }
  function simple(toolId, cls, make) {
    FP.view('tool:' + toolId, function () {
      var page = B.frame(toolId, cls);
      if (!page) { return; }
      page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
      make(page, function () { return page.isConnected; }).show();
    });
  }
  simple('billing_departments', 'fp-bdp', function (page, alive) {
    return B.crud({page: page, pre: 'fp-bdp', title: t('bdp_title'), alive: alive,
      what: function () { return [el('p', {class: 'fp-muted', text: t('bdp_what')})]; },
      load: function () { return FP.call('get', 'billingDepartments').then(cleanDepartments); },
      heads: [B.th(t('bdp_col_name')), B.th(t('bdp_col_desc')), B.th(t('bdp_col_hidden')), B.th(t('bdp_col_tickets'), 'fp-bil-num')],
      cells: function (d) { return [el('th', {scope: 'row', class: 'fp-bil-wrap', text: d.name}), el('td', {class: 'fp-bil-wrap', text: d.description || '—'}), el('td', {text: t(d.hidden ? 'bil_yes' : 'bil_no')}),
        el('td', {class: 'fp-bil-num', text: d.tickets === null ? '—' : B.num(d.tickets)})]; },
      removable: function (d) { return !d.tickets; },
      fields: [{name: 'name', label: t('bdp_name'), required: true, max: 60}, {name: 'description', label: t('bdp_desc'), max: 200, hint: t('bdp_desc_hint')},
        {name: 'hidden', label: t('bdp_hidden'), kind: 'check', hint: t('bdp_hidden_hint')}],
      add: 'billingDepartments', item: 'billingDepartment', nameOf: function (d) { return d.name; },
      strings: {none: t('bdp_none'), addTitle: t('bdp_add_title'), addSave: t('bdp_add'), editTitle: function (n) { return t('bil_change_title', {name: n}); },
        added: function (n) { return t('bil_added', {name: n}); }, saved: function (n) { return t('bil_saved', {name: n}); }, removed: function (n) { return t('bil_removed', {name: n}); },
        removeAsk: function (n) { return t('bdp_remove_ask', {name: n}); }, removeYes: t('bdp_remove_yes')}});
  });
  /* ---- canned replies ---- */
  simple('billing_canned', 'fp-bcn', function (page, alive) {
    var depts = [];
    var R = B.crud({page: page, pre: 'fp-bcn', title: t('bcn_title'), alive: alive,
      what: function () { return [el('p', {class: 'fp-muted', text: t('bcn_what')})]; },
      load: function () {
        return Promise.all([FP.call('get', 'billingCanned', undefined, {}), FP.call('get', 'billingDepartments').then(cleanDepartments, function () { return []; })]).then(function (r) {
          depts = r[1];
          return cleanCanned(r[0]);
        });
      },
      heads: [B.th(t('bcn_col_title')), B.th(t('bcn_col_dept'))],
      cells: function (c) {
        var d = depts.filter(function (x) { return x.id === c.department_id; })[0];
        return [el('th', {scope: 'row', class: 'fp-bil-wrap', text: c.title}), el('td', {text: c.department_id ? (d ? d.name : '—') : t('bcn_any_dept')})];
      },
      fieldsFor: function () {
        return [{name: 'title', label: t('bcn_f_title'), required: true, max: 80}, {name: 'department_id', label: t('bcn_col_dept'), kind: 'select', num: true,
          options: [['', t('bcn_any_dept')]].concat(depts.map(function (d) { return [String(d.id), d.name]; }))},
        {name: 'body', label: t('bcn_f_body'), kind: 'textarea', required: true, max: 20000, rows: 6, hint: t('bcn_f_body_hint'), wide: true}];
      },
      add: 'billingCannedNew', item: 'billingCannedOne', nameOf: function (c) { return c.title; }, clean: function (r) { return r; },
      strings: {none: t('bcn_none'), addTitle: t('bcn_add_title'), addSave: t('bcn_add'), editTitle: function (n) { return t('bil_change_title', {name: n}); },
        added: function (n) { return t('bil_added', {name: n}); }, saved: function (n) { return t('bil_saved', {name: n}); }, removed: function (n) { return t('bil_removed', {name: n}); },
        removeAsk: function (n) { return t('bcn_remove_ask', {name: n}); }, removeYes: t('bcn_remove_yes')}});
    return R;
  });
})();

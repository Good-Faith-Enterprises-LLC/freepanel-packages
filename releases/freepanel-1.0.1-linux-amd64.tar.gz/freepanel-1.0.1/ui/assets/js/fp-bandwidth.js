/* freePanel bandwidth limits (docs/api.md, "Bandwidth limits"), in the admin panel: Accounts > Bandwidth use
   (#/tool/bandwidth_use) lists each account's transfer this month against its package's limit, and brings a stopped
   account's sites back for two hours, one or all at once, for the admin and for a reseller the admin allows;
   Resellers > Reseller rights (#/tool/reseller_rights) is where the admin allows it. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;

  var USER_RE = /^[a-z][a-z0-9]{0,15}$/;
  var NAME_RE = /^[A-Za-z0-9][A-Za-z0-9_. -]{0,63}$/;
  function str(v) { return typeof v === 'string' ? v : ''; }
  function num(v) { return typeof v === 'number' && isFinite(v) && v >= 0; }
  function isAdmin() { return FP.session.user.role === 'admin'; }
  function count(n) { return Math.round(n).toLocaleString('en'); }
  var UNITS = ['KB', 'MB', 'GB', 'TB', 'PB'];
  function size(n) {
    if (n < 1024) { return t('size_bytes', {n: count(n)}); }
    var u = -1;
    do { n /= 1024; u++; } while (n >= 1024 && u < UNITS.length - 1);
    return (n < 10 ? n.toFixed(1) : count(n)) + ' ' + UNITS[u];
  }
  function time(iso) {
    var d = iso ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString(undefined, {month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'}) : '';
  }
  function frame(id) {
    var tool = FP.tools[id];
    if (!tool || FP.realm !== 'admin') { FP.views['not-found']({view: 'not-found'}); return null; }
    var g = FP.group(tool.group);
    return FP.frame({title: tool.label, desc: t(id === 'bandwidth_use' ? (isAdmin() ? 'bw_desc' : 'bw_desc_reseller') : 'rr_desc'), cls: 'fp-bw',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
  }
  function card(id, title, children, cls) {
    return el('section', {class: 'sig-card fp-bw-card' + (cls ? ' ' + cls : ''), 'aria-labelledby': id}, [el('div', {class: 'sig-card-body'},
      [el('h2', {class: 'fp-h2', id: id, tabindex: '-1', text: title})].concat(children))]);
  }
  function monthName(m) {
    var x = /^(\d{4})-(\d{2})$/.exec(str(m));
    if (!x) { return ''; }
    return new Date(Date.UTC(Number(x[1]), Number(x[2]) - 1, 1)).toLocaleDateString('en', {month: 'long', year: 'numeric', timeZone: 'UTC'});
  }

  /* ================= Bandwidth use ================= */
  var B = {page: null};
  function cleanRow(a) {
    if (!a || typeof a !== 'object' || !USER_RE.test(str(a.username))) { return null; }
    var limit = num(a.limit_bytes) ? a.limit_bytes : null;
    var bytes = num(a.bytes) ? a.bytes : 0;
    return {username: a.username, owner: USER_RE.test(str(a.owner)) ? a.owner : '', package: NAME_RE.test(str(a.package)) ? a.package : '',
      bytes: bytes, limit: limit, ratio: limit ? bytes / limit : (limit === 0 ? 1 : 0), over: a.over === true, limited: a.limited === true,
      liftedUntil: a.over === true && a.limited !== true ? str(a.lifted_until) : ''};
  }
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var rows = (Array.isArray(r.accounts) ? r.accounts : []).map(cleanRow).filter(Boolean);
    rows.sort(function (x, y) { return (y.limited - x.limited) || (y.over - x.over) || (y.ratio - x.ratio) || (x.username < y.username ? -1 : 1); });
    return {month: str(r.month), canLift: r.can_lift === true, rows: rows};
  }
  function stateCell(a) {
    if (a.limited) { return el('span', {class: 'sig-pill sig-pill--danger', text: t('bw_stopped')}); }
    if (a.over) { return el('span', {class: 'sig-pill sig-pill--warn', text: a.liftedUntil ? t('bw_back_until', {when: time(a.liftedUntil)}) : t('bw_back')}); }
    if (a.limit !== null && a.ratio >= 0.8) { return el('span', {class: 'sig-pill sig-pill--warn', text: t('bw_near')}); }
    return el('span', {class: 'fp-muted', text: '—'});
  }
  function usedCell(a) {
    var pct = a.limit ? Math.round(a.ratio * 100) : -1;
    var td = el('td', {class: 'fp-num'}, [el('span', {text: size(a.bytes)}), pct >= 0 ? el('span', {class: 'fp-muted fp-bw-pct', text: ' (' + pct + '%)'}) : null]);
    if (pct >= 0) {
      var bar = el('i');
      bar.style.width = Math.min(100, pct) + '%';
      td.appendChild(el('div', {class: 'sig-meter' + (a.over ? ' is-danger' : pct >= 80 ? ' is-warn' : ''), 'aria-hidden': 'true'}, [bar]));
    }
    return td;
  }
  function row(a) {
    return el('tr', {'data-fp-account': a.username}, [el('th', {scope: 'row', class: 'sig-mono', text: a.username}),
      isAdmin() ? el('td', {text: a.owner || '—'}) : null,
      el('td', {text: a.package || '—'}), usedCell(a),
      el('td', {class: 'fp-num', text: a.limit === null ? t('bw_no_limit') : size(a.limit)}),
      el('td', null, [stateCell(a)]),
      el('td', {class: 'fp-bw-acts'}, [a.limited && B.data.canLift ? el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button',
        'data-fp-act': 'lift', 'aria-label': t('bw_lift_of', {name: a.username}), text: t('bw_lift')}) : null])]);
  }
  function render(note, focus) {
    var page = B.page;
    var d = B.data;
    page.textContent = '';
    var stopped = d.rows.filter(function (a) { return a.limited; });
    var q = B.filter.toLowerCase();
    var shown = q ? d.rows.filter(function (a) { return [a.username, a.owner, a.package].join(' ').toLowerCase().indexOf(q) >= 0; }) : d.rows;
    var parts = [el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': ''}), el('p', {class: 'fp-ok-line', role: 'status', 'data-fp-status': '', text: note || ''}),
      el('p', {class: 'fp-bw-summary', 'data-fp-summary': '', text: stopped.length ? t(stopped.length === 1 ? 'bw_stopped_one' : 'bw_stopped_n', {n: count(stopped.length)}) : t('bw_none_stopped')})];
    if (stopped.length && d.canLift) {
      parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'lift-all',
        text: t('bw_lift_all')})]));
    } else if (stopped.length && !isAdmin()) {
      parts.push(el('p', {class: 'fp-muted', text: t('bw_cant_lift')}));
    }
    parts.push(el('p', {class: 'fp-muted', text: t('bw_lift_what')}));
    if (d.rows.length) {
      var filter = el('input', {class: 'sig-input', id: 'fp-bw-filter', type: 'search', autocomplete: 'off', spellcheck: 'false', maxlength: '64'});
      filter.value = B.filter;
      parts.push(el('div', {class: 'sig-field fp-bw-filter'}, [el('label', {class: 'sig-label', for: 'fp-bw-filter', text: t('bw_filter')}), filter]));
      filter.addEventListener('input', function () {
        B.filter = filter.value.trim();
        render('', '#fp-bw-filter');
      });
    }
    if (!d.rows.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('bw_no_accounts')}));
    } else if (!shown.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('bw_no_match')}));
    } else {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-bw-h'}, [
        el('table', {class: 'sig-table fp-bw-table'}, [el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('bw_account')}),
          isAdmin() ? el('th', {scope: 'col', text: t('acct_owner')}) : null, el('th', {scope: 'col', text: t('acct_package')}),
          el('th', {scope: 'col', class: 'fp-num', text: t('bw_used')}), el('th', {scope: 'col', class: 'fp-num', text: t('bw_limit')}),
          el('th', {scope: 'col', text: t('bw_state')}), el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]),
        el('tbody', null, shown.map(row))])]));
    }
    page.appendChild(card('fp-bw-h', t('bw_title', {month: monthName(d.month) || d.month}), parts, 'fp-bw-list'));
    var f = focus && page.querySelector(focus);
    if (f) {
      f.focus();
      if (f.id === 'fp-bw-filter') { f.setSelectionRange(f.value.length, f.value.length); }
    }
  }
  /* the list read again after a lift, so every row says what the server now holds */
  function reload(note, focus) {
    var mine = B.page;
    return FP.call('get', 'bandwidth').then(function (r) {
      if (B.page !== mine) { return; }
      B.data = clean(r);
      render(note, focus);
    });
  }
  /* 503 service_unavailable: Core stored the lift but the web server hasn't taken it yet; the next check sends it again */
  function failed(err, b) {
    if (err.code === 'service_unavailable') {
      return reload(t('bw_lift_pending'), '#fp-bw-h').catch(function (e) { failed(e, b); });
    }
    UI.setBusy(b, false);
    var list = B.page.querySelector('.fp-bw-list');
    UI.showError(list, err.message);
  }
  function onClick(e) {
    if (!B.page) { return; }
    var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !B.page.contains(b) || b.disabled) { return; }
    var a = b.getAttribute('data-fp-act');
    var list = B.page.querySelector('.fp-bw-list');
    if (a === 'lift') {
      var name = b.closest('tr').getAttribute('data-fp-account');
      UI.showError(list, '');
      UI.setBusy(b, true);
      FP.call('post', 'bandwidthLift', undefined, name).then(function (r) {
        var until = r && typeof r === 'object' ? time(str(r.lifted_until)) : '';
        return reload(until ? t('bw_lifted', {name: name, when: until}) : t('bw_lifted_plain', {name: name}), '#fp-bw-h');
      }).catch(function (err) { failed(err, b); });
    } else if (a === 'lift-all') {
      UI.showError(list, '');
      UI.setBusy(b, true);
      FP.call('post', 'bandwidthLiftAll').then(function (r) {
        var names = (r && Array.isArray(r.lifted) ? r.lifted : []).filter(function (n) { return USER_RE.test(str(n)); });
        return reload(names.length ? t('bw_lifted_all', {names: names.join(', ')}) : t('bw_lifted_none'), '#fp-bw-h');
      }).catch(function (err) { failed(err, b); });
    }
  }
  document.addEventListener('click', onClick);
  FP.view('tool:bandwidth_use', function () {
    B.page = null;
    var body = frame('bandwidth_use');
    if (!body) { return; }
    B.page = body;
    B.filter = '';
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    reload('', '').catch(function (err) {
      if (B.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(FP.tools.bandwidth_use.label, err.message));
    });
  });

  /* ================= Reseller rights ================= */
  var R = {page: null};
  function rrRender(list) {
    var page = R.page;
    page.textContent = '';
    var parts = [el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': ''}), el('p', {class: 'fp-ok-line', role: 'status', 'data-fp-status': ''}),
      el('p', {class: 'fp-muted', text: t('rr_what')})];
    if (!list.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('rr_none')}));
    } else {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-rr-h'}, [
        el('table', {class: 'sig-table fp-bw-table fp-rr-table'}, [el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('rr_reseller')}),
          el('th', {scope: 'col', text: t('rr_lift')}), el('th', {scope: 'col', text: t('rr_branding')})])]),
        el('tbody', null, list.map(function (r) {
          return el('tr', {'data-fp-reseller': r.username}, [el('th', {scope: 'row', class: 'sig-mono', text: r.username}),
            el('td', null, [el('label', {class: 'fp-check'}, [el('input', {type: 'checkbox', 'data-fp-priv': 'lift_bandwidth',
              checked: r.lift ? true : null}), el('span', {text: t('rr_lift_of', {name: r.username})})])]),
            el('td', null, [el('label', {class: 'fp-check'}, [el('input', {type: 'checkbox', 'data-fp-priv': 'branding',
              checked: r.branding ? true : null}), el('span', {text: t('rr_branding_of', {name: r.username})})])])]);
        }))])]));
    }
    page.appendChild(card('fp-rr-h', t('rr_title'), parts, 'fp-rr-list'));
  }
  function onChange(e) {
    if (!R.page || !e.target.hasAttribute || !e.target.hasAttribute('data-fp-priv') || !R.page.contains(e.target)) { return; }
    var box = e.target;
    var right = box.getAttribute('data-fp-priv') === 'branding' ? 'branding' : 'lift_bandwidth';
    var name = box.closest('tr').getAttribute('data-fp-reseller');
    var want = box.checked;
    var scope = R.page.querySelector('.fp-rr-list');
    UI.showError(scope, '');
    scope.querySelector('[data-fp-status]').textContent = '';
    box.disabled = true;
    var sent = {};
    sent[right] = want;
    FP.call('put', 'resellerPrivileges', sent, name).then(function (r) {
      box.disabled = false;
      var now = r && r.privileges && typeof r.privileges === 'object' ? r.privileges[right] === true : want;
      box.checked = now;
      scope.querySelector('[data-fp-status]').textContent = t((right === 'branding' ? 'rr_branding_' : 'rr_') + (now ? 'on' : 'off'), {name: name});
      box.focus();
    }, function (err) {
      box.disabled = false;
      box.checked = !want;
      UI.showError(scope, err.message);
      box.focus();
    });
  }
  document.addEventListener('change', onChange);
  FP.view('tool:reseller_rights', function () {
    R.page = null;
    if (!isAdmin()) { FP.views['not-found']({view: 'not-found'}); return; }
    var body = frame('reseller_rights');
    if (!body) { return; }
    R.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'resellers').then(function (r) {
      if (R.page !== body) { return; }
      var list = (r && Array.isArray(r.resellers) ? r.resellers : []).filter(function (x) { return x && USER_RE.test(str(x.username)); }).map(function (x) {
        return {username: x.username, lift: Boolean(x.privileges && x.privileges.lift_bandwidth === true), branding: Boolean(x.privileges && x.privileges.branding === true)};
      }).sort(function (a, b) { return a.username < b.username ? -1 : 1; });
      rrRender(list);
    }, function (err) {
      if (R.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(FP.tools.reseller_rights.label, err.message));
    });
  });
})();

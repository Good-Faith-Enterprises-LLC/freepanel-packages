/* freePanel billing payment gateways (#/tool/billing_gateways; docs/api.md, "Billing: payments", Gateways; docs/billing/navigation-map.md,
   "Payment gateways"): the gateways the server has, each on or off. Turning one off is asked first, since its payments and saved methods stop
   working; turning the test gateway on says plainly that it takes no money and that anyone with a checkout's link can mark it paid. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;
  var M = FP.mail;

  FP.view('tool:billing_gateways', function () {
    var page = B.frame('billing_gateways', 'fp-bgw');
    if (!page) { return; }
    var alive = function () { return page.isConnected; };
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    function clean(r) { return B.pickAll(r && r.gateways, {id: [40], name: [60], enabled: 'b'}, 'id').filter(function (g) { return /^[a-z0-9_-]{1,40}$/.test(g.id); }); }
    function draw(list, said) {
      var boxes = list.map(function (g) {
        var fid = 'fp-bgw-' + g.id;
        return el('li', {class: 'fp-bgw-item', 'data-fp-gateway': g.id}, [el('label', {class: 'fp-bil-check', for: fid}, [el('input', {type: 'checkbox', id: fid, name: 'enabled', value: g.id,
          checked: g.enabled ? true : null}), el('span', {class: 'fp-bgw-name', text: g.name || g.id})]),
          el('span', {class: 'fp-bgw-state'}, [B.pill(t(g.enabled ? 'bgw_on' : 'bgw_off'), g.enabled ? 'ok' : '')]),
          g.id === 'test' ? el('p', {class: 'fp-muted fp-row-note fp-bgw-warn', id: 'fp-bgw-test-warn', text: t('bgw_test_warn')}) : null]);
      });
      var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bil_save_changes')});
      var form = el('form', {class: 'fp-form fp-bgw-form', novalidate: '', 'aria-labelledby': 'fp-bgw-h'}, [M.errorLine(), M.statusLine(),
        list.length ? el('fieldset', {class: 'fp-bil-set'}, [el('legend', {class: 'sig-label', text: t('bgw_legend')}), el('ul', {class: 'fp-bgw-list'}, boxes)]) :
          el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('bgw_none')}),
        list.length ? el('div', {class: 'fp-actions', 'data-fp-acts': ''}, [save]) : null]);
      var test = form.querySelector('#fp-bgw-test');
      if (test) { test.setAttribute('aria-describedby', 'fp-bgw-test-warn'); }
      function chosen() { return Array.prototype.filter.call(form.querySelectorAll('[name="enabled"]'), function (c) { return c.checked; }).map(function (c) { return c.value; }); }
      function send(b, on) {
        UI.setBusy(b, true);
        FP.call('put', 'billingGatewaysSet', {enabled: on}).then(function (r) {
          if (!alive()) { return; }
          draw(clean(r), t('bgw_saved'));
        }, function (err) {
          if (!alive()) { return; }
          draw(list);
          B.failed(page.querySelector('.fp-bgw-form'), err);
        });
      }
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!B.begin(form, save)) { return; }
        var on = chosen();
        var off = list.filter(function (g) { return g.enabled && on.indexOf(g.id) < 0; });
        if (!off.length && on.length === list.filter(function (g) { return g.enabled; }).length) { M.say(form, t('bil_nothing_changed')); return; }
        if (!off.length) { send(save, on); return; }
        /* turning a gateway off is asked first */
        var box = form.querySelector('[data-fp-acts]');
        box.textContent = '';
        var yes = el('button', {class: 'sig-btn sig-btn--danger', type: 'button', text: t('bgw_off_yes'), 'aria-describedby': 'fp-bgw-q'});
        var no = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', text: t('bgw_off_keep'), 'aria-describedby': 'fp-bgw-q'});
        box.appendChild(el('p', {class: 'fp-mail-confirm', id: 'fp-bgw-q', text: t('bgw_off_ask', {names: off.map(function (g) { return g.name || g.id; }).join(', ')})}));
        box.appendChild(yes);
        box.appendChild(no);
        yes.addEventListener('click', function () { send(yes, on); });
        no.addEventListener('click', function () { box.textContent = ''; box.appendChild(save); save.focus(); });
        no.focus();
      });
      B.screen(page, [B.card('fp-bgw-h', t('bgw_title'), [el('p', {class: 'fp-muted', text: t('bgw_what')}), form], 'fp-bgw', 'gateways')]);
      if (said) { M.say(page.querySelector('.fp-bgw-form'), said); page.querySelector('#fp-bgw-h').focus(); }
    }
    function load() {
      FP.call('get', 'billingGateways').then(function (r) {
        if (alive()) { draw(clean(r)); }
      }, function (err) {
        if (!alive()) { return; }
        B.screen(page, [FP.empty(t('bgw_title'), err.message, B.button('reload', t('bil_try_again')))]);
        page.querySelector('[data-fp-act="reload"]').addEventListener('click', load);
      });
    }
    load();
  });
})();

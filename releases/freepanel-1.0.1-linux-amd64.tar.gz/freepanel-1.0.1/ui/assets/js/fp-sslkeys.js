/* freePanel private keys and certificate requests (docs/api.md, "Domains and sites": private keys and certificate requests):
   the customer's page (#/tool/ssl_keys) makes a private key on the server, asks for a certificate request (a CSR) made with it,
   shows the request to give to a certificate authority, and lists and removes both. A key is never shown: the server keeps it
   and the SSL certificates page installs a certificate with it by its id. What the server sends is cleaned to the shapes drawn
   here and shown as text. Page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var KEY_ID = /^k-[0-9a-f]{12}$/;
  var CSR_ID = /^r-[0-9a-f]{12}$/;
  var FINGERPRINT = /^[0-9a-f]{64}$/;
  var NAME_RE = /^(\*\.)?([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var PEM_RE = /^-----BEGIN CERTIFICATE REQUEST-----[A-Za-z0-9+/=\r\n ]{1,16000}-----END CERTIFICATE REQUEST-----\s*$/;
  var TYPES = ['rsa2048', 'rsa3072', 'rsa4096', 'ecdsa-p256', 'ecdsa-p384'];
  var MAX_LABEL = 64;
  var MAX_NAMES = 20;
  var SUBJECT = [['country', 'ky_country'], ['state', 'ky_state'], ['locality', 'ky_locality'], ['organization', 'ky_organization'], ['unit', 'ky_unit'], ['email', 'ky_email']];

  function str(v) { return typeof v === 'string' ? v : ''; }
  function hasControl(s) {
    for (var i = 0; i < s.length; i++) {
      var c = s.charCodeAt(i);
      if (c < 32 || c === 127) { return true; }
    }
    return false;
  }
  function bytes(s) { return new window.TextEncoder().encode(s).length; }
  function when(iso) { return iso ? (FP.bk ? FP.bk.when(iso) : '') || iso : ''; }
  function typeLabel(type) { return TYPES.indexOf(type) < 0 ? '' : t('ky_type_' + type.replace('-', '_')); }
  function cleanKey(k) {
    if (!k || typeof k !== 'object' || !KEY_ID.test(str(k.id)) || TYPES.indexOf(k.type) < 0) { return null; }
    return {id: k.id, label: str(k.label).slice(0, MAX_LABEL), type: k.type, fingerprint: FINGERPRINT.test(str(k.fingerprint)) ? k.fingerprint : '', created: str(k.created)};
  }
  function cleanKeys(r) {
    return (r && Array.isArray(r.keys) ? r.keys : []).map(cleanKey).filter(Boolean);
  }
  function cleanCsr(c) {
    if (!c || typeof c !== 'object' || !CSR_ID.test(str(c.id)) || !KEY_ID.test(str(c.key_id))) { return null; }
    var names = (Array.isArray(c.names) ? c.names : []).filter(function (n) { return NAME_RE.test(str(n)); }).slice(0, MAX_NAMES);
    return {id: c.id, keyId: c.key_id, names: names, subject: str(c.subject).slice(0, 400), fingerprint: FINGERPRINT.test(str(c.key_fingerprint)) ? c.key_fingerprint : '',
      created: str(c.created), pem: PEM_RE.test(str(c.csr)) ? c.csr : ''};
  }
  function cleanCsrs(r) {
    return (r && Array.isArray(r.csrs) ? r.csrs : []).map(cleanCsr).filter(Boolean);
  }
  /* what a key is called on the page: its own name, or its type and the start of its fingerprint */
  function keyName(k) {
    return k.label || t('ky_unnamed', {type: typeLabel(k.type), print: k.fingerprint.slice(0, 8)});
  }
  FP.ky = {cleanKeys: cleanKeys, keyName: keyName, typeLabel: typeLabel};

  var KS = null;
  function keyOf(id) { return KS.keys.filter(function (k) { return k.id === id; })[0]; }
  function sorted(list) {
    return list.slice().sort(function (a, b) { return a.created < b.created ? 1 : (a.created > b.created ? -1 : 0); });
  }
  function fact(label, children) { return el('div', null, [el('dt', {text: label}), el('dd', null, children)]); }

  /* ================= keys ================= */
  function keysTable() {
    return el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-ky-keys-h'}, [
      el('table', {class: 'sig-table fp-mail-table fp-ky-table'}, [el('thead', null, [el('tr', null, [
        el('th', {scope: 'col', text: t('ky_col_key')}), el('th', {scope: 'col', text: t('ky_col_made')}),
        el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]),
      el('tbody', null, KS.keys.map(function (k) {
        return el('tr', {'data-fp-key': k.id}, [
          el('th', {scope: 'row', class: 'fp-mail-name fp-ky-name'}, [el('span', {class: 'fp-ky-title', text: keyName(k)}),
            el('span', {class: 'fp-muted fp-row-note', text: typeLabel(k.type)}),
            k.fingerprint ? el('span', {class: 'fp-muted fp-row-note sig-mono fp-ky-print', text: t('ky_fingerprint', {print: k.fingerprint})}) : null]),
          el('td', null, [el('span', {text: when(k.created)})]),
          el('td', {class: 'fp-mail-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'key-remove',
            'aria-label': t('ky_remove_of', {name: keyName(k)}), text: t('ky_remove')})])]);
      }))])]);
  }
  function keyForm() {
    var label = el('input', {class: 'sig-input', id: 'fp-ky-label', name: 'label', type: 'text', maxlength: '64', autocomplete: 'off', spellcheck: 'false'});
    var type = el('select', {class: 'sig-select', id: 'fp-ky-type', name: 'type'}, TYPES.map(function (x) { return el('option', {value: x, text: typeLabel(x)}); }));
    var form = el('form', {class: 'fp-form fp-mail-form fp-ky-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-ky-label', t('ky_label'), label, t('ky_label_hint')), M.field('fp-ky-type', t('ky_type'), type, t('ky_type_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('ky_make')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var name = label.value.trim();
      if (bytes(name) > MAX_LABEL || hasControl(name)) { M.fieldError(form, label, t('ky_label_bad')); return; }
      var body = {type: type.value};
      if (name) { body.label = name; }
      var mine = KS;
      UI.setBusy(b, true);
      M.say(form, t('ky_making'));
      FP.call('post', 'sslKeyNew', body, mine.account).then(function (r) {
        if (KS !== mine) { return; }
        var k = cleanKey(r);
        if (k) { mine.keys = sorted([k].concat(mine.keys)); }
        drawKeys();
        M.say(KS.page.querySelector('.fp-ky-keys'), t('ky_made', {name: k ? keyName(k) : name}));
        KS.page.querySelector('#fp-ky-keys-h').focus();
        drawRequestForm();
      }, function (err) {
        UI.setBusy(b, false);
        if (KS !== mine) { return; }
        M.say(form, '');
        M.failed(form, err);
      });
    });
    return form;
  }
  function keysCard() {
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted fp-ky-lead', text: t('ky_keys_desc')})];
    if (!KS.keysError && !KS.keys.length) { parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': 'keys', text: t('ky_keys_none')})); }
    else if (KS.keys.length) { parts.push(keysTable()); }
    parts.push(el('h3', {class: 'fp-h3', text: t('ky_make_title')}), keyForm());
    var card = M.card('fp-ky-keys-h', t('ky_keys_title'), parts, 'fp-ky-keys');
    if (KS.keysError) { UI.showError(card, KS.keysError); }
    return card;
  }
  function drawKeys() {
    var old = KS.page.querySelector('.fp-ky-keys');
    var fresh = keysCard();
    if (old) { old.replaceWith(fresh); } else { KS.page.appendChild(fresh); }
  }

  /* ================= requests ================= */
  function nameList(raw) {
    var seen = {};
    return raw.split(/[\s,;]+/).map(function (n) { return n.trim().toLowerCase().replace(/\.$/, ''); }).filter(function (n) {
      if (!n || seen[n]) { return false; }
      seen[n] = true;
      return true;
    });
  }
  function requestForm() {
    var keyPick = el('select', {class: 'sig-select', id: 'fp-ky-key', name: 'key_id', disabled: KS.keys.length ? null : true}, KS.keys.length ?
      KS.keys.map(function (k) { return el('option', {value: k.id, text: keyName(k) + ' (' + typeLabel(k.type) + ')'}); }) :
      [el('option', {value: '', text: t('ky_no_key')})]);
    var names = el('textarea', {class: 'sig-input sig-mono fp-ky-names', id: 'fp-ky-names', name: 'names', rows: '3', spellcheck: 'false', autocomplete: 'off', autocapitalize: 'none',
      placeholder: 'example.com\nwww.example.com'});
    var more = SUBJECT.map(function (s) {
      var input = el('input', {class: 'sig-input', id: 'fp-ky-' + s[0], name: s[0], type: 'text', maxlength: s[0] === 'country' ? '2' : (s[0] === 'email' ? '254' : '64'),
        autocomplete: 'off', spellcheck: 'false', autocapitalize: s[0] === 'email' ? 'none' : null});
      return M.field('fp-ky-' + s[0], t(s[1]), input, s[0] === 'country' ? t('ky_country_hint') : null);
    });
    var fields = el('div', {class: 'fp-ky-subject-box', id: 'fp-ky-subject', hidden: ''}, [el('p', {class: 'fp-muted', text: t('ky_subject_hint')}), el('div', {class: 'fp-ky-subject'}, more)]);
    var toggle = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'aria-expanded': 'false', 'aria-controls': 'fp-ky-subject', text: t('ky_subject_summary')});
    function openSubject(open) {
      fields.hidden = !open;
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    }
    toggle.addEventListener('click', function () { openSubject(fields.hidden); });
    var details = el('div', {class: 'fp-ky-more'}, [toggle, fields]);
    var form = el('form', {class: 'fp-form fp-mail-form fp-ky-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-ky-key', t('ky_use_key'), keyPick, KS.keys.length ? t('ky_use_key_hint') : t('ky_no_key_hint')),
      M.field('fp-ky-names', t('ky_names'), names, t('ky_names_hint')), details,
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('ky_ask'), disabled: KS.keys.length ? null : true})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var list = nameList(names.value);
      if (!list.length) { M.fieldError(form, names, t('ky_names_none')); return; }
      if (list.length > MAX_NAMES) { M.fieldError(form, names, t('ky_names_many', {n: MAX_NAMES})); return; }
      var odd = list.filter(function (n) { return !NAME_RE.test(n); })[0];
      if (odd) { M.fieldError(form, names, t('ky_names_bad', {name: odd.slice(0, 80)})); return; }
      var body = {key_id: keyPick.value, names: list};
      for (var i = 0; i < SUBJECT.length; i++) {
        var f = form.querySelector('#fp-ky-' + SUBJECT[i][0]);
        var v = f.value.trim();
        if (!v) { continue; }
        if (SUBJECT[i][0] === 'country' && !/^[A-Za-z]{2}$/.test(v)) { openSubject(true); M.fieldError(form, f, t('ky_country_bad')); return; }
        if (SUBJECT[i][0] === 'email' && (!M.isAddress(v) || !/^[\x20-\x7e]+$/.test(v))) { openSubject(true); M.fieldError(form, f, t('ky_email_bad')); return; }
        if (bytes(v) > 64 && SUBJECT[i][0] !== 'email' || hasControl(v)) { openSubject(true); M.fieldError(form, f, t('ky_subject_bad')); return; }
        body[SUBJECT[i][0]] = SUBJECT[i][0] === 'country' ? v.toUpperCase() : v;
      }
      var mine = KS;
      UI.setBusy(b, true);
      FP.call('post', 'sslCsrs', body, mine.account).then(function (r) {
        if (KS !== mine) { return; }
        var c = cleanCsr(r);
        if (c) { mine.csrs = sorted([c].concat(mine.csrs)); mine.shown = c; }
        drawRequests();
        drawShown();
        M.say(KS.page.querySelector('.fp-ky-requests'), t('ky_asked'));
        var shown = KS.page.querySelector('.fp-ky-shown');
        (shown ? shown.querySelector('h2') : KS.page.querySelector('#fp-ky-requests-h')).focus();
      }, function (err) {
        UI.setBusy(b, false);
        if (KS !== mine) { return; }
        M.failed(form, err);
      });
    });
    return form;
  }
  function csrTitle(c) {
    return c.names.length ? c.names[0] + (c.names.length > 1 ? t('ky_and_more', {n: c.names.length - 1}) : '') : t('ky_unnamed_request');
  }
  function requestsTable() {
    return el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-ky-requests-h'}, [
      el('table', {class: 'sig-table fp-mail-table fp-ky-table'}, [el('thead', null, [el('tr', null, [
        el('th', {scope: 'col', text: t('ky_col_request')}), el('th', {scope: 'col', text: t('ky_col_made')}),
        el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]),
      el('tbody', null, KS.csrs.map(function (c) {
        var k = keyOf(c.keyId);
        return el('tr', {'data-fp-csr': c.id}, [
          el('th', {scope: 'row', class: 'fp-mail-name fp-ky-name'}, [el('span', {class: 'fp-ky-title', text: csrTitle(c)}),
            c.names.length > 1 ? el('span', {class: 'fp-muted fp-row-note fp-ky-names-line', text: t('ky_names_of', {names: c.names.join(', ')})}) : null,
            el('span', {class: 'fp-muted fp-row-note', text: t('ky_made_with', {key: k ? keyName(k) : (c.fingerprint ? t('ky_key_print', {print: c.fingerprint.slice(0, 8)}) : t('ky_key_gone'))})})]),
          el('td', null, [el('span', {text: when(c.created)})]),
          el('td', {class: 'fp-mail-acts'}, [
            el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'csr-show', 'aria-label': t('ky_show_of', {name: csrTitle(c)}), text: t('ky_show')}),
            el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'csr-remove',
              'aria-label': t('ky_remove_request_of', {name: csrTitle(c)}), text: t('ky_remove')})])]);
      }))])]);
  }
  function requestsCard() {
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted fp-ky-lead', text: t('ky_requests_desc')})];
    if (!KS.csrsError && !KS.csrs.length) { parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': 'requests', text: t('ky_requests_none')})); }
    else if (KS.csrs.length) { parts.push(requestsTable()); }
    parts.push(el('h3', {class: 'fp-h3', text: t('ky_ask_title')}), requestForm());
    var card = M.card('fp-ky-requests-h', t('ky_requests_title'), parts, 'fp-ky-requests');
    if (KS.csrsError) { UI.showError(card, KS.csrsError); }
    return card;
  }
  function drawRequests() {
    var old = KS.page.querySelector('.fp-ky-requests');
    var fresh = requestsCard();
    if (old) { old.replaceWith(fresh); } else { KS.page.appendChild(fresh); }
  }
  /* the form of a new request again when the keys changed, so its key list is the current one */
  function drawRequestForm() {
    var card = KS.page.querySelector('.fp-ky-requests');
    if (!card) { return; }
    var forms = card.querySelectorAll('form');
    if (forms.length) { forms[forms.length - 1].replaceWith(requestForm()); }
  }

  /* the request to give to the authority, with a way to copy it */
  function shownCard() {
    var c = KS.shown;
    var area = el('textarea', {class: 'sig-input sig-mono fp-ky-pem', id: 'fp-ky-pem', rows: '10', readonly: '', spellcheck: 'false', 'aria-label': t('ky_pem_label'), 'data-fp-ky-pem': ''});
    area.value = c.pem;
    var facts = [fact(t('ky_f_names'), [el('span', {text: c.names.join(', ')})])];
    if (c.subject) { facts.push(fact(t('ky_f_subject'), [el('span', {class: 'sig-mono', text: c.subject})])); }
    return M.card('fp-ky-shown-h', t('ky_shown_title', {name: csrTitle(c)}), [M.statusLine(),
      c.pem ? el('p', {class: 'fp-muted', text: t('ky_shown_hint')}) : el('p', {class: 'fp-alert', role: 'alert', text: t('ky_shown_bad')}),
      el('dl', {class: 'fp-ky-facts'}, facts), c.pem ? area : null,
      el('div', {class: 'fp-actions'}, [c.pem ? el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'csr-copy', text: t('ky_copy')}) : null,
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'csr-close', text: t('ky_close')})])], 'fp-ky-shown');
  }
  function drawShown() {
    var old = KS.page.querySelector('.fp-ky-shown');
    if (!KS.shown) { if (old) { old.remove(); } return; }
    var fresh = shownCard();
    if (old) { old.replaceWith(fresh); } else { KS.page.insertBefore(fresh, KS.page.querySelector('.fp-ky-requests').nextSibling); }
  }

  function render() {
    KS.page.textContent = '';
    KS.page.appendChild(keysCard());
    KS.page.appendChild(requestsCard());
    if (KS.shown) { drawShown(); }
  }

  /* ================= clicks ================= */
  function onClick(e) {
    if (!KS || !KS.page) { return; }
    var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !KS.page.contains(b) || b.disabled) { return; }
    var act = b.getAttribute('data-fp-act');
    var tr = b.closest('tr');
    var keyRow = tr ? tr.getAttribute('data-fp-key') : '';
    var csrRow = tr ? tr.getAttribute('data-fp-csr') : '';
    var mine = KS;
    var card;
    if (act === 'key-remove') {
      var k = keyOf(keyRow);
      if (k) { M.confirmIn(tr.querySelector('.fp-mail-acts'), t('ky_remove_ask', {name: keyName(k)}), 'key-remove-yes', t('ky_remove')); }
    } else if (act === 'csr-remove') {
      var c = KS.csrs.filter(function (x) { return x.id === csrRow; })[0];
      if (c) { M.confirmIn(tr.querySelector('.fp-mail-acts'), t('ky_remove_request_ask', {name: csrTitle(c)}), 'csr-remove-yes', t('ky_remove')); }
    } else if (act === 'confirm-no') {
      if (keyRow) { drawKeys(); focusRow('key', keyRow, 'key-remove'); } else { drawRequests(); focusRow('csr', csrRow, 'csr-remove'); }
    } else if (act === 'key-remove-yes') {
      card = KS.page.querySelector('.fp-ky-keys');
      UI.showError(card, '');
      UI.setBusy(b, true);
      FP.call('del', 'sslKey', undefined, {name: KS.account, id: keyRow}).then(function () {
        if (KS !== mine) { return; }
        var gone = keyOf(keyRow);
        mine.keys = mine.keys.filter(function (x) { return x.id !== keyRow; });
        drawKeys();
        drawRequestForm();
        M.say(KS.page.querySelector('.fp-ky-keys'), t('ky_removed', {name: gone ? keyName(gone) : ''}));
        KS.page.querySelector('#fp-ky-keys-h').focus();
      }, function (err) {
        if (KS !== mine) { return; }
        drawKeys();
        UI.showError(KS.page.querySelector('.fp-ky-keys'), err.message);
        focusRow('key', keyRow, 'key-remove');
      });
    } else if (act === 'csr-remove-yes') {
      card = KS.page.querySelector('.fp-ky-requests');
      UI.showError(card, '');
      UI.setBusy(b, true);
      FP.call('del', 'sslCsr', undefined, {name: KS.account, id: csrRow}).then(function () {
        if (KS !== mine) { return; }
        mine.csrs = mine.csrs.filter(function (x) { return x.id !== csrRow; });
        if (mine.shown && mine.shown.id === csrRow) { mine.shown = null; }
        drawRequests();
        drawShown();
        M.say(KS.page.querySelector('.fp-ky-requests'), t('ky_request_removed'));
        KS.page.querySelector('#fp-ky-requests-h').focus();
        /* a key kept for a request may be removable now; the list needs no change */
      }, function (err) {
        if (KS !== mine) { return; }
        drawRequests();
        UI.showError(KS.page.querySelector('.fp-ky-requests'), err.message);
        focusRow('csr', csrRow, 'csr-remove');
      });
    } else if (act === 'csr-show') {
      card = KS.page.querySelector('.fp-ky-requests');
      UI.showError(card, '');
      UI.setBusy(b, true);
      FP.call('get', 'sslCsr', undefined, {name: KS.account, id: csrRow}).then(function (r) {
        if (KS !== mine) { return; }
        var shown = cleanCsr(r);
        UI.setBusy(b, false);
        if (!shown) { UI.showError(card, t('ky_shown_bad')); return; }
        mine.shown = shown;
        drawShown();
        KS.page.querySelector('.fp-ky-shown h2').focus();
      }, function (err) {
        UI.setBusy(b, false);
        if (KS === mine) { UI.showError(card, err.message); }
      });
    } else if (act === 'csr-close') {
      var was = KS.shown;
      KS.shown = null;
      drawShown();
      if (was) { focusRow('csr', was.id, 'csr-show'); }
    } else if (act === 'csr-copy') {
      card = KS.page.querySelector('.fp-ky-shown');
      var pem = card.querySelector('[data-fp-ky-pem]');
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(pem.value).then(function () { M.say(card, t('copied')); }, function () { pem.select(); M.say(card, t('copy_failed')); });
      } else { pem.select(); M.say(card, t('copy_failed')); }
    }
  }
  function focusRow(kind, id, act) {
    var n = KS.page.querySelector('tr[data-fp-' + kind + '="' + id + '"] [data-fp-act="' + act + '"]');
    if (n) { n.focus(); }
  }
  document.addEventListener('click', onClick);

  FP.view('tool:ssl_keys', function () {
    KS = null;
    var body = M.frame('ssl_keys', 'fp-ky');
    if (!body) { return; }
    KS = {page: body, account: FP.account(), keys: [], csrs: [], keysError: '', csrsError: '', shown: null};
    var mine = KS;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    var keys = FP.call('get', 'sslKeys', undefined, KS.account).then(function (r) { return {r: r}; }, function (err) { return {err: err}; });
    var csrs = FP.call('get', 'sslCsrs', undefined, KS.account).then(function (r) { return {r: r}; }, function (err) { return {err: err}; });
    Promise.all([keys, csrs]).then(function (all) {
      if (KS !== mine) { return; }
      if (all[0].err && all[1].err) {
        body.textContent = '';
        body.appendChild(FP.empty(FP.tools.ssl_keys.label, all[0].err.message));
        return;
      }
      mine.keysError = all[0].err ? all[0].err.message : '';
      mine.csrsError = all[1].err ? all[1].err.message : '';
      mine.keys = all[0].err ? [] : sorted(cleanKeys(all[0].r));
      mine.csrs = all[1].err ? [] : sorted(cleanCsrs(all[1].r));
      render();
    });
  });
})();

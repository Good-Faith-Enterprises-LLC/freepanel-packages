/* freePanel mail tools of the administrators' panel (docs/api.md, "Email delivery tools"): Welcome email (#/tool/mail_welcome), Mail
   statistics (#/tool/mail_stats), Blocked senders and networks (#/tool/mail_blocks) and Outgoing addresses (#/tool/mail_outgoing_ips).
   Nothing changes until the admin saves; what the server sends is cleaned to the shapes drawn and shown as text, and what the page
   can see is wrong is said before anything is sent, in the server's own limits. Page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function whole(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.round(v) : 0; }
  function arr(v) { return Array.isArray(v) ? v : []; }
  function count(n) { return n.toLocaleString('en'); }
  function frame(id, desc, cls) {
    var tool = FP.tools[id];
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return null; }
    var g = FP.group(tool.group);
    return FP.frame({title: tool.label, desc: t(desc), cls: 'fp-mail fp-mt3 ' + cls,
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
  }
  function failedPage(page, id, err) {
    page.textContent = '';
    page.appendChild(FP.empty(FP.tools[id].label, err.message));
  }
  function warn(text, attr) {
    var b = el('div', {class: 'sig-banner sig-banner--warn', role: 'note'}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: text})]);
    if (attr) { b.setAttribute(attr, ''); }
    return b;
  }
  function lines(box) {
    return box.value.split('\n').map(function (l) { return l.trim(); }).filter(Boolean);
  }
  function bytes(s) { return window.TextEncoder ? new window.TextEncoder().encode(s).length : s.length; }

  /* ================= Welcome email ================= */
  var W = null;
  /* a control character other than a tab or a line break */
  var CONTROL_RE = {test: function (text) {
    for (var i = 0; i < text.length; i++) {
      var c = text.charCodeAt(i);
      if ((c < 32 && c !== 9 && c !== 10 && c !== 13) || c === 127) { return true; }
    }
    return false;
  }};
  function cleanWelcome(r) {
    r = r && typeof r === 'object' ? r : {};
    return {enabled: r.enabled === true, subject: str(r.subject, 200), body: str(r.body, 4000), ready: r.ready === true, warning: str(r.warning, 300),
      placeholders: arr(r.placeholders).filter(function (p) { return typeof p === 'string' && /^\{[a-z]{1,20}\}$/.test(p); }).slice(0, 10)};
  }
  /* a word in braces the server does not know is refused there; the page says so first, naming the ones it does */
  function strayWord(text, known) {
    var found = text.match(/\{[^{}\s]*\}/g) || [];
    for (var i = 0; i < found.length; i++) { if (known.indexOf(found[i]) < 0) { return found[i]; } }
    return '';
  }
  function welcomeDraw() {
    W.page.textContent = '';
    if (W.data.warning) { W.page.appendChild(warn(t('mw_warning', {why: W.data.warning}), 'data-fp-warning')); }
    if (!W.data.ready) { W.page.appendChild(warn(t('mw_not_ready'), 'data-fp-not-ready')); }
    var d = W.data;
    var on = el('input', {type: 'checkbox', id: 'fp-mw-on', name: 'enabled', checked: d.enabled ? true : null, disabled: !d.ready && !d.enabled ? true : null});
    var subject = el('input', {class: 'sig-input', id: 'fp-mw-subject', name: 'subject', type: 'text', maxlength: '200', autocomplete: 'off', value: d.subject});
    var body = el('textarea', {class: 'sig-input fp-mw-body', id: 'fp-mw-body', name: 'body', rows: '12', spellcheck: 'true', autocomplete: 'off'});
    body.value = d.body;
    var known = d.placeholders.join(', ');
    var form = el('form', {class: 'fp-form fp-mail-form fp-mw-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'sig-field'}, [el('label', {class: 'fp-check', for: 'fp-mw-on'}, [on, el('span', {text: t('mw_on')})]),
        el('span', {class: 'sig-hint', id: 'fp-mw-on-hint', text: t('mw_on_hint')})]),
      M.field('fp-mw-subject', t('mw_subject'), subject, t('mw_subject_hint')),
      M.field('fp-mw-body', t('mw_body'), body, t('mw_body_hint', {words: known || '—'})),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('mw_save')})])]);
    on.setAttribute('aria-describedby', 'fp-mw-on-hint');
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var s = subject.value;
      if (/[\r\n]/.test(s) || s.length > 200 || CONTROL_RE.test(s)) { M.fieldError(form, subject, t('mw_subject_bad')); return; }
      var stray = strayWord(s, d.placeholders);
      if (stray) { M.fieldError(form, subject, t('mw_stray', {word: stray, words: known})); return; }
      var text = body.value;
      if (bytes(text) > 4000 || CONTROL_RE.test(text)) { M.fieldError(form, body, t('mw_body_bad')); return; }
      stray = strayWord(text, d.placeholders);
      if (stray) { M.fieldError(form, body, t('mw_stray', {word: stray, words: known})); return; }
      var mine = W;
      UI.setBusy(b, true);
      FP.call('put', 'mailWelcome', {enabled: on.checked, subject: s, body: text}).then(function (r) {
        if (W !== mine) { return; }
        mine.data = cleanWelcome(r);
        welcomeDraw();
        M.say(W.page.querySelector('.fp-mw-form'), t(mine.data.enabled ? 'mw_saved_on' : 'mw_saved_off'));
        W.page.querySelector('#fp-mw-h').focus();
      }, function (err) {
        UI.setBusy(b, false);
        if (W === mine) { M.failed(form, err); }
      });
    });
    W.page.appendChild(M.card('fp-mw-h', t('mw_title'), [el('p', {class: 'fp-muted', text: t('mw_intro')}), form], 'fp-mw'));
  }
  FP.view('tool:mail_welcome', function () {
    W = null;
    var page = frame('mail_welcome', 'mw_desc', 'fp-mw-page');
    if (!page) { return; }
    var mine = W = {page: page, data: null};
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'mailWelcome').then(function (r) {
      if (W !== mine) { return; }
      mine.data = cleanWelcome(r);
      welcomeDraw();
    }, function (err) { if (W === mine) { failedPage(page, 'mail_welcome', err); } });
  });

  /* ================= Mail statistics ================= */
  var S = null;
  var DAYS = [7, 30, 90];
  var KINDS = ['received', 'relayed', 'submitted', 'delivered_remote', 'delivered_local', 'deferred', 'bounced', 'rejected'];
  function counts(x) {
    x = x && typeof x === 'object' ? x : {};
    var out = {};
    KINDS.forEach(function (k) { out[k] = whole(x[k]); });
    return out;
  }
  function names(list) {
    return arr(list).filter(function (x) { return x && typeof x === 'object' && typeof x.name === 'string' && x.name; }).slice(0, 20)
      .map(function (x) { return {name: str(x.name, 253), count: whole(x.count)}; });
  }
  function cleanStats(r) {
    r = r && typeof r === 'object' ? r : {};
    var series = arr(r.series).filter(function (x) { return x && typeof x === 'object' && /^[0-9]{4}-[0-9]{2}-[0-9]{2}$/.test(str(x.date, 10)); }).slice(0, 90)
      .map(function (x) { var c = counts(x); c.date = x.date; return c; });
    return {days: whole(r.days), from: str(r.from, 10), to: str(r.to, 10), series: series, totals: counts(r.totals),
      domains: names(r.top_domains), rejected: names(r.top_rejected), relayers: names(r.top_relayers)};
  }
  function statsDate(iso) {
    var d = new Date(iso + 'T00:00:00Z');
    return isNaN(d.getTime()) ? iso : d.toLocaleDateString('en-GB', {day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC'});
  }
  function topCard(id, title, note, list) {
    var parts = [el('p', {class: 'fp-muted', text: note})];
    if (!list.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': id, text: t('ms_none')}));
    } else {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-ms-' + id + '-h'}, [el('table', {class: 'sig-table fp-ms-top'}, [
        el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('ms_col_name')}), el('th', {scope: 'col', class: 'fp-num', text: t('ms_col_count')})])]),
        el('tbody', null, list.map(function (x) {
          return el('tr', null, [el('th', {scope: 'row', class: 'sig-mono', text: x.name}), el('td', {class: 'fp-num', text: count(x.count)})]);
        }))])]));
    }
    return M.card('fp-ms-' + id + '-h', title, parts, 'fp-ms-card fp-ms-' + id);
  }
  function statsDraw() {
    var d = S.data;
    S.out.textContent = '';
    var total = KINDS.reduce(function (n, k) { return n + d.totals[k]; }, 0);
    var facts = [];
    KINDS.forEach(function (k) { facts.push(el('div', {'data-fp-total': k}, [el('dt', {text: t('ms_k_' + k)}), el('dd', {text: count(d.totals[k])})])); });
    var parts = [el('p', {class: 'fp-muted', 'data-fp-period': '', text: t('ms_period', {from: statsDate(d.from), to: statsDate(d.to), days: d.days})})];
    if (!total) { parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('ms_empty')})); }
    parts.push(el('dl', {class: 'fp-mt3-facts'}, facts));
    parts.push(el('p', {class: 'fp-muted', text: t('ms_kept')}));
    S.out.appendChild(M.card('fp-ms-totals-h', t('ms_totals'), parts, 'fp-ms-totals'));
    var rows = d.series.slice().reverse().map(function (x) {
      return el('tr', {'data-fp-day': x.date}, [el('th', {scope: 'row', text: statsDate(x.date)})].concat(KINDS.map(function (k) { return el('td', {class: 'fp-num', text: count(x[k])}); })));
    });
    S.out.appendChild(M.card('fp-ms-days-h', t('ms_days'), [el('p', {class: 'fp-muted', text: t('ms_days_note')}),
      el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-ms-days-h'}, [el('table', {class: 'sig-table fp-ms-table'}, [
        el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('ms_col_day')})].concat(KINDS.map(function (k) { return el('th', {scope: 'col', class: 'fp-num', text: t('ms_c_' + k)}); })))]),
        el('tbody', null, rows)])])], 'fp-ms-card fp-ms-days'));
    S.out.appendChild(topCard('domains', t('ms_top_domains'), t('ms_top_domains_note'), d.domains));
    S.out.appendChild(topCard('rejected', t('ms_top_rejected'), t('ms_top_rejected_note'), d.rejected));
    S.out.appendChild(topCard('relayers', t('ms_top_relayers'), t('ms_top_relayers_note'), d.relayers));
  }
  function statsLoad(refresh, note) {
    var mine = S;
    var q = {days: String(mine.days)};
    if (refresh) { q.refresh = '1'; }
    var b = mine.form.querySelector('.fp-submit');
    UI.showError(mine.form, '');
    UI.setBusy(b, true);
    return FP.call('get', 'mailStats', undefined, q).then(function (r) {
      UI.setBusy(b, false);
      if (S !== mine) { return; }
      mine.data = cleanStats(r);
      statsDraw();
      M.say(mine.form, note || '');
    }, function (err) {
      UI.setBusy(b, false);
      if (S === mine) { M.failed(mine.form, err); }
    });
  }
  FP.view('tool:mail_stats', function () {
    S = null;
    var page = frame('mail_stats', 'ms_desc', 'fp-ms-page');
    if (!page) { return; }
    var pick = el('select', {class: 'sig-select', id: 'fp-ms-days', name: 'days'}, DAYS.map(function (n) { return el('option', {value: String(n), text: t('ms_last', {days: n})}); }));
    pick.value = '30';
    var form = el('form', {class: 'fp-form fp-mail-form fp-ms-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-ms-days', t('ms_period_label'), pick, t('ms_period_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary fp-submit', type: 'submit', text: t('ms_refresh')})])]);
    var out = el('div', {class: 'fp-ms-out'});
    var mine = S = {page: page, form: form, out: out, days: 30, data: null};
    page.appendChild(M.card('fp-ms-pick-h', t('ms_pick_title'), [form], 'fp-ms-pick'));
    page.appendChild(out);
    out.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    pick.addEventListener('change', function () {
      mine.days = parseInt(pick.value, 10) || 30;
      statsLoad(false, t('ms_updated'));
    });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (form.querySelector('.fp-submit').disabled) { return; }
      statsLoad(true, t('ms_read'));
    });
    FP.call('get', 'mailStats', undefined, {days: '30'}).then(function (r) {
      if (S !== mine) { return; }
      mine.data = cleanStats(r);
      statsDraw();
    }, function (err) { if (S === mine) { failedPage(page, 'mail_stats', err); } });
  });

  /* ================= Blocked senders and networks ================= */
  var B = null;
  var MAX_BLOCKS = 500;
  function cleanBlocks(r) {
    r = r && typeof r === 'object' ? r : {};
    function list(v) { return arr(v).filter(function (x) { return typeof x === 'string' && x; }).slice(0, MAX_BLOCKS).map(function (x) { return x.slice(0, 253); }); }
    return {domains: list(r.sender_domains), networks: list(r.client_networks), trusted: list(r.trusted_networks), warning: str(r.warning, 300)};
  }
  function blocksDraw() {
    var d = B.data;
    B.page.textContent = '';
    if (d.warning) { B.page.appendChild(warn(t('mb_warning', {why: d.warning}), 'data-fp-warning')); }
    var domains = el('textarea', {class: 'sig-input sig-mono fp-mb-list', id: 'fp-mb-domains', name: 'sender_domains', rows: '8', spellcheck: 'false', autocapitalize: 'none', autocomplete: 'off'});
    domains.value = d.domains.join('\n');
    var networks = el('textarea', {class: 'sig-input sig-mono fp-mb-list', id: 'fp-mb-networks', name: 'client_networks', rows: '8', spellcheck: 'false', autocapitalize: 'none', autocomplete: 'off'});
    networks.value = d.networks.join('\n');
    var trusted = el('textarea', {class: 'sig-input sig-mono fp-mb-list', id: 'fp-mb-trusted', name: 'trusted_networks', rows: '5', spellcheck: 'false', autocapitalize: 'none', autocomplete: 'off'});
    trusted.value = d.trusted.join('\n');
    var summary = d.domains.length || d.networks.length ? t('mb_now', {domains: count(d.domains.length), networks: count(d.networks.length)}) : t('mb_none');
    var form = el('form', {class: 'fp-form fp-mail-form fp-mb-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-mb-domains', t('mb_domains'), domains, t('mb_domains_hint', {max: MAX_BLOCKS})),
      M.field('fp-mb-networks', t('mb_networks'), networks, t('mb_networks_hint', {max: MAX_BLOCKS})),
      M.field('fp-mb-trusted', t('mb_trusted'), trusted, t('mb_trusted_hint', {max: MAX_BLOCKS})),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('mb_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var ds = lines(domains);
      var ns = lines(networks);
      var ts = lines(trusted);
      var bad = null;
      [[ds, domains], [ns, networks], [ts, trusted]].forEach(function (p) {
        if (bad) { return; }
        if (p[0].length > MAX_BLOCKS) { bad = [p[1], t('mb_many', {max: MAX_BLOCKS})]; return; }
        p[0].forEach(function (x) { if (!bad && (/\s/.test(x) || x.length > 253)) { bad = [p[1], t('mb_line_bad', {line: x.slice(0, 60)})]; } });
      });
      if (bad) { M.fieldError(form, bad[0], bad[1]); return; }
      var mine = B;
      UI.setBusy(b, true);
      FP.call('put', 'mailBlocks', {sender_domains: ds, client_networks: ns, trusted_networks: ts}).then(function (r) {
        if (B !== mine) { return; }
        mine.data = cleanBlocks(r);
        blocksDraw();
        M.say(B.page.querySelector('.fp-mb-form'), t('mb_saved'));
        B.page.querySelector('#fp-mb-h').focus();
      }, function (err) {
        UI.setBusy(b, false);
        if (B === mine) { M.failed(form, err); }
      });
    });
    B.page.appendChild(M.card('fp-mb-h', t('mb_title'), [el('p', {class: 'fp-muted', text: t('mb_intro')}), el('p', {class: 'fp-mb-now', 'data-fp-now': '', text: summary}), form], 'fp-mb'));
  }
  FP.view('tool:mail_blocks', function () {
    B = null;
    var page = frame('mail_blocks', 'mb_desc', 'fp-mb-page');
    if (!page) { return; }
    var mine = B = {page: page, data: null};
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'mailBlocks').then(function (r) {
      if (B !== mine) { return; }
      mine.data = cleanBlocks(r);
      blocksDraw();
    }, function (err) { if (B === mine) { failedPage(page, 'mail_blocks', err); } });
  });

  /* ================= Outgoing addresses ================= */
  var O = null;
  var MAX_OUT = 200;
  var NAME_RE = /^[a-z0-9.-]{1,253}$/;
  var ADDR_RE = /^[0-9a-fA-F:.]{2,45}$/;
  function cleanOut(r) {
    r = r && typeof r === 'object' ? r : {};
    var chosen = {};
    var dom = r.domains && typeof r.domains === 'object' && !Array.isArray(r.domains) ? r.domains : {};
    Object.keys(dom).slice(0, 1000).forEach(function (k) { if (NAME_RE.test(k) && typeof dom[k] === 'string' && ADDR_RE.test(dom[k])) { chosen[k] = dom[k]; } });
    return {chosen: chosen, addresses: arr(r.addresses).filter(function (a) { return typeof a === 'string' && ADDR_RE.test(a); }).slice(0, 200),
      hosted: arr(r.hosted_domains).filter(function (d) { return typeof d === 'string' && NAME_RE.test(d); }).slice(0, 2000), warning: str(r.warning, 400)};
  }
  function outDraw() {
    var d = O.data;
    O.page.textContent = '';
    if (d.warning) { O.page.appendChild(warn(t('mo_warning', {why: d.warning}), 'data-fp-warning')); }
    var parts = [el('p', {class: 'fp-muted', text: t('mo_intro')})];
    var form = null;
    if (!d.hosted.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': 'domains', text: t('mo_no_domains')}));
    } else if (!d.addresses.length && !Object.keys(d.chosen).length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': 'addresses', text: t('mo_no_addresses')}));
    } else {
      /* a domain not hosted here any more can still hold a choice: it is listed so it can be cleared */
      var domains = d.hosted.slice();
      Object.keys(d.chosen).forEach(function (k) { if (domains.indexOf(k) < 0) { domains.push(k); } });
      domains.sort();
      var rows = domains.map(function (name, i) {
        var id = 'fp-mo-' + i;
        var pick = el('select', {class: 'sig-select', id: id, name: name, 'data-fp-domain': name}, [el('option', {value: '', text: t('mo_system')})]
          .concat(d.addresses.map(function (a) { return el('option', {value: a, text: a}); })));
        var want = d.chosen[name] || '';
        if (want && d.addresses.indexOf(want) < 0) { pick.appendChild(el('option', {value: want, text: t('mo_gone', {address: want})})); }
        pick.value = want;
        return el('tr', {'data-fp-row': name}, [el('th', {scope: 'row', class: 'sig-mono'}, [el('label', {for: id, text: name})]), el('td', null, [pick])]);
      });
      form = el('form', {class: 'fp-form fp-mail-form fp-mo-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
        el('p', {class: 'fp-muted', 'data-fp-count': '', text: t('mo_count', {n: count(Object.keys(d.chosen).length), max: MAX_OUT})}),
        el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-mo-h'}, [el('table', {class: 'sig-table fp-mo-table'}, [
          el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('mo_col_domain')}), el('th', {scope: 'col', text: t('mo_col_address')})])]),
          el('tbody', null, rows)])]),
        el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('mo_save')})])]);
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var b = M.start(form);
        if (!b) { return; }
        var choice = {};
        var picks = form.querySelectorAll('select[data-fp-domain]');
        for (var i = 0; i < picks.length; i++) { if (picks[i].value) { choice[picks[i].getAttribute('data-fp-domain')] = picks[i].value; } }
        if (Object.keys(choice).length > MAX_OUT) { M.fieldError(form, null, t('mo_many', {max: MAX_OUT})); return; }
        var mine = O;
        UI.setBusy(b, true);
        FP.call('put', 'mailOutIps', {domains: choice}).then(function (r) {
          if (O !== mine) { return; }
          mine.data = cleanOut(r);
          outDraw();
          M.say(O.page.querySelector('.fp-mo-form'), t('mo_saved'));
          O.page.querySelector('#fp-mo-h').focus();
        }, function (err) {
          UI.setBusy(b, false);
          if (O === mine) { M.failed(form, err); }
        });
      });
      parts.push(form);
    }
    O.page.appendChild(M.card('fp-mo-h', t('mo_title'), parts, 'fp-mo'));
  }
  FP.view('tool:mail_outgoing_ips', function () {
    O = null;
    var page = frame('mail_outgoing_ips', 'mo_desc', 'fp-mo-page');
    if (!page) { return; }
    var mine = O = {page: page, data: null};
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'mailOutIps').then(function (r) {
      if (O !== mine) { return; }
      mine.data = cleanOut(r);
      outDraw();
    }, function (err) { if (O === mine) { failedPage(page, 'mail_outgoing_ips', err); } });
  });
})();

/* freePanel Git repositories (#/tool/git_repos), the customer panel's page for the account's repositories (docs/api.md, "Git repositories"):
   make an empty one or copy a public one from its https address, bring a copy up to date, choose the folder of the site its files are
   deployed to (and whether an update deploys them), and remove it. Copies, updates and deploys run on the server in the background, so
   the page asks again every few seconds while one runs, and says how it went. What the server sends is drawn as text. It shares the mail
   pages' look and helpers (FP.mail). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var NAME_RE = /^[a-z0-9][a-z0-9._-]{0,63}$/;
  var BRANCH_RE = /^[A-Za-z0-9][A-Za-z0-9._/-]{0,99}$/;
  var PART_RE = /^[A-Za-z0-9._-]+$/;
  var SHA_RE = /^[0-9a-f]{7,64}$/;
  var STATUS = {ready: 'git_st_ready', cloning: 'git_st_cloning', updating: 'git_st_updating', deploying: 'git_st_deploying', failed: 'git_st_failed',
    stopped: 'git_st_stopped'};
  var BUSY = {cloning: true, updating: true, deploying: true};
  var EVERY = 2000;
  var G = {page: null, account: '', state: null, open: '', ask: '', timer: 0};

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function num(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.floor(v) : 0; }
  function when(iso) {
    var d = iso ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString(undefined, {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }
  function cleanRepo(r) {
    if (!r || typeof r !== 'object' || !NAME_RE.test(str(r.name, 80)) || !STATUS[r.status]) { return null; }
    var h = r.head && typeof r.head === 'object' && SHA_RE.test(str(r.head.sha, 70)) ?
      {sha: r.head.sha, subject: str(r.head.subject, 220), when: str(r.head.when, 40)} : null;
    var d = r.deployed && typeof r.deployed === 'object' && SHA_RE.test(str(r.deployed.commit, 70)) ?
      {commit: r.deployed.commit, when: str(r.deployed.when, 40), files: num(r.deployed.files), removed: num(r.deployed.removed), skipped: num(r.deployed.skipped)} : null;
    return {name: r.name, path: 'repositories/' + r.name, remote: str(r.remote, 2100), branch: str(r.branch, 110), status: r.status, problem: str(r.problem, 900),
      head: h, updated: str(r.updated, 40), note: str(r.note, 200), deployDir: str(r.deploy_dir, 255), auto: r.auto_deploy === true, deployed: d,
      deployProblem: str(r.deploy_problem, 900)};
  }
  function clean(v) {
    if (!v || typeof v !== 'object' || !Array.isArray(v.repos)) { return null; }
    return {repos: v.repos.slice(0, 60).map(cleanRepo).filter(Boolean).sort(function (a, b) { return a.name < b.name ? -1 : 1; })};
  }
  function find(name) {
    for (var i = 0; i < G.state.repos.length; i++) { if (G.state.repos[i].name === name) { return G.state.repos[i]; } }
    return null;
  }
  function anyBusy() { return G.state.repos.some(function (r) { return BUSY[r.status]; }); }

  /* a folder as typed: '' for none; the clean path otherwise; or the key of the string that says why it will not do */
  function cleanDir(v) {
    v = v.trim().replace(/^\/+|\/+$/g, '');
    if (v === '' || v === '.') { return {dir: ''}; }
    if (v.length > 255) { return {bad: 'git_set_dir_bad'}; }
    var parts = v.split('/');
    for (var i = 0; i < parts.length; i++) {
      if (!PART_RE.test(parts[i]) || parts[i] === '.' || parts[i] === '..') { return {bad: 'git_set_dir_bad'}; }
    }
    if (v === 'repositories' || v.indexOf('repositories/') === 0) { return {bad: 'git_set_dir_repos'}; }
    if (v.charAt(0) === '.') { return {bad: 'git_set_dir_hidden'}; }
    return {dir: v};
  }

  /* ---- the form that makes a repository ---- */
  function createCard() {
    var submit = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('git_make_btn')});
    var remote = el('input', {class: 'sig-input sig-mono', id: 'fp-git-remote', name: 'remote', type: 'text', autocomplete: 'off', spellcheck: 'false',
      autocapitalize: 'none', maxlength: '2048', placeholder: 'https://github.com/owner/project.git'});
    var form = el('form', {class: 'fp-form fp-mail-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-git-name', t('git_name'), el('input', {class: 'sig-input sig-mono', id: 'fp-git-name', name: 'name', type: 'text', autocomplete: 'off', spellcheck: 'false',
        autocapitalize: 'none', maxlength: '64'}), t('git_name_hint')),
      M.field('fp-git-remote', t('git_remote'), remote, t('git_remote_hint')),
      M.field('fp-git-branch', t('git_branch'), el('input', {class: 'sig-input sig-mono', id: 'fp-git-branch', name: 'branch', type: 'text', autocomplete: 'off',
        spellcheck: 'false', autocapitalize: 'none', maxlength: '100'}), t('git_branch_hint')),
      el('div', {class: 'fp-actions'}, [submit])]);
    remote.addEventListener('input', function () { submit.textContent = remote.value.trim() ? t('git_clone_btn') : t('git_make_btn'); });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var name = form.querySelector('[name="name"]');
      var branch = form.querySelector('[name="branch"]');
      if (!NAME_RE.test(name.value.trim()) || name.value.indexOf('..') >= 0 || /\.lock$/.test(name.value.trim())) { M.fieldError(form, name, t('git_name_bad')); return; }
      var body = {name: name.value.trim()};
      if (remote.value.trim()) {
        if (!/^https:\/\/[^\s/]+\/\S*$/i.test(remote.value.trim())) { M.fieldError(form, remote, t('git_remote_bad')); return; }
        body.remote = remote.value.trim();
      }
      if (branch.value.trim()) {
        if (!BRANCH_RE.test(branch.value.trim()) || branch.value.indexOf('..') >= 0) { M.fieldError(form, branch, t('git_branch_bad')); return; }
        body.branch = branch.value.trim();
      }
      UI.setBusy(b, true);
      FP.call('post', 'gitRepos', body, G.account).then(function (r) {
        var s = clean(r);
        UI.setBusy(b, false);
        if (!s) { M.fieldError(form, null, t('api_failed')); return; }
        G.state = s;
        syncList();
        schedule();
        form.reset();
        submit.textContent = t('git_make_btn');
        M.say(form, body.remote ? t('git_clone_started', {name: body.name}) : t('git_made_empty', {name: body.name}));
        name.focus();
      }, function (err) {
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return M.card('fp-git-make-h', t('git_make_title'), [el('p', {class: 'fp-muted', text: t('git_make_desc')}), form], 'fp-git-make');
  }

  /* ---- the list ---- */
  function pill(r) {
    var cls = r.status === 'ready' ? ' sig-pill--ok' : BUSY[r.status] ? ' sig-pill--accent' : ' sig-pill--danger';
    return el('span', {class: 'sig-pill' + cls, text: t(STATUS[r.status])});
  }
  function fact(list, key, value, mono) {
    if (!value) { return; }
    list.push(el('dt', {class: 'fp-git-k', text: t(key)}), el('dd', {class: 'fp-git-v' + (mono ? ' sig-mono' : ''), text: value}));
  }
  function summary(r) {
    var facts = [];
    fact(facts, 'git_f_folder', r.path, true);
    facts.push(el('dt', {class: 'fp-git-k', text: t('git_f_from')}), el('dd', {class: 'fp-git-v' + (r.remote ? ' sig-mono' : ''), text: r.remote || t('git_empty_here')}));
    fact(facts, 'git_f_branch', r.branch, true);
    if (r.head) {
      fact(facts, 'git_f_commit', t('git_commit', {subject: r.head.subject, sha: r.head.sha.slice(0, 7), date: when(r.head.when)}));
    } else if (r.status === 'ready' || r.status === 'updating' || r.status === 'deploying') {
      fact(facts, 'git_f_commit', t('git_no_commit'));
    }
    if (r.updated) { fact(facts, 'git_f_update', t('git_updated', {note: r.note, date: when(r.updated)}).trim()); }
    if (r.status !== 'failed' && r.status !== 'stopped') {
      fact(facts, 'git_f_deploy', r.deployDir ? (r.auto ? t('git_deploys_auto', {dir: r.deployDir}) : r.deployDir) : t('git_no_deploy'), Boolean(r.deployDir) && !r.auto);
    }
    if (r.deployed) {
      var d = r.deployed;
      var extra = [];
      if (d.removed) { extra.push(t('git_x_removed', {n: d.removed})); }
      if (d.skipped) { extra.push(t('git_x_skipped', {n: d.skipped})); }
      fact(facts, 'git_f_deployed', t(d.files === 1 ? 'git_deployed_one' : 'git_deployed', {files: d.files, sha: d.commit.slice(0, 7), date: when(d.when)}) +
        (extra.length ? ' (' + extra.join(', ') + ')' : ''));
    }
    var parts = [el('dl', {class: 'fp-git-vals'}, facts)];
    if (r.problem) { parts.push(el('p', {class: 'fp-warn-line', 'data-fp-problem': '', text: r.problem})); }
    if (r.status === 'failed' || r.status === 'stopped') { parts.push(el('p', {class: 'fp-muted', text: t('git_failed_hint')})); }
    if (r.deployProblem) { parts.push(el('p', {class: 'fp-warn-line', 'data-fp-deploy-problem': '', text: t('git_deploy_problem', {problem: r.deployProblem})})); }
    return parts;
  }
  function button(act, label, aria, extra) {
    return el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm' + (extra || ''), type: 'button', 'data-fp-act': act, 'aria-label': aria, text: label});
  }
  function removeAsk(r) {
    var id = 'fp-git-ask-' + r.name;
    return el('div', {class: 'fp-git-ask', role: 'group', 'aria-labelledby': id}, [
      el('p', {class: 'fp-mail-confirm', id: id, text: t('git_remove_ask', {name: r.name})}),
      el('label', {class: 'fp-check'}, [el('input', {type: 'checkbox', name: 'files', 'aria-describedby': id + '-hint'}), el('span', {text: t('git_remove_files', {name: r.name})})]),
      el('span', {class: 'sig-hint', id: id + '-hint', text: r.deployDir ? t('git_remove_files_hint') : ''}),
      el('div', {class: 'fp-git-acts'}, [
        el('button', {class: 'sig-btn sig-btn--danger sig-btn--sm', type: 'button', 'data-fp-act': 'remove-yes', 'aria-describedby': id, text: t('git_remove_yes')}),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'remove-no', 'aria-describedby': id, text: t('git_keep')})])]);
  }
  function actions(r) {
    if (BUSY[r.status]) { return el('p', {class: 'fp-muted fp-git-wait', text: t('git_working')}); }
    if (G.ask === r.name) { return removeAsk(r); }
    var acts = [];
    if (r.status === 'ready') {
      /* the viewer (fp-gitview.js) opens on the repository this link was made for */
      acts.push(el('a', {class: 'sig-btn sig-btn--secondary sig-btn--sm', href: '#/tool/git_view', 'data-fp-view': r.name, 'aria-label': t('git_browse_of', {name: r.name}),
        text: t('git_browse')}));
      if (r.remote) { acts.push(button('update', t('git_update'), t('git_update_of', {name: r.name}))); }
      if (r.deployDir && r.head) { acts.push(button('deploy', t('git_deploy_now'), t('git_deploy_of', {name: r.name}))); }
      var s = button('settings', t('git_settings'), t('git_settings_of', {name: r.name}));
      s.setAttribute('aria-expanded', String(G.open === r.name));
      acts.push(s);
    }
    acts.push(button('remove', t('git_remove'), t('git_remove_of', {name: r.name}), ' fp-btn-danger-text'));
    return el('div', {class: 'fp-git-acts'}, acts);
  }
  function main(r) {
    var head = el('div', {class: 'fp-git-head'}, [el('h3', {class: 'fp-h3 sig-mono', id: 'fp-git-h-' + r.name, tabindex: '-1', text: r.name}), pill(r)]);
    return [head].concat(summary(r), [actions(r)]);
  }
  function sig(r) { return JSON.stringify([r, G.open === r.name, G.ask === r.name]); }
  function section(r) {
    var s = el('section', {class: 'fp-git-item', 'data-fp-repo': r.name, 'aria-labelledby': 'fp-git-h-' + r.name}, [el('div', {class: 'fp-git-main'}), el('div', {class: 'fp-git-more'})]);
    return s;
  }
  function fill(node, r) {
    var m = node.querySelector('.fp-git-main');
    m.textContent = '';
    main(r).forEach(function (c) { m.appendChild(c); });
    node.setAttribute('data-fp-sig', sig(r));
  }
  /* brings the list on the page to the state: only the repositories that changed are drawn again, so a form left open elsewhere is kept */
  function syncList() {
    var holder = G.page.querySelector('.fp-git-items');
    var none = G.page.querySelector('[data-fp-empty]');
    none.hidden = G.state.repos.length > 0;
    var have = {};
    Array.prototype.forEach.call(holder.children, function (n) { have[n.getAttribute('data-fp-repo')] = n; });
    G.state.repos.forEach(function (r) { delete have[r.name]; });
    Object.keys(have).forEach(function (k) {
      if (G.open === k) { G.open = ''; }
      if (G.ask === k) { G.ask = ''; }
      holder.removeChild(have[k]);
    });
    var after = null;
    G.state.repos.forEach(function (r) {
      var node = holder.querySelector('[data-fp-repo="' + r.name + '"]');
      if (!node) {
        node = section(r);
        holder.insertBefore(node, after ? after.nextSibling : holder.firstChild);
      }
      if (node.getAttribute('data-fp-sig') !== sig(r)) { fill(node, r); }
      after = node;
    });
  }
  function listCard() {
    var items = el('div', {class: 'fp-git-items'});
    var card = M.card('fp-git-list-h', t('git_list_title'), [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('git_none')}), items], 'fp-git-list');
    return card;
  }
  function render() {
    G.page.textContent = '';
    G.page.appendChild(createCard());
    G.page.appendChild(listCard());
    syncList();
  }
  function node(name) { return G.page.querySelector('[data-fp-repo="' + window.CSS.escape(name) + '"]'); }
  function focusHead(name) {
    var h = G.page.querySelector('#fp-git-h-' + window.CSS.escape(name));
    if (h) { h.focus(); }
  }
  function focusAct(name, act) {
    var n = node(name);
    var b = n && n.querySelector('[data-fp-act="' + act + '"]');
    if (b) { b.focus(); } else { focusHead(name); }
  }
  function redraw(name) {
    var n = node(name);
    var r = find(name);
    if (n && r) { fill(n, r); }
  }

  /* ---- the deploy settings of one repository ---- */
  function settingsForm(r) {
    var dirId = 'fp-git-dir-' + r.name;
    var autoId = 'fp-git-auto-' + r.name;
    var auto = el('input', {type: 'checkbox', id: autoId, name: 'auto_deploy', checked: r.auto ? true : null, disabled: r.remote ? null : true, 'aria-describedby': autoId + '-hint'});
    var form = el('form', {class: 'fp-form fp-mail-inline fp-git-set', novalidate: '', 'aria-labelledby': 'fp-git-set-h-' + r.name}, [
      el('h4', {class: 'fp-h3', id: 'fp-git-set-h-' + r.name, tabindex: '-1', text: t('git_set_title', {name: r.name})}), M.errorLine(), M.statusLine(),
      el('p', {class: 'fp-muted', text: t('git_set_about')}),
      M.field(dirId, t('git_set_dir'), el('input', {class: 'sig-input sig-mono', id: dirId, name: 'deploy_dir', type: 'text', autocomplete: 'off', spellcheck: 'false',
        autocapitalize: 'none', maxlength: '255', value: r.deployDir, placeholder: 'public_html/…'}), t('git_set_dir_hint')),
      el('div', {class: 'sig-field'}, [el('label', {class: 'fp-check', for: autoId}, [auto, el('span', {text: t('git_set_auto')})]),
        el('span', {class: 'sig-hint', id: autoId + '-hint', text: r.remote ? t('git_set_auto_hint') : t('git_set_auto_empty')})]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('git_set_save')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'settings-close', text: t('cancel')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var dirField = form.querySelector('[name="deploy_dir"]');
      var d = cleanDir(dirField.value);
      if (d.bad) { M.fieldError(form, dirField, t(d.bad)); return; }
      var want = auto.checked && d.dir !== '';
      if (auto.checked && d.dir === '') { M.fieldError(form, dirField, t('git_set_auto_nodir')); return; }
      var body = {};
      if (d.dir !== r.deployDir) { body.deploy_dir = d.dir; }
      if (want !== r.auto && !(d.dir === '' && !r.auto)) { body.auto_deploy = want; }
      if (!Object.keys(body).length) { M.fieldError(form, dirField, t('git_set_nothing')); return; }
      UI.setBusy(b, true);
      FP.call('patch', 'gitRepo', body, {name: G.account, repo: r.name}).then(function (res) {
        var s = clean(res);
        UI.setBusy(b, false);
        if (!s) { M.fieldError(form, null, t('api_failed')); return; }
        G.state = s;
        G.open = '';
        closeMore(r.name);
        syncList();
        M.say(G.page.querySelector('.fp-git-list'), t('git_set_saved', {name: r.name}));
        focusAct(r.name, 'settings');
      }, function (err) {
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return form;
  }
  function closeMore(name) {
    var n = node(name);
    if (n) { n.querySelector('.fp-git-more').textContent = ''; }
  }

  /* ---- what runs on the server in the background: asked again until it ends ---- */
  function here() { return Boolean(G.page && G.page.isConnected); }
  function schedule() {
    window.clearTimeout(G.timer);
    G.timer = 0;
    if (here() && G.state && anyBusy()) { G.timer = window.setTimeout(refresh, EVERY); }
  }
  function ended(before, after) {
    var list = G.page.querySelector('.fp-git-list');
    after.repos.forEach(function (r) {
      var was = before.repos.filter(function (x) { return x.name === r.name; })[0];
      if (!was || !BUSY[was.status] || BUSY[r.status]) { return; }
      var key = null;
      if (was.status === 'cloning') { key = r.status === 'ready' ? 'git_a_cloned' : 'git_a_clone_failed'; }
      if (was.status === 'updating') { key = r.problem ? 'git_a_update_failed' : 'git_a_updated'; }
      if (was.status === 'deploying') { key = r.deployProblem ? 'git_a_deploy_failed' : 'git_a_deployed'; }
      if (key) { M.say(list, t(key, {name: r.name, note: r.note})); }
    });
  }
  function refresh() {
    var page = G.page;
    G.timer = 0;
    if (!here()) { return; }
    FP.call('get', 'git', undefined, G.account).then(function (r) {
      if (G.page !== page || !here()) { return; }
      var s = clean(r);
      if (!s) { return; }
      var before = G.state;
      G.state = s;
      syncList();
      ended(before, s);
      schedule();
    }, function () {
      if (G.page !== page || !here()) { return; }
      UI.showError(G.page.querySelector('.fp-git-list'), t('git_refresh_failed'));
    });
  }

  /* ---- clicks ---- */
  function change(name, b, path, verb, doneKey) {
    var list = G.page.querySelector('.fp-git-list');
    UI.showError(list, '');
    M.say(list, '');
    UI.setBusy(b, true);
    FP.call(verb, path, undefined, {name: G.account, repo: name}).then(function (r) {
      var s = clean(r);
      if (!s) { UI.setBusy(b, false); UI.showError(list, t('api_failed')); return; }
      G.state = s;
      syncList();
      M.say(list, t(doneKey, {name: name}));
      schedule();
      focusHead(name);
    }, function (err) {
      UI.setBusy(b, false);
      UI.showError(list, name + ': ' + err.message);
    });
  }
  document.addEventListener('click', function (e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !G.page || !G.page.contains(b)) { return; }
    var a = b.getAttribute('data-fp-act');
    var n = b.closest('[data-fp-repo]');
    var name = n ? n.getAttribute('data-fp-repo') : '';
    var list = G.page.querySelector('.fp-git-list');
    if (a === 'update') {
      change(name, b, 'gitUpdate', 'post', 'git_started_update');
    } else if (a === 'deploy') {
      change(name, b, 'gitDeploy', 'post', 'git_started_deploy');
    } else if (a === 'settings') {
      var r = find(name);
      if (G.open === name) {
        G.open = '';
        closeMore(name);
        redraw(name);
        focusAct(name, 'settings');
      } else if (r) {
        if (G.open) { var was = G.open; G.open = ''; closeMore(was); redraw(was); }
        G.open = name;
        redraw(name);
        var more = n.querySelector('.fp-git-more');
        more.textContent = '';
        more.appendChild(settingsForm(r));
        more.querySelector('[name="deploy_dir"]').focus();
      }
    } else if (a === 'settings-close') {
      G.open = '';
      closeMore(name);
      redraw(name);
      focusAct(name, 'settings');
    } else if (a === 'remove') {
      G.ask = name;
      redraw(name);
      n.querySelector('[data-fp-act="remove-no"]').focus();
    } else if (a === 'remove-no') {
      G.ask = '';
      redraw(name);
      focusAct(name, 'remove');
    } else if (a === 'remove-yes') {
      var files = n.querySelector('[name="files"]').checked;
      UI.showError(list, '');
      UI.setBusy(b, true);
      FP.call('del', files ? 'gitRepoFiles' : 'gitRepo', undefined, {name: G.account, repo: name}).then(function (res) {
        var s = clean(res);
        if (!s) { G.ask = ''; redraw(name); UI.showError(list, t('api_failed')); return; }
        G.state = s;
        G.ask = '';
        if (G.open === name) { G.open = ''; }
        syncList();
        M.say(list, t('git_a_removed', {name: name}));
        G.page.querySelector('#fp-git-list-h').focus();
      }, function (err) {
        G.ask = '';
        redraw(name);
        UI.showError(list, name + ': ' + err.message);
        focusAct(name, 'remove');
      });
    }
  });

  FP.view('tool:git_repos', function () {
    window.clearTimeout(G.timer);
    G.page = null;
    var body = M.frame('git_repos', 'fp-git');
    if (!body) { return; }
    G.page = body;
    G.account = FP.account();
    G.open = '';
    G.ask = '';
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'git', undefined, G.account).then(function (r) {
      if (G.page !== body) { return; }
      var s = clean(r);
      body.textContent = '';
      if (!s) { body.appendChild(FP.empty(FP.tools.git_repos.label, t('api_failed'))); return; }
      G.state = s;
      render();
      schedule();
    }, function (err) {
      if (G.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(FP.tools.git_repos.label, err.message));
    });
  });
})();

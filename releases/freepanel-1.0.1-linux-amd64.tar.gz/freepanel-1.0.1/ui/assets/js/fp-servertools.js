/* freePanel server tool pages, in the admin panel (docs/api.md, "Apache status", "Server"): Web server status (#/tool/apache_status)
   shows what the web server is doing now, read from the system; Password rules (#/tool/password_rules) sets what a password must be
   when one is chosen; Shell limits (#/tool/shell_limits) sets how many processes, open files and minutes of processor time a
   hosting account's shell session may use. Nothing changes until the admin saves. What the server sends is cleaned to the shapes
   drawn here and shown as text. Page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function num(v) { return typeof v === 'number' && isFinite(v) ? v : 0; }
  function arr(v) { return Array.isArray(v) ? v : []; }
  function count(n) { return Math.round(n).toLocaleString('en'); }
  function frame(id, desc, cls) {
    var tool = FP.tools[id];
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return null; }
    var g = FP.group(tool.group);
    return FP.frame({title: tool.label, desc: t(desc), cls: 'fp-mail fp-stl ' + cls,
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
  }
  function failedPage(page, id, err) {
    page.textContent = '';
    page.appendChild(FP.empty(FP.tools[id].label, err.message));
  }
  function warn(text, attr) {
    var b = el('div', {class: 'sig-banner sig-banner--warn', role: 'note'}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: text})]);
    if (attr) { b.setAttribute(attr, ''); }
    return b;
  }
  function size(bytes) {
    if (bytes >= 1073741824) { return (bytes / 1073741824).toFixed(1) + ' GiB'; }
    return Math.round(bytes / 1048576).toLocaleString('en') + ' MiB';
  }
  function span(seconds) {
    var s = Math.max(0, Math.round(seconds));
    var d = Math.floor(s / 86400);
    var h = Math.floor((s % 86400) / 3600);
    var m = Math.floor((s % 3600) / 60);
    if (d) { return t('stl_span_dh', {d: d, h: h}); }
    if (h) { return t('stl_span_hm', {h: h, m: m}); }
    return t('stl_span_m', {m: m});
  }
  function fact(key, label, node) {
    return el('div', {'data-fp-fact': key}, [el('dt', {text: label}), el('dd', null, [node])]);
  }

  /* ================= Web server status ================= */
  var AS = null;
  function cleanPort(p) {
    p = p && typeof p === 'object' ? p : {};
    return {port: Math.round(num(p.port)), established: Math.round(Math.max(0, num(p.established))), waiting: Math.round(Math.max(0, num(p.waiting))), other: Math.round(Math.max(0, num(p.other)))};
  }
  function cleanStatus(r) {
    r = r && typeof r === 'object' ? r : {};
    return {installed: r.installed === true, running: r.running === true, unit: str(r.unit, 64), state: str(r.state, 80), version: str(r.version, 120), mpm: str(r.mpm, 32),
      uptime: Math.max(0, num(r.uptime_seconds)), restarts: Math.round(Math.max(0, num(r.restarts))), workers: Math.round(Math.max(0, num(r.workers))), threads: Math.round(Math.max(0, num(r.threads))),
      memory: Math.max(0, num(r.memory_bytes)), cpu: Math.max(0, num(r.cpu_seconds)), maxWorkers: Math.round(Math.max(0, num(r.max_request_workers))),
      connections: cleanPort(r.connections), ports: arr(r.ports).slice(0, 32).map(cleanPort), note: str(r.note, 400)};
  }
  function asDraw() {
    var s = AS.status;
    var parts = [M.errorLine(), M.statusLine()];
    if (!s.installed) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('aps_not_installed')}));
    } else {
      var pill = el('span', {class: 'sig-pill' + (s.running ? ' sig-pill--ok' : ''), 'data-fp-state': s.running ? 'running' : 'stopped', text: t(s.running ? 'aps_running' : 'aps_stopped')});
      parts.push(el('p', {class: 'fp-wc-now'}, [pill, ' ', el('span', {class: 'fp-muted sig-mono', text: s.state || s.unit})]));
      if (s.note) { parts.push(warn(s.note, 'data-fp-note')); }
      if (s.running) {
        var facts = [fact('version', t('aps_version'), el('span', {class: 'sig-mono', text: s.version || '—'})), fact('mpm', t('aps_mpm'), el('span', {text: s.mpm || '—'})),
          fact('uptime', t('aps_uptime'), el('span', {text: span(s.uptime)})), fact('restarts', t('aps_restarts'), el('span', {text: count(s.restarts)})),
          fact('workers', t('aps_workers'), el('span', {text: t('aps_workers_of', {workers: count(s.workers), threads: count(s.threads)})})),
          fact('limit', t('aps_limit'), el('span', {text: s.maxWorkers ? count(s.maxWorkers) : '—'})),
          fact('memory', t('aps_memory'), el('span', {text: size(s.memory)})), fact('cpu', t('aps_cpu'), el('span', {text: t('aps_cpu_value', {seconds: count(s.cpu)})})),
          fact('connections', t('aps_connections'), el('span', {text: t('aps_conn_value', {open: count(s.connections.established), waiting: count(s.connections.waiting), other: count(s.connections.other)})}))];
        parts.push(el('dl', {class: 'fp-stl-facts'}, facts));
      }
    }
    var refresh = el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'refresh', text: t('aps_refresh')})]);
    parts.push(refresh);
    var cards = [M.card('fp-aps-h', t('aps_title'), parts, 'fp-aps')];
    if (s.running && s.ports.length) {
      cards.push(M.card('fp-aps-ports-h', t('aps_ports_title'), [el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-aps-ports-h'}, [
        el('table', {class: 'sig-table'}, [el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('aps_col_port')}), el('th', {scope: 'col', class: 'fp-num', text: t('aps_col_open')}),
          el('th', {scope: 'col', class: 'fp-num', text: t('aps_col_waiting')}), el('th', {scope: 'col', class: 'fp-num', text: t('aps_col_other')})])]),
        el('tbody', null, s.ports.map(function (p) {
          return el('tr', {'data-fp-port': String(p.port)}, [el('th', {scope: 'row', class: 'sig-mono', text: String(p.port)}), el('td', {class: 'fp-num', text: count(p.established)}),
            el('td', {class: 'fp-num', text: count(p.waiting)}), el('td', {class: 'fp-num', text: count(p.other)})]);
        }))])]), el('p', {class: 'fp-muted fp-wc-note', text: t('aps_ports_note')})], 'fp-aps-ports'));
    }
    AS.page.textContent = '';
    cards.forEach(function (c) { AS.page.appendChild(c); });
  }
  function asClick(e) {
    var b = e.target.closest ? e.target.closest('[data-fp-act="refresh"]') : null;
    if (!b || !AS || !AS.page.contains(b)) { return; }
    var mine = AS;
    UI.setBusy(b, true);
    FP.call('get', 'apacheStatus').then(function (r) {
      if (AS !== mine) { return; }
      mine.status = cleanStatus(r);
      asDraw();
      M.say(mine.page, t('aps_updated'));
      mine.page.querySelector('[data-fp-act="refresh"]').focus();
    }, function (err) {
      UI.setBusy(b, false);
      if (AS === mine) { UI.showError(mine.page.querySelector('.fp-aps'), err.message); }
    });
  }
  FP.view('tool:apache_status', function () {
    AS = null;
    var page = frame('apache_status', 'aps_desc', 'fp-aps-page');
    if (!page) { return; }
    var mine = AS = {page: page, status: null};
    page.addEventListener('click', asClick);
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'apacheStatus').then(function (r) {
      if (AS !== mine) { return; }
      mine.status = cleanStatus(r);
      asDraw();
    }, function (err) { if (AS === mine) { failedPage(page, 'apache_status', err); } });
  });

  /* ================= Password rules ================= */
  var PW = null;
  var PW_FLAGS = ['require_mixed_case', 'require_digit', 'require_symbol', 'forbid_username', 'forbid_common'];
  function cleanRules(r) {
    r = r && typeof r === 'object' ? r : {};
    var rules = r.rules && typeof r.rules === 'object' ? r.rules : {};
    var out = {min: Math.round(num(rules.min_length)) || 12, floor: Math.round(num(r.min_length_floor)) || 12, ceiling: Math.round(num(r.min_length_ceiling)) || 128,
      flags: {}, said: arr(r.requirements).filter(function (x) { return typeof x === 'string'; }).slice(0, 12).map(function (x) { return x.slice(0, 200); })};
    PW_FLAGS.forEach(function (k) { out.flags[k] = rules[k] === true; });
    return out;
  }
  function pwDraw() {
    var d = PW.data;
    var len = el('input', {class: 'sig-input', id: 'fp-spw-min', name: 'min_length', type: 'number', inputmode: 'numeric', min: String(d.floor), max: String(d.ceiling), step: '1', value: String(d.min)});
    var boxes = PW_FLAGS.map(function (k) {
      var id = 'fp-spw-' + k.replace(/_/g, '-');
      return el('div', {class: 'sig-field'}, [el('label', {class: 'fp-check', for: id}, [el('input', {type: 'checkbox', id: id, name: k, checked: d.flags[k] ? true : null,
        'aria-describedby': id + '-hint'}), el('span', {text: t('spw_' + k)})]), el('span', {class: 'sig-hint', id: id + '-hint', text: t('spw_' + k + '_hint')})]);
    });
    var form = el('form', {class: 'fp-form fp-stl-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-spw-min', t('spw_min'), len, t('spw_min_hint', {floor: d.floor, ceiling: d.ceiling}))].concat(boxes,
      [el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('spw_save')})])]));
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var raw = len.value.trim();
      var n = /^[0-9]{1,4}$/.test(raw) ? parseInt(raw, 10) : 0;
      if (n < d.floor || n > d.ceiling) { M.fieldError(form, len, t('spw_min_bad', {floor: d.floor, ceiling: d.ceiling})); return; }
      var body = {min_length: n};
      PW_FLAGS.forEach(function (k) { body[k] = form.querySelector('input[name="' + k + '"]').checked; });
      var mine = PW;
      UI.setBusy(b, true);
      FP.call('put', 'passwordRules', body).then(function (r) {
        if (PW !== mine) { return; }
        mine.data = cleanRules(r);
        pwDraw();
        M.say(mine.page.querySelector('.fp-spw'), t('spw_saved'));
        mine.page.querySelector('#fp-spw-h').focus();
      }, function (err) {
        UI.setBusy(b, false);
        if (PW === mine) { M.failed(form, err); }
      });
    });
    var now = el('ul', {class: 'fp-stl-list', 'data-fp-said': ''}, d.said.map(function (x) { return el('li', {text: x}); }));
    PW.page.textContent = '';
    PW.page.appendChild(M.card('fp-spw-h', t('spw_title'), [el('p', {class: 'fp-muted', text: t('spw_intro')}), form], 'fp-spw'));
    PW.page.appendChild(M.card('fp-spw-now-h', t('spw_now_title'), [el('p', {class: 'fp-muted', text: t('spw_now_intro')}), now], 'fp-spw-now'));
  }
  FP.view('tool:password_rules', function () {
    PW = null;
    var page = frame('password_rules', 'spw_desc', 'fp-spw-page');
    if (!page) { return; }
    var mine = PW = {page: page, data: null};
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'passwordRules').then(function (r) {
      if (PW !== mine) { return; }
      mine.data = cleanRules(r);
      pwDraw();
    }, function (err) { if (PW === mine) { failedPage(page, 'password_rules', err); } });
  });

  /* ================= Shell limits ================= */
  var SL = null;
  var SL_KEYS = ['processes', 'open_files', 'cpu_minutes'];
  function cleanLimits(r) {
    r = r && typeof r === 'object' ? r : {};
    var b = r.bounds && typeof r.bounds === 'object' ? r.bounds : {};
    var out = {accounts: Math.round(Math.max(0, num(r.accounts))), pam: r.pam_limits === true, pending: r.pending === true, values: {}, bounds: {}};
    SL_KEYS.forEach(function (k) {
      out.values[k] = Math.round(Math.max(0, num(r[k])));
      var pair = arr(b[k]);
      out.bounds[k] = [Math.round(Math.max(0, num(pair[0]))), Math.round(Math.max(0, num(pair[1])))];
    });
    return out;
  }
  function slDraw() {
    var d = SL.data;
    var inputs = SL_KEYS.map(function (k) {
      var id = 'fp-sls-' + k.replace(/_/g, '-');
      var lo = d.bounds[k][0];
      var hi = d.bounds[k][1];
      var inp = el('input', {class: 'sig-input', id: id, name: k, type: 'number', inputmode: 'numeric', min: '0', max: String(hi), step: '1', value: String(d.values[k])});
      return M.field(id, t('sls_' + k), inp, t('sls_' + k + '_hint', {min: count(lo), max: count(hi)}));
    });
    var parts = [M.errorLine(), M.statusLine()];
    if (!d.pam) { parts.push(warn(t('sls_no_pam'), 'data-fp-nopam')); }
    if (d.pending) { parts.push(warn(t('sls_pending'), 'data-fp-pending')); }
    parts.push(el('p', {class: 'fp-muted', 'data-fp-accounts': '', text: t('sls_accounts', {count: d.accounts})}));
    var form = el('form', {class: 'fp-form fp-stl-form', novalidate: ''}, [M.errorLine(), M.statusLine()].concat(inputs,
      [el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('sls_save')})])]));
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var body = {};
      for (var i = 0; i < SL_KEYS.length; i++) {
        var k = SL_KEYS[i];
        var input = form.querySelector('input[name="' + k + '"]');
        var raw = input.value.trim();
        var n = /^[0-9]{1,9}$/.test(raw) ? parseInt(raw, 10) : -1;
        var lo = d.bounds[k][0];
        var hi = d.bounds[k][1];
        if (n < 0 || (n !== 0 && (n < lo || n > hi))) { M.fieldError(form, input, t('sls_bad', {label: t('sls_' + k), min: count(lo), max: count(hi)})); return; }
        body[k] = n;
      }
      var mine = SL;
      UI.setBusy(b, true);
      FP.call('put', 'shellLimits', body).then(function (r) {
        if (SL !== mine) { return; }
        mine.data = cleanLimits(r);
        slDraw();
        M.say(mine.page.querySelector('.fp-sls-form'), t(mine.data.pending ? 'sls_saved_pending' : 'sls_saved'));
        mine.page.querySelector('#fp-sls-h').focus();
      }, function (err) {
        UI.setBusy(b, false);
        if (SL === mine) { M.failed(form, err); }
      });
    });
    var head = parts.slice(2);
    SL.page.textContent = '';
    SL.page.appendChild(M.card('fp-sls-h', t('sls_title'), [el('p', {class: 'fp-muted', text: t('sls_intro')})].concat(head, [form]), 'fp-sls-form'));
  }
  FP.view('tool:shell_limits', function () {
    SL = null;
    var page = frame('shell_limits', 'sls_desc', 'fp-sls-page');
    if (!page) { return; }
    var mine = SL = {page: page, data: null};
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'shellLimits').then(function (r) {
      if (SL !== mine) { return; }
      mine.data = cleanLimits(r);
      slDraw();
    }, function (err) { if (SL === mine) { failedPage(page, 'shell_limits', err); } });
  });
})();

/* freePanel hosting accounts in the admin panel (docs/api.md, "Accounts"): #/tool/account_new makes an account, and
   #/tool/account_list lists them with what can be done to each in its row: change the package, contact email, owner
   or password, suspend or unsuspend, and remove (the files are moved aside, never deleted). The account_edit,
   account_suspend, account_remove and account_password tools open the same list. An admin sees every account; a
   reseller sees its own and cannot set owners, and can make and download a copy of one (fp-download.js; an admin does that
   on the Back up and restore page). An admin who has the Spam settings page (where the server's own limit is set) also sees a Mail limit button in each row:
   how many recipients that account's mail may name in an hour (follow the server's limit, its own, or none). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;

  var USER_RE = /^[a-z][a-z0-9]{0,15}$/;
  var DOMAIN_RE = /^(?=.{4,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/;
  var EMAIL_RE = /^[^\s@,;"<>]+@[^\s@,;"<>]+\.[^\s@,;"<>]+$/;
  var NAME_RE = /^[A-Za-z0-9][A-Za-z0-9_. -]{0,63}$/;   /* package names, as internal/validate allows them */
  var LIST_TOOLS = ['account_list', 'account_edit', 'account_suspend', 'account_remove', 'account_password'];

  function str(v) { return typeof v === 'string' ? v : ''; }
  function isAdmin() { return FP.session.user.role === 'admin'; }
  /* only the server's administrator sets an account's mail limit, on a server that has the Spam settings page, where the server's own limit is set */
  function limitAllowed() { return isAdmin() && Boolean(FP.tools.spam_settings); }
  function cleanAccount(a) {
    if (!a || !USER_RE.test(str(a.username))) { return null; }
    return {username: a.username, domain: DOMAIN_RE.test(str(a.domain)) ? a.domain : '', owner: USER_RE.test(str(a.owner)) ? a.owner : '',
      package: NAME_RE.test(str(a.package)) ? a.package : '', email: str(a.contact_email).slice(0, 254),
      status: a.status === 'suspended' ? 'suspended' : (a.status === 'creating' ? 'creating' : 'active'),
      reason: str(a.suspend_reason).slice(0, 200), created: str(a.created_at)};
  }
  function day(iso) {
    var d = iso ? new Date(iso) : null;
    if (!d || isNaN(d.getTime())) { return ''; }
    return d.toLocaleDateString(undefined, {year: 'numeric', month: 'short', day: 'numeric'});
  }

  function errorLine() { return el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': ''}); }
  function statusLine() { return el('p', {class: 'fp-ok-line', role: 'status', 'data-fp-status': ''}); }
  function say(scope, text) {
    var s = scope && scope.querySelector('[data-fp-status]');
    if (s) { s.textContent = text || ''; }
  }
  function field(id, label, input, hint) {
    if (hint) { input.setAttribute('aria-describedby', id + '-hint'); }
    return el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: id, text: label}), input,
      hint ? el('span', {class: 'sig-hint', id: id + '-hint', text: hint}) : null]);
  }
  function select(id, name, options, value) {
    return el('select', {class: 'sig-select', id: id, name: name}, options.map(function (o) {
      var opt = el('option', {value: o[0], text: o[1]});
      if (o[0] === value) { opt.selected = true; }
      return opt;
    }));
  }
  function passwordFields(id, optional) {
    return [field(id, optional ? t('acct_new_password') : t('label_password'), el('div', {class: 'fp-reveal-wrap'}, [
      el('input', {class: 'sig-input', id: id, name: 'password', type: 'password', autocomplete: 'new-password', maxlength: '1024'}),
      el('button', {class: 'sig-ghost fp-reveal', type: 'button', 'data-overlap-ok': '', 'data-fp-reveal': id + ',' + id + '-again',
        'aria-pressed': 'false', 'aria-label': 'Show password'}, [UI.icon(FP.ui, 'ui_eye')])]),
    optional ? t('acct_password_keep') : t('acct_password_hint')),
    field(id + '-again', t('acct_password_again'), el('input', {class: 'sig-input', id: id + '-again', name: 'again', type: 'password',
      autocomplete: 'new-password', maxlength: '1024'})),
    el('div', {class: 'fp-acct-gen'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'generate',
      'data-fp-for': id, text: t('acct_generate')})])];
  }
  /* 20 characters any login form takes as they are */
  var GEN = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789-_.+=';
  function generate() {
    var out = '';
    var buf = new Uint8Array(1);
    while (out.length < 20) {
      window.crypto.getRandomValues(buf);
      if (buf[0] < 256 - (256 % GEN.length)) { out += GEN.charAt(buf[0] % GEN.length); }
    }
    return out;
  }
  function fillGenerated(b) {
    var form = b.closest('form');
    var id = b.getAttribute('data-fp-for');
    var pw = generate();
    var p = form.querySelector('#' + id);
    var again = form.querySelector('#' + id + '-again');
    p.value = pw;
    again.value = pw;
    var eye = form.querySelector('[data-fp-reveal]');
    if (eye && eye.getAttribute('aria-pressed') !== 'true') { eye.click(); }
    UI.announce(t('acct_generated'));
    p.focus();
    p.select();
  }
  function fieldError(form, f, message) {
    UI.showError(form, message);
    if (f) {
      f.setAttribute('aria-invalid', 'true');
      f.focus({preventScroll: true});
    }
    var line = form.querySelector('[data-fp-error]');
    if (line && line.scrollIntoView) { line.scrollIntoView({block: 'nearest'}); }
  }
  function failed(form, err) {
    var f = err && err.field ? UI.fieldNamed(form, err.field) : null;
    var label = f ? form.querySelector('label[for="' + f.id + '"]') : null;
    fieldError(form, f, (label ? label.textContent + ': ' : '') + (err ? err.message : t('api_failed')));
  }
  function start(form) {
    var b = form.querySelector('.fp-submit');
    if (b.disabled) { return null; }
    UI.showError(form, '');
    say(form, '');
    var bad = form.querySelectorAll('[aria-invalid]');
    for (var i = 0; i < bad.length; i++) { bad[i].removeAttribute('aria-invalid'); }
    return b;
  }
  function checkPassword(form, optional) {
    var p = form.querySelector('[name="password"]');
    var a = form.querySelector('[name="again"]');
    if (optional && !p.value && !a.value) { return ''; }
    if (p.value.length < 12) { fieldError(form, p, t('acct_short_password')); return null; }
    if (p.value !== a.value) { fieldError(form, a, t('acct_password_mismatch')); return null; }
    return p.value;
  }
  function packagesOf(r) {
    return (r && Array.isArray(r.packages) ? r.packages : []).map(function (p) { return {name: str(p && p.name), owner: str(p && p.owner)}; })
      .filter(function (p) { return NAME_RE.test(p.name); });
  }
  function resellersOf(r) {
    return (r && Array.isArray(r.resellers) ? r.resellers : []).map(function (x) { return str(x && x.username); }).filter(function (n) { return USER_RE.test(n); });
  }
  /* the packages, and for an admin the resellers who can own accounts; a failed list leaves that choice out */
  function choices() {
    var me = FP.session.user.username;
    return Promise.all([FP.call('get', 'packages').then(packagesOf),
      isAdmin() ? FP.call('get', 'resellers').then(resellersOf, function () { return []; }) : Promise.resolve([])]).then(function (r) {
      return {packages: r[0], resellers: r[1], owners: [[me, t('acct_owner_you', {name: me})]].concat(r[1].map(function (n) { return [n, n]; }))};
    });
  }
  /* the packages an account of owner can be on: the owner's own or an admin's (docs/api.md, PATCH /accounts). A reseller
     lists only its own packages, and an admin's are the ones no reseller owns. */
  function usableFor(c, owner) {
    return c.packages.filter(function (p) { return !isAdmin() || p.owner === owner || c.resellers.indexOf(p.owner) < 0; })
      .map(function (p) { return p.name; });
  }
  function pairs(names) { return names.map(function (n) { return [n, n]; }); }
  /* refills a package list, keeping the choice when it is still offered */
  function refill(sel, options, keep) {
    sel.textContent = '';
    var value = options.some(function (o) { return o[0] === keep; }) ? keep : options[0][0];
    options.forEach(function (o) {
      var opt = el('option', {value: o[0], text: o[1]});
      if (o[0] === value) { opt.selected = true; }
      sel.appendChild(opt);
    });
  }

  /* ---- New account ---- */
  /* a username from the domain, the way hosting panels suggest one: its first letters and digits, starting with a letter */
  function suggest(domain) {
    var s = domain.split('.')[0].replace(/[^a-z0-9]/g, '').replace(/^[0-9]+/, '');
    return s.slice(0, 8);
  }
  function newAccount(body, c, done) {
    var me = FP.session.user.username;
    var domain = el('input', {class: 'sig-input', id: 'fp-acct-domain', name: 'domain', type: 'text', autocomplete: 'off', spellcheck: 'false',
      autocapitalize: 'none', maxlength: '253'});
    var user = el('input', {class: 'sig-input sig-mono', id: 'fp-acct-user', name: 'username', type: 'text', autocomplete: 'off', spellcheck: 'false',
      autocapitalize: 'none', maxlength: '16'});
    var email = el('input', {class: 'sig-input', id: 'fp-acct-email', name: 'contact_email', type: 'email', autocomplete: 'off', maxlength: '254'});
    var parts = [errorLine(), statusLine(),
      field('fp-acct-domain', t('acct_domain'), domain, t('acct_domain_hint')),
      field('fp-acct-user', t('acct_username'), user, t('acct_username_hint'))].concat(passwordFields('fp-acct-pw', false), [
      field('fp-acct-email', t('acct_email'), email, t('acct_email_hint')),
      c.packages.length ? field('fp-acct-package', t('acct_package'), select('fp-acct-package', 'package',
        [['', t('acct_pick')]].concat(pairs(usableFor(c, me))), ''), isAdmin() ? t('acct_package_hint_owner') : '')
        : el('p', {class: 'fp-muted', 'data-fp-no-packages': '', text: t('acct_no_packages')})]);
    if (isAdmin()) {
      var ownerSel = select('fp-acct-owner', 'owner', c.owners, me);
      parts.push(field('fp-acct-owner', t('acct_owner'), ownerSel, t('acct_owner_hint')));
      ownerSel.addEventListener('change', function () {
        var pkgSel = form.querySelector('[name="package"]');
        if (!pkgSel) { return; }
        refill(pkgSel, [['', t('acct_pick')]].concat(pairs(usableFor(c, ownerSel.value))), pkgSel.value);
        UI.announce(t('acct_packages_follow'));
      });
      parts.push(el('label', {class: 'fp-check'}, [el('input', {type: 'checkbox', name: 'allow_shared_domain', id: 'fp-acct-shared'}),
        el('span', {text: t('acct_shared_domain')})]));
    }
    parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('acct_create'),
      disabled: c.packages.length ? null : true})]));
    var form = el('form', {class: 'fp-form fp-acct-form', novalidate: ''}, parts);
    var userTouched = false;
    user.addEventListener('input', function () { userTouched = Boolean(user.value); });
    domain.addEventListener('input', function () {
      if (!userTouched) { user.value = suggest(domain.value.trim().toLowerCase()); }
    });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = start(form);
      if (!b) { return; }
      var d = domain.value.trim().toLowerCase().replace(/\.$/, '');
      var u = user.value.trim().toLowerCase();
      if (!DOMAIN_RE.test(d)) { fieldError(form, domain, t('acct_bad_domain')); return; }
      if (!USER_RE.test(u)) { fieldError(form, user, t('acct_bad_username')); return; }
      var pw = checkPassword(form, false);
      if (!pw) { return; }
      var em = email.value.trim();
      if (em && !EMAIL_RE.test(em)) { fieldError(form, email, t('acct_bad_email')); return; }
      var pkg = form.querySelector('[name="package"]');
      if (!pkg.value) { fieldError(form, pkg, t('acct_pick_package')); return; }
      var payload = {username: u, domain: d, password: pw, package: pkg.value};
      if (em) { payload.contact_email = em; }
      if (isAdmin()) {
        var owner = form.querySelector('[name="owner"]').value;
        if (owner && owner !== me) { payload.owner = owner; }
        if (form.querySelector('[name="allow_shared_domain"]').checked) { payload.allow_shared_domain = true; }
      }
      UI.setBusy(b, true);
      say(form, t('acct_creating', {name: u}));
      FP.call('post', 'accounts', payload).then(function (r) {
        var a = cleanAccount(r) || {username: u, domain: d, package: pkg.value};
        done(a);
      }, function (err) {
        UI.setBusy(b, false);
        say(form, '');
        failed(form, err);
      });
    });
    body.appendChild(el('section', {class: 'sig-card'}, [el('div', {class: 'sig-card-body'}, [form])]));
  }
  function created(body, a, again) {
    body.textContent = '';
    var list = FP.tools.account_list;
    var card = el('section', {class: 'sig-card fp-acct-done', 'aria-labelledby': 'fp-acct-done-h'}, [el('div', {class: 'sig-card-body'}, [
      el('h2', {class: 'fp-h2', id: 'fp-acct-done-h', tabindex: '-1', text: t('acct_created', {name: a.username})}),
      el('dl', {class: 'fp-acct-facts'}, [el('dt', {text: t('acct_domain')}), el('dd', {text: a.domain}),
        el('dt', {text: t('acct_username')}), el('dd', {class: 'sig-mono', text: a.username}),
        el('dt', {text: t('acct_package')}), el('dd', {text: a.package})]),
      el('div', {class: 'fp-actions'}, [
        el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'another', text: t('acct_another')}),
        list ? el('a', {class: 'sig-btn sig-btn--secondary', href: list.href, text: t('acct_to_list')}) : null])])]);
    body.appendChild(card);
    card.querySelector('[data-fp-act="another"]').addEventListener('click', again);
    card.querySelector('#fp-acct-done-h').focus();
  }

  /* ---- All accounts ---- */
  var page = null;
  var accounts = [];
  var opts = null;
  var open = null;  /* {user, what: 'change' | 'suspend' | 'download' | 'limit'} for the row whose form or card is open */
  var dl = null;    /* {user, card}: the download card of the row whose Download is open, kept across redraws */
  var lim = null;   /* {user, state: 'loading' | 'ready' | 'failed', own, applies, message}: what the open Mail limit row knows, kept across redraws */

  function statusPill(a) {
    if (a.status === 'suspended') { return el('span', {class: 'sig-pill sig-pill--warn', text: t('acct_suspended')}); }
    if (a.status === 'creating') { return el('span', {class: 'sig-pill', text: t('acct_being_made')}); }
    return el('span', {class: 'sig-pill sig-pill--ok', text: t('acct_active')});
  }
  function actions(a) {
    var n = a.username;
    return el('td', {class: 'fp-acct-acts'}, a.status === 'creating' ? [] : [
      el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'change', 'aria-expanded': String(Boolean(open && open.user === n && open.what === 'change')),
        'aria-label': t('acct_change_of', {name: n}), text: t('acct_change')}),
      a.status === 'suspended' ?
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'unsuspend', 'aria-label': t('acct_unsuspend_of', {name: n}), text: t('acct_unsuspend')}) :
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'suspend', 'aria-expanded': String(Boolean(open && open.user === n && open.what === 'suspend')),
          'aria-label': t('acct_suspend_of', {name: n}), text: t('acct_suspend')}),
      isAdmin() || !FP.backupDownload ? null :
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'download', 'aria-expanded': String(Boolean(open && open.user === n && open.what === 'download')),
          'aria-label': t('dl_open_of', {account: n}), text: t('dl_open')}),
      limitAllowed() ?
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'limit', 'aria-expanded': String(Boolean(open && open.user === n && open.what === 'limit')),
          'aria-label': t('acct_limit_of', {name: n}), text: t('acct_limit')}) : null,
      el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'remove', 'aria-label': t('acct_remove_of', {name: n}), text: t('acct_remove')})]);
  }
  function cols() { return isAdmin() ? 7 : 6; }
  function row(a) {
    return el('tr', {'data-fp-account': a.username}, [
      el('th', {scope: 'row', class: 'sig-mono', text: a.username}),
      el('td', {class: 'fp-acct-domain', text: a.domain || '–'}),
      isAdmin() ? el('td', {text: a.owner || '–'}) : null,
      el('td', {text: a.package || '–'}),
      el('td', null, [statusPill(a), a.status === 'suspended' && a.reason ? el('span', {class: 'fp-muted fp-acct-reason', text: a.reason}) : null]),
      el('td', {text: day(a.created) || '–'}),
      actions(a)]);
  }
  /* the packages the change form offers for owner: the usable ones, with the account's own kept while its owner stays,
     and a "choose" line when a new owner can't keep it */
  function changeOptions(a, owner) {
    var names = usableFor(opts, owner);
    if (names.indexOf(a.package) >= 0) { return pairs(names); }
    return owner === a.owner ? [[a.package, a.package]].concat(pairs(names)) : [['', t('acct_pick')]].concat(pairs(names));
  }
  function changeRow(a) {
    var pkgSel = opts.packages.length ? select('fp-acct-c-package', 'package', changeOptions(a, a.owner), a.package) : null;
    var parts = [errorLine(),
      el('p', {class: 'fp-muted', text: t('acct_change_for', {name: a.username})}),
      el('div', {class: 'fp-acct-pair'}, [
        pkgSel ? field('fp-acct-c-package', t('acct_package'), pkgSel, isAdmin() ? t('acct_package_hint_owner') : '') : null,
        field('fp-acct-c-email', t('acct_email'), el('input', {class: 'sig-input', id: 'fp-acct-c-email', name: 'contact_email', type: 'email',
          autocomplete: 'off', maxlength: '254', value: a.email})),
        isAdmin() ? field('fp-acct-c-owner', t('acct_owner'), select('fp-acct-c-owner', 'owner',
          opts.owners.some(function (o) { return o[0] === a.owner; }) ? opts.owners : opts.owners.concat([[a.owner, a.owner]]), a.owner)) : null])]
      .concat(passwordFields('fp-acct-c-pw', true), [el('div', {class: 'fp-actions'}, [
        el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('acct_save')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'close', text: t('cancel')})])]);
    var form = el('form', {class: 'fp-form fp-acct-inline', novalidate: ''}, parts);
    var ownerSel = form.querySelector('[name="owner"]');
    if (ownerSel && pkgSel) {
      ownerSel.addEventListener('change', function () {
        refill(pkgSel, changeOptions(a, ownerSel.value), pkgSel.value);
        UI.announce(t('acct_packages_follow'));
      });
    }
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = start(form);
      if (!b) { return; }
      var change = {};
      var pkg = form.querySelector('[name="package"]');
      if (pkg && !pkg.value) { fieldError(form, pkg, t('acct_pick_package_owner')); return; }
      if (pkg && pkg.value !== a.package) { change.package = pkg.value; }
      var em = form.querySelector('[name="contact_email"]');
      var emv = em.value.trim();
      if (emv && !EMAIL_RE.test(emv)) { fieldError(form, em, t('acct_bad_email')); return; }
      if (emv !== a.email) { change.contact_email = emv; }
      var owner = form.querySelector('[name="owner"]');
      if (owner && owner.value !== a.owner) { change.owner = owner.value; }
      var pw = checkPassword(form, true);
      if (pw === null) { return; }
      if (pw) { change.password = pw; }
      if (!Object.keys(change).length) { fieldError(form, null, t('acct_nothing_changed')); return; }
      UI.setBusy(b, true);
      FP.call('patch', 'account', change, a.username).then(function (r) {
        replace(r, a.username);
        open = null;
        draw(t(change.password && Object.keys(change).length === 1 ? 'acct_password_set' : 'acct_saved', {name: a.username}), a.username, 'change');
      }, function (err) {
        UI.setBusy(b, false);
        failed(form, err);
      });
    });
    return el('tr', {class: 'fp-acct-formrow'}, [el('td', {colspan: String(cols())}, [form])]);
  }
  function suspendRow(a) {
    var reason = el('input', {class: 'sig-input', id: 'fp-acct-reason', name: 'reason', type: 'text', maxlength: '200', autocomplete: 'off'});
    var form = el('form', {class: 'fp-form fp-acct-inline', novalidate: ''}, [errorLine(),
      el('p', {class: 'fp-muted', text: t('acct_suspend_what', {name: a.username})}),
      field('fp-acct-reason', t('acct_reason'), reason, t('acct_reason_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--danger fp-submit', type: 'submit', text: t('acct_suspend')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'close', text: t('cancel')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = start(form);
      if (!b) { return; }
      UI.setBusy(b, true);
      var r = reason.value.trim();
      FP.call('post', 'accountSuspend', r ? {reason: r} : {}, a.username).then(function (x) {
        replace(x, a.username);
        open = null;
        draw(t('acct_suspended_done', {name: a.username}), a.username, 'change');
      }, function (err) {
        UI.setBusy(b, false);
        failed(form, err);
      });
    });
    return el('tr', {class: 'fp-acct-formrow'}, [el('td', {colspan: String(cols())}, [form])]);
  }
  /* a reseller's download card for one account: the same card the admin's Back up and restore page shows, with no restore */
  function downloadRow(a) {
    if (!dl || dl.user !== a.username) {
      if (dl) { dl.card.stop(); }
      dl = {user: a.username, card: FP.backupDownload.card(a.username, {onClose: function () {
        open = null;
        draw('', a.username, 'download');
      }})};
    }
    return el('tr', {class: 'fp-acct-formrow'}, [el('td', {colspan: String(cols())}, [dl.card.node])]);
  }

  /* ---- an account's limit on outgoing mail: the recipients its mail may name in an hour (docs/api.md, "Email").
     The Mail view says what it has, {outgoing: {max_hourly_recipients (the limit that applies, 0 none), own (0 follows
     the server, -1 none)}}, and PUT .../email/limit sets its own. ---- */
  var LIMIT_MAX = 100000;
  function wholeNumber(v) { return typeof v === 'number' && isFinite(v) && Math.floor(v) === v ? v : null; }
  function limitOf(r) {
    var o = r && r.outgoing;
    var own = o ? wholeNumber(o.own) : null;
    var applies = o ? wholeNumber(o.max_hourly_recipients) : null;
    if (own === null || applies === null || applies < 0 || own < -1 || own > LIMIT_MAX) { return null; }
    return {own: own, applies: applies};
  }
  function recipients(n) { return t(n === 1 ? 'acct_limit_rcpt_1' : 'acct_limit_rcpt', {n: n.toLocaleString('en')}); }
  function limitNow(l) {
    if (l.own === -1) { return t('acct_limit_now_none'); }
    if (l.own > 0) { return t('acct_limit_now_own', {n: recipients(l.own)}); }
    return l.applies > 0 ? t('acct_limit_now_follow', {n: recipients(l.applies)}) : t('acct_limit_now_follow_none');
  }
  function limitBody(a) {
    var n = a.username;
    var parts = [el('p', {class: 'fp-muted', tabindex: '-1', 'data-fp-focus': '', text: t('acct_limit_for', {name: n})})];
    var close = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'close', text: t('cancel')});
    if (lim.state === 'loading') {
      return el('div', {class: 'fp-acct-limit'}, parts.concat([el('p', {class: 'fp-muted', role: 'status', text: t('loading')})]));
    }
    if (lim.state === 'failed') {
      return el('div', {class: 'fp-acct-limit', 'data-fp-limit-failed': ''}, parts.concat([el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': '', text: lim.message}),
        el('div', {class: 'fp-actions'}, [close])]));
    }
    var id = 'fp-acct-og';
    var current = lim.own === 0 ? 'follow' : (lim.own === -1 ? 'none' : 'own');
    var num = el('input', {class: 'sig-input fp-num-input', id: id + '-n', name: 'max_hourly_recipients', type: 'number', inputmode: 'numeric',
      min: '1', max: String(LIMIT_MAX), step: '1', autocomplete: 'off', value: lim.own > 0 ? String(lim.own) : ''});
    var numField = field(id + '-n', t('acct_limit_n'), num, t('acct_limit_n_hint', {max: LIMIT_MAX.toLocaleString('en')}));
    function choice(value, extra) {
      return el('div', {class: 'fp-acct-choice'}, [el('label', {class: 'fp-check', for: id + '-' + value}, [
        el('input', {type: 'radio', id: id + '-' + value, name: 'limit', value: value, checked: value === current ? true : null, 'aria-describedby': id + '-' + value + '-hint'}),
        el('span', {text: t('acct_limit_' + value)})]),
      el('span', {class: 'sig-hint', id: id + '-' + value + '-hint', text: t('acct_limit_' + value + '_hint', {page: FP.tools.spam_settings.label})}), extra]);
    }
    var form = el('form', {class: 'fp-form fp-acct-inline', novalidate: ''}, [errorLine(),
      el('p', {'data-fp-limit-now': '', text: limitNow(lim)}),
      el('fieldset', {class: 'fp-acct-kinds'}, [el('legend', {class: 'sig-label', text: t('acct_limit_which')}),
        choice('follow'), choice('own', numField), choice('none')]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('acct_save')}), close])]);
    function sync() { numField.hidden = form.querySelector('[name="limit"]:checked').value !== 'own'; }
    form.addEventListener('change', sync);
    sync();
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = start(form);
      if (!b) { return; }
      var pick = form.querySelector('[name="limit"]:checked').value;
      var want = pick === 'follow' ? 0 : -1;
      if (pick === 'own') {
        var raw = num.value.trim();
        want = /^[0-9]{1,7}$/.test(raw) ? parseInt(raw, 10) : 0;
        if (want < 1 || want > LIMIT_MAX) { fieldError(form, num, t('acct_limit_bad', {max: LIMIT_MAX.toLocaleString('en')})); return; }
      }
      if (want === lim.own) { fieldError(form, null, t('acct_nothing_changed')); return; }
      var mine = lim;
      UI.setBusy(b, true);
      FP.call('put', 'mailLimit', {max_hourly_recipients: want}, n).then(function (r) {
        var l = limitOf(r);
        var message = t('acct_saved', {name: n}) + (l ? ' ' + limitNow(l) : '');
        if (lim !== mine) {
          say(page && page.querySelector('.fp-acct-list'), message);
          return;
        }
        open = null;
        draw(message, n, 'limit');
      }, function (err) {
        UI.setBusy(b, false);
        if (lim === mine) {
          failed(form, err);
        } else if (page && page.querySelector('.fp-acct-list')) {
          UI.showError(page.querySelector('.fp-acct-list'), err.message);
        }
      });
    });
    return el('div', {class: 'fp-acct-limit'}, parts.concat([form]));
  }
  /* the row for the account whose Mail limit is open; the Mail view is read when it opens and the row is drawn again when it comes */
  function limitRow(a) {
    if (!lim || lim.user !== a.username) {
      var mine = lim = {user: a.username, state: 'loading', own: 0, applies: 0, message: ''};
      FP.call('get', 'mail', undefined, a.username).then(function (r) {
        var l = limitOf(r);
        if (l) {
          mine.own = l.own;
          mine.applies = l.applies;
          mine.state = 'ready';
        } else {
          mine.state = 'failed';
          mine.message = t('acct_limit_unknown');
        }
      }, function (err) {
        mine.state = 'failed';
        mine.message = err.message;
      }).then(function () {
        var td = lim === mine && page ? page.querySelector('tr[data-fp-limit-row="' + a.username + '"] > td') : null;
        if (!td) { return; }
        var kept = td.contains(document.activeElement) || document.activeElement === document.body;
        td.textContent = '';
        td.appendChild(limitBody(a));
        var f = td.querySelector('input:checked') || td.querySelector('input') || td.querySelector('[data-fp-focus]');
        if (f && kept) { f.focus(); }
      });
    }
    return el('tr', {class: 'fp-acct-formrow', 'data-fp-limit-row': a.username}, [el('td', {colspan: String(cols())}, [limitBody(a)])]);
  }
  function replace(r, name) {
    var a = cleanAccount(r);
    if (!a) { return; }
    for (var i = 0; i < accounts.length; i++) { if (accounts[i].username === name) { accounts[i] = a; } }
  }

  var filterValue = '';
  function draw(message, focusUser, focusAct) {
    page.textContent = '';
    if (dl && !(open && open.what === 'download' && open.user === dl.user)) { dl.card.stop(); dl = null; }
    if (lim && !(open && open.what === 'limit' && open.user === lim.user)) { lim = null; }
    var newTool = FP.tools.account_new;
    var head = el('div', {class: 'fp-acct-top'}, [
      el('div', {class: 'sig-field fp-acct-filter'}, [el('label', {class: 'sig-label', for: 'fp-acct-filter', text: t('acct_filter')}),
        el('input', {class: 'sig-input', id: 'fp-acct-filter', type: 'search', autocomplete: 'off', spellcheck: 'false', maxlength: '253',
          'aria-describedby': 'fp-acct-count', value: filterValue})]),
      newTool ? el('a', {class: 'sig-btn sig-btn--primary', href: newTool.href, text: t('acct_new')}) : null]);
    var card = el('section', {class: 'sig-card fp-acct-list'}, [el('div', {class: 'sig-card-body'}, [head, errorLine(), statusLine(),
      el('p', {class: 'fp-muted', id: 'fp-acct-count', role: 'status', 'aria-live': 'polite'})])]);
    var inner = card.firstChild;
    page.appendChild(card);
    if (!accounts.length) {
      inner.appendChild(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('acct_none')}));
      head.querySelector('.fp-acct-filter').hidden = true;
      say(card, message);
      return;
    }
    var rows = [];
    accounts.forEach(function (a) {
      rows.push(row(a));
      if (open && open.user === a.username) { rows.push(open.what === 'change' ? changeRow(a) : (open.what === 'download' ? downloadRow(a) : (open.what === 'limit' ? limitRow(a) : suspendRow(a)))); }
    });
    var tbody = el('tbody', null, rows);
    var none = el('p', {class: 'fp-muted', 'data-fp-acct-none': '', hidden: true, text: t('acct_no_match')});
    var wrap = el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-h1'}, [
      el('table', {class: 'sig-table fp-acct-table'}, [el('thead', null, [el('tr', null, [
        el('th', {scope: 'col', text: t('acct_username')}), el('th', {scope: 'col', text: t('acct_domain')}),
        isAdmin() ? el('th', {scope: 'col', text: t('acct_owner')}) : null, el('th', {scope: 'col', text: t('acct_package')}),
        el('th', {scope: 'col', text: t('acct_status')}), el('th', {scope: 'col', text: t('acct_created_col')}),
        el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('acct_actions')})])])]), tbody])]);
    inner.appendChild(wrap);
    inner.appendChild(none);
    var filter = head.querySelector('#fp-acct-filter');
    var count = inner.querySelector('#fp-acct-count');
    function apply() {
      filterValue = filter.value;
      var q = filter.value.trim().toLowerCase();
      var shown = 0;
      Array.prototype.forEach.call(tbody.querySelectorAll('tr[data-fp-account]'), function (tr) {
        var a = accounts.filter(function (x) { return x.username === tr.getAttribute('data-fp-account'); })[0];
        var hit = !q || [a.username, a.domain, a.owner, a.package].some(function (v) { return v.indexOf(q) >= 0; });
        tr.hidden = !hit;
        var next = tr.nextElementSibling;
        if (next && next.classList.contains('fp-acct-formrow')) { next.hidden = !hit; }
        if (hit) { shown++; }
      });
      wrap.hidden = shown === 0;
      none.hidden = shown !== 0;
      count.textContent = q ? t('acct_count_filtered', {n: shown, total: accounts.length}) : t(accounts.length === 1 ? 'acct_count_1' : 'acct_count', {n: accounts.length});
    }
    filter.addEventListener('input', apply);
    filter.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && filter.value) { e.stopPropagation(); filter.value = ''; apply(); }
    });
    apply();
    say(card, message);
    if (focusUser) {
      var target = open && open.user === focusUser ? (page.querySelector('.fp-acct-formrow input:checked') || page.querySelector('.fp-acct-formrow input, .fp-acct-formrow select') ||
        page.querySelector('.fp-acct-formrow [data-fp-focus]')) :
        page.querySelector('tr[data-fp-account="' + focusUser + '"] [data-fp-act="' + focusAct + '"]');
      if (target) { target.focus(); }
    }
  }
  function confirmRemove(tr) {
    var n = tr.getAttribute('data-fp-account');
    var cell = tr.querySelector('.fp-acct-acts');
    cell.textContent = '';
    var yes = el('button', {class: 'sig-btn sig-btn--danger sig-btn--sm', type: 'button', 'data-fp-act': 'remove-yes', text: t('acct_remove')});
    var no = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'remove-no', text: t('cancel')});
    cell.appendChild(el('span', {class: 'fp-acct-confirm', id: 'fp-acct-confirm', text: t('acct_remove_ask', {name: n})}));
    cell.appendChild(yes);
    cell.appendChild(no);
    yes.setAttribute('aria-describedby', 'fp-acct-confirm');
    no.setAttribute('aria-describedby', 'fp-acct-confirm');
    /* Cancel takes focus, so a second Enter on Remove can't remove the account */
    no.focus();
  }
  function act(b, call, done) {
    var card = page.querySelector('.fp-acct-list');
    UI.showError(card, '');
    UI.setBusy(b, true);
    call.then(done, function (err) {
      UI.setBusy(b, false);
      UI.showError(card, err.message);
    });
  }

  function onClick(e) {
    var target = e.target.closest ? e.target : null;
    if (!target || !page || !page.contains(target)) { return; }
    var b = target.closest('[data-fp-act]');
    if (!b) { return; }
    var a = b.getAttribute('data-fp-act');
    var tr = b.closest('tr[data-fp-account]');
    var n = tr ? tr.getAttribute('data-fp-account') : '';
    if (a === 'generate') {
      fillGenerated(b);
    } else if (a === 'change' || a === 'suspend' || a === 'download' || a === 'limit') {
      open = open && open.user === n && open.what === a ? null : {user: n, what: a};
      draw('', n, a);
      /* the card's heading takes the focus, as on the Back up and restore page */
      if (a === 'download' && open && dl) { dl.card.node.querySelector('#fp-dl-h').focus(); }
    } else if (a === 'close') {
      var was = open;
      open = null;
      if (was) { draw('', was.user, was.what); }
    } else if (a === 'unsuspend') {
      act(b, FP.call('post', 'accountUnsuspend', {}, n), function (r) {
        replace(r, n);
        draw(t('acct_unsuspended_done', {name: n}), n, 'suspend');
      });
    } else if (a === 'remove') {
      confirmRemove(tr);
    } else if (a === 'remove-no') {
      draw('', n, 'remove');
    } else if (a === 'remove-yes') {
      act(b, FP.call('del', 'account', undefined, n), function () {
        accounts = accounts.filter(function (x) { return x.username !== n; });
        if (open && open.user === n) { open = null; }
        draw(t('acct_removed', {name: n}));
        var h = document.getElementById('fp-h1');
        if (h) { h.focus(); }
      });
    }
  }
  document.addEventListener('click', onClick);

  function listView(id) {
    var tool = FP.tools[id];
    if (!tool || FP.realm !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    open = null;
    lim = null;
    if (dl) { dl.card.stop(); dl = null; }
    filterValue = '';
    page = FP.frame({title: tool.label, desc: t(id === 'account_list' ? (isAdmin() ? 'acct_list_desc' : 'acct_list_desc_reseller') : 'acct_list_hint_' + id),
      cls: 'fp-acct', crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    var mine = page;
    Promise.all([FP.call('get', 'accounts'), choices().catch(function () { return {packages: [], resellers: [], owners: []}; })]).then(function (r) {
      if (page !== mine) { return; }
      accounts = (r[0] && Array.isArray(r[0].accounts) ? r[0].accounts : []).map(cleanAccount).filter(Boolean)
        .sort(function (x, y) { return x.username < y.username ? -1 : 1; });
      opts = r[1];
      draw('');
    }, function (err) {
      if (page !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err.message));
    });
  }
  LIST_TOOLS.forEach(function (id) { FP.view('tool:' + id, function () { listView(id); }); });

  FP.view('tool:account_new', function () {
    var tool = FP.tools.account_new;
    if (!tool || FP.realm !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('acct_new_desc'), cls: 'fp-acct',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    page = body;
    function show() {
      body.textContent = '';
      body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
      choices().then(function (c) {
        if (page !== body) { return; }
        body.textContent = '';
        newAccount(body, c, function (a) { created(body, a, show); });
      }, function (err) {
        if (page !== body) { return; }
        body.textContent = '';
        body.appendChild(FP.empty(tool.label, err.message));
      });
    }
    show();
  });
})();

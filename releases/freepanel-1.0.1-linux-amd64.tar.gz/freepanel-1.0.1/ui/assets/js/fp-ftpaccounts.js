/* freePanel FTP accounts (#/tool/ftp_accounts), the customer panel's page for the account's FTP logins (docs/api.md, "FTP"): each login is
   an address on one of the account's domains, kept to a folder of the home, with a quota of its own or none. Logins are added, changed
   (password, folder, quota) and removed here; a login can't be renamed. What the server sends is drawn as text. The page pieces come
   from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var MAX_QUOTA = 1048576;
  var DIR_RE = /^[A-Za-z0-9._-]+(\/[A-Za-z0-9._-]+)*$/;
  var LOCAL_RE = /^[a-z0-9._-]{1,32}$/;
  var V = {page: null, account: '', logins: [], domains: null, suspended: false, open: '', removing: ''};

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function num(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.floor(v) : 0; }
  function count(n) { return Math.round(n).toLocaleString('en'); }
  function clean(r) {
    if (!r || typeof r !== 'object' || !Array.isArray(r.logins)) { return null; }
    return {suspended: r.suspended === true, logins: r.logins.filter(function (l) { return l && M.isAddress(str(l.login, 300)); }).map(function (l) {
      return {login: l.login, dir: str(l.dir, 1024), quota: num(l.quota_mb)};
    }).sort(function (a, b) { return a.login < b.login ? -1 : 1; })};
  }
  function dirText(d) { return d ? '~/' + d : t('fta_home'); }
  function quotaText(q) { return q ? t('fta_quota_mb', {n: count(q)}) : t('fta_quota_none'); }
  /* a folder under the home: '' for the whole home; null with the field marked when it is not one */
  function readDir(form) {
    var f = form.querySelector('[name="dir"]');
    var v = f.value.trim().replace(/^~?\/+/, '').replace(/\/+$/, '');
    if (v === '' || v === '.') { return ''; }
    if (v.length > 1024 || !DIR_RE.test(v) || v.split('/').some(function (p) { return p === '.' || p === '..'; })) {
      M.fieldError(form, f, t('fta_dir_bad'));
      return null;
    }
    return v;
  }
  function readQuota(form) {
    var f = form.querySelector('[name="quota_mb"]');
    var v = f.value.trim();
    if (v === '') { return 0; }
    if (!/^[0-9]{1,7}$/.test(v) || Number(v) > MAX_QUOTA) { M.fieldError(form, f, t('fta_quota_bad', {max: count(MAX_QUOTA)})); return null; }
    return Number(v);
  }
  function dirField(id, value, hint) {
    return M.field(id, t('fta_dir'), el('input', {class: 'sig-input sig-mono', id: id, name: 'dir', type: 'text', autocomplete: 'off', spellcheck: 'false',
      autocapitalize: 'none', maxlength: '1024', value: value}), hint);
  }
  function quotaField(id, value) {
    return M.field(id, t('fta_quota'), el('input', {class: 'sig-input fp-mail-quota', id: id, name: 'quota_mb', type: 'number', inputmode: 'numeric',
      min: '0', max: String(MAX_QUOTA), step: '1', value: value ? String(value) : ''}), t('fta_quota_hint'));
  }
  function idOf(login) { return login.replace(/[^a-z0-9]/g, '-'); }

  function createCard() {
    var form = el('form', {class: 'fp-form fp-mail-form fp-fta-add', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.addressField('fp-fta-login', t('fta_login'), V.domains, t('fta_login_hint'))].concat(M.passwordFields('fp-fta-pw'),
      [dirField('fp-fta-dir', '', t('fta_dir_new_hint')), quotaField('fp-fta-quota', 0),
        el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('fta_add')})])]));
    var local = form.querySelector('[name="address"]');
    var dir = form.querySelector('[name="dir"]');
    /* the folder follows the name until it is typed in, as a new login gets a folder of its own in the site's */
    var dirTouched = false;
    dir.addEventListener('input', function () { dirTouched = true; });
    local.addEventListener('input', function () {
      if (dirTouched) { return; }
      var v = local.value.trim().toLowerCase().split('@')[0];
      dir.value = LOCAL_RE.test(v) ? 'public_html/' + v : '';
    });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var login = M.readAddress(form);
      if (!login || !LOCAL_RE.test(login.split('@')[0])) { M.fieldError(form, local, t('fta_login_bad')); return; }
      var pw = M.readPassword(form);
      if (!pw) { return; }
      var d = readDir(form);
      if (d === null) { return; }
      var q = readQuota(form);
      if (q === null) { return; }
      var mine = V.page;
      UI.setBusy(b, true);
      FP.call('post', 'ftpLogins', {login: login, password: pw.value, dir: d, quota_mb: q}, V.account).then(function (r) {
        if (V.page !== mine) { return; }
        take(r);
        draw();
        M.say(V.page.querySelector('.fp-fta-listbox'), t('fta_added', {login: login}));
        V.page.querySelector('#fp-fta-list-h').focus();
      }, function (err) {
        if (V.page !== mine) { return; }
        UI.setBusy(b, false);
        M.failed(form, err.field === 'login' ? {field: 'address', message: err.message} : err);
      });
    });
    return M.card('fp-fta-add-h', t('fta_add_title'), [form], 'fp-fta-add-card');
  }
  function editRow(l) {
    var id = 'fp-fta-e-' + idOf(l.login);
    var form = el('form', {class: 'fp-form fp-mail-form fp-fta-edit', novalidate: '', 'data-fp-login': l.login}, [M.errorLine(), M.statusLine()].concat(
      M.passwordFields(id + '-pw', true), [dirField(id + '-dir', l.dir, t('fta_dir_hint')), quotaField(id + '-quota', l.quota),
        el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('fta_save')}),
          el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'fta-close', text: t('cancel')})])]));
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var pw = M.readPassword(form, true);
      if (!pw) { return; }
      var d = readDir(form);
      if (d === null) { return; }
      var q = readQuota(form);
      if (q === null) { return; }
      var body = {dir: d, quota_mb: q};
      if (pw.value) { body.password = pw.value; }
      var mine = V.page;
      UI.setBusy(b, true);
      FP.call('patch', 'ftpLogin', body, {name: V.account, login: l.login}).then(function (r) {
        if (V.page !== mine) { return; }
        take(r);
        V.open = '';
        draw('[data-fp-act="fta-edit"][data-fp-login="' + l.login + '"]');
        M.say(V.page.querySelector('.fp-fta-listbox'), t('fta_saved', {login: l.login}));
      }, function (err) {
        if (V.page !== mine) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return el('tr', {class: 'fp-fta-edit-row'}, [el('td', {colspan: '4'}, [el('h3', {class: 'fp-h3', id: id + '-h', tabindex: '-1', text: t('fta_edit_title', {login: l.login})}), form])]);
  }
  function listCard() {
    var parts = [el('p', {class: 'fp-muted', text: t('fta_what')})];
    var box = el('div', {class: 'fp-mail-form fp-fta-listbox'}, [M.errorLine(), M.statusLine()]);
    if (!V.logins.length) {
      box.appendChild(el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('fta_none')}));
    } else {
      var rows = [];
      V.logins.forEach(function (l) {
        rows.push(el('tr', {'data-fp-row': l.login}, [el('th', {scope: 'row', class: 'sig-mono fp-fta-login', text: l.login}),
          el('td', {class: 'sig-mono fp-fta-dir', text: dirText(l.dir)}), el('td', {text: quotaText(l.quota)}),
          el('td', {class: 'fp-fta-act'}, [
            el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'fta-edit', 'data-fp-login': l.login,
              'aria-expanded': V.open === l.login ? 'true' : 'false', 'aria-label': t('fta_edit_label', {login: l.login}), text: t('fta_edit')}),
            el('button', {class: 'sig-btn sig-btn--danger sig-btn--sm', type: 'button', 'data-fp-act': 'fta-remove', 'data-fp-login': l.login,
              'aria-label': t('fta_remove_label', {login: l.login}), text: t('fta_remove')})])]));
        if (V.open === l.login) { rows.push(editRow(l)); }
      });
      box.appendChild(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-fta-list-h'}, [
        el('table', {class: 'sig-table fp-mail-table fp-fta-table'}, [el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('fta_login')}),
          el('th', {scope: 'col', text: t('fta_dir')}), el('th', {scope: 'col', text: t('fta_quota_col')}),
          el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]), el('tbody', null, rows)])]));
    }
    parts.push(box);
    return M.card('fp-fta-list-h', t('fta_list_title'), parts, 'fp-fta-list');
  }
  function take(r) {
    var v = clean(r);
    if (v) { V.logins = v.logins; V.suspended = v.suspended; }
  }
  function draw(focus) {
    var page = V.page;
    page.textContent = '';
    if (V.suspended) { page.appendChild(M.suspendedBanner(t('fta_suspended'))); }
    page.appendChild(listCard());
    page.appendChild(createCard());
    var f = focus && page.querySelector(focus);
    if (f) { f.focus(); }
  }
  document.addEventListener('click', function (e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !V.page || !V.page.contains(b) || b.disabled) { return; }
    var act = b.getAttribute('data-fp-act');
    var login = b.getAttribute('data-fp-login') || '';
    if (act === 'fta-edit') {
      V.open = V.open === login ? '' : login;
      draw(V.open ? '#fp-fta-e-' + idOf(login) + '-h' : '[data-fp-act="fta-edit"][data-fp-login="' + login + '"]');
    } else if (act === 'fta-close') {
      var was = V.open;
      V.open = '';
      draw('[data-fp-act="fta-edit"][data-fp-login="' + was + '"]');
    } else if (act === 'fta-remove') {
      V.removing = login;
      M.confirmIn(b.parentNode, t('fta_remove_ask'), 'fta-remove-yes', t('fta_remove_yes'));
    } else if (act === 'confirm-no' && V.removing) {
      var back = V.removing;
      V.removing = '';
      draw('[data-fp-act="fta-remove"][data-fp-login="' + back + '"]');
    } else if (act === 'fta-remove-yes' && V.removing) {
      var gone = V.removing;
      V.removing = '';
      var mine = V.page;
      UI.setBusy(b, true);
      FP.call('del', 'ftpLogin', undefined, {name: V.account, login: gone}).then(function (r) {
        if (V.page !== mine) { return; }
        take(r);
        if (V.open === gone) { V.open = ''; }
        draw('#fp-fta-list-h');
        M.say(V.page.querySelector('.fp-fta-listbox'), t('fta_removed', {login: gone}));
      }, function (err) {
        if (V.page !== mine) { return; }
        draw();
        var box = V.page.querySelector('.fp-fta-listbox');
        UI.showError(box, err.message);
        V.page.querySelector('#fp-fta-list-h').focus();
      });
    }
  });
  FP.view('tool:ftp_accounts', function () {
    var body = M.frame('ftp_accounts', 'fp-fta');
    if (!body) { return; }
    V = {page: body, account: FP.account(), logins: [], domains: null, suspended: false, open: '', removing: ''};
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all([FP.call('get', 'ftpAccounts', undefined, V.account),
      FP.call('get', 'domains', undefined, V.account).then(M.domainsOf, function () { return null; })]).then(function (r) {
      if (V.page !== body) { return; }
      var v = clean(r[0]);
      if (!v) { body.textContent = ''; body.appendChild(FP.empty(FP.tools.ftp_accounts.label, t('api_failed'))); return; }
      V.logins = v.logins;
      V.suspended = v.suspended;
      V.domains = r[1];
      draw();
    }, function (err) {
      if (V.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(FP.tools.ftp_accounts.label, err.message));
    });
  });
})();

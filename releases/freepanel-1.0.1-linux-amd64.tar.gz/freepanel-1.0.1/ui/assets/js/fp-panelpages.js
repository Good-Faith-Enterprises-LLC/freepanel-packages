/* freePanel billing: the hosting panel's pages (#/tool/billing_panel_pages, docs/api.md, "Billing: the hosting panel"). The administrator chooses which
   billing pages a hosting account's panel offers; a page turned off is in no account's menu and its routes answer as if there were none. The admin's
   alone (FP.billing.frame). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;
  var M = FP.mail;

  /* each page the setting names, in the order the form shows them */
  var PAGES = [{key: 'market', label: 'ppg_market', hint: 'ppg_market_hint'}, {key: 'tickets', label: 'ppg_tickets', hint: 'ppg_tickets_hint'}];
  var S = {page: null, busy: false};

  function form(v) {
    var boxes = PAGES.map(function (p) {
      return el('div', {class: 'sig-field'}, [el('label', {class: 'fp-bil-check'}, [el('input', {type: 'checkbox', name: p.key, id: 'fp-ppg-' + p.key, checked: v[p.key] === true ? true : null,
        'aria-describedby': 'fp-ppg-' + p.key + '-hint'}), el('span', {text: t(p.label)})]), el('span', {class: 'sig-hint', id: 'fp-ppg-' + p.key + '-hint', text: t(p.hint)})]);
    });
    return M.card('fp-ppg-h', t('ppg_title'), [el('form', {class: 'fp-form fp-ppg-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('p', {class: 'fp-muted', text: t('ppg_intro')})].concat(boxes, [el('div', {class: 'fp-actions'}, [B.button('ppg-save', t('ppg_save'), 'sig-btn--primary fp-submit')])]))], 'fp-ppg');
  }
  function save(b) {
    var f = b.closest('form');
    if (S.busy || !B.begin(f, b)) { return; }
    var body = {};
    PAGES.forEach(function (p) { body[p.key] = f.elements[p.key].checked; });
    S.busy = true;
    UI.setBusy(b, true);
    FP.call('patch', 'panelPages', body).then(function (v) {
      S.busy = false;
      UI.setBusy(b, false);
      PAGES.forEach(function (p) { f.elements[p.key].checked = v && v[p.key] === true; });
      M.say(f, t('ppg_saved'));
    }, function (err) {
      S.busy = false;
      UI.setBusy(b, false);
      B.failed(f, err);
    });
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('[data-fp-act="ppg-save"]') : null;
    if (b && S.page && S.page.contains(b)) { save(b); }
  });
  document.addEventListener('submit', function (e) {
    if (S.page && S.page.contains(e.target)) { e.preventDefault(); save(e.target.querySelector('[data-fp-act="ppg-save"]')); }
  });

  FP.view('tool:billing_panel_pages', function () {
    var body = B.frame('billing_panel_pages', 'fp-ppg-page');
    if (!body) { return; }
    S.page = body;
    S.busy = false;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'panelPages').then(function (v) {
      if (S.page !== body) { return; }
      body.textContent = '';
      body.appendChild(form(v && typeof v === 'object' ? v : {}));
    }, function (err) {
      if (S.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(FP.tools.billing_panel_pages.label, err.message));
    });
  });
})();

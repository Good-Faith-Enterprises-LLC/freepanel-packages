/* freePanel two-factor sign-in (#/two-factor), the same page in both panels: its status, set-up (scan or type the
   key, confirm a code), the recovery codes shown once, and turning it off. The QR code is drawn here from the
   otpauth URI (docs/api.md) by the vendored qrcode-generator (MIT). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var API = window.FPAPI;

  function crumbs() {
    var tool = null;
    Object.keys(FP.tools).forEach(function (id) { if (FP.tools[id].route === 'two-factor') { tool = FP.tools[id]; } });
    var c = [{label: t('menu_home'), href: '#/'}];
    if (tool) { c.push({label: tool.groupLabel, href: '#/group/' + tool.group}); }
    c.push({label: t('mfa_title')});
    return c;
  }

  function card(children, cls) { return el('section', {class: 'sig-card fp-mfa-card' + (cls ? ' ' + cls : '')}, [el('div', {class: 'sig-card-body'}, children)]); }
  function heading(text, id) { return el('h2', {class: 'fp-h2', id: id, tabindex: '-1', text: text}); }
  function errorLine() { return el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': ''}); }
  function field(id, label, attrs) {
    return el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: id, text: label}),
      el('input', Object.assign({class: 'sig-input', id: id}, attrs))]);
  }
  function codeField(id) {
    return field(id, t('label_code'), {type: 'text', inputmode: 'numeric', pattern: '[0-9]{6}', maxlength: '6',
      autocomplete: 'one-time-code', spellcheck: 'false', class: 'sig-input fp-code fp-code--short'});
  }
  function readCode(input, scope) {
    var v = input.value.replace(/\s+/g, '');
    if (!/^[0-9]{6}$/.test(v)) {
      input.setAttribute('aria-invalid', 'true');
      UI.showError(scope, t('need_code'));
      input.focus();
      return '';
    }
    input.removeAttribute('aria-invalid');
    return v;
  }
  function failed(scope, input, err) {
    if (input && (err.code === 'unauthorized' || err.code === 'validation_failed')) {
      UI.showError(scope, t('bad_code'));
      input.value = '';
      input.setAttribute('aria-invalid', 'true');
      input.focus();
      return;
    }
    UI.showError(scope, err.message);
  }

  var body = null;
  function replace(node, focusSel) {
    body.textContent = '';
    body.appendChild(node);
    var f = focusSel ? node.querySelector(focusSel) : null;
    if (f) { f.focus(); }
  }

  /* ---- status ---- */
  function showStatus(focus, note) {
    replace(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'session').then(function (s) {
      var on = Boolean(s.user && s.user.two_factor);
      var pill = el('span', {class: 'sig-pill ' + (on ? 'sig-pill--ok' : 'sig-pill--warn'), text: on ? t('mfa_on') : t('mfa_off')});
      var parts = [el('div', {class: 'fp-mfa-status'}, [heading(t('mfa_title'), 'fp-mfa-h'), pill]),
        el('p', {text: on ? t('mfa_status_on') : t('mfa_status_off')})];
      if (on) { parts.push(codesLeft(s.recovery_codes_left)); }
      if (note) { parts.push(el('p', {class: 'fp-ok-line', role: 'status', text: note})); }
      var actions = el('div', {class: 'fp-actions'});
      if (on) {
        actions.appendChild(el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'codes', text: t('mfa_make_codes')}));
        actions.appendChild(el('button', {class: 'sig-btn sig-btn--secondary fp-btn-danger-text', type: 'button', 'data-fp-act': 'off', text: t('mfa_turn_off')}));
      } else {
        actions.appendChild(el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'setup', text: t('mfa_start')}));
      }
      parts.push(actions);
      replace(card(parts), focus ? '#fp-mfa-h' : null);
    }, function (err) {
      replace(FP.empty(t('mfa_title'), err.message));
    });
  }

  /* how many recovery codes are left (the session says, docs/api.md); a warning when few are */
  function codesLeft(n) {
    if (typeof n !== 'number' || !isFinite(n) || n < 0) { return null; }
    if (n === 0) { return el('p', {class: 'fp-warn-line', 'data-fp-codes-left': '0', text: t('mfa_codes_left_0')}); }
    if (n <= 3) { return el('p', {class: 'fp-warn-line', 'data-fp-codes-left': String(n), text: t('mfa_codes_low', {n: n})}); }
    return el('p', {class: 'fp-muted', 'data-fp-codes-left': String(n), text: t('mfa_codes_left', {n: n})});
  }

  /* ---- set up ---- */
  /* the otpauth URI as a QR code image (an <img> of an SVG we drew, so nothing in it can run) */
  function qrImage(uri) {
    if (typeof uri !== 'string' || uri.indexOf('otpauth://') !== 0 || typeof window.qrcode !== 'function') { return null; }
    try {
      var qr = window.qrcode(0, 'M');
      qr.addData(uri, 'Byte');
      qr.make();
      var n = qr.getModuleCount();
      var quiet = 4;
      var size = n + quiet * 2;
      var path = '';
      for (var r = 0; r < n; r++) {
        for (var c = 0; c < n; c++) {
          if (qr.isDark(r, c)) { path += 'M' + (c + quiet) + ' ' + (r + quiet) + 'h1v1h-1z'; }
        }
      }
      var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + size + ' ' + size + '" shape-rendering="crispEdges">' +
        '<rect width="' + size + '" height="' + size + '" fill="#fff"/><path fill="#000" d="' + path + '"/></svg>';
      var img = el('img', {class: 'fp-qr', alt: t('mfa_qr_alt'), width: '180', height: '180'});
      img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);   /* our own SVG; el refuses data: */
      return img;
    } catch (e) {
      return null;
    }
  }
  function groupedKey(secret) { return String(secret).replace(/\s+/g, '').replace(/(.{4})/g, '$1 ').trim(); }
  function startSetup(button) {
    UI.setBusy(button, true);
    FP.call('post', 'tfSetup', {}).then(function (s) {
      var secret = typeof s.secret === 'string' ? s.secret : '';
      var qr = qrImage(s.otpauth_uri);
      var input;
      var pass = field('fp-mfa-pass', t('label_password'), {type: 'password', autocomplete: 'current-password', maxlength: '1024'});
      var form = el('form', {class: 'fp-form', novalidate: ''}, [
        el('h3', {class: 'fp-h3', text: '2. ' + t('mfa_step_confirm')}), errorLine(), pass, (input = codeField('fp-mfa-code')),
        el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('mfa_confirm')}),
          el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'cancel', text: t('cancel')})])]);
      input = input.querySelector('input');
      pass = pass.querySelector('input');
      var keyRow = el('div', {class: 'fp-key-row'}, [el('code', {class: 'sig-mono fp-key', id: 'fp-mfa-key', text: groupedKey(secret)}),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-copy': secret, 'aria-label': t('mfa_codes_copy') + ' ' + t('mfa_key')},
          [UI.icon(FP.ui, 'ui_copy'), t('mfa_codes_copy')])]);
      var scan = el('div', {class: 'fp-mfa-scan'}, [qr, el('div', {class: 'fp-mfa-scan-text'}, [
        el('h3', {class: 'fp-h3', text: '1. ' + t('mfa_step_scan')}), el('p', {class: 'fp-muted', text: t('mfa_step_scan_desc')}),
        el('p', {class: 'sig-label', text: t('mfa_key')}), keyRow])]);
      var node = card([heading(t('mfa_start'), 'fp-mfa-h'), scan, form]);
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var b = form.querySelector('.fp-submit');
        if (b.disabled) { return; }
        UI.showError(form, '');
        var code = readCode(input, form);
        if (!code) { return; }
        if (!pass.value) {
          pass.setAttribute('aria-invalid', 'true');
          UI.showError(form, t('mfa_need_password'));
          pass.focus();
          return;
        }
        UI.setBusy(b, true);
        API.post('tfEnable', {password: pass.value, code: code}).then(function (r) {
          showCodes(r.recovery_codes, t('mfa_turned_on'));
        }, function (err) {
          UI.setBusy(b, false);
          /* a wrong code is a 422 on "code"; a wrong password is refused like turning it off (docs/api.md) */
          if (err.code === 'forbidden' || err.code === 'unauthorized' || (err.code === 'validation_failed' && err.field === 'password')) {
            pass.value = '';
            pass.setAttribute('aria-invalid', 'true');
            UI.showError(form, t('mfa_off_refused'));
            pass.focus();
            return;
          }
          failed(form, input, err);
        });
      });
      replace(node, '#fp-mfa-h');
    }, function (err) {
      UI.setBusy(button, false);
      var line = body.querySelector('[data-fp-error]');
      if (!line) { body.querySelector('.sig-card-body').appendChild(errorLine()); }
      UI.showError(body, err.message);
    });
  }

  /* ---- recovery codes, shown once ---- */
  function showCodes(codes, note) {
    codes = (Array.isArray(codes) ? codes : []).filter(function (c) { return typeof c === 'string' && /^[A-Za-z0-9-]{4,64}$/.test(c); });
    var list = el('ol', {class: 'fp-codes sig-mono'});
    codes.forEach(function (c) { list.appendChild(el('li', {text: c})); });
    var text = codes.join('\n') + '\n';
    var check = el('input', {type: 'checkbox', id: 'fp-codes-saved'});
    var done = el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'codes-done', disabled: '', text: t('mfa_codes_done')});
    check.addEventListener('change', function () { done.disabled = !check.checked; });
    var parts = [heading(t('mfa_codes_title'), 'fp-mfa-h')];
    if (note) { parts.push(el('p', {class: 'fp-ok-line', role: 'status', text: note})); }
    parts.push(el('p', {class: 'fp-muted', text: t('mfa_codes_desc')}), list,
      el('div', {class: 'fp-actions'}, [
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-download': '', 'data-fp-text': text}, [UI.icon(FP.ui, 'ui_download'), t('mfa_codes_download')]),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-copy': text}, [UI.icon(FP.ui, 'ui_copy'), t('mfa_codes_copy')])]),
      el('p', {class: 'fp-copy-status', role: 'status', 'data-fp-copy-status': ''}),
      el('label', {class: 'fp-check', for: 'fp-codes-saved'}, [check, el('span', {text: t('mfa_codes_saved_check')})]),
      el('div', {class: 'fp-actions'}, [done]));
    replace(card(parts), '#fp-mfa-h');
  }

  /* ---- off, or new recovery codes: a small form under the status; both take the password and a code from the app ---- */
  function inlineForm(kind) {
    var host = body.querySelector('.sig-card-body');
    var old = host.querySelector('.fp-inline-form');
    if (old) { old.remove(); }
    host.querySelector('.fp-actions').hidden = true;
    var children = [el('h3', {class: 'fp-h3', id: 'fp-inline-h', tabindex: '-1', text: kind === 'off' ? t('mfa_turn_off_title') : t('mfa_new_codes_title')}),
      el('p', {class: 'fp-muted', text: kind === 'off' ? t('mfa_turn_off_desc') : t('mfa_new_codes_desc')}), errorLine()];
    var pass = field('fp-mfa-pass', t('label_password'), {type: 'password', autocomplete: 'current-password', maxlength: '1024'});
    children.push(pass);
    pass = pass.querySelector('input');
    var codeWrap = codeField('fp-mfa-code');
    children.push(codeWrap);
    var input = codeWrap.querySelector('input');
    children.push(el('div', {class: 'fp-actions'}, [
      el('button', {class: 'sig-btn fp-submit ' + (kind === 'off' ? 'sig-btn--danger' : 'sig-btn--primary'), type: 'submit',
        text: kind === 'off' ? t('mfa_turn_off') : t('mfa_make_codes')}),
      el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'cancel', text: t('cancel')})]));
    var form = el('form', {class: 'fp-form fp-inline-form', novalidate: ''}, children);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = form.querySelector('.fp-submit');
      if (b.disabled) { return; }
      UI.showError(form, '');
      if (!pass.value) {
        pass.setAttribute('aria-invalid', 'true');
        UI.showError(form, t('need_password'));
        pass.focus();
        return;
      }
      var code = readCode(input, form);
      if (!code) { return; }
      UI.setBusy(b, true);
      var call = kind === 'off' ? API.post('tfDisable', {password: pass.value, code: code}) : API.post('tfCodes', {password: pass.value, code: code});
      call.then(function (r) {
        if (kind === 'off') { showStatus(true, t('mfa_turned_off')); } else { showCodes(r.recovery_codes, t('mfa_codes_made')); }
      }, function (err) {
        UI.setBusy(b, false);
        /* two-factor was turned off elsewhere meanwhile: show the page as it is now */
        if (err.code === 'conflict') { showStatus(true); return; }
        /* the password or the code was wrong; the session itself still stands (the shell's next call would say if not) */
        if (err.code === 'unauthorized' || err.code === 'forbidden' || err.code === 'validation_failed') {
          pass.value = '';
          input.value = '';
          pass.setAttribute('aria-invalid', 'true');
          UI.showError(form, t('mfa_off_refused'));
          pass.focus();
          return;
        }
        UI.showError(form, err.message);
      });
    });
    host.appendChild(form);
    form.querySelector('#fp-inline-h').focus();
  }

  function onClick(e) {
    var target = e.target.closest ? e.target : null;
    if (!target || !body || !body.contains(target)) { return; }
    var act = target.closest('[data-fp-act]');
    if (act) {
      var a = act.getAttribute('data-fp-act');
      if (a === 'codes-done' && FP.held) {
        /* two-factor is on: the server lets the session through now, so the panel loads again with the whole list */
        window.history.replaceState(null, '', '#/');
        window.location.reload();
        return;
      }
      if (a === 'setup') { startSetup(act); } else if (a === 'cancel' || a === 'codes-done') { showStatus(true); } else if (a === 'off' || a === 'codes') { inlineForm(a); }
      return;
    }
    var copy = target.closest('[data-fp-copy]');
    if (copy) {
      var status = body.querySelector('[data-fp-copy-status]');
      var say = function (msg) { if (status) { status.textContent = msg; } else { UI.announce(msg); } };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(copy.getAttribute('data-fp-copy')).then(function () { say(t('copied')); }, function () { say(t('copy_failed')); });
      } else { say(t('copy_failed')); }
      return;
    }
    var dl = target.closest('[data-fp-download]');
    if (dl) {
      var blob = new Blob([dl.getAttribute('data-fp-text')], {type: 'text/plain'});
      var url = URL.createObjectURL(blob);
      var link = el('a', {download: 'recovery-codes.txt'});
      link.href = url;   /* our own blob: address; el refuses non-web schemes */
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
    }
  }
  document.addEventListener('click', onClick);

  FP.view('two-factor', function () {
    body = FP.frame({title: t('mfa_title'), desc: t('mfa_desc'), crumbs: crumbs(), cls: 'fp-narrow'});
    showStatus(false);
  });
})();

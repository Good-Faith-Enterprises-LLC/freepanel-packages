/* freePanel page helpers shared by the sign-in pages and the shells: text lookup, element building, busy buttons,
   error lines, show/hide password, browser storage that never throws, the host's branding and the colour mode.
   Declares only window.FPUI. */
(function () {
  'use strict';
  var root = document.documentElement;

  function t(key, vars) {
    var s = (window.FPSTRINGS && window.FPSTRINGS[key]) || key;
    if (vars) {
      s = s.replace(/\{([a-z_]+)\}/g, function (m, k) { return Object.prototype.hasOwnProperty.call(vars, k) ? String(vars[k]) : m; });
    }
    return s;
  }

  /* el('a', {class: 'x', href: '#'}, [children]) - text is always set as text, never parsed as HTML */
  /* addresses el may put in href or src: relative, fragment, http(s) or mailto; never javascript:, data: and the like */
  var URL_ATTR = {href: true, src: true, action: true, formaction: true};
  function safeAttrUrl(v) {
    var scheme = /^([a-z][a-z0-9+.-]*):/i.exec(String(v).replace(/[\u0000-\u0020\u007f]/g, ''));   // eslint-disable-line no-control-regex -- browsers ignore these inside a scheme
    return !scheme || /^(https?|mailto)$/i.test(scheme[1]);
  }

  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    if (attrs) {
      Object.keys(attrs).forEach(function (k) {
        var v = attrs[k];
        if (v === null || v === undefined || v === false) { return; }
        if (URL_ATTR[k] && !safeAttrUrl(v)) { return; }
        if (k === 'text') { node.textContent = String(v); } else if (k === 'hidden') { node.hidden = true; } else { node.setAttribute(k, v === true ? '' : String(v)); }
      });
    }
    (children || []).forEach(function (c) {
      if (c === null || c === undefined || c === false) { return; }
      node.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    });
    return node;
  }

  var SVGNS = 'http://www.w3.org/2000/svg';
  var ICON_ID_RE = /^[a-z0-9_]+$/;
  /* <svg class="sig-ico ..."><use href="sprite#sig-id"></svg>, hidden from screen readers (names go on the control) */
  function icon(sprite, id, cls) {
    var svg = document.createElementNS(SVGNS, 'svg');
    svg.setAttribute('class', 'sig-ico' + (cls ? ' ' + cls : ''));
    svg.setAttribute('aria-hidden', 'true');
    svg.setAttribute('focusable', 'false');
    var use = document.createElementNS(SVGNS, 'use');
    if (ICON_ID_RE.test(id)) { use.setAttribute('href', sprite + '#sig-' + id); }
    svg.appendChild(use);
    return svg;
  }
  function assetVersion() {
    var s = document.querySelector('script[src*="/assets/js/fp-ui.js"]');
    var m = s && /[?&]v=([0-9a-f]{6,16})/.exec(s.getAttribute('src'));
    return m ? m[1] : '';
  }
  var V = assetVersion();
  function sprite(name) { return '/assets/icons/' + name + '.svg' + (V ? '?v=' + V : ''); }

  var store = {
    get: function (k) { try { return window.localStorage.getItem(k); } catch (e) { return null; } },
    set: function (k, v) { try { window.localStorage.setItem(k, v); } catch (e) { /* works without it */ } },
    del: function (k) { try { window.localStorage.removeItem(k); } catch (e) { /* ignore */ } },
    json: function (k, fallback) {
      var raw = this.get(k);
      if (!raw) { return fallback; }
      try { return JSON.parse(raw); } catch (e) { return fallback; }
    }
  };

  function setBusy(button, busy) {
    if (!button) { return; }
    button.disabled = busy;
    if (busy) { button.setAttribute('aria-busy', 'true'); } else { button.removeAttribute('aria-busy'); }
  }

  /* the step's error line (role="alert"); empty text hides it */
  function showError(scope, message) {
    var box = scope.querySelector('[data-fp-error]');
    if (!box) { return; }
    box.textContent = message || '';
    box.classList.toggle('is-shown', Boolean(message));
  }

  /* A control a page marks aria-invalid is described by its form's error line, so a screen reader that lands on the control
     hears why, as well as the alert that spoke when the error came. The pages mark and clear the controls; this links the
     error line to a marked control and unlinks it from one that is cleared. */
  var errorSeq = 0;
  function errorLineOf(control) {
    var form = control.closest('form');
    if (form) { return form.querySelector('[data-fp-error]'); }
    for (var n = control.parentElement; n; n = n.parentElement) {
      var line = n.querySelector('[data-fp-error]');
      if (line) { return line; }
    }
    return null;
  }
  function describeInvalid(control) {
    var invalid = control.getAttribute('aria-invalid') === 'true';
    var ids = (control.getAttribute('aria-describedby') || '').split(/\s+/).filter(Boolean);
    var linked = ids.filter(function (id) { return id.indexOf('fp-err-') === 0; });
    var line = invalid ? errorLineOf(control) : null;
    if (line && !line.id) { errorSeq += 1; line.id = 'fp-err-' + errorSeq; }
    var want = line ? [line.id] : [];
    if (linked.join(' ') === want.join(' ')) { return; }
    ids = ids.filter(function (id) { return id.indexOf('fp-err-') !== 0; }).concat(want);
    if (ids.length) { control.setAttribute('aria-describedby', ids.join(' ')); } else { control.removeAttribute('aria-describedby'); }
  }
  function initInvalid() {
    if (!window.MutationObserver) { return; }
    new window.MutationObserver(function (records) {
      records.forEach(function (r) { describeInvalid(r.target); });
    }).observe(document.documentElement, {subtree: true, attributes: true, attributeFilter: ['aria-invalid']});
  }

  /* A scrolling table frame is a region a keyboard can scroll, and it is named by its card's heading. When the card is a
     region of that name too, the screen reader's list shows two of one name; the frame is then named "<heading>: table". */
  function nameFrame(frame) {
    var id = frame.getAttribute('aria-labelledby');
    var heading = id && document.getElementById(id);
    var card = heading && frame.parentElement ? frame.parentElement.closest('[aria-labelledby="' + id + '"]') : null;
    if (!card) { return; }
    frame.removeAttribute('aria-labelledby');
    frame.setAttribute('aria-label', t('table_of', {name: heading.textContent.replace(/\s+/g, ' ').trim()}));
  }
  function nameFramesIn(node) {
    if (node.nodeType !== 1) { return; }
    if (node.matches('.fp-table-wrap[role="region"][aria-labelledby]')) { nameFrame(node); }
    Array.prototype.forEach.call(node.querySelectorAll('.fp-table-wrap[role="region"][aria-labelledby]'), nameFrame);
  }
  function initFrames() {
    if (!window.MutationObserver) { return; }
    new window.MutationObserver(function (records) {
      records.forEach(function (r) { Array.prototype.forEach.call(r.addedNodes, nameFramesIn); });
    }).observe(document.documentElement, {subtree: true, childList: true});
  }

  function initReveal() {
    document.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('[data-fp-reveal]') : null;
      if (!b) { return; }
      var show = b.getAttribute('aria-pressed') !== 'true';
      b.getAttribute('data-fp-reveal').split(',').forEach(function (id) {
        var input = document.getElementById(id);
        if (input) { input.type = show ? 'text' : 'password'; }
      });
      /* a toggle button keeps its name and says whether it is on: "Show password, pressed" */
      b.setAttribute('aria-pressed', String(show));
      var use = b.querySelector('use');
      if (use) { use.setAttribute('href', use.getAttribute('href').replace(/#sig-ui_eye(_slash)?$/, show ? '#sig-ui_eye_slash' : '#sig-ui_eye')); }
    });
  }

  /* the host's help link: https, or mailto with one address (docs/api.md: branding) */
  function safeSupport(u) {
    if (typeof u !== 'string') { return ''; }
    return /^https:\/\/[^\s"'<>]+$/.test(u) || /^mailto:[^\s"'<>,;?&@]+@[^\s"'<>,;?&@]+$/.test(u) ? u : '';
  }
  var LOGO = '/api/v1/branding/logo';
  var brand = {name: 'freePanel'};
  /* the host's branding (GET /branding): its name as text, its logo (the server re-encodes it as a plain PNG) and its
     help link; empty values keep the page's defaults */
  function applyBrand(b) {
    if (!b || typeof b !== 'object') { return; }
    var name = typeof b.name === 'string' ? b.name.replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 64) : '';   // eslint-disable-line no-control-regex -- the contract allows printable characters only
    if (name) {
      brand.name = name;
      var names = document.querySelectorAll('[data-fp-brand]');
      for (var i = 0; i < names.length; i++) { names[i].textContent = name; }
      if (/freePanel$/.test(document.title)) { document.title = document.title.slice(0, -'freePanel'.length) + name; }
    }
    if (b.logo === true) {
      var imgs = document.querySelectorAll('img[data-fp-logo]');
      for (var j = 0; j < imgs.length; j++) { showLogo(imgs[j]); }
    }
    applyColours(b.colours);
    var support = safeSupport(b.support_url);
    var links = document.querySelectorAll('[data-fp-support]');
    for (var k = 0; k < links.length; k++) {
      if (support) { links[k].href = support; links[k].hidden = false; }
    }
  }
  /* a reseller's brand colour, for its own customers (GET /branding sends it to them alone): the panels' --sig-brand-* properties,
     worked out by the server with readable contrast; only known names and #rrggbb values are taken */
  var BRAND_COLOURS = ['fill', 'on-fill', 'badge', 'text-light', 'line-light', 'chip-light', 'chip-line-light', 'chip-text-light', 'text-dark',
    'line-dark', 'chip-dark', 'chip-line-dark', 'chip-text-dark'];
  function applyColours(c) {
    if (!c || typeof c !== 'object') { return; }
    BRAND_COLOURS.forEach(function (k) {
      if (typeof c[k] === 'string' && /^#[0-9a-fA-F]{6}$/.test(c[k])) { root.style.setProperty('--sig-brand-' + k, c[k]); }
    });
  }
  /* the logo stands in for the name, so it carries the name as its text; a logo that fails to load goes back to the name */
  function showLogo(img) {
    img.addEventListener('error', function () {
      img.hidden = true;
      img.removeAttribute('src');
      img.parentNode.classList.remove('has-logo');
    }, {once: true});
    img.alt = brand.name;
    img.src = LOGO;
    img.hidden = false;
    img.parentNode.classList.add('has-logo');
  }
  /* fetched once a page; a failure keeps the defaults (the page works without it) */
  var brandCall = null;
  function loadBrand() {
    if (!brandCall) {
      brandCall = window.FPAPI.get('branding').then(function (b) { applyBrand(b); return brand; }, function () { return brand; });
    }
    return brandCall;
  }

  /* the two panels' pages; each port serves one realm, and GET /health says which (docs/api.md: realms) */
  var PANEL = {admin: {shell: '/admin/', login: '/admin/login.html'}, user: {shell: '/', login: '/login.html'}};
  var healthCall = null;
  function health() {
    if (!healthCall) { healthCall = window.FPAPI.get('health').then(null, function () { return {}; }); }
    return healthCall;
  }
  /* on a port that serves the other realm, go to that realm's page instead; resolves true when leaving */
  function toServedPanel(realm, page) {
    return health().then(function (h) {
      if ((h.realm !== 'admin' && h.realm !== 'user') || h.realm === realm) { return false; }
      window.location.replace(PANEL[h.realm][page] + (page === 'shell' ? window.location.hash : ''));
      return true;
    });
  }

  /* which panel a session belongs to (docs/api.md: realms) */
  function realmOf(session) {
    var role = session && session.user && session.user.role;
    return role === 'admin' || role === 'reseller' ? 'admin' : role === 'user' ? 'user' : '';
  }

  /* colour mode: auto follows the system; fp-boot.js applies a stored choice before the first paint */
  function applyMode(mode) {
    if (mode === 'light' || mode === 'dark') { root.setAttribute('data-sig-mode', mode); } else { root.removeAttribute('data-sig-mode'); }
    var buttons = document.querySelectorAll('button[data-fp-mode]');
    for (var i = 0; i < buttons.length; i++) {
      buttons[i].setAttribute('aria-pressed', String(buttons[i].getAttribute('data-fp-mode') === (mode || 'auto')));
    }
  }
  function initModes() {
    applyMode(store.get('fp.mode'));
    document.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('button[data-fp-mode]') : null;
      if (!b) { return; }
      var mode = b.getAttribute('data-fp-mode');
      if (mode === 'light' || mode === 'dark') { store.set('fp.mode', mode); } else { store.del('fp.mode'); mode = null; }
      applyMode(mode);
    });
    window.addEventListener('storage', function (e) { if (e.key === 'fp.mode' || e.key === null) { applyMode(store.get('fp.mode')); } });
  }

  /* a "next" target from the address: only one of the shell's own routes (#/...), never another site */
  function safeNext(value) {
    return typeof value === 'string' && /^#\/[A-Za-z0-9_\-/]{0,120}$/.test(value) ? value : '';
  }

  function announce(text) {
    var live = document.getElementById('fp-live');
    if (!live) { return; }
    live.textContent = '';
    window.setTimeout(function () { live.textContent = text; }, 40);
  }

  /* The control of form called name. A name that came from the server is escaped, never used as selector text, so an
     odd one finds nothing instead of throwing. */
  function fieldNamed(form, name) {
    if (typeof name !== 'string' || !name) { return null; }
    var q = window.CSS && window.CSS.escape ? window.CSS.escape(name) : name.replace(/[^A-Za-z0-9_-]/g, '');
    return form.querySelector('[name="' + q + '"]');
  }

  window.FPUI = {t: t, el: el, icon: icon, sprite: sprite, store: store, setBusy: setBusy, showError: showError, fieldNamed: fieldNamed,
    loadBrand: loadBrand, applyBrand: applyBrand, realmOf: realmOf, health: health, toServedPanel: toServedPanel, panel: PANEL, brand: brand, applyMode: applyMode, safeNext: safeNext, announce: announce};
  initReveal();
  initInvalid();
  initFrames();
  initModes();
})();

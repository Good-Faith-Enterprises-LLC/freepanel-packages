/* freePanel's Languages page for the admin panel (#/tool/language_settings, docs/api.md, "Language packs"): the language a login that has chosen none
   follows, and which of the translations the panels carry are offered. The packs are files of the built panels, so the page only chooses among them.
   What the server answers is cleaned to the shapes drawn and shown as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var el = UI.el;
  var M = FP.mail;

  var t = UI.t;

  var L = null;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  function code(v) { return typeof v === 'string' && /^[a-z]{2,3}(-[A-Z]{2})?$/.test(v) ? v : ''; }
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var seen = {};
    var packs = (Array.isArray(r.languages) ? r.languages : []).map(function (x) {
      x = x && typeof x === 'object' ? x : {};
      return {code: code(x.code), name: str(x.name, 64), strings: typeof x.strings === 'number' && isFinite(x.strings) && x.strings >= 0 ? Math.min(Math.floor(x.strings), 100000) : 0,
        hidden: x.hidden === true};
    }).filter(function (p) {
      if (!p.code || !p.name || seen[p.code]) { return false; }
      seen[p.code] = true;
      return true;
    }).slice(0, 200);
    var def = code(r.default);
    return {def: def && (seen[def] || def === 'en') ? def : 'en', packs: packs};
  }

  function defaultSelect(selected) {
    var offered = L.packs.filter(function (p) { return !p.hidden; });
    var sel = el('select', {class: 'sig-select', id: 'fp-lg-default', name: 'default'}, [el('option', {value: 'en', text: t('lg_en')})].concat(offered.map(function (p) {
      return el('option', {value: p.code, text: p.name});
    })));
    sel.value = offered.some(function (p) { return p.code === selected; }) || selected === 'en' ? selected : 'en';
    return sel;
  }

  function card() {
    var opts = [el('label', {class: 'fp-check fp-lg-opt', for: 'fp-lg-en'}, [
      el('input', {type: 'checkbox', id: 'fp-lg-en', checked: true, disabled: true}),
      el('span', {class: 'fp-lg-opt-text'}, [el('span', {class: 'fp-lg-name', text: t('lg_en')}), el('span', {class: 'fp-muted fp-lg-note', text: t('lg_en_note')})])])];
    L.packs.forEach(function (p, i) {
      var id = 'fp-lg-pack-' + i;
      var input = el('input', {type: 'checkbox', id: id, name: 'hidden', value: p.code, checked: p.hidden ? null : true});
      opts.push(el('label', {class: 'fp-check fp-lg-opt', for: id}, [input, el('span', {class: 'fp-lg-opt-text'}, [el('span', {class: 'fp-lg-name', text: p.name}),
        el('span', {class: 'fp-muted fp-lg-note', text: t('lg_pack_note', {code: p.code, n: String(p.strings)})})])]));
    });
    var group = el('fieldset', {class: 'fp-lg-choice'}, [el('legend', {class: 'sig-label', text: t('lg_offered')})].concat(opts, [el('p', {class: 'sig-hint', text: t('lg_offered_hint')})]));
    var sel = defaultSelect(L.def);
    var form = el('form', {class: 'fp-form fp-lg-form', novalidate: ''}, [group, M.field('fp-lg-default', t('lg_default'), sel, t('lg_default_hint')), M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('lg_save')})])]);
    /* a translation that is switched off is not a choice for the default any more: the list follows, and English is what is left when it was the default */
    group.addEventListener('change', function () {
      var now = form.querySelector('[name="default"]');
      var keep = now ? now.value : 'en';
      var off = {};
      Array.prototype.forEach.call(form.querySelectorAll('input[name="hidden"]'), function (c) { if (!c.checked) { off[c.value] = true; } });
      var fresh = el('select', {class: 'sig-select', id: 'fp-lg-default', name: 'default'}, [el('option', {value: 'en', text: t('lg_en')})].concat(L.packs.filter(function (p) {
        return !off[p.code];
      }).map(function (p) { return el('option', {value: p.code, text: p.name}); })));
      fresh.setAttribute('aria-describedby', 'fp-lg-default-hint');
      fresh.value = off[keep] ? 'en' : keep;
      if (now && now.parentNode) { now.parentNode.replaceChild(fresh, now); }
    });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var go = M.start(form);
      if (!go) { return; }
      var hidden = [];
      Array.prototype.forEach.call(form.querySelectorAll('input[name="hidden"]'), function (c) { if (!c.checked) { hidden.push(c.value); } });
      var mine = L;
      UI.setBusy(go, true);
      FP.call('put', 'serverLanguages', {default: form.querySelector('[name="default"]').value, hidden: hidden}).then(function (r) {
        if (L !== mine) { return; }
        L.def = clean(r).def;
        L.packs = clean(r).packs;
        L.say = t('lg_saved');
        draw('#fp-lg-h');
      }, function (err) {
        if (L !== mine) { return; }
        UI.setBusy(go, false);
        M.failed(form, err);
      });
    });
    return M.card('fp-lg-h', t('lg_title'), [form], 'fp-lg');
  }
  function draw(focus) {
    var page = L.page;
    page.textContent = '';
    if (!L.packs.length) {
      page.appendChild(FP.empty(t('lg_title'), t('lg_none')));
      return;
    }
    page.appendChild(card());
    if (L.say) { M.say(page, L.say); L.say = ''; }
    var target = focus ? page.querySelector(focus) : null;
    if (target) { target.focus(); }
  }

  FP.view('tool:language_settings', function () {
    L = null;
    var tool = FP.tools.language_settings;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('lg_desc'), cls: 'fp-mail fp-lg-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    if (!page) { return; }
    L = {page: page, def: 'en', packs: [], say: ''};
    var mine = L;
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'serverLanguages').then(function (r) {
      if (L !== mine) { return; }
      var c = clean(r);
      L.def = c.def;
      L.packs = c.packs;
      draw('');
    }, function (err) {
      if (L !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err && err.message ? err.message : t('lg_unavailable')));
    });
  });
})();

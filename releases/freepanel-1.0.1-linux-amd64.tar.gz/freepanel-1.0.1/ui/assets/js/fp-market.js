/* freePanel Marketplace (#/tool/billing_market, docs/api.md, "Billing: the hosting panel"): what the host's own billing sells, seen from a hosting account's
   panel. The account is linked to a billing customer by the host (the provisioning bridge's account link); the page shows that customer's plan with the
   plans it can move to (priced for the days left before anything changes), the catalogue with each plan's add-ons, and the domains for sale. An order is
   placed for the linked customer and waits for the host's review; payment is in the billing account (/account). An account with no link is told how to
   get one. A support session reads the page and orders nothing. Everything the server sends is shown as text; money is whole cents (FP.billing). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;
  var M = FP.mail;

  var TERMS = ['monthly', 'quarterly', 'semiannual', 'annual', 'biennial', 'triennial'];
  var TLD_RE = /^[a-z0-9][a-z0-9-]{0,62}(\.[a-z0-9][a-z0-9-]{0,62})*$/;
  var NAME_RE = /^[a-z][a-z0-9]{0,15}$/;
  var S = {page: null, data: null, busy: false};

  /* ---- what the server sends, kept to what the page shows ---- */
  function prices(v) {
    var out = {};
    if (v && typeof v === 'object') { TERMS.forEach(function (k) { var c = B.cents(v[k]); if (c !== null && c >= 0) { out[k] = c; } }); }
    return out;
  }
  function list(v, n) { return Array.isArray(v) ? v.slice(0, n) : []; }
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var out = {linked: r.linked === true, support: r.support_session === true, currency: B.str(r.currency, 3), customer: null, service: null,
      switchTo: [], groups: [], extensions: [], terms: null};
    if (!out.linked) { return out; }
    if (r.customer && typeof r.customer === 'object') { out.customer = {name: B.str(r.customer.name, 100), status: B.str(r.customer.status, 20)}; }
    var s = r.service;
    if (s && typeof s === 'object' && B.id(s.id)) {
      out.service = {id: s.id, plan: B.str(s.plan_name, 100), planId: B.id(s.plan_id), term: TERMS.indexOf(s.term) >= 0 ? s.term : '', status: B.str(s.status, 20),
        renewal: B.cents(s.renewal_cents), nextDue: B.str(s.next_due, 10)};
    }
    out.switchTo = list(r.switch_to, 100).filter(function (p) { return p && B.id(p.id); }).map(function (p) {
      return {id: p.id, name: B.str(p.name, 100), desc: B.str(p.description, 500), group: B.str(p.group, 100), price: B.cents(p.price_cents)};
    });
    out.groups = list(r.groups, 50).filter(function (g) { return g && B.id(g.id); }).map(function (g) {
      return {id: g.id, name: B.str(g.name, 100), desc: B.str(g.description, 500), plans: list(g.plans, 100).filter(function (p) { return p && B.id(p.id); }).map(function (p) {
        return {id: p.id, name: B.str(p.name, 100), desc: B.str(p.description, 500), setup: B.cents(p.setup_cents) || 0, prices: prices(p.prices),
          addons: list(p.addons, 20).filter(function (a) { return a && B.id(a.id); }).map(function (a) {
            return {id: a.id, name: B.str(a.name, 100), desc: B.str(a.description, 500), setup: B.cents(a.setup_cents) || 0, prices: prices(a.prices)};
          })};
      })};
    });
    out.extensions = list(r.extensions, 200).filter(function (e) { return e && TLD_RE.test(B.str(e.tld, 63)); }).map(function (e) {
      return {tld: e.tld, register: B.cents(e.register_cents), renew: B.cents(e.renew_cents), years: Math.min(B.whole(e.max_years) || 1, 10)};
    });
    if (r.terms && typeof r.terms === 'object' && B.id(r.terms.id) && r.terms.required === true) {
      out.terms = {id: r.terms.id, accepted: r.terms.accepted === true, title: B.str(r.terms.title, 200), body: B.str(r.terms.body, 100000)};
    }
    return out;
  }
  function money(c) { return B.money(c, S.data && S.data.currency); }
  function termName(k) { return t('mkt_term_' + k); }
  function priceLine(p) {
    return TERMS.filter(function (k) { return p.prices[k] !== undefined; }).map(function (k) { return t('mkt_price_per', {price: money(p.prices[k]), term: termName(k)}); }).join(' · ');
  }

  /* ---- the cards ---- */
  function noLinkCard() {
    return M.card('fp-mkt-none-h', t('mkt_none_title'), [el('p', {'data-fp-empty': '', text: t('mkt_none_text', {account: FP.account()})}),
      el('p', {class: 'fp-muted', text: t('mkt_none_how')})], 'fp-mkt-none');
  }
  function whoCard(d) {
    var parts = [el('p', {'data-fp-mkt-who': '', text: t('mkt_linked', {name: d.customer ? d.customer.name : ''})}),
      el('p', null, [el('a', {class: 'fp-link-text', href: '/account', text: t('mkt_open_billing')})])];
    if (d.customer && d.customer.status !== 'active') { parts.push(el('p', {class: 'fp-muted', text: t('mkt_customer_off')})); }
    return M.card('fp-mkt-who-h', t('mkt_who_title'), parts, 'fp-mkt-who');
  }
  function planCard(d) {
    var parts = [M.errorLine(), M.statusLine()];
    var s = d.service;
    if (!s) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('mkt_no_service')}));
      return M.card('fp-mkt-plan-h', t('mkt_plan_title'), parts, 'fp-mkt-plan');
    }
    parts.push(B.facts([[t('mkt_plan_now'), s.plan], [t('mkt_plan_term'), s.term ? termName(s.term) : ''], [t('mkt_plan_renewal'), money(s.renewal)],
      [t('mkt_plan_next'), B.day(s.nextDue)]]));
    if (s.status !== 'active') {
      parts.push(el('p', {class: 'fp-muted', text: t('mkt_plan_inactive')}));
    } else if (!d.switchTo.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('mkt_switch_none')}));
    } else {
      parts.push(el('h3', {class: 'fp-h3', text: t('mkt_switch_title')}));
      parts.push(el('ul', {class: 'fp-mkt-list'}, d.switchTo.map(function (p) {
        return el('li', {class: 'fp-mkt-item', 'data-fp-plan': String(p.id)}, [
          el('div', {class: 'fp-mkt-item-text'}, [el('b', {text: p.name}), el('span', {class: 'fp-muted', text: t('mkt_price_per', {price: money(p.price), term: termName(s.term)})}),
            p.desc ? el('span', {class: 'fp-muted', text: p.desc}) : null]),
          el('div', {class: 'fp-actions fp-mkt-acts'}, [B.button('mkt-change-quote', t('mkt_switch_price'), 'sig-btn--secondary sig-btn--sm',
            {'data-fp-id': String(p.id), 'aria-label': t('mkt_switch_price_of', {plan: p.name}), disabled: d.support ? true : null})])]);
      })));
    }
    return M.card('fp-mkt-plan-h', t('mkt_plan_title'), parts, 'fp-mkt-plan');
  }
  function catalogueCard(d) {
    var parts = [];
    if (!d.groups.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('mkt_shop_none')}));
      return M.card('fp-mkt-shop-h', t('mkt_shop_title'), parts, 'fp-mkt-shop');
    }
    d.groups.forEach(function (g) {
      parts.push(el('h3', {class: 'fp-h3', text: g.name}));
      if (g.desc) { parts.push(el('p', {class: 'fp-muted', text: g.desc})); }
      parts.push(el('ul', {class: 'fp-mkt-list'}, g.plans.map(function (p) {
        var bits = [el('b', {text: p.name}), el('span', {class: 'fp-muted', text: priceLine(p)})];
        if (p.setup) { bits.push(el('span', {class: 'fp-muted', text: t('mkt_setup', {price: money(p.setup)})})); }
        if (p.desc) { bits.push(el('span', {class: 'fp-muted', text: p.desc})); }
        if (p.addons.length) { bits.push(el('span', {class: 'fp-muted', text: t('mkt_addons_with', {names: p.addons.map(function (a) { return a.name; }).join(', ')})})); }
        return el('li', {class: 'fp-mkt-item', 'data-fp-plan': String(p.id)}, [el('div', {class: 'fp-mkt-item-text'}, bits),
          el('div', {class: 'fp-actions fp-mkt-acts'}, [B.button('mkt-pick', t('mkt_order_this'), 'sig-btn--secondary sig-btn--sm',
            {'data-fp-id': String(p.id), 'aria-label': t('mkt_order_this_of', {plan: p.name}), disabled: d.support ? true : null})])]);
      })));
    });
    return M.card('fp-mkt-shop-h', t('mkt_shop_title'), parts, 'fp-mkt-shop');
  }
  function planById(id) {
    var found = null;
    S.data.groups.forEach(function (g) { g.plans.forEach(function (p) { if (p.id === id) { found = p; } }); });
    return found;
  }
  function orderCard(d) {
    var options = [['', t('mkt_choose_plan')]];
    d.groups.forEach(function (g) { g.plans.forEach(function (p) { options.push([String(p.id), g.name + ' · ' + p.name]); }); });
    var form = el('form', {class: 'fp-form fp-mkt-order', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-mkt-plan', t('mkt_f_plan'), B.select('fp-mkt-plan', 'plan_id', options, '')),
      el('div', {'data-fp-mkt-choice': ''}),
      M.field('fp-mkt-user', t('mkt_f_username'), B.input('fp-mkt-user', 'username', '', {maxlength: '16', autocapitalize: 'none', spellcheck: 'false'}), t('mkt_f_username_hint')),
      M.field('fp-mkt-domain', t('mkt_f_domain'), B.input('fp-mkt-domain', 'domain', '', {maxlength: '253', autocapitalize: 'none', spellcheck: 'false', inputmode: 'url'}), t('mkt_f_domain_hint')),
      termsBox(d),
      el('div', {'data-fp-mkt-quote': ''}),
      el('div', {class: 'fp-actions'}, [B.button('mkt-quote', t('mkt_quote'), 'sig-btn--secondary', {type: 'submit', disabled: d.support ? true : null}),
        B.button('mkt-place', t('mkt_place'), 'sig-btn--primary fp-submit', {disabled: d.support ? true : null})])]);
    return M.card('fp-mkt-order-h', t('mkt_order_title'), [el('p', {class: 'fp-muted', text: t('mkt_order_intro')}), form], 'fp-mkt-orders');
  }
  function termsBox(d) {
    if (!d.terms || d.terms.accepted) { return null; }
    return el('div', {class: 'fp-mkt-terms'}, [
      el('details', null, [el('summary', {text: t('mkt_terms_read', {title: d.terms.title || t('mkt_terms')})}), el('div', {class: 'fp-mkt-terms-text', tabindex: '0', text: d.terms.body})]),
      el('label', {class: 'fp-bil-check'}, [el('input', {type: 'checkbox', name: 'terms_id', value: String(d.terms.id)}), el('span', {text: t('mkt_terms_accept')})])]);
  }
  /* the term and add-ons of the plan chosen */
  function choiceFor(p) {
    var box = S.page.querySelector('[data-fp-mkt-choice]');
    box.textContent = '';
    S.page.querySelector('[data-fp-mkt-quote]').textContent = '';
    if (!p) { return; }
    var terms = TERMS.filter(function (k) { return p.prices[k] !== undefined; });
    box.appendChild(M.field('fp-mkt-term', t('mkt_f_term'), B.select('fp-mkt-term', 'term', terms.map(function (k) { return [k, termName(k) + ' · ' + money(p.prices[k])]; }), terms[0] || '')));
    if (p.addons.length) {
      box.appendChild(el('fieldset', {class: 'fp-mkt-addons'}, [el('legend', {class: 'sig-label', text: t('mkt_f_addons')})].concat(p.addons.map(function (a) {
        var line = TERMS.filter(function (k) { return a.prices[k] !== undefined; }).map(function (k) { return t('mkt_price_per', {price: money(a.prices[k]), term: termName(k)}); }).join(' · ');
        return el('label', {class: 'fp-bil-check'}, [el('input', {type: 'checkbox', name: 'addon_ids', value: String(a.id)}), el('span', {text: a.name + (line ? ' (' + line + ')' : '')})]);
      }))));
    }
  }
  function domainsCard(d) {
    var parts = [M.errorLine(), M.statusLine()];
    if (!d.extensions.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('mkt_dom_none')}));
      return M.card('fp-mkt-dom-h', t('mkt_dom_title'), parts, 'fp-mkt-dom');
    }
    parts.push(B.table('fp-mkt-dom-h', 'fp-mkt-ext', [B.th(t('mkt_dom_ext')), B.th(t('mkt_dom_register')), B.th(t('mkt_dom_renew'))], d.extensions.map(function (e) {
      return el('tr', null, [el('td', {text: '.' + e.tld}), el('td', {text: money(e.register)}), el('td', {text: money(e.renew)})]);
    })));
    parts.push(el('form', {class: 'fp-form fp-mkt-search', role: 'search', novalidate: ''}, [
      M.field('fp-mkt-q', t('mkt_dom_search'), B.input('fp-mkt-q', 'q', '', {maxlength: '253', autocapitalize: 'none', spellcheck: 'false', inputmode: 'url'}), t('mkt_dom_search_hint')),
      el('div', {class: 'fp-actions'}, [B.button('mkt-search', t('mkt_dom_look'), 'sig-btn--secondary fp-submit', {type: 'submit'})])]));
    parts.push(el('ul', {class: 'fp-mkt-list', 'data-fp-mkt-found': '', 'aria-live': 'polite'}));
    return M.card('fp-mkt-dom-h', t('mkt_dom_title'), parts, 'fp-mkt-dom');
  }

  function render() {
    var d = S.data;
    S.page.textContent = '';
    if (!d.linked) { S.page.appendChild(noLinkCard()); return; }
    if (d.support) {
      S.page.appendChild(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-mkt-support': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('mkt_support_note')})]));
    }
    S.page.appendChild(whoCard(d));
    S.page.appendChild(planCard(d));
    S.page.appendChild(catalogueCard(d));
    if (d.groups.length) { S.page.appendChild(orderCard(d)); }
    S.page.appendChild(domainsCard(d));
  }
  function read() {
    return FP.call('get', 'market', undefined, FP.account()).then(function (r) {
      S.data = clean(r);
      render();
    });
  }

  /* ---- a change of plan: the price first, then a question ---- */
  function changeQuote(b) {
    var item = b.closest('.fp-mkt-item');
    var card = S.page.querySelector('.fp-mkt-plan');
    var id = Number(b.getAttribute('data-fp-id'));
    UI.showError(card, '');
    M.say(card, '');
    UI.setBusy(b, true);
    FP.call('post', 'marketChangeQuote', {plan_id: id}, FP.account()).then(function (q) {
      var diff = B.cents(q.difference_cents);
      var renewal = B.cents(q.new_renewal_cents);
      var days = B.whole(q.days_left);
      var what = diff === null ? '' : diff > 0 ? t('mkt_change_pay', {price: money(diff), days: String(days)}) : diff < 0 ? t('mkt_change_credit', {price: money(-diff), days: String(days)}) : t('mkt_change_even');
      var acts = item.querySelector('.fp-mkt-acts');
      acts.textContent = '';
      acts.appendChild(el('p', {class: 'fp-mkt-quote-line', 'data-fp-mkt-change': '', text: what + ' ' + t('mkt_change_renewal', {price: money(renewal)})}));
      M.confirmIn(acts.appendChild(el('div', {class: 'fp-actions'})), t('mkt_change_ask', {plan: B.str(q.to_plan_name, 100)}), 'mkt-change-yes', t('mkt_change_yes'));
      acts.querySelector('[data-fp-act="mkt-change-yes"]').setAttribute('data-fp-id', String(id));
    }, function (err) {
      UI.setBusy(b, false);
      UI.showError(card, err.message);
    });
  }
  function change(b) {
    if (S.busy) { return; }
    S.busy = true;
    UI.setBusy(b, true);
    var mine = S.page;
    FP.call('post', 'marketChange', {plan_id: Number(b.getAttribute('data-fp-id'))}, FP.account()).then(function (r) {
      return read().then(function () {
        S.busy = false;
        if (S.page !== mine) { return; }
        var card = S.page.querySelector('.fp-mkt-plan');
        var inv = B.id(r.invoice_id);
        var credit = B.cents(r.credit_cents);
        M.say(card, inv ? t('mkt_changed_invoice') : credit ? t('mkt_changed_credit', {price: money(credit)}) : t('mkt_changed'));
        card.querySelector('#fp-mkt-plan-h').focus();
      });
    }, function (err) {
      S.busy = false;
      if (S.page !== mine) { return; }
      render();
      var card = S.page.querySelector('.fp-mkt-plan');
      UI.showError(card, err.message);
      card.querySelector('#fp-mkt-plan-h').focus();
    });
  }

  /* ---- a new order ---- */
  function cart(form) {
    var plan = Number(form.elements.plan_id.value);
    var term = form.elements.term ? form.elements.term.value : '';
    var adds = [];
    var boxes = form.querySelectorAll('input[name="addon_ids"]:checked');
    for (var i = 0; i < boxes.length; i++) { adds.push(Number(boxes[i].value)); }
    var item = {plan_id: plan, term: term, addon_ids: adds, username: form.elements.username.value.trim().toLowerCase(), domain: form.elements.domain.value.trim().toLowerCase()};
    var body = {items: [item]};
    var terms = form.querySelector('input[name="terms_id"]');
    if (terms && terms.checked) { body.terms_id = Number(terms.value); }
    return body;
  }
  function checkCart(form) {
    var f = form.elements;
    if (!f.plan_id.value) { M.fieldError(form, f.plan_id, t('mkt_err_plan')); return false; }
    var u = f.username.value.trim().toLowerCase();
    if (u && !NAME_RE.test(u)) { M.fieldError(form, f.username, t('mkt_err_username')); return false; }
    var terms = form.querySelector('input[name="terms_id"]');
    if (terms && !terms.checked) { M.fieldError(form, terms, t('mkt_err_terms')); return false; }
    return true;
  }
  function quote(b) {
    var form = b.closest('form');
    if (!B.begin(form, b) || !checkCart(form)) { return; }
    var box = form.querySelector('[data-fp-mkt-quote]');
    box.textContent = '';
    UI.setBusy(b, true);
    FP.call('post', 'marketQuote', cart(form), FP.account()).then(function (r) {
      UI.setBusy(b, false);
      var o = r && Array.isArray(r.orders) && r.orders[0] && typeof r.orders[0] === 'object' ? r.orders[0] : {};
      var tax = r && r.tax && typeof r.tax === 'object' ? B.cents(r.tax.tax_cents) : null;
      box.appendChild(B.facts([[t('mkt_q_first'), money(B.cents(r.first_total_cents))], tax ? [t('mkt_q_tax'), money(tax)] : null,
        [t('mkt_q_renewal'), money(B.cents(o.renewal_total_cents))]], 'fp-mkt-quote'));
    }, function (err) {
      UI.setBusy(b, false);
      B.failed(form, err);
    });
  }
  function place(b) {
    var form = b.closest('form');
    if (S.busy || !B.begin(form, b) || !checkCart(form)) { return; }
    S.busy = true;
    UI.setBusy(b, true);
    var mine = S.page;
    FP.call('post', 'marketOrders', cart(form), FP.account()).then(function (r) {
      S.busy = false;
      if (S.page !== mine) { return; }
      UI.setBusy(b, false);
      var n = r && Array.isArray(r.orders) ? r.orders.length : 0;
      form.reset();
      choiceFor(null);
      M.say(form, n ? t('mkt_placed') : t('mkt_placed_some'));
      form.querySelector('#fp-mkt-plan').focus();
    }, function (err) {
      S.busy = false;
      if (S.page !== mine) { return; }
      UI.setBusy(b, false);
      B.failed(form, err);
    });
  }

  /* ---- domains ---- */
  function search(b) {
    var form = b.closest('form');
    var card = S.page.querySelector('.fp-mkt-dom');
    var q = form.elements.q.value.trim().toLowerCase();
    UI.showError(card, '');
    M.say(card, '');
    if (!B.begin(form, b)) { return; }
    if (!q) { M.fieldError(card, form.elements.q, t('mkt_err_q')); return; }
    var found = S.page.querySelector('[data-fp-mkt-found]');
    found.textContent = '';
    UI.setBusy(b, true);
    FP.call('get', 'marketDomains', undefined, {name: FP.account(), q: q}).then(function (r) {
      UI.setBusy(b, false);
      var offers = list(r && r.domains, 20).filter(function (o) { return o && TLD_RE.test(B.str(o.domain, 253)); });
      if (!offers.length) { found.appendChild(el('li', {class: 'fp-muted', text: t('mkt_dom_nothing')})); return; }
      offers.forEach(function (o) {
        var years = Math.min(B.whole(o.max_years) || 1, 10);
        var opts = [];
        for (var y = 1; y <= years; y++) { opts.push([String(y), t(y === 1 ? 'mkt_year' : 'mkt_years', {n: String(y)})]); }
        var sel = 'fp-mkt-y-' + o.domain.replace(/[^a-z0-9]/g, '-');
        found.appendChild(el('li', {class: 'fp-mkt-item', 'data-fp-domain': o.domain}, [
          el('div', {class: 'fp-mkt-item-text'}, [el('b', {text: o.domain}),
            el('span', {class: 'fp-muted', text: o.available === true ? t('mkt_dom_free', {price: money(B.cents(o.register_cents))}) : t('mkt_dom_taken')})]),
          o.available === true ? el('div', {class: 'fp-actions fp-mkt-acts'}, [
            el('label', {class: 'sig-vh', for: sel, text: t('mkt_dom_years_of', {domain: o.domain})}),
            B.select(sel, 'years', opts, '1', {class: 'sig-select fp-mkt-years'}),
            B.button('mkt-register', t('mkt_dom_order'), 'sig-btn--secondary sig-btn--sm', {'data-fp-name': o.domain, 'aria-label': t('mkt_dom_order_of', {domain: o.domain}),
              disabled: S.data.support ? true : null})]) : null]));
      });
    }, function (err) {
      UI.setBusy(b, false);
      UI.showError(card, err.message);
    });
  }
  function register(b) {
    var card = S.page.querySelector('.fp-mkt-dom');
    if (S.busy) { return; }
    S.busy = true;
    UI.showError(card, '');
    M.say(card, '');
    UI.setBusy(b, true);
    var name = b.getAttribute('data-fp-name');
    var years = Number(b.closest('.fp-mkt-acts').querySelector('select').value) || 1;
    FP.call('post', 'marketDomainOrder', {domain: name, years: years}, FP.account()).then(function () {
      S.busy = false;
      var acts = b.closest('.fp-mkt-acts');
      acts.textContent = '';
      acts.appendChild(el('span', {class: 'fp-muted', text: t('mkt_dom_ordered_short')}));
      M.say(card, t('mkt_dom_ordered', {domain: name}));
    }, function (err) {
      S.busy = false;
      UI.setBusy(b, false);
      UI.showError(card, err.message);
    });
  }

  document.addEventListener('change', function (e) {
    if (!S.page || !S.page.contains(e.target) || e.target.id !== 'fp-mkt-plan') { return; }
    choiceFor(planById(Number(e.target.value)));
  });
  /* Check the price and Look are the forms' submit buttons, so Enter in a field prices the order or looks; only its own button places an order */
  document.addEventListener('submit', function (e) {
    if (!S.page || !S.page.contains(e.target)) { return; }
    e.preventDefault();
    if (e.target.classList.contains('fp-mkt-search')) { search(e.target.querySelector('[data-fp-act="mkt-search"]')); } else { quote(e.target.querySelector('[data-fp-act="mkt-quote"]')); }
  });
  document.addEventListener('click', function (e) {
    var node = e.target.closest ? e.target : null;
    var b = node && node.closest('[data-fp-act]');
    if (!b || !S.page || !S.page.contains(b)) { return; }
    var a = b.getAttribute('data-fp-act');
    if (a === 'mkt-change-quote') { changeQuote(b); } else if (a === 'mkt-change-yes') { change(b); } else if (a === 'confirm-no' && b.closest('.fp-mkt-plan')) {
      render();
      S.page.querySelector('#fp-mkt-plan-h').focus();
    } else if (a === 'mkt-pick') {
      var sel = S.page.querySelector('#fp-mkt-plan');
      sel.value = b.getAttribute('data-fp-id');
      choiceFor(planById(Number(sel.value)));
      sel.focus();
    } else if (a === 'mkt-place') { place(b); } else if (a === 'mkt-register') { register(b); }
  });

  FP.view('tool:billing_market', function () {
    var tool = FP.tools.billing_market;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    S.data = null;
    S.busy = false;
    var body = FP.frame({title: tool.label, desc: t('mkt_desc'), cls: 'fp-mail fp-mkt-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    S.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    read().then(null, function (err) {
      if (S.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

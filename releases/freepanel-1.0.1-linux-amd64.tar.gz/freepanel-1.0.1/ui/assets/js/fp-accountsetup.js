/* freePanel account set-up pages of the administrators' panel (docs/api.md, "Starter files", "Welcome message", "Web server"): Starter files
   (#/tool/starter_files: the files every new account's home folder begins with), Welcome message (#/tool/welcome_message: the email a new
   customer is sent when an account is made for them) and Suspended page (#/tool/suspended_page: the one page every suspended site shows).
   All three are the administrator's alone. What the server sends is drawn as text. The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var UNITS = ['KB', 'MB', 'GB'];

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function num(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.floor(v) : 0; }
  function count(n) { return Number(n).toLocaleString('en'); }
  function sentence(m) { return typeof m === 'string' && m ? m.charAt(0).toUpperCase() + m.slice(1) : m; }
  function size(n) {
    if (n < 1024) { return count(n) + ' B'; }
    var u = -1;
    do { n /= 1024; u++; } while (n >= 1024 && u < UNITS.length - 1);
    return (n < 10 ? n.toFixed(1) : Math.round(n).toLocaleString('en')) + ' ' + UNITS[u];
  }
  function stamp(iso) {
    var d = typeof iso === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(iso) ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }
  function bytesOf(text) { return new window.TextEncoder().encode(text).length; }
  function frame(id) {
    var tool = FP.tools[id];
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return null; }
    var g = FP.group(tool.group);
    return FP.frame({title: tool.label, desc: t(id + '_desc'), cls: 'fp-mail fp-as fp-as-' + id,
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
  }
  function listFail(body, label, err) {
    body.textContent = '';
    body.appendChild(FP.empty(label, sentence(err.message)));
  }

  /* ================= Starter files ================= */
  var PART_RE = /^[A-Za-z0-9._-]{1,64}$/;
  var KEPT = /^(\.ssh|mail|logs|tmp)(\/|$)/;
  var SF = {page: null, data: null, edit: null};

  function cleanFiles(r) {
    if (!r || typeof r !== 'object' || !Array.isArray(r.files)) { return null; }
    var lim = r.limits && typeof r.limits === 'object' ? r.limits : {};
    return {files: r.files.map(function (f) {
      if (!f || typeof f !== 'object' || !pathOk(str(f.path, 420))) { return null; }
      return {path: f.path, size: num(f.size), executable: f.executable === true, at: stamp(f.updated_at)};
    }).filter(Boolean), total: num(r.total_bytes), files_max: num(lim.files) || 200, file_bytes: num(lim.file_bytes) || 131072, bytes: num(lim.bytes) || 524288};
  }
  /* a path the server keeps: plain names, at most 6 deep, not in the folders the panel keeps for itself */
  function pathOk(p) {
    if (!p || p.length > 400 || p.charAt(0) === '/') { return false; }
    var parts = p.split('/');
    if (parts.length > 6) { return false; }
    for (var i = 0; i < parts.length; i++) { if (!PART_RE.test(parts[i]) || parts[i] === '.' || parts[i] === '..') { return false; } }
    return !KEPT.test(p);
  }
  function sfUse() {
    var d = SF.data;
    return t('sf_use', {files: count(d.files.length), max: count(d.files_max), size: size(d.total), limit: size(d.bytes)});
  }
  function sfRow(f) {
    var acts = el('div', {class: 'fp-mail-acts fp-sf-acts'}, [
      el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'sf-edit', 'data-fp-path': f.path, 'aria-label': t('sf_edit_of', {path: f.path}), text: t('sf_edit')}),
      el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'sf-delete', 'data-fp-path': f.path,
        'aria-label': t('sf_delete_of', {path: f.path}), text: t('sf_delete')})]);
    return el('li', {class: 'fp-sf-row', 'data-fp-file': f.path}, [
      el('div', {class: 'fp-sf-what'}, [el('span', {class: 'fp-sf-path sig-mono', text: f.path}),
        el('span', {class: 'fp-muted fp-row-note', text: [size(f.size), f.at ? t('sf_changed', {when: f.at}) : ''].filter(Boolean).join(' · ')}),
        f.executable ? el('span', {class: 'sig-pill sig-pill--accent', text: t('sf_runs')}) : null]), acts]);
  }
  function sfList() {
    var d = SF.data;
    var parts = [el('p', {class: 'fp-muted', text: t('sf_intro')}), el('p', {class: 'fp-sf-use', 'data-fp-use': '', text: sfUse()}), M.errorLine(), M.statusLine()];
    if (!d.files.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('sf_none')}));
    } else {
      parts.push(el('ul', {class: 'fp-sf-list', 'aria-label': t('sf_list_label')}, d.files.map(sfRow)));
    }
    return M.card('fp-sf-list-h', t('sf_list_title'), parts, 'fp-sf-files');
  }
  /* a file read from the computer: its text, when it is UTF-8 text without NUL; else its bytes as base64 */
  function readFile(file, done) {
    var reader = new window.FileReader();
    reader.onload = function () {
      var buf = new Uint8Array(reader.result);
      var text;
      try { text = new window.TextDecoder('utf-8', {fatal: true}).decode(buf); } catch (e) { text = null; }
      if (typeof text === 'string' && text.indexOf('\u0000') < 0) { done({text: text}); return; }
      var bin = '';
      for (var i = 0; i < buf.length; i += 8192) { bin += String.fromCharCode.apply(null, buf.subarray(i, i + 8192)); }
      done({base64: window.btoa(bin), bytes: buf.length});
    };
    reader.onerror = function () { done(null); };
    reader.readAsArrayBuffer(file);
  }
  function sfEditor() {
    var path = el('input', {class: 'sig-input sig-mono', id: 'fp-sf-path', name: 'path', type: 'text', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', maxlength: '400',
      placeholder: 'public_html/index.html'});
    var text = el('textarea', {class: 'sig-input sig-mono fp-sf-text', id: 'fp-sf-text', name: 'text', rows: '12', spellcheck: 'false', wrap: 'off'});
    var load = el('input', {class: 'sig-input fp-sf-file', id: 'fp-sf-load', name: 'file', type: 'file'});
    var exec = el('input', {type: 'checkbox', id: 'fp-sf-exec', name: 'executable'});
    var note = el('p', {class: 'fp-muted fp-sf-bin', 'data-fp-bin': '', hidden: true});
    var cancel = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'sf-reset', text: t('sf_clear'), hidden: true});
    var form = el('form', {class: 'fp-form fp-mail-form fp-sf-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-sf-path', t('sf_path'), path, t('sf_path_hint')),
      M.field('fp-sf-text', t('sf_content'), text, t('sf_content_hint', {limit: size(SF.data.file_bytes)})), note,
      M.field('fp-sf-load', t('sf_load'), load, t('sf_load_hint')),
      el('label', {class: 'fp-check', for: 'fp-sf-exec'}, [exec, el('span', {text: t('sf_exec')})]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('sf_save')}), cancel])]);
    var binary = null;
    function setBinary(b, name) {
      binary = b;
      text.disabled = Boolean(b);
      if (b) { text.value = ''; }
      note.hidden = !b;
      note.textContent = b ? t('sf_binary', {name: name, size: size(b.bytes)}) : '';
    }
    SF.fill = function (f, content) {
      form.querySelector('[data-fp-error]').textContent = '';
      form.querySelector('[data-fp-error]').removeAttribute('aria-invalid');
      path.value = f.path;
      exec.checked = f.executable;
      load.value = '';
      cancel.hidden = false;
      if (content.base64 !== null && content.base64 !== undefined) {
        setBinary({base64: content.base64, bytes: f.size}, f.path);
      } else {
        setBinary(null);
        text.value = content.text || '';
      }
      M.say(form, '');
      path.focus();
      path.scrollIntoView({block: 'nearest'});
    };
    load.addEventListener('change', function () {
      var file = load.files && load.files[0];
      if (!file) { return; }
      M.start(form);
      if (file.size > SF.data.file_bytes) { M.fieldError(form, load, t('sf_too_big', {limit: size(SF.data.file_bytes)})); load.value = ''; return; }
      readFile(file, function (got) {
        if (!got) { M.fieldError(form, load, t('sf_read_failed')); return; }
        if (!path.value.trim()) { path.value = file.name; }
        if (got.text !== undefined) { setBinary(null); text.value = got.text; } else { setBinary(got, file.name); }
      });
    });
    form.addEventListener('click', function (e) {
      if (e.target.closest && e.target.closest('[data-fp-act="sf-reset"]')) {
        form.reset();
        setBinary(null);
        cancel.hidden = true;
        M.start(form);
        path.focus();
      }
    });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var p = path.value.trim().replace(/^\.\//, '');
      if (!pathOk(p)) { M.fieldError(form, path, t(p.charAt(0) === '/' ? 'sf_path_abs' : KEPT.test(p) ? 'sf_path_kept' : 'sf_path_bad')); return; }
      var body = {path: p, executable: exec.checked};
      if (binary) {
        body.base64 = binary.base64;
      } else {
        if (bytesOf(text.value) > SF.data.file_bytes) { M.fieldError(form, text, t('sf_too_big', {limit: size(SF.data.file_bytes)})); return; }
        body.text = text.value;
      }
      var page = SF.page;
      UI.setBusy(b, true);
      FP.call('put', 'starterFiles', body).then(function () {
        if (SF.page !== page) { return; }
        UI.setBusy(b, false);
        sfReload(t('sf_saved', {path: p}), true);
      }, function (err) {
        if (SF.page !== page) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return M.card('fp-sf-edit-h', t('sf_edit_title'), [el('p', {class: 'fp-muted', text: t('sf_edit_intro')}), form], 'fp-sf-editor');
  }
  function sfDraw(note) {
    SF.page.textContent = '';
    SF.page.appendChild(sfList());
    SF.page.appendChild(sfEditor());
    if (note) { M.say(SF.page.querySelector('.fp-sf-editor'), note); }
  }
  /* the list again after a change, with the editor emptied */
  function sfReload(note, focusEditor) {
    var page = SF.page;
    FP.call('get', 'starterFiles').then(function (r) {
      if (SF.page !== page) { return; }
      var d = cleanFiles(r);
      if (d) { SF.data = d; }
      sfDraw(note);
      if (focusEditor) { SF.page.querySelector('#fp-sf-path').focus(); }
    }, function (err) {
      if (SF.page === page) { M.fieldError(page.querySelector('.fp-sf-form'), null, err.message); }
    });
  }
  function sfAsk(btn) {
    var path = btn.getAttribute('data-fp-path');
    var cell = btn.closest('.fp-sf-acts');
    M.confirmIn(cell, t('sf_delete_ask', {path: path}), 'sf-delete-yes', t('sf_delete_yes'));
    cell.setAttribute('data-fp-path', path);
  }
  FP.view('tool:starter_files', function () {
    SF = {page: null, data: null, fill: null};
    var body = frame('starter_files');
    if (!body) { return; }
    SF.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'starterFiles').then(function (r) {
      if (SF.page !== body) { return; }
      SF.data = cleanFiles(r);
      if (!SF.data) { listFail(body, FP.tools.starter_files.label, {message: t('api_failed')}); return; }
      sfDraw('');
    }, function (err) {
      if (SF.page === body) { listFail(body, FP.tools.starter_files.label, err); }
    });
    body.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
      if (!b || SF.page !== body || !SF.data) { return; }
      var act = b.getAttribute('data-fp-act');
      var card = body.querySelector('.fp-sf-files');
      if (act === 'sf-edit') {
        var p = b.getAttribute('data-fp-path');
        UI.setBusy(b, true);
        FP.call('get', 'starterFile', undefined, {path: p}).then(function (r) {
          if (SF.page !== body) { return; }
          UI.setBusy(b, false);
          if (!r || typeof r !== 'object' || (typeof r.text !== 'string' && typeof r.base64 !== 'string')) { M.fieldError(card, null, t('api_failed')); return; }
          SF.fill({path: p, executable: r.executable === true, size: num(r.size)}, {text: typeof r.text === 'string' ? r.text : null, base64: typeof r.base64 === 'string' ? r.base64 : null});
        }, function (err) {
          if (SF.page !== body) { return; }
          UI.setBusy(b, false);
          M.fieldError(card, null, err.message);
        });
      } else if (act === 'sf-delete') {
        sfAsk(b);
      } else if (act === 'sf-delete-yes') {
        var cell = b.closest('.fp-sf-acts');
        var path = cell.getAttribute('data-fp-path');
        UI.setBusy(b, true);
        FP.call('del', 'starterFileDelete', undefined, {path: path}).then(function () {
          if (SF.page !== body) { return; }
          sfReload(t('sf_deleted', {path: path}), false);
        }, function (err) {
          if (SF.page !== body) { return; }
          UI.setBusy(b, false);
          M.fieldError(card, null, err.message);
        });
      } else if (act === 'confirm-no') {
        var row = b.closest('.fp-sf-row');
        var path2 = row ? row.getAttribute('data-fp-file') : '';
        sfDraw('');
        var back = body.querySelector('[data-fp-file="' + path2 + '"] [data-fp-act="sf-delete"]');
        if (back) { back.focus(); }
      }
    });
  });

  /* ================= Welcome message ================= */
  var WL = {page: null, data: null};
  function cleanWelcome(r) {
    if (!r || typeof r !== 'object' || typeof r.subject !== 'string' || typeof r.body !== 'string') { return null; }
    var p = r.preview && typeof r.preview === 'object' ? r.preview : {};
    return {enabled: r.enabled === true, subject: str(r.subject, 400), body: str(r.body, 12000), saved: r.saved === true,
      names: (Array.isArray(r.placeholders) ? r.placeholders : []).map(function (x) { return str(x, 30); }).filter(function (x) { return /^[a-z_]+$/.test(x); }),
      preview: {subject: str(p.subject, 400), body: str(p.body, 12000)}};
  }
  function wlPreview() {
    var d = WL.data;
    return M.card('fp-wlc-prev-h', t('wlc_prev_title'), [el('p', {class: 'fp-muted', text: t('wlc_prev_intro')}),
      el('div', {class: 'fp-wlc-mail', 'data-fp-preview': ''}, [el('p', {class: 'fp-wlc-subject'}, [el('b', {text: t('wlc_subject') + ':'}), el('span', {text: d.preview.subject})]),
        el('pre', {class: 'fp-wlc-text', text: d.preview.body})])], 'fp-wlc-prev');
  }
  function wlForm() {
    var d = WL.data;
    var on = el('input', {type: 'checkbox', id: 'fp-wlc-on', name: 'enabled', checked: d.enabled ? true : null});
    var subject = el('input', {class: 'sig-input', id: 'fp-wlc-subject', name: 'subject', type: 'text', maxlength: '150', autocomplete: 'off', value: d.subject});
    var text = el('textarea', {class: 'sig-input fp-wlc-body', id: 'fp-wlc-body', name: 'body', rows: '14', maxlength: '10000'});
    text.value = d.body;
    var counter = el('span', {class: 'sig-hint fp-wlc-counter', text: t('wlc_bytes', {n: count(bytesOf(d.body))})});
    var names = el('ul', {class: 'fp-wlc-names', 'aria-label': t('wlc_names_label')}, d.names.map(function (n) {
      return el('li', null, [el('code', {class: 'sig-mono', text: '{' + n + '}'}), el('span', {class: 'fp-muted', text: ' ' + t('wlc_name_' + n)})]);
    }));
    var ask = el('div', {class: 'fp-wlc-ask'});
    var form = el('form', {class: 'fp-form fp-mail-form fp-wlc-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('label', {class: 'fp-check fp-wlc-on', for: 'fp-wlc-on'}, [on, el('span', {text: t('wlc_on')})]),
      el('p', {class: 'sig-hint fp-wlc-onhint', text: t(d.enabled ? 'wlc_on_hint_on' : 'wlc_on_hint_off')}),
      M.field('fp-wlc-subject', t('wlc_subject'), subject, t('wlc_subject_hint')),
      M.field('fp-wlc-body', t('wlc_body'), text, t('wlc_body_hint')), counter,
      el('p', {class: 'fp-muted fp-wlc-names-h', text: t('wlc_names_title')}), names,
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('wlc_save')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'wlc-default', text: t('wlc_default'), disabled: d.saved ? null : true})]), ask]);
    text.addEventListener('input', function () { counter.textContent = t('wlc_bytes', {n: count(bytesOf(text.value))}); });
    function body() {
      var s = subject.value.trim();
      var b = text.value;
      var empty = !s && !b.trim();
      if (!empty) {
        if (!s || Array.from(s).length > 150 || /[\u0000-\u001f\u007f]/.test(s)) { M.fieldError(form, subject, t('wlc_subject_bad')); return null; }   // eslint-disable-line no-control-regex -- one printable line
        if (!b.trim()) { M.fieldError(form, text, t('wlc_body_missing')); return null; }
        if (bytesOf(b) > 10000 || /[\u0000-\u0008\u000b-\u001f\u007f]/.test(b)) { M.fieldError(form, text, t(bytesOf(b) > 10000 ? 'wlc_body_long' : 'wlc_body_bad')); return null; }   // eslint-disable-line no-control-regex -- text only
        var bad = null;
        (s + '\n' + b).replace(/\{([A-Za-z_]*)\}/g, function (m, name) { if (!bad && d.names.indexOf(name) < 0) { bad = m; } return m; });
        if (bad) { M.fieldError(form, (b.indexOf(bad) >= 0 ? text : subject), t('wlc_name_bad', {name: bad})); return null; }
      }
      return {enabled: on.checked, subject: s, body: empty ? '' : b};
    }
    function put(payload, note, b) {
      var page = WL.page;
      UI.setBusy(b, true);
      FP.call('put', 'serverWelcome', payload).then(function (r) {
        if (WL.page !== page) { return; }
        var fresh = cleanWelcome(r);
        if (!fresh) { UI.setBusy(b, false); M.fieldError(form, null, t('api_failed')); return; }
        WL.data = fresh;
        wlDraw(note(fresh));
      }, function (err) {
        if (WL.page !== page) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    }
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var payload = body();
      if (!payload) { return; }
      put(payload, function (fresh) { return t(fresh.enabled ? 'wlc_saved_on' : 'wlc_saved_off'); }, b);
    });
    form.addEventListener('click', function (e) {
      var def = e.target.closest ? e.target.closest('[data-fp-act="wlc-default"]') : null;
      var yes = e.target.closest ? e.target.closest('[data-fp-act="wlc-default-yes"]') : null;
      var no = e.target.closest ? e.target.closest('[data-fp-act="confirm-no"]') : null;
      if (def && !def.disabled) {
        M.start(form);
        M.confirmIn(ask, t('wlc_default_ask'), 'wlc-default-yes', t('wlc_default_yes'));
      } else if (yes) {
        put({subject: '', body: ''}, function () { return t('wlc_default_done'); }, yes);
      } else if (no) {
        ask.textContent = '';
        form.querySelector('[data-fp-act="wlc-default"]').focus();
      }
    });
    return M.card('fp-wlc-form-h', t('wlc_form_title'), [form], 'fp-wlc-edit');
  }
  function wlDraw(note) {
    WL.page.textContent = '';
    WL.page.appendChild(wlForm());
    WL.page.appendChild(wlPreview());
    if (note) { M.say(WL.page.querySelector('.fp-wlc-edit'), note); }
  }
  FP.view('tool:welcome_message', function () {
    WL = {page: null, data: null};
    var body = frame('welcome_message');
    if (!body) { return; }
    WL.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'serverWelcome').then(function (r) {
      if (WL.page !== body) { return; }
      WL.data = cleanWelcome(r);
      if (!WL.data) { listFail(body, FP.tools.welcome_message.label, {message: t('api_failed')}); return; }
      wlDraw('');
    }, function (err) {
      if (WL.page === body) { listFail(body, FP.tools.welcome_message.label, err); }
    });
  });

  /* ================= Suspended page ================= */
  var SP = {page: null, data: null, kind: 'suspended'};
  var SP_KINDS = ['suspended', 'default', 'over_limit'];
  /* the suspended page has its own path; the default host and over-limit pages share one */
  function spCall(method, body) {
    return SP.kind === 'suspended' ? FP.call(method, 'suspendedPage', body) : FP.call(method, 'sitePage', body, {page: SP.kind});
  }
  function spLoad(body, note) {
    var kind = SP.kind;
    spCall('get').then(function (r) {
      if (SP.page !== body || SP.kind !== kind) { return; }
      SP.data = cleanSuspended(r);
      if (!SP.data) { listFail(body, FP.tools.suspended_page.label, {message: t('api_failed')}); return; }
      spDraw(note || '');
    }, function (err) {
      if (SP.page === body && SP.kind === kind) { listFail(body, FP.tools.suspended_page.label, err); }
    });
  }
  function cleanSuspended(r) {
    if (!r || typeof r !== 'object' || typeof r.html !== 'string' || typeof r.default !== 'string') { return null; }
    return {custom: r.custom === true, html: r.html.slice(0, 70000), def: r.default.slice(0, 70000), max: num(r.max_bytes) || 65536};
  }
  function spDraw(note) {
    var d = SP.data;
    var text = el('textarea', {class: 'sig-input sig-mono fp-susp-text', id: 'fp-susp-html', name: 'html', rows: '18', spellcheck: 'false', wrap: 'off'});
    text.value = d.html;
    var counter = el('span', {class: 'sig-hint fp-susp-counter', 'aria-live': 'off', text: t('susp_bytes', {n: count(bytesOf(d.html)), max: count(d.max)})});
    var ask = el('div', {class: 'fp-susp-ask'});
    var form = el('form', {class: 'fp-form fp-mail-form fp-susp-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-susp-html', t('susp_html'), text, t('susp_html_hint')), counter,
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('susp_save')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'susp-start', text: t('susp_start')}),
        el('button', {class: 'sig-btn sig-btn--secondary fp-btn-danger-text', type: 'button', 'data-fp-act': 'susp-reset', disabled: d.custom ? null : true, text: t('susp_reset')})]), ask]);
    text.addEventListener('input', function () { counter.textContent = t('susp_bytes', {n: count(bytesOf(text.value)), max: count(d.max)}); });
    function done(r, message, b) {
      var fresh = cleanSuspended(r);
      if (!fresh) { UI.setBusy(b, false); M.fieldError(form, null, t('api_failed')); return; }
      SP.data = fresh;
      spDraw(message);
      SP.page.querySelector('#fp-susp-h').focus();
    }
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      ask.textContent = '';
      if (!text.value.trim()) { M.fieldError(form, text, t('susp_empty')); return; }
      if (bytesOf(text.value) > d.max) { M.fieldError(form, text, t('susp_long', {max: count(d.max)})); return; }
      if (text.value.indexOf('\u0000') >= 0) { M.fieldError(form, text, t('susp_nul')); return; }
      var page = SP.page;
      UI.setBusy(b, true);
      M.say(form, t('susp_working'));
      spCall('put', {html: text.value}).then(function (r) {
        if (SP.page === page) { done(r, t(SP.kind === 'suspended' ? 'susp_saved' : 'susp_saved_other'), b); }
      }, function (err) {
        if (SP.page !== page) { return; }
        UI.setBusy(b, false);
        M.say(form, '');
        M.failed(form, err);
      });
    });
    form.addEventListener('click', function (e) {
      var start = e.target.closest ? e.target.closest('[data-fp-act="susp-start"]') : null;
      var reset = e.target.closest ? e.target.closest('[data-fp-act="susp-reset"]') : null;
      var yes = e.target.closest ? e.target.closest('[data-fp-act="susp-reset-yes"]') : null;
      var no = e.target.closest ? e.target.closest('[data-fp-act="confirm-no"]') : null;
      if (start) {
        text.value = d.def;
        text.dispatchEvent(new window.Event('input'));
        M.start(form);
        M.say(form, t('susp_started'));
        text.focus();
      } else if (reset && !reset.disabled) {
        M.start(form);
        M.confirmIn(ask, t('susp_reset_ask'), 'susp-reset-yes', t('susp_reset_yes'));
      } else if (yes) {
        var page = SP.page;
        UI.setBusy(yes, true);
        spCall('del').then(function (r) {
          if (SP.page === page) { done(r, t(SP.kind === 'suspended' ? 'susp_reset_done' : 'susp_reset_done_other'), yes); }
        }, function (err) {
          if (SP.page !== page) { return; }
          UI.setBusy(yes, false);
          ask.textContent = '';
          M.failed(form, err);
        });
      } else if (no) {
        ask.textContent = '';
        form.querySelector('[data-fp-act="susp-reset"]').focus();
      }
    });
    SP.page.textContent = '';
    var which = el('select', {class: 'sig-select', id: 'fp-susp-kind', name: 'page'}, SP_KINDS.map(function (k) {
      return el('option', {value: k, text: t('susp_kind_' + k), selected: k === SP.kind ? true : null});
    }));
    which.addEventListener('change', function () {
      SP.kind = SP_KINDS.indexOf(which.value) >= 0 ? which.value : 'suspended';
      var body = SP.page;
      spLoad(body);
    });
    SP.page.appendChild(el('div', {class: 'fp-form fp-susp-which'}, [M.field('fp-susp-kind', t('susp_which'), which, t('susp_which_hint'))]));
    SP.page.appendChild(el('div', {class: 'sig-banner fp-susp-state', role: 'note', 'data-fp-state': d.custom ? 'custom' : 'default'},
      [UI.icon(FP.ui, 'ui_info'), el('span', {text: t(d.custom ? 'susp_state_custom' : 'susp_state_default')})]));
    SP.page.appendChild(M.card('fp-susp-h', t('susp_title'), [el('p', {class: 'fp-muted', text: t(SP.kind === 'suspended' ? 'susp_intro' : 'susp_intro_' + SP.kind)}), form], 'fp-susp-card'));
    if (note) { M.say(SP.page.querySelector('.fp-susp-card'), note); }
  }
  FP.view('tool:suspended_page', function () {
    SP = {page: null, data: null, kind: 'suspended'};
    var body = frame('suspended_page');
    if (!body) { return; }
    SP.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    spLoad(body);
  });
})();

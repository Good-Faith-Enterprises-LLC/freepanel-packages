/* freePanel: change your own contact address (docs/api.md, POST /auth/email), the same page in both panels:
   Preferences > Contact details in the customer panel (#/tool/contact), Security > My contact address in the admin
   panel (#/tool/my_contact). Reset links and notices go to this address. Like a password change, it asks for the
   current password, and wrong guesses count against the sign-in limit. An empty address clears it. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var EMAIL_RE = /^[^\s@,;"<>]+@[^\s@,;"<>]+\.[^\s@,;"<>]+$/;

  var page = null;
  function current() { return (FP.session && FP.session.user && FP.session.user.email) || ''; }
  function mark(form, input, message) {
    UI.showError(form, message);
    input.setAttribute('aria-invalid', 'true');
    input.focus();
  }
  function nowLine() {
    var now = current();
    return now ? el('p', {class: 'fp-ct-now', 'data-fp-now': ''}, [el('span', {text: t('ct_now')}), el('strong', {class: 'fp-ct-addr', text: now})])
      : el('p', {class: 'fp-ct-now', 'data-fp-now': ''}, [el('span', {text: t('ct_none')})]);
  }

  function render() {
    var pw = el('input', {class: 'sig-input', id: 'fp-ct-current', name: 'current_password', type: 'password', autocomplete: 'current-password',
      maxlength: '1024', spellcheck: 'false', autocapitalize: 'none'});
    var email = el('input', {class: 'sig-input', id: 'fp-ct-email', name: 'email', type: 'email', autocomplete: 'email', maxlength: '254',
      spellcheck: 'false', autocapitalize: 'none', 'aria-describedby': 'fp-ct-email-hint'});
    email.value = current();
    var form = el('form', {class: 'fp-form fp-ct-form', novalidate: ''}, [
      el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': ''}),
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: 'fp-ct-email', text: t('ct_email')}), email,
        el('span', {class: 'sig-hint', id: 'fp-ct-email-hint', text: t('ct_email_hint')})]),
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: 'fp-ct-current', text: t('pw_current')}),
        el('div', {class: 'fp-reveal-wrap'}, [pw, el('button', {class: 'sig-ghost fp-reveal', type: 'button', 'data-overlap-ok': '',
          'data-fp-reveal': 'fp-ct-current', 'aria-pressed': 'false', 'aria-label': 'Show password'}, [UI.icon(FP.ui, 'ui_eye')])])]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('ct_save')})])]);
    var status = el('p', {class: 'fp-ok-line', role: 'status', 'data-fp-status': ''});
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = form.querySelector('.fp-submit');
      if (b.disabled) { return; }
      var next = email.value.trim();
      UI.showError(form, '');
      status.textContent = '';
      [pw, email].forEach(function (i) { i.removeAttribute('aria-invalid'); });
      if (next && !EMAIL_RE.test(next)) { mark(form, email, t('acct_bad_email')); return; }
      if (next === current()) { mark(form, email, next ? t('ct_same') : t('ct_same_none')); return; }
      if (!pw.value) { mark(form, pw, t('pw_need_current')); return; }
      UI.setBusy(b, true);
      FP.call('post', 'email', {current_password: pw.value, email: next}).then(function () {
        UI.setBusy(b, false);
        pw.value = '';
        email.value = next;
        FP.session.user.email = next;
        page.querySelector('[data-fp-now]').replaceWith(nowLine());
        status.textContent = next ? t('ct_saved', {email: next}) : t('ct_cleared');
        page.querySelector('#fp-ct-h').focus();
      }, function (err) {
        UI.setBusy(b, false);
        if (err.code === 'forbidden') {
          pw.value = '';
          mark(form, pw, t('pw_wrong_current'));
        } else if (err.code === 'validation_failed' && err.field === 'email') {
          mark(form, email, t('ct_email') + ': ' + err.message);
        } else {
          UI.showError(form, err.message);
        }
      });
    });
    page.textContent = '';
    page.appendChild(el('section', {class: 'sig-card fp-ct-card', 'aria-labelledby': 'fp-ct-h'}, [el('div', {class: 'sig-card-body'}, [
      el('h2', {class: 'fp-h2', id: 'fp-ct-h', tabindex: '-1', text: t('ct_title')}),
      nowLine(), el('p', {class: 'fp-muted', text: t('ct_note')}), status, form])]));
  }

  function view(id, realm) {
    FP.view('tool:' + id, function () {
      page = null;
      var tool = FP.tools[id];
      if (!tool || FP.realm !== realm) { FP.views['not-found']({view: 'not-found'}); return; }
      var g = FP.group(tool.group);
      page = FP.frame({title: tool.label, desc: t('ct_desc'), cls: 'fp-ct',
        crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
      render();
    });
  }
  view('contact', 'user');
  view('my_contact', 'admin');
})();

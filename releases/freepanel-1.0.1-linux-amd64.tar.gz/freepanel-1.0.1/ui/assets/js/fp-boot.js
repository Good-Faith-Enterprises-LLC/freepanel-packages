/* freePanel first paint: apply the stored colour mode and the folded main menu before anything is drawn, so the
   page never flashes the other way. Loaded without defer in <head>; external so a strict CSP needs no inline script. */
(function () {
  'use strict';
  var root = document.documentElement;
  try {
    var mode = window.localStorage.getItem('fp.mode');
    if (mode === 'light' || mode === 'dark') { root.setAttribute('data-sig-mode', mode); }
    if (window.localStorage.getItem('fp.side') === 'collapsed') { root.setAttribute('data-sig-side', 'collapsed'); }
  } catch (e) { /* storage blocked: system mode, open menu */ }
})();

/* freePanel SSH settings in the admin panel (docs/api.md, "SSH settings" and "SSH port"): #/tool/ssh_settings shows what sshd uses now
   (it is asked, so this is the truth and not what a file says), changes password sign-in and root sign-in through the panel's own
   drop-in, and moves the port in two steps with a way back: open the new port beside the old, sign in on it from a second terminal,
   confirm, or let the server undo it after ten minutes. Admin only: the server refuses these calls to anyone else. Everything the
   server sends is shown as text. The pieces of a page come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var ROOT = ['yes', 'prohibit-password', 'forced-commands-only', 'no'];
  /* the settings the form changes: the API's name, its choices, and the word for "leave it to sshd's other files" */
  var SETTINGS = [{key: 'password_authentication', id: 'password', label: 'shs_f_password', hint: 'shs_f_password_hint', choices: ['on', 'off']},
    {key: 'permit_root_login', id: 'root', label: 'shs_f_root', hint: 'shs_f_root_hint', choices: ROOT}];
  var GUARDS = {no_ssh_key: true, no_sudo_user: true};

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function port(v) { return typeof v === 'number' && isFinite(v) && Math.floor(v) === v && v >= 1 && v <= 65535 ? v : 0; }
  function ports(a) { return (Array.isArray(a) ? a : []).map(port).filter(Boolean).slice(0, 20); }
  function iso(v) { return typeof v === 'string' ? v.slice(0, 40) : ''; }
  function when(v) {
    var d = new Date(iso(v));
    return isNaN(d.getTime()) ? '' : d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'});
  }
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var fp = r.effective_from_panel && typeof r.effective_from_panel === 'object' ? r.effective_from_panel : {};
    var p = r.pending_port && typeof r.pending_port === 'object' && port(r.pending_port.port) ? r.pending_port : null;
    var l = r.last_port_change && typeof r.last_port_change === 'object' && port(r.last_port_change.port) ? r.last_port_change : null;
    return {supported: r.supported !== false, reason: str(r.reason), ports: ports(r.ports),
      password: r.password_authentication === true, root: ROOT.indexOf(r.permit_root_login) >= 0 ? r.permit_root_login : '', empty: r.permit_empty_passwords === true,
      fromPanel: {password_authentication: fp.password_authentication === true, permit_root_login: fp.permit_root_login === true},
      socket: r.socket_activated === true, service: /^[A-Za-z0-9_.@-]{1,40}$/.test(str(r.service, 40)) ? r.service : '', problem: str(r.problem),
      pending: p ? {port: port(p.port), revertAt: iso(p.revert_at), oldPorts: ports(p.old_ports)} : null,
      last: l ? {port: port(l.port), outcome: str(l.outcome, 60), at: iso(l.at), problem: str(l.problem)} : null,
      notes: (Array.isArray(r.notes) ? r.notes : []).filter(function (n) { return typeof n === 'string' && n; }).slice(0, 6).map(function (n) { return n.slice(0, 300); })};
  }

  var page = null;
  var V = null;          /* what the server says about SSH, cleaned */
  var notes = [];        /* what the server said should be done by hand after the last change */

  function pill(kind, text) { return el('span', {class: 'sig-pill' + (kind ? ' sig-pill--' + kind : ''), text: text}); }
  function banner(text, attr) {
    var b = el('div', {class: 'sig-banner sig-banner--warn', role: 'note'}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: text})]);
    if (attr) { b.setAttribute(attr, ''); }
    return b;
  }
  function rootText(v) { return t('shs_root_' + v.replace(/-/g, '_')); }
  function portList(list) { return list.length ? list.join(', ') : '–'; }

  /* ---- what sshd uses now ---- */
  function row(label, content) { return el('div', null, [el('dt', {text: label}), el('dd', null, content)]); }
  function whereText(on) { return t(on ? 'shs_set_here' : 'shs_set_elsewhere'); }
  function nowCard() {
    var parts = [];
    if (V.problem) { parts.push(banner(t('shs_problem', {problem: V.problem}), 'data-fp-shs-problem')); }
    if (V.socket) { parts.push(el('p', {class: 'fp-muted', 'data-fp-shs-socket': '', text: t('shs_socket', {service: V.service || 'ssh'})})); }
    if (!V.problem) {
      var rootKind = V.root === 'yes' ? 'warn' : (V.root === 'no' ? 'ok' : '');
      parts.push(el('dl', {class: 'fp-shs-facts'}, [
        row(t('shs_service'), [el('span', {class: 'sig-mono', text: V.service || '–'})]),
        row(t('shs_ports'), [el('span', {class: 'sig-mono', 'data-fp-shs-ports': '', text: portList(V.ports)})]),
        row(t('shs_password'), [pill(V.password ? '' : 'ok', t(V.password ? 'shs_o_on' : 'shs_o_off')), el('span', {class: 'fp-muted fp-shs-where', text: whereText(V.fromPanel.password_authentication)})]),
        row(t('shs_root'), [pill(rootKind, V.root ? rootText(V.root) : '–'), el('span', {class: 'fp-muted fp-shs-where', text: whereText(V.fromPanel.permit_root_login)})]),
        row(t('shs_empty'), [pill(V.empty ? 'warn' : 'ok', t(V.empty ? 'shs_o_on' : 'shs_o_off'))])]));
    }
    parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'look', text: t('sec_look_again')})]),
      M.errorLine(), M.statusLine());
    return M.card('fp-shs-now-h', t('shs_now_title'), parts, 'fp-shs-now');
  }

  /* ---- the sign-in settings ---- */
  function choiceText(s, c) { return s.id === 'root' ? rootText(c) : t(c === 'on' ? 'shs_o_on' : 'shs_o_off'); }
  function valueOf(s) {
    if (!V.fromPanel[s.key]) { return 'inherit'; }
    return s.id === 'root' ? V.root : (V.password ? 'on' : 'off');
  }
  function settingsCard() {
    var selects = {};
    var fields = SETTINGS.map(function (s) {
      var id = 'fp-shs-' + s.id;
      var opts = s.choices.map(function (c) { return el('option', {value: c, text: choiceText(s, c)}); }).concat([el('option', {value: 'inherit', text: t('shs_o_inherit')})]);
      var select = el('select', {class: 'sig-select', id: id, name: s.key, 'aria-describedby': id + '-hint'}, opts);
      select.value = valueOf(s);
      selects[s.key] = select;
      return el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: id, text: t(s.label)}), select, el('span', {class: 'sig-hint', id: id + '-hint', text: t(s.hint)})]);
    });
    var actions = el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('shs_save')})]);
    var form = el('form', {class: 'fp-form fp-shs-form', novalidate: ''}, [M.errorLine(), M.statusLine()].concat(fields, [actions]));

    /* only what the admin changed is sent: a setting left as it was is not named, so the others cannot be turned back by it */
    function read() {
      var body = {};
      var inherit = [];
      SETTINGS.forEach(function (s) {
        var v = selects[s.key].value;
        if (v === valueOf(s)) { return; }
        if (v === 'inherit') { inherit.push(s.key); } else { body[s.key] = s.id === 'root' ? v : v === 'on'; }
      });
      if (inherit.length) { body.inherit = inherit; }
      return Object.keys(body).length ? body : null;
    }
    function restoreActions() {
      var now = form.querySelector('.fp-actions');
      if (now !== actions) { now.replaceWith(actions); }
    }
    function save(body, b) {
      var mine = page;
      UI.setBusy(b, true);
      FP.call('put', 'sshSettings', body).then(function (r) {
        if (page !== mine) { return; }
        V = clean(r);
        notes = V.notes;
        draw(['now', 'settings', 'port'], {say: ['settings', t('shs_saved')], focus: '#fp-shs-password'});
      }, function (err) {
        if (page !== mine) { return; }
        UI.setBusy(b, false);
        restoreActions();
        /* two guards keep an admin from locking themselves out: the server says what it found, and the admin may go ahead anyway */
        if (err && err.status === 409 && GUARDS[err.field] && !body.force) {
          UI.showError(form, err.message);
          askForce(body);
          return;
        }
        M.failed(form, err);
      });
    }
    function askForce(body) {
      var yes = el('button', {class: 'sig-btn sig-btn--danger', type: 'button', 'data-fp-act': 'force-yes', text: t('shs_force_yes')});
      var no = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'force-no', text: t('cancel')});
      var q = el('div', {class: 'fp-actions fp-shs-ask'}, [el('p', {class: 'fp-shs-confirm', id: 'fp-shs-force-ask', text: t('shs_force_ask')}), yes, no]);
      yes.setAttribute('aria-describedby', 'fp-shs-force-ask');
      no.setAttribute('aria-describedby', 'fp-shs-force-ask');
      yes.addEventListener('click', function () { save(Object.assign({}, body, {force: true}), yes); });
      no.addEventListener('click', function () { restoreActions(); UI.showError(form, ''); form.querySelector('.fp-submit').focus(); });
      actions.replaceWith(q);
      no.focus();
    }
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var body = read();
      if (!body) { UI.showError(form, t('shs_nothing')); return; }
      save(body, b);
    });
    return M.card('fp-shs-settings-h', t('shs_settings_title'), [el('p', {class: 'fp-muted', text: t('shs_settings_what')}), form], 'fp-shs-settings');
  }

  /* ---- the port ---- */
  function pendingBox() {
    var p = V.pending;
    var old = portList(p.oldPorts);
    var at = when(p.revertAt);
    var confirm = el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'port-confirm', text: t('shs_port_confirm', {port: p.port})});
    var revert = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'port-revert', text: t('shs_port_revert')});
    return el('div', {class: 'fp-shs-pending', 'data-fp-shs-pending': String(p.port)}, [
      el('h3', {class: 'fp-h3', text: t('shs_pending_title', {port: p.port, old: old})}),
      el('ol', {class: 'fp-shs-steps'}, [el('li', {text: t('shs_step_1', {port: p.port})}), el('li', {text: t('shs_step_2', {port: p.port})}),
        el('li', {text: at ? t('shs_step_3', {when: at}) : t('shs_step_3_soon')})]),
      el('div', {class: 'fp-actions fp-shs-port-acts'}, [confirm, revert])]);
  }
  function lastText(l) {
    var at = when(l.at);
    return t('shs_last', {port: l.port, outcome: l.outcome || '–'}) + (at ? ' ' + t('shs_last_at', {when: at}) : '') + (l.problem ? ' ' + l.problem : '');
  }
  function portCard() {
    var parts = [el('p', {class: 'fp-muted', text: t('shs_port_what')}), M.statusLine()];
    if (notes.length) { parts.push(el('ul', {class: 'fp-shs-notes', 'data-fp-shs-notes': ''}, notes.map(function (n) { return el('li', {text: n}); }))); }
    if (V.pending) {
      /* a waiting change has no form: its error line is the card's */
      parts.push(M.errorLine(), pendingBox());
    } else {
      var input = el('input', {class: 'sig-input fp-num-input', id: 'fp-shs-port', name: 'port', type: 'number', inputmode: 'numeric', min: '22', max: '65535', step: '1', 'aria-describedby': 'fp-shs-port-hint'});
      var form = el('form', {class: 'fp-form fp-shs-portform', novalidate: ''}, [M.field('fp-shs-port', t('shs_port_field'), input, t('shs_port_hint')),
        el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('shs_port_open')})])]);
      form.insertBefore(M.errorLine(), form.firstChild);
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var b = M.start(form);
        if (!b) { return; }
        var v = input.value.trim();
        var n = /^[0-9]{1,5}$/.test(v) ? Number(v) : 0;
        if (n !== 22 && (n < 1024 || n > 65535)) { M.fieldError(form, input, t('shs_port_bad')); return; }
        var mine = page;
        UI.setBusy(b, true);
        FP.call('put', 'sshPort', {port: n}).then(function (r) {
          if (page !== mine) { return; }
          notes = [];
          var waiting = clean({pending_port: r && r.pending_port}).pending;
          /* the answer is the waiting change alone: the settings are read again, so the ports show both */
          return FP.call('get', 'ssh').then(clean, function () { return null; }).then(function (fresh) {
            if (page !== mine) { return; }
            if (fresh) { V = fresh; }
            if (!V.pending) { V.pending = waiting; }
            draw(['now', 'port'], {say: ['port', t('shs_port_opened', {port: n})], focus: '[data-fp-act="port-confirm"]'});
          });
        }, function (err) {
          if (page !== mine) { return; }
          UI.setBusy(b, false);
          /* a refusal that names a reason (a port in use, one the server keeps, a Port line in another file) is about the port */
          if (err && err.status === 409) { M.fieldError(form, input, err.message); } else { M.failed(form, err); }
        });
      });
      parts.push(form);
    }
    if (V.last) { parts.push(el('p', {class: 'fp-muted fp-shs-last', 'data-fp-shs-last': '', text: lastText(V.last)})); }
    return M.card('fp-shs-port-h', t('shs_port_title'), parts, 'fp-shs-port');
  }

  var CARDS = {now: nowCard, settings: settingsCard, port: portCard};

  /* ---- drawing ---- */
  function build(name) {
    var node = CARDS[name]();
    node.setAttribute('data-fp-card', name);
    return node;
  }
  function drawAll() {
    page.textContent = '';
    if (!V.supported) {
      page.appendChild(FP.empty(t('shs_unsupported_title'), V.reason || t('shs_unsupported')));
      return;
    }
    page.appendChild(build('now'));
    if (!V.problem) { page.appendChild(build('settings')); page.appendChild(build('port')); }
  }
  /* redraws the cards named; opts.say is [card, text] for that card's status line, opts.focus a selector for the control that takes focus */
  function draw(names, opts) {
    opts = opts || {};
    if (!V.supported || V.problem) { drawAll(); return; }
    names.forEach(function (name) {
      var old = page.querySelector('[data-fp-card="' + name + '"]');
      if (old) { old.replaceWith(build(name)); }
    });
    if (opts.say) { M.say(page.querySelector('[data-fp-card="' + opts.say[0] + '"]'), opts.say[1]); }
    var target = opts.focus ? page.querySelector(opts.focus) : null;
    if (target) { target.focus(); }
  }

  function onClick(e) {
    var node = e.target.closest ? e.target : null;
    var b = node && node.closest('[data-fp-act]');
    if (!b || !page || !page.contains(b) || !V) { return; }
    var a = b.getAttribute('data-fp-act');
    var mine = page;
    var portCardNode = function () { return page.querySelector('[data-fp-card="port"]'); };
    if (a === 'look') {
      UI.setBusy(b, true);
      FP.call('get', 'ssh').then(function (r) {
        if (page !== mine) { return; }
        V = clean(r);
        draw(['now', 'settings', 'port'], {say: ['now', t('shs_looked')], focus: '[data-fp-card="now"] [data-fp-act="look"]'});
        if (!V.supported || V.problem) { M.say(page.querySelector('[data-fp-card="now"]'), t('shs_looked')); }
      }, function (err) {
        if (page !== mine) { return; }
        UI.setBusy(b, false);
        UI.showError(page.querySelector('[data-fp-card="now"]'), err.message);
        b.focus();
      });
    } else if (a === 'port-confirm') {
      M.confirmIn(b.parentNode, t('shs_confirm_ask', {port: V.pending ? V.pending.port : '', old: V.pending ? portList(V.pending.oldPorts) : ''}), 'port-confirm-yes', t('shs_confirm_yes'));
    } else if (a === 'confirm-no') {
      draw(['port']);
      var again = page.querySelector('[data-fp-act="port-confirm"]');
      if (again) { again.focus(); }
    } else if (a === 'port-confirm-yes' || a === 'port-revert') {
      var confirming = a === 'port-confirm-yes';
      UI.setBusy(b, true);
      var call = confirming ? FP.call('post', 'sshPortConfirm', {}) : FP.call('del', 'sshPort');
      call.then(function (r) {
        if (page !== mine) { return; }
        V = clean(r);
        notes = confirming ? V.notes : [];
        draw(['now', 'settings', 'port'], {say: ['port', t(confirming ? 'shs_port_confirmed' : 'shs_port_reverted')], focus: '#fp-shs-port'});
      }, function (err) {
        if (page !== mine) { return; }
        draw(['port']);
        UI.showError(portCardNode(), err.message);
        var back = page.querySelector('[data-fp-act="port-confirm"]');
        /* nothing was waiting any more (the timer undid it): the settings are read again so the page says what is so */
        if (err && err.status === 409 && err.field === 'no_pending_port') {
          FP.call('get', 'ssh').then(function (x) { V = clean(x); draw(['now', 'settings', 'port']); UI.showError(page.querySelector('[data-fp-card="port"]'), err.message); }, function () { return null; });
        } else if (back) { back.focus(); }
      });
    }
  }
  document.addEventListener('click', onClick);

  FP.view('tool:ssh_settings', function () {
    var tool = FP.tools.ssh_settings;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    V = null;
    notes = [];
    var mine = FP.frame({title: tool.label, desc: t('shs_desc'), cls: 'fp-mail fp-srv fp-shs-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    page = mine;
    mine.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'ssh').then(function (r) {
      if (page !== mine) { return; }
      V = clean(r);
      drawAll();
    }, function (err) {
      if (page !== mine) { return; }
      mine.textContent = '';
      mine.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

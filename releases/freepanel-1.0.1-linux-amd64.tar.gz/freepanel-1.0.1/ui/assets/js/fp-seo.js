/* freePanel search engine files (docs/api.md, "Redirects and search engines"): the customer panel's page (#/tool/seo_files) for a website's
   robots.txt and sitemap.xml. The server reads and writes them in the website's folder as the account, through the file manager; this page offers
   ready-made robots.txt text and a sitemap made from a list of pages, and shows what the files hold. Everything the server sends is shown as text.
   The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var DOMAIN_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var PAGE_RE = /^\/[A-Za-z0-9._~!$&'()*+,;=:@/%-]{0,1023}$/;
  var MAX_ROBOTS = 64 * 1024;
  var MAX_PAGES = 1000;
  var FREQS = ['', 'always', 'hourly', 'daily', 'weekly', 'monthly', 'yearly', 'never'];

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  function file(v) {
    v = v && typeof v === 'object' ? v : {};
    return {file: str(v.file, 1024), exists: v.exists === true, text: str(v.text, 300000), tooLarge: v.too_large === true};
  }
  function clean(v) {
    v = v && typeof v === 'object' ? v : {};
    var base = /^https?:\/\/[a-z0-9.-]{1,253}$/.test(str(v.base, 300)) ? v.base : '';
    var pages = (Array.isArray(v.pages) ? v.pages : []).filter(function (p) { return typeof p === 'string' && PAGE_RE.test(p); }).slice(0, MAX_PAGES);
    var listed = (Array.isArray(v.sitemap_urls) ? v.sitemap_urls : []).filter(function (u) { return typeof u === 'string'; }).map(function (u) { return u.slice(0, 2048); }).slice(0, MAX_PAGES);
    return {base: base, robots: file(v.robots), sitemap: file(v.sitemap), pages: pages, listed: listed};
  }
  function sitesOf(v) {
    return (v && Array.isArray(v.sites) ? v.sites : []).map(function (s) { return s && s.domain; }).filter(function (d) { return typeof d === 'string' && DOMAIN_RE.test(d); }).sort();
  }

  var P = {page: null, account: '', sites: [], site: '', state: null};

  /* ready-made robots.txt text */
  function preset(kind, base) {
    if (kind === 'allow') { return 'User-agent: *\nDisallow:\n'; }
    if (kind === 'block') { return 'User-agent: *\nDisallow: /\n'; }
    return base ? 'Sitemap: ' + base + '/sitemap.xml\n' : '';
  }
  function robotsCard(v) {
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t('seo_robots_note')}),
      el('p', {class: 'fp-muted fp-seo-file'}, [el('span', {text: t('seo_file') + ' '}), el('span', {class: 'sig-mono', text: v.robots.file || 'robots.txt'}),
        el('span', {class: 'sig-pill fp-seo-state ' + (v.robots.exists ? 'sig-pill--ok' : ''), text: t(v.robots.exists ? 'seo_exists' : 'seo_missing')})])];
    if (v.robots.tooLarge) {
      parts.push(M.suspendedBanner(t('seo_too_large')));
      return M.card('fp-seo-robots-h', t('seo_robots_title'), parts, 'fp-seo-robots');
    }
    var text = el('textarea', {class: 'sig-input sig-mono fp-seo-text', id: 'fp-seo-robots', name: 'text', rows: '10', spellcheck: 'false', wrap: 'off',
      autocapitalize: 'none', maxlength: String(MAX_ROBOTS)});
    text.value = v.robots.text;
    var form = el('form', {class: 'fp-form fp-mail-form fp-seo-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-seo-robots', t('seo_robots_text'), text, t('seo_robots_hint')),
      el('div', {class: 'fp-seo-presets', role: 'group', 'aria-label': t('seo_presets')}, [
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-seo-preset': 'allow', text: t('seo_preset_allow')}),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-seo-preset': 'block', text: t('seo_preset_block')}),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-seo-preset': 'sitemap', text: t('seo_preset_sitemap')})]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('seo_robots_save')})])]);
    form.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('[data-fp-seo-preset]') : null;
      if (!b) { return; }
      var kind = b.getAttribute('data-fp-seo-preset');
      if (kind === 'sitemap') {
        var line = preset('sitemap', v.base);
        if (text.value.indexOf(line.trim()) < 0) { text.value = text.value.replace(/\n*$/, text.value ? '\n' : '') + line; }
      } else {
        var keep = text.value.split('\n').filter(function (l) { return /^sitemap:/i.test(l.trim()); }).join('\n');
        text.value = preset(kind, v.base) + (keep ? keep + '\n' : '');
      }
      M.say(form, t('seo_preset_done'));
      text.focus();
    });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      if (new window.TextEncoder().encode(text.value).length > MAX_ROBOTS) { M.fieldError(form, text, t('seo_robots_long')); return; }
      UI.setBusy(b, true);
      FP.call('put', 'siteSEORobots', {text: text.value}, {name: P.account, domain: P.site}).then(function (r) {
        P.state.robots = file(r);
        render();
        var card = P.page.querySelector('.fp-seo-robots');
        M.say(card.querySelector('form'), t('seo_robots_saved'));
        card.querySelector('textarea').focus();
      }, function (err) {
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    parts.push(form);
    return M.card('fp-seo-robots-h', t('seo_robots_title'), parts, 'fp-seo-robots');
  }
  /* the pages the sitemap can list: those found at the top of the website and those it lists now, once each */
  function pageChoices(v) {
    var out = v.pages.slice();
    v.listed.forEach(function (u) {
      if (v.base && u.indexOf(v.base + '/') === 0) {
        var p = u.slice(v.base.length);
        if (PAGE_RE.test(p) && out.indexOf(p) < 0) { out.push(p); }
      }
    });
    return out;
  }
  function sitemapCard(v) {
    var parts = [el('p', {class: 'fp-muted', text: t('seo_sitemap_note', {base: v.base})}),
      el('p', {class: 'fp-muted fp-seo-file'}, [el('span', {text: t('seo_file') + ' '}), el('span', {class: 'sig-mono', text: v.sitemap.file || 'sitemap.xml'}),
        el('span', {class: 'sig-pill fp-seo-state ' + (v.sitemap.exists ? 'sig-pill--ok' : ''), text: t(v.sitemap.exists ? 'seo_exists' : 'seo_missing')})])];
    var choices = pageChoices(v);
    var on = v.listed.length ? v.listed.map(function (u) { return u.slice(v.base.length); }) : choices;
    var boxes = choices.map(function (p, i) {
      var id = 'fp-seo-page-' + i;
      var c = el('input', {type: 'checkbox', id: id, name: 'page', value: p});
      c.checked = on.indexOf(p) >= 0;
      return el('li', {class: 'fp-check'}, [c, el('label', {for: id, class: 'sig-mono', text: p})]);
    });
    var extra = el('textarea', {class: 'sig-input sig-mono fp-seo-extra', id: 'fp-seo-extra', name: 'extra', rows: '4', spellcheck: 'false', wrap: 'off',
      autocapitalize: 'none', placeholder: '/blog/\n/contact.html'});
    var freq = el('select', {class: 'sig-select', id: 'fp-seo-freq', name: 'changefreq'}, FREQS.map(function (f) { return el('option', {value: f, text: t('seo_freq_' + (f || 'none'))}); }));
    var form = el('form', {class: 'fp-form fp-mail-form fp-seo-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('fieldset', {class: 'fp-seo-pages'}, [el('legend', {class: 'sig-label', text: t('seo_pages')}), el('ul', {class: 'fp-seo-list'}, boxes)]),
      M.field('fp-seo-extra', t('seo_extra'), extra, t('seo_extra_hint')),
      M.field('fp-seo-freq', t('seo_freq'), freq, t('seo_freq_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t(v.sitemap.exists ? 'seo_sitemap_replace' : 'seo_sitemap_make')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var paths = [];
      Array.prototype.forEach.call(form.querySelectorAll('input[name="page"]'), function (c) { if (c.checked) { paths.push(c.value); } });
      var lines = extra.value.split('\n').map(function (l) { return l.trim(); }).filter(Boolean);
      for (var i = 0; i < lines.length; i++) {
        var p = lines[i].charAt(0) === '/' ? lines[i] : '/' + lines[i];
        if (!PAGE_RE.test(p) || /\/\.\.(\/|$)/.test(p)) { M.fieldError(form, extra, t('seo_extra_bad', {page: lines[i].slice(0, 80)})); return; }
        if (paths.indexOf(p) < 0) { paths.push(p); }
      }
      if (!paths.length) { M.fieldError(form, extra, t('seo_pages_none')); return; }
      if (paths.length > MAX_PAGES) { M.fieldError(form, extra, t('seo_pages_many', {n: MAX_PAGES})); return; }
      UI.setBusy(b, true);
      FP.call('put', 'siteSEOSitemap', {paths: paths, changefreq: freq.value}, {name: P.account, domain: P.site}).then(function (r) {
        P.state.sitemap = file(r);
        P.state.listed = paths.map(function (x) { return P.state.base + x; });
        render();
        var card = P.page.querySelector('.fp-seo-sitemap');
        M.say(card.querySelector('form'), t('seo_sitemap_saved', {n: paths.length}));
        card.querySelector('#fp-seo-sitemap-h').focus();
      }, function (err) {
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    if (v.sitemap.tooLarge) {
      parts.push(M.suspendedBanner(t('seo_sitemap_large')));
    }
    parts.push(form);
    if (v.sitemap.exists && !v.sitemap.tooLarge) {
      parts.push(el('details', {class: 'fp-seo-show'}, [el('summary', {text: t('seo_sitemap_show')}),
        el('pre', {class: 'sig-mono fp-seo-pre', tabindex: '0', text: v.sitemap.text})]));
    }
    return M.card('fp-seo-sitemap-h', t('seo_sitemap_title'), parts, 'fp-seo-sitemap');
  }
  function render() {
    P.page.textContent = '';
    var pick = el('select', {class: 'sig-select', id: 'fp-seo-site'}, P.sites.map(function (d) {
      var o = el('option', {value: d, text: d});
      if (d === P.site) { o.selected = true; }
      return o;
    }));
    pick.addEventListener('change', function () { load(pick.value, true); });
    P.page.appendChild(el('div', {class: 'sig-field fp-rd-pick'}, [el('label', {class: 'sig-label', for: 'fp-seo-site', text: t('rd_site')}), pick]));
    if (!P.state) { return; }
    P.page.appendChild(robotsCard(P.state));
    P.page.appendChild(sitemapCard(P.state));
  }
  function load(site, focus) {
    P.site = site;
    P.state = null;
    var mine = P.page;
    render();
    P.page.appendChild(el('p', {class: 'fp-muted', 'data-fp-loading': '', text: t('loading')}));
    FP.call('get', 'siteSEO', undefined, {name: P.account, domain: site}).then(function (r) {
      if (P.page !== mine || P.site !== site) { return; }
      P.state = clean(r);
      render();
      if (focus) { P.page.querySelector('#fp-seo-site').focus(); }
    }, function (err) {
      if (P.page !== mine || P.site !== site) { return; }
      render();
      P.page.appendChild(FP.empty(t('seo_unreadable_title'), err.message));
    });
  }

  FP.view('tool:seo_files', function () {
    var tool = FP.tools.seo_files;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    P.account = FP.account();
    P.state = null;
    var body = FP.frame({title: tool.label, desc: t('seo_files_desc'), cls: 'fp-mail fp-seo-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    P.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'domains', undefined, P.account).then(function (r) {
      if (P.page !== body) { return; }
      P.sites = sitesOf(r);
      body.textContent = '';
      if (!P.sites.length) { body.appendChild(FP.empty(t('rd_no_sites_title'), t('php_no_sites'))); return; }
      load(P.sites.indexOf(P.site) >= 0 ? P.site : P.sites[0], false);
    }, function (err) {
      if (P.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

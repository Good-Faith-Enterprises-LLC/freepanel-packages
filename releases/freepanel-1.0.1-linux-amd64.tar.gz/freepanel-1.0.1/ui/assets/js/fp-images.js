/* freePanel image tools (#/tool/image_tools), the customer panel's page for making a smaller copy of a picture, or the same picture in
   another format (docs/api.md, "File manager": POST …/files/image). The original is never changed; the copy is a new file beside it
   (or in another folder). File names, paths and sizes come from the server's answers and are shown as text, never as markup. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var MAX_SIDE = 8192;
  var MAX_MADE = 10;
  var S = null;

  function str(v) { return typeof v === 'string' ? v : ''; }
  function size(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.min(Math.floor(v), 1e6) : 0; }
  function formatOf(name) {
    var m = /\.(png|jpe?g|gif)$/i.exec(name);
    return m ? (m[1].toLowerCase() === 'png' ? 'png' : m[1].toLowerCase() === 'gif' ? 'gif' : 'jpeg') : '';
  }
  function dirname(p) { var i = p.lastIndexOf('/'); return i < 0 ? '' : p.slice(0, i); }
  function cleanResult(r) {
    r = r && typeof r === 'object' ? r : {};
    var from = r.from && typeof r.from === 'object' ? r.from : {};
    var entry = r.entry && typeof r.entry === 'object' ? r.entry : {};
    return {name: str(entry.name).slice(0, 255), format: str(r.format).slice(0, 8), fw: size(from.width), fh: size(from.height), w: size(r.width), h: size(r.height)};
  }

  function number(id, name, label, hint) {
    return M.field(id, label, el('input', {class: 'sig-input fp-im-num', id: id, name: name, type: 'text', inputmode: 'numeric', maxlength: '5', autocomplete: 'off'}), hint);
  }
  function formCard() {
    var path = el('input', {class: 'sig-input', id: 'fp-pic-path', name: 'path', type: 'text', maxlength: '4096', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none'});
    var to = el('input', {class: 'sig-input', id: 'fp-pic-to', name: 'to', type: 'text', maxlength: '4096', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none'});
    var name = el('input', {class: 'sig-input', id: 'fp-pic-name', name: 'name', type: 'text', maxlength: '255', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none'});
    var quality = el('input', {class: 'sig-input fp-im-num', id: 'fp-pic-quality', name: 'quality', type: 'text', inputmode: 'numeric', maxlength: '3', value: '85', autocomplete: 'off'});
    var qualityField = M.field('fp-pic-quality', t('pic_quality'), quality, t('pic_quality_hint'));
    function syncQuality() { qualityField.hidden = formatOf(name.value.trim()) !== 'jpeg'; }
    syncQuality();
    name.addEventListener('input', syncQuality);
    path.addEventListener('change', function () {
      var p = path.value.trim();
      if (p && !to.value.trim()) { to.value = dirname(p); }
    });
    var form = el('form', {class: 'fp-form fp-mail-form fp-pic-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-pic-path', t('pic_path'), path, t('pic_path_hint')),
      M.field('fp-pic-to', t('pic_to'), to, t('pic_to_hint')),
      M.field('fp-pic-name', t('pic_name'), name, t('pic_name_hint')),
      el('div', {class: 'fp-pic-box'}, [number('fp-pic-width', 'width', t('pic_width'), t('pic_box_hint')), number('fp-pic-height', 'height', t('pic_height'))]),
      qualityField,
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('pic_make')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var f = function (n) { return form.querySelector('[name="' + n + '"]'); };
      var p = path.value.trim();
      var n = name.value.trim();
      if (!p) { M.fieldError(form, path, t('pic_need_path')); return; }
      if (!n || n.indexOf('/') >= 0) { M.fieldError(form, name, t('pic_name_bad')); return; }
      if (!formatOf(n)) { M.fieldError(form, name, t('pic_name_ending')); return; }
      var body = {path: p, to: to.value.trim(), name: n};
      var sides = [['width', f('width')], ['height', f('height')]];
      for (var i = 0; i < sides.length; i++) {
        var v = sides[i][1].value.trim();
        if (!v) { continue; }
        if (!/^[0-9]{1,5}$/.test(v) || Number(v) > MAX_SIDE) { M.fieldError(form, sides[i][1], t('pic_side_bad', {max: String(MAX_SIDE)})); return; }
        if (Number(v) > 0) { body[sides[i][0]] = Number(v); }
      }
      if (formatOf(n) === 'jpeg' && quality.value.trim()) {
        var q = quality.value.trim();
        if (!/^[0-9]{1,3}$/.test(q) || Number(q) < 1 || Number(q) > 100) { M.fieldError(form, quality, t('pic_quality_bad')); return; }
        body.quality = Number(q);
      }
      UI.setBusy(b, true);
      M.say(form, t('pic_working'));
      FP.call('post', 'filesImage', body, S.account).then(function (r) {
        var res = cleanResult(r);
        res.where = (body.to ? body.to + '/' : '') + res.name;
        S.made.unshift(res);
        S.made = S.made.slice(0, MAX_MADE);
        render();
        M.say(S.page.querySelector('.fp-pic-card'), t('pic_made', {name: res.where}));
        S.page.querySelector('#fp-pic-made-h').focus();
      }, function (err) {
        UI.setBusy(b, false);
        M.say(form, '');
        M.failed(form, err);
        if (!form.contains(document.activeElement)) { b.focus(); }
      });
    });
    return M.card('fp-pic-h', t('pic_title'), [el('p', {class: 'fp-muted', text: t('pic_desc')}), form], 'fp-pic-card');
  }
  function madeCard() {
    if (!S.made.length) { return null; }
    return M.card('fp-pic-made-h', t('pic_made_title'), [el('ul', {class: 'fp-pic-made', 'aria-label': t('pic_made_title')}, S.made.map(function (m) {
      return el('li', {'data-fp-pic-made': m.name}, [el('span', {class: 'sig-mono fp-pic-file', text: m.where}), ' ',
        el('span', {class: 'fp-muted', text: t('pic_made_row', {fw: String(m.fw), fh: String(m.fh), w: String(m.w), h: String(m.h), format: m.format.toUpperCase()})})]);
    })), el('p', {class: 'fp-muted', text: t('pic_made_note')})], 'fp-pic-made-card');
  }
  function render() {
    S.page.textContent = '';
    if (S.suspended) { S.page.appendChild(M.suspendedBanner(t('pic_suspended'))); }
    S.page.appendChild(formCard());
    var m = madeCard();
    if (m) { S.page.appendChild(m); }
  }

  FP.view('tool:image_tools', function () {
    var tool = FP.tools.image_tools;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('image_tools_desc'), cls: 'fp-mail fp-pic',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    S = {page: body, account: FP.account(), made: [], suspended: false};
    var mine = S;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.summary().then(function (a) { return a; }, function () { return null; }).then(function (a) {
      if (S !== mine) { return; }
      S.suspended = !!(a && a.status === 'suspended');
      render();
    });
  });
})();

/* freePanel billing affiliates (#/tool/billing_affiliates; docs/api.md, "Billing: affiliates"; docs/billing/navigation-map.md, "Affiliates"):
   the scheme's settings above the affiliates with their code, client, state, rate, how many clients they referred and what is ready to pay
   out. An affiliate opens on the same page with their commissions and payouts, a form to change their code, state and rate, and Pay out,
   asked first, since it pays all that is ready at once. The panel never sends money anywhere by itself. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;
  var M = FP.mail;

  var AFF = {id: 'id', customer_id: 'id', customer_name: [100], code: [32], status: ['=', ['active', 'paused']], rate_bp: 'n', referred: 'n', created: 'w'};
  var COM = {id: 'id', invoice_id: 'id', base_cents: 'c', rate_bp: 'n', amount_cents: 'c', status: ['=', ['pending', 'available', 'paid', 'reversed']], available_on: 'd', created: 'w'};
  var PAY = {id: 'id', amount_cents: 'c', method: ['=', ['credit', 'manual']], reference: [100], note: [200], created_by: [64], created: 'w', commissions: 'n'};
  var A = null;
  function cleanBalance(r) {
    var b = r && r.balance && typeof r.balance === 'object' ? r.balance : {};
    var c = function (k) { var v = B.cents(b[k]); return v === null ? 0 : v; };
    return {pending: c('pending_cents'), available: c('available_cents'), paid: c('paid_cents'), reversed: c('reversed_cents')};
  }
  function rateText(a) { return a.rate_bp === null ? t('baf_rate_scheme', {rate: A.settings.rate_bp === null ? '—' : B.bpText(A.settings.rate_bp) + '%'}) : B.bpText(a.rate_bp) + '%'; }
  function comPill(s) { return B.pill(t('baf_c_' + (s || 'pending')), s === 'available' ? 'ok' : s === 'paid' ? 'accent' : s === 'reversed' ? '' : 'warn'); }

  function settingsCard(v, said) {
    var specs = [{name: 'rate_bp', label: t('baf_s_rate'), kind: 'percent', required: true, hint: t('baf_s_rate_hint')}, {name: 'hold_days', label: t('baf_s_hold'), kind: 'number', max: 3, required: true, hint: t('baf_s_hold_hint')},
      {name: 'min_payout_cents', label: t('baf_s_min'), kind: 'amount', required: true, hint: t('baf_s_min_hint')}, {name: 'first_invoice_only', label: t('baf_s_first'), kind: 'check', hint: t('baf_s_first_hint')}];
    var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bil_save_changes')});
    var form = el('form', {class: 'fp-form fp-bil-crud-form fp-baf-set', novalidate: '', 'aria-labelledby': 'fp-baf-set-h'}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-bil-grid'}, B.fieldsOf('fp-baf-s', specs, v)), el('div', {class: 'fp-actions'}, [save])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!B.begin(form, save)) { return; }
      var body = B.readFields(form, specs, v);
      if (!body) { return; }
      if (!Object.keys(body).length) { M.say(form, t('bil_nothing_changed')); return; }
      UI.setBusy(save, true);
      FP.call('patch', 'billingAffiliateSettings', body).then(function () {
        if (A && A.page.isConnected) { showList(null, t('baf_s_saved'), '#fp-baf-set-h'); }
      }, function (err) {
        if (!A || !A.page.isConnected) { return; }
        UI.setBusy(save, false);
        B.failed(form, err);
      });
    });
    var c = B.card('fp-baf-set-h', t('baf_scheme'), [el('p', {class: 'fp-muted', text: t('baf_scheme_what')}), form], 'fp-baf-set-card', 'settings');
    if (said) { M.say(form, said); }
    return c;
  }
  function loadSettings() {
    return FP.call('get', 'billingAffiliateSettings').then(function (r) {
      var v = B.pick(r, {first_invoice_only: 'b'}) || {};
      v.rate_bp = B.whole(r && r.rate_bp);
      v.hold_days = B.whole(r && r.hold_days);
      v.min_payout_cents = B.whole(r && r.min_payout_cents);
      return v;
    });
  }
  function showList(focus, said, sayFocus) {
    var mine = A;
    A.view = 'list';
    A.a = null;
    return Promise.all([loadSettings(), FP.call('get', 'billingAffiliates').then(function (r) { return B.pickAll(r && r.affiliates, AFF, 'id'); })]).then(function (r) {
      A.settings = r[0];
      return Promise.all(r[1].slice(0, 100).map(function (a) {
        return FP.call('get', 'billingAffiliateCommissions', undefined, {id: String(a.id)}).then(function (x) { a.balance = cleanBalance(x); }, function () { a.balance = null; });
      })).then(function () { return r[1]; });
    }).then(function (list) {
      if (A !== mine || !A.page.isConnected) { return; }
      var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t('baf_list_what')})];
      parts.push(list.length ? B.table('fp-baf-h', 'fp-baf-table', [B.th(t('baf_col_code')), B.th(t('baf_col_client')), B.th(t('baf_col_status')), B.th(t('baf_col_rate')),
        B.th(t('baf_col_referred'), 'fp-bil-num'), B.th(t('baf_col_available'), 'fp-bil-num')], list.map(function (a) {
        return el('tr', {'data-fp-affiliate': String(a.id)}, [el('th', {scope: 'row', class: 'fp-bil-name'}, [B.button('open', a.code, 'sig-btn--link fp-bil-link', {'data-fp-id': String(a.id), 'aria-label': t('baf_open_of', {code: a.code})})]),
          el('td', {class: 'fp-bil-wrap', text: a.customer_name || '—'}), el('td', null, [B.pill(B.word('aff', a.status), a.status === 'active' ? 'ok' : 'warn')]), el('td', {text: rateText(a)}),
          el('td', {class: 'fp-bil-num', text: a.referred === null ? '—' : B.num(a.referred)}), el('td', {class: 'fp-bil-num', text: a.balance ? B.money(a.balance.available, 'USD') : '—'})]);
      })) : el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('baf_none')}));
      var listCard = B.card('fp-baf-h', t('baf_list'), parts, 'fp-baf-list', 'list');
      B.screen(A.page, [settingsCard(A.settings, sayFocus ? said : ''), listCard]);
      if (said && !sayFocus) { M.say(listCard, said); }
      var f = sayFocus || focus ? A.page.querySelector(sayFocus || focus) : null;
      if (f) { f.focus(); }
    }, function (err) {
      if (A !== mine || !A.page.isConnected) { return; }
      B.screen(A.page, [FP.empty(t('baf_list'), err.message, B.button('reload', t('bil_try_again')))]);
    });
  }
  function openAffiliate(aid, said, focus) {
    var mine = A;
    return Promise.all([FP.call('get', 'billingAffiliate', undefined, {id: String(aid)}), FP.call('get', 'billingAffiliateCommissions', undefined, {id: String(aid)}),
      FP.call('get', 'billingAffiliatePayouts', undefined, {id: String(aid)}), A.settings ? A.settings : loadSettings()]).then(function (r) {
      if (A !== mine || !A.page.isConnected) { return; }
      var a = B.pick(r[0], AFF);
      if (!a || !a.id) { throw {message: t('api_failed')}; }
      A.settings = r[3];
      A.view = 'affiliate';
      A.a = a;
      var bal = cleanBalance(r[1]);
      var coms = B.pickAll(r[1] && r[1].commissions, COM, 'id');
      var pays = B.pickAll(r[2] && r[2].payouts, PAY, 'id');
      B.screen(A.page, [B.back('to-list', t('baf_back')), headCard(a, bal), payCard(a, bal), comCard(coms), payoutsCard(pays), editCard(a)]);
      if (said) { M.say(A.page.querySelector('[data-fp-card="head"]'), said); }
      (A.page.querySelector(focus || '#fp-baf-a-h') || A.page.querySelector('#fp-baf-a-h')).focus();
    }).catch(function (err) {
      if (A !== mine || !A.page.isConnected) { return; }
      var list = A.page.querySelector('[data-fp-card="list"]');
      if (list) { UI.showError(list, err.message); return; }
      showList();
    });
  }
  function headCard(a, bal) {
    return el('section', {class: 'sig-card fp-bil-head', 'aria-labelledby': 'fp-baf-a-h', 'data-fp-card': 'head'}, [el('div', {class: 'sig-card-body'}, [M.statusLine(),
      el('div', {class: 'fp-bil-head-row'}, [el('div', {class: 'fp-bil-head-name'}, [el('h2', {class: 'fp-h2', id: 'fp-baf-a-h', tabindex: '-1', text: t('baf_title_of', {code: a.code})}),
        el('p', {class: 'fp-muted fp-bil-sub'}, [a.customer_id && FP.tools.billing_clients ? B.button('open-client', a.customer_name || '—', 'sig-btn--link fp-bil-link',
          {'data-fp-id': String(a.customer_id), 'aria-label': t('binv_open_client', {name: a.customer_name})}) : el('span', {text: a.customer_name || '—'})])]), B.pill(B.word('aff', a.status), a.status === 'active' ? 'ok' : 'warn')]),
      B.facts([[t('baf_col_rate'), rateText(a)], [t('baf_col_referred'), a.referred === null ? '—' : B.num(a.referred)], [t('baf_b_pending'), B.money(bal.pending, 'USD')],
        [t('baf_b_available'), B.money(bal.available, 'USD')], [t('baf_b_paid'), B.money(bal.paid, 'USD')]], 'fp-bil-money')])]);
  }
  function payCard(a, bal) {
    var min = A.settings.min_payout_cents || 0;
    if (!bal.available || bal.available < min) {
      return B.card('fp-baf-pay-h', t('baf_pay_title'), [el('p', {class: 'fp-muted', 'data-fp-cant-pay': '', text: bal.available ? t('baf_pay_below', {amount: B.money(bal.available, 'USD'), min: B.money(min, 'USD')}) : t('baf_pay_nothing')})], 'fp-baf-pay', 'pay');
    }
    var specs = [{name: 'method', label: t('baf_pay_method'), kind: 'select', options: [['credit', t('baf_pay_credit')], ['manual', t('baf_pay_manual')]], value: 'credit'},
      {name: 'reference', label: t('baf_pay_ref'), max: 100, hint: t('baf_pay_ref_hint')}, {name: 'note', label: t('baf_pay_note'), max: 200}];
    var go = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('baf_pay', {amount: B.money(bal.available, 'USD')})});
    var form = el('form', {class: 'fp-form fp-bil-crud-form fp-baf-pay-form', novalidate: '', 'aria-labelledby': 'fp-baf-pay-h'}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-bil-grid'}, B.fieldsOf('fp-baf-p', specs, null)), el('div', {class: 'fp-actions', 'data-fp-acts': ''}, [go])]);
    function restore(focus) { var box = form.querySelector('[data-fp-acts]'); box.textContent = ''; box.appendChild(go); UI.setBusy(go, false); if (focus) { go.focus(); } }
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!B.begin(form, go)) { return; }
      var body = B.readFields(form, specs, null);
      if (!body) { return; }
      if (body.method === 'manual' && !body.reference) { M.fieldError(form, UI.fieldNamed(form, 'reference'), t('baf_pay_ref_needed')); return; }
      var box = form.querySelector('[data-fp-acts]');
      box.textContent = '';
      var yes = el('button', {class: 'sig-btn sig-btn--danger', type: 'button', text: t('baf_pay_yes'), 'aria-describedby': 'fp-baf-q'});
      var no = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', text: t('baf_pay_keep'), 'aria-describedby': 'fp-baf-q'});
      box.appendChild(el('p', {class: 'fp-mail-confirm', id: 'fp-baf-q', text: t(body.method === 'credit' ? 'baf_pay_ask_credit' : 'baf_pay_ask_manual', {amount: B.money(bal.available, 'USD')})}));
      box.appendChild(yes);
      box.appendChild(no);
      no.addEventListener('click', function () { restore(true); });
      yes.addEventListener('click', function () {
        UI.setBusy(yes, true);
        FP.call('post', 'billingAffiliatePayouts', body, {id: String(a.id)}).then(function (r) {
          if (!A || !A.page.isConnected) { return; }
          var p = B.pick(r, PAY);
          openAffiliate(a.id, t('baf_paid', {amount: B.money(p ? p.amount_cents : bal.available, 'USD')}), '#fp-baf-a-h');
        }, function (err) {
          if (!A || !A.page.isConnected) { return; }
          restore(false);
          B.failed(form, err);
        });
      });
      no.focus();
    });
    return B.card('fp-baf-pay-h', t('baf_pay_title'), [el('p', {class: 'fp-muted', text: t('baf_pay_what')}), form], 'fp-baf-pay', 'pay');
  }
  function comCard(coms) {
    return B.card('fp-baf-c-h', t('baf_coms'), [coms.length ? B.table('fp-baf-c-h', 'fp-baf-c-table', [B.th(t('baf_col_when')), B.th(t('baf_col_invoice')), B.th(t('baf_col_base'), 'fp-bil-num'),
      B.th(t('baf_col_rate'), 'fp-bil-num'), B.th(t('baf_col_amount'), 'fp-bil-num'), B.th(t('baf_col_cstatus')), B.th(t('baf_col_ready'))], coms.map(function (c) {
      return el('tr', null, [el('td', {class: 'fp-bil-nowrap', text: B.day(c.created) || '—'}), el('td', {text: c.invoice_id ? t('binv_invoice_ref', {id: String(c.invoice_id)}) : '—'}),
        el('td', {class: 'fp-bil-num', text: B.money(c.base_cents, 'USD')}), el('td', {class: 'fp-bil-num', text: c.rate_bp === null ? '—' : B.bpText(c.rate_bp) + '%'}),
        el('td', {class: 'fp-bil-num', text: B.money(c.amount_cents, 'USD')}), el('td', null, [comPill(c.status)]), el('td', {class: 'fp-bil-nowrap', text: B.day(c.available_on) || '—'})]);
    })) : el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('baf_no_coms')})], 'fp-baf-coms', 'commissions');
  }
  function payoutsCard(pays) {
    return B.card('fp-baf-po-h', t('baf_payouts'), [pays.length ? B.table('fp-baf-po-h', 'fp-baf-po-table', [B.th(t('baf_col_when')), B.th(t('baf_col_amount'), 'fp-bil-num'), B.th(t('baf_pay_method')),
      B.th(t('baf_pay_ref')), B.th(t('baf_col_by'))], pays.map(function (p) {
      return el('tr', null, [el('td', {class: 'fp-bil-nowrap', text: B.day(p.created) || '—'}), el('td', {class: 'fp-bil-num', text: B.money(p.amount_cents, 'USD')}),
        el('td', {text: t(p.method === 'manual' ? 'baf_pay_manual' : 'baf_pay_credit')}), el('td', {class: 'fp-bil-wrap', text: p.reference || '—'}), el('td', {text: p.created_by || '—'})]);
    })) : el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('baf_no_payouts')})], 'fp-baf-payouts', 'payouts');
  }
  function editCard(a) {
    var specs = [{name: 'code', label: t('baf_col_code'), required: true, max: 32, code: true, hint: t('baf_code_hint')},
      {name: 'status', label: t('baf_col_status'), kind: 'select', options: [['active', B.word('aff', 'active')], ['paused', B.word('aff', 'paused')]], hint: t('baf_status_hint')},
      {name: 'rate_bp', label: t('baf_own_rate'), kind: 'percent', empty: null, hint: t('baf_own_rate_hint')}];
    var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bil_save_changes')});
    var form = el('form', {class: 'fp-form fp-bil-crud-form fp-baf-edit', novalidate: '', 'aria-labelledby': 'fp-baf-e-h'}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-bil-grid'}, B.fieldsOf('fp-baf-e', specs, a)), el('div', {class: 'fp-actions'}, [save])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!B.begin(form, save)) { return; }
      var body = B.readFields(form, specs, a);
      if (!body) { return; }
      if (body.code !== undefined) { body.code = body.code.toLowerCase(); if (body.code === a.code) { delete body.code; } }
      if (!Object.keys(body).length) { M.say(form, t('bil_nothing_changed')); return; }
      UI.setBusy(save, true);
      FP.call('patch', 'billingAffiliate', body, {id: String(a.id)}).then(function () {
        if (A && A.page.isConnected) { openAffiliate(a.id, t('baf_saved'), '#fp-baf-a-h'); }
      }, function (err) {
        if (!A || !A.page.isConnected) { return; }
        UI.setBusy(save, false);
        B.failed(form, err);
      });
    });
    return B.card('fp-baf-e-h', t('baf_edit'), [form], 'fp-baf-edit-card', 'edit');
  }
  function onClick(e) {
    var target = e.target && e.target.closest ? e.target : null;
    if (!target || !A || !A.page.isConnected || !A.page.contains(target)) { return; }
    var b = target.closest('[data-fp-act]');
    if (!b || b.disabled) { return; }
    var a = b.getAttribute('data-fp-act');
    var xid = Number(b.getAttribute('data-fp-id')) || 0;
    if (a === 'open' && xid) {
      UI.setBusy(b, true);
      openAffiliate(xid);
    } else if (a === 'to-list') {
      var from = A.a ? A.a.id : 0;
      showList(from ? '[data-fp-act="open"][data-fp-id="' + from + '"]' : '#fp-baf-h');
    } else if (a === 'open-client' && xid) {
      B.go('billing_clients', {client: xid});
    } else if (a === 'reload') {
      showList();
    }
  }
  document.addEventListener('click', onClick);

  FP.view('tool:billing_affiliates', function () {
    var page = B.frame('billing_affiliates', 'fp-baf');
    if (!page) { return; }
    A = {page: page, view: 'list', settings: null, a: null};
    var handed = B.take('billing_affiliates');
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    if (handed && B.id(handed.affiliate)) { openAffiliate(handed.affiliate); } else { showList(); }
  });
})();

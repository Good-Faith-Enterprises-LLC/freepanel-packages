/* freePanel backup downloads (docs/api.md, "Accounts": downloads; plans/backups.md, stage 3): a copy of one account to
   download, as the whole archive, the home folder, one database or the mail settings. An account has at most one: a
   new one replaces it and each goes 24 hours after it was made. The server makes two at a time and the rest wait their
   turn, so the card asks every few seconds while one is being made or waiting. What it shows of a copy comes from the
   server: whether this viewer may fetch it (fetchable) and what it leaves out (left_out). The card is
   the customer panel's Backups page (#/tool/backups) and, for a chosen account, part of the admin panel's Back up and
   restore page (fp-backups.js), through FP.backupDownload.card. The same card sends a home folder archive back (stage 3b,
   POST .../backups/upload?kind=home): it is checked whole, then unpacked into the home folder as the account, so files
   it doesn't hold stay; the restore runs in the same slot and the card follows it. Resellers can't send one (403), so
   their card has no upload form. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var KINDS = ['full', 'home', 'database', 'mail'];
  var STAGES = ['receiving', 'checking', 'queued', 'restoring'];
  var LEFT_OUT = ['login_password', 'mailbox_passwords', 'ftp_passwords', 'folder_passwords', 'database_passwords', 'certificates'];
  var ENGINES = ['mysql', 'postgres'];
  var NAME_RE = /^[A-Za-z0-9][A-Za-z0-9._-]{0,199}$/;
  var DB_RE = /^[A-Za-z0-9_]{1,64}$/;
  var KIND_RE = /^[a-z][a-z0-9_]{0,39}$/;
  var POLL_MS = 3000;
  var UNITS = ['KB', 'MB', 'GB', 'TB', 'PB'];
  var MAX_UPLOAD = 50 * 1024 * 1024 * 1024;
  var UPLOAD_RE = /\.(tar\.gz|tgz|tar)$/i;

  function str(v) { return typeof v === 'string' ? v : ''; }
  function size(n) {
    if (n < 1024) { return t('size_bytes', {n: String(Math.round(n))}); }
    var u = -1;
    do { n /= 1024; u++; } while (n >= 1024 && u < UNITS.length - 1);
    return (n < 10 ? n.toFixed(1) : Math.round(n).toLocaleString('en')) + ' ' + UNITS[u];
  }
  function when(iso) {
    var d = iso ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }
  /* what the server says a copy leaves out: the kinds this page has words for first, in the API's order, then any other
     kind by its key, so a kind added later shows in plain words and is not dropped */
  function leftOutKinds(list) {
    var all = (Array.isArray(list) ? list : []).filter(function (k, i, a) { return typeof k === 'string' && KIND_RE.test(k) && a.indexOf(k) === i; }).slice(0, 20);
    return LEFT_OUT.filter(function (k) { return all.indexOf(k) >= 0; }).concat(all.filter(function (k) { return LEFT_OUT.indexOf(k) < 0; }));
  }
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var d = r.download && typeof r.download === 'object' ? r.download : null;
    var dl = d && NAME_RE.test(str(d.name)) && KINDS.indexOf(d.kind) >= 0 ? {name: d.name, kind: d.kind,
      engine: ENGINES.indexOf(d.engine) >= 0 ? d.engine : '', database: DB_RE.test(str(d.database)) ? d.database : '',
      bytes: typeof d.bytes === 'number' && isFinite(d.bytes) && d.bytes >= 0 ? d.bytes : null, created: str(d.created), expires: str(d.expires),
      leftOut: leftOutKinds(d.left_out)} : null;
    var lr = r.last_restore && typeof r.last_restore === 'object' ? r.last_restore : null;
    var stage = STAGES.indexOf(r.upload) >= 0 ? r.upload : (r.restoring === true ? 'restoring' : '');
    /* busy: the copy being made waits its turn behind the ones the server is making; upload: how far the account's
       upload has got (receiving, checking, queued behind the server's backups and restores, restoring) */
    return {download: dl, fetchable: r.fetchable === true, making: r.making === true, queued: r.making === true && r.busy === true,
      error: str(r.last_error).slice(0, 1024), upload: stage,
      lastRestore: lr ? {ended: str(lr.ended), error: str(lr.error).slice(0, 1024),
        notes: (Array.isArray(lr.notes) ? lr.notes : []).filter(function (n) { return typeof n === 'string' && n; }).slice(0, 101)
          .map(function (n) { return n.slice(0, 1024); })} : null};
  }
  function leftOutText(keys) {
    var names = keys.map(function (k) { return LEFT_OUT.indexOf(k) >= 0 ? t('dl_left_' + k) : k.replace(/_/g, ' '); });
    var list = names.length > 1 ? names.slice(0, -1).join(', ') + ' ' + t('dl_and') + ' ' + names[names.length - 1] : names[0];
    return t('dl_left_out', {list: list});
  }
  function kindText(d) {
    return d.kind === 'database' && d.database ? t('dl_kind_database_of', {database: d.database, engine: t('dl_engine_' + (d.engine || 'mysql'))}) : t('dl_kind_' + d.kind);
  }
  function canUpload() { return !(FP.realm === 'admin' && FP.session.user.role === 'reseller'); }
  function fileURL(account, name) {
    return '/api/v1/accounts/' + encodeURIComponent(account) + '/backups/download/file?name=' + encodeURIComponent(name);
  }

  /* one account's card; .node is the section, kept across redraws of the page around it */
  /* opts.onClose: the admin page's card names its account and has a Close button that calls it */
  function Card(account, opts) {
    this.account = account;
    this.opts = opts || {};
    this.data = null;
    this.dbs = [];
    this.kind = 'full';
    this.timer = 0;
    this.sending = null;
    this.node = M.card('fp-dl-h', this.title(), [el('p', {class: 'fp-muted', text: t('loading')})], 'fp-dl');
    this.node.addEventListener('click', this.onClick.bind(this));
    this.load();
  }
  Card.prototype.title = function () { return this.opts.onClose ? t('dl_title_of', {account: this.account}) : t('dl_title'); };
  Card.prototype.body = function () { return this.node.querySelector('.sig-card-body'); };
  Card.prototype.alive = function () { return document.body.contains(this.node); };
  Card.prototype.load = function () {
    var self = this;
    var calls = [FP.call('get', 'backupDownload', undefined, self.account)];
    ENGINES.forEach(function (e) {
      calls.push(FP.call('get', e, undefined, self.account).then(function (r) {
        return (r && Array.isArray(r.databases) ? r.databases : []).map(function (d) { return d && str(d.name); })
          .filter(function (n) { return DB_RE.test(n); }).sort().map(function (n) { return {engine: e, name: n}; });
      }, function () { return []; }));
    });
    return Promise.all(calls).then(function (r) {
      self.data = clean(r[0]);
      self.dbs = r[1].concat(r[2]);
      self.render();
      if (self.data.making || self.data.upload) { self.poll(); }
    }, function (err) {
      var b = self.body();
      b.textContent = '';
      b.appendChild(el('h2', {class: 'fp-h2', id: 'fp-dl-h', tabindex: '-1', text: self.title()}));
      b.appendChild(el('p', {class: 'fp-muted', 'data-fp-dl-failed': '', text: err.message}));
      if (self.opts.onClose) { b.appendChild(self.closeButton()); }
    });
  };
  Card.prototype.readyPart = function () {
    var d = this.data.download;
    if (!d) { return el('p', {class: 'fp-muted', 'data-fp-dl-ready': '', text: this.data.making ? '' : t('dl_none')}); }
    var get = this.data.fetchable ? el('a', {class: 'sig-btn sig-btn--primary', href: fileURL(this.account, d.name), download: d.name,
      'data-fp-dl-link': '', 'aria-label': t('dl_get_of', {kind: kindText(d)}), text: t('dl_get')}) : null;
    return el('div', {class: 'fp-dl-ready', 'data-fp-dl-ready': ''}, [
      el('p', null, [el('strong', {class: 'fp-dl-kind', text: kindText(d)}), el('span', {text: t('dl_ready_facts', {made: when(d.created) || '—',
        size: d.bytes === null ? '—' : size(d.bytes)})})]),
      el('p', {class: 'fp-muted', text: t('dl_expires', {when: when(d.expires) || '—'})}),
      d.leftOut.length ? el('p', {class: 'fp-muted', 'data-fp-dl-left-out': '',
        text: leftOutText(d.leftOut) + (d.kind === 'full' ? ' ' + t('dl_left_out_restore') : '')}) : null,
      this.data.fetchable ? null : el('p', {class: 'fp-muted', 'data-fp-dl-not-yours': '', text: t('dl_not_fetchable')}),
      el('div', {class: 'fp-actions', 'data-fp-dl-acts': ''}, [get,
        el('button', {class: 'sig-btn sig-btn--secondary fp-btn-danger-text', type: 'button', 'data-fp-act': 'dl-remove', text: t('dl_remove')})])]);
  };
  Card.prototype.formPart = function () {
    var self = this;
    var blocked = this.data.making;
    var radios = KINDS.map(function (k) {
      var off = k === 'database' && !self.dbs.length;
      var hint = k === 'full' && FP.realm === 'admin' && FP.session.user.role === 'reseller' ? t('dl_hint_full_reseller') :
        off ? t('dl_hint_no_databases') : t('dl_hint_' + k);
      return el('div', {class: 'fp-dl-choice'}, [el('label', {class: 'fp-check', for: 'fp-dl-' + k}, [
        el('input', {type: 'radio', id: 'fp-dl-' + k, name: 'kind', value: k, checked: k === self.kind ? true : null, disabled: off ? true : null,
          'aria-describedby': 'fp-dl-' + k + '-hint'}), el('span', {text: t('dl_kind_' + k)})]),
      el('span', {class: 'sig-hint', id: 'fp-dl-' + k + '-hint', text: hint})]);
    });
    var db = el('select', {class: 'sig-select', id: 'fp-dl-db', name: 'database'}, this.dbs.map(function (d) {
      return el('option', {value: d.engine + ':' + d.name, text: t('dl_kind_database_of', {database: d.name, engine: t('dl_engine_' + d.engine)})});
    }));
    var dbField = M.field('fp-dl-db', t('dl_database'), db);
    var form = el('form', {class: 'fp-form fp-mail-form fp-dl-form', novalidate: ''}, [M.errorLine(),
      el('fieldset', {class: 'fp-dl-kinds'}, [el('legend', {class: 'sig-label', text: t('dl_what')})].concat(radios).concat([dbField])),
      el('p', {class: 'sig-hint', text: t('dl_replaces')}),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('dl_make'),
        disabled: blocked ? true : null})])]);
    function sync() {
      var c = form.querySelector('[name="kind"]:checked');
      self.kind = c ? c.value : 'full';
      dbField.hidden = self.kind !== 'database';
    }
    form.addEventListener('change', sync);
    sync();
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var body = {kind: self.kind};
      if (self.kind === 'database') {
        var v = db.value.split(':');
        body.engine = v[0];
        body.database = v[1];
      }
      UI.setBusy(b, true);
      FP.call('post', 'backupDownload', body, self.account).then(function (r) {
        self.data = clean(r);
        if (!self.data.making && !self.data.download) { self.data.making = true; }
        self.render(t('dl_making_now', {kind: t('dl_kind_' + body.kind)}));
        self.node.querySelector('#fp-dl-h').focus();
        self.poll();
      }, function (err) {
        UI.setBusy(b, false);
        /* past the copies allowed in a day: when the next one may start, from Retry-After */
        if (err.status === 429 && err.retryAfter) {
          err = {message: t('dl_limited', {when: when(new Date(Date.now() + err.retryAfter * 1000).toISOString())})};
        }
        M.failed(form, err.field === 'kind' ? {message: err.message} : err);
        if (err.status === 409) { self.refresh(); }
      });
    });
    return form;
  };
  /* how the last restore of an upload ended */
  Card.prototype.restoredPart = function () {
    var l = this.data.lastRestore;
    if (!l || this.data.upload) { return null; }
    if (l.error) { return el('p', {class: 'fp-bk-bad', 'data-fp-up-last': '', text: t('up_last_failed', {when: when(l.ended) || '—', error: l.error})}); }
    return el('div', {'data-fp-up-last': ''}, [el('p', {class: 'fp-up-done', text: t('up_last_done', {when: when(l.ended) || '—'})}),
      l.notes.length ? el('p', {class: 'fp-muted', id: 'fp-up-notes-h', text: t('up_left_out')}) : null,
      l.notes.length ? el('ul', {class: 'fp-up-notes', 'aria-labelledby': 'fp-up-notes-h'}, l.notes.map(function (n) { return el('li', {text: n}); })) : null]);
  };
  Card.prototype.uploadPart = function () {
    var self = this;
    var d = this.data;
    var blocked = Boolean(d.upload);
    var file = el('input', {class: 'sig-input fp-up-file', id: 'fp-up-file', name: 'archive', type: 'file', accept: '.tar.gz,.tgz,.tar',
      disabled: blocked || this.sending ? true : null});
    var acts = el('div', {class: 'fp-actions', 'data-fp-up-acts': ''}, [el('button', {class: 'sig-btn sig-btn--secondary fp-submit', type: 'submit',
      text: t('up_send'), disabled: blocked || this.sending ? true : null})]);
    var form = el('form', {class: 'fp-form fp-mail-form fp-up-form', novalidate: ''}, [M.errorLine(),
      M.field('fp-up-file', t('up_file'), file, t('up_file_hint')), acts]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (self.sending || form.querySelector('#fp-up-ask')) { return; }
      var b = M.start(form);
      if (!b) { return; }
      var f = file.files && file.files[0];
      if (!f) { M.fieldError(form, file, t('up_file_none')); return; }
      if (!UPLOAD_RE.test(f.name)) { M.fieldError(form, file, t('up_file_bad')); return; }
      if (!f.size) { M.fieldError(form, file, t('up_file_empty')); return; }
      if (f.size > MAX_UPLOAD) { M.fieldError(form, file, t('up_file_big', {size: size(f.size)})); return; }
      /* files of the same name in the home folder are written over, so it asks first; Yes sends the file asked about,
         whatever the field holds by then */
      self.asked = f;
      acts.textContent = '';
      var no = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'up-no', 'aria-describedby': 'fp-up-ask', text: t('cancel')});
      acts.appendChild(el('span', {class: 'fp-mail-confirm', id: 'fp-up-ask', text: t('up_ask', {file: f.name, account: self.account})}));
      acts.appendChild(el('button', {class: 'sig-btn sig-btn--danger', type: 'button', 'data-fp-act': 'up-yes', 'aria-describedby': 'fp-up-ask',
        text: t('up_yes')}));
      acts.appendChild(no);
      no.focus();
    });
    var parts = [el('h3', {class: 'fp-h3', id: 'fp-up-h', tabindex: '-1', text: t('up_title')}),
      el('p', {class: 'fp-muted', text: t('up_desc')})];
    if (d.upload === 'restoring') {
      parts.push(el('p', {class: 'fp-dl-making', 'data-fp-up-restoring': '', text: t('up_restoring')}));
    } else if (d.upload) {
      /* until the restore starts (receiving, checking, waiting behind the server's backups and restores) it can be called off */
      var queued = d.upload === 'queued';
      var wait = {receiving: 'up_receiving', checking: 'up_checking', queued: 'up_queued'}[d.upload];
      var hook = queued ? {'data-fp-up-queued': ''} : {'data-fp-up-checking': ''};
      parts.push(el('div', Object.assign({class: 'fp-up-queued'}, hook), [el('p', {class: 'fp-dl-making', id: 'fp-up-wait', text: t(wait)}),
        el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'up-cancel',
          'aria-describedby': 'fp-up-wait', text: t('up_cancel')})])]));
    }
    parts.push(this.restoredPart());
    parts.push(form);
    return el('div', {class: 'fp-up', 'data-fp-up': ''}, parts);
  };
  /* sends the chosen archive; the card shows how far it got and can stop it */
  Card.prototype.send = function () {
    var self = this;
    var form = self.node.querySelector('.fp-up-form');
    var f = self.asked;
    self.asked = null;
    if (!f) { return; }
    var acts = form.querySelector('[data-fp-up-acts]');
    var bar = el('progress', {class: 'fp-up-bar', id: 'fp-up-bar', max: '100', value: '0', 'aria-labelledby': 'fp-up-sending'});
    var line = el('span', {id: 'fp-up-sending', text: t('up_sending', {file: f.name, n: '0'})});
    var stop = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'up-stop', text: t('up_stop')});
    acts.textContent = '';
    acts.appendChild(el('div', {class: 'fp-up-progress', 'data-fp-up-sending': ''}, [line, bar]));
    acts.appendChild(stop);
    form.querySelector('#fp-up-file').disabled = true;
    stop.focus();
    var shown = -1;
    sendingNow.push(self);
    self.sending = window.FPAPI.upload('backupUpload', f, /\.tar$/i.test(f.name) ? 'application/x-tar' : 'application/gzip', self.account, function (x) {
      var n = Math.floor(x * 100);
      bar.value = n;
      /* the text says it in steps of ten, so a screen reader isn't told every percent */
      if (n - shown >= 10 || n === 100) { shown = n; line.textContent = t('up_sending', {file: f.name, n: String(n)}); }
    });
    self.sending.done.then(function (r) {
      self.sending = null;
      if (!self.alive()) { return; }
      self.data = clean(r);
      if (!self.data.upload) { self.data.upload = 'checking'; }
      self.render(t('up_sent', {file: f.name}));
      self.node.querySelector('#fp-up-h').focus();
      self.poll();
    }, function (err) {
      self.sending = null;
      if (!self.alive()) { return; }
      if (err.status === 401) { FP.signedOut(true); return; }
      self.render(err.code === 'aborted' ? t('up_stopped') : '');
      var now = self.node.querySelector('.fp-up-form');
      /* past the uploads allowed in a day: when the next one may be sent, from Retry-After */
      if (err.status === 429 && err.retryAfter) {
        err = {status: 429, message: t('up_limited', {when: when(new Date(Date.now() + err.retryAfter * 1000).toISOString())})};
      }
      if (err.code !== 'aborted') { M.fieldError(now, now.querySelector('#fp-up-file'), err.message); } else { now.querySelector('#fp-up-file').focus(); }
      if (err.status === 409) { self.refresh(); }
    });
  };
  Card.prototype.render = function (said) {
    var b = this.body();
    var onHead = document.activeElement && document.activeElement.id === 'fp-dl-h' && b.contains(document.activeElement);
    b.textContent = '';
    var head = el('h2', {class: 'fp-h2', id: 'fp-dl-h', tabindex: '-1', text: this.title()});
    b.appendChild(head);
    b.appendChild(M.errorLine());
    b.appendChild(M.statusLine());
    b.appendChild(el('p', {class: 'fp-muted', text: t('dl_desc')}));
    if (this.data.queued) {
      b.appendChild(el('p', {class: 'fp-dl-making', 'data-fp-dl-queued': '', text: t('dl_queued')}));
    } else if (this.data.making) {
      b.appendChild(el('p', {class: 'fp-dl-making', 'data-fp-dl-making': '', text: t('dl_making')}));
    }
    if (this.data.error && !this.data.making) { b.appendChild(el('p', {class: 'fp-bk-bad', 'data-fp-dl-error': '', text: t('dl_last_failed', {error: this.data.error})})); }
    b.appendChild(this.readyPart());
    b.appendChild(this.formPart());
    if (canUpload()) { b.appendChild(this.uploadPart()); }
    if (this.opts.onClose) { this.node.querySelector('.fp-dl-form .fp-actions').appendChild(this.closeButton()); }
    if (said) { M.say(this.node, said); }
    /* a redraw (the first load ending, a refresh) leaves the focus where the person had it */
    if (onHead) { head.focus(); }
  };
  /* GET again, keeping the form's choice; used after a refusal and when a removal fails */
  Card.prototype.refresh = function () {
    var self = this;
    return FP.call('get', 'backupDownload', undefined, self.account).then(function (r) {
      if (!self.alive()) { return; }
      var shown = self.node.querySelector('.fp-dl-form [data-fp-error]');
      var text = shown ? shown.textContent : '';
      var upShown = self.node.querySelector('.fp-up-form [data-fp-error]');
      var upText = upShown ? upShown.textContent : '';
      self.data = clean(r);
      self.render();
      if (text) { UI.showError(self.node.querySelector('.fp-dl-form'), text); }
      if (upText && self.node.querySelector('.fp-up-form')) { UI.showError(self.node.querySelector('.fp-up-form'), upText); }
      if (self.data.making || self.data.upload) { self.poll(); }
    }, function () {});
  };
  /* draws the card again, saying said, with the focus back where it was (or on focusTo when that went away) */
  Card.prototype.redraw = function (said, focusTo) {
    var at = document.activeElement;
    var inside = at && this.node.contains(at);
    var id = inside && at.id ? at.id : '';
    this.render(said);
    var again = id ? this.node.querySelector('#' + window.CSS.escape(id)) : null;
    if (again) { again.focus(); } else if (inside) { (this.node.querySelector(focusTo || '#fp-dl-h') || this.node.querySelector('#fp-dl-h')).focus(); }
  };
  Card.prototype.poll = function () {
    var self = this;
    window.clearTimeout(self.timer);
    self.timer = window.setTimeout(function () {
      if (!self.alive()) { return; }
      FP.call('get', 'backupDownload', undefined, self.account).then(function (r) {
        if (!self.alive()) { return; }
        var st = clean(r);
        if (st.making || st.upload) {
          /* a copy waiting its turn then being made, an upload checked, queued, then restored: the lines say which */
          var changed = st.queued !== self.data.queued || st.making !== self.data.making || st.upload !== self.data.upload;
          var copied = self.data.making && !st.making;
          self.data = st;
          if (changed) { self.redraw(copied ? (st.error && !st.download ? t('dl_failed_now', {error: st.error}) : t('dl_ready_now')) : ''); }
          self.poll();
          return;
        }
        if (self.data.upload) {
          /* an upload ended: say how, and leave the focus where the person had it */
          var l = st.lastRestore;
          var was = self.data.upload;
          self.data = st;
          self.redraw(was !== 'restoring' && !l ? t('up_ended_early') : !l ? t('up_ended') : l.error ? t('up_failed_now', {error: l.error}) :
            (l.notes.length ? t('up_done_notes') : t('up_done_now')), '#fp-up-h');
          return;
        }
        /* a tick left over after an upload was cancelled finds nothing to say */
        if (!self.data.making) { return; }
        /* a finished copy takes focus unless the person is choosing the next one in the form */
        var a = document.activeElement;
        var keep = a && a.id && self.node.contains(a) && a.closest('.fp-dl-form') ? a.id : '';
        var inCard = a && self.node.contains(a);
        self.data = st;
        self.render(st.error && !st.download ? t('dl_failed_now', {error: st.error}) : t('dl_ready_now'));
        var back = keep ? self.node.querySelector('#' + window.CSS.escape(keep)) : null;
        /* a copy the person can't fetch (a reseller, for a copy holding the account's credentials) has no Download link */
        var link = st.download ? self.node.querySelector('[data-fp-dl-link]') : null;
        if (back) { back.focus(); } else if (link) { link.focus(); } else if (inCard) { self.node.querySelector('.fp-dl-form .fp-submit').focus(); }
      }, function () { self.poll(); });
    }, POLL_MS);
  };
  Card.prototype.onClick = function (e) {
    var self = this;
    var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !self.node.contains(b)) { return; }
    var a = b.getAttribute('data-fp-act');
    var acts = self.node.querySelector('[data-fp-dl-acts]');
    if (a === 'up-no') {
      /* the question gives way to the button again, keeping the chosen file */
      self.asked = null;
      var upActs = self.node.querySelector('[data-fp-up-acts]');
      upActs.textContent = '';
      upActs.appendChild(el('button', {class: 'sig-btn sig-btn--secondary fp-submit', type: 'submit', text: t('up_send')}));
      self.node.querySelector('#fp-up-file').focus();
    } else if (a === 'up-yes') {
      self.send();
    } else if (a === 'up-stop') {
      if (self.sending) { self.sending.abort(); }
    } else if (a === 'up-cancel') {
      UI.setBusy(b, true);
      FP.call('del', 'backupUploadCancel', undefined, self.account).then(function () {
        self.data.upload = '';
        self.render(t('up_cancelled'));
        self.node.querySelector('#fp-up-file').focus();
      }, function (err) {
        /* it started meanwhile (409) or was gone (404): the server's words, then how it stands now */
        self.refresh().then(function () {
          if (!self.alive()) { return; }
          var up = self.node.querySelector('.fp-up-form');
          if (up) { UI.showError(up, err.message); }
          (self.node.querySelector('#fp-up-h') || self.node.querySelector('#fp-dl-h')).focus();
        });
      });
    } else if (a === 'dl-close') {
      self.stop();
      self.opts.onClose();
    } else if (a === 'dl-remove') {
      acts.textContent = '';
      var q = el('span', {class: 'fp-mail-confirm', id: 'fp-dl-ask', text: t('dl_remove_ask')});
      var yes = el('button', {class: 'sig-btn sig-btn--danger', type: 'button', 'data-fp-act': 'dl-remove-yes', 'aria-describedby': 'fp-dl-ask', text: t('dl_remove')});
      var no = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'dl-remove-no', 'aria-describedby': 'fp-dl-ask', text: t('cancel')});
      acts.appendChild(q);
      acts.appendChild(yes);
      acts.appendChild(no);
      no.focus();
    } else if (a === 'dl-remove-no') {
      self.render();
      self.node.querySelector('[data-fp-act="dl-remove"]').focus();
    } else if (a === 'dl-remove-yes') {
      UI.setBusy(b, true);
      FP.call('del', 'backupDownload', undefined, self.account).then(function () {
        self.data.download = null;
        self.render(t('dl_removed'));
        self.node.querySelector('#fp-dl-h').focus();
      }, function (err) {
        self.render();
        UI.showError(self.node, err.message);
        var again = self.node.querySelector('[data-fp-act="dl-remove"]');
        if (again) { again.focus(); }
      });
    }
  };
  Card.prototype.closeButton = function () {
    return el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'dl-close', text: t('dl_close')});
  };
  Card.prototype.stop = function () {
    window.clearTimeout(this.timer);
    if (this.sending) { this.sending.abort(); }
  };

  FP.backupDownload = {card: function (account, opts) { return new Card(account, opts); }};
  /* leaving the page stops an archive still being sent, so no restore starts that nobody is watching */
  var sendingNow = [];
  window.addEventListener('hashchange', function () {
    window.setTimeout(function () {
      sendingNow = sendingNow.filter(function (c) {
        if (c.sending && !c.alive()) { c.sending.abort(); }
        return Boolean(c.sending) && c.alive();
      });
    }, 0);
  });

  var mine = null;
  var own = null;
  FP.view('tool:backups', function () {
    if (mine) { mine.stop(); mine = null; }
    if (own) { own.stop(); own = null; }
    var tool = FP.tools.backups;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('backups_desc'), cls: 'fp-mail fp-dl-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    mine = new Card(FP.account());
    body.appendChild(mine.node);
    /* the account's own login may also put back chosen items of its kept backups, where the server offers it (fp-ownrestore.js) */
    if (FP.ownRestore && Array.isArray(FP.session.features) && FP.session.features.indexOf('backup_restore') >= 0) {
      own = FP.ownRestore.card({account: FP.account()});
      body.appendChild(own.node);
    }
  });
})();

/* freePanel's administrator page for the database servers' settings (docs/api.md, "Database server settings"): the few settings of MariaDB
   and PostgreSQL an administrator tunes for the machine's size and load (#/tool/db_config). Each server has a card with its settings; a
   setting has a box for the number freePanel sets, what the running server has now, and what the setting does. What a server answers is
   shown as text, and a setting is named only by the server's own list. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var el = UI.el;
  var M = FP.mail;

  var t = UI.t;

  var ENGINES = [
    {engine: 'mysql', id: 'local-mysql', title: 'dc_title_mysql', off: 'dc_off_mysql', note: 'dc_note_mysql'},
    {engine: 'postgres', id: 'local-postgres', title: 'dc_title_postgres', off: 'dc_off_postgres', note: 'dc_note_postgres'}
  ];
  var NAME_RE = /^[a-z][a-z0-9_]{0,63}$/;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 200) : ''; }
  function num(v, hi) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.min(Math.floor(v), hi || 1e15) : 0; }
  function orNull(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.floor(v) : null; }
  function count(n) { return Math.round(n).toLocaleString('en'); }
  function admin() { return FP.realm === 'admin' && FP.session.user.role === 'admin'; }
  function described(name, prefix) { var k = prefix + name; return window.FPSTRINGS[k] ? t(k) : ''; }

  /* what a server answers, cleaned to the shapes drawn */
  function cleanConfig(r) {
    r = r && typeof r === 'object' ? r : {};
    var list = (Array.isArray(r.settings) ? r.settings : []).slice(0, 100).filter(function (s) { return s && typeof s.name === 'string' && NAME_RE.test(s.name); }).map(function (s) {
      var kind = s.kind === 'mb' || s.kind === 'seconds' || s.kind === 'bool' ? s.kind : 'int';
      return {name: s.name, kind: kind, min: num(s.min), max: num(s.max) || 1e15, value: orNull(s.value), live: orNull(s.live), restart: s.restart === true, pending: s.restart_pending === true};
    });
    return {running: r.running === true, error: str(r.error, 300), memory: num(r.memory_mb, 1e9), settings: list};
  }
  function unit(kind) { return kind === 'mb' ? t('dc_unit_mb') : (kind === 'seconds' ? t('dc_unit_seconds') : ''); }
  function show(s, n) {
    if (s.kind === 'bool') { return t(n ? 'dc_on' : 'dc_off'); }
    return count(n) + (unit(s.kind) ? ' ' + unit(s.kind) : '');
  }
  function memoryText(mb) { return mb >= 1024 ? (Math.round(mb / 102.4) / 10).toLocaleString('en') + ' GB' : count(mb) + ' MB'; }

  var C = null;

  function field(e, s) {
    var id = 'fp-dc-' + e.engine + '-' + s.name;
    var label = el('label', {class: 'sig-label', for: id}, [described(s.name, 'dc_s_') || s.name, ' ', el('code', {class: 'sig-mono fp-dc-code', text: '(' + s.name + ')'})]);
    var control;
    if (s.kind === 'bool') {
      control = el('select', {class: 'sig-select', id: id, name: s.name, 'aria-describedby': id + '-hint'}, [
        el('option', {value: '', text: t('dc_server_default')}), el('option', {value: '0', text: t('dc_off')}), el('option', {value: '1', text: t('dc_on')})]);
      control.value = s.value === null ? '' : String(s.value);
    } else {
      control = el('input', {class: 'sig-input fp-dc-num', id: id, name: s.name, type: 'text', inputmode: 'numeric', autocomplete: 'off', spellcheck: 'false',
        value: s.value === null ? '' : String(s.value), 'aria-describedby': id + '-hint'});
    }
    var now;
    if (s.live === null) { now = t('dc_now_unknown'); } else if (s.pending) { now = t('dc_waiting', {value: show(s, s.live)}); } else { now = t('dc_now', {value: show(s, s.live)}); }
    var hint = [described(s.name, 'dc_d_'), s.kind === 'bool' ? '' : t('dc_range', {min: count(s.min), max: count(s.max)}), s.restart ? t('dc_needs_restart') : ''].filter(Boolean).join(' ');
    return el('div', {class: 'fp-dc-row', 'data-fp-setting': s.name}, [
      el('div', {class: 'fp-dc-name'}, [label, el('span', {class: 'sig-hint', id: id + '-hint', text: hint})]),
      el('div', {class: 'fp-dc-set'}, [control, unit(s.kind) && s.kind !== 'bool' ? el('span', {class: 'fp-muted', text: unit(s.kind)}) : null,
        el('span', {class: 'fp-dc-now' + (s.pending ? ' fp-dc-wait' : ''), 'data-fp-now': '', text: now})])]);
  }
  function restartNote(cfg) {
    var names = cfg.settings.filter(function (s) { return s.pending; }).map(function (s) { return s.name; });
    if (!names.length) { return null; }
    /* the setting names are the server's own words, not text of the panel: they go in code, so they are never taken for a string key */
    var sentence = t('dc_restart_note', {names: '\u0001'}).split('\u0001');
    return el('p', {class: 'fp-dc-restart', 'data-fp-restart': ''}, [sentence[0], el('code', {class: 'sig-mono', text: names.join(', ')}), sentence[1] || '', ' ',
      el('a', {href: '#/tool/service_manager', text: t('dc_restart_link')})]);
  }
  function card(e, entry) {
    var h = 'fp-dc-h-' + e.engine;
    if (entry.off) {
      return M.card(h, t(e.title), [el('p', {class: 'fp-muted', 'data-fp-off': '', text: t(e.off)})], 'fp-dc fp-dc-' + e.engine);
    }
    if (entry.failed) {
      return M.card(h, t(e.title), [el('div', {class: 'fp-alert is-shown', role: 'alert', 'data-fp-error': '', text: t('dc_failed_load', {name: t(e.title), why: entry.failed})}), el('div', {class: 'fp-actions'}, [
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'dc-again', 'data-fp-engine': e.engine, text: t('status_again')})])], 'fp-dc fp-dc-' + e.engine);
    }
    var cfg = entry.cfg;
    var lines = [el('p', {class: 'fp-muted', text: cfg.memory ? t('dc_memory', {mb: memoryText(cfg.memory)}) : t('dc_memory_unknown')})];
    if (!cfg.running) { lines.push(el('p', {class: 'fp-dc-wait', 'data-fp-down': '', text: t('dc_down', {why: cfg.error ? cfg.error.replace(/^the server did not answer: /, '') : '—'})})); }
    var form = el('form', {class: 'fp-dc-form', 'data-fp-config': e.engine, novalidate: ''}, [
      el('div', {class: 'fp-dc-rows'}, cfg.settings.map(function (s) { return field(e, s); })),
      el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': ''}),
      M.statusLine(),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('dc_save')})])]);
    form.addEventListener('submit', function (ev) { ev.preventDefault(); save(e, form); });
    var note = restartNote(cfg);
    return M.card(h, t(e.title), lines.concat([note, form, el('p', {class: 'fp-muted fp-dc-foot', text: t(e.note)})].filter(Boolean)), 'fp-dc fp-dc-' + e.engine);
  }
  function entryOf(engine) { return C.entries[engine]; }
  function draw(engine, focus) {
    var e = ENGINES.filter(function (x) { return x.engine === engine; })[0];
    var old = C.page.querySelector('.fp-dc-' + engine);
    var made = card(e, entryOf(engine));
    if (old) { old.replaceWith(made); } else { C.page.appendChild(made); }
    var target = focus ? C.page.querySelector(focus) : null;
    if (target) { target.focus(); }
    return made;
  }

  /* the numbers typed that differ from what freePanel has set: a number to give, null to take away */
  function changes(e, form) {
    var cfg = entryOf(e.engine).cfg;
    var out = {};
    var n = 0;
    for (var i = 0; i < cfg.settings.length; i++) {
      var s = cfg.settings[i];
      var input = form.elements[s.name];
      if (!input) { continue; }
      var raw = String(input.value).trim();
      var want = null;
      if (raw !== '') {
        if (!/^[0-9]{1,15}$/.test(raw) || Number(raw) < s.min || Number(raw) > s.max) {
          M.fieldError(form, input, t('dc_bad_number', {min: count(s.min), max: count(s.max)}));
          return null;
        }
        want = Number(raw);
      }
      if (want !== s.value) { out[s.name] = want; n++; }
    }
    return {map: out, n: n};
  }
  function save(e, form) {
    var go = M.start(form);
    if (!go) { return; }
    var mine = C;
    var got = changes(e, form);
    if (!got) { return; }
    if (!got.n) { UI.setBusy(go, false); M.say(form, t('dc_nothing')); return; }
    UI.setBusy(go, true);
    FP.call('put', 'dbConfig', {settings: got.map}, {id: e.id}).then(function (r) {
      if (C !== mine) { return; }
      entryOf(e.engine).cfg = cleanConfig(r);
      var made = draw(e.engine, '[data-fp-config] .fp-submit');
      M.say(made.querySelector('form'), got.n === 1 ? t('dc_saved_one') : t('dc_saved_n', {n: String(got.n)}));
    }, function (err) {
      if (C !== mine) { return; }
      UI.setBusy(go, false);
      M.failed(form, err);
    });
  }

  /* a 503 with the API's words for a server that is off is a server that is not set up, which is not a failure; the other 503, "the server agent
     is not running", is one: the page must not say a server is not set up when it cannot be asked */
  function notSetUp(err) { return Boolean(err) && err.status === 503 && /not turned on for this server/.test(err.message || ''); }
  function load(engine) {
    var e = ENGINES.filter(function (x) { return x.engine === engine; })[0];
    var mine = C;
    return FP.call('get', 'dbConfig', undefined, {id: e.id}).then(function (r) {
      if (C === mine) { C.entries[engine] = {cfg: cleanConfig(r)}; }
    }, function (err) {
      if (C !== mine) { return; }
      C.entries[engine] = notSetUp(err) ? {off: true} : {failed: err && err.message ? err.message : t('api_failed')};
    });
  }
  document.addEventListener('click', function (ev) {
    var b = ev.target && ev.target.closest ? ev.target.closest('[data-fp-act="dc-again"]') : null;
    if (!b || !C || !C.page.contains(b) || b.disabled) { return; }
    var engine = b.getAttribute('data-fp-engine');
    if (!entryOf(engine)) { return; }
    var mine = C;
    UI.setBusy(b, true);
    load(engine).then(function () {
      if (C !== mine) { return; }
      draw(engine, '#fp-dc-h-' + engine);
    });
  });

  FP.view('tool:db_config', function () {
    C = null;
    var tool = FP.tools.db_config;
    if (!tool || !admin()) { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('db_config_desc'), cls: 'fp-mail fp-dc-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    if (!page) { return; }
    C = {page: page, entries: {}};
    var mine = C;
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all(ENGINES.map(function (e) { return load(e.engine); })).then(function () {
      if (C !== mine) { return; }
      page.textContent = '';
      var anyOn = ENGINES.some(function (e) { return !entryOf(e.engine).off; });
      if (!anyOn) { page.appendChild(FP.empty(t('dc_none_title'), t('dc_none'))); return; }
      page.appendChild(el('p', {class: 'fp-muted fp-dc-what', text: t('dc_what')}));
      ENGINES.forEach(function (e) { page.appendChild(card(e, entryOf(e.engine))); });
    });
  });
})();

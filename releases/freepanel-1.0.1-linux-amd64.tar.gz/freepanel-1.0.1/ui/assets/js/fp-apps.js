/* freePanel app installer (docs/api.md, "Domains and sites": the app installer): the customer's App installer page
   (#/tool/app_installer: install WordPress on one of the account's websites, see what is installed, take an install out) and
   the admin's App installer page (#/tool/web_apps: the switch that lets customers install apps, the release the server keeps
   and a check for a newer one). The installer is off until an admin turns it on, and the server fetches an app only when an
   admin turns it on, presses Check, and once a day; the customer page says so when it is off, and still lists and removes
   what is installed. What the server sends is cleaned to the shapes drawn here and shown as text; an address becomes a link
   only when it is an http or https one. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var POLL_MS = 3000;
  var URL_RE = /^https?:\/\/[^\s<>"]{1,2040}$/i;
  var DOMAIN_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var APP_RE = /^[a-z0-9][a-z0-9_-]{0,31}$/;
  var ID_RE = /^[0-9a-f]{16}$/;
  var USER_RE = /^[A-Za-z0-9_.@-]{1,60}$/;
  var EMAIL_RE = /^[^\s@<>(),;:"\\[\]]{1,64}@[^\s@<>(),;:"\\[\]]{1,190}$/;
  var FOLDER_PART_RE = /^[A-Za-z0-9_][A-Za-z0-9_.-]{0,127}$/;
  var PHP_RE = /^[0-9]{1,2}\.[0-9]{1,2}$/;
  /* past this many apps the admin's list gets a filter */
  var FILTER_FROM = 8;
  var MAX_TITLE = 100;
  var MIN_PASSWORD = 12;

  function str(v) { return typeof v === 'string' ? v : ''; }
  function link(v) { v = str(v); return URL_RE.test(v) ? v : ''; }
  function when(iso) { return iso ? (FP.bk ? FP.bk.when(iso) : '') || iso : ''; }
  function a(url, text) {
    return url ? el('a', {href: url, target: '_blank', rel: 'noopener noreferrer', text: text || url}) : el('span', {text: text || ''});
  }

  /* ================= admin: the switch and the release on file ================= */
  var AD = null;

  function cleanAdmin(r) {
    r = r && typeof r === 'object' ? r : {};
    var apps = (Array.isArray(r.apps) ? r.apps : []).filter(function (x) { return x && APP_RE.test(str(x.id)); }).map(function (x) {
      return {id: x.id, name: str(x.name).slice(0, 60) || x.id, category: str(x.category).slice(0, 40), minPhp: PHP_RE.test(str(x.min_php)) ? x.min_php : '',
        maxPhp: PHP_RE.test(str(x.max_php)) ? x.max_php : '', listable: x.listable !== false,
        offered: x.offered === true, error: str(x.error).slice(0, 400),
        version: /^[0-9][0-9.]{0,31}$/.test(str(x.version)) ? x.version : '', fetched: str(x.fetched)};
    });
    return {enabled: r.enabled === true, last: str(r.last_check), error: str(r.last_error).slice(0, 400), checking: r.checking === true, apps: apps};
  }
  function adminState() {
    var st = AD.st;
    if (!st.enabled) { return t('apa_state_off'); }
    return going() ? t('apa_state_checking') : t('apa_state_on');
  }
  /* a check is going from the moment one is asked for, though the server may take a moment to show it */
  function going() { return AD.st.checking || (AD.watching && !AD.seen); }
  function releaseTable(st) {
    if (!st.apps.length) { return null; }
    return el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-ap-status-h'}, [
      el('table', {class: 'sig-table fp-mail-table fp-ap-releases'}, [el('thead', null, [el('tr', null, [
        el('th', {scope: 'col', text: t('apa_app')}), el('th', {scope: 'col', text: t('apa_release')}), el('th', {scope: 'col', text: t('apa_fetched')})])]),
      el('tbody', null, st.apps.filter(function (x) { return x.offered; }).map(function (x) {
        return el('tr', {'data-fp-app': x.id}, [el('th', {scope: 'row', class: 'fp-mail-name', text: x.name}),
          el('td', null, [x.version ? el('span', {class: 'sig-mono', text: x.version}) : el('span', {class: 'fp-muted', text: t('apa_none_yet')}),
            x.error ? el('div', {class: 'fp-ap-app-error', 'data-fp-ap-app-error': '', text: t('apa_app_failed', {error: x.error})}) : null]),
          el('td', null, [x.fetched ? el('span', {text: when(x.fetched)}) : el('span', {class: 'fp-muted', text: '—'})])]);
      }))])]);
  }
  /* the apps on offer: a box for each app in the catalogue, grouped by category, with a filter when the list is long */
  function offerCard() {
    var st = AD.st;
    var groups = {};
    var order = [];
    st.apps.forEach(function (x) {
      var c = x.category || t('apa_other');
      if (!groups[c]) { groups[c] = []; order.push(c); }
      groups[c].push(x);
    });
    var count = el('p', {class: 'fp-muted', 'data-fp-ap-count': '', 'aria-live': 'polite'});
    function counted() {
      var n = form.querySelectorAll('input[name="offered"]:checked').length;
      count.textContent = t('apa_offer_count', {n: n, total: st.apps.length});
    }
    var sets = order.map(function (c, i) {
      return el('fieldset', {class: 'fp-ap-offer-group', 'data-fp-ap-group': c}, [el('legend', {class: 'fp-ap-offer-legend', text: c}),
        el('ul', {class: 'fp-ap-offer-list', role: 'list'}, groups[c].map(function (x) {
          var id = 'fp-ap-offer-' + x.id;
          var box = el('input', {type: 'checkbox', id: id, name: 'offered', value: x.id});
          box.checked = x.offered && x.listable;
          /* an app that runs on no PHP version with security fixes cannot be offered: the server refuses it */
          box.disabled = !x.listable;
          var note = !x.listable ? t('apa_no_secure_php') : x.minPhp && x.maxPhp ? t('apa_php_range', {min: x.minPhp, max: x.maxPhp}) : x.minPhp ? t('apa_min_php', {version: x.minPhp}) : '';
          return el('li', {'data-fp-ap-offer': x.id, 'data-fp-ap-name': x.name.toLowerCase()}, [
            el('label', {class: 'fp-check', for: id}, [box, el('span', {text: x.name}), note ? el('span', {class: 'fp-muted fp-ap-offer-php', text: note}) : null])]);
        }))], i);
    });
    var filter = null;
    if (st.apps.length > FILTER_FROM) {
      filter = el('input', {type: 'search', class: 'sig-input', id: 'fp-ap-offer-filter', autocomplete: 'off', 'aria-describedby': 'fp-ap-offer-count'});
      filter.addEventListener('input', function () {
        var q = filter.value.trim().toLowerCase();
        form.querySelectorAll('[data-fp-ap-offer]').forEach(function (li) {
          li.hidden = q !== '' && li.getAttribute('data-fp-ap-name').indexOf(q) < 0 && li.getAttribute('data-fp-ap-offer').indexOf(q) < 0;
        });
        form.querySelectorAll('.fp-ap-offer-group').forEach(function (g) {
          g.hidden = !g.querySelector('[data-fp-ap-offer]:not([hidden])');
        });
      });
    }
    count.id = 'fp-ap-offer-count';
    var form = el('form', {class: 'fp-form fp-mail-form fp-ap-offer', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('p', {class: 'sig-hint', text: t('apa_offer_hint')}),
      filter ? el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: 'fp-ap-offer-filter', text: t('apa_offer_filter')}), filter]) : null,
      count, el('div', {class: 'fp-ap-offer-groups'}, sets),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('apa_offer_save')})])]);
    form.addEventListener('change', counted);
    counted();
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var mine = AD;
      var before = mine.st.last;
      var ids = Array.prototype.map.call(form.querySelectorAll('input[name="offered"]:checked'), function (x) { return x.value; });
      UI.setBusy(b, true);
      FP.call('put', 'webApps', {offered: ids}).then(function (r) {
        UI.setBusy(b, false);
        if (AD !== mine) { return; }
        mine.st = cleanAdmin(r);
        /* an app newly on offer is fetched in the background while the installer is on */
        var fresh = mine.st.apps.some(function (x) { return x.offered && !x.version; });
        if (mine.st.enabled && fresh) { watch(before); } else { drawStatus(); }
        M.say(form, t(fresh && mine.st.enabled ? 'apa_offer_saved_fetch' : 'apa_offer_saved'));
      }, function (err) {
        UI.setBusy(b, false);
        if (AD === mine) { M.failed(form, err); }
      });
    });
    return M.card('fp-ap-offer-h', t('apa_offer_title'), [form], 'fp-ap-offer-card');
  }
  function statusCard() {
    var st = AD.st;
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-ap-state', 'data-fp-ap-state': ''}, [
      el('span', {class: 'sig-pill' + (st.enabled ? ' sig-pill--ok' : ''), text: t(st.enabled ? 'apa_pill_on' : 'apa_pill_off')}),
      el('span', {text: adminState()})])];
    if (st.error) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-ap-error': ''}, [UI.icon(FP.ui, 'ui_warning'),
        el('span', {text: t('apa_last_failed', {error: st.error})})]));
    }
    var table = releaseTable(st);
    if (table) { parts.push(table); }
    parts.push(el('p', {class: 'fp-muted', 'data-fp-ap-last': '', text: st.last ? t('apa_last', {when: when(st.last)}) : t('apa_last_none')}));
    if (st.enabled) {
      parts.push(el('div', {class: 'fp-actions'}, [going() ?
        el('p', {class: 'fp-muted', 'data-fp-ap-going': '', text: t('apa_going')}) :
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'check', text: t('apa_check')})]));
    }
    return M.card('fp-ap-status-h', t('apa_status_title'), parts, 'fp-ap-status');
  }
  function drawStatus() {
    var old = AD.page.querySelector('.fp-ap-status');
    var fresh = statusCard();
    var active = document.activeElement;
    var act = old && active && old.contains(active) ? active.getAttribute('data-fp-act') : null;
    if (old) { old.replaceWith(fresh); } else { AD.page.insertBefore(fresh, AD.page.firstChild); }
    if (act) {
      var again = fresh.querySelector('[data-fp-act="' + act + '"]') || fresh.querySelector('#fp-ap-status-h');
      if (again) { again.focus(); }
    }
  }
  function settingsCard() {
    var box = el('input', {type: 'checkbox', id: 'fp-ap-enabled', name: 'enabled', 'aria-describedby': 'fp-ap-enabled-hint'});
    box.checked = AD.st.enabled;
    var form = el('form', {class: 'fp-form fp-mail-form fp-ap-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('label', {class: 'fp-check', for: 'fp-ap-enabled'}, [box, el('span', {text: t('apa_enabled')})]),
      el('p', {class: 'sig-hint', id: 'fp-ap-enabled-hint', text: t('apa_enabled_hint')}),
      el('p', {class: 'fp-muted fp-ap-outward', 'data-fp-ap-outward': '', text: t('apa_outward')}),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('apa_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var mine = AD;
      var before = mine.st.last;
      UI.setBusy(b, true);
      FP.call('put', 'webApps', {enabled: box.checked}).then(function (r) {
        UI.setBusy(b, false);
        if (AD !== mine) { return; }
        mine.st = cleanAdmin(r);
        box.checked = mine.st.enabled;
        /* turning it on asks for a check, which goes on in the background */
        if (mine.st.enabled) { watch(before); } else { mine.watching = false; drawStatus(); }
        M.say(form, t(mine.st.enabled ? 'apa_saved_on' : 'apa_saved_off'));
      }, function (err) {
        UI.setBusy(b, false);
        if (AD === mine) { M.failed(form, err); }
      });
    });
    return M.card('fp-ap-settings-h', t('apa_settings_title'), [form], 'fp-ap-settings');
  }
  /* asks how the check is every few seconds while one goes on (or is about to start); when it ends, says how */
  function poll() {
    window.clearTimeout(AD.timer);
    var mine = AD;
    AD.timer = window.setTimeout(function () {
      if (AD !== mine || !document.body.contains(mine.page)) { return; }
      FP.call('get', 'webApps').then(function (r) {
        if (AD !== mine) { return; }
        var fresh = cleanAdmin(r);
        mine.st = fresh;
        if (fresh.checking) { mine.seen = true; drawStatus(); poll(); return; }
        /* a check asked for has not shown yet: look a few times more before giving up on it */
        if (mine.watching && !mine.seen && fresh.last === mine.from && mine.tries++ < 3) { drawStatus(); poll(); return; }
        mine.watching = false;
        drawStatus();
        M.say(mine.page.querySelector('.fp-ap-status'), fresh.error ? t('apa_ended_failed') : t('apa_ended'));
      }, function () { if (AD === mine) { poll(); } });
    }, POLL_MS);
  }
  /* from: the time of the last check before the one asked for, to tell when the new one has ended */
  function watch(from) {
    AD.watching = true;
    AD.seen = AD.st.checking;
    AD.from = from;
    AD.tries = 0;
    drawStatus();
    poll();
  }
  function adminClick(b) {
    if (b.getAttribute('data-fp-act') !== 'check') { return; }
    var mine = AD;
    var card = AD.page.querySelector('.fp-ap-status');
    UI.showError(card, '');
    M.say(card, '');
    UI.setBusy(b, true);
    var before = mine.st.last;
    FP.call('post', 'webAppsCheck').then(function (r) {
      if (AD !== mine) { return; }
      mine.st = cleanAdmin(r);
      watch(before);
      mine.page.querySelector('#fp-ap-status-h').focus();
      M.say(mine.page.querySelector('.fp-ap-status'), t('apa_check_started'));
    }, function (err) {
      if (AD !== mine) { return; }
      UI.setBusy(b, false);
      UI.showError(card, err.message);
      b.focus();
    });
  }

  /* ================= customer: install, list, take out ================= */
  var CU = null;

  function cleanSites(list) {
    return (Array.isArray(list) ? list : []).filter(function (s) { return s && DOMAIN_RE.test(str(s.domain)); }).map(function (s) {
      return {domain: s.domain, aliases: (Array.isArray(s.aliases) ? s.aliases : []).filter(function (x) { return DOMAIN_RE.test(str(x)); }),
        folder: str(s.folder).replace(/^\/+|\/+$/g, ''), https: s.https === true, problem: str(s.problem).slice(0, 300)};
    });
  }
  function cleanApps(r) {
    r = r && typeof r === 'object' ? r : {};
    return {apps: (Array.isArray(r.apps) ? r.apps : []).filter(function (x) { return x && APP_RE.test(str(x.id)); }).map(function (x) {
      return {id: x.id, name: str(x.name).slice(0, 60) || x.id, category: str(x.category).slice(0, 40), minPhp: PHP_RE.test(str(x.min_php)) ? x.min_php : '',
        maxPhp: PHP_RE.test(str(x.max_php)) ? x.max_php : '',
        version: /^[0-9][0-9.]{0,31}$/.test(str(x.version)) ? x.version : '', available: x.available === true, updates: x.updates === true};
    }), sites: cleanSites(r.sites)};
  }
  function cleanInstall(x) {
    if (!x || typeof x !== 'object' || !ID_RE.test(str(x.id))) { return null; }
    return {id: x.id, app: str(x.app).slice(0, 32), name: str(x.name).slice(0, 60) || str(x.app), version: str(x.version).slice(0, 32), domain: str(x.domain).slice(0, 253),
      folder: str(x.folder).slice(0, 400), url: link(x.url), adminUrl: link(x.admin_url), database: str(x.database).slice(0, 64), dbUser: str(x.db_user).slice(0, 64),
      installed: str(x.installed), autoUpdate: x.auto_update === true};
  }
  function cleanInstalls(r) {
    return (r && Array.isArray(r.installs) ? r.installs : []).map(cleanInstall).filter(Boolean);
  }
  function installOf(id) { return CU.installs.filter(function (x) { return x.id === id; })[0]; }
  function siteOfName(name) {
    return CU.apps.sites.filter(function (s) { return s.domain === name || s.aliases.indexOf(name) >= 0; })[0];
  }

  /* ---- the form ---- */
  function siteOptions() {
    var opts = [];
    CU.apps.sites.forEach(function (s) {
      [s.domain].concat(s.aliases.slice().sort()).forEach(function (n) {
        var o = el('option', {value: n, text: s.problem ? t('apx_site_problem', {name: n, problem: s.problem}) : n});
        if (s.problem) { o.disabled = true; }
        opts.push(o);
      });
    });
    return opts;
  }
  function firstUsable() {
    var s = CU.apps.sites.filter(function (x) { return !x.problem; })[0];
    return s ? s.domain : '';
  }
  function formCard(app) {
    var base = 'fp-ap';
    var site = el('select', {class: 'sig-select', id: base + '-site', name: 'domain'}, siteOptions());
    site.value = firstUsable();
    var prefix = el('span', {class: 'fp-dom-home sig-mono', 'data-fp-ap-prefix': ''});
    var folder = el('input', {class: 'sig-input', id: base + '-folder', name: 'folder', type: 'text', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none',
      maxlength: '400', placeholder: 'blog', 'aria-describedby': base + '-folder-hint'});
    var title = el('input', {class: 'sig-input', id: base + '-title', name: 'site_title', type: 'text', autocomplete: 'off', maxlength: String(MAX_TITLE)});
    var user = el('input', {class: 'sig-input', id: base + '-user', name: 'admin_user', type: 'text', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', maxlength: '60'});
    var email = el('input', {class: 'sig-input', id: base + '-email', name: 'admin_email', type: 'email', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', maxlength: '254'});
    var pass = el('input', {class: 'sig-input', id: base + '-pass', name: 'admin_password', type: 'password', autocomplete: 'new-password', maxlength: '200',
      'aria-describedby': base + '-pass-hint'});
    var secure = el('p', {class: 'fp-muted fp-ap-secure', 'data-fp-ap-secure': '', role: 'status'});
    function sync() {
      var s = siteOfName(site.value);
      prefix.textContent = s && s.folder ? s.folder + '/' : '';
      prefix.hidden = !prefix.textContent;
      secure.textContent = s && !s.https && !s.problem ? t('apx_http_note') : '';
      secure.hidden = !secure.textContent;
    }
    site.addEventListener('change', sync);
    sync();
    var form = el('form', {class: 'fp-form fp-mail-form fp-ap-install', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-ap-grid'}, [
        M.field(base + '-site', t('apx_site'), site),
        el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: base + '-folder', text: t('apx_folder')}),
          el('div', {class: 'fp-dom-path'}, [prefix, folder]), el('span', {class: 'sig-hint', id: base + '-folder-hint', text: t('apx_folder_hint')})])]),
      secure,
      M.field(base + '-title', t('apx_title'), title, t('apx_title_hint')),
      el('div', {class: 'fp-ap-grid'}, [M.field(base + '-user', t('apx_user'), user, t('apx_user_hint')), M.field(base + '-email', t('apx_email'), email, t('apx_email_hint'))]),
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: base + '-pass', text: t('apx_pass')}), pass,
        el('span', {class: 'sig-hint', id: base + '-pass-hint', text: t('apx_pass_hint', {n: MIN_PASSWORD})})]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('apx_install', {app: app.name})})])]);
    form.addEventListener('submit', function (e) { e.preventDefault(); submitInstall(form, app); });
    return form;
  }
  /* the form's values, or null (and a message on the form) when one can't be sent */
  function readInstall(form) {
    function f(name) { return form.querySelector('[name="' + name + '"]'); }
    var domain = f('domain').value;
    if (!domain) { M.fieldError(form, f('domain'), t('apx_site_none')); return null; }
    var folder = f('folder').value.trim().replace(/^\/+|\/+$/g, '');
    if (folder) {
      var parts = folder.split('/');
      if (parts.length > 3 || parts.some(function (p) { return !FOLDER_PART_RE.test(p); })) { M.fieldError(form, f('folder'), t('apx_folder_bad')); return null; }
    }
    var title = f('site_title').value.trim();
    if (!title || title.length > MAX_TITLE) { M.fieldError(form, f('site_title'), t('apx_title_bad', {n: MAX_TITLE})); return null; }
    var user = f('admin_user').value.trim();
    if (!USER_RE.test(user)) { M.fieldError(form, f('admin_user'), t('apx_user_bad')); return null; }
    var email = f('admin_email').value.trim();
    if (!EMAIL_RE.test(email) || email.length > 254) { M.fieldError(form, f('admin_email'), t('apx_email_bad')); return null; }
    var pass = f('admin_password').value;
    if (pass && pass.length < MIN_PASSWORD) { M.fieldError(form, f('admin_password'), t('apx_pass_short', {n: MIN_PASSWORD})); return null; }
    var body = {domain: domain, site_title: title, admin_user: user, admin_email: email};
    if (folder) { body.folder = folder; }
    if (pass) { body.admin_password = pass; }
    return body;
  }
  function submitInstall(form, app) {
    var b = M.start(form);
    if (!b) { return; }
    var body = readInstall(form);
    if (!body) { return; }
    var mine = CU;
    UI.setBusy(b, true);
    M.say(form, t('apx_installing', {app: app.name}));
    FP.call('post', 'appInstall', body, {name: CU.account, app: app.id}).then(function (r) {
      if (CU !== mine) { return; }
      var done = cleanInstall(r && r.install);
      if (!done) { UI.setBusy(b, false); M.say(form, ''); M.fieldError(form, null, t('apx_bad_answer')); return; }
      mine.installs = mine.installs.filter(function (x) { return x.id !== done.id; });
      mine.installs.unshift(done);
      mine.done = {install: done, user: str(r.admin_user), email: str(r.admin_email), password: str(r.admin_password)};
      render();
      var card = mine.page.querySelector('.fp-ap-done');
      if (card) { card.querySelector('h2').focus(); }
    }, function (err) {
      if (CU !== mine) { return; }
      UI.setBusy(b, false);
      M.say(form, '');
      var field = err.field ? UI.fieldNamed(form, err.field) : null;
      if (field) { M.failed(form, err); } else { M.fieldError(form, /folder/i.test(err.message) ? form.querySelector('[name="folder"]') : null, err.message); }
    });
  }

  /* ---- the answer to an install ---- */
  function fact(label, content, cls) {
    return el('div', {class: cls || null}, [el('dt', {text: label}), el('dd', null, content)]);
  }
  function doneCard() {
    var d = CU.done;
    var i = d.install;
    var facts = [
      fact(t('apx_f_address'), [a(i.url)]),
      fact(t('apx_f_signin'), [a(i.adminUrl)]),
      fact(t('apx_f_user'), [el('span', {class: 'sig-mono', text: d.user})]),
      fact(t('apx_f_email'), [el('span', {text: d.email})])];
    var parts = [el('p', {class: 'fp-ap-done-lead', text: t('apx_done_lead', {app: i.name, version: i.version})}), el('dl', {class: 'fp-ap-facts'}, facts)];
    if (d.password) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn fp-ap-once', role: 'note', 'data-fp-ap-once': ''}, [UI.icon(FP.ui, 'ui_warning'), el('div', null, [
        el('p', {class: 'fp-ap-once-title', text: t('apx_once_title')}),
        el('p', {class: 'fp-ap-pass sig-mono', 'data-fp-ap-pass': '', text: d.password}),
        el('p', {class: 'fp-muted', text: t('apx_once_hint')}),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'copy', 'data-fp-copy': d.password, text: t('apx_copy')})])]));
    }
    parts.push(M.statusLine());
    parts.push(el('div', {class: 'fp-actions'}, [
      i.adminUrl ? el('a', {class: 'sig-btn sig-btn--primary', href: i.adminUrl, target: '_blank', rel: 'noopener noreferrer', text: t('apx_signin')}) : null,
      el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'again', text: t('apx_another')})]));
    return M.card('fp-ap-done-h', t('apx_done_title', {app: i.name}), parts, 'fp-ap-done');
  }

  /* ---- what is installed ---- */
  function listCard() {
    var parts = [M.errorLine(), M.statusLine()];
    if (!CU.installs.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('apx_none')}));
    } else {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-ap-list-h'}, [
        el('table', {class: 'sig-table fp-mail-table fp-ap-table'}, [el('thead', null, [el('tr', null, [
          el('th', {scope: 'col', text: t('apx_col_app')}),
          el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]),
        el('tbody', null, CU.installs.map(installRow))])]));
    }
    return M.card('fp-ap-list-h', t('apx_list_title'), parts, 'fp-ap-list');
  }
  /* the app's entry when the panel updates its installs, and whether the release on file is newer than the install */
  function updatesOf(x) { return CU.apps.apps.filter(function (a) { return a.id === x.app && a.updates; })[0]; }
  function newer(a, b) {
    var pa = a.split('.'), pb = b.split('.');
    for (var i = 0; i < Math.max(pa.length, pb.length); i++) {
      var d = (parseInt(pa[i], 10) || 0) - (parseInt(pb[i], 10) || 0);
      if (d) { return d > 0; }
    }
    return false;
  }
  function updateControls(x, addr) {
    var app = updatesOf(x);
    if (!app) { return []; }
    var id = 'fp-ap-auto-' + x.id;
    var box = el('input', {type: 'checkbox', id: id, 'data-fp-act': 'auto'});
    box.checked = x.autoUpdate;
    return [
      app.version && x.version && newer(app.version, x.version) ? el('button', {class: 'sig-btn sig-btn--primary sig-btn--sm', type: 'button', 'data-fp-act': 'update',
        text: t('apx_update_to', {version: app.version}), 'aria-label': t('apx_update_of', {address: addr, version: app.version})}) : null,
      el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'undo', text: t('apx_undo'), 'aria-label': t('apx_undo_of', {address: addr})}),
      el('label', {class: 'fp-check fp-ap-auto', for: id}, [box, el('span', {text: t('apx_auto')})])];
  }
  function installRow(x) {
    var addr = x.url ? x.url.replace(/^https?:\/\//i, '') : x.domain;
    return el('tr', {'data-fp-install': x.id}, [
      el('th', {scope: 'row', class: 'fp-mail-name fp-ap-app'}, [el('span', {class: 'fp-ap-name', text: x.name + (x.version ? ' ' + x.version : '')}),
        el('span', {class: 'fp-row-note fp-ap-addr'}, [a(x.url, addr)]),
        el('span', {class: 'fp-muted fp-row-note fp-ap-meta', text: t('apx_meta_folder', {folder: x.folder || '—'})}),
        x.database ? el('span', {class: 'fp-muted fp-row-note fp-ap-meta', text: t('apx_database', {name: x.database})}) : null,
        x.installed ? el('span', {class: 'fp-muted fp-row-note fp-ap-meta', text: t('apx_meta_installed', {when: when(x.installed)})}) : null]),
      el('td', {class: 'fp-mail-acts fp-ap-acts'}, updateControls(x, addr).concat([
        x.app === 'wordpress' ? el('a', {class: 'sig-btn sig-btn--secondary sig-btn--sm', href: '#/tool/wordpress_manager', text: t('apx_manage'), 'aria-label': t('apx_manage_of', {address: addr})}) : null,
        x.adminUrl ? el('a', {class: 'sig-btn sig-btn--secondary sig-btn--sm', href: x.adminUrl, target: '_blank', rel: 'noopener noreferrer', text: t('apx_signin'),
          'aria-label': t('apx_signin_to', {address: addr})}) : null,
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'uninstall', text: t('apx_uninstall'),
          'aria-label': t('apx_uninstall_of', {address: addr})})]))]);
  }
  /* an update or an undo from the list: the answer is said under the list, with what the site answered afterwards */
  function updateApp(b, x, undo) {
    var mine = CU;
    var addr = x.url ? x.url.replace(/^https?:\/\//i, '') : x.domain;
    UI.setBusy(b, true);
    FP.call('post', undo ? 'wpUndo' : 'wpUpdate', undefined, {name: CU.account, id: x.id}).then(function (r) {
      if (CU !== mine) { return; }
      var to = r && /^[0-9][0-9.]{0,31}$/.test(str(r.to)) ? r.to : '';
      var h = r && r.health && typeof r.health === 'object' ? r.health : {};
      if (to) { x.version = to; }
      render();
      var word = undo ? 'apx_undone' : h.rolled_back === true ? 'apx_rolled_back' : h.checked === true ? 'apx_updated' : 'apx_updated_unchecked';
      var card = mine.page.querySelector('.fp-ap-list');
      M.say(card, t(word, {name: x.name, address: addr, version: to, status: String(Number(h.status) || '')}));
      card.querySelector('h2').focus();
    }, function (err) {
      if (CU !== mine) { return; }
      UI.setBusy(b, false);
      UI.showError(mine.page.querySelector('.fp-ap-list'), err.message);
      b.focus();
    });
  }
  function autoApp(box, x) {
    var mine = CU;
    var want = box.checked;
    box.disabled = true;
    FP.call('put', 'appAuto', {auto_update: want}, {name: CU.account, id: x.id}).then(function () {
      if (CU !== mine) { return; }
      x.autoUpdate = want;
      box.disabled = false;
      M.say(mine.page.querySelector('.fp-ap-list'), t(want ? 'apx_auto_on' : 'apx_auto_off', {name: x.name}));
    }, function (err) {
      if (CU !== mine) { return; }
      box.checked = !want;
      box.disabled = false;
      UI.showError(mine.page.querySelector('.fp-ap-list'), err.message);
      box.focus();
    });
  }
  /* the question that stands in place of a row's buttons, under the row's own details where there is room for it: nothing is deleted unless asked for */
  function askUninstall(tr, x) {
    var cell = tr.querySelector('.fp-ap-acts');
    var id = 'fp-ap-ask-' + x.id;
    cell.textContent = '';
    function tick(name, label) {
      return el('label', {class: 'fp-check', for: id + '-' + name}, [el('input', {type: 'checkbox', id: id + '-' + name, name: name}), el('span', {text: label})]);
    }
    var yes = el('button', {class: 'sig-btn sig-btn--danger sig-btn--sm', type: 'button', 'data-fp-act': 'uninstall-yes', text: t('apx_uninstall')});
    var no = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'uninstall-no', text: t('cancel')});
    var q = el('p', {class: 'fp-mail-confirm', id: id, text: t('apx_uninstall_ask', {name: x.name, address: x.url ? x.url.replace(/^https?:\/\//i, '') : x.domain})});
    tr.querySelector('.fp-ap-app').appendChild(el('div', {class: 'fp-ap-ask', role: 'group', 'aria-labelledby': id}, [q,
      tick('remove_files', t('apx_remove_files', {folder: x.folder || x.domain})),
      x.database ? tick('remove_database', t('apx_remove_database', {name: x.database})) : null,
      el('p', {class: 'sig-hint', text: t('apx_uninstall_hint')}), el('div', {class: 'fp-actions'}, [yes, no])]));
    yes.setAttribute('aria-describedby', id);
    no.focus();
  }
  function uninstall(b, tr, x) {
    var ask = tr.querySelector('.fp-ap-ask');
    var files = ask.querySelector('[name="remove_files"]').checked;
    var dbBox = ask.querySelector('[name="remove_database"]');
    var db = dbBox ? dbBox.checked : false;
    var mine = CU;
    UI.setBusy(b, true);
    FP.call('del', 'appUninstall', undefined, {name: CU.account, id: x.id, files: files ? 'true' : 'false', db: db ? 'true' : 'false'}).then(function (r) {
      if (CU !== mine) { return; }
      mine.installs = mine.installs.filter(function (y) { return y.id !== x.id; });
      if (mine.done && mine.done.install.id === x.id) { mine.done = null; }
      render();
      var removedFiles = r && r.removed_files === true;
      var removedDb = r && r.removed_database === true;
      var word = removedFiles && removedDb ? 'apx_removed_both' : removedFiles ? 'apx_removed_files' : removedDb ? 'apx_removed_db' : 'apx_removed_none';
      var card = mine.page.querySelector('.fp-ap-list');
      M.say(card, t(word, {name: x.name, address: x.url ? x.url.replace(/^https?:\/\//i, '') : x.domain}));
      card.querySelector('h2').focus();
    }, function (err) {
      if (CU !== mine) { return; }
      render();
      var card = mine.page.querySelector('.fp-ap-list');
      UI.showError(card, err.message);
      var again = card.querySelector('tr[data-fp-install="' + x.id + '"] [data-fp-act="uninstall"]');
      if (again) { again.focus(); }
    });
  }

  /* ---- the page ---- */
  /* the app picker, when more than one app can be installed: grouped by category */
  function appPicker(ready, app) {
    var groups = {};
    var order = [];
    ready.forEach(function (x) {
      var c = x.category || t('apa_other');
      if (!groups[c]) { groups[c] = []; order.push(c); }
      groups[c].push(x);
    });
    var sel = el('select', {class: 'sig-select', id: 'fp-ap-app', name: 'app'}, order.map(function (c) {
      return el('optgroup', {label: c}, groups[c].map(function (x) {
        var o = el('option', {value: x.id, text: x.name + ' ' + x.version});
        o.selected = x.id === app.id;
        return o;
      }));
    }));
    sel.addEventListener('change', function () {
      CU.pick = sel.value;
      render();
      var again = CU.page.querySelector('#fp-ap-app');
      if (again) { again.focus(); }
    });
    return el('div', {class: 'sig-field fp-ap-pick'}, [el('label', {class: 'sig-label', for: 'fp-ap-app', text: t('apx_app')}), sel]);
  }
  function installCard() {
    var ready = CU.apps.apps.filter(function (x) { return x.available; });
    var app = ready.filter(function (x) { return x.id === CU.pick; })[0] || ready[0];
    var parts = [];
    var form = false;
    if (CU.off) {
      /* the server says why the installer is not on (a 409), and that is shown in its words; the page adds that the list of installs still works */
      var said = typeof CU.offError === 'string' ? CU.offError.trim().slice(0, 300) : '';
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-ap-off': ''},
        [UI.icon(FP.ui, 'ui_warning'), el('span', {text: said ? said + ' ' + t('apx_off_list') : t('apx_off')})]));
    } else if (!app) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-ap-wait': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('apx_no_release')})]));
    } else if (!CU.apps.sites.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('php_no_sites')}));
    } else if (!firstUsable()) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-ap-nosite': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('apx_no_usable_site')})]));
    } else {
      if (ready.length > 1) { parts.push(appPicker(ready, app)); }
      parts.push(el('p', {class: 'fp-muted fp-ap-lead', text: t('apx_lead', {app: app.name, version: app.version})}));
      if (app.minPhp && app.maxPhp) {
        parts.push(el('p', {class: 'fp-muted fp-ap-php', 'data-fp-ap-php': '', text: t('apx_php_range', {app: app.name, min: app.minPhp, max: app.maxPhp})}));
      } else if (app.minPhp) { parts.push(el('p', {class: 'fp-muted fp-ap-php', 'data-fp-ap-php': '', text: t('apx_min_php', {app: app.name, version: app.minPhp})})); }
      parts.push(formCard(app));
      form = true;
    }
    /* the form has its own error line; the other states have this one */
    if (!form) { parts.unshift(M.errorLine()); }
    return M.card('fp-ap-install-h', app ? t('apx_install_title', {app: app.name}) : t('apx_install_title_plain'), parts, 'fp-ap-install-card');
  }
  function render() {
    CU.page.textContent = '';
    if (CU.suspended) { CU.page.appendChild(M.suspendedBanner(t('dom_suspended'))); }
    CU.page.appendChild(CU.done ? doneCard() : installCard());
    CU.page.appendChild(listCard());
  }
  function customerClick(b) {
    var act = b.getAttribute('data-fp-act');
    var tr = b.closest('tr');
    var x = tr ? installOf(tr.getAttribute('data-fp-install')) : null;
    if (act === 'copy') {
      var card = b.closest('.fp-ap-done');
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(b.getAttribute('data-fp-copy')).then(function () { M.say(card, t('copied')); }, function () { M.say(card, t('copy_failed')); });
      } else {
        M.say(card, t('copy_failed'));
      }
    } else if (act === 'again') {
      CU.done = null;
      render();
      CU.page.querySelector('#fp-ap-site, #fp-ap-install-h').focus();
    } else if (act === 'uninstall' && x) {
      askUninstall(tr, x);
    } else if (act === 'uninstall-no' && x) {
      render();
      var back = CU.page.querySelector('tr[data-fp-install="' + x.id + '"] [data-fp-act="uninstall"]');
      if (back) { back.focus(); }
    } else if (act === 'uninstall-yes' && x) {
      uninstall(b, tr, x);
    } else if ((act === 'update' || act === 'undo') && x) {
      updateApp(b, x, act === 'undo');
    } else if (act === 'auto' && x) {
      autoApp(b, x);
    }
  }

  document.addEventListener('click', function (e) {
    var target = e.target && e.target.closest ? e.target : null;
    var b = target ? target.closest('[data-fp-act]') : null;
    if (!b) { return; }
    if (AD && AD.page && AD.page.contains(b)) { adminClick(b); } else if (CU && CU.page && CU.page.contains(b)) { customerClick(b); }
  });

  function frame(id, desc, cls, realm) {
    var tool = FP.tools[id];
    if (!tool || FP.realm !== realm || (realm === 'admin' && FP.session.user.role !== 'admin')) { FP.views['not-found']({view: 'not-found'}); return null; }
    var g = FP.group(tool.group);
    return {tool: tool, body: FP.frame({title: tool.label, desc: t(desc), cls: 'fp-mail ' + cls,
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]})};
  }

  FP.view('tool:web_apps', function () {
    if (AD) { window.clearTimeout(AD.timer); }
    AD = null;
    var f = frame('web_apps', 'web_apps_desc', 'fp-ap', 'admin');
    if (!f) { return; }
    AD = {page: f.body, st: cleanAdmin(null), timer: 0, watching: false, seen: false, from: '', tries: 0};
    var mine = AD;
    f.body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'webApps').then(function (r) {
      if (AD !== mine) { return; }
      mine.st = cleanAdmin(r);
      f.body.textContent = '';
      f.body.appendChild(statusCard());
      f.body.appendChild(settingsCard());
      f.body.appendChild(offerCard());
      if (mine.st.checking) { mine.watching = true; mine.seen = true; mine.from = mine.st.last; poll(); }
    }, function (err) {
      if (AD !== mine) { return; }
      f.body.textContent = '';
      f.body.appendChild(FP.empty(f.tool.label, err.message));
    });
  });

  FP.view('tool:app_installer', function () {
    CU = null;
    var f = frame('app_installer', 'app_installer_desc', 'fp-ap fp-ap-page', 'user');
    if (!f) { return; }
    CU = {page: f.body, account: FP.account(), apps: {apps: [], sites: []}, installs: [], off: false, suspended: false, done: null, pick: ''};
    var mine = CU;
    f.body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    /* the list of installs works while the installer is off; the page for a new install says it is off (409) */
    var offer = FP.call('get', 'apps', undefined, CU.account).then(function (r) { return {r: r}; }, function (err) { return {err: err}; });
    var list = FP.call('get', 'appInstalls', undefined, CU.account).then(function (r) { return {r: r}; }, function (err) { return {err: err}; });
    Promise.all([offer, list]).then(function (all) {
      if (CU !== mine) { return; }
      if (all[0].err && all[0].err.status !== 409 && all[1].err) {
        f.body.textContent = '';
        f.body.appendChild(FP.empty(f.tool.label, all[0].err.message));
        return;
      }
      if (all[0].err) {
        mine.off = all[0].err.status === 409;
        mine.offError = all[0].err.message;
      } else {
        mine.apps = cleanApps(all[0].r);
      }
      mine.installs = all[1].err ? [] : cleanInstalls(all[1].r);
      render();
      if (all[1].err) { UI.showError(mine.page.querySelector('.fp-ap-list'), all[1].err.message); }
      if (all[0].err && !mine.off) { UI.showError(mine.page.querySelector('.fp-ap-install-card'), all[0].err.message); }
    });
  });
})();

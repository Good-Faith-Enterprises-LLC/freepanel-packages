/* freePanel API tokens (#/tool/api_tokens), the customer panel's page for the tokens a script uses to manage the account without the
   password (docs/api.md, "Customer API tokens"): the list with last use and revoke, a form that makes one with the parts of the account it
   may use, and the secret shown once. Making one needs two-factor on the owner's own login, which the page says before the server has to.
   Names, dates, addresses and the catalogue's words come from the server and are cleaned to the shapes drawn here and shown as text.
   Page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var NAME_RE = /^[A-Za-z0-9][A-Za-z0-9 ._-]{0,63}$/;
  var ID_RE = /^[a-z][a-z0-9_]{0,23}$/;
  var ADDRESS_RE = /^[0-9A-Fa-f:.]{2,45}(\/[0-9]{1,3})?$/;
  var MAX_TOKENS = 50;
  var MAX_ADDRESSES = 10;
  var MAX_PASSWORD = 1024;
  var DAYS = [30, 90, 180, 365];

  var S = null;

  function obj(v) { return v && typeof v === 'object' ? v : {}; }
  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function num(v, min, max, fallback) { return typeof v === 'number' && isFinite(v) && v >= min ? Math.min(Math.floor(v), max) : fallback; }
  function when(iso, withTime) {
    var d = iso ? new Date(iso) : null;
    if (!d || isNaN(d.getTime())) { return ''; }
    return d.toLocaleString(undefined, withTime ? {dateStyle: 'medium', timeStyle: 'short'} : {dateStyle: 'medium'});
  }
  function pill(text, kind) { return el('span', {class: 'sig-pill' + (kind ? ' sig-pill--' + kind : ''), text: text}); }

  /* ---- what the server sends, cleaned ---- */
  function cleanGrant(g) {
    g = obj(g);
    if (!ID_RE.test(str(g.id, 30))) { return null; }
    return {id: g.id, label: str(g.label, 60) || g.id, desc: str(g.description, 300), code: g.runs_code === true};
  }
  function cleanToken(x) {
    x = obj(x);
    if (typeof x.id !== 'number' || !isFinite(x.id) || x.id < 1 || !NAME_RE.test(str(x.name, 70))) { return null; }
    var seen = {};
    var grants = (Array.isArray(x.grants) ? x.grants : []).filter(function (g) {
      if (typeof g !== 'string' || !ID_RE.test(g) || seen[g]) { return false; }
      seen[g] = true;
      return true;
    }).slice(0, 30);
    var addresses = (Array.isArray(x.addresses) ? x.addresses : []).filter(function (a) { return typeof a === 'string' && ADDRESS_RE.test(a); }).slice(0, MAX_ADDRESSES);
    return {id: x.id, name: x.name, scope: x.scope === 'full' ? 'full' : 'read', grants: grants, prefix: str(x.prefix, 12).replace(/[^A-Za-z0-9_-]/g, ''),
      addresses: addresses, created: str(x.created_at, 40), expires: str(x.expires_at, 40), expired: x.expired === true,
      lastAt: typeof x.last_used_at === 'string' ? str(x.last_used_at, 40) : '', lastIp: str(x.last_used_ip, 45).replace(/[^0-9A-Fa-f:.]/g, '')};
  }
  function clean(r) {
    r = obj(r);
    var tokens = (Array.isArray(r.tokens) ? r.tokens : []).map(cleanToken).filter(Boolean).slice(0, MAX_TOKENS);
    return {tokens: tokens, grants: (Array.isArray(r.grants) ? r.grants : []).map(cleanGrant).filter(Boolean).slice(0, 30),
      limit: num(r.limit, 1, 100, 10), rpm: num(r.requests_per_minute, 1, 100000, 300), wpm: num(r.writes_per_minute, 1, 100000, 60),
      can: r.can_create !== false, tf: r.two_factor === true};
  }
  function byId(id) {
    for (var i = 0; i < S.data.tokens.length; i++) { if (S.data.tokens[i].id === id) { return S.data.tokens[i]; } }
    return null;
  }
  function grantLabel(id) {
    for (var i = 0; i < S.data.grants.length; i++) { if (S.data.grants[i].id === id) { return S.data.grants[i].label; } }
    return id;
  }

  /* ---- two-factor first ---- */
  function twoFactorCard() {
    if (S.data.tf) { return null; }
    return M.card('fp-ctok-tf-h', t('ctok_tf_title'), [M.errorLine(),
      el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-ctok-tf': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('ctok_tf_needed')})]),
      el('p', {class: 'fp-muted', text: t('ctok_tf_why')}),
      el('div', {class: 'fp-actions'}, [el('a', {class: 'sig-btn sig-btn--primary', href: '#/two-factor', text: t('ctok_tf_link')})])], 'fp-ctok-tf');
  }

  /* ---- the secret, once ---- */
  function freshCard() {
    var f = S.fresh;
    if (!f) { return null; }
    return M.card('fp-ctok-fresh-h', t('ctok_fresh_title', {name: f.name}), [M.statusLine(),
      el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-ctok-once': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('ctok_once')})]),
      el('div', {class: 'fp-ctok-secret-row'}, [el('code', {class: 'sig-mono fp-ctok-secret', id: 'fp-ctok-secret', tabindex: '0', 'data-fp-ctok-secret': '', 'aria-label': t('ctok_secret_label'), text: f.token}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'copy', text: t('ctok_copy')})]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'done', text: t('ctok_done')})])], 'fp-ctok-fresh');
  }
  function copy(b) {
    var f = S.fresh;
    var scope = S.page.querySelector('.fp-ctok-fresh');
    var node = S.page.querySelector('#fp-ctok-secret');
    function selected() {
      var range = document.createRange();
      range.selectNodeContents(node);
      var sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
      M.say(scope, t('ctok_selected'));
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(f.token).then(function () { M.say(scope, t('ctok_copied')); }, selected);
    } else {
      selected();
    }
    b.focus();
  }

  /* ---- the list ---- */
  function actsFor(x) {
    return [el('button', {class: 'sig-btn sig-btn--danger sig-btn--sm', type: 'button', 'data-fp-act': 'revoke', 'aria-label': t('ctok_revoke_of', {name: x.name}), text: t('ctok_revoke')})];
  }
  function grantsCell(x) {
    if (!x.grants.length) { return el('span', {class: 'fp-muted', 'data-fp-ctok-grants': '', text: t('ctok_no_grants')}); }
    return el('ul', {class: 'fp-ctok-grants', 'data-fp-ctok-grants': ''}, x.grants.map(function (g) { return el('li', null, [pill(grantLabel(g), '')]); }));
  }
  function usedLine(x) {
    var at = when(x.lastAt, true);
    if (!at) { return t('ctok_never_used'); }
    return x.lastIp ? t('ctok_last_used_from', {when: at, ip: x.lastIp}) : t('ctok_last_used', {when: at});
  }
  function rowFor(x) {
    var ends = when(x.expires);
    return el('li', {class: 'fp-ctok-row', 'data-fp-token': String(x.id)}, [
      el('div', {class: 'fp-ctok-who'}, [el('span', {class: 'sig-mono fp-ctok-name', text: x.name}),
        el('span', {class: 'fp-ctok-state'}, [pill(t(x.scope === 'full' ? 'ctok_scope_full' : 'ctok_scope_read'), x.scope === 'full' ? 'warn' : ''),
          x.expired ? pill(t('ctok_expired'), 'warn') : null]),
        x.prefix ? el('span', {class: 'fp-muted fp-row-note', text: t('ctok_prefix', {prefix: x.prefix})}) : null,
        ends ? el('span', {class: 'fp-muted fp-row-note', 'data-fp-ctok-expires': '', text: t(x.expired ? 'ctok_ended' : 'ctok_ends', {when: ends})}) : null,
        el('span', {class: 'fp-muted fp-row-note', 'data-fp-ctok-used': '', text: usedLine(x)}),
        x.addresses.length ? el('span', {class: 'fp-muted fp-row-note', 'data-fp-ctok-from': '', text: t('ctok_from', {addresses: x.addresses.join(', ')})}) : null]),
      el('div', {class: 'fp-ctok-access'}, [el('span', {class: 'fp-ctok-h', text: t('ctok_col_access')}), grantsCell(x)]),
      el('div', {class: 'fp-actions fp-ctok-acts'}, actsFor(x))]);
  }
  function listCard() {
    var D = S.data;
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', 'data-fp-ctok-count': '', text: t('ctok_count', {n: String(D.tokens.length), limit: String(D.limit)})})];
    if (!D.tokens.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('ctok_none')}));
    } else {
      parts.push(el('ul', {class: 'fp-ctok-list', 'aria-labelledby': 'fp-ctok-list-h'}, D.tokens.map(rowFor)));
      parts.push(el('div', {class: 'fp-actions fp-ctok-all'}, [el('button', {class: 'sig-btn sig-btn--danger sig-btn--sm', type: 'button', 'data-fp-act': 'revoke-all', text: t('ctok_revoke_all')})]));
    }
    parts.push(el('p', {class: 'fp-muted', 'data-fp-ctok-revoke-note': '', text: t('ctok_revoke_note')}));
    return M.card('fp-ctok-list-h', t('ctok_list_title'), parts, 'fp-ctok-list-card');
  }

  /* ---- making one ---- */
  function grantsField() {
    var boxes = S.data.grants.map(function (g) {
      var id = 'fp-ctok-g-' + g.id;
      var box = el('input', {type: 'checkbox', id: id, name: 'grant', value: g.id, 'aria-describedby': id + '-d'});
      return el('div', {class: 'fp-ctok-grant', 'data-fp-grant': g.id}, [el('label', {class: 'fp-check', for: id}, [box, el('span', {text: g.label})]),
        el('span', {class: 'sig-hint fp-ctok-grant-d', id: id + '-d'}, [el('span', {text: g.desc}), g.code ? pill(t('ctok_runs_code'), 'warn') : null])]);
    });
    return el('fieldset', {class: 'fp-ctok-set', 'data-fp-ctok-grants-field': ''}, [el('legend', {class: 'sig-label', text: t('ctok_grants')}), el('p', {class: 'sig-hint', text: t('ctok_grants_hint')})].concat(boxes));
  }
  function scopeField() {
    function radio(value, labelKey, hintKey, on) {
      var id = 'fp-ctok-scope-' + value;
      var input = el('input', {type: 'radio', id: id, name: 'scope', value: value, 'aria-describedby': id + '-d'});
      if (on) { input.checked = true; }
      return el('div', {class: 'fp-ctok-grant'}, [el('label', {class: 'fp-check', for: id}, [input, el('span', {text: t(labelKey)})]), el('span', {class: 'sig-hint fp-ctok-grant-d', id: id + '-d', text: t(hintKey)})]);
    }
    return el('fieldset', {class: 'fp-ctok-set'}, [el('legend', {class: 'sig-label', text: t('ctok_scope')}),
      radio('read', 'ctok_scope_read', 'ctok_scope_read_hint', true), radio('full', 'ctok_scope_full', 'ctok_scope_full_hint', false)]);
  }
  function daysField() {
    var select = el('select', {class: 'sig-select', id: 'fp-ctok-days', name: 'days'}, DAYS.map(function (d) { return el('option', {value: String(d), text: t('ctok_days', {n: String(d)})}); }));
    select.value = '90';
    return M.field('fp-ctok-days', t('ctok_expires'), select, t('ctok_expires_hint'));
  }
  function addressesField() {
    var area = el('textarea', {class: 'sig-input fp-ctok-addresses', id: 'fp-ctok-addresses', name: 'addresses', rows: '3', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none'});
    return M.field('fp-ctok-addresses', t('ctok_addresses'), area, t('ctok_addresses_hint', {n: String(MAX_ADDRESSES)}));
  }
  function readAddresses(form) {
    var f = form.querySelector('[name="addresses"]');
    var list = f.value.split(/[\s,]+/).filter(Boolean);
    if (list.length > MAX_ADDRESSES) { M.fieldError(form, f, t('ctok_addresses_many', {n: String(MAX_ADDRESSES)})); return null; }
    for (var i = 0; i < list.length; i++) {
      if (!ADDRESS_RE.test(list[i])) { M.fieldError(form, f, t('ctok_address_bad', {address: list[i].slice(0, 40)})); return null; }
    }
    return list;
  }
  function readGrants(form) {
    var out = [];
    var boxes = form.querySelectorAll('input[name="grant"]');
    for (var i = 0; i < boxes.length; i++) { if (boxes[i].checked) { out.push(boxes[i].value); } }
    return out;
  }
  function addCard() {
    var D = S.data;
    if (!D.tf) { return null; }
    if (!D.can) { return M.card('fp-ctok-add-h', t('ctok_add_title'), [el('p', {class: 'fp-muted', 'data-fp-ctok-cannot': '', text: t('ctok_cannot_make')})], 'fp-ctok-add'); }
    if (D.tokens.length >= D.limit) {
      return M.card('fp-ctok-add-h', t('ctok_add_title'), [el('p', {class: 'fp-muted', 'data-fp-ctok-full': '', text: t('ctok_full', {limit: String(D.limit)})})], 'fp-ctok-add');
    }
    if (!D.grants.length) {
      return M.card('fp-ctok-add-h', t('ctok_add_title'), [el('p', {class: 'fp-muted', text: t('ctok_no_catalog')})], 'fp-ctok-add');
    }
    var name = el('input', {class: 'sig-input', id: 'fp-ctok-name', name: 'name', type: 'text', autocomplete: 'off', maxlength: '64', spellcheck: 'false', autocapitalize: 'none'});
    var current = el('input', {class: 'sig-input', id: 'fp-ctok-cur', name: 'current_password', type: 'password', autocomplete: 'current-password', maxlength: String(MAX_PASSWORD)});
    var form = el('form', {class: 'fp-form fp-mail-form fp-ctok-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-ctok-name', t('ctok_name'), name, t('ctok_name_hint')), scopeField(), grantsField(), daysField(), addressesField(),
      M.field('fp-ctok-cur', t('ctok_current'), current, t('ctok_current_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('ctok_make')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var n = name.value.trim();
      if (!NAME_RE.test(n)) { M.fieldError(form, name, t('ctok_name_bad')); return; }
      if (S.data.tokens.some(function (x) { return x.name === n; })) { M.fieldError(form, name, t('ctok_name_taken', {name: n})); return; }
      var grants = readGrants(form);
      if (!grants.length) { M.fieldError(form, form.querySelector('input[name="grant"]'), t('ctok_grants_need')); return; }
      var addresses = readAddresses(form);
      if (addresses === null) { return; }
      if (!current.value) { M.fieldError(form, current, t('ctok_current_need')); return; }
      var body = {name: n, scope: form.querySelector('input[name="scope"]:checked').value, grants: grants,
        expires_days: Number(form.querySelector('[name="days"]').value), addresses: addresses, current_password: current.value};
      UI.setBusy(b, true);
      var mine = S;
      FP.call('post', 'acctTokens', body, S.account).then(function (r) {
        if (S !== mine) { return; }
        r = obj(r);
        var made = cleanToken(r);
        var secret = typeof r.token === 'string' && /^fpt_[A-Za-z0-9_-]{43}$/.test(r.token) ? r.token : '';
        if (made) { S.data.tokens.unshift(made); }
        S.fresh = secret ? {name: n, token: secret} : null;
        render();
        M.say(S.page.querySelector('.fp-ctok-list-card'), t('ctok_made', {name: n}));
        (S.page.querySelector('#fp-ctok-secret') || S.page.querySelector('#fp-ctok-list-h')).focus();
      }, function (err) {
        if (S !== mine) { return; }
        UI.setBusy(b, false);
        if (err.code === 'two_factor_required') { S.data.tf = false; render(); UI.showError(S.page.querySelector('.fp-ctok-tf'), err.message); S.page.querySelector('#fp-ctok-tf-h').focus(); return; }
        if (err.code === 'forbidden') { current.value = ''; M.fieldError(form, current, t('ctok_current_wrong')); return; }
        if (err.code === 'conflict') { M.fieldError(form, name, err.message); return; }
        M.failed(form, err);
        if (!form.contains(document.activeElement)) { b.focus(); }
      });
    });
    return M.card('fp-ctok-add-h', t('ctok_add_title'), [el('p', {class: 'fp-muted', text: t('ctok_add_desc')}), form], 'fp-ctok-add');
  }

  /* ---- using one ---- */
  function useCard() {
    var example = 'curl -H "Authorization: Bearer YOUR_TOKEN" ' + window.location.origin + '/api/v1/accounts/' + S.account;
    return M.card('fp-ctok-use-h', t('ctok_use_title'), [el('p', {class: 'fp-muted', text: t('ctok_use_how')}),
      el('pre', {class: 'sig-mono fp-ctok-example', tabindex: '0', 'aria-label': t('ctok_use_example'), 'data-fp-ctok-example': '', text: example}),
      el('p', {class: 'fp-muted', 'data-fp-ctok-limits': '', text: t('ctok_limits', {rpm: String(S.data.rpm), wpm: String(S.data.wpm)})}),
      el('p', {class: 'fp-muted', text: t('ctok_never')})], 'fp-ctok-use');
  }

  /* ---- the page ---- */
  function render() {
    S.page.textContent = '';
    [twoFactorCard(), freshCard(), listCard(), addCard(), useCard()].forEach(function (c) { if (c) { S.page.appendChild(c); } });
  }
  function rowError(b, err) {
    UI.setBusy(b, false);
    UI.showError(S.page.querySelector('.fp-ctok-list-card'), err.message);
    b.focus();
  }

  function onClick(e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !S || !S.page || !S.page.contains(b) || b.disabled || !S.data) { return; }
    var a = b.getAttribute('data-fp-act');
    var row = b.closest('[data-fp-token]');
    var id = row ? Number(row.getAttribute('data-fp-token')) : 0;
    var x = id ? byId(id) : null;
    var list = S.page.querySelector('.fp-ctok-list-card');
    var mine = S;
    if (a === 'copy' && S.fresh) {
      copy(b);
    } else if (a === 'done') {
      S.fresh = null;
      render();
      (S.page.querySelector('#fp-ctok-list-h')).focus();
    } else if (a === 'revoke' && x) {
      UI.showError(list, '');
      M.say(list, '');
      M.confirmIn(b.parentNode, t('ctok_revoke_ask', {name: x.name}), 'revoke-yes', t('ctok_revoke'));
    } else if (a === 'revoke-all') {
      UI.showError(list, '');
      M.say(list, '');
      M.confirmIn(b.parentNode, t('ctok_revoke_all_ask'), 'revoke-all-yes', t('ctok_revoke_all'));
    } else if (a === 'confirm-no') {
      var cell = b.parentNode;
      cell.textContent = '';
      if (x) {
        actsFor(x).forEach(function (n) { cell.appendChild(n); });
        cell.querySelector('[data-fp-act="revoke"]').focus();
      } else {
        var all = el('button', {class: 'sig-btn sig-btn--danger sig-btn--sm', type: 'button', 'data-fp-act': 'revoke-all', text: t('ctok_revoke_all')});
        cell.appendChild(all);
        all.focus();
      }
    } else if (a === 'revoke-yes' && x) {
      UI.setBusy(b, true);
      FP.call('del', 'acctToken', undefined, {name: S.account, id: String(x.id)}).then(function () {
        if (S !== mine) { return; }
        S.data.tokens = S.data.tokens.filter(function (n) { return n.id !== x.id; });
        render();
        M.say(S.page.querySelector('.fp-ctok-list-card'), t('ctok_revoked', {name: x.name}));
        S.page.querySelector('#fp-ctok-list-h').focus();
      }, function (err) { if (S === mine) { rowError(b, err); } });
    } else if (a === 'revoke-all-yes') {
      UI.setBusy(b, true);
      FP.call('del', 'acctTokens', undefined, S.account).then(function () {
        if (S !== mine) { return; }
        S.data.tokens = [];
        render();
        M.say(S.page.querySelector('.fp-ctok-list-card'), t('ctok_revoked_all'));
        S.page.querySelector('#fp-ctok-list-h').focus();
      }, function (err) { if (S === mine) { rowError(b, err); } });
    }
  }
  document.addEventListener('click', onClick);
  /* the secret is kept for the page only: leaving it forgets it (it is shown once, and the server keeps no copy) */
  window.addEventListener('hashchange', function () {
    if (S && S.fresh && window.location.hash.indexOf('#/tool/api_tokens') !== 0) { S.fresh = null; }
  });

  FP.view('tool:api_tokens', function () {
    S = null;
    var tool = FP.tools.api_tokens;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('ctok_desc'), cls: 'fp-mail fp-ctok',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    S = {page: page, account: FP.account(), data: null, fresh: null};
    var mine = S;
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'acctTokens', undefined, S.account).then(function (r) {
      if (S !== mine) { return; }
      S.data = clean(r);
      render();
    }, function (err) {
      if (S !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

/* freePanel SSL certificates (docs/api.md, "Domains and sites"): the customer panel's SSL certificates page
   (#/tool/ssl). Each website's certificate, installing one (PUT .../certificate), taking an installed one away
   (DELETE .../certificate) and sending every visitor to HTTPS (PUT .../https). Other names of a website share its
   certificate, so only websites are listed. Free certificates come from the server and renew themselves; this page
   shows them but doesn't remove them. The private key goes to the server and is never shown again: the field is
   emptied once it's sent; a certificate can instead be installed with one of the keys made on the Private keys and requests
   page (key_id). Every change answers with the whole list again. Page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var DOMAIN_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var NAME_RE = /^(\*\.)?([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var MAX_CHAIN = 64 * 1024;
  var MAX_KEY = 16 * 1024;
  var MAX_CERTS = 10;
  var CERT_BEGIN = '-----BEGIN CERTIFICATE-----';
  var KEY_RE = /-----BEGIN (RSA |EC )?PRIVATE KEY-----/;

  function str(v) { return typeof v === 'string' ? v : ''; }
  function kindOf(k) { return k === 'main' || k === 'addon' ? k : (k === 'sub' || k === 'subdomain' ? 'sub' : ''); }
  var ORDER = {main: 0, addon: 1, sub: 2};
  function cleanCert(c) {
    if (!c || typeof c !== 'object' || (c.source !== 'free' && c.source !== 'installed')) { return null; }
    var end = new Date(str(c.not_after));
    return {source: c.source, names: (Array.isArray(c.names) ? c.names : []).filter(function (n) { return NAME_RE.test(str(n)); }).slice(0, 100),
      end: isNaN(end.getTime()) ? null : end, expired: c.expired === true};
  }
  function clean(v) {
    v = v && typeof v === 'object' ? v : {};
    var sites = (Array.isArray(v.sites) ? v.sites : []).filter(function (s) {
      return s && DOMAIN_RE.test(str(s.domain)) && kindOf(s.kind);
    }).map(function (s) {
      return {domain: s.domain, kind: kindOf(s.kind), https: s.force_https === true, cert: cleanCert(s.certificate),
        aliases: (Array.isArray(s.aliases) ? s.aliases : []).filter(function (a) { return DOMAIN_RE.test(str(a)); }).sort(),
        noWildcard: s.autossl && typeof s.autossl === 'object' ? str(s.autossl.wildcard_note).slice(0, 300) : ''};
    }).sort(function (a, b) { return ORDER[a.kind] - ORDER[b.kind] || (a.domain < b.domain ? -1 : 1); });
    return {suspended: v.suspended === true, sites: sites};
  }
  function day(d) { return d ? d.toLocaleDateString('en', {dateStyle: 'medium'}) : ''; }
  function valid(s) { return Boolean(s.cert && !s.cert.expired); }

  var P = {page: null, state: null, account: '', site: '', keys: []};
  function siteOf(domain) { return P.state.sites.filter(function (s) { return s.domain === domain; })[0]; }

  /* why the free certificate has no wildcard although they are on; an installed certificate has nothing to say about it */
  function wildNote(s) {
    return s.noWildcard && !(s.cert && s.cert.source === 'installed') ?
      el('span', {class: 'fp-muted fp-row-note fp-ssl-nowild', 'data-fp-nowild': '', text: t('ssl_no_wildcard', {why: s.noWildcard})}) : null;
  }
  function certCell(s) {
    var c = s.cert;
    if (!c) {
      return el('td', {class: 'fp-ssl-cert'}, [el('span', {class: 'sig-pill', text: t('ssl_none')}),
        el('span', {class: 'fp-muted fp-row-note', text: t('ssl_none_note')}), wildNote(s)]);
    }
    var pill = c.expired ? el('span', {class: 'sig-pill sig-pill--danger', text: t('ssl_expired')}) :
      el('span', {class: 'sig-pill' + (c.source === 'free' ? ' sig-pill--accent' : ''), text: t(c.source === 'free' ? 'ssl_free' : 'ssl_installed')});
    var end = c.end ? t(c.expired ? 'ssl_expired_on' : (c.source === 'free' ? 'ssl_renews' : 'ssl_valid_until'), {date: day(c.end)}) : '';
    return el('td', {class: 'fp-ssl-cert'}, [pill, end ? el('span', {class: 'fp-row-note', text: end}) : null,
      c.names.length ? el('span', {class: 'fp-muted fp-row-note fp-ssl-names', text: t('ssl_covers', {names: c.names.join(', ')})}) : null, wildNote(s)]);
  }
  function httpsCell(s, row) {
    var id = 'fp-ssl-https-' + row;
    var box = el('input', {type: 'checkbox', id: id, 'data-fp-https': '', checked: s.https ? true : null,
      disabled: valid(s) || s.https ? null : true, 'aria-describedby': valid(s) ? null : id + '-why'});
    return el('td', {class: 'fp-ssl-https'}, [el('label', {class: 'fp-check', for: id}, [box, el('span', {class: 'sig-vh', text: t('ssl_https_of', {domain: s.domain})}),
      el('span', {'aria-hidden': 'true', text: t('ssl_https_short')})]),
      valid(s) ? null : el('span', {class: 'fp-muted fp-row-note', id: id + '-why', text: t('ssl_https_needs')})]);
  }
  function actsCell(s) {
    var b = [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'ssl-install',
      'aria-label': t(s.cert && s.cert.source === 'installed' ? 'ssl_replace_of' : 'ssl_install_of', {domain: s.domain}),
      text: t(s.cert && s.cert.source === 'installed' ? 'ssl_replace' : 'ssl_install')})];
    if (s.cert && s.cert.source === 'installed') {
      b.push(el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'ssl-remove',
        'aria-label': t('ssl_remove_of', {domain: s.domain}), text: t('ssl_remove')}));
    }
    return el('td', {class: 'fp-mail-acts'}, b);
  }
  function listCard() {
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t('ssl_note')})];
    if (!P.state.sites.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('php_no_sites')}));
    } else {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-ssl-h'}, [
        el('table', {class: 'sig-table fp-mail-table fp-ssl-table'}, [el('thead', null, [el('tr', null, [
          el('th', {scope: 'col', text: t('php_site')}), el('th', {scope: 'col', text: t('ssl_cert_col')}),
          el('th', {scope: 'col', text: t('ssl_https_col')}),
          el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]),
        el('tbody', null, P.state.sites.map(function (s, i) {
          return el('tr', {'data-fp-site': s.domain}, [el('th', {scope: 'row', class: 'fp-mail-name'}, [el('span', {text: s.domain}),
            s.aliases.length ? el('span', {class: 'fp-muted fp-row-note', text: t('php_also', {names: s.aliases.join(', ')})}) : null]),
          certCell(s), httpsCell(s, i), actsCell(s)]);
        }))])]));
    }
    return M.card('fp-ssl-h', t('ssl_title'), parts, 'fp-ssl-list');
  }

  /* a "Load from a file" button that puts a file's text into the field next to it */
  function fileButton(area, max, labelKey) {
    var pick = el('input', {type: 'file', class: 'sig-vh', tabindex: '-1', 'aria-hidden': 'true', accept: '.pem,.crt,.cer,.key,.txt,text/plain'});
    var b = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', text: t('ssl_from_file'),
      'aria-label': t(labelKey)});
    b.addEventListener('click', function () { pick.click(); });
    pick.addEventListener('change', function () {
      var f = pick.files && pick.files[0];
      pick.value = '';
      if (!f) { return; }
      var form = area.form;
      M.start(form);
      if (f.size > max) { M.fieldError(form, area, t('ssl_file_too_big', {name: f.name, kb: max >> 10})); return; }
      f.text().then(function (text) {
        area.value = text;
        area.focus();
      }, function () { M.fieldError(form, area, t('ssl_file_unread', {name: f.name})); });
    });
    return el('div', {class: 'fp-ssl-file'}, [b, pick]);
  }
  function installCard() {
    var site = siteOf(P.site);
    var pick = el('select', {class: 'sig-select', id: 'fp-ssl-site', name: 'site'}, P.state.sites.map(function (s) {
      var o = el('option', {value: s.domain, text: s.domain});
      if (s.domain === site.domain) { o.selected = true; }
      return o;
    }));
    var cert = el('textarea', {class: 'sig-input sig-mono fp-ssl-pem', id: 'fp-ssl-cert', name: 'certificate', rows: '6', spellcheck: 'false',
      autocomplete: 'off', autocapitalize: 'none', placeholder: CERT_BEGIN});
    var key = el('textarea', {class: 'sig-input sig-mono fp-ssl-pem', id: 'fp-ssl-key', name: 'key', rows: '6', spellcheck: 'false',
      autocomplete: 'off', autocapitalize: 'none', placeholder: '-----BEGIN PRIVATE KEY-----'});
    /* the account's own keys, when it has any: a certificate made from a request is installed with its key by id */
    var keyPick = P.keys.length ? el('select', {class: 'sig-select', id: 'fp-ssl-keypick', name: 'key_id'}, [el('option', {value: '', text: t('ssl_key_paste')})].concat(
      P.keys.map(function (k) { return el('option', {value: k.id, text: FP.ky.keyName(k) + ' (' + FP.ky.typeLabel(k.type) + ')'}); }))) : null;
    var replaces = el('p', {class: 'fp-muted', 'data-fp-replaces': ''});
    function sync() {
      var s = siteOf(pick.value);
      P.site = pick.value;
      replaces.textContent = s && s.cert ? t(s.cert.source === 'free' ? 'ssl_replaces_free' : 'ssl_replaces', {domain: s.domain}) : '';
      replaces.hidden = !replaces.textContent;
    }
    pick.addEventListener('change', sync);
    var form = el('form', {class: 'fp-form fp-mail-form fp-ssl-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-ssl-site', t('ssl_for_site'), pick), replaces,
      M.field('fp-ssl-cert', t('ssl_cert_field'), cert, t('ssl_cert_hint')), fileButton(cert, MAX_CHAIN, 'ssl_cert_file'),
      keyPick ? M.field('fp-ssl-keypick', t('ssl_key_source'), keyPick, t('ssl_key_source_hint')) : null,
      el('div', {class: 'fp-ssl-keyarea'}, [M.field('fp-ssl-key', t('ssl_key_field'), key, t('ssl_key_hint')), fileButton(key, MAX_KEY, 'ssl_key_file')]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('ssl_install')})])]);
    function pasting() { return !keyPick || !keyPick.value; }
    if (keyPick) {
      keyPick.addEventListener('change', function () { form.querySelector('.fp-ssl-keyarea').hidden = !pasting(); });
    }
    sync();
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var domain = pick.value;
      var c = cert.value.trim();
      var k = key.value.trim();
      var n = c.split(CERT_BEGIN).length - 1;
      if (!n) { M.fieldError(form, cert, t('ssl_cert_bad')); return; }
      if (c.length > MAX_CHAIN) { M.fieldError(form, cert, t('ssl_cert_big', {kb: MAX_CHAIN >> 10})); return; }
      if (n > MAX_CERTS) { M.fieldError(form, cert, t('ssl_cert_many', {n: MAX_CERTS})); return; }
      if (pasting()) {
        if (/-----BEGIN ENCRYPTED PRIVATE KEY-----|Proc-Type: 4,ENCRYPTED/.test(k)) { M.fieldError(form, key, t('ssl_key_encrypted')); return; }
        if (!KEY_RE.test(k)) { M.fieldError(form, key, t('ssl_key_bad')); return; }
        if (k.length > MAX_KEY) { M.fieldError(form, key, t('ssl_key_big', {kb: MAX_KEY >> 10})); return; }
      }
      UI.setBusy(b, true);
      FP.call('put', 'siteCertificate', pasting() ? {certificate: c + '\n', key: k + '\n'} : {certificate: c + '\n', key_id: keyPick.value}, {name: P.account, domain: domain}).then(function (r) {
        key.value = '';
        P.state = clean(r);
        render();
        M.say(P.page.querySelector('.fp-ssl-list'), t('ssl_installed_for', {domain: domain}));
        P.page.querySelector('#fp-ssl-h').focus();
      }, function (err) {
        UI.setBusy(b, false);
        /* the server's words say which half it refused */
        M.fieldError(form, /private key|RSA key|ECDSA key/.test(err.message) || (!pasting() && /\bkey\b/.test(err.message)) ? (pasting() ? key : keyPick) : (err.code === 'bad_request' ? cert : null), err.message);
      });
    });
    return M.card('fp-ssl-add-h', t('ssl_add_title'), [el('p', {class: 'fp-muted', text: t('ssl_add_desc')}), form], 'fp-ssl-add');
  }

  function render() {
    P.page.textContent = '';
    if (P.state.suspended) { P.page.appendChild(M.suspendedBanner(t('dom_suspended'))); }
    if (!P.state.sites.length) {
      P.page.appendChild(FP.empty(t('rd_no_sites_title'), t('php_no_sites')));
      return;
    }
    if (!siteOf(P.site)) { P.site = P.state.sites[0].domain; }
    P.page.appendChild(listCard());
    P.page.appendChild(installCard());
  }
  /* the list drawn again on its own, so what is typed in the install form stays */
  function refreshList() {
    var old = P.page.querySelector('.fp-ssl-list');
    if (!old || !P.state.sites.length) { render(); return; }
    old.replaceWith(listCard());
    var pick = P.page.querySelector('#fp-ssl-site');
    if (pick) { pick.dispatchEvent(new Event('change')); }
  }
  function focusRow(domain, sel) {
    var n = P.page.querySelector('tr[data-fp-site="' + window.CSS.escape(domain) + '"] ' + sel);
    if (n) { n.focus(); }
  }

  function onClick(e) {
    if (!P.page) { return; }
    var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !P.page.contains(b) || b.disabled) { return; }
    var a = b.getAttribute('data-fp-act');
    var tr = b.closest('tr');
    var domain = tr ? tr.getAttribute('data-fp-site') : '';
    var list = P.page.querySelector('.fp-ssl-list');
    if (a === 'ssl-install') {
      P.site = domain;
      var pick = P.page.querySelector('#fp-ssl-site');
      pick.value = domain;
      pick.dispatchEvent(new Event('change'));
      P.page.querySelector('#fp-ssl-cert').focus();
    } else if (a === 'ssl-remove') {
      var s = siteOf(domain);
      M.confirmIn(tr.querySelector('.fp-mail-acts'), t(s && s.https ? 'ssl_remove_ask_https' : 'ssl_remove_ask', {domain: domain}), 'ssl-remove-yes', t('ssl_remove'));
    } else if (a === 'confirm-no') {
      refreshList();
      focusRow(domain, '[data-fp-act="ssl-remove"]');
    } else if (a === 'ssl-remove-yes') {
      UI.showError(list, '');
      UI.setBusy(b, true);
      FP.call('del', 'siteCertificate', undefined, {name: P.account, domain: domain}).then(function (r) {
        P.state = clean(r);
        refreshList();
        M.say(P.page.querySelector('.fp-ssl-list'), t('ssl_removed', {domain: domain}));
        P.page.querySelector('#fp-ssl-h').focus();
      }, function (err) {
        refreshList();
        UI.showError(P.page.querySelector('.fp-ssl-list'), err.message);
        focusRow(domain, '[data-fp-act="ssl-remove"]');
      });
    }
  }
  function onChange(e) {
    if (!P.page || !e.target.matches || !e.target.matches('[data-fp-https]') || !P.page.contains(e.target)) { return; }
    var box = e.target;
    var domain = box.closest('tr').getAttribute('data-fp-site');
    var want = box.checked;
    var list = P.page.querySelector('.fp-ssl-list');
    UI.showError(list, '');
    M.say(list, '');
    box.disabled = true;
    FP.call('put', 'siteHTTPS', {force_https: want}, {name: P.account, domain: domain}).then(function (r) {
      P.state = clean(r);
      refreshList();
      M.say(P.page.querySelector('.fp-ssl-list'), t(want ? 'ssl_https_on' : 'ssl_https_off', {domain: domain}));
      focusRow(domain, '[data-fp-https]');
    }, function (err) {
      box.checked = !want;
      box.disabled = false;
      UI.showError(list, err.message);
      box.focus();
    });
  }
  document.addEventListener('click', onClick);
  document.addEventListener('change', onChange);

  FP.view('tool:ssl', function () {
    P.page = null;
    var tool = FP.tools.ssl;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('ssl_desc'), cls: 'fp-mail fp-site fp-ssl-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    P.page = body;
    P.account = FP.account();
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    /* the account's own keys are an extra: a server without them leaves the paste field as the only way */
    var keys = FP.call('get', 'sslKeys', undefined, P.account).then(function (r) { return FP.ky ? FP.ky.cleanKeys(r) : []; }, function () { return []; });
    Promise.all([FP.call('get', 'domains', undefined, P.account), keys]).then(function (all) {
      if (P.page !== body) { return; }
      P.state = clean(all[0]);
      P.keys = all[1];
      render();
    }, function (err) {
      if (P.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

/* freePanel server updates (#/tool/server_updates), the admin panel's page for the server's own packages (docs/api.md,
   "Server updates"): what dnf would upgrade, security updates first; a check for new ones; installing the security
   updates, all of them or only freePanel's own packages; the end of the output of the update that ran or runs, with a
   stop; and automatic security updates. An update runs on the server in a unit of its own, so it goes on if this page
   is closed, and while one runs the page asks how it is every few seconds. Everything dnf and the repositories say
   (names, versions, advisories, output) is shown as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var POLL_MS = 3000;
  /* the most of each list and line the page keeps (docs/api.md) */
  var MAX_ROWS = 500;
  var MAX_LOG = 200;
  var MAX_LINE = 1000;
  var SEVERITIES = ['Critical', 'Important', 'Moderate', 'Low'];
  var STATES = ['idle', 'running', 'succeeded', 'failed', 'stopped'];
  var ACTIONS = ['refresh', 'apply'];
  var SCOPES = ['security', 'all', 'freepanel'];
  var CARDS = ['fp-upd-status', 'fp-upd-list', 'fp-upd-install', 'fp-upd-job', 'fp-upd-auto'];

  var S = null;

  function str(v) { return typeof v === 'string' ? v : ''; }
  function obj(v) { return v && typeof v === 'object' ? v : {}; }
  function count(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.floor(v) : 0; }
  function when(iso) {
    var d = typeof iso === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(iso) ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }

  /* ---------- what the server says, kept to the shapes the page draws ---------- */
  function cleanUpdate(u) {
    u = obj(u);
    if (!str(u.name)) { return null; }
    var sec = u.security === true;
    return {name: str(u.name).slice(0, 200), arch: str(u.arch).slice(0, 40), version: str(u.version).slice(0, 200), repo: str(u.repo).slice(0, 100),
      security: sec, severity: sec && SEVERITIES.indexOf(u.severity) >= 0 ? u.severity : '',
      advisories: (Array.isArray(u.advisories) ? u.advisories : []).filter(function (a) { return typeof a === 'string' && a; }).slice(0, 5)
        .map(function (a) { return a.slice(0, 60); }), freepanel: u.freepanel === true};
  }
  function cleanJob(j) {
    j = obj(j);
    return {state: STATES.indexOf(j.state) >= 0 ? j.state : 'idle', action: ACTIONS.indexOf(j.action) >= 0 ? j.action : '',
      scope: SCOPES.indexOf(j.scope) >= 0 ? j.scope : '', started: str(j.started), ended: str(j.ended),
      exit: typeof j.exit_code === 'number' && isFinite(j.exit_code) ? Math.floor(j.exit_code) : null, timedOut: j.timed_out === true,
      log: (Array.isArray(j.log) ? j.log : []).filter(function (l) { return typeof l === 'string'; }).slice(-MAX_LOG)
        .map(function (l) { return l.slice(0, MAX_LINE); }), truncated: j.log_truncated === true};
  }
  function cleanAuto(a) {
    a = obj(a);
    return {enabled: a.enabled === true, running: a.running === true, next: str(a.next), last: str(a.last), lastOk: a.last_ok === true};
  }
  function clean(r) {
    r = obj(r);
    return {supported: r.supported === true, reason: str(r.reason).slice(0, 400), checked: str(r.checked), fpRepo: r.freepanel_repo === true,
      updates: (Array.isArray(r.updates) ? r.updates : []).slice(0, MAX_ROWS).map(cleanUpdate).filter(Boolean),
      total: count(r.total), security: count(r.security), freepanel: count(r.freepanel), truncated: r.truncated === true,
      busy: r.busy === true, listError: str(r.list_error).slice(0, 600), reboot: r.reboot_needed === true ? true : (r.reboot_needed === false ? false : null),
      job: cleanJob(r.job), auto: cleanAuto(r.auto)};
  }
  /* an update runs: the list is not read meanwhile, so what was on the page stays until it ends */
  function adopt(fresh) {
    var old = S.data;
    if (fresh.busy && old && old.supported) {
      ['updates', 'total', 'security', 'freepanel', 'truncated', 'listError', 'checked', 'reboot'].forEach(function (k) { fresh[k] = old[k]; });
      fresh.listHeld = true;
    }
    S.data = fresh;
  }
  function active(d) { return d.job.state === 'running' || d.busy || d.auto.running; }

  /* ---------- the cards ---------- */
  function whatText(j) {
    if (j.action === 'refresh') { return t('upd_what_refresh'); }
    return j.action === 'apply' && j.scope ? t('upd_what_' + j.scope) : t('upd_what_other');
  }
  function statusCard() {
    var d = S.data;
    var parts = [M.errorLine(), M.statusLine()];
    if (!d.supported) {
      parts.push(el('p', {'data-fp-unsupported': '', text: d.reason || t('upd_unsupported')}));
      return M.card('fp-upd-status-h', t('upd_title'), parts, 'fp-upd-status');
    }
    if (d.reboot === true) { parts.push(M.suspendedBanner(t('upd_reboot'))); }
    if (d.busy) { parts.push(el('p', {class: 'fp-muted', 'data-fp-held': '', text: t('upd_busy')})); }
    if (!d.busy || d.listHeld) {
      var n = d.total;
      var line = !d.checked ? t('upd_never') : (n === 0 ? t('upd_none') : (n === 1 ? t('upd_n_one') : t('upd_n_many', {n: n.toLocaleString('en')})));
      if (d.checked) {
        if (n > 0 && d.security === 1) { line += ' ' + t(n === 1 ? 'upd_sec_it' : 'upd_sec_one'); }
        if (d.security > 1) { line += ' ' + t('upd_sec_many', {n: d.security.toLocaleString('en')}); }
      }
      parts.push(el('p', {'data-fp-summary': '', text: line}));
      if (d.freepanel > 0) { parts.push(el('p', {class: 'fp-muted', 'data-fp-fp': '', text: t('upd_fp_n', {n: d.freepanel.toLocaleString('en')})})); }
      if (d.truncated) { parts.push(el('p', {class: 'fp-muted', 'data-fp-truncated': '', text: t('upd_truncated', {shown: d.updates.length.toLocaleString('en'), n: d.total.toLocaleString('en')})})); }
    }
    if (d.checked) { parts.push(el('p', {class: 'fp-muted', 'data-fp-checked': '', text: t('upd_checked', {when: when(d.checked) || d.checked})})); }
    if (d.listError) { parts.push(el('p', {class: 'fp-bk-bad', 'data-fp-list-error': '', text: t('upd_list_error', {why: d.listError})})); }
    var acts = el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'refresh',
      'data-fp-focus': 'refresh', text: t('upd_check'), disabled: active(d)})]);
    parts.push(acts);
    parts.push(el('p', {class: 'fp-muted sig-hint', text: t('upd_check_hint')}));
    return M.card('fp-upd-status-h', t('upd_title'), parts, 'fp-upd-status');
  }
  function listCard() {
    var d = S.data;
    if (!d.supported || !d.updates.length) { return null; }
    var head = el('tr', null, ['upd_col_package', 'upd_col_version', 'upd_col_repo', 'upd_col_security'].map(function (k) {
      return el('th', {scope: 'col', text: t(k)});
    }));
    var rows = d.updates.map(function (u) {
      var sec = u.security ? [el('span', {class: 'sig-pill sig-pill--warn', text: u.severity ? t('upd_sec_sev', {severity: u.severity}) : t('upd_sec_plain')})] : [el('span', {text: '—'})];
      if (u.advisories.length) { sec.push(el('span', {class: 'fp-muted fp-upd-adv', text: u.advisories.join(', ')})); }
      return el('tr', {'data-fp-update': u.name + '.' + u.arch}, [
        el('th', {scope: 'row'}, [el('span', {class: 'sig-mono', text: u.name}), u.arch ? el('span', {class: 'fp-muted fp-upd-arch', text: u.arch}) : null]),
        el('td', null, [el('span', {class: 'sig-mono', text: u.version})]),
        el('td', null, [el('span', {text: u.repo || '—'}), u.freepanel ? el('span', {class: 'sig-pill sig-pill--accent fp-upd-fp', text: t('upd_fp')}) : null]),
        el('td', null, sec)]);
    });
    return M.card('fp-upd-list-h', t('upd_list_title'), [
      el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-upd-list-h'},
        [el('table', {class: 'sig-table fp-mail-table fp-upd-table'}, [el('thead', null, [head]), el('tbody', null, rows)])])], 'fp-upd-list');
  }
  function installButtons() {
    var d = S.data;
    var off = active(d);
    var buttons = [el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'install', 'data-fp-scope': 'security',
      'data-fp-focus': 'install-security', text: t('upd_install_security'), disabled: off}),
    el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'install', 'data-fp-scope': 'all',
      'data-fp-focus': 'install-all', text: t('upd_install_all'), disabled: off})];
    if (d.fpRepo) {
      buttons.push(el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'install', 'data-fp-scope': 'freepanel',
        'data-fp-focus': 'install-freepanel', text: t('upd_install_fp'), disabled: off}));
    }
    return buttons;
  }
  function installCard() {
    var d = S.data;
    if (!d.supported) { return null; }
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t('upd_install_desc')})];
    parts.push(el('div', {class: 'fp-actions', 'data-fp-install': ''}, installButtons()));
    if (active(d)) { parts.push(el('p', {class: 'fp-muted', 'data-fp-install-busy': '', text: t('upd_install_busy')})); }
    return M.card('fp-upd-install-h', t('upd_install_title'), parts, 'fp-upd-install');
  }
  function jobSentence(j) {
    var what = whatText(j);
    var at = when(j.state === 'running' ? j.started : j.ended) || '—';
    if (j.state === 'running') { return t('upd_job_running', {what: what, when: when(j.started) || '—'}); }
    if (j.state === 'succeeded') { return t('upd_job_ok', {what: what, when: at}); }
    if (j.state === 'stopped') { return t('upd_job_stopped', {what: what, when: at}); }
    return t('upd_job_failed', {what: what, when: at});
  }
  function jobCard() {
    var d = S.data;
    if (!d.supported) { return null; }
    var j = d.job;
    var parts = [M.errorLine(), M.statusLine()];
    if (j.state === 'idle') {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-job': 'idle', text: t('upd_job_idle')}));
      return M.card('fp-upd-job-h', t('upd_job_title'), parts, 'fp-upd-job');
    }
    parts.push(el('p', {'data-fp-job': j.state, class: j.state === 'failed' ? 'fp-bk-bad' : '', text: jobSentence(j)}));
    if (j.state === 'failed') {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-job-why': '', text: j.timedOut ? t('upd_job_timeout') : (j.exit !== null ? t('upd_job_exit', {code: j.exit}) : t('upd_job_noexit'))}));
    }
    if (j.state === 'stopped') { parts.push(el('p', {class: 'fp-muted', text: t('upd_job_stopped_note')})); }
    if (j.state === 'running') {
      parts.push(el('div', {class: 'fp-actions', 'data-fp-stop': ''}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button',
        'data-fp-act': 'stop', 'data-fp-focus': 'stop', text: t('upd_stop')})]));
    }
    if (j.log.length) {
      if (j.truncated) { parts.push(el('p', {class: 'fp-muted sig-hint', text: t('upd_log_cut')})); }
      parts.push(el('pre', {class: 'fp-upd-log sig-mono', tabindex: '0', role: 'region', 'aria-label': t('upd_log_label'), 'data-fp-log': '', text: j.log.join('\n')}));
    } else if (j.state === 'running') {
      parts.push(el('p', {class: 'fp-muted', text: t('upd_log_none')}));
    }
    return M.card('fp-upd-job-h', t('upd_job_title'), parts, 'fp-upd-job');
  }
  function autoCard() {
    var d = S.data;
    if (!d.supported) { return null; }
    var a = d.auto;
    var parts = [M.errorLine(), M.statusLine(), el('p', {'data-fp-auto': a.enabled ? 'on' : 'off', text: t(a.enabled ? 'upd_auto_on' : 'upd_auto_off')})];
    if (a.enabled && a.next) { parts.push(el('p', {class: 'fp-muted', 'data-fp-auto-next': '', text: t('upd_auto_next', {when: when(a.next) || a.next})})); }
    if (a.running) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-auto-running': '', text: t('upd_auto_running')}));
      parts.push(el('div', {class: 'fp-actions', 'data-fp-stop': ''}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button',
        'data-fp-act': 'stop', 'data-fp-focus': 'stop-auto', 'data-fp-stop-of': 'automatic', text: t('upd_stop_auto')})]));
    } else if (a.last) {
      parts.push(el('p', {class: a.lastOk ? 'fp-muted' : 'fp-bk-bad', 'data-fp-auto-last': '', text: t(a.lastOk ? 'upd_auto_last_ok' : 'upd_auto_last_bad', {when: when(a.last) || a.last})}));
    }
    parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn ' + (a.enabled ? 'sig-btn--secondary' : 'sig-btn--primary'), type: 'button',
      'data-fp-act': a.enabled ? 'auto-off' : 'auto-on', 'data-fp-focus': 'auto', text: t(a.enabled ? 'upd_auto_turn_off' : 'upd_auto_turn_on')})]));
    parts.push(el('p', {class: 'fp-muted sig-hint', text: t('upd_auto_note')}));
    return M.card('fp-upd-auto-h', t('upd_auto_title'), parts, 'fp-upd-auto');
  }
  var MAKERS = {'fp-upd-status': statusCard, 'fp-upd-list': listCard, 'fp-upd-install': installCard, 'fp-upd-job': jobCard, 'fp-upd-auto': autoCard};

  /* puts a card in its place among the others, keeping the focus on the same button, or on the card's heading. While the
     page only follows a running update (keep), an answer or error still on show stays, and a question being asked is
     not taken away: only the output under it moves on */
  function swap(cls, keep) {
    var old = S.page.querySelector('.' + cls);
    if (keep && old && old.querySelector('.fp-mail-confirm')) {
      var shown = old.querySelector('[data-fp-log]');
      var made = MAKERS[cls]();
      var log = made ? made.querySelector('[data-fp-log]') : null;
      if (shown && log) { shown.textContent = log.textContent; }
      return;
    }
    var fresh = MAKERS[cls]();
    var focused = document.activeElement;
    var key = old && focused && old.contains(focused) ? focused.getAttribute('data-fp-focus') : null;
    var oldLog = old ? old.querySelector('[data-fp-log]') : null;
    var atEnd = oldLog ? oldLog.scrollTop + oldLog.clientHeight >= oldLog.scrollHeight - 4 : true;
    if (!fresh) { if (old) { old.remove(); } return; }
    if (keep && old) {
      var oldError = old.querySelector('[data-fp-error]');
      if (oldError && oldError.textContent) { UI.showError(fresh, oldError.textContent); }
      var said = old.querySelector('[data-fp-status]');
      if (said) { M.say(fresh, said.textContent); }
    }
    if (old) {
      old.replaceWith(fresh);
    } else {
      var later = null;
      for (var i = CARDS.indexOf(cls) + 1; i < CARDS.length && !later; i++) { later = S.page.querySelector('.' + CARDS[i]); }
      S.page.insertBefore(fresh, later);
    }
    var tail = fresh.querySelector('[data-fp-log]');
    if (tail && (atEnd || !old) && S.data.job.state === 'running') { tail.scrollTop = tail.scrollHeight; }
    if (key) {
      var back = fresh.querySelector('[data-fp-focus="' + key + '"]:not([disabled])') || fresh.querySelector('.fp-h2');
      if (back) { back.focus(); }
    }
  }
  function drawAll() {
    CARDS.forEach(function (c) { swap(c, false); });
  }
  /* what changes while an update runs; the list of waiting updates stays as it is */
  function drawLive() {
    ['fp-upd-status', 'fp-upd-install', 'fp-upd-job', 'fp-upd-auto'].forEach(function (c) { swap(c, true); });
  }

  /* ---------- asking the server ---------- */
  function say(cls, text) {
    var card = S.page.querySelector('.' + cls);
    if (card) { M.say(card, text); }
  }
  function fail(cls, err) {
    var card = S.page.querySelector('.' + cls);
    if (card) { UI.showError(card, err && err.message ? err.message : t('api_failed')); }
  }
  /* while an update runs, asks how it is every few seconds; when it ends, reads the list again and says so */
  function poll() {
    window.clearTimeout(S.timer);
    var mine = S;
    mine.timer = window.setTimeout(function () {
      if (S !== mine || !document.body.contains(mine.page)) { return; }
      FP.call('get', 'serverUpdates').then(function (r) {
        if (S !== mine) { return; }
        var wasBusy = active(mine.data);
        adopt(clean(r));
        if (active(mine.data)) { drawLive(); poll(); return; }
        drawAll();
        if (wasBusy && mine.watching) { say('fp-upd-job', t('upd_ended')); }
        mine.watching = false;
      }, function () { if (S === mine) { poll(); } });
    }, POLL_MS);
  }
  /* an update was started or stopped: the server's answer is the job as it is now */
  function took(job, message, cls) {
    S.data.job = cleanJob(job);
    S.data.busy = S.data.job.state === 'running';
    S.data.listHeld = S.data.busy;
    S.watching = true;
    swap(cls, false);
    drawLive();
    var card = S.page.querySelector('.' + cls);
    if (card) { var h = card.querySelector('.fp-h2'); if (h) { h.focus(); } }
    say(cls, message);
    poll();
  }
  function reload(cls, message) {
    var mine = S;
    FP.call('get', 'serverUpdates').then(function (r) {
      if (S !== mine) { return; }
      adopt(clean(r));
      drawAll();
      if (message) { say(cls, message); }
      if (active(mine.data)) { poll(); }
    }, function (err) { if (S === mine) { fail(cls, err); } });
  }

  /* the card a button is in */
  function cardOf(b) {
    return CARDS.filter(function (c) { return b.closest('.' + c); })[0] || '';
  }
  function onClick(e) {
    var target = e.target && e.target.closest ? e.target : null;
    var b = target && S && S.page && S.page.contains(target) ? target.closest('[data-fp-act]') : null;
    if (!b) { return; }
    var act = b.getAttribute('data-fp-act');
    var mine = S;
    var scope = b.getAttribute('data-fp-scope');
    var cls = cardOf(b);
    if (act === 'install' && SCOPES.indexOf(scope) >= 0) {
      var holder = b.parentNode;
      M.confirmIn(holder, t('upd_ask_' + scope), 'install-yes', t('upd_install_yes'));
      holder.querySelector('[data-fp-act="install-yes"]').setAttribute('data-fp-scope', scope);
      holder.setAttribute('data-fp-asked', scope);
    } else if (act === 'stop') {
      var auto = b.getAttribute('data-fp-stop-of') === 'automatic';
      M.confirmIn(b.parentNode, t(auto ? 'upd_ask_stop_auto' : 'upd_ask_stop'), 'stop-yes', t('upd_stop_yes'));
    } else if (act === 'confirm-no') {
      var asked = b.parentNode.getAttribute('data-fp-asked');
      swap(cls, false);
      var back = S.page.querySelector('.' + cls + ' [data-fp-scope="' + (asked || '') + '"]') || S.page.querySelector('.' + cls + ' [data-fp-act]:not([disabled])');
      if (back) { back.focus(); }
    } else if (act === 'refresh') {
      start(b, cls, 'post', 'serverUpdatesRefresh', undefined, function (r) { took(r && r.job, t('upd_check_started'), cls); });
    } else if (act === 'install-yes' && SCOPES.indexOf(scope) >= 0) {
      start(b, cls, 'post', 'serverUpdatesApply', {scope: scope}, function (r) { took(r && r.job, t('upd_install_started'), cls); });
    } else if (act === 'stop-yes') {
      start(b, cls, 'post', 'serverUpdatesStop', undefined, function () {
        if (S === mine) { reload(cls, t('upd_stopped')); }
      });
    } else if (act === 'auto-on' || act === 'auto-off') {
      start(b, cls, 'put', 'serverUpdatesAuto', {enabled: act === 'auto-on'}, function (r) {
        S.data.auto = cleanAuto(r);
        swap(cls, false);
        say(cls, t(S.data.auto.enabled ? 'upd_auto_saved_on' : 'upd_auto_saved_off'));
        var h = S.page.querySelector('.' + cls + ' .fp-h2');
        if (h) { h.focus(); }
      });
    }
  }
  /* one call from a button: busy while it runs, the card's error line on failure; a refusal because an update is
     running (409) also brings the page up to date */
  function start(b, cls, method, path, body, done) {
    var mine = S;
    var card = S.page.querySelector('.' + cls);
    UI.showError(card, '');
    M.say(card, '');
    UI.setBusy(b, true);
    FP.call(method, path, body).then(function (r) {
      if (S !== mine) { return; }
      UI.setBusy(b, false);
      done(r);
    }, function (err) {
      if (S !== mine) { return; }
      UI.setBusy(b, false);
      /* the question the button belonged to is closed; the buttons come back */
      swap(cls, false);
      fail(cls, err);
      var f = S.page.querySelector('.' + cls + ' [data-fp-act]:not([disabled])');
      if (f) { f.focus(); }
      if (err && err.status === 409) { catchUp(); }
    });
  }
  /* reads the page's data again without saying anything: what shows stays */
  function catchUp() {
    var mine = S;
    FP.call('get', 'serverUpdates').then(function (r) {
      if (S !== mine) { return; }
      adopt(clean(r));
      CARDS.forEach(function (c) { swap(c, true); });
      if (active(mine.data)) { mine.watching = true; poll(); }
    }, function () {});
  }
  document.addEventListener('click', onClick);

  FP.view('tool:server_updates', function () {
    var tool = FP.tools.server_updates;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('upd_desc'), cls: 'fp-mail fp-upd',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    if (S) { window.clearTimeout(S.timer); }
    S = {page: body, data: null, timer: 0, watching: false};
    var mine = S;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'serverUpdates').then(function (r) {
      if (S !== mine) { return; }
      mine.data = clean(r);
      body.textContent = '';
      drawAll();
      if (active(mine.data)) { poll(); }
    }, function (err) {
      if (S !== mine) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

/* freePanel website settings (docs/api.md, "Domains and sites"): the customer panel's PHP version (#/tool/php_version:
   each website's PHP version, from the versions installed on the server) and Redirects (#/tool/redirects: send
   visitors of one of a website's names, or one of its pages, to another address; each name's canonical host and HTTPS;
   and a test that follows an address through this server's own web server) pages. Before a redirect is added the
   server follows it over every site of the account: a loop is refused, and a chain is shown and saved only when asked. Other names of a website use
   its settings, so only websites are listed. Every change answers with the whole list again. The page pieces come from
   FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var DOMAIN_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var VERSION_RE = /^[5-9]\.[0-9]$/;
  var PATH_RE = /^\/[^\s]{0,1023}$/;
  var MAX_REDIRECTS = 100;
  var MAX_TARGET = 2048;
  var WWW = ['either', 'only_www', 'no_www'];
  var STATUSES = [301, 308, 302, 307];
  var QUERY = ['keep', 'drop', 'merge'];
  var MANAGED = ['', 'canonical', 'https'];

  function str(v) { return typeof v === 'string' ? v : ''; }
  function kindOf(k) { return k === 'main' || k === 'addon' ? k : (k === 'sub' || k === 'subdomain' ? 'sub' : ''); }
  var ORDER = {main: 0, addon: 1, sub: 2};
  function has(v) { return v !== undefined && v !== null; }
  /* a redirect the page can show and send back as it is, or null. The page replaces a website's whole list on every
     change, so a rule it left out or rewrote would be lost or changed in the live website: a website with such a rule
     is read-only here (docs/api.md names the default of a field that is left out) */
  function cleanRedirect(r) {
    if (!r || typeof r !== 'object') { return null; }
    var o = {domain: has(r.domain) ? r.domain : '', path: has(r.path) ? r.path : '/', target: r.target, status: has(r.status) ? r.status : 301,
      www: has(r.www) ? r.www : 'either', wildcard: has(r.wildcard) ? r.wildcard : false, query: has(r.query) ? r.query : 'keep',
      httpOnly: has(r.http_only) ? r.http_only : false, managed: has(r.managed) ? r.managed : ''};
    var ok = (o.domain === '' || DOMAIN_RE.test(str(o.domain))) && PATH_RE.test(str(o.path)) && /^https?:\/\/\S+$/i.test(str(o.target)) &&
      o.target.length <= MAX_TARGET && STATUSES.indexOf(o.status) >= 0 && WWW.indexOf(o.www) >= 0 && typeof o.wildcard === 'boolean' &&
      QUERY.indexOf(o.query) >= 0 && typeof o.httpOnly === 'boolean' && MANAGED.indexOf(o.managed) >= 0;
    return ok ? o : null;
  }
  /* the chains (and loops) the server found: each a rule whose redirect leads on to another redirect of the account */
  function cleanChains(v) {
    return (Array.isArray(v) ? v : []).filter(function (c) { return c && typeof c === 'object' && Array.isArray(c.hops) && c.hops.length; }).slice(0, 50).map(function (c) {
      return {site: str(c.site).slice(0, 253), rule: typeof c.rule === 'number' ? c.rule : 0, loop: c.loop === true,
        hops: c.hops.slice(0, 12).map(function (h) { return {from: str(h && h.from).slice(0, 600), status: h && typeof h.status === 'number' ? h.status : 0, to: str(h && h.to).slice(0, 600)}; })};
    });
  }
  function clean(v) {
    v = v && typeof v === 'object' ? v : {};
    var sites = (Array.isArray(v.sites) ? v.sites : []).filter(function (s) {
      return s && DOMAIN_RE.test(str(s.domain)) && kindOf(s.kind);
    }).map(function (s) {
      var raw = Array.isArray(s.redirects) ? s.redirects : [];
      var shown = raw.map(cleanRedirect).filter(Boolean);
      return {domain: s.domain, kind: kindOf(s.kind), php: VERSION_RE.test(str(s.php_version)) ? s.php_version : '',
        aliases: (Array.isArray(s.aliases) ? s.aliases : []).filter(function (a) { return DOMAIN_RE.test(str(a)); }).sort(),
        redirects: shown, readable: shown.length === raw.length};
    }).sort(function (a, b) { return ORDER[a.kind] - ORDER[b.kind] || (a.domain < b.domain ? -1 : 1); });
    return {suspended: v.suspended === true, sites: sites, chains: cleanChains(v.chains)};
  }
  function cleanVersions(v) {
    v = v && typeof v === 'object' ? v : {};
    var list = (Array.isArray(v.versions) ? v.versions : []).filter(function (x) { return VERSION_RE.test(str(x)); });
    return {versions: list, def: VERSION_RE.test(str(v.default)) ? v.default : ''};
  }
  function frame(id, cls) {
    var tool = FP.tools[id];
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return null; }
    var g = FP.group(tool.group);
    return FP.frame({title: tool.label, desc: t(id + '_desc'), cls: 'fp-mail fp-site ' + cls,
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
  }
  function siteOf(P, domain) { return P.state.sites.filter(function (s) { return s.domain === domain; })[0]; }

  /* ================= PHP version ================= */
  var PV = {page: null, state: null, versions: null, account: ''};

  function phpOptions(current) {
    var list = PV.versions.versions.slice();
    var opts = list.map(function (v) {
      return el('option', {value: v, text: t(v === PV.versions.def ? 'php_option_default' : 'php_option', {v: v})});
    });
    /* a site may still run a version the server no longer has: show it, but it can't be picked again */
    if (current && list.indexOf(current) < 0) {
      opts.unshift(el('option', {value: current, disabled: '', text: t('php_option_gone', {v: current})}));
    }
    opts.forEach(function (o) { if (o.value === current) { o.selected = true; } });
    return opts;
  }
  function pvRender() {
    PV.page.textContent = '';
    if (PV.state.suspended) { PV.page.appendChild(M.suspendedBanner(t('dom_suspended'))); }
    var rows = PV.state.sites.map(function (s) {
      var id = 'fp-php-' + s.domain.replace(/[^a-z0-9]/g, '-');
      var pick = el('select', {class: 'sig-select fp-php-pick', id: id, 'aria-label': t('php_for', {domain: s.domain})}, phpOptions(s.php));
      var save = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'php-save', text: t('php_save'),
        'aria-label': t('php_save_for', {domain: s.domain}), disabled: ''});
      pick.addEventListener('change', function () { save.disabled = pick.value === s.php; });
      return el('tr', {'data-fp-site': s.domain}, [
        el('th', {scope: 'row', class: 'fp-mail-name'}, [el('span', {text: s.domain}),
          s.aliases.length ? el('span', {class: 'fp-muted fp-row-note', text: t('php_also', {names: s.aliases.join(', ')})}) : null]),
        el('td', {class: 'fp-php-now'}, [s.php ? el('span', {text: t('php_option', {v: s.php})}) : el('span', {class: 'fp-muted', text: '—'})]),
        el('td', {class: 'fp-php-cell'}, [el('div', {class: 'fp-php-change'}, [pick, save])])]);
    });
    var parts = [M.errorLine(), M.statusLine(),
      el('p', {class: 'fp-muted', 'data-fp-php-default': '', text: PV.versions.def ? t('php_default_note', {v: PV.versions.def}) : t('php_note')})];
    if (!PV.versions.versions.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('php_none_installed')}));
    } else if (!rows.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('php_no_sites')}));
    } else {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-php-h'}, [
        el('table', {class: 'sig-table fp-mail-table fp-php-table'}, [el('thead', null, [el('tr', null, [
          el('th', {scope: 'col', text: t('php_site')}), el('th', {scope: 'col', text: t('php_now')}),
          el('th', {scope: 'col', text: t('php_change')})])]), el('tbody', null, rows)])]));
    }
    PV.page.appendChild(M.card('fp-php-h', t('php_title'), parts, 'fp-php-list'));
  }
  function pvSave(b, tr) {
    var domain = tr.getAttribute('data-fp-site');
    var pick = tr.querySelector('select');
    var v = pick.value;
    var card = PV.page.querySelector('.fp-php-list');
    UI.showError(card, '');
    M.say(card, '');
    UI.setBusy(b, true);
    FP.call('put', 'sitePHP', {php_version: v}, {name: PV.account, domain: domain}).then(function (r) {
      PV.state = clean(r);
      pvRender();
      M.say(PV.page.querySelector('.fp-php-list'), t('php_saved', {domain: domain, v: v}));
      var again = PV.page.querySelector('tr[data-fp-site="' + window.CSS.escape(domain) + '"] select');
      if (again) { again.focus(); }
    }, function (err) {
      UI.setBusy(b, false);
      UI.showError(card, err.message);
      pick.focus();
    });
  }

  /* ================= Redirects ================= */
  var RD = {page: null, state: null, account: '', site: '', pending: null, test: null};

  function whereText(r, site) {
    return (r.domain || t('rd_every_name', {domain: site.domain})) + r.path + (r.wildcard ? '*' : '');
  }
  function statusText(st) { return t(st === 301 || st === 308 ? 'rd_permanent_n' : 'rd_temporary_n', {n: st}); }
  function rdNotes(r) {
    var notes = [];
    if (r.www !== 'either') { notes.push(t(r.www === 'only_www' ? 'rd_only_www' : 'rd_no_www')); }
    if (r.httpOnly) { notes.push(t('rd_http_only_note')); }
    if (r.query !== 'keep') { notes.push(t(r.query === 'drop' ? 'rd_query_drop_note' : 'rd_query_merge_note')); }
    if (r.managed) { notes.push(t(r.managed === 'https' ? 'rd_managed_https' : 'rd_managed_canonical')); }
    return notes.map(function (n) { return el('span', {class: 'fp-muted fp-row-note', text: n}); });
  }
  function rdRow(site, r, i) {
    return el('tr', {'data-fp-redirect': String(i)}, [
      el('th', {scope: 'row', class: 'fp-rd-from'}, [el('span', {class: 'sig-mono', text: whereText(r, site)})].concat(rdNotes(r))),
      el('td', {class: 'fp-rd-to sig-mono', text: r.target}),
      el('td', null, [el('span', {class: 'sig-pill' + (r.status === 301 || r.status === 308 ? ' sig-pill--accent' : ''), text: statusText(r.status)})]),
      el('td', {class: 'fp-mail-acts'}, site.readable && !r.managed ? [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button',
        'data-fp-act': 'rd-remove', 'aria-label': t('rd_remove_of', {where: whereText(r, site)}), text: t('rd_remove')})] : [])]);
  }
  /* the chains of the account that start at this site, as a list of addresses */
  function chainList(chains) {
    return el('ul', {class: 'fp-rd-chains'}, chains.map(function (c) {
      var parts = [c.hops[0].from].concat(c.hops.map(function (h) { return h.to; }));
      return el('li', {class: 'sig-mono', text: parts.join(' → ')});
    }));
  }
  function rdListCard(site) {
    var parts = [M.errorLine(), M.statusLine()];
    if (!site.readable) { parts.push(M.suspendedBanner(t('rd_unreadable'))); }
    var mine = RD.state.chains.filter(function (c) { return c.site === site.domain; });
    if (mine.length) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn fp-rd-chain-note', role: 'note', 'data-fp-chains': ''}, [UI.icon(FP.ui, 'ui_warning'),
        el('div', null, [el('p', {text: t(mine.length === 1 ? 'rd_chains_one' : 'rd_chains', {n: mine.length})}), chainList(mine)])]));
    }
    if (!site.redirects.length) {
      if (site.readable) { parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('rd_none', {domain: site.domain})})); }
    } else {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-rd-list-h'}, [
        el('table', {class: 'sig-table fp-mail-table fp-rd-table'}, [el('thead', null, [el('tr', null, [
          el('th', {scope: 'col', text: t('rd_from')}), el('th', {scope: 'col', text: t('rd_to')}), el('th', {scope: 'col', text: t('rd_type')}),
          el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]),
        el('tbody', null, site.redirects.map(function (r, i) { return rdRow(site, r, i); }))])]));
    }
    return M.card('fp-rd-list-h', t('rd_list_title', {domain: site.domain}), parts, 'fp-rd-list');
  }
  function rdAddCard(site) {
    var names = [site.domain].concat(site.aliases);
    var dom = el('select', {class: 'sig-select', id: 'fp-rd-domain', name: 'domain'},
      [el('option', {value: '', text: t('rd_every_name_option')})].concat(names.map(function (n) { return el('option', {value: n, text: n}); })));
    var path = el('input', {class: 'sig-input sig-mono', id: 'fp-rd-path', name: 'path', type: 'text', value: '/', autocomplete: 'off', spellcheck: 'false',
      autocapitalize: 'none', maxlength: '1024'});
    var target = el('input', {class: 'sig-input', id: 'fp-rd-target', name: 'target', type: 'url', inputmode: 'url', autocomplete: 'off', spellcheck: 'false',
      autocapitalize: 'none', maxlength: String(MAX_TARGET), placeholder: 'https://www.example.com/'});
    var status = el('select', {class: 'sig-select', id: 'fp-rd-status', name: 'status'},
      STATUSES.map(function (st) { return el('option', {value: String(st), text: t('rd_' + st + '_long')}); }));
    var www = el('select', {class: 'sig-select', id: 'fp-rd-www', name: 'www'},
      [['either', 'rd_www_either'], ['only_www', 'rd_www_only'], ['no_www', 'rd_www_no']].map(function (o) { return el('option', {value: o[0], text: t(o[1])}); }));
    var query = el('select', {class: 'sig-select', id: 'fp-rd-query', name: 'query'},
      QUERY.map(function (q) { return el('option', {value: q, text: t('rd_query_' + q)}); }));
    var wild = el('input', {type: 'checkbox', id: 'fp-rd-wild', name: 'wildcard'});
    var plain = el('input', {type: 'checkbox', id: 'fp-rd-plain', name: 'http_only'});
    var form = el('form', {class: 'fp-form fp-mail-form fp-rd-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-rd-grid'}, [M.field('fp-rd-domain', t('rd_domain'), dom), M.field('fp-rd-path', t('rd_path'), path, t('rd_path_hint'))]),
      M.field('fp-rd-target', t('rd_target'), target, t('rd_target_hint')),
      el('div', {class: 'fp-rd-grid'}, [M.field('fp-rd-status', t('rd_type'), status, t('rd_type_hint')), M.field('fp-rd-www', t('rd_www'), www)]),
      M.field('fp-rd-query', t('rd_query'), query, t('rd_query_hint')),
      el('div', {class: 'sig-field fp-check'}, [wild, el('label', {for: 'fp-rd-wild', text: t('rd_wildcard')})]),
      el('p', {class: 'sig-hint', id: 'fp-rd-wild-hint', text: t('rd_wildcard_hint')}),
      el('div', {class: 'sig-field fp-check'}, [plain, el('label', {for: 'fp-rd-plain', text: t('rd_http_only')})]),
      el('p', {class: 'sig-hint', id: 'fp-rd-plain-hint', text: t('rd_http_only_hint')}),
      el('div', {class: 'fp-rd-confirm', 'data-fp-rd-confirm': ''}),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('rd_add')})])]);
    wild.setAttribute('aria-describedby', 'fp-rd-wild-hint');
    plain.setAttribute('aria-describedby', 'fp-rd-plain-hint');
    form.addEventListener('input', function () {
      /* a change after the chain warning asks again */
      if (RD.pending) {
        RD.pending = null;
        form.querySelector('[data-fp-rd-confirm]').textContent = '';
        form.querySelector('.fp-submit').textContent = t('rd_add');
      }
    });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var p = path.value.trim() || '/';
      if (p.charAt(0) !== '/') { p = '/' + p; }
      if (!PATH_RE.test(p)) { M.fieldError(form, path, t('rd_path_bad')); return; }
      var to = target.value.trim();
      if (!/^https?:\/\/[^\s/]+\.[^\s]*$/.test(to) || to.length > MAX_TARGET) { M.fieldError(form, target, t('rd_target_bad')); return; }
      if (site.redirects.length >= MAX_REDIRECTS) { M.fieldError(form, null, t('rd_too_many', {n: MAX_REDIRECTS})); return; }
      var r = {domain: dom.value, path: p, target: to, status: Number(status.value), www: www.value, wildcard: wild.checked, query: query.value,
        httpOnly: plain.checked, managed: ''};
      var list = site.redirects.concat([r]);
      var failed = function (err) {
        UI.setBusy(b, false);
        /* the server names the redirect by its number; the new one is the last */
        M.fieldError(form, /path/.test(err.message) ? path : (/target|itself|loop/.test(err.message) ? target : null), err.message.replace(/^redirect \d+: /, ''));
      };
      UI.setBusy(b, true);
      if (RD.pending) {
        RD.pending = null;
        rdSave(site, list, r).then(null, failed);
        return;
      }
      /* checked first: a loop is refused, and a chain this redirect makes is shown before it is saved */
      FP.call('post', 'siteRedirectsCheck', {redirects: body(list)}, {name: RD.account, domain: site.domain}).then(function (c) {
        var before = RD.state.chains.length;
        var now = cleanChains(c && c.chains);
        if (now.length > before) {
          UI.setBusy(b, false);
          RD.pending = r;
          var box = form.querySelector('[data-fp-rd-confirm]');
          box.textContent = '';
          box.appendChild(el('div', {class: 'sig-banner sig-banner--warn', role: 'alert'}, [UI.icon(FP.ui, 'ui_warning'),
            el('div', null, [el('p', {text: t('rd_chain_ask')}), chainList(now)])]));
          b.textContent = t('rd_add_anyway');
          b.focus();
          return;
        }
        return rdSave(site, list, r);
      }).then(null, failed);
    });
    return M.card('fp-rd-add-h', t('rd_add_title'), [form], 'fp-rd-add');
  }
  function rdSave(site, list, r) {
    return rdPut(site, list).then(function () {
      M.say(RD.page.querySelector('.fp-rd-add'), t('rd_added', {where: whereText(r, site)}));
      RD.page.querySelector('#fp-rd-target').focus();
    });
  }
  function body(list) {
    return list.map(function (r) {
      var o = {path: r.path, target: r.target, status: r.status, www: r.www, wildcard: r.wildcard, query: r.query};
      if (r.domain) { o.domain = r.domain; }
      if (r.httpOnly) { o.http_only = true; }
      if (r.managed) { o.managed = r.managed; }
      return o;
    });
  }
  /* sends the site's whole list; resolves once the page shows the answer */
  function rdPut(site, list) {
    return FP.call('put', 'siteRedirects', {redirects: body(list)}, {name: RD.account, domain: site.domain}).then(function (r) {
      RD.state = clean(r);
      RD.pending = null;
      rdRender();
    });
  }
  /* each name's canonical host and HTTPS, as the panel's own rules say */
  function canonicalOf(site, name) {
    var host = 'either';
    var https = false;
    site.redirects.forEach(function (r) {
      if (r.domain !== name || !r.managed) { return; }
      if (r.managed === 'canonical') { host = r.www === 'only_www' ? 'bare' : 'www'; }
      if (r.managed === 'https') { https = true; }
    });
    return {host: host, https: https};
  }
  function rdCanonicalCard(site) {
    var names = [site.domain].concat(site.aliases).filter(function (n) { return n.indexOf('www.') !== 0; });
    var rows = names.map(function (n, i) {
      var now = canonicalOf(site, n);
      var id = 'fp-rd-cn-' + i;
      var host = el('select', {class: 'sig-select', id: id, 'aria-label': t('rd_canon_host_for', {name: n})},
        [['either', 'rd_canon_either'], ['bare', 'rd_canon_bare'], ['www', 'rd_canon_www']].map(function (o) {
          var opt = el('option', {value: o[0], text: t(o[1], {name: n})});
          if (o[0] === now.host) { opt.selected = true; }
          return opt;
        }));
      var https = el('input', {type: 'checkbox', id: id + '-https'});
      https.checked = now.https;
      return el('tr', {'data-fp-canon': n}, [
        el('th', {scope: 'row', class: 'fp-rd-from'}, [el('span', {class: 'sig-mono', text: n})]),
        el('td', null, [host]),
        el('td', null, [el('div', {class: 'fp-check'}, [https, el('label', {for: id + '-https', text: t('rd_canon_https')})])]),
        el('td', {class: 'fp-mail-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'rd-canon-save',
          'aria-label': t('rd_canon_save_for', {name: n}), text: t('rd_canon_save')})])]);
    });
    return M.card('fp-rd-canon-h', t('rd_canon_title'), [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t('rd_canon_note')}),
      el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-rd-canon-h'}, [
        el('table', {class: 'sig-table fp-mail-table fp-rd-canon'}, [el('thead', null, [el('tr', null, [
          el('th', {scope: 'col', text: t('rd_canon_name')}), el('th', {scope: 'col', text: t('rd_canon_host')}), el('th', {scope: 'col', text: t('rd_canon_https_col')}),
          el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]), el('tbody', null, rows)])])], 'fp-rd-canon-card');
  }
  var RESULTS = ['arrives', 'leaves', 'loop', 'too_many', 'failed'];
  function cleanTest(v) {
    v = v && typeof v === 'object' ? v : {};
    return {result: RESULTS.indexOf(v.result) >= 0 ? v.result : 'failed', final: str(v.final).slice(0, 600),
      hops: (Array.isArray(v.hops) ? v.hops : []).slice(0, 12).map(function (h) {
        h = h && typeof h === 'object' ? h : {};
        return {url: str(h.url).slice(0, 600), status: typeof h.status === 'number' ? h.status : 0, location: str(h.location).slice(0, 600), error: str(h.error).slice(0, 300)};
      }),
      expected: cleanChains([{hops: v.expected}]).concat([{hops: []}])[0].hops};
  }
  function rdTestCard(site) {
    var url = el('input', {class: 'sig-input sig-mono', id: 'fp-rd-test-url', name: 'url', type: 'url', inputmode: 'url', autocomplete: 'off', spellcheck: 'false',
      autocapitalize: 'none', maxlength: String(MAX_TARGET), value: RD.test && RD.test.site === site.domain ? RD.test.url : 'http://' + site.domain + '/'});
    var form = el('form', {class: 'fp-form fp-mail-form fp-rd-test', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-rd-test-url', t('rd_test_url'), url, t('rd_test_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary fp-submit', type: 'submit', text: t('rd_test_run')})])]);
    var out = el('div', {'data-fp-rd-test-out': ''});
    if (RD.test && RD.test.site === site.domain && RD.test.out) { out.appendChild(testOut(RD.test.out)); }
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var u = url.value.trim();
      if (!/^https?:\/\/[^\s/]+/i.test(u) || u.length > MAX_TARGET) { M.fieldError(form, url, t('rd_test_bad')); return; }
      UI.setBusy(b, true);
      FP.call('post', 'siteRedirectsTest', {url: u}, {name: RD.account, domain: site.domain}).then(function (r) {
        UI.setBusy(b, false);
        RD.test = {site: site.domain, url: u, out: cleanTest(r)};
        out.textContent = '';
        out.appendChild(testOut(RD.test.out));
        M.say(form, t('rd_test_done'));
      }, function (err) {
        UI.setBusy(b, false);
        M.fieldError(form, err.field === 'url' ? url : null, err.message);
      });
    });
    return M.card('fp-rd-test-h', t('rd_test_title'), [el('p', {class: 'fp-muted', text: t('rd_test_note')}), form, out], 'fp-rd-test-card');
  }
  function testOut(v) {
    var steps = v.hops.map(function (h) {
      var said = h.error ? h.error : (h.location ? t('rd_test_hop', {status: h.status, to: h.location}) : t('rd_test_end', {status: h.status}));
      return el('li', null, [el('span', {class: 'sig-mono fp-rd-test-at', text: h.url}), el('span', {class: 'fp-muted fp-row-note', text: said})]);
    });
    var same = v.expected.length === v.hops.filter(function (h) { return h.location; }).length &&
      v.expected.every(function (x, i) { return v.hops[i] && v.hops[i].status === x.status; });
    return el('div', {class: 'fp-rd-test-result'}, [
      el('p', {class: 'fp-rd-test-line', 'data-fp-rd-result': v.result}, [el('span', {class: 'sig-pill ' + (v.result === 'arrives' || v.result === 'leaves' ? 'sig-pill--ok' : 'sig-pill--warn'),
        text: t('rd_test_' + v.result)}), el('span', {class: 'sig-mono fp-rd-test-final', text: v.final})]),
      el('ol', {class: 'fp-rd-test-hops'}, steps),
      el('p', {class: 'fp-muted', 'data-fp-rd-expected': same ? 'same' : 'differs', text: t(same ? 'rd_test_as_saved' : 'rd_test_differs')})]);
  }
  function rdRender() {
    RD.page.textContent = '';
    if (RD.state.suspended) { RD.page.appendChild(M.suspendedBanner(t('dom_suspended'))); }
    var sites = RD.state.sites;
    if (!sites.length) {
      RD.page.appendChild(FP.empty(t('rd_no_sites_title'), t('php_no_sites')));
      return;
    }
    if (!siteOf(RD, RD.site)) { RD.site = sites[0].domain; }
    var site = siteOf(RD, RD.site);
    var pick = el('select', {class: 'sig-select', id: 'fp-rd-site'}, sites.map(function (s) {
      var o = el('option', {value: s.domain, text: s.redirects.length ? t(s.redirects.length === 1 ? 'rd_site_option_one' : 'rd_site_option', {domain: s.domain, n: s.redirects.length}) : s.domain});
      if (s.domain === site.domain) { o.selected = true; }
      return o;
    }));
    pick.addEventListener('change', function () {
      RD.site = pick.value;
      RD.pending = null;
      rdRender();
      RD.page.querySelector('#fp-rd-site').focus();
    });
    RD.page.appendChild(el('div', {class: 'sig-field fp-rd-pick'}, [el('label', {class: 'sig-label', for: 'fp-rd-site', text: t('rd_site')}), pick]));
    RD.page.appendChild(rdListCard(site));
    if (site.readable) {
      RD.page.appendChild(rdAddCard(site));
      RD.page.appendChild(rdCanonicalCard(site));
    }
    RD.page.appendChild(rdTestCard(site));
  }
  function rdCanonSave(b, tr) {
    var site = siteOf(RD, RD.site);
    var name = tr.getAttribute('data-fp-canon');
    var card = RD.page.querySelector('.fp-rd-canon-card');
    var host = tr.querySelector('select').value;
    var https = tr.querySelector('input[type="checkbox"]').checked;
    UI.showError(card, '');
    M.say(card, '');
    UI.setBusy(b, true);
    FP.call('put', 'siteCanonical', {host: host, https: https}, {name: RD.account, domain: name}).then(function (r) {
      RD.state = clean(r);
      rdRender();
      var again = RD.page.querySelector('.fp-rd-canon-card');
      M.say(again, t('rd_canon_saved', {name: name}));
      var row = again.querySelector('tr[data-fp-canon="' + window.CSS.escape(name) + '"] select');
      if (row) { row.focus(); }
    }, function (err) {
      UI.setBusy(b, false);
      UI.showError(card, err.message);
      tr.querySelector('select').focus();
    });
    return site;
  }
  function rdClick(b, a, tr) {
    var site = siteOf(RD, RD.site);
    if (a === 'rd-canon-save' && tr) { rdCanonSave(b, tr); return; }
    var i = tr ? Number(tr.getAttribute('data-fp-redirect')) : -1;
    var r = site && site.readable && site.redirects[i];
    if (a === 'rd-remove' && r) {
      M.confirmIn(tr.querySelector('.fp-mail-acts'), t('rd_remove_ask', {where: whereText(r, site), target: r.target}), 'rd-remove-yes', t('rd_remove'));
    } else if (a === 'confirm-no') {
      rdRender();
      var back = RD.page.querySelector('tr[data-fp-redirect="' + i + '"] [data-fp-act="rd-remove"]');
      if (back) { back.focus(); }
    } else if (a === 'rd-remove-yes' && r) {
      UI.setBusy(b, true);
      var where = whereText(r, site);
      rdPut(site, site.redirects.filter(function (x, j) { return j !== i; })).then(function () {
        M.say(RD.page.querySelector('.fp-rd-list'), t('rd_removed', {where: where}));
        RD.page.querySelector('#fp-rd-list-h').focus();
      }, function (err) {
        rdRender();
        UI.showError(RD.page.querySelector('.fp-rd-list'), err.message);
        var again = RD.page.querySelector('tr[data-fp-redirect="' + i + '"] [data-fp-act="rd-remove"]');
        if (again) { again.focus(); }
      });
    }
  }

  document.addEventListener('click', function (e) {
    var target = e.target.closest ? e.target : null;
    var b = target && target.closest('[data-fp-act]');
    if (!b) { return; }
    var a = b.getAttribute('data-fp-act');
    var tr = b.closest('tr');
    if (PV.page && PV.page.contains(b) && a === 'php-save' && tr) { pvSave(b, tr); } else if (RD.page && RD.page.contains(b)) { rdClick(b, a, tr); }
  });

  FP.view('tool:php_version', function () {
    PV.page = RD.page = null;
    var body = frame('php_version', 'fp-php-page');
    if (!body) { return; }
    PV.page = body;
    PV.account = FP.account();
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all([FP.call('get', 'domains', undefined, PV.account), FP.call('get', 'phpVersions')]).then(function (r) {
      if (PV.page !== body) { return; }
      PV.state = clean(r[0]);
      PV.versions = cleanVersions(r[1]);
      pvRender();
    }, function (err) {
      if (PV.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(FP.tools.php_version.label, err.message));
    });
  });
  FP.view('tool:redirects', function () {
    PV.page = RD.page = null;
    var body = frame('redirects', 'fp-rd-page');
    if (!body) { return; }
    RD.page = body;
    RD.account = FP.account();
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'domains', undefined, RD.account).then(function (r) {
      if (RD.page !== body) { return; }
      RD.state = clean(r);
      rdRender();
    }, function (err) {
      if (RD.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(FP.tools.redirects.label, err.message));
    });
  });
})();

/* freePanel billing tax (#/tool/billing_tax; docs/api.md, "Billing: tax"; docs/billing/navigation-map.md, "Tax rules"): the tax settings
   (on, inclusive or exclusive, home country, reverse charge) above the rules, one rate per place (a region of a country, a whole country, or
   everywhere). A rule's place can't change; its name and rate can. Rates are hundredths of a percent, typed as a percent. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;
  var M = FP.mail;

  var RULE = {id: 'id', name: [60], country: [2], region: [100], rate_bp: 'n'};
  FP.view('tool:billing_tax', function () {
    var page = B.frame('billing_tax', 'fp-btr');
    if (!page) { return; }
    var alive = function () { return page.isConnected; };
    var top = el('div', {'data-fp-part': 'settings'});
    var rules = el('div', {class: 'fp-btr-rules', 'data-fp-part': 'rules'});
    page.appendChild(top);
    page.appendChild(rules);
    function place(r) { return !r.country ? t('btr_everywhere') : r.region ? r.region + ', ' + r.country : r.country; }
    function settings(said) {
      return FP.call('get', 'billingTaxSettings').then(function (r) {
        if (!alive()) { return; }
        var v = B.pick(r, {enabled: 'b', mode: ['=', ['exclusive', 'inclusive']], home_country: [2], reverse_charge: 'b'}) || {};
        var specs = [{name: 'enabled', label: t('btr_enabled'), kind: 'check', hint: t('btr_enabled_hint')},
          {name: 'mode', label: t('btr_mode'), kind: 'select', options: [['exclusive', t('btr_exclusive')], ['inclusive', t('btr_inclusive')]], hint: t('btr_mode_hint')},
          {name: 'home_country', label: t('btr_home'), max: 2, code: true, hint: t('btr_home_hint'), send_empty: true},
          {name: 'reverse_charge', label: t('btr_reverse'), kind: 'check', hint: t('btr_reverse_hint')}];
        var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bil_save_changes')});
        var form = el('form', {class: 'fp-form fp-bil-crud-form', novalidate: '', 'aria-labelledby': 'fp-btr-set-h'}, [M.errorLine(), M.statusLine(),
          el('div', {class: 'fp-bil-grid'}, B.fieldsOf('fp-btr-s', specs, v)), el('div', {class: 'fp-actions'}, [save])]);
        form.addEventListener('submit', function (e) {
          e.preventDefault();
          if (!B.begin(form, save)) { return; }
          var body = B.readFields(form, specs, v);
          if (!body) { return; }
          if (body.home_country !== undefined) { body.home_country = body.home_country.toUpperCase(); if (body.home_country === v.home_country) { delete body.home_country; } }
          if (!Object.keys(body).length) { M.say(form, t('bil_nothing_changed')); return; }
          UI.setBusy(save, true);
          FP.call('patch', 'billingTaxSettings', body).then(function () {
            if (alive()) { settings(t('btr_set_saved')).then(function () { page.querySelector('#fp-btr-set-h').focus(); }); }
          }, function (err) {
            if (!alive()) { return; }
            UI.setBusy(save, false);
            B.failed(form, err);
          });
        });
        B.screen(top, [B.card('fp-btr-set-h', t('btr_settings'), [el('p', {class: 'fp-muted', text: t('btr_settings_what')}), form], 'fp-btr-set', 'settings')]);
        if (said) { M.say(form, said); }
        return true;
      });
    }
    var R = B.crud({page: rules, pre: 'fp-btr', title: t('btr_rules'), alive: alive,
      what: function () { return [el('p', {class: 'fp-muted', text: t('btr_rules_what')})]; },
      load: function () { return FP.call('get', 'billingTaxRules').then(function (r) { return B.pickAll(r && r.rules, RULE, 'id'); }); },
      heads: [B.th(t('btr_col_name')), B.th(t('btr_col_place')), B.th(t('btr_col_rate'), 'fp-bil-num')],
      cells: function (r) { return [el('th', {scope: 'row', class: 'fp-bil-wrap', text: r.name}), el('td', {class: 'fp-bil-wrap', text: place(r)}), el('td', {class: 'fp-bil-num', text: B.bpText(r.rate_bp) + '%'})]; },
      fieldsFor: function (x) {
        var f = [{name: 'name', label: t('btr_col_name'), required: true, max: 60, hint: t('btr_name_hint')}, {name: 'rate_bp', label: t('btr_col_rate'), kind: 'percent', required: true, hint: t('btr_rate_hint')}];
        return x ? f : f.concat([{name: 'country', label: t('btr_country'), max: 2, code: true, hint: t('btr_country_hint')}, {name: 'region', label: t('btr_region'), max: 100, hint: t('btr_region_hint')}]);
      },
      check: function (body) { if (body.country) { body.country = body.country.toUpperCase(); } return false; },
      add: 'billingTaxRules', item: 'billingTaxRule', nameOf: function (r) { return r.name; },
      strings: {none: t('btr_none'), addTitle: t('btr_add_title'), addSave: t('btr_add'), editTitle: function (n) { return t('bil_change_title', {name: n}); },
        added: function (n) { return t('bil_added', {name: n}); }, saved: function (n) { return t('bil_saved', {name: n}); }, removed: function (n) { return t('bil_removed', {name: n}); },
        removeAsk: function (n) { return t('btr_remove_ask', {name: n}); }, removeYes: t('btr_remove_yes'), formWhat: t('btr_form_what')}});
    top.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    settings().then(function () { if (alive()) { R.show(); } }, function (err) {
      if (!alive()) { return; }
      B.screen(page, [FP.empty(t('btr_settings'), err.message, B.button('reload', t('bil_try_again')))]);
      page.querySelector('[data-fp-act="reload"]').addEventListener('click', function () { FP.route(true); });
    });
  });
})();

/* freePanel billing domains of the setup group (docs/api.md, "Billing: domains"; docs/billing/navigation-map.md, "Domain pricing"): Domain
   pricing (#/tool/billing_domain_pricing), the extensions sold with their prices for one year, below the registrar in use. An extension's
   name can't change; one with domains can't be removed (turn it off). Prices are whole cents, typed in dollars and cents. Domains
   (#/tool/billing_domains), every client's domains filtered by name, state and client; a domain's page reads it back, does its waiting work,
   changes its nameservers, lock, privacy and renewing at the registrar, renews it (an invoice is issued, asked first), shows its transfer code
   and ends its record once it has moved away (asked first). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;
  var M = FP.mail;

  var EXT = {tld: [80], register_cents: 'c', renew_cents: 'c', transfer_cents: 'c', max_years: 'n', enabled: 'b'};
  FP.view('tool:billing_domain_pricing', function () {
    var page = B.frame('billing_domain_pricing', 'fp-bdx');
    if (!page) { return; }
    var alive = function () { return page.isConnected; };
    var registrar = {active: '', name: '', read: false};
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    function inUse() {
      var text = !registrar.read ? t('bdx_registrar_unread') : registrar.active ? t('bdx_registrar_now', {name: registrar.name || registrar.active}) : t('bdx_registrar_none');
      return el('div', {class: 'fp-bdx-registrar', 'data-fp-registrar': registrar.active}, [el('p', {text: text}),
        FP.tools.billing_registrar ? B.button('open-registrar', t('bdx_registrar_change'), 'sig-btn--secondary sig-btn--sm') : null]);
    }
    var R = B.crud({page: page, pre: 'fp-bdx', title: t('bdx_title'), alive: alive, idOf: function (x) { return x.tld; }, argOf: function (x) { return {tld: x.tld}; },
      what: function () { return [inUse(), el('p', {class: 'fp-muted', text: t('bdx_what')})]; },
      load: function () {
        return Promise.all([FP.call('get', 'billingExtensions'), FP.call('get', 'billingRegistrar').then(function (r) {
          var active = B.str(r && r.active, 40);
          var list = B.pickAll(r && r.registrars, {id: [40], name: [60]}, 'id');
          registrar = {active: active, name: (list.filter(function (x) { return x.id === active; })[0] || {name: active}).name, read: true};
        }, function () { registrar = {active: '', name: '', read: false}; })]).then(function (r) {
          return B.pickAll(r[0] && r[0].extensions, EXT, 'tld').filter(function (x) { return /^[a-z0-9-]+(\.[a-z0-9-]+){0,2}$/.test(x.tld); });
        });
      },
      heads: [B.th(t('bdx_col_tld')), B.th(t('bdx_col_register'), 'fp-bil-num'), B.th(t('bdx_col_renew'), 'fp-bil-num'), B.th(t('bdx_col_transfer'), 'fp-bil-num'),
        B.th(t('bdx_col_years'), 'fp-bil-num'), B.th(t('bdx_col_sold'))],
      cells: function (x) {
        return [el('th', {scope: 'row', class: 'fp-bil-wrap'}, [el('code', {text: '.' + x.tld})]), el('td', {class: 'fp-bil-num', text: B.money(x.register_cents, 'USD')}),
          el('td', {class: 'fp-bil-num', text: B.money(x.renew_cents, 'USD')}), el('td', {class: 'fp-bil-num', text: B.money(x.transfer_cents, 'USD')}),
          el('td', {class: 'fp-bil-num', text: x.max_years === null ? '—' : B.num(x.max_years)}), el('td', null, [B.pill(t(x.enabled ? 'bdx_sold' : 'bdx_not_sold'), x.enabled ? 'ok' : '')])];
      },
      fieldsFor: function (x) {
        var f = x ? [] : [{name: 'tld', label: t('bdx_col_tld'), required: true, max: 80, code: true, hint: t('bdx_tld_hint')}];
        return f.concat([{name: 'register_cents', label: t('bdx_col_register'), kind: 'amount', required: true, hint: t('bdx_price_hint')},
          {name: 'renew_cents', label: t('bdx_col_renew'), kind: 'amount', required: true, hint: t('bdx_price_hint')},
          {name: 'transfer_cents', label: t('bdx_col_transfer'), kind: 'amount', required: true, hint: t('bdx_transfer_hint')},
          {name: 'max_years', label: t('bdx_col_years'), kind: 'number', hint: t('bdx_years_hint')},
          {name: 'enabled', label: t('bdx_enabled'), kind: 'check', value: true, hint: t('bdx_enabled_hint')}]);
      },
      check: function (body) { if (body.tld !== undefined) { body.tld = body.tld.replace(/^\.+/, '').toLowerCase(); } return false; },
      add: 'billingExtensions', item: 'billingExtension', nameOf: function (x) { return '.' + x.tld; }, clean: function (r) { return B.pick(r, EXT) || {}; },
      onAct: function (a) { if (a === 'open-registrar') { window.location.hash = '#/tool/billing_registrar'; } },
      strings: {none: t('bdx_none'), addTitle: t('bdx_add_title'), addSave: t('bdx_add'), editTitle: function (n) { return t('bil_change_title', {name: n}); },
        added: function (n) { return t('bil_added', {name: n}); }, saved: function (n) { return t('bil_saved', {name: n}); }, removed: function (n) { return t('bil_removed', {name: n}); },
        removeAsk: function (n) { return t('bdx_remove_ask', {name: n}); }, removeYes: t('bdx_remove_yes'), formWhat: t('bdx_form_what')}});
    R.show();
  });

  /* ================= Domains: the list, and a domain's page ================= */
  var STATUSES = ['pending', 'active', 'expired', 'cancelled', 'failed', 'transferred_away'];
  var DOMAIN = {id: 'id', customer_id: 'id', name: [253], tld: [80], status: ['=', STATUSES], action: [20], registrar: [40], years: 'n', invoice_id: 'id', auto_renew: 'b', locked: 'b',
    privacy: 'b', registered_on: 'd', expires_on: 'd', attempts: 'n', last_error: [300], created: 'w'};
  function cleanDomain(x) {
    var d = B.pick(x, DOMAIN);
    if (!d || !d.id || !d.name) { return null; }
    d.nameservers = (Array.isArray(x.nameservers) ? x.nameservers : []).filter(function (n) { return typeof n === 'string'; }).slice(0, 5).map(function (n) { return n.slice(0, 253); });
    return d;
  }
  var RENEWAL = {id: 'id', domain_id: 'id', years: 'n', invoice_id: 'id', status: ['=', ['pending', 'done', 'cancelled', 'failed']], attempts: 'n', last_error: [300], created_by: [64], created: 'w'};
  var D = null;
  FP.view('tool:billing_domains', function () {
    var page = B.frame('billing_domains', 'fp-bdm');
    if (!page) { return; }
    D = {page: page, names: {}, domain: null};
    var mine = D;
    var alive = function () { return D === mine && page.isConnected; };
    var live = function (d) { return d.status === 'active' || d.status === 'expired'; };
    var L = B.lister({page: page, pre: 'fp-bdm', title: t('bdm_list_title'), findLabel: t('bdm_find'), tableCls: 'fp-bdm-table', alive: alive,
      before: function () { return [el('p', {class: 'fp-muted fp-row-note', text: t('bdm_what')})]; },
      blank: {name: '', status: '', customer: ''},
      filters: [
        {name: 'name', label: t('bdm_f_name'), control: function (v) { return B.input('fp-bdm-f-name', 'name', v || '', {type: 'search', maxlength: '253', spellcheck: 'false', autocapitalize: 'none'}); }},
        {name: 'status', label: t('bdm_f_status'), control: function (v) { return B.select('fp-bdm-f-status', 'status', [['', t('bil_any')]].concat(STATUSES.map(function (s) { return [s, B.word('domain', s)]; })), v); }},
        {name: 'customer', control: function (v) { return B.clientPicker('fp-bdm-f-client', {name: 'customer', label: t('bdm_f_client'), placeholder: t('bil_any'), value: v, valueName: v ? D.names[v] : ''}); }}],
      load: function (f, offset, limit) {
        return B.listOf('billingDomains', {limit: String(limit), offset: String(offset), name: f.name.toLowerCase(), status: f.status, customer: f.customer}, 'domains', cleanDomain).then(function (r) {
          return B.namesFor(D.names, r.items.map(function (x) { return x.customer_id; })).then(function () { return r; });
        });
      },
      heads: [B.th(t('bdm_col_domain')), B.th(t('bdm_col_client')), B.th(t('bdm_col_status')), B.th(t('bdm_col_expires')), B.th(t('bdm_col_auto_renew')), B.th(t('bdm_col_registrar'))],
      row: function (d) {
        return el('tr', {'data-fp-domain': String(d.id)}, [el('th', {scope: 'row', class: 'fp-bil-name'}, [B.button('open', d.name, 'sig-btn--link fp-bil-link', {'data-fp-id': String(d.id), 'aria-label': t('bdm_open_of', {name: d.name})})]),
          el('td', {class: 'fp-bil-wrap'}, [B.clientLink(D.names, d.customer_id)]), el('td', null, [B.statePill('domain', d.status)]), el('td', {class: 'fp-bil-nowrap', text: d.expires_on ? B.day(d.expires_on) : '—'}),
          el('td', {text: t(d.auto_renew ? 'bil_yes' : 'bil_no')}), el('td', {text: d.registrar ? B.word('registrar', d.registrar) : '—'})]);
      },
      none: t('bdm_none'), noneMatch: t('bdm_none_match'),
      found: function (n) { return n === 1 ? t('bdm_found_1') : t('bdm_found', {n: B.num(n)}); }});

    /* ---- one domain ---- */
    function read(did) {
      return Promise.all([FP.call('get', 'billingDomain', undefined, {id: String(did)}), FP.call('get', 'billingDomainRenewals', undefined, {id: String(did)}).then(function (r) { return B.pickAll(r && r.renewals, RENEWAL, 'id'); }, function () { return null; })])
        .then(function (r) {
          var d = cleanDomain(r[0]);
          if (!d) { throw {message: t('api_failed')}; }
          return B.namesFor(D.names, [d.customer_id]).then(function () { return {domain: d, renewals: r[1]}; });
        });
    }
    function show(did, focus, said, saidOn) {
      return read(did).then(function (x) {
        if (!alive()) { return; }
        D.domain = x.domain;
        draw(x.domain, x.renewals);
        page.setAttribute('data-fp-from', String(did));
        var f = page.querySelector(focus || '#fp-bdm-dom-h');
        if (f) { f.focus(); }
        if (said) { M.say(page.querySelector(saidOn || '[data-fp-card="domain"]'), said); }
      });
    }
    function draw(d, renewals) {
      var acts = [];
      if (live(d)) { acts.push(B.button('sync', t('bdm_sync'), 'sig-btn--secondary')); }
      if (d.status === 'pending' || d.status === 'failed') { acts.push(B.button('process', t('bdm_process'), 'sig-btn--secondary')); }
      if (d.status === 'active') { acts.push(B.button('code', t('bdm_code'), 'sig-btn--secondary', d.locked ? {disabled: true, 'aria-describedby': 'fp-bdm-code-why'} : null)); }
      if (live(d)) { acts.push(B.button('away', t('bdm_away'), 'sig-btn--secondary fp-btn-danger-text')); }
      var head = B.card('fp-bdm-dom-h', d.name, [M.errorLine(), M.statusLine(), B.facts([[t('bdm_col_client'), [B.clientLink(D.names, d.customer_id)]], [t('bdm_col_status'), [B.statePill('domain', d.status)]],
        [t('bdm_col_registrar'), d.registrar ? B.word('registrar', d.registrar) : ''], [t('bdm_registered'), d.registered_on ? B.day(d.registered_on) : ''], [t('bdm_col_expires'), d.expires_on ? B.day(d.expires_on) : ''],
        [t('bdm_col_auto_renew'), t(d.auto_renew ? 'bil_yes' : 'bil_no')], [t('bdm_locked'), t(d.locked ? 'bil_yes' : 'bil_no')], [t('bdm_privacy'), t(d.privacy ? 'bil_yes' : 'bil_no')],
        d.invoice_id ? [t('bdm_invoice'), [FP.tools.billing_invoices ? B.button('open-invoice', t('binv_invoice_ref', {id: String(d.invoice_id)}), 'sig-btn--link fp-bil-link', {'data-fp-id': String(d.invoice_id)}) : t('binv_invoice_ref', {id: String(d.invoice_id)})]] : null,
        d.last_error ? [t('bdm_last_error'), d.last_error] : null]),
        acts.length ? el('div', {class: 'fp-actions fp-bil-toolbar', 'data-fp-acts': 'domain'}, acts) : null,
        d.status === 'active' && d.locked ? el('p', {class: 'fp-muted fp-row-note', id: 'fp-bdm-code-why', text: t('bdm_code_locked')}) : null,
        el('div', {'data-fp-code': ''})], 'fp-bdm-dom', 'domain');
      B.screen(page, [B.back('to-list', t('bdm_back')), head, live(d) ? settingsCard(d) : null, live(d) ? renewCard(d) : null, renewalsCard(d, renewals)]);
    }
    function settingsCard(d) {
      var specs = [{name: 'nameservers', label: t('bdm_ns'), kind: 'textarea', rows: 3, max: 1300, hint: t('bdm_ns_hint'), wide: true},
        {name: 'locked', label: t('bdm_lock'), kind: 'check', hint: t('bdm_lock_hint')}, {name: 'privacy', label: t('bdm_privacy_f'), kind: 'check', hint: t('bdm_privacy_hint')},
        {name: 'auto_renew', label: t('bdm_auto_renew_f'), kind: 'check', hint: t('bdm_auto_renew_hint')}];
      var v = {nameservers: d.nameservers.join('\n'), locked: d.locked, privacy: d.privacy, auto_renew: d.auto_renew};
      var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bil_save_changes')});
      var form = el('form', {class: 'fp-form fp-bil-crud-form', novalidate: '', 'aria-labelledby': 'fp-bdm-set-h'}, [M.errorLine(), M.statusLine(),
        d.status === 'expired' ? el('p', {class: 'fp-muted fp-row-note', text: t('bdm_set_expired')}) : null,
        el('div', {class: 'fp-bil-grid'}, B.fieldsOf('fp-bdm-s', specs, v)), el('div', {class: 'fp-actions'}, [save])]);
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!B.begin(form, save)) { return; }
        var body = B.readFields(form, specs, v);
        if (!body) { return; }
        if (body.nameservers !== undefined) { body.nameservers = body.nameservers.split('\n').map(function (n) { return n.trim().toLowerCase(); }).filter(Boolean); }
        if (!Object.keys(body).length) { M.say(form, t('bil_nothing_changed')); return; }
        UI.setBusy(save, true);
        FP.call('patch', 'billingDomain', body, {id: String(d.id)}).then(function () {
          if (alive()) { show(d.id, '#fp-bdm-set-h', t('bdm_set_saved'), '.fp-bdm-set'); }
        }, function (err) {
          if (!alive()) { return; }
          UI.setBusy(save, false);
          B.failed(form, err);
        });
      });
      return B.card('fp-bdm-set-h', t('bdm_set_title'), [el('p', {class: 'fp-muted', text: t('bdm_set_what')}), form], 'fp-bdm-set', 'settings');
    }
    function renewCard(d) {
      var years = B.select('fp-bdm-years', 'years', [1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(function (n) { return [String(n), n === 1 ? t('bdm_years_1') : t('bdm_years_n', {n: String(n)})]; }), '1');
      var go = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bdm_renew')});
      var form = el('form', {class: 'fp-form fp-bdm-renew-form', novalidate: '', 'aria-labelledby': 'fp-bdm-renew-h'}, [M.errorLine(), M.statusLine(),
        el('div', {class: 'fp-bil-grid'}, [M.field('fp-bdm-years', t('bdm_years'), years, t('bdm_years_hint'))]), el('div', {class: 'fp-actions', 'data-fp-acts': 'renew'}, [go])]);
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!B.begin(form, go)) { return; }
        var n = Number(years.value);
        M.confirmIn(form.querySelector('[data-fp-acts="renew"]'), n === 1 ? t('bdm_renew_ask_1', {name: d.name}) : t('bdm_renew_ask', {name: d.name, n: String(n)}), 'renew-yes', t('bdm_renew_yes'));
        /* the years asked about are the years renewed, whatever the field says by the time of Yes */
        form.querySelector('[data-fp-act="renew-yes"]').setAttribute('data-fp-years', String(n));
      });
      return B.card('fp-bdm-renew-h', t('bdm_renew_title'), [el('p', {class: 'fp-muted', text: t('bdm_renew_what')}), form], 'fp-bdm-renew', 'renew');
    }
    function renewalsCard(d, list) {
      var parts = [M.errorLine(), M.statusLine()];
      if (list === null) {
        parts.push(el('p', {class: 'fp-muted', text: t('bdm_rn_unread')}));
      } else if (!list.length) {
        parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('bdm_rn_none')}));
      } else {
        parts.push(B.table('fp-bdm-rn-h', 'fp-bdm-rn-table', [B.th(t('bdm_rn_col_made')), B.th(t('bdm_rn_col_years'), 'fp-bil-num'), B.th(t('bdm_invoice')), B.th(t('bdm_col_status')),
          B.th(t('bdm_last_error')), el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('acct_actions')})])], list.map(function (r) {
          return el('tr', {'data-fp-renewal': String(r.id)}, [el('td', {class: 'fp-bil-nowrap', text: B.when(r.created) || '—'}), el('td', {class: 'fp-bil-num', text: r.years === null ? '—' : B.num(r.years)}),
            el('td', {text: r.invoice_id ? t('binv_invoice_ref', {id: String(r.invoice_id)}) : '—'}), el('td', {text: t('bdm_rn_' + (r.status || 'pending'))}),
            el('td', {class: 'fp-bil-wrap', text: r.last_error || '—'}),
            el('td', {class: 'fp-bil-acts'}, r.status === 'pending' || r.status === 'failed' ? [B.button('renewal-process', t('bdm_process'), 'sig-btn--secondary sig-btn--sm', {'data-fp-id': String(r.id), 'aria-label': t('bdm_rn_process_of', {id: String(r.id)})})] : [])]);
        })));
      }
      return B.card('fp-bdm-rn-h', t('bdm_rn_title'), parts, 'fp-bdm-rn', 'renewals');
    }
    function act(b, call, body, arg, said, focus, saidOn, card) {
      UI.setBusy(b, true);
      var box = page.querySelector(card || '[data-fp-card="domain"]');
      UI.showError(box, '');
      return FP.call('post', call, body || {}, arg).then(function (r) {
        if (!alive()) { return; }
        return show(D.domain.id, focus, typeof said === 'function' ? said(r) : said, saidOn);
      }, function (err) {
        if (!alive()) { return; }
        UI.setBusy(b, false);
        UI.showError(box, err.message);
        b.focus();
      });
    }
    function restoreActs() {
      if (D.domain) { show(D.domain.id, '[data-fp-act="away"]'); }
    }
    page.addEventListener('click', function (e) {
      var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
      if (!b || b.disabled || !alive()) { return; }
      var a = b.getAttribute('data-fp-act');
      var xid = Number(b.getAttribute('data-fp-id')) || 0;
      var d = D.domain;
      var arg = d ? {id: String(d.id)} : null;
      if (a === 'open' && xid) {
        UI.setBusy(b, true);
        show(xid).catch(function (err) {
          if (!alive()) { return; }
          UI.setBusy(b, false);
          L.error(err);
          b.focus();
        });
      } else if (a === 'to-list') {
        var from = page.getAttribute('data-fp-from');
        D.domain = null;
        L.show(from ? '[data-fp-act="open"][data-fp-id="' + from + '"]' : '#fp-bdm-list-h');
      } else if (a === 'open-client' && xid) {
        B.go('billing_clients', {client: xid});
      } else if (a === 'open-invoice' && xid) {
        B.go('billing_invoices', {invoice: xid});
      } else if (a === 'sync') {
        act(b, 'billingDomainSync', {}, arg, t('bdm_synced'), '[data-fp-act="sync"]');
      } else if (a === 'process') {
        act(b, 'billingDomainProcess', {}, arg, function (r) { var x = cleanDomain(r); return t('bdm_processed', {status: B.word('domain', x ? x.status : '')}); }, '#fp-bdm-dom-h');
      } else if (a === 'code') {
        UI.setBusy(b, true);
        UI.showError(page.querySelector('[data-fp-card="domain"]'), '');
        FP.call('post', 'billingDomainCode', {}, arg).then(function (r) {
          if (!alive()) { return; }
          UI.setBusy(b, false);
          var box = page.querySelector('[data-fp-code]');
          box.textContent = '';
          var code = B.str(r && r.auth_code, 64);
          box.appendChild(el('p', {class: 'fp-bdm-code', role: 'status'}, [el('span', {text: t('bdm_code_is') + ' '}), el('code', {text: code, 'data-fp-auth': ''})]));
          box.appendChild(el('p', {class: 'fp-muted fp-row-note', text: t('bdm_code_note')}));
        }, function (err) {
          if (!alive()) { return; }
          UI.setBusy(b, false);
          UI.showError(page.querySelector('[data-fp-card="domain"]'), err.message);
          b.focus();
        });
      } else if (a === 'away') {
        M.confirmIn(b.closest('[data-fp-acts]'), t('bdm_away_ask', {name: d.name}), 'away-yes', t('bdm_away_yes'));
      } else if (a === 'away-yes') {
        act(b, 'billingDomainAway', {}, arg, t('bdm_away_done', {name: d.name}), '#fp-bdm-dom-h');
      } else if (a === 'renew-yes') {
        var years = Number(b.getAttribute('data-fp-years')) || 1;
        act(b, 'billingDomainRenew', {years: years}, arg, function (r) { var inv = B.id(r && r.invoice_id); return inv ? t('bdm_renew_done_inv', {id: String(inv)}) : t('bdm_renew_done'); },
          '#fp-bdm-rn-h', '.fp-bdm-rn', '[data-fp-card="renew"]');
      } else if (a === 'renewal-process' && xid) {
        act(b, 'billingDomainRenewalProcess', {}, {id: String(d.id), renewal: String(xid)}, t('bdm_rn_processed'), '#fp-bdm-rn-h', '.fp-bdm-rn', '[data-fp-card="renewals"]');
      } else if (a === 'confirm-no' && b.closest('[data-fp-acts]')) {
        var box = b.closest('[data-fp-acts]');
        if (box.getAttribute('data-fp-acts') === 'renew') {
          box.textContent = '';
          var again = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bdm_renew')});
          box.appendChild(again);
          again.focus();
        } else {
          restoreActs();
        }
      }
    });
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    var handed = B.take('billing_domains');
    if (handed && handed.domain) {
      show(handed.domain).catch(function () { L.show(); });
    } else {
      L.show();
    }
  });
})();

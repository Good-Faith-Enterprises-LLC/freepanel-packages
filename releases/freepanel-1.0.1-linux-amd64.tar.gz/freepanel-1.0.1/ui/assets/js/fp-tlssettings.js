/* freePanel TLS settings (docs/api.md, "Server", GET and PUT /server/tls): the admin panel's page (#/tool/server_tls) for the oldest TLS version
   and the ciphers the web server (Apache) and mail (Postfix and Dovecot, the server side only) accept. A setting only narrows what the system
   allows: nothing older than TLS 1.2 can be chosen. Each service is saved on its own and only that service is sent; the service's own check runs
   before it is reloaded and the old setting stays if it refuses. Admin only: the server refuses these calls to anyone else. Everything the server
   sends is shown as text. The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var PROTOCOLS = ['system', '1.2', '1.3'];
  var CIPHERS = ['system', 'strong'];
  var SERVICES = ['web', 'mail'];

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  function service(v) {
    v = v && typeof v === 'object' ? v : {};
    return {protocol: PROTOCOLS.indexOf(v.protocol) >= 0 ? v.protocol : 'system', ciphers: CIPHERS.indexOf(v.ciphers) >= 0 ? v.ciphers : 'system',
      available: v.available === true, reason: str(v.reason, 400), drift: v.drift === true};
  }
  function clean(v) {
    v = v && typeof v === 'object' ? v : {};
    return {web: service(v.web), mail: service(v.mail)};
  }

  var T = {page: null, S: null, busy: false};

  function nowText(s) {
    return t('stl_now', {protocol: t('stl_protocol_' + s.protocol.replace('.', '_') + '_short'), ciphers: t('stl_ciphers_' + s.ciphers + '_short')});
  }
  function choice(id, name, value, current, label, hint) {
    return el('div', {class: 'fp-stl-choice'}, [el('label', {class: 'fp-check', for: id}, [
      el('input', {type: 'radio', id: id, name: name, value: value, checked: value === current ? true : null, 'aria-describedby': id + '-hint'}), el('span', {text: label})]),
    el('span', {class: 'sig-hint', id: id + '-hint', text: hint})]);
  }
  function serviceForm(key, s) {
    var form = el('form', {class: 'fp-form fp-stl-form', novalidate: '', 'data-fp-service': key}, [M.errorLine(), M.statusLine(),
      el('fieldset', {class: 'fp-stl-set'}, [el('legend', {class: 'sig-label', text: t('stl_protocol')})].concat(PROTOCOLS.map(function (p) {
        var k = p.replace('.', '_');
        return choice('fp-stl-' + key + '-p-' + k, 'protocol', p, s.protocol, t('stl_protocol_' + k), t('stl_protocol_' + k + '_hint'));
      }))),
      el('fieldset', {class: 'fp-stl-set'}, [el('legend', {class: 'sig-label', text: t('stl_ciphers')})].concat(CIPHERS.map(function (c) {
        return choice('fp-stl-' + key + '-c-' + c, 'ciphers', c, s.ciphers, t('stl_ciphers_' + c), t('stl_ciphers_' + c + '_hint'));
      }))),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('stl_save_' + key)})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || T.busy) { return; }
      var body = {};
      body[key] = {protocol: form.querySelector('[name="protocol"]:checked').value, ciphers: form.querySelector('[name="ciphers"]:checked').value};
      T.busy = true;
      UI.setBusy(b, true);
      var mine = T.page;
      FP.call('put', 'serverTls', body).then(function (r) {
        T.busy = false;
        if (T.page !== mine) { return; }
        T.S = clean(r);
        var unsaved = unsavedEdits(key);
        render();
        restoreEdits(unsaved);
        M.say(T.page.querySelector('[data-fp-card="' + key + '"]'), t('stl_saved_' + key));
        var next = T.page.querySelector('[data-fp-card="' + key + '"] input[name="protocol"]:checked') || T.page.querySelector('#fp-stl-' + key + '-h');
        if (next) { next.focus(); }
      }, function (err) {
        T.busy = false;
        if (T.page !== mine) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return form;
  }
  // What is picked in the other service's form but not saved yet. A save draws both cards again from the server's answer, which would put
  // the other card back to what is saved; this keeps the pick, so saving one service never undoes an edit in the other.
  function unsavedEdits(saved) {
    var out = {};
    SERVICES.forEach(function (k) {
      var form = k === saved ? null : T.page.querySelector('[data-fp-service="' + k + '"]');
      var p = form && form.querySelector('[name="protocol"]:checked');
      var c = form && form.querySelector('[name="ciphers"]:checked');
      if (p && c) { out[k] = {protocol: p.value, ciphers: c.value}; }
    });
    return out;
  }
  function restoreEdits(edits) {
    Object.keys(edits).forEach(function (k) {
      var form = T.page.querySelector('[data-fp-service="' + k + '"]');
      if (!form) { return; }
      ['protocol', 'ciphers'].forEach(function (name) {
        var input = form.querySelector('[name="' + name + '"][value="' + edits[k][name] + '"]');
        if (input) { input.checked = true; }
      });
    });
  }
  function card(key) {
    var s = T.S[key];
    var parts = [];
    if (!s.available) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-unavailable': key}, [UI.icon(FP.ui, 'ui_warning'),
        el('span', {text: t('stl_unavailable', {reason: s.reason || t('stl_no_reason')})})]));
    } else {
      parts.push(el('p', {class: 'fp-stl-now', 'data-fp-now': key}, [el('span', {class: 'sig-pill' + (s.protocol !== 'system' || s.ciphers !== 'system' ? ' sig-pill--accent' : ''),
        text: s.protocol !== 'system' || s.ciphers !== 'system' ? t('stl_pill_set') : t('stl_pill_system')}), ' ', el('span', {text: nowText(s)})]));
      if (s.drift) {
        parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-drift': key}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('stl_drift')})]));
      }
      parts.push(serviceForm(key, s));
    }
    var c = M.card('fp-stl-' + key + '-h', t('stl_title_' + key), [el('p', {class: 'fp-muted', text: t('stl_what_' + key)})].concat(parts), 'fp-stl-card');
    c.setAttribute('data-fp-card', key);
    return c;
  }
  function render() {
    T.page.textContent = '';
    T.page.appendChild(M.card('fp-stl-intro-h', t('stl_intro_title'), [el('p', {class: 'fp-muted', text: t('stl_intro_1')}), el('p', {class: 'fp-muted', text: t('stl_intro_2')})], 'fp-stl-intro'));
    SERVICES.forEach(function (k) { T.page.appendChild(card(k)); });
  }

  FP.view('tool:server_tls', function () {
    var tool = FP.tools.server_tls;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    T.S = null;
    T.busy = false;
    var body = FP.frame({title: tool.label, desc: t('stl_desc'), cls: 'fp-mail fp-srv fp-stl-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    T.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'serverTls').then(function (r) {
      if (T.page !== body) { return; }
      T.S = clean(r);
      render();
    }, function (err) {
      if (T.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

/* freePanel DNSSEC (docs/api.md, "DNS zones", DNSSEC). The customer's page (#/tool/dnssec) signs one of the account's zones, shows the DS
   records to give the registrar and whether the registrar has one of them, lists the signing keys, rolls a key in steps that wait, and stops
   signing without breaking the domain: while the registrar still holds a DS record the page says so and asks before it goes ahead.
   What the server sends is cleaned to the shapes drawn here and shown as text. Page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var ZONE_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var HEX_RE = /^[0-9a-fA-F]{8,200}$/;
  var ALGS = ['ecdsa256', 'ecdsa384', 'ed25519', 'rsa2048'];
  var PARENT = ['none', 'missing', 'published', 'mismatch', 'orphan', 'unknown'];
  var KINDS = ['ksk', 'zsk', 'csk'];

  function obj(v) { return v && typeof v === 'object' ? v : {}; }
  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 400) : ''; }
  function whole(v) { return typeof v === 'number' && isFinite(v) && v >= 0 && v === Math.floor(v) ? v : 0; }
  function date(iso) {
    var d = iso ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString(undefined, {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }
  function pill(text, kind) { return el('span', {class: 'sig-pill' + (kind ? ' sig-pill--' + kind : ''), text: text}); }
  function warn(text, attrs) {
    return el('div', Object.assign({class: 'sig-banner sig-banner--warn', role: 'note'}, attrs || {}), [UI.icon(FP.ui, 'ui_warning'), el('span', {text: text})]);
  }
  function algName(a) { return ALGS.indexOf(a) >= 0 ? t('dsec_alg_' + a) : str(a, 20).toUpperCase(); }
  function digestName(n) { return n === 2 ? 'SHA-256' : (n === 4 ? 'SHA-384' : t('dsec_digest_other', {n: n})); }

  /* ---- what the server sends, cleaned ---- */
  function cleanZones(v) {
    return (v && Array.isArray(v.zones) ? v.zones : []).filter(function (z) { return z && ZONE_RE.test(str(z.zone)); }).map(function (z) {
      return {zone: z.zone, primary: z.primary === true};
    }).sort(function (a, b) { return (b.primary - a.primary) || (a.zone < b.zone ? -1 : 1); });
  }
  function cleanDnssec(r) {
    r = obj(r);
    var keys = (Array.isArray(r.keys) ? r.keys : []).map(function (k) {
      k = obj(k);
      return whole(k.id) ? {id: k.id, kind: KINDS.indexOf(k.kind) >= 0 ? k.kind : 'zsk', algorithm: str(k.algorithm, 20), bits: whole(k.bits), tag: whole(k.tag),
        active: k.active === true, published: k.published === true} : null;
    }).filter(Boolean).slice(0, 20);
    var ds = (Array.isArray(r.ds) ? r.ds : []).map(function (d) {
      d = obj(d);
      if (!HEX_RE.test(str(d.digest, 200))) { return null; }
      return {tag: whole(d.tag), algorithm: whole(d.algorithm), digestType: whole(d.digest_type), digest: d.digest, value: str(d.value, 400), keyId: whole(d.key_id)};
    }).filter(Boolean).slice(0, 10);
    var p = obj(r.parent);
    var ro = r.rollover && typeof r.rollover === 'object' ? r.rollover : null;
    return {zone: str(r.zone, 253), available: r.available === true, reason: str(r.reason), enabled: r.enabled === true, algorithm: str(r.algorithm, 20), nsec3: r.nsec3 === true,
      keys: keys, ds: ds,
      parent: {state: PARENT.indexOf(p.state) >= 0 ? p.state : 'unknown', checked: str(p.checked, 40), error: str(p.error, 300)},
      rollover: ro && (ro.kind === 'zsk' || ro.kind === 'ksk') ? {kind: ro.kind, phase: ro.phase === 'switched' ? 'switched' : 'published', started: str(ro.started, 40),
        oldKey: whole(ro.old_key), newKey: whole(ro.new_key), due: str(ro.can_advance_at, 40), waitsForParent: ro.waiting === 'parent'} : null,
      warnings: (Array.isArray(r.warnings) ? r.warnings : []).filter(function (w) { return typeof w === 'string' && w; }).slice(0, 8).map(function (w) { return w.slice(0, 400); })};
  }

  /* rev counts the answers that changed the zone (sign, stop, replace a key). A read that was sent before one of them and comes back after it
     is stale and is dropped: it must not show a signed zone that has just been stopped. */
  var Z = {page: null, account: '', zones: [], cur: '', data: null, copied: '', rev: 0};
  function changed(r) { Z.data = cleanDnssec(r); Z.rev++; }
  /* The answer to a change (sign, stop, replace a key) carries the zone's keys and DS records but not what the registrar holds or the warnings: only
     a read does. So after a change the zone is read again, and the page is drawn from that; if the read fails the change's own answer is drawn. */
  function applied(zone, r, done) {
    changed(r);
    var rev = Z.rev;
    var own = Z.data.warnings;
    var finish = function (fresh) {
      if (Z.cur !== zone || Z.rev !== rev) { return; }
      if (fresh) {
        Z.data = cleanDnssec(fresh);
        /* A stop that could not ask the registrar says so in its own answer (make sure the record is removed there). When the read could not
           ask either, it has no word of that, so the change's words stay with it. */
        if (Z.data.parent.state === 'unknown') { own.forEach(function (w) { if (Z.data.warnings.indexOf(w) < 0) { Z.data.warnings.push(w); } }); }
      }
      done();
    };
    FP.call('get', 'acctDnssec', undefined, {name: Z.account, zone: zone}).then(finish, function () { finish(null); });
  }

  function holdsDs(d) { return d.parent.state === 'published' || d.parent.state === 'mismatch'; }
  function sectionBase() { return Z.page.querySelector('.fp-dsec-body'); }

  /* ---- the zone ---- */
  function pickCard() {
    var pick = el('select', {class: 'sig-select', id: 'fp-dsec-zone', name: 'zone'}, Z.zones.map(function (z) {
      return el('option', {value: z.zone, text: z.primary ? t('dsec_zone_main', {zone: z.zone}) : z.zone});
    }));
    pick.value = Z.cur;
    pick.addEventListener('change', function () { open(pick.value); });
    return el('section', {class: 'sig-card fp-mail-card fp-dsec-pick', 'aria-label': t('dsec_zone')}, [el('div', {class: 'sig-card-body'}, [M.field('fp-dsec-zone', t('dsec_zone'), pick)])]);
  }

  /* ---- signing, and the way back ---- */
  function parentLine(d) {
    var p = d.parent;
    var words = t('dsec_parent_' + p.state) + (p.state === 'unknown' && p.error ? ' ' + p.error : '');
    var kind = p.state === 'published' ? 'ok' : (p.state === 'orphan' || p.state === 'mismatch' ? 'danger' : (p.state === 'missing' ? 'accent' : ''));
    return el('p', {class: 'fp-dsec-parent', 'data-fp-parent': p.state}, [pill(t('dsec_pill_' + p.state), kind), el('span', {text: words + (p.checked ? ' ' + t('dsec_checked', {when: date(p.checked)}) : '')})]);
  }
  function signForm() {
    var alg = el('select', {class: 'sig-select', id: 'fp-dsec-alg', name: 'algorithm'}, ALGS.map(function (a) { return el('option', {value: a, text: t('dsec_alg_' + a) + (a === 'ecdsa256' ? t('dsec_alg_default') : '')}); }));
    var nsec3 = el('input', {type: 'checkbox', id: 'fp-dsec-nsec3', name: 'nsec3', 'aria-describedby': 'fp-dsec-nsec3-hint'});
    var form = el('form', {class: 'fp-form fp-mail-form fp-dsec-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-dsec-alg', t('dsec_alg'), alg, t('dsec_alg_hint')),
      el('div', null, [el('label', {class: 'fp-check', for: 'fp-dsec-nsec3'}, [nsec3, el('span', {text: t('dsec_nsec3')})]), el('span', {class: 'sig-hint', id: 'fp-dsec-nsec3-hint', text: t('dsec_nsec3_hint')})]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('dsec_sign')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var mine = Z.data;
      var zone = Z.cur;
      UI.setBusy(b, true);
      FP.call('put', 'acctDnssec', {algorithm: alg.value, nsec3: nsec3.checked}, {name: Z.account, zone: zone}).then(function (r) {
        if (Z.cur !== zone || Z.data !== mine) { return; }
        applied(zone, r, function () {
          draw('#fp-dsec-main-h');
          M.say(Z.page.querySelector('.fp-dsec-main'), t('dsec_signed_now'));
        });
      }, function (err) {
        if (Z.cur !== zone) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return form;
  }
  function warningList(d) {
    return el('ul', {class: 'fp-dsec-warnings', 'data-fp-dsec-warnings': ''}, d.warnings.map(function (w) { return el('li', {text: w}); }));
  }
  function mainCard() {
    var d = Z.data;
    var parts = [el('p', {class: 'fp-muted', text: t('dsec_what')})];
    if (!d.available || d.enabled) { parts.push(M.errorLine(), M.statusLine()); }
    if (!d.available) {
      parts.push(warn(d.reason || t('dsec_unavailable'), {'data-fp-dsec-note': 'unavailable'}));
    } else if (!d.enabled) {
      parts.push(el('p', {'data-fp-dsec-state': 'off', text: t('dsec_off', {zone: Z.cur})}));
      if (d.parent.state === 'orphan') { parts.push(warn(t('dsec_orphan'), {'data-fp-dsec-note': 'orphan'})); }
      /* what the server says about a stopped zone (the registrar could not be asked); a record the registrar still holds has the note above */
      if (d.warnings.length && d.parent.state !== 'orphan') { parts.push(warningList(d)); }
      parts.push(signForm());
    } else {
      parts.push(el('p', {'data-fp-dsec-state': 'on', text: t(d.nsec3 ? 'dsec_on_nsec3' : 'dsec_on', {zone: Z.cur, alg: algName(d.algorithm)})}));
      if (d.warnings.length) { parts.push(warningList(d)); }
      parts.push(el('div', {class: 'fp-actions fp-dsec-stop'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'stop', text: t('dsec_stop')})]));
    }
    return M.card('fp-dsec-main-h', t('dsec_title', {zone: Z.cur}), parts, 'fp-dsec-main');
  }
  function stopAsk(b) {
    var d = Z.data;
    var question = holdsDs(d) ? t('dsec_stop_ask_held', {zone: Z.cur}) : (d.parent.state === 'unknown' ? t('dsec_stop_ask_unknown', {zone: Z.cur}) : t('dsec_stop_ask', {zone: Z.cur}));
    M.confirmIn(b.parentNode, question, 'stop-yes', t(holdsDs(d) ? 'dsec_stop_anyway' : 'dsec_stop_yes'));
  }
  function stop(b) {
    var zone = Z.cur;
    var force = holdsDs(Z.data);
    var card = Z.page.querySelector('.fp-dsec-main');
    UI.showError(card, '');
    M.say(card, '');
    UI.setBusy(b, true);
    FP.call('del', force ? 'acctDnssecOff' : 'acctDnssec', undefined, {name: Z.account, zone: zone}).then(function (r) {
      if (Z.cur !== zone) { return; }
      applied(zone, r, function () {
        draw('#fp-dsec-main-h');
        M.say(Z.page.querySelector('.fp-dsec-main'), t(Z.data.parent.state === 'orphan' ? 'dsec_stopped_orphan' : 'dsec_stopped'));
      });
    }, function (err) {
      if (Z.cur !== zone) { return; }
      redrawMain();
      UI.showError(Z.page.querySelector('.fp-dsec-main'), err.message);
      var again = Z.page.querySelector('.fp-dsec-main [data-fp-act="stop"]');
      if (again) { again.focus(); }
    });
  }

  /* ---- the DS records for the registrar, and what the registrar holds ---- */
  function keyNote(d, row) {
    if (!d.rollover || d.rollover.kind !== 'ksk') { return null; }
    if (row.keyId === d.rollover.newKey) { return pill(t('dsec_key_new'), 'accent'); }
    return row.keyId === d.rollover.oldKey ? pill(t('dsec_key_old'), '') : null;
  }
  function dsCard() {
    var d = Z.data;
    var rows = d.ds.map(function (r, i) {
      return el('tr', {'data-fp-ds': String(i)}, [el('th', {scope: 'row', class: 'fp-dsec-tag', text: String(r.tag)}), el('td', {text: String(r.algorithm)}),
        el('td', null, [el('span', {text: digestName(r.digestType)}), keyNote(d, r) ? el('span', {class: 'fp-dsec-pill'}, [keyNote(d, r)]) : null]),
        el('td', {class: 'fp-dsec-digest sig-mono', text: r.digest}),
        el('td', {class: 'fp-mail-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'copy', 'data-fp-copy': r.value || [r.tag, r.algorithm, r.digestType, r.digest].join(' '),
          'aria-label': t('dsec_copy_named', {tag: r.tag, digest: digestName(r.digestType)}), text: t('dsec_copy')})])]);
    });
    var parts = [el('p', {class: 'fp-muted', text: t('dsec_ds_what')}), M.errorLine(), M.statusLine()];
    if (rows.length) {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-dsec-ds-h'}, [el('table', {class: 'sig-table fp-mail-table fp-dsec-table'}, [
        el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('dsec_col_tag')}), el('th', {scope: 'col', text: t('dsec_col_alg')}), el('th', {scope: 'col', text: t('dsec_col_digest_type')}),
          el('th', {scope: 'col', text: t('dsec_col_digest')}), el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]), el('tbody', null, rows)])]));
    } else {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('dsec_ds_none')}));
    }
    parts.push(parentLine(d), el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'check', text: t('dsec_check')})]));
    return M.card('fp-dsec-ds-h', t('dsec_ds_title'), parts, 'fp-dsec-ds');
  }
  function check(b) {
    var zone = Z.cur;
    var rev = Z.rev;
    var card = Z.page.querySelector('.fp-dsec-ds');
    UI.showError(card, '');
    M.say(card, '');
    UI.setBusy(b, true);
    FP.call('get', 'acctDnssec', undefined, {name: Z.account, zone: zone}).then(function (r) {
      if (Z.cur !== zone || Z.rev !== rev) { return; }
      Z.data = cleanDnssec(r);
      draw();
      M.say(Z.page.querySelector('.fp-dsec-ds'), t('dsec_checked_now'));
      var again = Z.page.querySelector('.fp-dsec-ds [data-fp-act="check"]');
      if (again) { again.focus(); }
    }, function (err) {
      if (Z.cur !== zone || Z.rev !== rev) { return; }
      UI.setBusy(b, false);
      UI.showError(card, err.message);
      b.focus();
    });
  }
  function copy(b) {
    var card = b.closest('.fp-dsec-ds');
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(b.getAttribute('data-fp-copy')).then(function () { M.say(card, t('copied')); }, function () { M.say(card, t('copy_failed')); });
    } else {
      M.say(card, t('copy_failed'));
    }
  }

  /* ---- the keys ---- */
  function keysCard() {
    var d = Z.data;
    var rows = d.keys.map(function (k) {
      var state = k.active ? t('dsec_key_active') : (k.published ? t('dsec_key_published') : t('dsec_key_inactive'));
      return el('tr', {'data-fp-key': String(k.id)}, [el('th', {scope: 'row', text: t('dsec_kind_' + k.kind)}), el('td', {text: algName(k.algorithm) + (k.bits ? ' (' + k.bits + ')' : '')}),
        el('td', {class: 'sig-mono', text: String(k.tag)}), el('td', null, [pill(state, k.active ? 'ok' : '')])]);
    });
    return M.card('fp-dsec-keys-h', t('dsec_keys_title'), [el('p', {class: 'fp-muted', text: t('dsec_keys_what')}),
      el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-dsec-keys-h'}, [el('table', {class: 'sig-table fp-mail-table fp-dsec-keys'}, [
        el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('dsec_col_key')}), el('th', {scope: 'col', text: t('dsec_col_alg')}), el('th', {scope: 'col', text: t('dsec_col_tag')}),
          el('th', {scope: 'col', text: t('dsec_col_state')})])]), el('tbody', null, rows)])])], 'fp-dsec-keys');
  }

  /* ---- rolling a key ---- */
  function rolloverCard() {
    var d = Z.data;
    var ro = d.rollover;
    var parts = [M.errorLine(), M.statusLine()];
    if (!ro) {
      parts.push(el('p', {class: 'fp-muted', text: t('dsec_roll_what')}),
        el('div', {class: 'fp-actions fp-dsec-roll'}, [
          el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'roll-zsk', text: t('dsec_roll_zsk')}),
          el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'roll-ksk', text: t('dsec_roll_ksk')})]),
        el('p', {class: 'fp-muted', text: t('dsec_roll_ksk_hint')}));
    } else {
      var due = ro.due ? new Date(ro.due) : null;
      var early = due && !isNaN(due.getTime()) && due.getTime() > Date.now();
      parts.push(el('p', {class: 'fp-dsec-now', 'data-fp-roll': ro.kind + ' ' + ro.phase, text: t('dsec_roll_on', {kind: t('dsec_roll_kind_' + ro.kind), when: date(ro.started) || '—'})}),
        el('p', {text: t('dsec_roll_step_' + ro.kind + '_' + ro.phase)}));
      if (ro.waitsForParent) { parts.push(el('p', {class: 'fp-muted', text: t('dsec_roll_parent')})); }
      parts.push(el('p', {class: 'fp-muted', 'data-fp-roll-due': early ? 'later' : 'now', text: early ? t('dsec_roll_due', {when: date(ro.due)}) : t('dsec_roll_due_now')}),
        el('div', {class: 'fp-actions fp-dsec-roll'}, [
          el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'next', text: t('dsec_roll_next')}),
          el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'next-force', text: t('dsec_roll_force')})]));
    }
    return M.card('fp-dsec-roll-h', t('dsec_roll_title'), parts, 'fp-dsec-rollover');
  }
  function roll(b, body, done) {
    var zone = Z.cur;
    var card = Z.page.querySelector('.fp-dsec-rollover');
    UI.showError(card, '');
    M.say(card, '');
    UI.setBusy(b, true);
    FP.call('post', 'acctDnssecRollover', body, {name: Z.account, zone: zone}).then(function (r) {
      if (Z.cur !== zone) { return; }
      applied(zone, r, function () {
        draw('#fp-dsec-roll-h');
        M.say(Z.page.querySelector('.fp-dsec-rollover'), t(done));
      });
    }, function (err) {
      if (Z.cur !== zone) { return; }
      redrawRollover();
      UI.showError(Z.page.querySelector('.fp-dsec-rollover'), err.message);
    });
  }

  /* ---- the page ---- */
  function cards() {
    var out = [mainCard()];
    if (Z.data.available && Z.data.enabled) { out.push(dsCard(), keysCard(), rolloverCard()); }
    return out;
  }
  function draw(focus) {
    var body = sectionBase();
    body.textContent = '';
    cards().forEach(function (c) { body.appendChild(c); });
    var target = focus ? body.querySelector(focus) : null;
    if (target) { target.focus(); }
  }
  function redrawMain() { var old = Z.page.querySelector('.fp-dsec-main'); if (old) { old.replaceWith(mainCard()); } }
  function redrawRollover() { var old = Z.page.querySelector('.fp-dsec-rollover'); if (old) { old.replaceWith(rolloverCard()); } }
  function open(zone) {
    Z.cur = zone;
    Z.data = null;
    /* an open is a change of what the page shows: a read of this zone that was sent before it (the page was left and opened again, or another
       zone was chosen and this one chosen back) is stale when it comes back, and is dropped */
    Z.rev++;
    var rev = Z.rev;
    var body = sectionBase();
    body.textContent = '';
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'acctDnssec', undefined, {name: Z.account, zone: zone}).then(function (r) {
      if (Z.cur !== zone || Z.rev !== rev) { return; }
      Z.data = cleanDnssec(r);
      draw();
    }, function (err) {
      if (Z.cur !== zone || Z.rev !== rev) { return; }
      body.textContent = '';
      body.appendChild(el('div', {class: 'fp-alert', role: 'alert', 'data-fp-dsec-read': '', text: err.message}));
    });
  }

  function onClick(e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !Z.page || !Z.page.contains(b) || b.disabled || !Z.data) { return; }
    var act = b.getAttribute('data-fp-act');
    if (act === 'stop') { stopAsk(b); }
    else if (act === 'stop-yes') { stop(b); }
    else if (act === 'confirm-no') {
      var card = b.closest('.sig-card');
      var kind = card && card.classList.contains('fp-dsec-rollover') ? 'rollover' : 'main';
      if (kind === 'rollover') { redrawRollover(); var n = Z.page.querySelector('[data-fp-act="next-force"]'); if (n) { n.focus(); } }
      else { redrawMain(); var s = Z.page.querySelector('.fp-dsec-main [data-fp-act="stop"]'); if (s) { s.focus(); } }
    }
    else if (act === 'copy') { copy(b); }
    else if (act === 'check') { check(b); }
    else if (act === 'roll-zsk') { roll(b, {step: 'start', kind: 'zsk'}, 'dsec_roll_started'); }
    else if (act === 'roll-ksk') { roll(b, {step: 'start', kind: 'ksk'}, 'dsec_roll_started'); }
    else if (act === 'next') { roll(b, {step: 'next', force: false}, 'dsec_roll_stepped'); }
    else if (act === 'next-force') { M.confirmIn(b.parentNode, t(Z.data.rollover && Z.data.rollover.kind === 'ksk' ? 'dsec_force_ask_ksk' : 'dsec_force_ask'), 'next-force-yes', t('dsec_force_yes')); }
    else if (act === 'next-force-yes') { roll(b, {step: 'next', force: true}, 'dsec_roll_stepped'); }
  }
  document.addEventListener('click', onClick);

  FP.view('tool:dnssec', function () {
    Z.page = null;
    var tool = FP.tools.dnssec;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('dnssec_desc'), cls: 'fp-mail fp-dsec',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    Z.page = page;
    Z.account = FP.account();
    Z.zones = [];
    Z.cur = '';
    Z.data = null;
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'accountZones', undefined, Z.account).then(function (r) {
      if (Z.page !== page) { return; }
      Z.zones = cleanZones(r);
      page.textContent = '';
      if (!Z.zones.length) { page.appendChild(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('dsec_none')})); return; }
      Z.cur = Z.zones[0].zone;
      if (Z.zones.length > 1) { page.appendChild(pickCard()); }
      page.appendChild(el('div', {class: 'fp-dsec-body'}));
      open(Z.cur);
    }, function (err) {
      if (Z.page !== page) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

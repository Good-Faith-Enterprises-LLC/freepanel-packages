/* freePanel FTP connections (#/tool/ftp_connections), the customer panel's page for the FTP sessions open on the account
   (docs/api.md, "FTP"): who is connected, since when and what they are doing, and ending one. A session is told apart by the
   account's user, not by login, so the list is of the account. Ending a session cuts the client off; it can sign in again,
   so to keep someone out the login's password is changed. What the server sends is drawn as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var ID_RE = /^\d{1,9}\.\d{1,20}$/;
  var STATES = {idle: 'fcn_state_idle', download: 'fcn_state_download', upload: 'fcn_state_upload', other: 'fcn_state_other'};
  var V = null;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 100) : ''; }
  function stamp(iso) {
    var d = typeof iso === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(iso) ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) && d.getFullYear() > 2000 ? d : null;
  }
  function clean(r) {
    if (!r || typeof r !== 'object' || !Array.isArray(r.sessions)) { return null; }
    return r.sessions.slice(0, 200).filter(function (s) { return s && typeof s === 'object' && ID_RE.test(str(s.id, 40)); }).map(function (s) {
      var ip = str(s.remote_ip, 45);
      return {id: s.id, ip: /^[0-9a-f.:]{2,45}$/i.test(ip) ? ip : '', started: stamp(s.started), state: STATES[str(s.state, 12)] ? s.state : 'other'};
    });
  }
  /* how long ago, in the biggest whole unit */
  function ago(d) {
    var s = Math.max(0, Math.round((Date.now() - d.getTime()) / 1000));
    if (s < 60) { return t('fcn_ago_s'); }
    if (s < 3600) { return t('fcn_ago_m', {n: Math.floor(s / 60)}); }
    if (s < 86400) { return t('fcn_ago_h', {n: Math.floor(s / 3600)}); }
    var days = Math.floor(s / 86400);
    return days === 1 ? t('fcn_ago_d1') : t('fcn_ago_d', {n: days});
  }

  function item(s) {
    var started = s.started ? el('span', {class: 'fp-muted', text: t('fcn_started', {when: s.started.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'}), ago: ago(s.started)})}) : null;
    var cell = el('span', {class: 'fp-fcn-act'}, [el('button', {class: 'sig-btn sig-btn--danger sig-btn--sm', type: 'button', 'data-fp-act': 'end', 'data-fp-id': s.id,
      'aria-label': t('fcn_end_label', {ip: s.ip || t('fcn_unknown')}), text: t('fcn_end')})]);
    return el('li', {class: 'fp-fcn-item', 'data-fp-session': s.id}, [
      el('span', {class: 'fp-fcn-who'}, [el('strong', {class: 'sig-mono', text: s.ip || t('fcn_unknown')}), started]),
      el('span', {class: 'sig-pill' + (s.state === 'other' || s.state === 'idle' ? '' : ' sig-pill--ok'), text: t(STATES[s.state])}), cell]);
  }
  function draw(focus) {
    V.page.textContent = '';
    var list = V.sessions.length ? el('ul', {class: 'fp-fcn-list', 'data-fp-list': ''}, V.sessions.map(item)) :
      el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('fcn_none')});
    V.page.appendChild(M.card('fp-fcn-h', t('fcn_title'), [M.errorLine(), M.statusLine(),
      el('p', {class: 'fp-muted', text: t('fcn_what')}), list,
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'refresh', text: t('fcn_refresh')})]),
      el('p', {class: 'fp-muted', text: t('fcn_note')})], 'fp-fcn'));
    var target = focus ? V.page.querySelector(focus) : null;
    if (target) { target.focus(); }
  }
  function cardEl() { return V.page.querySelector('.fp-fcn'); }
  function lock(on) {
    V.busy = on;
    var all = V.page.querySelectorAll('button');
    for (var i = 0; i < all.length; i++) { all[i].disabled = on; }
  }
  function reload(mine, then) {
    return FP.call('get', 'ftpSessions', undefined, V.account).then(function (r) {
      var list = clean(r);
      if (V !== mine) { return; }
      if (list) { V.sessions = list; }
      if (then) { then(Boolean(list)); }
    }, function (err) {
      if (V !== mine) { return; }
      if (then) { then(false, err); }
    });
  }
  function onClick(e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !V || !V.page.contains(b) || b.disabled || V.busy) { return; }
    var a = b.getAttribute('data-fp-act');
    var mine = V;
    if (a === 'refresh') {
      UI.setBusy(b, true);
      reload(mine, function (ok, err) {
        draw('[data-fp-act="refresh"]');
        if (ok) { M.say(cardEl(), t('fcn_refreshed', {n: V.sessions.length})); } else { UI.showError(cardEl(), err ? err.message : t('api_failed')); }
      });
    } else if (a === 'end') {
      V.ending = b.getAttribute('data-fp-id');
      var cell = b.closest('.fp-fcn-act');
      M.confirmIn(cell, t('fcn_ask'), 'end-yes', t('fcn_end_yes'));
    } else if (a === 'confirm-no') {
      var id = V.ending;
      V.ending = '';
      draw(id ? '[data-fp-id="' + id + '"]' : '');
    } else if (a === 'end-yes' && V.ending) {
      var sid = V.ending;
      lock(true);
      UI.setBusy(b, true);
      UI.showError(cardEl(), '');
      M.say(cardEl(), t('fcn_ending'));
      FP.call('del', 'ftpSession', undefined, {name: V.account, id: sid}).then(function (r) {
        if (V !== mine) { return; }
        var list = clean(r);
        lock(false);
        V.ending = '';
        if (list) { V.sessions = list; draw('#fp-fcn-h'); M.say(cardEl(), t('fcn_ended')); return; }
        reload(mine, function () { draw('#fp-fcn-h'); UI.showError(cardEl(), t('api_failed')); });
      }, function (err) {
        if (V !== mine) { return; }
        lock(false);
        V.ending = '';
        /* a session that is already gone, or any refusal: show what is open now, with the server's words */
        reload(mine, function () { draw('#fp-fcn-h'); UI.showError(cardEl(), err.message); });
      });
    }
  }
  document.addEventListener('click', onClick);

  FP.view('tool:ftp_connections', function () {
    var body = M.frame('ftp_connections', 'fp-fcn-page');
    if (!body) { return; }
    V = {page: body, account: FP.account(), sessions: [], busy: false, ending: ''};
    var mine = V;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'ftpSessions', undefined, V.account).then(function (r) {
      if (V !== mine) { return; }
      var list = clean(r);
      body.textContent = '';
      if (!list) { body.appendChild(FP.empty(FP.tools.ftp_connections.label, t('api_failed'))); return; }
      V.sessions = list;
      draw();
    }, function (err) {
      if (V !== mine) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(FP.tools.ftp_connections.label, err.message));
    });
  });
})();

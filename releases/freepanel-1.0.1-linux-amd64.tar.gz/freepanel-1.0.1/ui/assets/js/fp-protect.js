/* freePanel protected folders (docs/api.md, "Protected folders"): the customer panel's Protected folders page
   (#/tool/protected_folders). A folder in one of the account's sites asks visitors for a login before anything in it
   opens. The list shows each protected folder with its login prompt's name and its logins; a folder's Logins card
   changes the prompt's name and adds, changes and removes logins. A site without a certificate still asks for the
   login, but over plain HTTP, so the page names those sites wherever a login would travel unencrypted. A folder no
   site serves any more (served false) keeps its protection until it is removed. Page pieces come from FP.mail. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var PART_RE = /^[A-Za-z0-9_-][A-Za-z0-9._-]*$/;
  var MAX_LEVELS = 32;
  var NAME_RE = /^[\x20-\x7e]+$/;
  var MAX_NAME = 100;
  var LOGIN_RE = /^[A-Za-z0-9._@-]{1,64}$/;
  var MIN_PASSWORD = 12;
  var MAX_PASSWORD_BYTES = 72;
  var DOMAIN_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;

  function str(v) { return typeof v === 'string' ? v : ''; }
  function folderOK(f) {
    var parts = f.split('/');
    return parts.length <= MAX_LEVELS && parts.every(function (p) { return PART_RE.test(p); });
  }
  function nameOK(n) { return n.length >= 1 && n.length <= MAX_NAME && NAME_RE.test(n) && !/["\\]/.test(n); }
  function cleanFolders(v) {
    return (v && Array.isArray(v.folders) ? v.folders : []).filter(function (f) {
      return f && folderOK(str(f.folder)) && nameOK(str(f.name));
    }).map(function (f) {
      return {folder: f.folder, name: f.name, served: f.served !== false,
        logins: (Array.isArray(f.logins) ? f.logins : []).filter(function (l) { return LOGIN_RE.test(str(l)); }).sort()};
    }).sort(function (a, b) { return a.folder < b.folder ? -1 : (a.folder > b.folder ? 1 : 0); });
  }
  /* the account's home, worked out from its main site's docroot (public_html in it) rather than assumed: where homes
     are is the server's configuration. '' when it can't be worked out */
  function homeOf(v) {
    var main = (v && Array.isArray(v.sites) ? v.sites : []).filter(function (s) { return s && s.kind === 'main'; })[0];
    var m = main && /^(\/.+)\/public_html$/.exec(str(main.docroot));
    return m ? m[1] + '/' : '';
  }
  /* each site as the folder it serves (relative to the home, as protected folders are) and whether it has HTTPS */
  function cleanSites(v, home) {
    if (!home) { return []; }
    return (v && Array.isArray(v.sites) ? v.sites : []).filter(function (s) {
      return s && DOMAIN_RE.test(str(s.domain)) && str(s.docroot).indexOf(home) === 0 && folderOK(s.docroot.slice(home.length));
    }).map(function (s) {
      var c = s.certificate;
      return {domain: s.domain, aliases: (Array.isArray(s.aliases) ? s.aliases : []).filter(function (a) { return DOMAIN_RE.test(str(a)); }),
        folder: s.docroot.slice(home.length), secure: Boolean(c && typeof c === 'object' && c.expired === false)};
    });
  }
  function holds(site, folder) { return folder === site.folder || folder.indexOf(site.folder + '/') === 0; }
  /* the names a login to this folder would be sent over plain HTTP on */
  function plainNames(folder) {
    var out = [];
    P.sites.forEach(function (s) {
      if (!holds(s, folder) || s.secure) { return; }
      [s.domain].concat(s.aliases).forEach(function (d) { if (out.indexOf(d) < 0) { out.push(d); } });
    });
    return out.sort();
  }
  function siteFolders() {
    var out = [];
    P.sites.forEach(function (s) { if (out.indexOf(s.folder) < 0) { out.push(s.folder); } });
    return out.sort();
  }
  function folderOf(name) { return P.folders.filter(function (f) { return f.folder === name; })[0] || null; }
  function bytes(s) { return new window.TextEncoder().encode(s).length; }

  /* homeUnknown: the sites came without a main site the home can be worked out from, so which of them have a certificate is not known */
  var P = {page: null, account: '', folders: [], sites: [], homeUnknown: false, suspended: false, open: '', draft: null};

  function plainLine(folder, cls) {
    var names = plainNames(folder);
    if (!names.length) { return null; }
    return el('p', {class: cls || 'fp-warn-line fp-pf-plain', 'data-fp-pf-plain': '', text: t('pf_plain', {names: names.join(', ')})});
  }

  /* ---------- the list ---------- */
  function loginsText(f) {
    if (!f.logins.length) { return t('pf_no_logins'); }
    return t(f.logins.length === 1 ? 'pf_logins_one' : 'pf_logins_many', {n: f.logins.length, logins: f.logins.join(', ')});
  }
  function listCard() {
    var parts = [M.errorLine(), M.statusLine()];
    if (P.homeUnknown) { parts.push(el('p', {class: 'fp-warn-line', 'data-fp-pf-plain-unknown': '', text: t('pf_plain_unknown')})); }
    if (!P.folders.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('pf_none')}));
    } else {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-pf-h'}, [
        el('table', {class: 'sig-table fp-mail-table fp-pf-table'}, [el('thead', null, [el('tr', null, [
          el('th', {scope: 'col', text: t('pf_folder')}), el('th', {scope: 'col', text: t('pf_name')}),
          el('th', {scope: 'col', text: t('pf_logins')}), el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]),
        el('tbody', null, P.folders.map(function (f) {
          return el('tr', {'data-fp-folder': f.folder}, [
            el('th', {scope: 'row', class: 'fp-mail-name fp-pf-folder'}, [el('span', {class: 'sig-mono', text: f.folder}),
              f.served ? null : el('span', {class: 'fp-muted fp-row-note', text: t('pf_not_served')}),
              f.served ? plainLine(f.folder, 'fp-row-note fp-pf-plain') : null]),
            el('td', {class: 'fp-pf-name', text: f.name}),
            el('td', {class: 'fp-pf-logins' + (f.logins.length ? '' : ' fp-muted'), text: loginsText(f)}),
            el('td', {class: 'fp-mail-acts'}, [
              el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'pf-open',
                'aria-label': t('pf_open_of', {folder: f.folder}), text: t('pf_open')}),
              el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'pf-unprotect',
                'aria-label': t('pf_unprotect_of', {folder: f.folder}), text: t('pf_unprotect')})])]);
        }))])]));
    }
    return M.card('fp-pf-h', t('pf_title'), parts, 'fp-pf-list');
  }

  /* ---------- protecting a folder ---------- */
  function addCard() {
    var folders = siteFolders();
    var folder = el('input', {class: 'sig-input sig-mono', id: 'fp-pf-folder', name: 'folder', type: 'text', autocomplete: 'off', spellcheck: 'false',
      autocapitalize: 'none', placeholder: folders.length ? folders[0] + '/private' : 'public_html/private'});
    var name = el('input', {class: 'sig-input', id: 'fp-pf-name', name: 'name', type: 'text', maxlength: String(MAX_NAME), autocomplete: 'off'});
    var warn = el('p', {class: 'fp-warn-line fp-pf-plain', id: 'fp-pf-folder-plain', 'data-fp-pf-plain': '', hidden: true});
    var form = el('form', {class: 'fp-form fp-mail-form fp-pf-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-pf-folder', t('pf_folder'), folder, folders.length ? t('pf_folder_hint', {folders: folders.join(', ')}) : t(P.homeUnknown ? 'pf_folder_hint_unknown' : 'pf_folder_hint_none')),
      warn,
      M.field('fp-pf-name', t('pf_name'), name, t('pf_name_hint', {n: MAX_NAME})),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('pf_protect')})])]);
    function tidy(v) { return v.trim().replace(/^\/+|\/+$/g, ''); }
    /* says, as the folder is typed, which sites would ask for its logins over plain HTTP */
    function sync() {
      var f = tidy(folder.value);
      var names = f && folderOK(f) ? plainNames(f) : [];
      warn.hidden = !names.length;
      warn.textContent = names.length ? t('pf_plain', {names: names.join(', ')}) : '';
    }
    folder.addEventListener('input', sync);
    if (P.draft) { folder.value = P.draft.folder; name.value = P.draft.name; sync(); }
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var f = tidy(folder.value);
      var n = name.value.trim();
      if (!f) { M.fieldError(form, folder, t('pf_folder_none')); return; }
      if (!folderOK(f)) { M.fieldError(form, folder, t('pf_folder_bad', {n: MAX_LEVELS})); return; }
      /* with no home to relate the sites' folders to, the server decides whether the folder is inside one */
      if (!P.homeUnknown && !P.sites.some(function (s) { return holds(s, f); })) { M.fieldError(form, folder, t('pf_folder_outside')); return; }
      if (folderOf(f)) { M.fieldError(form, folder, t('pf_folder_already', {folder: f})); return; }
      if (!nameOK(n)) { M.fieldError(form, name, t('pf_name_bad', {n: MAX_NAME})); return; }
      UI.setBusy(b, true);
      FP.call('put', 'protectedFolders', {folder: f, protected: true, name: n}, P.account).then(function (r) {
        P.folders = cleanFolders(r);
        folder.value = name.value = '';
        P.open = f;
        render();
        M.say(logins(), t('pf_protected', {folder: f}));
        P.page.querySelector('#fp-pf-login').focus();
      }, function (err) {
        UI.setBusy(b, false);
        M.failed(form, err.field ? err : {field: err.status === 400 ? 'folder' : '', message: err.message});
      });
    });
    return M.card('fp-pf-add-h', t('pf_add_title'), [form], 'fp-pf-add');
  }

  /* ---------- one folder's prompt name and logins ---------- */
  function logins() { return P.page.querySelector('.fp-pf-open'); }
  function openCard(f) {
    var parts = [M.errorLine(), M.statusLine()];
    var plain = plainNames(f.folder);
    if (!f.served) { parts.push(el('p', {class: 'fp-muted', text: t('pf_not_served_long')})); }
    if (plain.length) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-pf-plain': ''}, [UI.icon(FP.ui, 'ui_warning'),
        el('span', {text: t('pf_plain_long', {names: plain.join(', ')})})]));
    }
    var nameInput = el('input', {class: 'sig-input', id: 'fp-pf-rename', name: 'name', type: 'text', maxlength: String(MAX_NAME), autocomplete: 'off',
      value: f.name});
    var nameForm = el('form', {class: 'fp-form fp-mail-form fp-pf-rename', novalidate: ''}, [
      M.field('fp-pf-rename', t('pf_name'), nameInput, t('pf_name_hint', {n: MAX_NAME})),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary fp-submit', type: 'submit', text: t('pf_rename')})])]);
    nameForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var card = logins();
      var b = M.start(nameForm);
      if (!b) { return; }
      UI.showError(card, '');
      var n = nameInput.value.trim();
      if (!nameOK(n)) { M.fieldError(card, nameInput, t('pf_name_bad', {n: MAX_NAME})); return; }
      UI.setBusy(b, true);
      FP.call('put', 'protectedFolders', {folder: f.folder, protected: true, name: n}, P.account).then(function (r) {
        settled(r, t('pf_renamed', {folder: f.folder}), '#fp-pf-rename');
      }, function (err) { UI.setBusy(b, false); answer(err, nameInput); });
    });
    parts.push(nameForm);

    parts.push(el('h3', {class: 'fp-h3', id: 'fp-pf-logins-h', text: t('pf_logins')}));
    if (!f.logins.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-pf-nologins': '', text: t('pf_no_logins_long')}));
    } else {
      parts.push(el('ul', {class: 'fp-pf-login-list', 'aria-labelledby': 'fp-pf-logins-h'}, f.logins.map(function (l) {
        return el('li', {'data-fp-login': l}, [el('span', {class: 'sig-mono fp-pf-login', text: l}),
          el('span', {class: 'fp-pf-login-acts'}, [
            el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'pf-password',
              'aria-label': t('pf_password_of', {login: l}), text: t('pf_password')}),
            el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'pf-login-remove',
              'aria-label': t('pf_login_remove_of', {login: l}), text: t('pf_login_remove')})])]);
      })));
    }

    var login = el('input', {class: 'sig-input sig-mono', id: 'fp-pf-login', name: 'login', type: 'text', maxlength: '64', autocomplete: 'off',
      spellcheck: 'false', autocapitalize: 'none'});
    var pw = el('input', {class: 'sig-input', id: 'fp-pf-password', name: 'password', type: 'password', autocomplete: 'new-password',
      maxlength: String(MAX_PASSWORD_BYTES), 'aria-describedby': 'fp-pf-password-hint'});
    var again = el('input', {class: 'sig-input', id: 'fp-pf-password-again', name: 'again', type: 'password', autocomplete: 'new-password',
      maxlength: String(MAX_PASSWORD_BYTES)});
    var form = el('form', {class: 'fp-form fp-mail-form fp-pf-login-form', novalidate: ''}, [
      M.field('fp-pf-login', t('pf_login'), login, t('pf_login_hint')),
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: 'fp-pf-password', text: t('label_password')}),
        el('div', {class: 'fp-reveal-wrap'}, [pw, el('button', {class: 'sig-ghost fp-reveal', type: 'button', 'data-overlap-ok': '',
          'data-fp-reveal': 'fp-pf-password,fp-pf-password-again', 'aria-pressed': 'false', 'aria-label': 'Show password'}, [UI.icon(FP.ui, 'ui_eye')])]),
        el('span', {class: 'sig-hint', id: 'fp-pf-password-hint', text: t('pf_password_hint', {min: MIN_PASSWORD, max: MAX_PASSWORD_BYTES})})]),
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: 'fp-pf-password-again', text: t('mail_password_again')}), again]),
      el('div', {class: 'fp-mail-gen'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'generate',
        'data-fp-for': 'fp-pf-password', text: t('mail_generate')})]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('pf_login_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var card = logins();
      var b = M.start(form);
      if (!b) { return; }
      UI.showError(card, '');
      var l = login.value.trim();
      if (!LOGIN_RE.test(l)) { M.fieldError(card, login, t('pf_login_bad')); return; }
      if (pw.value.length < MIN_PASSWORD || bytes(pw.value) > MAX_PASSWORD_BYTES) {
        M.fieldError(card, pw, t('pf_password_bad', {min: MIN_PASSWORD, max: MAX_PASSWORD_BYTES}));
        return;
      }
      if (pw.value !== again.value) { M.fieldError(card, again, t('mail_password_mismatch')); return; }
      var had = f.logins.indexOf(l) >= 0;
      UI.setBusy(b, true);
      FP.call('put', 'protectedLogins', {folder: f.folder, login: l, password: pw.value}, P.account).then(function (r) {
        settled(r, t(had ? 'pf_login_changed' : 'pf_login_added', {login: l, folder: f.folder}), '#fp-pf-login');
      }, function (err) { UI.setBusy(b, false); answer(err, err.field === 'login' ? login : (err.field === 'password' ? pw : null)); });
    });
    parts.push(el('h3', {class: 'fp-h3', id: 'fp-pf-login-form-h', text: t('pf_login_form_title')}));
    parts.push(el('p', {class: 'sig-hint', text: t('pf_login_form_hint')}));
    parts.push(form);
    parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'pf-close',
      text: t('pf_close')})]));
    return M.card('fp-pf-open-h', t('pf_open_title', {folder: f.folder}), parts, 'fp-pf-open');
  }
  /* a server answer on the Logins card: the line goes on the card, the field it names is marked */
  function answer(err, f) {
    var card = logins();
    if (!card) { return; }
    M.fieldError(card, f, err.message);
    if (err.status === 404) { reload(); }
  }
  /* a changed folder list from the server: redraw, say what changed on the Logins card and focus where the person was */
  function settled(r, said, focus) {
    P.folders = cleanFolders(r);
    if (!folderOf(P.open)) { P.open = ''; }
    render();
    var card = logins();
    if (card) {
      M.say(card, said);
      (card.querySelector(focus) || card.querySelector('#fp-pf-open-h')).focus();
    } else {
      M.say(P.page.querySelector('.fp-pf-list'), said);
      P.page.querySelector('#fp-pf-h').focus();
    }
  }

  /* ---------- page ---------- */
  function render() {
    var draft = P.page.querySelector('.fp-pf-form');
    if (draft) { P.draft = {folder: draft.querySelector('#fp-pf-folder').value, name: draft.querySelector('#fp-pf-name').value}; }
    P.page.textContent = '';
    if (P.suspended) { P.page.appendChild(M.suspendedBanner(t('pf_suspended'))); }
    P.page.appendChild(listCard());
    var f = folderOf(P.open);
    if (f) { P.page.appendChild(openCard(f)); }
    P.page.appendChild(addCard());
  }
  /* the list as the server has it now, after an answer that says the page was behind */
  function reload() {
    var page = P.page;
    FP.call('get', 'protectedFolders', undefined, P.account).then(function (r) {
      if (P.page !== page) { return; }
      var card = logins();
      var shown = card ? card.querySelector('[data-fp-error]').textContent : '';
      P.folders = cleanFolders(r);
      if (!folderOf(P.open)) { P.open = ''; }
      render();
      var now = logins() || P.page.querySelector('.fp-pf-list');
      if (shown) { UI.showError(now, shown); }
    }, function () {});
  }

  function onClick(e) {
    var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !P.page || !P.page.contains(b)) { return; }
    var a = b.getAttribute('data-fp-act');
    var row = b.closest('tr');
    var folder = row ? row.getAttribute('data-fp-folder') : P.open;
    var list = P.page.querySelector('.fp-pf-list');
    if (a === 'pf-open') {
      P.open = folder;
      render();
      logins().querySelector('#fp-pf-open-h').focus();
    } else if (a === 'pf-close') {
      var was = P.open;
      P.open = '';
      render();
      var back = P.page.querySelector('[data-fp-folder="' + window.CSS.escape(was) + '"] [data-fp-act="pf-open"]');
      (back || P.page.querySelector('#fp-pf-h')).focus();
    } else if (a === 'pf-unprotect') {
      M.confirmIn(b.closest('td'), t('pf_unprotect_ask', {folder: folder}), 'pf-unprotect-yes', t('pf_unprotect'));
    } else if (a === 'confirm-no' && row) {
      render();
      P.page.querySelector('[data-fp-folder="' + window.CSS.escape(folder) + '"] [data-fp-act="pf-unprotect"]').focus();
    } else if (a === 'pf-unprotect-yes') {
      UI.setBusy(b, true);
      UI.showError(list, '');
      FP.call('put', 'protectedFolders', {folder: folder, protected: false}, P.account).then(function (r) {
        P.folders = cleanFolders(r);
        if (P.open === folder) { P.open = ''; }
        render();
        M.say(P.page.querySelector('.fp-pf-list'), t('pf_unprotected', {folder: folder}));
        P.page.querySelector('#fp-pf-h').focus();
      }, function (err) {
        render();
        UI.showError(P.page.querySelector('.fp-pf-list'), err.message);
        P.page.querySelector('#fp-pf-h').focus();
        if (err.status === 404) { reload(); }
      });
    } else if (a === 'pf-password') {
      var l = b.closest('[data-fp-login]').getAttribute('data-fp-login');
      var card = logins();
      card.querySelector('#fp-pf-login').value = l;
      card.querySelector('#fp-pf-password').focus();
    } else if (a === 'pf-login-remove') {
      var li = b.closest('[data-fp-login]');
      var acts = li.querySelector('.fp-pf-login-acts');
      M.confirmIn(acts, t('pf_login_remove_ask', {login: li.getAttribute('data-fp-login')}), 'pf-login-remove-yes', t('pf_login_remove'));
    } else if (a === 'confirm-no' && b.closest('[data-fp-login]')) {
      var who = b.closest('[data-fp-login]').getAttribute('data-fp-login');
      render();
      logins().querySelector('[data-fp-login="' + window.CSS.escape(who) + '"] [data-fp-act="pf-login-remove"]').focus();
    } else if (a === 'pf-login-remove-yes') {
      var gone = b.closest('[data-fp-login]').getAttribute('data-fp-login');
      var open = P.open;
      UI.setBusy(b, true);
      FP.call('del', 'protectedLogin', undefined, {name: P.account, folder: open, login: gone}).then(function (r) {
        settled(r, t('pf_login_removed', {login: gone, folder: open}), '#fp-pf-logins-h');
      }, function (err) {
        render();
        answer(err, null);
        logins().querySelector('#fp-pf-open-h').focus();
      });
    }
  }

  FP.view('tool:protected_folders', function () {
    P.page = null;
    var body = M.frame('protected_folders', 'fp-pf');
    if (!body) { return; }
    P.page = body;
    P.account = FP.account();
    P.open = '';
    P.draft = null;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all([FP.call('get', 'protectedFolders', undefined, P.account), FP.call('get', 'domains', undefined, P.account)]).then(function (r) {
      if (P.page !== body) { return; }
      P.folders = cleanFolders(r[0]);
      var home = homeOf(r[1]);
      P.sites = cleanSites(r[1], home);
      P.homeUnknown = !home && Boolean(r[1] && Array.isArray(r[1].sites) && r[1].sites.length);
      P.suspended = Boolean(r[1] && r[1].suspended === true);
      render();
    }, function (err) {
      if (P.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(FP.tools.protected_folders.label, err.message));
    });
  });
  document.addEventListener('click', onClick);
})();

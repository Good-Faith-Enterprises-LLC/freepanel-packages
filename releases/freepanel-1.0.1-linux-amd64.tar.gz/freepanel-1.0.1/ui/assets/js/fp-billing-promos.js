/* freePanel billing promotions (#/tool/billing_promos; docs/api.md, "Billing: orders"; docs/billing/navigation-map.md, "Promotions"): the
   promo codes orders take, with their kind and value, the term they apply to, the plan they are for, their uses and when they end. A code's
   text and kind are chosen once; the rest changes. A code orders have used is disabled, not removed; one never used is removed after a
   question. A percent is typed as a whole number, a fixed amount in dollars and cents and sent in cents. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;
  var M = FP.mail;

  var PROMO = {id: 'id', code: [32], description: [200], kind: ['=', ['percent', 'fixed']], amount: 'n', applies: ['=', ['first', 'recurring']], plan_id: 'id', expires: [40],
    max_uses: 'n', uses: 'n', status: ['=', ['active', 'disabled']]};
  /* the form reads amount and expires as typed: amount_n keeps the value as the API sends it */
  function clean(x) {
    var v = B.pick(x, PROMO);
    if (!v || !v.id || !v.code || !v.kind || v.amount === null) { return null; }
    v.amount_n = v.amount;
    v.amount = v.kind === 'percent' ? String(v.amount) : B.amountText(v.amount);
    v.expires = /^\d{4}-\d{2}-\d{2}/.test(v.expires) ? v.expires.slice(0, 10) : '';
    return v;
  }
  function value(p) { return p.kind === 'percent' ? t('bpm_percent_n', {n: String(p.amount_n)}) : B.money(p.amount_n, 'USD'); }
  function uses(p) { return p.max_uses === null ? B.num(p.uses || 0) : t('bpm_uses_of', {n: B.num(p.uses || 0), max: B.num(p.max_uses)}); }

  FP.view('tool:billing_promos', function () {
    var page = B.frame('billing_promos', 'fp-bpm');
    if (!page) { return; }
    var alive = function () { return page.isConnected; };
    var plans = [];
    function planName(pid) {
      if (!pid) { return t('bpm_any_plan'); }
      var p = plans.filter(function (x) { return x.id === pid; })[0];
      return p ? p.name : t('bpm_plan_n', {id: String(pid)});
    }
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    var R = B.crud({page: page, pre: 'fp-bpm', title: t('bpm_title'), alive: alive,
      what: function () { return [el('p', {class: 'fp-muted', text: t('bpm_what')})]; },
      load: function () {
        return Promise.all([FP.call('get', 'billingPromos', undefined, {}), FP.call('get', 'billingPlans', undefined, {}).then(function (r) { return B.pickAll(r && r.plans, {id: 'id', name: [60]}, 'id'); }, function () { return []; })])
          .then(function (r) {
            plans = r[1];
            return (r[0] && Array.isArray(r[0].promos) ? r[0].promos : []).map(clean).filter(Boolean);
          });
      },
      heads: [B.th(t('bpm_col_code')), B.th(t('bpm_col_value'), 'fp-bil-num'), B.th(t('bpm_col_applies')), B.th(t('bpm_col_plan')), B.th(t('bpm_col_uses'), 'fp-bil-num'),
        B.th(t('bpm_col_ends')), B.th(t('bpm_col_status'))],
      cells: function (p) {
        return [el('th', {scope: 'row', class: 'fp-bil-wrap'}, [el('code', {class: 'fp-bpm-code', text: p.code}), p.description ? el('span', {class: 'fp-muted fp-bpm-desc', text: p.description}) : null]),
          el('td', {class: 'fp-bil-num', text: value(p)}), el('td', {text: t('bpm_applies_' + (p.applies || 'first'))}), el('td', {class: 'fp-bil-wrap', text: planName(p.plan_id)}),
          el('td', {class: 'fp-bil-num', text: uses(p)}), el('td', {class: 'fp-bil-nowrap', text: p.expires ? B.day(p.expires) : t('bpm_no_end')}),
          el('td', null, [B.pill(t('bpm_status_' + (p.status || 'active')), p.status === 'disabled' ? '' : 'ok')])];
      },
      removable: function (p) { return !p.uses; },
      fieldsFor: function (x) {
        var f = [];
        if (!x) {
          f.push({name: 'code', label: t('bpm_col_code'), required: true, max: 32, code: true, hint: t('bpm_code_hint')},
            {name: 'kind', label: t('bpm_kind'), kind: 'select', options: [['percent', t('bpm_kind_percent')], ['fixed', t('bpm_kind_fixed')]], hint: t('bpm_kind_hint')});
        }
        return f.concat([{name: 'amount', label: x ? t(x.kind === 'percent' ? 'bpm_amount_percent' : 'bpm_amount_fixed') : t('bpm_amount'), required: true, max: 16, hint: t(x ? (x.kind === 'percent' ? 'bpm_amount_percent_hint' : 'bpm_amount_fixed_hint') : 'bpm_amount_hint')},
          {name: 'description', label: t('bpm_desc'), max: 200, hint: t('bpm_desc_hint')},
          {name: 'applies', label: t('bpm_col_applies'), kind: 'select', options: [['first', t('bpm_applies_first')], ['recurring', t('bpm_applies_recurring')]]},
          {name: 'plan_id', label: t('bpm_col_plan'), kind: 'select', num: true, options: [['', t('bpm_any_plan')]].concat(plans.map(function (p) { return [String(p.id), p.name]; }))},
          {name: 'expires', label: t('bpm_expires'), kind: 'date', hint: t('bpm_expires_hint')},
          {name: 'max_uses', label: t('bpm_max_uses'), kind: 'number', empty: null, hint: t('bpm_max_uses_hint')},
          {name: 'status', label: t('bpm_col_status'), kind: 'select', options: [['active', t('bpm_status_active')], ['disabled', t('bpm_status_disabled')]]}]);
      },
      /* the amount as the API takes it: a whole percent, or cents; an emptied end day is no end */
      check: function (body, x, form) {
        var kind = x ? x.kind : body.kind;
        if (body.amount !== undefined) {
          var n = kind === 'percent' ? (/^\d{1,3}%?$/.test(body.amount) ? parseInt(body.amount, 10) : null) : B.parseAmount(body.amount, false);
          if (n === null || n < 1 || (kind === 'percent' && n > 100)) { M.fieldError(form, UI.fieldNamed(form, 'amount'), t(kind === 'percent' ? 'bpm_amount_percent_bad' : 'bpm_amount_fixed_bad')); return true; }
          if (x && n === x.amount_n) { delete body.amount; } else { body.amount = n; }
        }
        if (body.code !== undefined) { body.code = body.code.toUpperCase(); }
        if (body.expires === '') { body.expires = null; }
        return false;
      },
      add: 'billingPromos', item: 'billingPromo', nameOf: function (p) { return p.code; }, clean: clean,
      strings: {none: t('bpm_none'), addTitle: t('bpm_add_title'), addSave: t('bpm_add'), editTitle: function (n) { return t('bil_change_title', {name: n}); },
        added: function (n) { return t('bil_added', {name: n}); }, saved: function (n) { return t('bil_saved', {name: n}); }, removed: function (n) { return t('bil_removed', {name: n}); },
        removeAsk: function (n) { return t('bpm_remove_ask', {name: n}); }, removeYes: t('bpm_remove_yes'), formWhat: t('bpm_form_what')}});
    R.show();
  });
})();

/* freePanel resource usage (docs/api.md, "Resource usage"): the customer panel's Resource usage (#/tool/resource_usage), graphs
   of what the account's processes used over a day, a week or two weeks (CPU, memory, disk, processes) and the processes
   running now; and the admin panel's Busiest accounts (#/tool/resource_top), the accounts a login may see ranked by what
   they used. Process names come from the accounts' own processes and are drawn as text. Needs FP.barChart (fp-webstats.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var USER_RE = /^[a-z][a-z0-9]{0,15}$/;
  var RANGES = [['24', 'rus_range_24'], ['168', 'rus_range_168'], ['336', 'rus_range_336']];

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 100) : ''; }
  function num(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? v : 0; }
  function count(n) { return Math.round(n).toLocaleString('en'); }
  function one(n) { return (Math.round(n * 10) / 10).toLocaleString('en'); }
  var UNITS = ['KB', 'MB', 'GB', 'TB', 'PB'];
  function size(n) {
    if (n < 1024) { return t('size_bytes', {n: count(n)}); }
    var u = -1;
    do { n /= 1024; u++; } while (n >= 1024 && u < UNITS.length - 1);
    return (n < 10 ? n.toFixed(1) : count(n)) + ' ' + UNITS[u];
  }
  function seconds(s) {
    if (s < 90) { return t('rus_sec', {n: one(s)}); }
    if (s < 5400) { return t('rus_min', {n: one(s / 60)}); }
    return t('rus_hour', {n: one(s / 3600)});
  }
  function stamp(iso) {
    var d = typeof iso === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(iso) ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) && d.getFullYear() > 2000 ? d : null;
  }
  function pointLabel(d, step) {
    return step >= 3600 ? d.toLocaleString('en', {month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false, timeZone: 'UTC'})
      : d.toLocaleString('en', {month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false, timeZone: 'UTC'});
  }
  function card(id, title, children, cls) {
    return el('section', {class: 'sig-card fp-rus-card' + (cls ? ' ' + cls : ''), 'aria-labelledby': id}, [el('div', {class: 'sig-card-body'},
      [el('h2', {class: 'fp-h2', id: id, tabindex: '-1', text: title})].concat(children))]);
  }
  function selectField(id, text, options, value) {
    var s = el('select', {class: 'sig-select', id: id}, options.map(function (o) {
      var opt = el('option', {value: o[0], text: o[1]});
      if (o[0] === value) { opt.selected = true; }
      return opt;
    }));
    return {select: s, field: el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: id, text: text}), s])};
  }
  function wrap(table, id) { return el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': id}, [table]); }

  /* ================= the account's graphs ================= */
  var R = null;
  function cleanHistory(r) {
    if (!r || typeof r !== 'object' || !Array.isArray(r.points) || !(num(r.step_seconds) > 0)) { return null; }
    var pts = r.points.slice(0, 400).map(function (p) {
      var at = p && typeof p === 'object' ? stamp(p.at) : null;
      if (!at) { return null; }
      return {at: at, samples: num(p.samples), cpu: num(p.cpu_seconds), cpuPct: num(p.cpu_percent), memAvg: num(p.mem_avg_bytes), memPeak: num(p.mem_peak_bytes),
        procs: num(p.processes), threads: num(p.threads), read: num(p.read_bytes), write: num(p.write_bytes), faults: num(p.faults)};
    }).filter(Boolean);
    return {step: r.step_seconds, points: pts};
  }
  function cleanNow(r) {
    if (!r || typeof r !== 'object' || !Array.isArray(r.top)) { return null; }
    return {processes: num(r.processes), threads: num(r.threads), mem: num(r.mem_bytes), truncated: r.truncated === true, at: stamp(r.at),
      top: r.top.slice(0, 15).filter(function (p) { return p && typeof p === 'object'; }).map(function (p) {
        return {pid: num(p.pid), name: str(p.name, 15), threads: num(p.threads), mem: num(p.mem_bytes), cpu: num(p.cpu_total_seconds), started: stamp(p.started)};
      })};
  }
  function graph(id, title, pts, step, pick, fmt, summary) {
    var vals = pts.map(pick);
    var top = Math.max.apply(null, vals.concat([0]));
    var peakAt = vals.indexOf(top);
    var said = top ? t('rus_graph_label', {title: title, peak: fmt(top), when: pointLabel(pts[peakAt].at, step)}) : t('rus_graph_none', {title: title});
    return card(id, title, [el('p', {class: 'fp-rus-sum', 'data-fp-summary': ''}, [el('strong', {text: summary})]),
      FP.barChart(vals, pts.map(function (p) { return pointLabel(p.at, step); }), said, fmt)], 'fp-rus-graph');
  }
  function numbers(pts, step) {
    return FP.disclose(t('rus_numbers'), wrap(el('table', {class: 'sig-table fp-rus-table'}, [
      el('thead', null, [el('tr', null, [t('rus_when'), t('rus_cpu_pct'), t('rus_mem_peak'), t('rus_procs'), t('rus_read'), t('rus_write'), t('rus_faults')].map(function (h, i) {
        return el('th', {scope: 'col', class: i ? 'fp-num' : null, text: h});
      }))]),
      el('tbody', null, pts.slice().reverse().filter(function (p) { return p.samples; }).map(function (p) {
        return el('tr', null, [el('th', {scope: 'row', text: pointLabel(p.at, step)}), el('td', {class: 'fp-num', text: one(p.cpuPct) + '%'}), el('td', {class: 'fp-num', text: size(p.memPeak)}),
          el('td', {class: 'fp-num', text: count(p.procs)}), el('td', {class: 'fp-num', text: size(p.read)}), el('td', {class: 'fp-num', text: size(p.write)}), el('td', {class: 'fp-num', text: count(p.faults)})]);
      }))]), 'fp-rus-num-h'));
  }
  function drawGraphs() {
    var page = R.page;
    var h = R.history;
    page.textContent = '';
    var range = selectField('fp-rus-range', t('rus_range'), RANGES.map(function (r) { return [r[0], t(r[1])]; }), R.hours);
    page.appendChild(card('fp-rus-h', t('rus_title'), [M.errorLine(), M.statusLine(), el('div', {class: 'fp-st-controls'}, [range.field]),
      el('p', {class: 'fp-muted', text: t('rus_note')})], 'fp-rus-top'));
    range.select.addEventListener('change', function () { R.hours = range.select.value; UI.store.set('fp.rus.range', R.hours); loadGraphs('#fp-rus-range'); });
    if (!h) { return; }
    var pts = h.points;
    var used = pts.filter(function (p) { return p.samples; });
    if (!used.length) {
      page.appendChild(card('fp-rus-none-h', t('rus_none_title'), [el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('rus_none')})], 'fp-rus-empty'));
    } else {
      var cpuTotal = used.reduce(function (a, p) { return a + p.cpu; }, 0);
      var cpuPeak = Math.max.apply(null, used.map(function (p) { return p.cpuPct; }));
      var memPeak = Math.max.apply(null, used.map(function (p) { return p.memPeak; }));
      var ioTotal = used.reduce(function (a, p) { return a + p.read + p.write; }, 0);
      var procsPeak = Math.max.apply(null, used.map(function (p) { return p.procs; }));
      page.appendChild(graph('fp-rus-cpu-h', t('rus_cpu'), pts, h.step, function (p) { return p.cpuPct; }, function (v) { return one(v) + '%'; },
        t('rus_cpu_sum', {total: seconds(cpuTotal), peak: one(cpuPeak)})));
      page.appendChild(graph('fp-rus-mem-h', t('rus_mem'), pts, h.step, function (p) { return p.memPeak; }, size, t('rus_mem_sum', {peak: size(memPeak)})));
      page.appendChild(graph('fp-rus-io-h', t('rus_io'), pts, h.step, function (p) { return p.read + p.write; }, size, t('rus_io_sum', {total: size(ioTotal)})));
      page.appendChild(graph('fp-rus-proc-h', t('rus_proc'), pts, h.step, function (p) { return p.procs; }, count, t('rus_proc_sum', {peak: count(procsPeak)})));
      page.appendChild(card('fp-rus-num-h', t('rus_numbers_title'), [numbers(pts, h.step), el('p', {class: 'fp-muted fp-st-utc', text: t('rus_utc')})], 'fp-rus-nums'));
    }
    drawNow();
  }
  function drawNow() {
    var old = R.page.querySelector('.fp-rus-now');
    var n = R.now;
    var body = [M.errorLine(), M.statusLine()];
    if (!n) {
      body.push(el('p', {class: 'fp-muted', text: t('rus_now_unknown')}));
    } else if (!n.top.length) {
      body.push(el('p', {class: 'fp-muted', 'data-fp-idle': '', text: t('rus_now_none')}));
    } else {
      body.push(el('p', {class: 'fp-rus-sum', 'data-fp-now-sum': ''}, [el('strong', {text: t('rus_now_sum', {n: count(n.processes), mem: size(n.mem), threads: count(n.threads)})})]),
        wrap(el('table', {class: 'sig-table fp-rus-table fp-rus-procs'}, [
          el('thead', null, [el('tr', null, [t('rus_p_name'), t('rus_p_mem'), t('rus_p_threads'), t('rus_p_cpu'), t('rus_p_started')].map(function (x, i) {
            return el('th', {scope: 'col', class: i && i < 4 ? 'fp-num' : null, text: x});
          }))]),
          el('tbody', null, n.top.map(function (p) {
            return el('tr', {'data-fp-proc': String(p.pid)}, [el('th', {scope: 'row', class: 'sig-mono fp-wst-name', text: p.name || '—'}), el('td', {class: 'fp-num', text: size(p.mem)}),
              el('td', {class: 'fp-num', text: count(p.threads)}), el('td', {class: 'fp-num', text: seconds(p.cpu)}),
              el('td', {text: p.started ? p.started.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'}) : '—'})]);
          }))]), 'fp-rus-now-h'));
      if (n.truncated) { body.push(el('p', {class: 'fp-muted', text: t('rus_now_more', {n: n.top.length})})); }
    }
    body.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'refresh-now', text: t('rus_refresh')})]));
    var fresh = card('fp-rus-now-h', t('rus_now_title'), body, 'fp-rus-now');
    if (old) { old.replaceWith(fresh); } else { R.page.appendChild(fresh); }
  }
  function loadGraphs(focus) {
    var mine = R;
    var arg = {name: R.account, hours: R.hours};
    R.history = null;
    drawGraphs();
    R.page.appendChild(el('p', {class: 'fp-muted', 'data-fp-loading': '', text: t('loading')}));
    if (focus) { R.page.querySelector(focus).focus(); }
    Promise.all([FP.call('get', 'resUsage', undefined, arg), FP.call('get', 'resNow', undefined, R.account).then(cleanNow, function () { return null; })]).then(function (r) {
      if (R !== mine) { return; }
      R.history = cleanHistory(r[0]);
      R.now = r[1];
      drawGraphs();
      if (!R.history) { UI.showError(R.page.querySelector('.fp-rus-top'), t('api_failed')); }
      if (focus) { R.page.querySelector(focus).focus(); }
      UI.announce(t('rus_loaded'));
    }, function (err) {
      if (R !== mine) { return; }
      drawGraphs();
      UI.showError(R.page.querySelector('.fp-rus-top'), err.message);
      UI.announce(err.message);
      if (focus) { R.page.querySelector(focus).focus(); }
    });
  }
  function onClick(e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act="refresh-now"]') : null;
    if (!b || !R || !R.page.contains(b) || b.disabled) { return; }
    var mine = R;
    UI.setBusy(b, true);
    FP.call('get', 'resNow', undefined, R.account).then(function (r) {
      if (R !== mine) { return; }
      var n = cleanNow(r);
      if (n) { R.now = n; }
      drawNow();
      var again = R.page.querySelector('[data-fp-act="refresh-now"]');
      again.focus();
      if (n) { M.say(R.page.querySelector('.fp-rus-now'), t('rus_now_refreshed')); } else { UI.showError(R.page.querySelector('.fp-rus-now'), t('api_failed')); }
    }, function (err) {
      if (R !== mine) { return; }
      drawNow();
      R.page.querySelector('[data-fp-act="refresh-now"]').focus();
      UI.showError(R.page.querySelector('.fp-rus-now'), err.message);
    });
  }
  document.addEventListener('click', onClick);

  FP.view('tool:resource_usage', function () {
    var body = M.frame('resource_usage', 'fp-rus-page');
    if (!body) { return; }
    var h = UI.store.get('fp.rus.range');
    R = {page: body, account: FP.account(), hours: RANGES.some(function (r) { return r[0] === h; }) ? h : '24', history: null, now: null};
    loadGraphs();
  });

  /* ================= the busiest accounts (admin and reseller) ================= */
  var T = null;
  var BY = [['cpu', 'rtp_by_cpu'], ['memory', 'rtp_by_memory'], ['io', 'rtp_by_io'], ['faults', 'rtp_by_faults']];
  function cleanTop(r) {
    if (!r || typeof r !== 'object' || !Array.isArray(r.accounts)) { return null; }
    return {considered: num(r.considered), withData: num(r.with_data), rows: r.accounts.slice(0, 100).filter(function (a) { return a && USER_RE.test(str(a.username, 16)); }).map(function (a) {
      return {name: a.username, cpu: num(a.cpu_seconds), cpuPct: num(a.cpu_percent), memAvg: num(a.mem_avg_bytes), memPeak: num(a.mem_peak_bytes), procs: num(a.processes),
        read: num(a.read_bytes), write: num(a.write_bytes), faults: num(a.faults)};
    })};
  }
  function drawTop() {
    var page = T.page;
    page.textContent = '';
    var hours = selectField('fp-rtp-hours', t('rus_range'), RANGES.map(function (r) { return [r[0], t(r[1])]; }), T.hours);
    var by = selectField('fp-rtp-by', t('rtp_by'), BY.map(function (r) { return [r[0], t(r[1])]; }), T.by);
    var d = T.data;
    var body = [M.errorLine(), el('div', {class: 'fp-st-controls'}, [hours.field, by.field]), el('p', {class: 'fp-muted', text: t(FP.session.user.role === 'admin' ? 'rtp_note_admin' : 'rtp_note_reseller')})];
    if (d) {
      body.push(el('p', {class: 'fp-rus-sum', 'data-fp-count': ''}, [el('strong', {text: t('rtp_count', {with: count(d.withData), all: count(d.considered)})})]));
      body.push(d.rows.length ? wrap(el('table', {class: 'sig-table fp-rus-table fp-rtp-table'}, [
        el('thead', null, [el('tr', null, [t('rtp_account'), t('rtp_cpu'), t('rtp_cpu_pct'), t('rus_mem_avg'), t('rus_mem_peak'), t('rus_read'), t('rus_write'), t('rus_faults')].map(function (x, i) {
          return el('th', {scope: 'col', class: i ? 'fp-num' : null, text: x});
        }))]),
        el('tbody', null, d.rows.map(function (a) {
          return el('tr', {'data-fp-account': a.name}, [el('th', {scope: 'row', class: 'sig-mono', text: a.name}), el('td', {class: 'fp-num', text: seconds(a.cpu)}),
            el('td', {class: 'fp-num', text: one(a.cpuPct) + '%'}), el('td', {class: 'fp-num', text: size(a.memAvg)}), el('td', {class: 'fp-num', text: size(a.memPeak)}),
            el('td', {class: 'fp-num', text: size(a.read)}), el('td', {class: 'fp-num', text: size(a.write)}), el('td', {class: 'fp-num', text: count(a.faults)})]);
        }))]), 'fp-rtp-h') : el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('rtp_none')}));
    }
    page.appendChild(card('fp-rtp-h', t('rtp_title'), body, 'fp-rtp-card'));
    hours.select.addEventListener('change', function () { T.hours = hours.select.value; loadTop('#fp-rtp-hours'); });
    by.select.addEventListener('change', function () { T.by = by.select.value; loadTop('#fp-rtp-by'); });
  }
  function loadTop(focus) {
    var mine = T;
    T.data = null;
    drawTop();
    T.page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    if (focus) { T.page.querySelector(focus).focus(); }
    FP.call('get', 'resTop', undefined, {hours: T.hours, by: T.by, limit: '20'}).then(function (r) {
      if (T !== mine) { return; }
      T.data = cleanTop(r);
      drawTop();
      if (!T.data) { UI.showError(T.page.querySelector('.fp-rtp-card'), t('api_failed')); }
      if (focus) { T.page.querySelector(focus).focus(); }
      UI.announce(t('rtp_loaded'));
    }, function (err) {
      if (T !== mine) { return; }
      drawTop();
      UI.showError(T.page.querySelector('.fp-rtp-card'), err.message);
      UI.announce(err.message);
      if (focus) { T.page.querySelector(focus).focus(); }
    });
  }
  FP.view('tool:resource_top', function () {
    var tool = FP.tools.resource_top;
    if (!tool || FP.realm !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('rtp_desc'), cls: 'fp-rus fp-rtp-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    T = {page: page, hours: '24', by: 'cpu', data: null};
    loadTop();
  });
})();

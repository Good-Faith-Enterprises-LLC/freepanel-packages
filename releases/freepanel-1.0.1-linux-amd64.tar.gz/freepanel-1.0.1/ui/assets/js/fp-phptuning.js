/* freePanel PHP pool tuning (docs/api.md, "PHP tuning"): the admin panel's page (#/tool/php_tuning) for giving one account's PHP pools another number
   of workers and another limit on the files each worker holds open. It limits how many PHP processes the account's websites run at once and what
   each holds, not the CPU or memory they use, and the page says so first. The admin picks an account (the list of accounts is offered as
   suggestions; the server answers 404 for a name it does not have), sees what each PHP version the account's sites use runs with now, and changes
   either number or puts its default back. A save names only the numbers that changed (a whole number sets, null puts the default back), and the
   same numbers apply to every PHP version the account uses. Admin only: the server refuses these calls to anyone else. Everything the server
   sends is shown as text. The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var FIELDS = ['max_workers', 'open_files'];
  var DEFAULT_RANGES = {max_workers: {min: 1, max: 500}, open_files: {min: 128, max: 1048576}};
  var NAME_RE = /^[a-z][a-z0-9]{0,15}$/;
  var VERSION_RE = /^[0-9][0-9.]{0,11}$/;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  function num(v) { return typeof v === 'number' && isFinite(v) && Math.floor(v) === v && v >= 0 ? v : null; }
  function fmt(n) { return n.toLocaleString('en'); }
  function ranges(v) {
    var out = {};
    FIELDS.forEach(function (f) {
      var r = v && typeof v === 'object' && v[f] && typeof v[f] === 'object' ? v[f] : {};
      var min = num(r.min);
      var max = num(r.max);
      out[f] = min !== null && max !== null && min <= max ? {min: min, max: max} : DEFAULT_RANGES[f];
    });
    return out;
  }
  function tuning(v) {
    v = v && typeof v === 'object' ? v : {};
    return {username: NAME_RE.test(str(v.username, 16)) ? v.username : '', max_workers: num(v.max_workers), open_files: num(v.open_files),
      versions: (Array.isArray(v.versions) ? v.versions : []).filter(function (x) { return x && typeof x === 'object' && VERSION_RE.test(str(x.version, 12)); }).slice(0, 30)
        .map(function (x) { return {version: x.version, max_workers: num(x.max_workers), open_files: num(x.open_files)}; }),
      ranges: ranges(v.ranges)};
  }
  function names(v) {
    return (v && Array.isArray(v.accounts) ? v.accounts : []).map(function (a) { return a && str(a.username, 16); }).filter(function (u) { return NAME_RE.test(u); })
      .sort().slice(0, 5000);
  }

  var P = {page: null, cur: null, accounts: [], listError: '', busy: false};

  function aboutCard() {
    return M.card('fp-phpt-about-h', t('phpt_about_title'), [
      el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-phpt-cover': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('phpt_cover')})]),
      el('p', {class: 'fp-muted', text: t('phpt_about_workers')}), el('p', {class: 'fp-muted', text: t('phpt_about_files')}),
      el('p', {class: 'fp-muted', text: t('phpt_about_selinux')})], 'fp-phpt-about');
  }
  function pickCard() {
    var list = el('datalist', {id: 'fp-phpt-accounts'}, P.accounts.map(function (u) { return el('option', {value: u}); }));
    var pick = el('input', {class: 'sig-input sig-mono', id: 'fp-phpt-account', name: 'username', type: 'text', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none',
      maxlength: '16', value: P.cur ? P.cur.username : '', list: P.accounts.length ? 'fp-phpt-accounts' : null, 'aria-describedby': 'fp-phpt-account-hint'});
    var form = el('form', {class: 'fp-form fp-phpt-form', novalidate: ''}, [M.errorLine(), M.field('fp-phpt-account', t('phpt_account'), pick, t('phpt_account_hint')), list,
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('phpt_show')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || P.busy) { return; }
      var name = pick.value.trim().toLowerCase();
      if (!NAME_RE.test(name)) { M.fieldError(form, pick, t('phpt_bad_account')); return; }
      load(name, b, form);
    });
    var parts = [el('p', {class: 'fp-muted', text: t('phpt_pick_what')})];
    /* the suggestions are a convenience, but a list the server refused is said, in its words, and the box is still there to type in */
    if (P.listError) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-phpt-listerr': ''}, [UI.icon(FP.ui, 'ui_warning'),
        el('span', {text: t('phpt_list_failed', {why: P.listError})})]));
    }
    parts.push(form);
    if (P.cur) { parts.push(tuneForm()); }
    return M.card('fp-phpt-pick-h', t('phpt_pick_title'), parts, 'fp-phpt-pickcard');
  }

  function versionsList() {
    var cur = P.cur;
    if (!cur.versions.length) { return el('p', {class: 'fp-muted', 'data-fp-phpt-nosite': '', text: t('phpt_no_site', {name: cur.username})}); }
    return el('ul', {class: 'fp-phpt-versions', 'data-fp-phpt-versions': ''}, cur.versions.map(function (v) {
      return el('li', {class: 'fp-phpt-version', 'data-fp-version': v.version}, [el('span', {class: 'fp-phpt-vname', text: t('phpt_version', {version: v.version})}),
        el('span', {class: 'fp-muted fp-phpt-vnow', text: t('phpt_runs', {workers: v.max_workers === null ? t('phpt_unknown') : fmt(v.max_workers),
          files: v.open_files === null ? t('phpt_system_limit') : fmt(v.open_files)})})]);
    }));
  }
  function numberField(f) {
    var cur = P.cur;
    var r = cur.ranges[f];
    var id = 'fp-phpt-' + f;
    var input = el('input', {class: 'sig-input fp-phpt-num', id: id, name: f, type: 'text', inputmode: 'numeric', autocomplete: 'off', maxlength: '8',
      value: cur[f] === null ? '' : String(cur[f]), 'aria-describedby': id + '-hint'});
    return M.field(id, t('phpt_label_' + f), input, t('phpt_hint_' + f, {min: fmt(r.min), max: fmt(r.max)}));
  }
  function readForm(form) {
    var cur = P.cur;
    var body = {};
    var any = false;
    for (var i = 0; i < FIELDS.length; i++) {
      var f = FIELDS[i];
      var box = form.querySelector('[name="' + f + '"]');
      var v = box.value.trim().replace(/[\s,]/g, '');
      if (v === '') {
        if (cur[f] !== null) { body[f] = null; any = true; }
        continue;
      }
      if (!/^[0-9]{1,8}$/.test(v)) { M.fieldError(form, box, t('phpt_bad_number')); return null; }
      var n = Number(v);
      var r = cur.ranges[f];
      if (n < r.min || n > r.max) { M.fieldError(form, box, t('phpt_out_of_range', {min: fmt(r.min), max: fmt(r.max)})); return null; }
      if (n !== cur[f]) { body[f] = n; any = true; }
    }
    if (!any) { M.fieldError(form, null, t('phpt_nothing')); return null; }
    return body;
  }
  function tuneForm() {
    var cur = P.cur;
    var anySet = FIELDS.some(function (f) { return cur[f] !== null; });
    var hasSite = cur.versions.length > 0;
    var form = el('form', {class: 'fp-form fp-phpt-form fp-phpt-account', novalidate: '', 'data-fp-phpt-for': cur.username}, [
      el('h3', {class: 'fp-h3', id: 'fp-phpt-for-h', tabindex: '-1', text: t('phpt_for', {name: cur.username})}), M.errorLine(), M.statusLine(),
      el('p', {class: 'fp-muted fp-phpt-now', text: t('phpt_now')}), versionsList()]);
    if (!hasSite) { return form; }
    FIELDS.forEach(function (f) { form.appendChild(numberField(f)); });
    form.appendChild(el('p', {class: 'fp-muted', text: t('phpt_apply')}));
    form.appendChild(el('div', {class: 'fp-actions fp-phpt-acts'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('phpt_save')}),
      anySet ? el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'phpt-defaults', text: t('phpt_defaults')}) : null]));
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || P.busy) { return; }
      var body = readForm(form);
      if (!body) { return; }
      save(body, b, form, t('phpt_saved', {name: cur.username}));
    });
    return form;
  }
  function render() {
    P.page.textContent = '';
    P.page.appendChild(aboutCard());
    P.page.appendChild(pickCard());
  }

  function load(name, b, form) {
    P.busy = true;
    UI.setBusy(b, true);
    var mine = P.page;
    FP.call('get', 'phpTuning', undefined, name).then(function (r) {
      P.busy = false;
      if (P.page !== mine) { return; }
      P.cur = tuning(r);
      if (!P.cur.username) { P.cur.username = name; }
      render();
      P.page.querySelector('#fp-phpt-for-h').focus();
    }, function (err) {
      P.busy = false;
      if (P.page !== mine) { return; }
      UI.setBusy(b, false);
      M.failed(form, err);
    });
  }
  function save(body, b, form, done) {
    P.busy = true;
    UI.setBusy(b, true);
    var mine = P.page;
    var name = P.cur.username;
    FP.call('put', 'phpTuning', body, name).then(function (r) {
      P.busy = false;
      if (P.page !== mine) { return; }
      P.cur = tuning(r);
      if (!P.cur.username) { P.cur.username = name; }
      render();
      M.say(P.page.querySelector('.fp-phpt-account'), done);
      P.page.querySelector('#fp-phpt-for-h').focus();
    }, function (err) {
      P.busy = false;
      if (P.page !== mine) { return; }
      UI.setBusy(b, false);
      M.failed(form, err);
    });
  }

  document.addEventListener('click', function (e) {
    var node = e.target.closest ? e.target : null;
    var b = node && node.closest('[data-fp-act]');
    if (!b || !P.page || !P.page.contains(b)) { return; }
    if (b.getAttribute('data-fp-act') === 'phpt-defaults' && P.cur && !P.busy) {
      var body = {};
      FIELDS.forEach(function (f) { if (P.cur[f] !== null) { body[f] = null; } });
      save(body, b, P.page.querySelector('.fp-phpt-account'), t('phpt_defaulted', {name: P.cur.username}));
    }
  });

  FP.view('tool:php_tuning', function () {
    var tool = FP.tools.php_tuning;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    P.cur = null;
    P.busy = false;
    P.accounts = [];
    P.listError = '';
    var body = FP.frame({title: tool.label, desc: t('phpt_desc'), cls: 'fp-mail fp-srv fp-phpt-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    P.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'accounts').then(function (r) { return names(r); }, function (err) { P.listError = err.message; return []; }).then(function (list) {
      if (P.page !== body) { return; }
      P.accounts = list;
      render();
    });
  });
})();

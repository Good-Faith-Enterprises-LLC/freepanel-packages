/* freePanel deliverability (#/tool/deliverability), the customer panel's check of the DNS records that get mail
   delivered (docs/api.md, "DNS zones": mail-auth): for each of the account's zones, whether its SPF, DKIM and DMARC
   records are set up, what they hold and what they should hold, and a button that writes what they should hold. The
   fix sends the zone's serial from the check, so a zone changed meanwhile is checked again instead of overwritten. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;

  var CHECKS = ['spf', 'dkim', 'dmarc'];
  var STATUS = {ok: 'ok', missing: 'danger', wrong: 'warn'};
  var DOMAIN_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;

  var page = null;
  var account = '';
  var zones = [];   /* [{zone, auth: cleaned MailAuth or null, error: text}] */

  function str(v) { return typeof v === 'string' ? v : ''; }
  function cleanAuth(v) {
    v = v && typeof v === 'object' ? v : {};
    var checks = v.checks && typeof v.checks === 'object' ? v.checks : {};
    /* the three DKIM fields are true only when the server says true: anything else (a missing field, a string) is not */
    var out = {serial: typeof v.serial === 'number' && v.serial > 0 ? v.serial : 0, checks: {},
      dkimStore: v.dkim_store === true, dkimKey: v.dkim_key === true, dkimSigning: v.dkim_signing === true};
    CHECKS.forEach(function (k) {
      var c = checks[k] && typeof checks[k] === 'object' ? checks[k] : {};
      out.checks[k] = {status: STATUS[c.status] ? c.status : 'missing', have: str(c.have), want: str(c.want)};
    });
    return out;
  }
  function allOk(a) { return CHECKS.every(function (k) { return a.checks[k].status === 'ok'; }); }
  /* DKIM's four cases (docs/api.md, MailAuth): off when the server keeps no DKIM keys (dkim_store false); no key yet
     when it keeps them but the zone has none (Fix makes it); otherwise the server signs the zone's mail (dkim_signing)
     or only holds the key. */
  function dkimState(a) {
    if (!a.dkimStore) { return 'off'; }
    if (!a.dkimKey) { return 'nokey'; }
    return a.dkimSigning ? 'signing' : 'unsigned';
  }
  /* The sentence under the DKIM pill. A case's own sentence says what the key and the signer are doing, and it is true only while
     the record is in place (the key is published); with the record missing or wrong the plain sentence stands, and the pill shows
     the record's status. Off and no key yet say what the server keeps, whatever the record. */
  function dkimWhat(c, dk) { return dk === 'off' || dk === 'nokey' || c.status === 'ok' ? 'auth_dkim_' + dk + '_what' : 'auth_dkim_what'; }
  /* the terms of the SPF record shown under "Now" that Fix would not keep (with two SPF records, Fix writes the
     server's default record in place of both) */
  function spfDropped(c) {
    if (c.status === 'ok' || !c.have || !c.want) { return []; }
    var keep = c.want.split(/\s+/);
    return c.have.split(/\s+/).filter(function (term) {
      return term && !/^v=spf1$/i.test(term) && !/^[-+~?]?all$/i.test(term) && keep.indexOf(term) < 0;
    });
  }
  function pillOf(k, c, a) {
    var dk = k === 'dkim' ? dkimState(a) : '';
    if (dk === 'off') { return el('span', {class: 'sig-pill', text: t('auth_dkim_off')}); }
    if (dk === 'signing' && c.status === 'ok') { return el('span', {class: 'sig-pill sig-pill--ok', text: t('auth_dkim_signing')}); }
    if (dk === 'unsigned' && c.status === 'ok') { return el('span', {class: 'sig-pill sig-pill--warn', text: t('auth_dkim_unsigned')}); }
    if (dk === 'nokey') { return el('span', {class: 'sig-pill sig-pill--warn', text: t('auth_dkim_nokey')}); }
    return el('span', {class: 'sig-pill sig-pill--' + STATUS[c.status], text: t('auth_status_' + c.status)});
  }

  function zoneCard(z, i) {
    var id = 'fp-dlv-' + i + '-h';
    var parts = [el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': ''}), el('p', {class: 'fp-ok-line', role: 'status', 'data-fp-status': ''})];
    var head = el('div', {class: 'fp-dlv-head'}, [el('h2', {class: 'fp-h2', id: id, tabindex: '-1', text: z.zone}),
      z.auth ? el('span', {class: 'sig-pill sig-pill--' + (allOk(z.auth) ? 'ok' : 'warn'), text: allOk(z.auth) ? t('auth_all_ok') : t('auth_needs_work')}) : null]);
    if (!z.auth) {
      parts.push(el('p', {class: 'fp-muted', text: z.error}));
    } else {
      parts.push(el('dl', {class: 'fp-dlv-list'}, CHECKS.map(function (k) {
        var c = z.auth.checks[k];
        var dk = k === 'dkim' ? dkimState(z.auth) : '';
        /* off has no record to show; no key yet shows what Fix writes, once the server can say */
        var off = dk === 'off' || (dk === 'nokey' && !c.want);
        var dropped = k === 'spf' ? spfDropped(c) : [];
        return el('div', {class: 'fp-dlv-item', 'data-fp-check': k}, [
          el('dt', {class: 'fp-dlv-name'}, [el('span', {class: 'fp-dlv-label', text: t('auth_' + k)}), pillOf(k, c, z.auth)]),
          el('dd', {class: 'fp-dlv-detail'}, [el('p', {class: 'fp-muted fp-dlv-what', text: t(dk ? dkimWhat(c, dk) : 'auth_' + k + '_what')}),
            off ? null : c.status !== 'ok' ? el('div', {class: 'fp-dlv-vals'}, [
              el('span', {class: 'fp-dlv-k', text: t('auth_have')}), el('code', {class: 'sig-mono fp-dlv-v', text: c.have || t('auth_nothing')}),
              el('span', {class: 'fp-dlv-k', text: t('auth_want')}), el('code', {class: 'sig-mono fp-dlv-v', text: c.want || '—'})]) :
              el('div', {class: 'fp-dlv-vals'}, [el('span', {class: 'fp-dlv-k', text: t('auth_record')}), el('code', {class: 'sig-mono fp-dlv-v', text: c.have || '—'})]),
            dropped.length ? el('p', {class: 'fp-dlv-dropped', 'data-fp-dropped': ''}, [el('span', {text: t('auth_spf_dropped') + ' '}),
              el('code', {class: 'sig-mono', text: dropped.join(' ')})]) : null])]);
      })));
      if (!allOk(z.auth)) {
        parts.push(el('p', {class: 'fp-muted', text: t('auth_fix_desc')}));
        parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'fix',
          'aria-label': t('auth_fix_of', {zone: z.zone}), text: t('auth_fix')})]));
      }
    }
    return el('section', {class: 'sig-card fp-dlv-card', 'aria-labelledby': id, 'data-fp-zone': z.zone}, [el('div', {class: 'sig-card-body'}, [head].concat(parts))]);
  }
  function render() {
    page.textContent = '';
    if (!zones.length) {
      page.appendChild(FP.empty(t('auth_none_title'), t('auth_none')));
      return;
    }
    zones.forEach(function (z, i) { page.appendChild(zoneCard(z, i)); });
  }
  function checkZone(zone) {
    return FP.call('get', 'mailAuth', undefined, {name: account, zone: zone}).then(function (r) {
      return {zone: zone, auth: cleanAuth(r), error: ''};
    }, function (err) {
      return {zone: zone, auth: null, error: err.message};
    });
  }
  function cardOf(zone) { return page.querySelector('[data-fp-zone="' + window.CSS.escape(zone) + '"]'); }

  document.addEventListener('click', function (e) {
    var target = e.target.closest ? e.target : null;
    if (!target || !page || !page.contains(target)) { return; }
    var b = target.closest('[data-fp-act="fix"]');
    if (!b) { return; }
    var cardNode = b.closest('[data-fp-zone]');
    var zone = cardNode.getAttribute('data-fp-zone');
    var i = zones.map(function (z) { return z.zone; }).indexOf(zone);
    UI.showError(cardNode, '');
    UI.setBusy(b, true);
    FP.call('post', 'mailAuthFix', {serial: zones[i].auth.serial}, {name: account, zone: zone}).then(function (r) {
      zones[i] = {zone: zone, auth: cleanAuth(r), error: ''};
      render();
      var c = cardOf(zone);
      c.querySelector('[data-fp-status]').textContent = allOk(zones[i].auth) ? t('auth_fixed', {zone: zone}) : t('auth_fixed_some', {zone: zone});
      c.querySelector('h2').focus();
    }, function (err) {
      var changed = err && err.code === 'conflict';
      var again = changed ? checkZone(zone) : Promise.resolve(zones[i]);
      again.then(function (z) {
        zones[i] = z;
        render();
        var c = cardOf(zone);
        UI.showError(c, changed ? t('auth_changed') : err.message);
        var fix = c.querySelector('[data-fp-act="fix"]');
        (fix || c.querySelector('h2')).focus();
      });
    });
  });

  FP.view('tool:deliverability', function () {
    var tool = FP.tools.deliverability;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    account = FP.account();
    var body = FP.frame({title: tool.label, desc: t('deliverability_desc'), cls: 'fp-dlv',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'accountZones', undefined, account).then(function (r) {
      var names = (r && Array.isArray(r.zones) ? r.zones : []).map(function (z) { return z && str(z.zone); })
        .filter(function (z) { return DOMAIN_RE.test(z); });
      return Promise.all(names.map(checkZone));
    }).then(function (list) {
      if (page !== body) { return; }
      zones = list;
      render();
    }, function (err) {
      if (page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

/* freePanel account import (#/tool/import_archive), the admin panel's page for moving an account here from another
   panel's full-account backup (docs/api.md, "Accounts": imports). The admin copies the archive into /backup/import/
   on the server; this page lists what waits there, has one read, shows what reading found, and imports it on a
   package and owner the admin picks. Reading and importing share the one run slot with backups and restores, so
   the page asks the server every few seconds while one goes. Everything the archive says (names, plan, notes) is
   shown as text, never as markup: it comes from another server. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var USER_RE = /^[a-z][a-z0-9]{0,15}$/;
  var FILE_RE = /^[A-Za-z0-9.-]{1,255}$/;
  var PART_RE = /^[a-z0-9_-]{1,32}$/;
  var PARTS = ['home', 'web', 'mail', 'mysql', 'postgres', 'dns', 'cron'];
  var SHELLS = ['disabled', 'jailed', 'normal'];
  var POLL_MS = 3000;
  var UNITS = ['KB', 'MB', 'GB', 'TB', 'PB'];

  var I = null;

  function str(v) { return typeof v === 'string' ? v : ''; }
  function text(v, n) { return str(v).slice(0, n || 300); }
  function num(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? v : null; }
  function names(v, n) {
    return (Array.isArray(v) ? v : []).filter(function (x) { return typeof x === 'string' && x; }).slice(0, n || 500).map(function (x) { return x.slice(0, 300); });
  }
  function size(n) {
    if (n === null) { return '—'; }
    if (n < 1024) { return t('size_bytes', {n: String(Math.round(n))}); }
    var u = -1;
    do { n /= 1024; u++; } while (n >= 1024 && u < UNITS.length - 1);
    return (n < 10 ? n.toFixed(1) : Math.round(n).toLocaleString('en')) + ' ' + UNITS[u];
  }
  function when(iso) {
    var d = iso ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString(undefined, {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }
  function partName(p) { return PARTS.indexOf(p) >= 0 ? t('im_part_' + p) : p; }

  function cleanImports(r) {
    r = r && typeof r === 'object' ? r : {};
    var files = (Array.isArray(r.files) ? r.files : []).filter(function (f) { return f && FILE_RE.test(str(f.file)); }).map(function (f) {
      return {file: f.file, bytes: num(f.bytes), modified: str(f.modified)};
    });
    var read = null;
    var rd = r.read;
    if (rd && typeof rd === 'object' && FILE_RE.test(str(rd.file))) {
      var info = null;
      var v = rd.info;
      if (v && typeof v === 'object') {
        info = {username: text(v.username, 64), domain: text(v.domain, 253), domains: names(v.domains), email: text(v.contact_email, 254),
          password: v.password === 'kept' ? 'kept' : 'reset', shell: SHELLS.indexOf(v.shell) >= 0 ? v.shell : '', plan: text(v.plan, 128), files: num(v.home_files), bytes: num(v.home_bytes),
          crontab: v.crontab === true, zones: names(v.zones), databases: num(v.databases), skipped: names(v.skipped), conflict: text(v.conflict, 500)};
      }
      read = {file: rd.file, reading: rd.reading === true, ended: str(rd.ended), info: info, error: text(rd.error, 1024)};
    }
    return {files: files, read: read};
  }
  function cleanRun(v) {
    if (!v || typeof v !== 'object') { return null; }
    if (v.kind === 'import-read') { return FILE_RE.test(str(v.file)) ? {kind: v.kind, username: '', file: v.file} : null; }
    return USER_RE.test(str(v.username)) ? {kind: str(v.kind).slice(0, 32), username: v.username, file: ''} : null;
  }
  function cleanLast(v) {
    if (!v || typeof v !== 'object') { return null; }
    var failed = [];
    if (v.failed && typeof v.failed === 'object') {
      Object.keys(v.failed).sort().forEach(function (p) { if (PART_RE.test(p)) { failed.push(partName(p) + ' (' + text(v.failed[p], 1024) + ')'); } });
    }
    return {kind: str(v.kind), ended: str(v.ended), error: text(v.error, 1024), notes: names(v.notes, 50),
      restored: (Array.isArray(v.restored) ? v.restored : []).filter(function (p) { return PART_RE.test(str(p)); }).map(partName), failed: failed};
  }

  /* ---------- cards ---------- */
  function filesCard() {
    var parts = [M.errorLine(), el('p', {class: 'fp-muted'}, [t('im_files_desc_1') + ' ', el('code', {class: 'sig-mono', text: '/backup/import/'}),
      ' ' + t('im_files_desc_2')])];
    if (!I.files.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('im_no_files')}));
    } else {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-im-files-h'}, [
        el('table', {class: 'sig-table fp-mail-table fp-im-table'}, [el('thead', null, [el('tr', null, [
          el('th', {scope: 'col', text: t('im_file')}), el('th', {scope: 'col', class: 'fp-num', text: t('im_size')}),
          el('th', {scope: 'col', text: t('im_copied')}), el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]),
        el('tbody', null, I.files.map(function (f) {
          return el('tr', {'data-fp-file': f.file}, [el('th', {scope: 'row', class: 'fp-im-name'}, [el('span', {class: 'sig-mono', text: f.file})]),
            el('td', {class: 'fp-num', text: size(f.bytes)}), el('td', {class: 'fp-im-when', text: when(f.modified) || '—'}),
            el('td', {class: 'fp-mail-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'read',
              'aria-label': t('im_read_of', {file: f.file}), text: t('im_read')})])]);
        }))])]));
    }
    parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'refresh', text: t('im_refresh')})]));
    return M.card('fp-im-files-h', t('im_files_title'), parts, 'fp-im-files');
  }
  function nowCard() {
    var parts = [M.errorLine()];
    var run = I.running;
    var line = !run ? t('im_idle') : run.kind === 'import-read' ? t('im_running_import_read_now', {file: run.file}) :
      t('im_running_' + (['backup', 'restore', 'import'].indexOf(run.kind) >= 0 ? run.kind : 'other'), {account: run.username});
    parts.push(el('p', {'data-fp-im-running': '', class: run ? '' : 'fp-muted', text: line}));
    if (I.started) { parts.push(el('p', {'data-fp-im-started': '', text: I.started})); }
    if (I.result) { parts.push(el('p', {'data-fp-im-result': '', class: I.result.bad ? 'fp-im-bad' : '', text: I.result.text})); }
    return M.card('fp-im-now-h', t('im_now_title'), parts, 'fp-im-now');
  }
  function row(label, value, mono) {
    return [el('dt', {class: 'fp-im-k', text: label}), el('dd', {class: 'fp-im-v' + (mono ? ' sig-mono' : ''), text: value})];
  }
  function readCard() {
    var r = I.read;
    if (!r) { return null; }
    var parts = [M.errorLine()];
    if (r.reading) {
      parts.push(el('p', {'data-fp-im-reading': '', text: t('im_reading', {file: r.file})}));
      return M.card('fp-im-read-h', t('im_read_title', {file: r.file}), parts, 'fp-im-read');
    }
    if (r.error || !r.info) {
      parts.push(el('p', {class: 'fp-im-bad', 'data-fp-im-unreadable': '', text: t('im_unreadable', {when: when(r.ended) || '—'}) + ' ' + (r.error || t('im_no_info'))}));
      return M.card('fp-im-read-h', t('im_read_title', {file: r.file}), parts, 'fp-im-read');
    }
    var v = r.info;
    var dl = [];
    dl = dl.concat(row(t('im_username'), v.username || '—', true));
    dl = dl.concat(row(t('im_domain'), v.domain || '—', true));
    dl = dl.concat(row(t('im_domains'), v.domains.filter(function (d) { return d !== v.domain; }).join(', ') || t('im_none'), true));
    dl = dl.concat(row(t('im_email'), v.email || t('im_none')));
    dl = dl.concat(row(t('im_password'), t('im_password_' + v.password)));
    dl = dl.concat(row(t('im_shell'), t(v.shell ? 'im_shell_' + v.shell : 'im_shell_none')));
    dl = dl.concat(row(t('im_plan'), v.plan || t('im_none')));
    dl = dl.concat(row(t('im_home'), t('im_home_v', {n: v.files === null ? '—' : v.files.toLocaleString('en'), size: size(v.bytes)})));
    dl = dl.concat(row(t('im_crontab'), v.crontab ? t('im_yes') : t('im_no')));
    dl = dl.concat(row(t('im_zones'), v.zones.join(', ') || t('im_none'), true));
    dl = dl.concat(row(t('im_databases'), v.databases === null ? '—' : String(v.databases)));
    if (v.skipped.length) { dl = dl.concat(row(t('im_skipped'), v.skipped.join(', '), true)); }
    parts.push(el('p', {class: 'fp-muted', text: t('im_read_at', {when: when(r.ended) || '—'})}));
    parts.push(el('dl', {class: 'fp-im-facts', 'data-fp-im-info': ''}, dl));
    if (v.skipped.length) { parts.push(el('p', {class: 'fp-muted', text: t('im_skipped_note')})); }
    if (v.conflict) {
      parts.push(el('p', {class: 'fp-im-bad', 'data-fp-im-conflict': '', text: t('im_conflict') + ' ' + v.conflict}));
    } else {
      parts.push(importForm(r, v));
    }
    return M.card('fp-im-read-h', t('im_read_title', {file: r.file}), parts, 'fp-im-read');
  }
  function packagesOf(owner) {
    return I.packages.filter(function (p) { return p.owner === owner; }).map(function (p) { return p.name; });
  }
  function importForm(r, v) {
    var me = FP.session.user.username;
    var owner = el('select', {class: 'sig-select', id: 'fp-im-owner', name: 'owner'}, [me].concat(I.resellers).map(function (u) {
      return el('option', {value: u, text: u === me ? t('im_owner_me', {name: u}) : u});
    }));
    var pkg = el('select', {class: 'sig-select', id: 'fp-im-package', name: 'package'});
    function fill() {
      var list = packagesOf(owner.value);
      pkg.textContent = '';
      pkg.appendChild(el('option', {value: '', text: list.length ? t('im_package_pick') : t('im_package_none')}));
      list.forEach(function (n) { pkg.appendChild(el('option', {value: n, text: n, selected: n === v.plan ? true : null})); });
    }
    owner.addEventListener('change', fill);
    fill();
    var form = el('form', {class: 'fp-form fp-mail-form fp-im-form', novalidate: ''}, [M.errorLine(),
      el('h3', {class: 'fp-h3', text: t('im_import_title', {account: v.username})}),
      M.field('fp-im-owner', t('im_owner'), owner, t('im_owner_hint')),
      M.field('fp-im-package', t('im_package'), pkg, t('im_package_hint')),
      el('div', {class: 'fp-actions', 'data-fp-im-acts': ''})]);
    resetActs(form);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      if (!pkg.value) { M.fieldError(form, pkg, t('im_package_need')); return; }
      var body = {package: pkg.value};
      if (owner.value !== me) { body.owner = owner.value; }
      var acts = form.querySelector('[data-fp-im-acts]');
      acts.textContent = '';
      var yes = el('button', {class: 'sig-btn sig-btn--primary', type: 'button', text: t('im_import'), 'aria-describedby': 'fp-im-ask'});
      var no = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', text: t('cancel'), 'aria-describedby': 'fp-im-ask'});
      acts.appendChild(el('p', {class: 'fp-mail-confirm', id: 'fp-im-ask', text: t('im_ask', {account: v.username, domain: v.domain, package: body.package,
        owner: owner.value})}));
      acts.appendChild(yes);
      acts.appendChild(no);
      no.addEventListener('click', function () { resetActs(form); form.querySelector('.fp-submit').focus(); });
      yes.addEventListener('click', function () { send(form, yes, r.file, v.username, body); });
      no.focus();
    });
    return form;
  }
  function resetActs(form) {
    var acts = form.querySelector('[data-fp-im-acts]');
    acts.textContent = '';
    acts.appendChild(el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('im_import')}));
  }
  function send(form, yes, file, username, body) {
    UI.setBusy(yes, true);
    FP.call('post', 'importApply', body, {file: file}).then(function (r) {
      r = r && typeof r === 'object' ? r : {};
      var said = [t('im_started', {account: username})];
      if (r.password === 'reset') { said.push(t('im_started_reset', {account: username})); }
      var left = names(r.not_imported, 200);
      if (left.length) { said.push(t('im_not_imported', {names: left.join(', ')})); }
      I.running = cleanRun(r.run) || {kind: 'import', username: username, file: ''};
      I.watch = username;
      I.result = null;
      I.started = said.join(' ');
      I.read = null;
      render();
      I.page.querySelector('#fp-im-now-h').focus();
      UI.announce(I.started);
      poll();
    }, function (err) {
      resetActs(form);
      M.failed(form, err);
      if (!form.contains(document.activeElement)) { form.querySelector('.fp-submit').focus(); }
    });
  }

  /* ---------- page ---------- */
  function render() {
    I.page.textContent = '';
    I.page.appendChild(nowCard());
    var rc = readCard();
    if (rc) { I.page.appendChild(rc); }
    I.page.appendChild(filesCard());
  }
  function load() {
    return Promise.all([FP.call('get', 'imports'), FP.call('get', 'backupStatus')]).then(function (r) {
      var im = cleanImports(r[0]);
      I.files = im.files;
      I.read = im.read;
      I.running = cleanRun(r[1] && r[1].running);
    });
  }
  /* how the import of an account ended, from the status's last entry for it */
  function resultOf(username, st) {
    var l = cleanLast(st && st.last && st.last[username]);
    if (!l || l.kind !== 'import') { return {text: t('im_ended', {account: username}), bad: false}; }
    if (l.error) { return {text: t('im_failed', {account: username, error: l.error}), bad: true}; }
    var out = t('im_done', {account: username, parts: l.restored.join(', ') || t('im_parts_none')});
    if (l.failed.length) { out += ' ' + t('im_last_restore_some', {parts: l.failed.join('; ')}); }
    if (l.notes.length) { out += ' ' + t('im_last_notes', {notes: l.notes.join('; ')}); }
    return {text: out, bad: l.failed.length > 0};
  }
  /* while a run goes on (an archive being read or an import), asks every few seconds; when it ends, shows the result
     without moving the focus */
  function poll() {
    window.clearTimeout(I.timer);
    var page = I.page;
    I.timer = window.setTimeout(function () {
      if (!I || I.page !== page || !document.body.contains(page)) { return; }
      Promise.all([FP.call('get', 'imports'), FP.call('get', 'backupStatus')]).then(function (r) {
        if (I.page !== page) { return; }
        var running = cleanRun(r[1] && r[1].running);
        var im = cleanImports(r[0]);
        if (running || (im.read && im.read.reading)) {
          I.running = running;
          poll();
          return;
        }
        var had = page.contains(document.activeElement) ? document.activeElement : null;
        var act = had && had.getAttribute('data-fp-act');
        var row = act && had.closest('[data-fp-file]');
        var id = had && !act ? had.id : '';
        I.files = im.files;
        I.read = I.watch ? null : im.read;
        I.running = null;
        if (I.watch) { I.result = resultOf(I.watch, r[1]); I.watch = ''; }
        render();
        /* the focus stays where it was: on the same button, or on the same heading or field */
        var again = row ? page.querySelector('[data-fp-file="' + window.CSS.escape(row.getAttribute('data-fp-file')) + '"] [data-fp-act="' + act + '"]') :
          act ? page.querySelector('[data-fp-act="' + act + '"]') : id ? page.querySelector('#' + window.CSS.escape(id)) : null;
        if (again) { again.focus(); }
        if (I.result) { UI.announce(I.result.text); }
      }, function () { poll(); });
    }, POLL_MS);
  }

  function onClick(e) {
    var target = e.target.closest ? e.target : null;
    var b = target && I && I.page && I.page.contains(target) ? target.closest('[data-fp-act]') : null;
    if (!b) { return; }
    var a = b.getAttribute('data-fp-act');
    var cardNode = I.page.querySelector('.fp-im-files');
    if (a === 'read') {
      var file = b.closest('[data-fp-file]').getAttribute('data-fp-file');
      UI.showError(cardNode, '');
      UI.setBusy(b, true);
      FP.call('post', 'importRead', undefined, {file: file}).then(function () {
        I.read = {file: file, reading: true, ended: '', info: null, error: ''};
        I.running = {kind: 'import-read', username: '', file: file};
        I.result = null;
        I.started = '';
        render();
        I.page.querySelector('#fp-im-read-h').focus();
        poll();
      }, function (err) {
        UI.setBusy(b, false);
        UI.showError(cardNode, err.message);
        b.focus();
      });
    } else if (a === 'refresh') {
      UI.setBusy(b, true);
      load().then(function () {
        render();
        I.page.querySelector('.fp-im-files [data-fp-act="refresh"]').focus();
        if (I.running || (I.read && I.read.reading)) { poll(); }
      }, function (err) {
        UI.setBusy(b, false);
        UI.showError(cardNode, err.message);
        b.focus();
      });
    }
  }
  document.addEventListener('click', onClick);

  FP.view('tool:import_archive', function () {
    var tool = FP.tools.import_archive;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('im_desc'), cls: 'fp-mail fp-im',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    if (I) { window.clearTimeout(I.timer); }
    I = {page: body, files: [], read: null, running: null, result: null, started: '', watch: '', resellers: [], packages: [], timer: 0};
    var mine = I;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    var extra = Promise.all([FP.call('get', 'resellers').then(function (r) {
      return (r && Array.isArray(r.resellers) ? r.resellers : []).map(function (x) { return x && str(x.username); }).filter(function (u) { return USER_RE.test(u); }).sort();
    }, function () { return []; }), FP.call('get', 'packages').then(function (r) {
      return (r && Array.isArray(r.packages) ? r.packages : []).filter(function (p) { return p && str(p.name) && p.name.length <= 64; })
        .map(function (p) { return {name: p.name, owner: str(p.owner)}; }).sort(function (a, b) { return a.name < b.name ? -1 : 1; });
    }, function () { return []; })]);
    Promise.all([load(), extra]).then(function (r) {
      if (I !== mine) { return; }
      I.resellers = r[1][0];
      I.packages = r[1][1];
      render();
      if (I.running || (I.read && I.read.reading)) { poll(); }
    }, function (err) {
      if (I !== mine) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

/* freePanel database wizard (docs/api.md, "Create a database and a user"): a card at the top of the customer panel's MariaDB and
   PostgreSQL pages (fp-databases.js) that makes a database, its user and the user's access in one step. The customer names the
   database; the user's name follows it until they type one of their own; a strong password is made for them (or they type theirs);
   MariaDB gives all privileges unless they choose fewer, PostgreSQL the full level unless they choose another. One request makes all
   three, and the server takes back what it made when a later step fails. The end shows how a site connects (host, port, database,
   user and, this once, the password), each ready to copy. Everything the server sends is cleaned and shown as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;

  var NAME_RE = /^[a-z][a-z0-9]{0,15}_[a-z0-9_]{1,80}$/;
  var PRIV_RE = /^[A-Z][A-Z ]{1,40}$/;
  var LEVELS = ['full', 'readwrite', 'read'];
  var ALL = 'ALL PRIVILEGES';
  /* the default ports of the two servers, used when the answer names none that makes sense */
  var PORTS = {mysql: 3306, postgres: 5432};

  /* W is the wizard while the page is open: whether it shows, what was typed (kept across the page's redraws), whether the
     user's name was typed by hand, the last error, and the result of a setup until the customer closes it */
  var W = null;
  function fresh(engine, open) {
    return {engine: engine, open: open, db: '', user: '', userOwn: false, password: '', shown: false, all: true, privs: [], level: 'full',
      error: '', errorField: '', busy: false, result: null};
  }

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 200) : ''; }
  /* 20 characters a shell, a URL, a config file and PostgreSQL all take as they are, with a lowercase and an uppercase letter, a
     digit and a symbol in each, so a server whose admin asks for every kind takes it */
  var GEN = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789-_.+=';
  var KINDS = [/[a-z]/, /[A-Z]/, /[0-9]/, /[-_.+=]/];
  function generate() {
    var buf = new Uint8Array(1);
    for (;;) {
      var out = '';
      while (out.length < 20) {
        window.crypto.getRandomValues(buf);
        if (buf[0] < 256 - (256 % GEN.length)) { out += GEN.charAt(buf[0] % GEN.length); }
      }
      if (KINDS.every(function (k) { return k.test(out); })) { return out; }
    }
  }
  function suffixOf(v, prefix) {
    v = String(v || '').trim().toLowerCase();
    return v.indexOf(prefix) === 0 ? v.slice(prefix.length) : v;
  }

  function errorLine() { return el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': ''}); }
  function statusLine() { return el('p', {class: 'fp-ok-line', role: 'status', 'data-fp-status': ''}); }
  function say(scope, text) {
    var s = scope && scope.querySelector('[data-fp-status]');
    if (s) { s.textContent = text || ''; }
  }

  /* one numbered step of the form */
  function step(n, id, title, children) {
    return el('li', {class: 'fp-dbw-step'}, [el('span', {class: 'fp-dbw-num', 'aria-hidden': 'true', text: String(n)}),
      el('fieldset', {class: 'fp-dbw-set', 'aria-labelledby': id}, [el('legend', {class: 'fp-dbw-legend', id: id, text: title})].concat(children))]);
  }
  function prefixed(id, name, label, value, maxSuffix, hint, prefix) {
    return el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: id, text: label}),
      el('div', {class: 'fp-db-prefixed'}, [el('span', {class: 'fp-db-prefix sig-mono', 'aria-hidden': 'true', text: prefix}),
        el('input', {class: 'sig-input sig-mono', id: id, name: name, type: 'text', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none',
          maxlength: String(Math.max(1, maxSuffix)), value: value, 'aria-describedby': id + '-hint'})]),
      el('span', {class: 'sig-hint', id: id + '-hint', text: hint})]);
  }

  /* ---- the form ---- */
  function formView(ctx, w) {
    var pg = ctx.engine === 'postgres';
    var prefix = ctx.prefix;
    var dbMax = ctx.maxDb - prefix.length;
    var userMax = ctx.maxUser - prefix.length;
    var eye = UI.icon(FP.ui, w.shown ? 'ui_eye_slash' : 'ui_eye');
    var pwInput = el('input', {class: 'sig-input sig-mono', id: 'fp-dbw-pw', name: 'password', type: w.shown ? 'text' : 'password', autocomplete: 'new-password',
      spellcheck: 'false', autocapitalize: 'none', minlength: '12', maxlength: '1024', value: w.password, 'aria-describedby': 'fp-dbw-pw-hint'});
    var access;
    if (pg) {
      access = el('div', {class: 'fp-dbw-levels'}, LEVELS.map(function (l) {
        var id = 'fp-dbw-level-' + l;
        return el('div', {class: 'fp-dbw-choice'}, [el('label', {class: 'fp-check', for: id}, [
          el('input', {type: 'radio', id: id, name: 'level', value: l, checked: w.level === l ? true : null, 'aria-describedby': id + '-hint'}),
          el('span', {text: t('dbw_level_' + l)})]), el('span', {class: 'sig-hint', id: id + '-hint', text: t('dbw_level_' + l + '_hint')})]);
      }));
    } else {
      var grid = el('div', {class: 'fp-db-privgrid fp-dbw-privgrid', 'data-fp-dbw-privs': '', hidden: w.all ? true : null}, ctx.privileges.map(function (p) {
        return el('label', {class: 'fp-check'}, [el('input', {type: 'checkbox', name: 'privilege', value: p, checked: w.privs.indexOf(p) >= 0 ? true : null}),
          el('span', {class: 'sig-mono', text: p})]);
      }));
      access = el('div', null, [el('label', {class: 'fp-check fp-check--all'}, [el('input', {type: 'checkbox', name: 'privileges', checked: w.all ? true : null,
        'aria-describedby': 'fp-dbw-all-hint'}), el('span', {text: t('dbw_all')})]),
      el('span', {class: 'sig-hint fp-dbw-all-hint', id: 'fp-dbw-all-hint', text: t('dbw_all_hint')}), grid]);
    }
    var submit = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('dbw_submit')});
    var form = el('form', {class: 'fp-form fp-dbw-form', novalidate: ''}, [errorLine(), statusLine(),
      el('ol', {class: 'fp-dbw-steps'}, [
        step(1, 'fp-dbw-s1', t('dbw_step_db'), [prefixed('fp-dbw-db', 'database', t('dbw_db_label'), w.db, dbMax, t('dbw_db_hint', {prefix: prefix}), prefix)]),
        step(2, 'fp-dbw-s2', t('dbw_step_user'), [prefixed('fp-dbw-user', 'user', t('dbw_user_label'), w.user, userMax, t('dbw_user_hint'), prefix)]),
        step(3, 'fp-dbw-s3', t('dbw_step_pw'), [el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: 'fp-dbw-pw', text: t('dbw_pw_label')}),
          el('div', {class: 'fp-dbw-pwrow'}, [el('div', {class: 'fp-reveal-wrap'}, [pwInput,
            el('button', {class: 'sig-ghost fp-reveal', type: 'button', 'data-overlap-ok': '', 'data-fp-reveal': 'fp-dbw-pw', 'aria-pressed': String(w.shown),
              'aria-label': t('dbw_show_pw')}, [eye])]),
          el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'dbw-generate', text: t('dbw_generate')})]),
          el('span', {class: 'sig-hint', id: 'fp-dbw-pw-hint', text: t(pg ? 'dbw_pw_hint_pg' : 'dbw_pw_hint')})])]),
        step(4, 'fp-dbw-s4', t('dbw_step_access'), [access])]),
      el('div', {class: 'fp-actions'}, [submit,
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'dbw-cancel', text: t('cancel')})])]);
    if (w.busy) { UI.setBusy(submit, true); }
    if (w.error) {
      UI.showError(form, w.error);
      var bad = w.errorField ? UI.fieldNamed(form, w.errorField) : null;
      if (bad) { bad.setAttribute('aria-invalid', 'true'); }
    }

    form.addEventListener('input', function (e) {
      var f = e.target;
      if (f.name === 'database') {
        w.db = f.value;
        /* the user's name follows the database's until the customer types one of their own */
        if (!w.userOwn) {
          w.user = suffixOf(f.value, prefix).slice(0, Math.max(0, userMax));
          form.querySelector('[name="user"]').value = w.user;
        }
      } else if (f.name === 'user') {
        w.user = f.value;
        w.userOwn = f.value.trim() !== '';
      } else if (f.name === 'password') {
        w.password = f.value;
      }
    });
    /* whether the password shows is kept for the next drawing; fp-ui.js turns it after this listener */
    form.addEventListener('click', function (e) {
      if (e.target.closest && e.target.closest('[data-fp-reveal]')) {
        window.setTimeout(function () { w.shown = pwInput.type === 'text'; }, 0);
      }
    });
    form.addEventListener('change', function (e) {
      var f = e.target;
      if (f.name === 'level') {
        w.level = f.value;
      } else if (f.name === 'privileges') {
        w.all = f.checked;
        var g = form.querySelector('[data-fp-dbw-privs]');
        g.hidden = w.all;
        if (!w.all && !w.privs.length) {
          /* opening the list starts from the usual set for a site, so the customer takes away rather than adds */
          w.privs = ctx.privileges.filter(function (p) { return ['SELECT', 'INSERT', 'UPDATE', 'DELETE'].indexOf(p) >= 0; });
          var boxes = g.querySelectorAll('[name="privilege"]');
          for (var i = 0; i < boxes.length; i++) { boxes[i].checked = w.privs.indexOf(boxes[i].value) >= 0; }
        }
      } else if (f.name === 'privilege') {
        var on = form.querySelectorAll('[name="privilege"]:checked');
        w.privs = [];
        for (var j = 0; j < on.length; j++) { w.privs.push(on[j].value); }
      }
    });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (w.busy) { return; }
      submitForm(ctx, w, form, submit);
    });
    return form;
  }

  function fieldError(form, f, message) {
    UI.showError(form, message);
    if (f) {
      f.setAttribute('aria-invalid', 'true');
      f.focus({preventScroll: true});
    }
    var line = form.querySelector('[data-fp-error]');
    if (line && line.scrollIntoView) { line.scrollIntoView({block: 'nearest'}); }
  }
  /* the checks the server makes, here first, so the customer is told at once and which field */
  function check(ctx, w, form) {
    var prefix = ctx.prefix;
    var names = [['database', ctx.maxDb, 'dbw_need_db'], ['user', ctx.maxUser, 'dbw_need_user']];
    var out = {};
    for (var i = 0; i < names.length; i++) {
      var f = UI.fieldNamed(form, names[i][0]);
      var v = suffixOf(f.value, prefix);
      if (!v) { fieldError(form, f, t(names[i][2])); return null; }
      if (!/^[a-z0-9_]+$/.test(v)) { fieldError(form, f, t('db_bad_name')); return null; }
      if ((prefix + v).length > names[i][1]) { fieldError(form, f, t('db_long_name', {n: names[i][1] - prefix.length})); return null; }
      out[names[i][0]] = prefix + v;
    }
    var p = UI.fieldNamed(form, 'password');
    if (p.value.length < 12) { fieldError(form, p, t('db_short_password')); return null; }
    if (ctx.engine === 'postgres' && !/^[\x20-\x7e]+$/.test(p.value)) { fieldError(form, p, t('db_ascii_password')); return null; }
    out.password = p.value;
    if (ctx.engine === 'postgres') {
      out.level = LEVELS.indexOf(w.level) >= 0 ? w.level : 'full';
    } else {
      out.privileges = w.all ? [ALL] : w.privs.slice();
      if (!out.privileges.length) { fieldError(form, UI.fieldNamed(form, 'privilege'), t('db_pick_privilege')); return null; }
    }
    return out;
  }
  function submitForm(ctx, w, form, submit) {
    UI.showError(form, '');
    say(form, '');
    w.error = '';
    w.errorField = '';
    var bad = form.querySelectorAll('[aria-invalid]');
    for (var i = 0; i < bad.length; i++) { bad[i].removeAttribute('aria-invalid'); }
    var body = check(ctx, w, form);
    if (!body) { return; }
    w.busy = true;
    UI.setBusy(submit, true);
    ctx.call('post', 'Setup', body).then(function (r) {
      w.busy = false;
      if (W !== w) { return; }
      w.result = cleanResult(ctx, r, body);
      w.password = '';
      w.db = '';
      w.user = '';
      w.userOwn = false;
      ctx.refresh('fp-dbw-done-h', '');
      UI.announce(t('dbw_done_status', {db: w.result.database, user: w.result.user}));
    }, function (err) {
      w.busy = false;
      if (W !== w) { return; }
      UI.setBusy(submit, false);
      var field = err && typeof err.field === 'string' ? err.field : '';
      w.error = err && err.message ? err.message : t('api_failed');
      w.errorField = field;
      if (err && err.status >= 500) {
        /* the server may have kept something it could not take back: the lists are read again, so it shows there */
        ctx.refresh('fp-dbw-h', '');
        return;
      }
      var f = field ? UI.fieldNamed(form, field) : null;
      var label = f && f.id ? form.querySelector('label[for="' + f.id + '"]') : null;
      fieldError(form, f, (label ? label.textContent + ': ' : '') + w.error);
    });
  }
  /* what the server made: its names when they are names, the port when it is one, the password the customer sent */
  function cleanResult(ctx, r, sent) {
    r = r && typeof r === 'object' ? r : {};
    var port = typeof r.port === 'number' && r.port > 0 && r.port < 65536 ? Math.floor(r.port) : PORTS[ctx.engine];
    var host = /^[A-Za-z0-9.-]{1,253}$/.test(str(r.host, 253)) ? r.host : 'localhost';
    var access;
    if (ctx.engine === 'postgres') {
      access = t('dbw_level_' + (LEVELS.indexOf(r.level) >= 0 ? r.level : sent.level));
    } else {
      var privs = (Array.isArray(r.privileges) ? r.privileges : sent.privileges).filter(function (p) { return typeof p === 'string' && PRIV_RE.test(p); });
      access = !privs.length || privs.indexOf(ALL) >= 0 ? t('db_all_privileges') : privs.join(', ');
    }
    return {database: NAME_RE.test(str(r.database)) ? r.database : sent.database, user: NAME_RE.test(str(r.user)) ? r.user : sent.user,
      host: host, port: port, password: sent.password, access: access};
  }

  /* ---- the result: how to connect ---- */
  function row(label, value, key, secret) {
    return el('div', {class: 'fp-dbw-fact', 'data-fp-dbw-fact': key}, [el('dt', {text: label}),
      el('dd', null, [el('span', {class: 'sig-mono fp-dbw-value' + (secret ? ' fp-dbw-secret' : ''), text: value}),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-dbw-copy', type: 'button', 'data-fp-act': 'dbw-copy', 'data-fp-copy': value,
          'aria-label': t('dbw_copy_of', {what: label})}, [UI.icon(FP.ui, 'ui_copy'), el('span', {text: t('dbw_copy')})])])]);
  }
  function doneView(ctx, w) {
    var r = w.result;
    var all = [t('dbw_f_host') + ': ' + r.host, t('dbw_f_port') + ': ' + r.port, t('dbw_f_db') + ': ' + r.database, t('dbw_f_user') + ': ' + r.user,
      t('dbw_f_pw') + ': ' + r.password].join('\n');
    return el('div', {class: 'fp-dbw-done'}, [
      el('p', {class: 'fp-dbw-lead'}, [UI.icon(FP.ui, 'ui_check', 'fp-dbw-ok'), el('span', {text: t('dbw_done_lead', {db: r.database, user: r.user})})]),
      el('dl', {class: 'fp-dbw-facts'}, [row(t('dbw_f_host'), r.host, 'host'), row(t('dbw_f_port'), String(r.port), 'port'),
        row(t('dbw_f_db'), r.database, 'database'), row(t('dbw_f_user'), r.user, 'user'), row(t('dbw_f_pw'), r.password, 'password', true)]),
      el('p', {class: 'fp-muted fp-dbw-access', text: t('dbw_f_access', {access: r.access})}),
      el('div', {class: 'sig-banner sig-banner--warn fp-dbw-once', role: 'note'}, [UI.icon(FP.ui, 'ui_warning'),
        el('p', {text: t('dbw_once')})]),
      el('div', {class: 'fp-actions'}, [
        el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'dbw-copy', 'data-fp-copy': all}, [UI.icon(FP.ui, 'ui_copy'), el('span', {text: t('dbw_copy_all')})]),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'dbw-another', text: t('dbw_another')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'dbw-close', text: t('dbw_close')})]),
      statusLine()]);
  }

  /* ---- the card ---- */
  /* ctx is {engine ('mysql' or 'postgres'), prefix, privileges, maxDb, maxUser, empty (no databases yet), call(), refresh(focusId, text)}
     from fp-databases.js */
  function card(ctx) {
    if (!W || W.engine !== ctx.engine) { W = fresh(ctx.engine, ctx.empty); }
    var w = W;
    if (w.open && !w.result && !w.password && !w.error) {
      w.password = generate();
      w.shown = true;
    }
    var head = el('div', {class: 'fp-db-head'}, [el('h2', {class: 'fp-h2', id: w.result ? 'fp-dbw-done-h' : 'fp-dbw-h', tabindex: '-1',
      text: w.result ? t('dbw_done_title') : t('dbw_title')})]);
    var body = [head];
    if (w.result) {
      body.push(doneView(ctx, w));
    } else if (w.open) {
      body.push(el('p', {class: 'fp-muted fp-dbw-intro', text: t('dbw_intro')}));
      body.push(formView(ctx, w));
    } else {
      body.push(el('div', {class: 'fp-dbw-closed'}, [el('p', {class: 'fp-muted', text: t('dbw_teaser')}),
        el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'dbw-open', 'aria-describedby': 'fp-dbw-h'}, [
          UI.icon(FP.sprite, 'grp_databases', 'fp-dbw-start-ico'), el('span', {text: t('dbw_start')})])]));
    }
    return el('section', {class: 'sig-card fp-db-card fp-dbw' + (w.open || w.result ? ' is-open' : ''), 'aria-labelledby': w.result ? 'fp-dbw-done-h' : 'fp-dbw-h'},
      [el('div', {class: 'sig-card-body'}, body)]);
  }

  /* the card's buttons; returns true when it handled the click. focus(id) moves the keys after the page is drawn again. */
  function click(ctx, b) {
    var a = b.getAttribute('data-fp-act');
    var w = W;
    if (!w || a.indexOf('dbw-') !== 0) { return false; }
    var scope = b.closest('.fp-dbw');
    if (a === 'dbw-open' || a === 'dbw-another') {
      /* each run starts from the usual choices, with a new password */
      W = fresh(w.engine, true);
      ctx.render();
      var first = ctx.page.querySelector('#fp-dbw-db');
      if (first) { first.focus(); }
    } else if (a === 'dbw-cancel' || a === 'dbw-close') {
      W = fresh(w.engine, false);
      ctx.render();
      var back = ctx.page.querySelector('[data-fp-act="dbw-open"]');
      if (back) { back.focus(); }
    } else if (a === 'dbw-generate') {
      var p = scope.querySelector('#fp-dbw-pw');
      w.password = generate();
      w.shown = true;
      p.value = w.password;
      p.removeAttribute('aria-invalid');
      var eye = scope.querySelector('[data-fp-reveal="fp-dbw-pw"]');
      if (eye && eye.getAttribute('aria-pressed') !== 'true') { eye.click(); }
      UI.announce(t('dbw_generated'));
      p.focus();
      p.select();
    } else if (a === 'dbw-copy') {
      var text = b.getAttribute('data-fp-copy');
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(function () { say(scope, t('copied')); }, function () { say(scope, t('copy_failed')); });
      } else {
        say(scope, t('copy_failed'));
      }
    }
    return true;
  }

  /* leaving the page forgets the wizard, and with it the password shown at its end */
  function reset() { W = null; }

  FP.dbWizard = {card: card, click: click, reset: reset};
})();

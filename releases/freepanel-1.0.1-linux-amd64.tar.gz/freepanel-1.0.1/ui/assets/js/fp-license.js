/* freePanel licence (#/tool/licence), the admin panel's Licence page (docs/api.md, "Licence"), the lock screen every login sees
   while the panel is locked, and the banner the administrator sees in grace. The page shows what the licence service has said
   about this server, checks again on request, and takes a key. Everything the server sends is drawn as text. The shell shows
   the lock screen (FP.locked, from the session) in place of every view: the administrator's is the Licence page with a note on
   top, anyone else's a plain "unavailable". Hosting is never locked, and the screens say so. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var STATES = ['unenforced', 'unlicensed', 'licensed', 'grace', 'locked'];
  var REASONS = ['no_key', 'no_lease', 'lease_ended', 'suspended', 'revoked', 'expired', 'in_use', 'unknown'];
  var KEY_RE = /^FP1\.[A-Za-z0-9_-]{1,64}\.[A-Za-z0-9_-]{1,4096}\.[A-Za-z0-9_-]{1,1024}$/;
  var DAY = 86400000;

  var V = null;   /* the page being shown: its body, what the server last said and whether a call is out */

  /* the daemon's own words, which start in lower case */
  function sentence(m) { return typeof m === 'string' && m ? m.charAt(0).toUpperCase() + m.slice(1) : m; }
  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function stamp(iso) {
    var d = typeof iso === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(iso) ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) && d.getFullYear() > 2000 ? d : null;
  }
  function when(d) { return d ? d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'}) : t('lic_never'); }
  function day(d) { return d.toLocaleString('en', {dateStyle: 'medium'}); }

  /* the licence status, or null when the answer is not one */
  function clean(r) {
    if (!r || typeof r !== 'object' || STATES.indexOf(r.state) < 0) { return null; }
    return {enforced: r.enforced === true, state: r.state, reason: REASONS.indexOf(r.reason) >= 0 || r.reason === 'upgrade' ? r.reason : '',
      id: str(r.license_id, 80), customer: str(r.customer, 120), plan: str(r.plan, 40), validUntil: stamp(r.valid_until), graceUntil: stamp(r.grace_until),
      lastCheck: stamp(r.last_check), lastOk: stamp(r.last_ok), lastError: str(r.last_error, 300), message: str(r.message, 300), serverId: str(r.server_id, 80),
      clockOff: r.clock_off === true};
  }

  /* what the state says in a sentence */
  function say(s) {
    if (s.state === 'unenforced') { return t('lic_say_unenforced'); }
    if (s.state === 'licensed') { return t('lic_say_licensed'); }
    if (s.state === 'grace') {
      if (s.reason === 'upgrade') { return t(s.graceUntil ? 'lic_say_upgrade' : 'lic_say_upgrade_nodate', {until: when(s.graceUntil)}); }
      return t(s.graceUntil ? 'lic_say_grace' : 'lic_say_grace_nodate', {until: when(s.graceUntil)});
    }
    var why = REASONS.indexOf(s.reason) >= 0 ? t('lic_reason_' + s.reason) : '';
    return (why ? why + ' ' : '') + t(s.state === 'unlicensed' ? 'lic_say_unlicensed' : 'lic_say_locked');
  }
  function pill(s) {
    var cls = s.state === 'licensed' ? ' sig-pill--ok' : s.state === 'grace' ? ' sig-pill--warn' : s.state === 'locked' || s.state === 'unlicensed' ? ' sig-pill--danger' : '';
    return el('span', {class: 'sig-pill' + cls, 'data-fp-state': s.state, text: t('lic_state_' + s.state)});
  }

  /* ---- the status ---- */
  function facts(s) {
    var rows = [];
    if (s.customer) { rows.push(['customer', t('lic_f_customer'), s.customer]); }
    if (s.plan) { rows.push(['plan', t('lic_f_plan'), s.plan]); }
    if (s.id) { rows.push(['id', t('lic_f_id'), s.id]); }
    if (s.enforced) {
      rows.push(['valid', t('lic_f_valid'), s.validUntil ? when(s.validUntil) : '—']);
      if (s.graceUntil) { rows.push(['grace', t(s.reason === 'upgrade' ? 'lic_f_grace_upgrade' : 'lic_f_grace'), when(s.graceUntil)]); }
      rows.push(['check', t('lic_f_check'), when(s.lastCheck)], ['ok', t('lic_f_ok'), when(s.lastOk)]);
    }
    if (s.serverId) { rows.push(['server', t('lic_f_server'), s.serverId]); }
    return el('dl', {class: 'fp-mail-facts fp-lic-facts'}, rows.reduce(function (out, r) {
      return out.concat([el('dt', {text: r[1]}), el('dd', {'data-fp-fact': r[0], text: r[2]})]);
    }, []));
  }
  function statusCard() {
    var s = V.status;
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-lic-state'}, [pill(s), el('span', {'data-fp-say': '', text: ' ' + say(s)})])];
    if (s.state !== 'unenforced' && s.state !== 'licensed') { parts.push(el('p', {class: 'fp-muted', 'data-fp-runs': '', text: t('lic_hosting_runs')})); }
    parts.push(facts(s));
    if (s.lastError) { parts.push(el('p', {class: 'fp-warn-line', 'data-fp-last-error': '', text: t('lic_last_error', {error: s.lastError})})); }
    if (s.clockOff) { parts.push(el('p', {class: 'fp-warn-line', 'data-fp-clock': '', text: t('lic_clock_off')})); }
    if (s.message) { parts.push(el('p', {class: 'fp-muted', 'data-fp-message': '', text: t('lic_message', {message: s.message})})); }
    if (s.enforced && s.id) {
      parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'check', text: t('lic_check')})]));
    }
    return M.card('fp-lic-h', t('lic_status_title'), parts, 'fp-lic');
  }

  /* ---- the key ---- */
  /* when a key ends, read from the key itself (its middle part is the signed text, which says it); null when it can't be read.
     The server decides what a key is worth: this only keeps an old key, from before a renewal, from being sent at all. */
  function keyEnds(key) {
    try {
      var b = key.split('.')[2].replace(/-/g, '+').replace(/_/g, '/');
      while (b.length % 4) { b += '='; }
      var raw = window.atob(b);
      var bytes = new window.Uint8Array(raw.length);
      for (var i = 0; i < raw.length; i++) { bytes[i] = raw.charCodeAt(i); }
      var j = JSON.parse(new window.TextDecoder().decode(bytes));
      return j && typeof j === 'object' ? stamp(j.expires) : null;
    } catch (e) {
      return null;
    }
  }
  function keyCard() {
    var s = V.status;
    var has = Boolean(s.id);
    var area = el('textarea', {class: 'sig-input fp-lic-key', id: 'fp-lic-key', name: 'key', rows: '4', maxlength: '6000', autocomplete: 'off',
      spellcheck: 'false', autocapitalize: 'none', disabled: V.busy ? true : null});
    var form = el('form', {class: 'fp-form fp-lic-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-lic-key', t('lic_key_label'), area, t('lic_key_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('lic_key_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || V.busy) { return; }
      var key = area.value.replace(/\s+/g, '');
      if (!key) { M.fieldError(form, area, t('lic_key_none')); return; }
      if (!KEY_RE.test(key)) { M.fieldError(form, area, t('lic_key_bad')); return; }
      var ends = keyEnds(key);
      if (ends && ends.getTime() < Date.now() - DAY) { M.fieldError(form, area, t('lic_key_ended', {date: day(ends)})); return; }
      save(form, b, key);
    });
    return M.card('fp-lic-key-h', t(has ? 'lic_key_title_change' : 'lic_key_title'), [el('p', {class: 'fp-muted', text: t(has ? 'lic_key_desc_change' : 'lic_key_desc')}), form],
      'fp-lic-keycard');
  }
  function save(form, b, key) {
    var mine = V;
    V.busy = true;
    UI.setBusy(b, true);
    M.say(form, t('lic_key_working'));
    FP.call('put', 'licenseKey', {key: key}).then(function (r) {
      if (V !== mine) { return; }
      mine.busy = false;
      var s = clean(r);
      if (!s) { UI.setBusy(b, false); M.say(form, ''); M.fieldError(form, null, t('api_failed')); return; }
      mine.status = s;
      /* the key is not kept on the page: the box is made again, empty */
      if (FP.locked && !closes(s)) { window.location.reload(); return; }
      setBanner(s);
      draw(t('lic_key_saved', {say: say(s)}), '.fp-lic-keycard');
    }, function (err) {
      if (V !== mine) { return; }
      mine.busy = false;
      UI.setBusy(b, false);
      M.say(form, '');
      M.fieldError(form, err.field === 'key' ? UI.fieldNamed(form, 'key') : null, sentence(err.message));
    });
  }

  /* ---- the page ---- */
  /* the panel is shut by this status (docs/api.md: locked and unlicensed) */
  /* freePanel's own terms and the third-party software in it: the notices file the build puts beside the panels' assets
     (and the installer in /usr/local/freepanel/share/doc). */
  function noticesCard() {
    return M.card('fp-lic-tp-h', t('lic_tp_title'), [el('p', {class: 'fp-muted', text: t('lic_tp_desc')}),
      el('p', null, [el('a', {href: '/assets/THIRD_PARTY_NOTICES.txt', target: '_blank', rel: 'noopener', 'data-fp-notices': '', text: t('lic_tp_link')})])],
      'fp-lic-tp');
  }
  function closes(s) { return s.enforced && (s.state === 'locked' || s.state === 'unlicensed'); }
  function lockNote() {
    return el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-lock-note': ''}, [UI.icon(FP.ui, 'ui_warning'),
      el('span', {text: t('lic_lock_note') + ' ' + t('lic_hosting_runs')})]);
  }
  function draw(note, scope) {
    V.page.textContent = '';
    if (V.locked || closes(V.status)) { V.page.appendChild(lockNote()); }
    V.page.appendChild(statusCard());
    if (V.status.enforced || V.status.state !== 'unenforced') { V.page.appendChild(keyCard()); }
    V.page.appendChild(noticesCard());
    if (note) {
      var card = V.page.querySelector(scope || '.fp-lic');
      M.say(card, note);
    }
  }
  function check(button) {
    var mine = V;
    var card = V.page.querySelector('.fp-lic');
    V.busy = true;
    UI.setBusy(button, true);
    UI.showError(card, '');
    M.say(card, t('lic_check_working'));
    FP.call('post', 'licenseCheck', {}).then(function (r) {
      if (V !== mine) { return; }
      mine.busy = false;
      var s = clean(r);
      if (!s) { UI.setBusy(button, false); M.say(card, ''); UI.showError(card, t('api_failed')); return; }
      mine.status = s;
      if (FP.locked && !closes(s)) { window.location.reload(); return; }
      setBanner(s);
      draw(t('lic_checked', {say: say(s)}));
      var again = mine.page.querySelector('[data-fp-act="check"]');
      if (again) { again.focus(); }
    }, function (err) {
      if (V !== mine) { return; }
      mine.busy = false;
      UI.setBusy(button, false);
      M.say(card, '');
      UI.showError(card, sentence(err.message));
      button.focus();
    });
  }
  function show(locked) {
    var tool = FP.tools.licence;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var mine = {page: null, status: null, busy: false, locked: Boolean(locked)};
    V = mine;
    mine.page = FP.frame({title: tool.label, desc: t('lic_desc'), cls: 'fp-mail fp-licence',
      crumbs: locked ? [] : [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    mine.page.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('[data-fp-act="check"]') : null;
      if (b && V === mine && !mine.busy) { check(b); }
    });
    mine.page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'license').then(function (r) {
      if (V !== mine) { return; }
      mine.status = clean(r);
      mine.page.textContent = '';
      if (!mine.status) { mine.page.appendChild(FP.empty(tool.label, t('api_failed'))); return; }
      draw('');
    }, function (err) {
      if (V !== mine) { return; }
      mine.page.textContent = '';
      mine.page.appendChild(FP.empty(tool.label, sentence(err.message)));
    });
  }
  FP.view('tool:licence', function () { show(false); });

  /* ---- the lock screen: the administrator's is the Licence page, everyone else's says to ask the host ---- */
  FP.view('license-lock', function () {
    if (FP.realm === 'admin' && FP.session.user.role === 'admin' && FP.tools.licence) { show(true); return; }
    var page = FP.frame({title: t('lic_lock_title'), desc: '', cls: 'fp-licence'});
    page.appendChild(M.card('fp-lic-lock-h', t('lic_lock_head'), [el('p', {'data-fp-lock': '', text: t('lic_lock_text')})], 'fp-lic-lock'));
  });

  /* ---- grace: a banner on every page, with the date the panel locks, for the administrator ---- */
  function makeBanner(s) {
    return el('div', {class: 'sig-banner sig-banner--warn fp-lic-banner', role: 'note', 'data-fp-grace': ''}, [UI.icon(FP.ui, 'ui_warning'),
      el('span', null, [t((s.reason === 'upgrade' ? 'lic_banner_upgrade' : 'lic_banner_grace') + (s.graceUntil ? '' : '_nodate'), {until: when(s.graceUntil)}), ' ',
        t('lic_hosting_runs'), ' ', FP.tools.licence && window.location.hash !== '#/tool/licence' ? el('a', {href: '#/tool/licence', text: t('lic_banner_link')}) : null])]);
  }
  /* what the administrator last heard: the banner on the page and on every page after it follows */
  function setBanner(s) {
    var shown = document.querySelectorAll('[data-fp-grace]');
    for (var i = 0; i < shown.length; i++) { shown[i].parentNode.removeChild(shown[i]); }
    FP.notice = s && s.state === 'grace' ? function () { return makeBanner(s); } : null;
  }
  FP.beforeStart = function (session) {
    if (FP.realm !== 'admin' || session.user.role !== 'admin' || !session.license || session.license.state !== 'grace') { return null; }
    return FP.call('get', 'license').then(function (r) {
      var s = clean(r);
      if (s && s.state === 'grace') { setBanner(s); }
    }, function () { return null; });
  };
})();

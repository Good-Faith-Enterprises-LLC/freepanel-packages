/* freePanel preferences pages (docs/api.md, "Authentication", "Language packs" and "Server information"): where you are signed in and
   how you have been (#/tool/signin_history, both panels), which notices you are mailed (#/tool/notifications, both panels), the
   language of the panel (#/tool/language, both panels) and the server information page (#/tool/server_info, customer panel). Each
   page is the login's own: no name is in any path but the account's on the information page. What the server sends is cleaned to
   the shapes drawn here and shown as text. A language pack the login chose is applied before the first page is drawn. Page pieces
   come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var HANDLE = /^[0-9a-f]{20}$/;
  var KIND = /^[a-z][a-z0-9_]{0,31}$/;
  var CODE = /^[a-z]{2,3}(-[A-Z]{2})?$/;
  var PANELS = {admin: 'sg_panel_admin', user: 'sg_panel_user'};
  var SHOWN = 100;

  function str(v) { return typeof v === 'string' ? v : ''; }
  function arr(v) { return Array.isArray(v) ? v : []; }
  function when(iso) {
    var d = new Date(str(iso));
    return isNaN(d.getTime()) ? str(iso).slice(0, 40) : d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'});
  }
  function frame(id, desc, cls) {
    var tool = FP.tools[id];
    if (!tool) { FP.views['not-found']({view: 'not-found'}); return null; }
    var g = FP.group(tool.group);
    return FP.frame({title: tool.label, desc: t(desc), cls: 'fp-prefs ' + cls,
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
  }
  function failedPage(page, id, err) {
    page.textContent = '';
    page.appendChild(FP.empty(FP.tools[id].label, err.message));
  }

  /* ================= Sign-in history and sessions ================= */
  var SG = null;
  function cleanSession(s) {
    if (!s || typeof s !== 'object' || !HANDLE.test(str(s.id))) { return null; }
    return {id: s.id, panel: PANELS[s.panel] ? s.panel : '', created: str(s.created_at), seen: str(s.last_seen_at), addr: str(s.remote_addr).slice(0, 64),
      agent: str(s.user_agent).slice(0, 160), current: s.current === true};
  }
  function cleanEntry(e) {
    if (!e || typeof e !== 'object') { return null; }
    return {at: str(e.at), panel: PANELS[e.panel] ? e.panel : '', addr: str(e.remote_addr).slice(0, 64), ok: e.result === 'ok', reason: str(e.reason).slice(0, 80)};
  }
  function sessionRow(s) {
    var what = s.addr || t('sg_unknown_addr');
    return el('li', {class: 'fp-sg-row', 'data-fp-session': s.id}, [
      el('div', {class: 'fp-sg-main'}, [
        el('span', {class: 'fp-sg-title', text: s.agent || t('sg_unknown_agent')}),
        s.current ? el('span', {class: 'sig-badge fp-sg-here', text: t('sg_this')}) : null,
        el('span', {class: 'fp-muted fp-row-note', text: t('sg_session_line', {addr: what, panel: s.panel ? t(PANELS[s.panel]) : '', when: when(s.seen)})})]),
      s.current ? null : el('span', {class: 'fp-sg-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button',
        'data-fp-act': 'end', 'aria-label': t('sg_end_of', {addr: what, when: when(s.seen)}), text: t('sg_end')})])]);
  }
  function sessionsCard() {
    var others = SG.sessions.filter(function (s) { return !s.current; });
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t('sg_sessions_desc')})];
    if (SG.sessionsError) { parts.length = 2; }
    else if (!SG.sessions.length) { parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': 'sessions', text: t('sg_sessions_none')})); }
    else {
      parts.push(el('ul', {class: 'fp-sg-list', 'aria-labelledby': 'fp-sg-sessions-h'}, SG.sessions.map(sessionRow)));
      if (others.length) {
        parts.push(el('div', {class: 'fp-actions fp-sg-end-all'}, [el('button', {class: 'sig-btn sig-btn--secondary fp-btn-danger-text', type: 'button',
          'data-fp-act': 'end-all', text: t('sg_end_all', {count: others.length})})]));
      }
    }
    var card = M.card('fp-sg-sessions-h', t('sg_sessions_title'), parts, 'fp-sg-sessions');
    if (SG.sessionsError) { UI.showError(card, SG.sessionsError); }
    return card;
  }
  function historyCard() {
    var parts = [M.errorLine(), el('p', {class: 'fp-muted', text: t('sg_history_desc')})];
    if (SG.historyError) { parts.length = 1; }
    else if (!SG.history.length) { parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': 'history', text: t('sg_history_none')})); }
    else {
      parts.push(el('ul', {class: 'fp-sg-list', 'aria-labelledby': 'fp-sg-history-h'}, SG.history.slice(0, SHOWN).map(function (e) {
        return el('li', {class: 'fp-sg-row' + (e.ok ? '' : ' fp-sg-refused'), 'data-fp-entry': e.ok ? 'ok' : 'denied'}, [
          el('div', {class: 'fp-sg-main'}, [
            el('span', {class: 'fp-sg-title', text: e.ok ? t('sg_ok') : t('sg_refused')}),
            e.reason ? el('span', {class: 'fp-muted', text: e.reason}) : null,
            el('span', {class: 'fp-muted fp-row-note', text: t('sg_entry_line', {addr: e.addr || t('sg_unknown_addr'), panel: e.panel ? t(PANELS[e.panel]) : '', when: when(e.at)})})])]);
      })));
    }
    var card = M.card('fp-sg-history-h', t('sg_history_title'), parts, 'fp-sg-history');
    if (SG.historyError) { UI.showError(card, SG.historyError); }
    return card;
  }
  function sgDraw() {
    SG.page.textContent = '';
    SG.page.appendChild(sessionsCard());
    SG.page.appendChild(historyCard());
  }
  /* told is a sentence for the list's error line, said once the list is drawn again (the redraw would take away one said before) */
  function sgReload(note, focusId, told) {
    var mine = SG;
    return FP.call('get', 'sessions').then(function (r) {
      if (SG !== mine) { return; }
      mine.sessions = arr(r && r.sessions).map(cleanSession).filter(Boolean);
      mine.sessionsError = '';
      sgDraw();
      if (note) { M.say(SG.page.querySelector('.fp-sg-sessions'), note); }
      if (told) { UI.showError(SG.page.querySelector('.fp-sg-sessions'), told); }
      if (focusId) { SG.page.querySelector(focusId).focus(); }
    }, function (err) {
      if (SG !== mine) { return; }
      sgDraw();
      UI.showError(SG.page.querySelector('.fp-sg-sessions'), err.message);
    });
  }
  function sgClick(e) {
    var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !SG || !SG.page.contains(b)) { return; }
    var act = b.getAttribute('data-fp-act');
    var card = SG.page.querySelector('.fp-sg-sessions');
    var mine = SG;
    if (act === 'end') {
      var row = b.closest('[data-fp-session]');
      UI.setBusy(b, true);
      FP.call('del', 'sessionEnd', undefined, {id: row.getAttribute('data-fp-session')}).then(function () {
        return sgReload(t('sg_ended'), '#fp-sg-sessions-h');
      }, function (err) {
        UI.setBusy(b, false);
        if (err.status === 404) { sgReload('', '', t('sg_gone')); }
        else if (SG === mine) { UI.showError(card, err.message); }
      });
    } else if (act === 'end-all') {
      var cell = b.closest('.fp-sg-end-all');
      cell.textContent = '';
      M.confirmIn(cell, t('sg_end_all_ask'), 'end-all-yes', t('sg_end_all_yes', {count: SG.sessions.filter(function (s) { return !s.current; }).length}));
    } else if (act === 'end-all-yes') {
      UI.setBusy(b, true);
      FP.call('del', 'sessions').then(function (r) {
        var n = r && typeof r.ended === 'number' ? r.ended : 0;
        return sgReload(t('sg_ended_all', {count: n}), '#fp-sg-sessions-h');
      }, function (err) {
        UI.setBusy(b, false);
        if (SG === mine) { UI.showError(card, err.message); }
      });
    } else if (act === 'confirm-no') {
      sgDraw();
      SG.page.querySelector('[data-fp-act="end-all"]').focus();
    }
  }
  FP.view('tool:signin_history', function () {
    SG = null;
    var page = frame('signin_history', 'sg_desc', 'fp-sg');
    if (!page) { return; }
    var mine = SG = {page: page, sessions: [], history: [], sessionsError: '', historyError: ''};
    page.addEventListener('click', sgClick);
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all([FP.call('get', 'sessions').then(function (r) { mine.sessions = arr(r && r.sessions).map(cleanSession).filter(Boolean); }, function (err) { mine.sessionsError = err.message; }),
      FP.call('get', 'history').then(function (r) { mine.history = arr(r && r.entries).map(cleanEntry).filter(Boolean); }, function (err) { mine.historyError = err.message; })]).then(function () {
      if (SG === mine) { sgDraw(); }
    });
  });

  /* ================= Notification choices ================= */
  var NOTICES = {admin: ['login_alert'], user: ['login_alert', 'bandwidth']};
  var NC = null;
  function ncDraw() {
    var page = NC.page;
    var kinds = NC.notices.filter(function (n) { return (NOTICES[FP.realm] || []).indexOf(n.kind) >= 0; });
    var boxes = kinds.map(function (n) {
      var id = 'fp-nc-' + n.kind.replace('_', '-');
      return el('div', {class: 'sig-field'}, [el('label', {class: 'fp-check', for: id}, [el('input', {type: 'checkbox', id: id, name: n.kind, checked: n.enabled ? true : null,
        'aria-describedby': id + '-hint'}), el('span', {text: t('nc_' + n.kind)})]), el('span', {class: 'sig-hint', id: id + '-hint', text: t('nc_' + n.kind + '_hint')})]);
    });
    var form = el('form', {class: 'fp-form fp-nc-form', novalidate: ''}, [M.errorLine(), M.statusLine()].concat(boxes,
      [el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('nc_save')})])]));
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var body = {};
      kinds.forEach(function (n) { body[n.kind] = form.querySelector('input[name="' + n.kind + '"]').checked; });
      var mine = NC;
      UI.setBusy(b, true);
      FP.call('put', 'notices', {notices: body}).then(function (r) {
        if (NC !== mine) { return; }
        mine.notices = cleanNotices(r).notices;
        ncDraw();
        M.say(NC.page, t('nc_saved'));
        NC.page.querySelector('#fp-nc-h').focus();
      }, function (err) {
        UI.setBusy(b, false);
        if (NC === mine) { M.failed(form, err); }
      });
    });
    var where = NC.email ? t('nc_where', {email: NC.email}) : t('nc_nowhere');
    page.textContent = '';
    page.appendChild(M.card('fp-nc-h', t('nc_title'), [el('p', {class: 'fp-muted', text: t('nc_intro')}),
      el('p', {class: 'fp-nc-where', 'data-fp-where': '', text: where}), form], 'fp-nc'));
  }
  function cleanNotices(r) {
    r = r && typeof r === 'object' ? r : {};
    return {email: str(r.email).slice(0, 254), notices: arr(r.notices).filter(function (n) {
      return n && typeof n === 'object' && KIND.test(str(n.kind)) && typeof n.enabled === 'boolean';
    }).map(function (n) { return {kind: n.kind, enabled: n.enabled}; })};
  }
  FP.view('tool:notifications', function () {
    NC = null;
    var page = frame('notifications', 'nc_desc', 'fp-ncp');
    if (!page) { return; }
    var mine = NC = {page: page, notices: [], email: ''};
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'notices').then(function (r) {
      if (NC !== mine) { return; }
      var c = cleanNotices(r);
      mine.notices = c.notices;
      mine.email = c.email;
      ncDraw();
    }, function (err) { if (NC === mine) { failedPage(page, 'notifications', err); } });
  });

  /* ================= Language ================= */
  var LG = null;
  function cleanLanguages(r) {
    r = r && typeof r === 'object' ? r : {};
    return arr(r.languages).filter(function (l) { return l && typeof l === 'object' && CODE.test(str(l.code)) && str(l.name); })
      .map(function (l) { return {code: l.code, name: str(l.name).slice(0, 64)}; });
  }
  function lgDraw() {
    var choices = [{value: '', text: t('lng_default')}, {value: 'en', text: 'English'}].concat(LG.langs.map(function (l) { return {value: l.code, text: l.name}; }));
    var pick = el('select', {class: 'sig-select', id: 'fp-lng-pick', name: 'language', 'aria-describedby': 'fp-lng-pick-hint'}, choices.map(function (c) {
      return el('option', {value: c.value, text: c.text});
    }));
    pick.value = choices.some(function (c) { return c.value === LG.current; }) ? LG.current : '';
    var form = el('form', {class: 'fp-form fp-lng-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-lng-pick', t('lng_pick'), pick, t('lng_pick_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('lng_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var mine = LG;
      UI.setBusy(b, true);
      FP.call('put', 'language', {language: pick.value}).then(function (r) {
        if (LG !== mine) { return; }
        mine.current = r && typeof r.language === 'string' ? r.language : pick.value;
        lgDraw();
        M.say(LG.page, t('lng_saved'));
        LG.page.querySelector('#fp-lng-h').focus();
      }, function (err) {
        UI.setBusy(b, false);
        if (LG === mine) { M.failed(form, err); }
      });
    });
    LG.page.textContent = '';
    LG.page.appendChild(M.card('fp-lng-h', t('lng_title'), [el('p', {class: 'fp-muted', text: t('lng_intro')}),
      LG.langs.length ? null : el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('lng_none')}), form], 'fp-lng'));
  }
  FP.view('tool:language', function () {
    LG = null;
    var page = frame('language', 'lng_desc', 'fp-lngp');
    if (!page) { return; }
    var mine = LG = {page: page, langs: [], current: ''};
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all([FP.call('get', 'languages'), FP.call('get', 'language')]).then(function (r) {
      if (LG !== mine) { return; }
      mine.langs = cleanLanguages(r[0]);
      mine.current = r[1] && typeof r[1].language === 'string' ? r[1].language : '';
      lgDraw();
    }, function (err) { if (LG === mine) { failedPage(page, 'language', err); } });
  });

  /* the chosen language, applied before the first page is drawn: only strings the panel already has are replaced, so a pack can
     change what the panel says and nothing else. A pack that can't be had leaves the panel in English. */
  var before = FP.beforeStart;
  FP.beforeStart = function (session) {
    var first = before ? before(session) : null;
    /* a team member's login has no language of its own to read (the route is the owner's) */
    if (session && session.user && session.user.account) { return first; }
    var lang = FP.call('get', 'language').then(function (r) {
      var code = r && typeof r.language === 'string' ? r.language : '';
      if (!CODE.test(code) || code === 'en') { return null; }
      return fetch('/assets/lang/' + code + '.json', {credentials: 'same-origin'}).then(function (res) {
        return res.ok ? res.json() : null;
      }).then(function (pack) {
        if (!pack || typeof pack !== 'object' || !pack.strings || typeof pack.strings !== 'object') { return; }
        Object.keys(pack.strings).forEach(function (k) {
          if (Object.prototype.hasOwnProperty.call(window.FPSTRINGS, k) && typeof pack.strings[k] === 'string' && pack.strings[k]) { window.FPSTRINGS[k] = pack.strings[k]; }
        });
        document.documentElement.setAttribute('lang', code);
      });
    }).catch(function () { return null; });
    return Promise.all([first, lang]);
  };

  /* ================= Server information ================= */
  var INFO_SECTIONS = ['server', 'account', 'web'];
  var INFO_KEYS = ['hostname', 'os', 'addresses', 'nameservers', 'username', 'domain', 'home', 'php_versions', 'php_default'];
  function cleanInfo(r) {
    return arr(r && r.sections).filter(function (s) { return s && INFO_SECTIONS.indexOf(s.id) >= 0; }).map(function (s) {
      return {id: s.id, items: arr(s.items).filter(function (i) { return i && INFO_KEYS.indexOf(i.key) >= 0; }).map(function (i) {
        return {key: i.key, value: str(i.value).slice(0, 253), values: arr(i.values).filter(function (v) { return typeof v === 'string'; }).map(function (v) { return v.slice(0, 253); }).slice(0, 40)};
      })};
    }).filter(function (s) { return s.items.length; });
  }
  FP.view('tool:server_info', function () {
    var page = frame('server_info', 'inf_desc', 'fp-inf');
    if (!page) { return; }
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'serverInfo', undefined, FP.account()).then(function (r) {
      if (!page.isConnected) { return; }
      var sections = cleanInfo(r);
      page.textContent = '';
      sections.forEach(function (s) {
        page.appendChild(M.card('fp-inf-' + s.id + '-h', t('inf_s_' + s.id), [el('dl', {class: 'fp-inf-facts'}, s.items.map(function (i) {
          return el('div', {'data-fp-fact': i.key}, [el('dt', {text: t('inf_k_' + i.key)}), el('dd', null, i.values.length ?
            [el('ul', {class: 'fp-inf-list'}, i.values.map(function (v) { return el('li', {class: 'sig-mono', text: v}); }))] : [el('span', {class: i.key === 'home' || i.key === 'hostname' ? 'sig-mono' : '', text: i.value})])]);
        }))], 'fp-inf-card'));
      });
      if (!sections.length) { page.appendChild(FP.empty(FP.tools.server_info.label, t('inf_none'))); }
    }, function (err) { failedPage(page, 'server_info', err); });
  });
})();

/* freePanel web statistics (#/tool/web_stats), the customer panel's page for one site's visits added up (docs/api.md,
   "Metrics"): the report over the logs on the server now (today and the day before), or the days kept for up to 90 days.
   Hits, page views, visitors (an estimate), the busiest pages, where visitors came from, missing pages, status codes,
   browsers, systems and crawlers. The names in the lists are whatever visitors sent: everything is drawn as text.
   FP.barChart is the bar chart the resource usage page draws its graphs with. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var DOMAIN_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var AT_RE = /^\d{4}-\d{2}-\d{2}(T\d{2})?$/;
  var VIEWS = [['now', 'wst_view_now', 0], ['7', 'wst_view_7', 7], ['30', 'wst_view_30', 30], ['90', 'wst_view_90', 90]];

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function num(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? v : 0; }
  function count(n) { return Math.round(n).toLocaleString('en'); }
  var UNITS = ['KB', 'MB', 'GB', 'TB', 'PB'];
  function size(n) {
    if (n < 1024) { return t('size_bytes', {n: count(n)}); }
    var u = -1;
    do { n /= 1024; u++; } while (n >= 1024 && u < UNITS.length - 1);
    return (n < 10 ? n.toFixed(1) : count(n)) + ' ' + UNITS[u];
  }
  var MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  /* "2026-10-15T08" as "Oct 15, 08:00" and "2026-10-15" as "Oct 15" (UTC, as the server counts) */
  function label(at) {
    var m = /^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}))?$/.exec(at);
    if (!m) { return ''; }
    var day = MONTHS[Number(m[2]) - 1] + ' ' + Number(m[3]);
    return m[4] ? day + ', ' + m[4] + ':00' : day;
  }

  /* a bar chart of values with a name for each, drawn from the page's CSS classes; label says what a screen reader hears */
  FP.barChart = function (values, names, said, unit) {
    var top = Math.max.apply(null, values.concat([0]));
    var cols = values.map(function (v, i) {
      var bar = el('div', {class: 'fp-st-bar' + (v ? '' : ' fp-st-bar--none')});
      bar.style.height = (top ? Math.max(v ? 2 : 0, Math.round(v / top * 100)) : 0) + '%';
      return el('div', {class: 'fp-st-col', title: names[i] + ': ' + unit(v)}, [bar]);
    });
    var n = names.length;
    var marks = n ? [0, Math.floor((n - 1) / 2), n - 1].map(function (i) { return el('span', {class: 'fp-st-mark', text: names[i]}); }) : [];
    return el('div', {class: 'fp-st-chart-wrap'}, [el('div', {class: 'fp-st-chart', role: 'img', 'aria-label': said, 'data-fp-chart': ''}, cols),
      el('div', {class: 'fp-st-marks', 'aria-hidden': 'true'}, marks)]);
  };

  /* a button that shows or hides a box (a closed <details> still takes part in the page's measurements) */
  var opened = 0;
  FP.disclose = function (label, content) {
    var id = 'fp-disc-' + (++opened);
    var box = el('div', {class: 'fp-disc-box', id: id, hidden: ''}, [content]);
    var b = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-disc-btn', type: 'button', 'aria-expanded': 'false', 'aria-controls': id, text: label});
    b.addEventListener('click', function () {
      var on = b.getAttribute('aria-expanded') !== 'true';
      b.setAttribute('aria-expanded', on ? 'true' : 'false');
      if (on) { box.removeAttribute('hidden'); } else { box.setAttribute('hidden', ''); }
    });
    return el('div', {class: 'fp-disc'}, [b, box]);
  };

  function names(list, max) {
    return (Array.isArray(list) ? list : []).slice(0, max || 60).filter(function (x) { return x && typeof x === 'object' && str(x.name, 200); })
      .map(function (x) { return {name: str(x.name, 200), count: num(x.count)}; });
  }
  function clean(r) {
    if (!r || typeof r !== 'object' || !r.totals || typeof r.totals !== 'object' || (r.unit !== 'hours' && r.unit !== 'days')) { return null; }
    var tt = r.totals;
    return {
      unit: r.unit, partial: r.partial === true,
      totals: {hits: num(tt.hits), pages: num(tt.pages), visitors: num(tt.visitors), crawled: num(tt.crawled), bytes: num(tt.bytes)},
      series: (Array.isArray(r.series) ? r.series : []).slice(0, 400).filter(function (p) { return p && typeof p === 'object' && AT_RE.test(str(p.at, 20)); })
        .map(function (p) { return {at: p.at, hits: num(p.hits), pages: num(p.pages), bytes: num(p.bytes)}; }),
      pages: (Array.isArray(r.pages) ? r.pages : []).slice(0, 40).filter(function (p) { return p && typeof p === 'object' && str(p.path, 200); })
        .map(function (p) { return {name: str(p.path, 200), hits: num(p.hits), bytes: num(p.bytes)}; }),
      referrers: names(r.referrers), missing: names(r.missing), status: names(r.status), browsers: names(r.browsers),
      systems: names(r.systems), crawlers: names(r.crawlers)
    };
  }

  var W = null;

  function card(id, title, children, cls) {
    return el('section', {class: 'sig-card fp-wst-card' + (cls ? ' ' + cls : ''), 'aria-labelledby': id}, [el('div', {class: 'sig-card-body'},
      [el('h2', {class: 'fp-h2', id: id, tabindex: '-1', text: title})].concat(children))]);
  }
  function selectField(id, text, options, value) {
    var s = el('select', {class: 'sig-select', id: id}, options.map(function (o) {
      var opt = el('option', {value: o[0], text: o[1]});
      if (o[0] === value) { opt.selected = true; }
      return opt;
    }));
    return {select: s, field: el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: id, text: text}), s])};
  }
  function wrap(table, id) { return el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': id}, [table]); }
  function nameTable(id, title, rows, head, empty) {
    var body = rows.length ? wrap(el('table', {class: 'sig-table fp-wst-table'}, [
      el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: head}), el('th', {scope: 'col', class: 'fp-num', text: t('wst_count')})])]),
      el('tbody', null, rows.map(function (x) {
        return el('tr', null, [el('th', {scope: 'row', class: 'fp-wst-name', text: x.name}), el('td', {class: 'fp-num', text: count(x.count)})]);
      }))]), id) : el('p', {class: 'fp-muted', text: empty});
    return card(id, title, [body], 'fp-wst-list');
  }
  function tile(key, value, text) {
    return el('div', {class: 'fp-wst-tile', 'data-fp-tile': key}, [el('strong', {text: value}), el('span', {class: 'fp-muted', text: text})]);
  }

  function render() {
    var page = W.page;
    var r = W.report;
    page.textContent = '';
    var site = selectField('fp-wst-site', t('wst_site'), W.sites.map(function (s) { return [s, s]; }), W.site);
    var view = selectField('fp-wst-view', t('wst_view'), VIEWS.map(function (v) { return [v[0], t(v[1])]; }), W.view);
    page.appendChild(card('fp-wst-h', t('wst_title'), [M.errorLine(), el('div', {class: 'fp-st-controls'}, [site.field, view.field]),
      el('p', {class: 'fp-muted', text: t(W.view === 'now' ? 'wst_now_note' : 'wst_days_note')})], 'fp-wst-top'));
    site.select.addEventListener('change', function () { W.site = site.select.value; UI.store.set('fp.wst.site', W.site); load('#fp-wst-site'); });
    view.select.addEventListener('change', function () { W.view = view.select.value; UI.store.set('fp.wst.view', W.view); load('#fp-wst-view'); });
    if (!r) { return; }
    var tt = r.totals;
    if (r.partial) { page.appendChild(el('p', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-partial': '', text: t('wst_partial')})); }
    var vals = r.series.map(function (p) { return p.hits; });
    var said = tt.hits ? t('wst_chart_label', {total: count(tt.hits), n: r.series.length}) : t('wst_chart_none');
    var seriesTable = r.series.length ? FP.disclose(t('wst_numbers'),
      wrap(el('table', {class: 'sig-table fp-wst-table'}, [el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('wst_when')}),
        el('th', {scope: 'col', class: 'fp-num', text: t('wst_hits')}), el('th', {scope: 'col', class: 'fp-num', text: t('wst_pageviews')}),
        el('th', {scope: 'col', class: 'fp-num', text: t('wst_sent')})])]),
      el('tbody', null, r.series.slice().reverse().map(function (p) {
        return el('tr', null, [el('th', {scope: 'row', text: label(p.at)}), el('td', {class: 'fp-num', text: count(p.hits)}), el('td', {class: 'fp-num', text: count(p.pages)}),
          el('td', {class: 'fp-num', text: size(p.bytes)})]);
      }))]), 'fp-wst-sum')) : null;
    page.appendChild(card('fp-wst-sum', t('wst_summary'), [
      el('div', {class: 'fp-wst-tiles'}, [tile('hits', count(tt.hits), t('wst_hits')), tile('pages', count(tt.pages), t('wst_pageviews')),
        tile('visitors', '~' + count(tt.visitors), t('wst_visitors')), tile('crawled', count(tt.crawled), t('wst_crawled')), tile('bytes', size(tt.bytes), t('wst_sent'))]),
      FP.barChart(vals, r.series.map(function (p) { return label(p.at); }), said, function (v) { return t('wst_hits_n', {n: count(v)}); }),
      el('p', {class: 'fp-muted fp-st-utc', text: t('wst_utc')}), el('p', {class: 'fp-muted', text: t('wst_visitors_note')}), seriesTable], 'fp-wst-summary'));
    page.appendChild(card('fp-wst-pages-h', t('wst_pages'), [r.pages.length ? wrap(el('table', {class: 'sig-table fp-wst-table'}, [
      el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('wst_path')}), el('th', {scope: 'col', class: 'fp-num', text: t('wst_hits')}),
        el('th', {scope: 'col', class: 'fp-num', text: t('wst_sent')})])]),
      el('tbody', null, r.pages.map(function (p) {
        return el('tr', null, [el('th', {scope: 'row', class: 'fp-wst-name', text: p.name}), el('td', {class: 'fp-num', text: count(p.hits)}), el('td', {class: 'fp-num', text: size(p.bytes)})]);
      }))]), 'fp-wst-pages-h') : el('p', {class: 'fp-muted', text: t('wst_no_pages')})], 'fp-wst-list'));
    page.appendChild(nameTable('fp-wst-ref-h', t('wst_referrers'), r.referrers, t('wst_from'), t('wst_none')));
    page.appendChild(nameTable('fp-wst-miss-h', t('wst_missing'), r.missing, t('wst_path'), t('wst_none')));
    page.appendChild(nameTable('fp-wst-status-h', t('wst_status'), r.status, t('wst_code'), t('wst_none')));
    page.appendChild(nameTable('fp-wst-browser-h', t('wst_browsers'), r.browsers, t('wst_browser'), t('wst_none')));
    page.appendChild(nameTable('fp-wst-system-h', t('wst_systems'), r.systems, t('wst_system'), t('wst_none')));
    page.appendChild(nameTable('fp-wst-crawler-h', t('wst_crawlers'), r.crawlers, t('wst_crawler'), t('wst_none')));
  }

  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function day(d) { return d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate()); }
  function load(focus) {
    var mine = W;
    var days = VIEWS.filter(function (v) { return v[0] === W.view; })[0][2];
    var arg = {name: W.account, domain: W.site};
    var call;
    if (!days) {
      call = FP.call('get', 'statsReport', undefined, arg);
    } else {
      var now = new Date();
      arg.to = day(now);
      arg.from = day(new Date(now.getTime() - (days - 1) * 86400000));
      call = FP.call('get', 'statsHistory', undefined, arg);
    }
    W.report = null;
    render();
    W.page.appendChild(el('p', {class: 'fp-muted', 'data-fp-loading': '', text: t('loading')}));
    if (focus) { W.page.querySelector(focus).focus(); }
    call.then(function (r) {
      if (W !== mine) { return; }
      var report = clean(r);
      W.report = report;
      render();
      if (!report) { UI.showError(W.page.querySelector('.fp-wst-top'), t('api_failed')); }
      if (focus) { W.page.querySelector(focus).focus(); }
      UI.announce(t('wst_loaded', {site: W.site}));
    }, function (err) {
      if (W !== mine) { return; }
      render();
      UI.showError(W.page.querySelector('.fp-wst-top'), err.message);
      UI.announce(err.message);
      if (focus) { W.page.querySelector(focus).focus(); }
    });
  }

  FP.view('tool:web_stats', function () {
    var tool = FP.tools.web_stats;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('wst_desc'), cls: 'fp-st fp-wst-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    W = {page: page, account: FP.account(), sites: [], site: '', view: 'now', report: null};
    var mine = W;
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'domains', undefined, W.account).then(function (r) {
      if (W !== mine) { return; }
      var out = [];
      (r && Array.isArray(r.sites) ? r.sites : []).forEach(function (s) {
        var d = s && typeof s.domain === 'string' ? s.domain : '';
        if (DOMAIN_RE.test(d) && out.indexOf(d) < 0) { out.push(d); }
      });
      page.textContent = '';
      if (!out.length) { page.appendChild(FP.empty(tool.label, t('wst_no_sites'))); return; }
      W.sites = out;
      var site = UI.store.get('fp.wst.site');
      var view = UI.store.get('fp.wst.view');
      W.site = out.indexOf(site) >= 0 ? site : out[0];
      W.view = VIEWS.some(function (v) { return v[0] === view; }) ? view : 'now';
      load();
    }, function (err) {
      if (W !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

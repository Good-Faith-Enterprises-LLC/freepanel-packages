/* freePanel IPv6 ranges (#/tool/ipv6_ranges), the admin panel's page for the IPv6 networks the provider routed to the server
   (docs/api.md, "IPv6 ranges"): record a range, give an account the next free address of one (it is put on the server and the
   account's names get an AAAA record of it), take an address back, and forget a range no account uses. What the server sends is
   drawn as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var NET_RE = /^[0-9a-fA-F:]{2,39}\/[0-9]{1,3}$/;
  var ADDR_RE = /^[0-9a-fA-F:]{2,39}$/;
  var NAME_RE = /^[a-z][a-z0-9_-]{0,31}$/;
  var V = null;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  function count(v) { return typeof v === 'number' && isFinite(v) && v > 0 ? Math.floor(v) : 0; }
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    return {
      ranges: (Array.isArray(r.ranges) ? r.ranges : []).filter(function (x) { return x && count(x.id) && NET_RE.test(str(x.network, 43)); })
        .map(function (x) { return {id: count(x.id), network: x.network, note: str(x.note, 200), used: count(x.used)}; }),
      assigned: (Array.isArray(r.assignments) ? r.assignments : []).filter(function (x) { return x && NAME_RE.test(str(x.account, 32)) && ADDR_RE.test(str(x.address, 39)); })
        .map(function (x) { return {account: x.account, address: x.address, range: count(x.range_id)}; })
    };
  }
  function names(r) {
    return (r && Array.isArray(r.accounts) ? r.accounts : []).map(function (a) { return a && str(a.username, 32); })
      .filter(function (n) { return NAME_RE.test(n); }).sort();
  }
  function rangeOf(id) {
    var r = V.data.ranges.filter(function (x) { return x.id === id; })[0];
    return r ? r.network : '';
  }
  function load() {
    return Promise.all([FP.call('get', 'ipv6Ranges'), FP.call('get', 'accounts').then(names, function () { return []; })]).then(function (rs) {
      V.data = clean(rs[0]);
      V.accounts = rs[1];
    });
  }
  /* the page again after a change; focus goes back where it was, a line says what happened */
  function reload(focus, scope, line) {
    var mine = V;
    return load().then(function () {
      if (V !== mine) { return; }
      draw();
      var c = V.page.querySelector(scope);
      if (c && line) { M.say(c, line); }
      var f = V.page.querySelector(focus) || (c && c.querySelector('h2'));
      if (f) { f.focus(); }
    }, function (err) {
      if (V !== mine) { return; }
      var c = V.page.querySelector(scope);
      if (c) { UI.showError(c, err.message); }
    });
  }

  /* ---- the ranges ---- */
  function rangeRow(r) {
    return el('tr', {'data-fp-range': String(r.id)}, [
      el('th', {scope: 'row', class: 'sig-mono', text: r.network}),
      el('td', {text: r.note || '—'}),
      el('td', {text: t('v6r_used', {n: r.used})}),
      el('td', {class: 'fp-actions-cell'}, [r.used ? el('span', {class: 'fp-muted', text: t('v6r_in_use')}) :
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'range-remove',
          'aria-label': t('v6r_remove_of', {network: r.network}), text: t('v6r_remove')})])]);
  }
  function rangesCard() {
    var parts = [el('p', {class: 'fp-muted', text: t('v6r_intro')}), M.errorLine(), M.statusLine()];
    if (V.data.ranges.length) {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-v6r-ranges-h'}, [el('table', {class: 'sig-table fp-v6r-table'}, [
        el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('v6r_col_network')}), el('th', {scope: 'col', text: t('v6r_col_note')}),
          el('th', {scope: 'col', text: t('v6r_col_used')}), el('th', {scope: 'col', text: t('v6r_col_actions')})])]),
        el('tbody', null, V.data.ranges.map(rangeRow))])]));
    } else {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('v6r_none')}));
    }
    var net = el('input', {class: 'sig-input sig-mono', id: 'fp-v6r-net', name: 'network', type: 'text', autocomplete: 'off', spellcheck: 'false',
      autocapitalize: 'none', maxlength: '43', placeholder: '2001:db8:1::/64'});
    var note = el('input', {class: 'sig-input', id: 'fp-v6r-note', name: 'note', type: 'text', autocomplete: 'off', maxlength: '200'});
    var form = el('form', {class: 'fp-form fp-v6r-add', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-v6r-net', t('v6r_network'), net, t('v6r_network_hint')),
      M.field('fp-v6r-note', t('v6r_note'), note, t('v6r_note_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('v6r_add')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var v = net.value.trim();
      if (!NET_RE.test(v)) { M.fieldError(form, net, t('v6r_network_bad')); return; }
      UI.setBusy(b, true);
      FP.call('post', 'ipv6Ranges', {network: v, note: note.value.trim()}).then(function (r) {
        reload('#fp-v6r-net', '.fp-v6r-ranges', t('v6r_added', {network: str(r && r.network, 43) || v}));
      }, function (err) {
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    parts.push(el('h3', {class: 'fp-h3', text: t('v6r_add_title')}), form);
    return M.card('fp-v6r-ranges-h', t('v6r_ranges_title'), parts, 'fp-v6r-ranges');
  }

  /* ---- the accounts ---- */
  function assignedRow(a) {
    return el('tr', {'data-fp-acct': a.account}, [
      el('th', {scope: 'row', text: a.account}),
      el('td', {class: 'sig-mono', text: a.address}),
      el('td', {class: 'sig-mono', text: rangeOf(a.range) || '—'}),
      el('td', {class: 'fp-actions-cell'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'take-back',
        'aria-label': t('v6r_take_back_of', {name: a.account}), text: t('v6r_take_back')})])]);
  }
  function accountsCard() {
    var parts = [el('p', {class: 'fp-muted', text: t('v6r_accounts_intro')}), M.errorLine(), M.statusLine()];
    if (V.data.assigned.length) {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-v6r-accts-h'}, [el('table', {class: 'sig-table fp-v6r-table'}, [
        el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('v6r_col_account')}), el('th', {scope: 'col', text: t('v6r_col_address')}),
          el('th', {scope: 'col', text: t('v6r_col_range')}), el('th', {scope: 'col', text: t('v6r_col_actions')})])]),
        el('tbody', null, V.data.assigned.map(assignedRow))])]));
    } else {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none-accts': '', text: t('v6r_no_accounts')}));
    }
    if (!V.data.ranges.length) {
      parts.push(el('p', {class: 'fp-warn-line', 'data-fp-need-range': '', text: t('v6r_need_range')}));
      return M.card('fp-v6r-accts-h', t('v6r_accounts_title'), parts, 'fp-v6r-accts');
    }
    var have = V.data.assigned.map(function (a) { return a.account; });
    var free = V.accounts.filter(function (n) { return have.indexOf(n) < 0; });
    var who = el('select', {class: 'sig-select', id: 'fp-v6r-who', name: 'username'},
      [el('option', {value: '', text: t('v6r_pick_account')})].concat(free.map(function (n) { return el('option', {value: n, text: n}); })));
    var from = el('select', {class: 'sig-select sig-mono', id: 'fp-v6r-from', name: 'range_id'},
      V.data.ranges.map(function (r) { return el('option', {value: String(r.id), text: r.network}); }));
    var form = el('form', {class: 'fp-form fp-v6r-give', novalidate: ''}, [M.errorLine(),
      M.field('fp-v6r-who', t('v6r_account'), who, t('v6r_account_hint')),
      M.field('fp-v6r-from', t('v6r_range'), from),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('v6r_give')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      if (!who.value) { M.fieldError(form, who, t('v6r_pick_account_first')); return; }
      UI.setBusy(b, true);
      FP.call('put', 'accountIPv6', {range_id: parseInt(from.value, 10)}, {name: who.value}).then(function (r) {
        var line = t('v6r_given', {name: who.value, address: str(r && r.address, 39), records: count(r && r.records), zones: count(r && r.zones)});
        if (r && r.warning) { line += ' ' + str(r.warning, 300); }
        reload('#fp-v6r-who', '.fp-v6r-accts', line);
      }, function (err) {
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    parts.push(el('h3', {class: 'fp-h3', text: t('v6r_give_title')}), form);
    return M.card('fp-v6r-accts-h', t('v6r_accounts_title'), parts, 'fp-v6r-accts');
  }

  function draw() {
    V.page.textContent = '';
    V.page.appendChild(rangesCard());
    V.page.appendChild(accountsCard());
  }
  function act(b, method, key, params, scope, focus, line) {
    var c = V.page.querySelector(scope);
    UI.showError(c, '');
    M.say(c, '');
    UI.setBusy(b, true);
    FP.call(method, key, undefined, params).then(function (r) {
      var w = r && typeof r.warning === 'string' ? ' ' + str(r.warning, 300) : '';
      reload(focus, scope, line + w);
    }, function (err) {
      UI.setBusy(b, false);
      UI.showError(c, err.message);
      b.focus();
    });
  }
  function onClick(e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !V || !V.page.contains(b) || b.disabled) { return; }
    var a = b.getAttribute('data-fp-act');
    var rr = b.closest('tr[data-fp-range]');
    var ar = b.closest('tr[data-fp-acct]');
    if (a === 'range-remove' && rr) {
      var net = rr.querySelector('th').textContent;
      M.confirmIn(b.parentNode, t('v6r_remove_ask', {network: net}), 'range-remove-yes', t('v6r_remove'));
    } else if (a === 'take-back' && ar) {
      M.confirmIn(b.parentNode, t('v6r_take_back_ask', {name: ar.getAttribute('data-fp-acct')}), 'take-back-yes', t('v6r_take_back'));
    } else if (a === 'confirm-no' && (rr || ar)) {
      var sel = rr ? 'tr[data-fp-range="' + rr.getAttribute('data-fp-range') + '"] [data-fp-act="range-remove"]' :
        'tr[data-fp-acct="' + ar.getAttribute('data-fp-acct') + '"] [data-fp-act="take-back"]';
      draw();
      var f = V.page.querySelector(sel);
      if (f) { f.focus(); }
    } else if (a === 'range-remove-yes' && rr) {
      act(b, 'del', 'ipv6Range', {id: rr.getAttribute('data-fp-range')}, '.fp-v6r-ranges', '#fp-v6r-net',
        t('v6r_removed', {network: rr.querySelector('th').textContent}));
    } else if (a === 'take-back-yes' && ar) {
      var n = ar.getAttribute('data-fp-acct');
      act(b, 'del', 'accountIPv6', {name: n}, '.fp-v6r-accts', '#fp-v6r-who', t('v6r_taken_back', {name: n}));
    }
  }
  document.addEventListener('click', onClick);

  FP.view('tool:ipv6_ranges', function () {
    var tool = FP.tools.ipv6_ranges;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('v6r_desc'), cls: 'fp-mail fp-srv fp-v6r-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    V = {page: page, data: null, accounts: []};
    var mine = V;
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    load().then(function () {
      if (V !== mine) { return; }
      draw();
    }, function (err) {
      if (V !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

/* freePanel catch-all subdomains (docs/api.md, "Domains and sites"): the customer panel's page (#/tool/catchall) that lets
   a main or addon website answer for every name under its domain that nothing else names (*.example.com), from its own
   folder and PHP version. A subdomain or an alias has none of its own, so only main and addon websites are listed. Every
   change answers with the whole list of sites again. The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var DOMAIN_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var VERSION_RE = /^[5-9]\.[0-9]$/;
  var DIR_RE = /^[A-Za-z0-9_][A-Za-z0-9_.-]{0,127}$/;
  var RESERVED = ['etc', 'mail', 'tmp', 'logs', 'ssl', 'access-logs', 'perl5', 'cache', 'backups'];
  var ORDER = {main: 0, addon: 1};

  function str(v) { return typeof v === 'string' ? v : ''; }
  function slug(domain) { return domain.replace(/[^a-z0-9]/g, '-'); }
  /* what the server says about a site's catch-all, or null when it has none */
  function cleanCatchall(c) {
    if (!c || typeof c !== 'object') { return null; }
    return {docroot: str(c.docroot), php: VERSION_RE.test(str(c.php_version)) ? c.php_version : '', certificate: c.certificate === true,
      note: str(c.note).slice(0, 300), problem: str(c.problem).slice(0, 300)};
  }
  function clean(v) {
    v = v && typeof v === 'object' ? v : {};
    var all = (Array.isArray(v.sites) ? v.sites : []).filter(function (s) { return s && DOMAIN_RE.test(str(s.domain)); });
    var main = all.filter(function (s) { return s.kind === 'main'; })[0];
    var home = main && /^\/.+\/public_html$/.test(str(main.docroot)) ? main.docroot.slice(0, -'/public_html'.length) : '';
    var sites = all.filter(function (s) { return s.kind === 'main' || s.kind === 'addon'; }).map(function (s) {
      return {domain: s.domain, kind: s.kind, docroot: str(s.docroot), php: VERSION_RE.test(str(s.php_version)) ? s.php_version : '',
        catchall: cleanCatchall(s.catchall)};
    }).sort(function (a, b) { return ORDER[a.kind] - ORDER[b.kind] || (a.domain < b.domain ? -1 : 1); });
    return {suspended: v.suspended === true, sites: sites, home: home};
  }
  function cleanVersions(v) {
    v = v && typeof v === 'object' ? v : {};
    return {versions: (Array.isArray(v.versions) ? v.versions : []).filter(function (x) { return VERSION_RE.test(str(x)); }),
      def: VERSION_RE.test(str(v.default)) ? v.default : ''};
  }
  /* a folder as the customer sees it in their home */
  function folderOf(docroot) {
    return CA.state.home && docroot.indexOf(CA.state.home + '/') === 0 ? docroot.slice(CA.state.home.length + 1) : docroot;
  }

  /* notes: domain -> what the server said the last time it changed that website's catch-all and the * records did not follow in DNS */
  var CA = {page: null, state: null, versions: null, account: '', editing: '', notes: {}};

  /* A change answers with the sites plus dns_note when the zone's * records did not follow (the list read later does not carry it), so the
     card keeps the note until that website's catch-all is changed again. */
  function rememberNote(domain, r) {
    var n = r && typeof r === 'object' ? str(r.dns_note).slice(0, 300) : '';
    if (n) { CA.notes[domain] = n; } else { delete CA.notes[domain]; }
  }
  function siteOf(domain) { return CA.state.sites.filter(function (s) { return s.domain === domain; })[0]; }
  function cardOf(domain) { return CA.page.querySelector('[data-fp-site="' + window.CSS.escape(domain) + '"]'); }

  /* ---- the form that turns a catch-all on or changes it ---- */
  function phpPick(id, site, current) {
    var same = site.php ? t('cac_php_same_v', {v: site.php}) : t('cac_php_same');
    var opts = [el('option', {value: '', text: same})].concat(CA.versions.versions.map(function (v) {
      return el('option', {value: v, text: t(v === CA.versions.def ? 'php_option_default' : 'php_option', {v: v})});
    }));
    /* a catch-all may still run a version the server no longer has: show it, but it can't be picked again */
    if (current && CA.versions.versions.indexOf(current) < 0) {
      opts.push(el('option', {value: current, disabled: '', text: t('php_option_gone', {v: current})}));
    }
    opts.forEach(function (o) { if (o.value === current) { o.selected = true; } });
    return el('select', {class: 'sig-select', id: id, name: 'php_version'}, opts);
  }
  function readFolder(form) {
    var f = form.querySelector('[name="docroot"]');
    var v = f.value.trim().replace(/^\/+|\/+$/g, '');
    if (!v) { return ''; }
    var parts = v.split('/');
    if (parts.length > 2 || parts.some(function (p) { return !DIR_RE.test(p); })) { M.fieldError(form, f, t('dom_folder_bad')); return null; }
    if (RESERVED.indexOf(parts[0]) >= 0) { M.fieldError(form, f, t('dom_folder_reserved', {folder: parts[0]})); return null; }
    return v;
  }
  function formOf(site) {
    var c = site.catchall;
    var base = 'fp-ca-' + slug(site.domain);
    var own = c && c.docroot !== site.docroot ? folderOf(c.docroot) : '';
    var folder = el('input', {class: 'sig-input', id: base + '-folder', name: 'docroot', type: 'text', autocomplete: 'off', spellcheck: 'false',
      autocapitalize: 'none', maxlength: '257', 'aria-describedby': base + '-folder-hint', value: own,
      placeholder: folderOf(site.docroot)});
    var pick = phpPick(base + '-php', site, c && c.php !== site.php ? c.php : '');
    var hint = t('cac_folder_hint', {folder: folderOf(site.docroot)});
    var form = el('form', {class: 'fp-form fp-mail-form fp-ca-form', novalidate: '', 'data-fp-form': site.domain}, [M.errorLine(),
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: base + '-folder', text: t('dom_folder')}),
        el('div', {class: 'fp-dom-path'}, [CA.state.home ? el('span', {class: 'fp-dom-home sig-mono', text: CA.state.home + '/'}) : null, folder]),
        el('span', {class: 'sig-hint', id: base + '-folder-hint', text: hint})]),
      M.field(base + '-php', t('cac_php'), pick, t('cac_php_hint')),
      c ? null : el('p', {class: 'sig-hint fp-ca-dns', text: t('cac_dns_note', {domain: site.domain})}),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t(c ? 'cac_save' : 'cac_on')}),
        c ? el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'ca-cancel', text: t('cancel')}) : null])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var f = readFolder(form);
      if (f === null) { return; }
      var body = {};
      if (f) { body.docroot = f; }
      if (pick.value) { body.php_version = pick.value; }
      UI.setBusy(b, true);
      FP.call('put', 'siteCatchall', body, {name: CA.account, domain: site.domain}).then(function (r) {
        CA.state = clean(r);
        rememberNote(site.domain, r);
        CA.editing = '';
        render();
        M.say(cardOf(site.domain), t(c ? 'cac_changed' : 'cac_turned_on', {domain: site.domain}));
        cardOf(site.domain).querySelector('h2').focus();
      }, function (err) {
        UI.setBusy(b, false);
        M.fieldError(form, /folder|document root/.test(err.message) ? folder : null, err.message);
      });
    });
    return form;
  }

  /* ---- what a site's catch-all is ---- */
  function certText(site) {
    var c = site.catchall;
    if (c.certificate) { return t('cac_cert_site', {domain: site.domain}); }
    return c.note ? c.note.charAt(0).toUpperCase() + c.note.slice(1) + (/[.!?]$/.test(c.note) ? '' : '.') : t('cac_cert_server', {domain: site.domain});
  }
  function factsOf(site) {
    var c = site.catchall;
    function row(label, content) { return el('div', null, [el('dt', {text: label}), el('dd', null, content)]); }
    return el('dl', {class: 'fp-ca-facts'}, [
      row(t('cac_f_folder'), [el('span', {class: 'sig-mono', text: folderOf(c.docroot) || '—'})]),
      row(t('cac_f_php'), [c.php ? el('span', {text: t('php_option', {v: c.php})}) : el('span', {class: 'fp-muted', text: '—'})]),
      row(t('cac_f_cert'), [el('span', {class: 'sig-pill ' + (c.certificate ? 'sig-pill--ok' : 'sig-pill--warn'), text: t(c.certificate ? 'cac_pill_site' : 'cac_pill_server')}),
        el('span', {class: 'fp-muted fp-row-note fp-ca-cert', text: certText(site)})])]);
  }
  function cardFor(site) {
    var c = site.catchall;
    var form = !c || CA.editing === site.domain;
    /* the form has its own error line (a field it is about is marked); the facts have this one */
    var parts = form ? [M.statusLine()] : [M.errorLine(), M.statusLine()];
    /* a catch-all the server cannot serve says so: it is not shown as On */
    var broken = Boolean(c && c.problem);
    parts.push(el('p', {class: 'fp-ca-state'}, [el('span', {class: 'sig-pill' + (broken ? ' sig-pill--warn' : (c ? ' sig-pill--ok' : '')), text: t(broken ? 'cac_pill_problem' : (c ? 'cac_pill_on' : 'cac_pill_off'))}),
      el('span', {class: 'fp-muted', text: t(c ? 'cac_on_note' : 'cac_off_note', {domain: site.domain})})]));
    if (broken) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-ca-problem': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: c.problem.charAt(0).toUpperCase() + c.problem.slice(1)})]));
    }
    /* the records for the names did not follow in DNS: the catch-all itself is as shown, the customer is told what to do */
    if (CA.notes[site.domain]) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-ca-dns-note': ''}, [UI.icon(FP.ui, 'ui_warning'),
        el('span', {text: CA.notes[site.domain].charAt(0).toUpperCase() + CA.notes[site.domain].slice(1)})]));
    }
    if (form) {
      parts.push(formOf(site));
    } else {
      parts.push(factsOf(site));
      parts.push(el('div', {class: 'fp-actions fp-ca-acts'}, [
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'ca-change', text: t('cac_change'),
          'aria-label': t('cac_change_of', {domain: site.domain})}),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'ca-off', text: t('cac_off'),
          'aria-label': t('cac_off_of', {domain: site.domain})})]));
    }
    var card = M.card('fp-ca-h-' + slug(site.domain), site.domain, parts, 'fp-ca-site');
    card.setAttribute('data-fp-site', site.domain);
    return card;
  }
  function render() {
    CA.page.textContent = '';
    if (CA.state.suspended) { CA.page.appendChild(M.suspendedBanner(t('dom_suspended'))); }
    if (!CA.state.sites.length) {
      CA.page.appendChild(FP.empty(t('cac_none_title'), t('php_no_sites')));
      return;
    }
    CA.page.appendChild(el('p', {class: 'fp-muted fp-ca-intro', text: t('cac_intro')}));
    CA.state.sites.forEach(function (s) { CA.page.appendChild(cardFor(s)); });
  }

  function click(b, a) {
    var card = b.closest('[data-fp-site]');
    var domain = card ? card.getAttribute('data-fp-site') : '';
    var site = domain ? siteOf(domain) : null;
    if (!site) { return; }
    if (a === 'ca-change') {
      CA.editing = domain;
      render();
      cardOf(domain).querySelector('input[name="docroot"]').focus();
    } else if (a === 'ca-cancel') {
      CA.editing = '';
      render();
      cardOf(domain).querySelector('[data-fp-act="ca-change"]').focus();
    } else if (a === 'ca-off') {
      M.confirmIn(card.querySelector('.fp-ca-acts'), t('cac_off_ask', {domain: domain, folder: folderOf(site.catchall.docroot)}), 'ca-off-yes', t('cac_off'));
    } else if (a === 'confirm-no') {
      render();
      cardOf(domain).querySelector('[data-fp-act="ca-off"]').focus();
    } else if (a === 'ca-off-yes') {
      UI.setBusy(b, true);
      FP.call('del', 'siteCatchall', undefined, {name: CA.account, domain: domain}).then(function (r) {
        CA.state = clean(r);
        rememberNote(domain, r);
        render();
        M.say(cardOf(domain), t('cac_turned_off', {domain: domain}));
        cardOf(domain).querySelector('h2').focus();
      }, function (err) {
        /* a catch-all that is already gone (404) leaves nothing to turn off: read the list again */
        FP.call('get', 'domains', undefined, CA.account).then(function (r) { CA.state = clean(r); }, function () { return null; }).then(function () {
          render();
          if (cardOf(domain)) {
            UI.showError(cardOf(domain), err.message);
            cardOf(domain).querySelector('h2').focus();
          }
        });
      });
    }
  }

  document.addEventListener('click', function (e) {
    var target = e.target.closest ? e.target : null;
    var b = target && target.closest('[data-fp-act]');
    if (!b || !CA.page || !CA.page.contains(b)) { return; }
    click(b, b.getAttribute('data-fp-act'));
  });

  FP.view('tool:catchall', function () {
    CA.page = null;
    CA.editing = '';
    CA.notes = {};
    var tool = FP.tools.catchall;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('catchall_desc'), cls: 'fp-mail fp-ca-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    CA.page = body;
    CA.account = FP.account();
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all([FP.call('get', 'domains', undefined, CA.account),
      FP.call('get', 'phpVersions').then(cleanVersions, function () { return cleanVersions(null); })]).then(function (r) {
      if (CA.page !== body) { return; }
      CA.state = clean(r[0]);
      CA.versions = r[1];
      render();
    }, function (err) {
      if (CA.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

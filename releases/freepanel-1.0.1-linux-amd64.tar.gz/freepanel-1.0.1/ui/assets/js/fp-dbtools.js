/* freePanel database tool pages, in the admin panel (docs/api.md, "Database servers", "Administrator password" and "All databases"):
   Database servers (#/tool/db_servers) shows the servers this machine runs with what they are doing and the connections open to
   them, and defines and tests servers that run elsewhere (nothing is placed on them yet); Database administrator password
   (#/tool/db_root_password) gives a local server's administrator a password for the admin's own use; All databases
   (#/tool/db_list) lists every database the panel has recorded, with its account, and pages through them. Nothing changes until the admin
   asks. What the server sends is cleaned to the shapes drawn here and shown as text; a password is never shown after it is sent. Page
   pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var ID_RE = /^(local-mysql|local-postgres|ext-[0-9a-f]{8})$/;
  var ENGINES = ['mysql', 'postgres'];
  var TLS = ['verify', 'skip', 'off'];
  var PAGE = 50;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function num(v) { return typeof v === 'number' && isFinite(v) ? v : 0; }
  function arr(v) { return Array.isArray(v) ? v : []; }
  function count(n) { return Math.round(n).toLocaleString('en'); }
  function size(b) {
    if (b >= 1073741824) { return (b / 1073741824).toFixed(1) + ' GiB'; }
    return Math.round(b / 1048576).toLocaleString('en') + ' MiB';
  }
  function span(seconds) {
    var s = Math.max(0, Math.round(seconds));
    var d = Math.floor(s / 86400);
    var h = Math.floor((s % 86400) / 3600);
    var m = Math.floor((s % 3600) / 60);
    if (d) { return t('dbt_span_dh', {d: d, h: h}); }
    if (h) { return t('dbt_span_hm', {h: h, m: m}); }
    return t('dbt_span_m', {m: m});
  }
  function frame(id, desc, cls) {
    var tool = FP.tools[id];
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return null; }
    var g = FP.group(tool.group);
    return FP.frame({title: tool.label, desc: t(desc), cls: 'fp-mail fp-dbt ' + cls,
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
  }
  function failedPage(page, id, err) {
    page.textContent = '';
    page.appendChild(FP.empty(FP.tools[id].label, err.message));
  }
  function warn(text, attr) {
    var b = el('div', {class: 'sig-banner sig-banner--warn', role: 'note'}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: text})]);
    if (attr) { b.setAttribute(attr, ''); }
    return b;
  }
  function when(iso) { return (FP.bk && FP.bk.when(iso)) || str(iso, 40); }
  function select(id, name, options, value) {
    var sel = el('select', {class: 'sig-select', id: id, name: name}, options.map(function (o) { return el('option', {value: o.value, text: o.text}); }));
    sel.value = value;
    return sel;
  }

  /* ================= Database servers ================= */
  var DS = null;
  function cleanTest(x) {
    return x && typeof x === 'object' ? {at: str(x.at, 40), ok: x.ok === true, version: str(x.version, 80), latency: Math.round(num(x.latency_ms)), error: str(x.error, 300)} : null;
  }
  function cleanServer(s) {
    if (!s || typeof s !== 'object' || !ID_RE.test(str(s.id)) || ENGINES.indexOf(s.engine) < 0) { return null; }
    return {id: s.id, external: s.kind === 'external', engine: s.engine, name: str(s.name, 64) || s.id, available: s.available !== false, running: s.running === true, version: str(s.version, 80),
      uptime: Math.max(0, num(s.uptime_seconds)), conns: Math.round(num(s.connections)), max: Math.round(num(s.max_connections)), bytes: Math.max(0, num(s.size_bytes)),
      accounts: Math.round(num(s.accounts)), databases: Math.round(num(s.databases)), error: str(s.error, 200), unreadable: Math.round(num(s.unreadable_records)),
      host: str(s.host, 253), port: Math.round(num(s.port)), user: str(s.user, 64), tls: TLS.indexOf(s.tls) >= 0 ? s.tls : 'verify', passwordSet: s.password_set === true, tested: cleanTest(s.tested)};
  }
  function cleanServers(r) {
    r = r && typeof r === 'object' ? r : {};
    return {list: arr(r.servers).map(cleanServer).filter(Boolean).slice(0, 30), warning: str(r.warning, 300)};
  }
  function engineTitle(e) { return t(e === 'mysql' ? 'dbt_mariadb' : 'dbt_postgres'); }
  function testLine(x) {
    if (!x) { return el('p', {class: 'fp-muted', 'data-fp-tested': 'never', text: t('dbt_never_tested')}); }
    var line = x.ok ? t('dbt_test_ok', {when: when(x.at), version: x.version || '—', ms: x.latency}) : t('dbt_test_failed', {when: when(x.at), error: x.error || '—'});
    return el('p', {class: x.ok ? 'fp-muted' : 'fp-alert is-shown', role: x.ok ? null : 'note', 'data-fp-tested': x.ok ? 'ok' : 'failed', text: line});
  }
  function factList(s) {
    var facts = [];
    function add(key, label, value) { facts.push(el('div', {'data-fp-fact': key}, [el('dt', {text: label}), el('dd', null, [value])])); }
    if (s.external) {
      add('host', t('dbt_k_host'), el('span', {class: 'sig-mono', text: s.host + ':' + s.port}));
      add('user', t('dbt_k_user'), el('span', {class: 'sig-mono', text: s.user}));
      add('tls', t('dbt_k_tls'), el('span', {text: t('dbt_tls_' + s.tls)}));
      add('password', t('dbt_k_password'), el('span', {text: t(s.passwordSet ? 'dbt_password_set' : 'dbt_password_none')}));
      if (s.version) { add('version', t('dbt_k_version'), el('span', {text: s.version})); }
    } else if (s.available && s.running) {
      add('version', t('dbt_k_version'), el('span', {class: 'sig-mono', text: s.version || '—'}));
      add('uptime', t('dbt_k_uptime'), el('span', {text: span(s.uptime)}));
      add('connections', t('dbt_k_connections'), el('span', {text: t('dbt_conn_of', {n: count(s.conns), max: count(s.max)})}));
      add('size', t('dbt_k_size'), el('span', {text: size(s.bytes)}));
    }
    if (!s.external) {
      add('accounts', t('dbt_k_accounts'), el('span', {text: t('dbt_accounts_dbs', {accounts: count(s.accounts), databases: count(s.databases)})}));
    }
    return el('dl', {class: 'fp-dbt-facts'}, facts);
  }
  function serverCard(s) {
    var parts = [M.errorLine(), M.statusLine()];
    var state = !s.external && !s.available ? 'unavailable' : (s.external ? (s.tested ? (s.tested.ok ? 'running' : 'stopped') : 'untested') : (s.running ? 'running' : 'stopped'));
    var pill = el('span', {class: 'sig-pill' + (state === 'running' ? ' sig-pill--ok' : ''), 'data-fp-state': state, text: t('dbt_state_' + state)});
    parts.push(el('p', {class: 'fp-dbt-now'}, [pill, el('span', {class: 'fp-muted', text: engineTitle(s.engine) + (s.external ? ' · ' + t('dbt_external') : ' · ' + t('dbt_local'))})]));
    if (!s.external && !s.available) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('dbt_not_set_up', {option: '--' + s.engine})}));
    } else {
      if (s.error) { parts.push(warn(s.error, 'data-fp-error-line')); }
      if (s.unreadable) { parts.push(warn(t('dbt_unreadable', {count: s.unreadable}), 'data-fp-unreadable')); }
      parts.push(factList(s));
      if (s.external) { parts.push(testLine(s.tested)); }
    }
    var acts = [];
    if (!s.external && s.available && s.running) {
      acts.push(el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'procs', text: t('dbt_show_conns')}));
    }
    if (s.external) {
      acts.push(el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'test', 'aria-label': t('dbt_test_of', {name: s.name}), text: t('dbt_test')}));
      acts.push(el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'edit', 'aria-label': t('dbt_edit_of', {name: s.name}), text: t('dbt_edit')}));
      acts.push(el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'remove', 'aria-label': t('dbt_remove_of', {name: s.name}), text: t('dbt_remove')}));
    }
    if (acts.length) { parts.push(el('div', {class: 'fp-actions fp-dbt-acts'}, acts)); }
    var card = M.card('fp-dbt-' + s.id + '-h', s.name, parts, 'fp-dbt-server');
    card.setAttribute('data-fp-server', s.id);
    return card;
  }
  function procsCard(id, r) {
    r = r && typeof r === 'object' ? r : {};
    var rows = arr(r.processes).slice(0, 500).map(function (p) {
      return el('tr', null, [el('th', {scope: 'row', class: 'sig-mono', text: String(Math.round(num(p.id)))}), el('td', {text: str(p.user, 80)}), el('td', {text: str(p.database, 80) || '—'}),
        el('td', {text: str(p.command, 60)}), el('td', {text: str(p.state, 60) || '—'}), el('td', {class: 'fp-num', text: count(num(p.seconds))}),
        el('td', {class: 'fp-dbt-kill'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'proc-kill', 'data-fp-pid': String(Math.round(num(p.id))),
          'aria-label': t('dbt_kill_of', {id: String(Math.round(num(p.id)))}), text: t('dbt_kill')})])]);
    });
    var parts = [M.errorLine(), M.statusLine()];
    if (!rows.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': 'procs', text: t('dbt_no_conns')}));
    } else {
      parts.push(el('p', {class: 'fp-muted', text: t('dbt_conns_note')}));
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-dbt-procs-h'}, [el('table', {class: 'sig-table'}, [
        el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('dbt_col_id')}), el('th', {scope: 'col', text: t('dbt_col_user')}), el('th', {scope: 'col', text: t('dbt_col_db')}),
          el('th', {scope: 'col', text: t('dbt_col_kind')}), el('th', {scope: 'col', text: t('dbt_col_state')}), el('th', {scope: 'col', class: 'fp-num', text: t('dbt_col_seconds')}), el('th', {scope: 'col', text: t('dbt_col_actions')})])]),
        el('tbody', null, rows)])]));
      if (r.truncated === true) { parts.push(el('p', {class: 'fp-muted', 'data-fp-truncated': '', text: t('dbt_conns_truncated')})); }
    }
    var card = M.card('fp-dbt-procs-h', t('dbt_conns_title', {name: DS.data.list.filter(function (s) { return s.id === id; })[0].name}), parts, 'fp-dbt-procs');
    card.setAttribute('data-fp-procs-of', id);
    return card;
  }
  function addCard() {
    var form = serverForm(null);
    return M.card('fp-dbt-add-h', t('dbt_add_title'), [el('p', {class: 'fp-muted', text: t('dbt_add_note')}), form], 'fp-dbt-add');
  }
  /* the form that defines a server (s null) or changes one: the password is asked again when where it points changes */
  function serverForm(s) {
    var p = s ? 'fp-dbt-e-' : 'fp-dbt-n-';
    var name = el('input', {class: 'sig-input', id: p + 'name', name: 'name', type: 'text', maxlength: '64', autocomplete: 'off', value: s ? s.name : ''});
    var engine = select(p + 'engine', 'engine', [{value: 'mysql', text: t('dbt_mariadb')}, {value: 'postgres', text: t('dbt_postgres')}], s ? s.engine : 'mysql');
    if (s) { engine.disabled = true; }
    var host = el('input', {class: 'sig-input sig-mono', id: p + 'host', name: 'host', type: 'text', maxlength: '253', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', value: s ? s.host : ''});
    var port = el('input', {class: 'sig-input', id: p + 'port', name: 'port', type: 'text', inputmode: 'numeric', maxlength: '5', autocomplete: 'off', value: s ? String(s.port) : ''});
    var user = el('input', {class: 'sig-input sig-mono', id: p + 'user', name: 'user', type: 'text', maxlength: '64', autocomplete: 'off', spellcheck: 'false', value: s ? s.user : ''});
    var pw = el('input', {class: 'sig-input', id: p + 'password', name: 'password', type: 'password', autocomplete: 'new-password'});
    var tls = select(p + 'tls', 'tls', TLS.map(function (x) { return {value: x, text: t('dbt_tls_' + x)}; }), s ? s.tls : 'verify');
    var form = el('form', {class: 'fp-form fp-dbt-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-rules-grid'}, [M.field(p + 'name', t('dbt_f_name'), name, t('dbt_f_name_hint')), M.field(p + 'engine', t('dbt_f_engine'), engine, s ? t('dbt_f_engine_fixed') : null),
        M.field(p + 'host', t('dbt_f_host'), host, t('dbt_f_host_hint')), M.field(p + 'port', t('dbt_f_port'), port, t('dbt_f_port_hint')),
        M.field(p + 'user', t('dbt_f_user'), user, t('dbt_f_user_hint')), M.field(p + 'password', t('dbt_f_password'), pw, s ? t('dbt_f_password_again') : t('dbt_f_password_hint')),
        M.field(p + 'tls', t('dbt_f_tls'), tls, t('dbt_f_tls_hint'))]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t(s ? 'dbt_save' : 'dbt_add')}),
        s ? el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'edit-cancel', text: t('cancel')}) : null])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var body = {name: name.value.trim(), host: host.value.trim().toLowerCase(), user: user.value.trim(), tls: tls.value};
      if (!body.name) { M.fieldError(form, name, t('dbt_need_name')); return; }
      if (!body.host) { M.fieldError(form, host, t('dbt_need_host')); return; }
      if (!body.user) { M.fieldError(form, user, t('dbt_need_user')); return; }
      if (port.value.trim()) {
        if (!/^[0-9]{1,5}$/.test(port.value.trim()) || parseInt(port.value, 10) < 1 || parseInt(port.value, 10) > 65535) { M.fieldError(form, port, t('dbt_bad_port')); return; }
        body.port = parseInt(port.value, 10);
      }
      if (pw.value) { body.password = pw.value; }
      if (!s) {
        if (!pw.value) { M.fieldError(form, pw, t('dbt_need_password')); return; }
        body.engine = engine.value;
      } else if (!pw.value && (body.host !== s.host || (body.port && body.port !== s.port) || body.user !== s.user)) {
        M.fieldError(form, pw, t('dbt_need_password_again'));
        return;
      }
      var mine = DS;
      UI.setBusy(b, true);
      FP.call(s ? 'put' : 'post', s ? 'dbServer' : 'dbServers', body, s ? {id: s.id} : undefined).then(function () {
        return dsReload(mine, t(s ? 'dbt_saved' : 'dbt_added', {name: body.name}), s ? s.id : 'new');
      }, function (err) {
        UI.setBusy(b, false);
        if (DS === mine) { M.failed(form, err); pw.value = ''; }
      });
    });
    return form;
  }
  function dsDraw(opts) {
    opts = opts || {};
    DS.page.textContent = '';
    if (DS.data.warning) { DS.page.appendChild(warn(DS.data.warning, 'data-fp-warning')); }
    DS.page.appendChild(el('p', {class: 'fp-muted fp-dbt-lead', text: t('dbt_lead')}));
    DS.data.list.forEach(function (s) {
      var card = serverCard(s);
      if (DS.editing === s.id) {
        var acts = card.querySelector('.fp-dbt-acts');
        if (acts) { acts.remove(); }
        card.querySelector('.sig-card-body').appendChild(serverForm(s));
      }
      DS.page.appendChild(card);
      if (DS.procs[s.id]) { DS.page.appendChild(procsCard(s.id, DS.procs[s.id])); }
    });
    DS.page.appendChild(addCard());
    if (opts.note) { M.say(DS.page.querySelector('[data-fp-server="' + opts.card + '"]') || DS.page.querySelector('.fp-dbt-add'), opts.note); }
  }
  function dsReload(mine, note, card) {
    return FP.call('get', 'dbServers').then(function (r) {
      if (DS !== mine) { return; }
      mine.data = cleanServers(r);
      mine.editing = '';
      var id = card === 'new' ? (mine.data.list[mine.data.list.length - 1] || {}).id : card;
      dsDraw({note: note, card: id});
      /* the page was drawn again, so the control that had the focus is gone: it goes to the card the note is in (the form's card when no server is) */
      var h = mine.page.querySelector(id ? '[data-fp-server="' + id + '"] h2' : '.fp-dbt-add h2');
      if (h) { h.focus(); }
    }, function (err) { if (DS === mine) { UI.showError(mine.page, err.message); } });
  }
  function dsClick(e) {
    var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !DS || !DS.page.contains(b)) { return; }
    var act = b.getAttribute('data-fp-act');
    var card = b.closest('[data-fp-server]');
    var id = card ? card.getAttribute('data-fp-server') : '';
    var mine = DS;
    var procsOf = b.closest('[data-fp-procs-of]');
    if (act === 'proc-kill') {
      M.confirmIn(b.closest('td'), t('dbt_kill_ask', {id: b.getAttribute('data-fp-pid')}), 'proc-kill-yes', t('dbt_kill'));
      mine.page.querySelector('[data-fp-act="proc-kill-yes"]').setAttribute('data-fp-pid', b.getAttribute('data-fp-pid'));
      return;
    }
    if (act === 'proc-kill-yes' && procsOf) {
      var sid = procsOf.getAttribute('data-fp-procs-of');
      UI.setBusy(b, true);
      FP.call('post', 'dbServerProcKill', {}, {id: sid, pid: b.getAttribute('data-fp-pid')}).then(function () {
        return FP.call('get', 'dbServerProcs', undefined, {id: sid});
      }).then(function (r) {
        if (DS !== mine) { return; }
        mine.procs[sid] = r || {};
        dsDraw();
        M.say(mine.page.querySelector('[data-fp-procs-of="' + sid + '"]'), t('dbt_killed'));
        mine.page.querySelector('#fp-dbt-procs-h').focus();
      }, function (err) {
        UI.setBusy(b, false);
        if (DS === mine) { UI.showError(procsOf, err.message); }
      });
      return;
    }
    if (act === 'procs') {
      UI.setBusy(b, true);
      FP.call('get', 'dbServerProcs', undefined, {id: id}).then(function (r) {
        if (DS !== mine) { return; }
        mine.procs[id] = r || {};
        dsDraw();
        mine.page.querySelector('#fp-dbt-procs-h').focus();
      }, function (err) {
        UI.setBusy(b, false);
        if (DS === mine) { UI.showError(card, err.message); }
      });
    } else if (act === 'test') {
      UI.setBusy(b, true);
      FP.call('post', 'dbServerTest', undefined, {id: id}).then(function (r) {
        if (DS !== mine) { return; }
        var x = cleanTest(r);
        mine.data.list.forEach(function (s) { if (s.id === id) { s.tested = x; } });
        dsDraw({note: t(x && x.ok ? 'dbt_test_done_ok' : 'dbt_test_done_failed'), card: id});
        mine.page.querySelector('[data-fp-server="' + id + '"] [data-fp-act="test"]').focus();
      }, function (err) {
        UI.setBusy(b, false);
        if (DS === mine) { UI.showError(card, err.message); }
      });
    } else if (act === 'edit') {
      mine.editing = id;
      dsDraw();
      mine.page.querySelector('[data-fp-server="' + id + '"] input[name="name"]').focus();
    } else if (act === 'edit-cancel') {
      mine.editing = '';
      dsDraw();
      mine.page.querySelector('[data-fp-server="' + id + '"] [data-fp-act="edit"]').focus();
    } else if (act === 'remove') {
      M.confirmIn(b.closest('.fp-dbt-acts'), t('dbt_remove_ask'), 'remove-yes', t('dbt_remove'));
    } else if (act === 'confirm-no') {
      dsDraw();
      var again = mine.page.querySelector('[data-fp-server="' + id + '"] [data-fp-act="remove"]');
      if (again) { again.focus(); }
    } else if (act === 'remove-yes') {
      UI.setBusy(b, true);
      FP.call('del', 'dbServer', undefined, {id: id}).then(function () {
        delete mine.procs[id];
        return dsReload(mine, t('dbt_removed'), '');
      }, function (err) {
        UI.setBusy(b, false);
        if (DS === mine) { UI.showError(card, err.message); }
      });
    }
  }
  FP.view('tool:db_servers', function () {
    DS = null;
    var page = frame('db_servers', 'dbt_servers_desc', 'fp-dbt-servers');
    if (!page) { return; }
    var mine = DS = {page: page, data: null, procs: {}, editing: ''};
    page.addEventListener('click', dsClick);
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'dbServers').then(function (r) {
      if (DS !== mine) { return; }
      mine.data = cleanServers(r);
      dsDraw();
    }, function (err) { if (DS === mine) { failedPage(page, 'db_servers', err); } });
  });

  /* ================= Administrator password ================= */
  var RP = null;
  function distinct(s) { var seen = {}; var n = 0; for (var i = 0; i < s.length; i++) { if (!seen[s[i]]) { seen[s[i]] = 1; n++; } } return n; }
  function randomPassword() {
    var alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
    var bytes = new Uint8Array(24);
    window.crypto.getRandomValues(bytes);
    var out = '';
    for (var i = 0; i < bytes.length; i++) { out += alphabet.charAt(bytes[i] % alphabet.length); }
    return out;
  }
  function rpCard(s) {
    var parts = [M.errorLine(), M.statusLine()];
    var account = s.engine === 'mysql' ? 'root' : 'postgres';
    parts.push(el('p', {class: 'fp-muted', text: t('dbp_intro', {account: account})}));
    if (!s.available) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('dbt_not_set_up', {option: '--' + s.engine})}));
      return M.card('fp-dbp-' + s.engine + '-h', engineTitle(s.engine), parts, 'fp-dbp-card');
    }
    var pw = el('input', {class: 'sig-input', id: 'fp-dbp-' + s.engine + '-pw', name: 'password', type: 'password', autocomplete: 'new-password', spellcheck: 'false'});
    var again = el('input', {class: 'sig-input', id: 'fp-dbp-' + s.engine + '-pw2', name: 'again', type: 'password', autocomplete: 'new-password', spellcheck: 'false'});
    var make = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'make', text: t('dbp_make')});
    var form = el('form', {class: 'fp-form fp-dbp-form', novalidate: '', 'data-fp-engine': s.engine}, [M.errorLine(), M.statusLine(),
      M.field(pw.id, t('dbp_password'), pw, t('dbp_password_hint')), M.field(again.id, t('dbp_again'), again, null),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('dbp_save', {account: account})}), make])]);
    make.addEventListener('click', function () {
      var made = randomPassword();
      pw.type = 'text';
      again.type = 'text';
      pw.value = made;
      again.value = made;
      M.say(form, t('dbp_made'));
      pw.focus();
    });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      if (pw.value.length < 16 || distinct(pw.value) < 8) { M.fieldError(form, pw, t('dbp_weak')); return; }
      if (s.engine === 'postgres' && !/^[\x20-\x7e]+$/.test(pw.value)) { M.fieldError(form, pw, t('dbp_ascii')); return; }
      if (pw.value !== again.value) { M.fieldError(form, again, t('dbp_differ')); return; }
      var mine = RP;
      UI.setBusy(b, true);
      FP.call('put', 'dbAdminPw', {password: pw.value}, {id: 'local-' + s.engine}).then(function (r) {
        if (RP !== mine) { return; }
        var accounts = arr(r && r.accounts).filter(function (x) { return typeof x === 'string'; }).slice(0, 10).map(function (x) { return x.slice(0, 80); });
        rpDraw();
        M.say(mine.page.querySelector('#fp-dbp-' + s.engine + '-h').closest('.sig-card'), t('dbp_saved', {accounts: accounts.join(', ') || account}));
        mine.page.querySelector('#fp-dbp-' + s.engine + '-h').focus();
      }, function (err) {
        UI.setBusy(b, false);
        if (RP === mine) { M.failed(form, err); pw.value = ''; again.value = ''; }
      });
    });
    parts.push(form);
    return M.card('fp-dbp-' + s.engine + '-h', engineTitle(s.engine), parts, 'fp-dbp-card');
  }
  function rpDraw() {
    RP.page.textContent = '';
    RP.page.appendChild(el('p', {class: 'fp-muted fp-dbt-lead', text: t('dbp_lead')}));
    RP.page.appendChild(warn(t('dbp_warn'), 'data-fp-warn'));
    RP.servers.forEach(function (s) { RP.page.appendChild(rpCard(s)); });
  }
  FP.view('tool:db_root_password', function () {
    RP = null;
    var page = frame('db_root_password', 'dbp_desc', 'fp-dbp');
    if (!page) { return; }
    var mine = RP = {page: page, servers: []};
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'dbServers').then(function (r) {
      if (RP !== mine) { return; }
      mine.servers = cleanServers(r).list.filter(function (s) { return !s.external; });
      rpDraw();
    }, function (err) { if (RP === mine) { failedPage(page, 'db_root_password', err); } });
  });

  /* ================= All databases ================= */
  var DL = null;
  function cleanDbs(r) {
    r = r && typeof r === 'object' ? r : {};
    var eng = r.engines && typeof r.engines === 'object' ? r.engines : {};
    var states = {};
    ENGINES.forEach(function (e) {
      var x = eng[e] && typeof eng[e] === 'object' ? eng[e] : {};
      states[e] = {available: x.available !== false, truncated: x.truncated === true, sizes: str(x.sizes_error, 200), unreadable: Math.round(num(x.unreadable_records))};
    });
    return {list: arr(r.databases).filter(function (d) { return d && typeof d === 'object' && ENGINES.indexOf(d.engine) >= 0; }).slice(0, 500).map(function (d) {
      return {engine: d.engine, account: str(d.account, 40), name: str(d.name, 80), bytes: Math.max(0, num(d.size_bytes)), suspended: d.suspended === true};
    }), total: Math.round(num(r.total)), offset: Math.round(num(r.offset)), states: states};
  }
  function dlLoad(note) {
    var mine = DL;
    var q = {limit: String(PAGE), offset: String(mine.offset), engine: mine.engine, account: mine.account, q: mine.q};
    return FP.call('get', 'allDbs', undefined, q).then(function (r) {
      if (DL !== mine) { return; }
      mine.data = cleanDbs(r);
      dlDraw(note);
    }, function (err) {
      if (DL !== mine) { return; }
      if (mine.drawn) { UI.showError(mine.page.querySelector('.fp-dbl-form'), err.message); } else { failedPage(mine.page, 'db_list', err); }
    });
  }
  function dlDraw(note) {
    var d = DL.data;
    var q = el('input', {class: 'sig-input', id: 'fp-dbl-q', name: 'q', type: 'search', maxlength: '128', autocomplete: 'off', spellcheck: 'false', value: DL.q});
    var account = el('input', {class: 'sig-input sig-mono', id: 'fp-dbl-account', name: 'account', type: 'text', maxlength: '32', autocomplete: 'off', spellcheck: 'false', value: DL.account});
    var engine = select('fp-dbl-engine', 'engine', [{value: '', text: t('dbl_all_engines')}, {value: 'mysql', text: t('dbt_mariadb')}, {value: 'postgres', text: t('dbt_postgres')}], DL.engine);
    var form = el('form', {class: 'fp-form fp-dbl-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-rules-grid'}, [M.field('fp-dbl-q', t('dbl_q'), q, t('dbl_q_hint')), M.field('fp-dbl-account', t('dbl_account'), account, t('dbl_account_hint')), M.field('fp-dbl-engine', t('dbl_engine'), engine, null)]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('dbl_search')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      DL.q = q.value.trim();
      DL.account = account.value.trim();
      DL.engine = engine.value;
      DL.offset = 0;
      UI.setBusy(b, true);
      dlLoad(t('dbl_updated'));
    });
    var parts = [];
    ENGINES.forEach(function (e) {
      var s = d.states[e];
      if (!s.available) { parts.push(warn(t('dbl_engine_off', {engine: engineTitle(e)}), 'data-fp-engine-off')); }
      if (s.truncated) { parts.push(warn(t('dbl_truncated', {engine: engineTitle(e)}), 'data-fp-truncated')); }
      if (s.sizes) { parts.push(warn(t('dbl_sizes', {engine: engineTitle(e)}), 'data-fp-sizes')); }
      if (s.unreadable) { parts.push(warn(t('dbl_unreadable', {engine: engineTitle(e), count: s.unreadable}), 'data-fp-unreadable')); }
    });
    var from = d.total ? d.offset + 1 : 0;
    var to = d.offset + d.list.length;
    if (!d.list.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': '', text: t(DL.q || DL.account || DL.engine ? 'dbl_none_found' : 'dbl_none')}));
    } else {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-range': '', text: t('dbl_range', {from: count(from), to: count(to), total: count(d.total)})}));
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-dbl-h'}, [el('table', {class: 'sig-table fp-dbl-table'}, [
        el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('dbl_col_db')}), el('th', {scope: 'col', text: t('dbl_col_account')}), el('th', {scope: 'col', text: t('dbl_col_engine')}),
          el('th', {scope: 'col', class: 'fp-num', text: t('dbl_col_size')})])]),
        el('tbody', null, d.list.map(function (x) {
          return el('tr', {'data-fp-db': x.account + '/' + x.name + '/' + x.engine}, [el('th', {scope: 'row', class: 'sig-mono', text: x.name}),
            el('td', null, [el('span', {class: 'sig-mono', text: x.account}), x.suspended ? el('span', {class: 'sig-pill', text: t('dbl_suspended')}) : null]), el('td', {text: engineTitle(x.engine)}),
            el('td', {class: 'fp-num', text: size(x.bytes)})]);
        }))])]));
      var prev = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'prev', disabled: d.offset > 0 ? null : true, text: t('dbl_prev')});
      var next = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'next', disabled: d.offset + d.list.length < d.total ? null : true, text: t('dbl_next')});
      parts.push(el('div', {class: 'fp-actions fp-dbl-pager'}, [prev, next]));
    }
    DL.page.textContent = '';
    DL.page.appendChild(M.card('fp-dbl-form-h', t('dbl_find_title'), [form], 'fp-dbl-find'));
    DL.page.appendChild(M.card('fp-dbl-h', t('dbl_title'), parts, 'fp-dbl'));
    DL.drawn = true;
    if (note) { M.say(DL.page.querySelector('.fp-dbl-find'), note); }
  }
  function dlClick(e) {
    var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !DL || !DL.page.contains(b)) { return; }
    var act = b.getAttribute('data-fp-act');
    if (act !== 'prev' && act !== 'next') { return; }
    DL.offset = Math.max(0, DL.offset + (act === 'next' ? PAGE : -PAGE));
    UI.setBusy(b, true);
    dlLoad('').then(function () { if (DL) { DL.page.querySelector('#fp-dbl-h').focus(); } });
  }
  FP.view('tool:db_list', function () {
    DL = null;
    var page = frame('db_list', 'dbl_desc', 'fp-dbl-page');
    if (!page) { return; }
    DL = {page: page, data: null, q: '', account: '', engine: '', offset: 0, drawn: false};
    page.addEventListener('click', dlClick);
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    dlLoad('');
  });
})();

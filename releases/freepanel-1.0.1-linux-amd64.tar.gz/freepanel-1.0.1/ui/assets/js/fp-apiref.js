/* freePanel API reference, in the admin panel (#/tool/api_reference, the server admin's alone): the HTTP API as it is documented with this build. The text comes
   from the API (GET /server/api-reference, the server's copy of docs/api.md without its internal notes), which only a signed-in admin may call; it is not a file
   of the panel. The page reads it as the small piece of markdown it is
   written in: headings, paragraphs, `- ` lists, code blocks, tables, `code` and **bold**. Nothing is ever turned into HTML: each piece is made with the DOM, its
   text set as text, so no character of the file is markup, a link in it is not drawn as a link, and nothing in it can run. The file is cut into sections at its
   `##` and `###` headings; a search names the sections that hold some text, with how many times, and a section opens with the lines that hold the text marked.
   Page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var MIN_QUERY = 2;
  var MAX_QUERY = 100;
  var MAX_RESULTS = 30;
  var MAX_COUNT = 99;
  var MAX_CODE = 20000;

  var A = null;
  /* the parsed reference, kept for the session: it is the same until the server is updated */
  var LOADED = null;

  function count(n) { return Math.round(n).toLocaleString('en'); }
  function plain(s) { return s.replace(/`/g, '').replace(/\*\*/g, ''); }

  /* ---- the file, read as markdown ---- */
  function splitRow(line) {
    var cells = [];
    var cur = '';
    var s = line.trim();
    if (s.charAt(0) === '|') { s = s.slice(1); }
    for (var i = 0; i < s.length; i++) {
      var c = s.charAt(i);
      if (c === '\\' && s.charAt(i + 1) === '|') { cur += '|'; i++; } else if (c === '|') { cells.push(cur.trim()); cur = ''; } else { cur += c; }
    }
    if (cur.trim() !== '' || cells.length === 0) { cells.push(cur.trim()); }
    return cells;
  }
  var LIST_ITEM = /^(\s*)- (.*)$/;
  function isStarter(line) {
    return /^```/.test(line) || /^#{1,6} /.test(line) || /^\|/.test(line) || LIST_ITEM.test(line);
  }
  function blocksOf(lines) {
    var out = [];
    var i = 0;
    while (i < lines.length) {
      var line = lines[i];
      if (/^\s*$/.test(line)) { i++; continue; }
      if (/^```/.test(line)) {
        var code = [];
        i++;
        while (i < lines.length && !/^```/.test(lines[i])) { code.push(lines[i]); i++; }
        i++;
        out.push({type: 'code', text: code.join('\n').slice(0, MAX_CODE)});
        continue;
      }
      var h = /^(#{1,6}) (.*)$/.exec(line);
      if (h) { out.push({type: 'heading', level: h[1].length, text: h[2]}); i++; continue; }
      if (/^\|/.test(line)) {
        var rows = [];
        while (i < lines.length && /^\|/.test(lines[i])) { rows.push(splitRow(lines[i])); i++; }
        var head = rows.length > 1 && rows[1].every(function (c) { return /^:?-{2,}:?$/.test(c); }) ? rows[0] : null;
        out.push({type: 'table', head: head, rows: rows.slice(head ? 2 : 0)});
        continue;
      }
      if (LIST_ITEM.test(line)) {
        var items = [];
        while (i < lines.length) {
          var m = LIST_ITEM.exec(lines[i]);
          if (m) {
            items.push({depth: Math.min(3, Math.floor(m[1].length / 2)), text: m[2]});
            i++;
          } else if (/^\s+\S/.test(lines[i]) && items.length) {
            items[items.length - 1].text += ' ' + lines[i].trim();
            i++;
          } else if (/^\s*$/.test(lines[i]) && i + 1 < lines.length && (LIST_ITEM.test(lines[i + 1]) || /^\s+\S/.test(lines[i + 1])) && !/^```/.test(lines[i + 1])) {
            i++;
          } else {
            break;
          }
        }
        out.push({type: 'list', items: items});
        continue;
      }
      var para = [line.trim()];
      i++;
      while (i < lines.length && !/^\s*$/.test(lines[i]) && !isStarter(lines[i])) { para.push(lines[i].trim()); i++; }
      out.push({type: 'paragraph', text: para.join(' ')});
    }
    return out;
  }
  /* the file cut into sections at its ## and ### headings (a fence's own # lines are not headings); a #### heading stays inside its section */
  function parse(text) {
    var units = [];
    var cur = null;
    var fence = false;
    var group = '';
    text.replace(/\r\n?/g, '\n').split('\n').forEach(function (line) {
      if (/^```/.test(line)) { fence = !fence; }
      var h = !fence ? /^(#{1,3}) (.+)$/.exec(line) : null;
      if (h) {
        if (h[1].length === 2) { group = plain(h[2]); }
        cur = {id: units.length, level: h[1].length, title: h[1].length === 1 ? '' : plain(h[2]), group: h[1].length === 3 ? group : '', lines: []};
        units.push(cur);
      } else {
        if (!cur) { cur = {id: 0, level: 1, title: '', group: '', lines: []}; units.push(cur); }
        cur.lines.push(line);
      }
    });
    units.forEach(function (u) { u.lower = u.lines.join('\n').toLowerCase(); });
    return units.filter(function (u) { return u.lines.some(function (l) { return l.trim() !== ''; }) || u.level > 1; });
  }

  /* ---- drawing a block ---- */
  /* `code` and **bold** are the two marks drawn; every other character is text */
  // A bold or code span in running text that wraps has a box that spans the lines of its neighbours (data-overlap-ok: it is not a collision); the paragraph itself is still checked
  function inline(text) {
    var out = [];
    text.split(/(`[^`]+`)/).forEach(function (part) {
      if (part.length > 2 && part.charAt(0) === '`' && part.charAt(part.length - 1) === '`') {
        out.push(el('code', {class: 'sig-mono fp-aref-code', 'data-overlap-ok': '', text: part.slice(1, -1)}));
        return;
      }
      part.split(/(\*\*[^*]+\*\*)/).forEach(function (bit) {
        if (bit.length > 4 && bit.slice(0, 2) === '**' && bit.slice(-2) === '**') { out.push(el('strong', {'data-overlap-ok': '', text: bit.slice(2, -2)})); } else if (bit) { out.push(bit); }
      });
    });
    return out;
  }
  function holds(text, q) { return q && text.toLowerCase().indexOf(q) >= 0; }
  function mark(node, hit) { if (hit) { node.className += ' fp-aref-hit'; } return node; }
  var framed = 0;
  function drawBlock(b, q) {
    if (b.type === 'heading') { return el('h3', {class: 'fp-h3 fp-aref-h3', text: plain(b.text)}); }
    if (b.type === 'paragraph') { return mark(el('p', {class: 'fp-aref-p'}, inline(b.text)), holds(b.text, q)); }
    if (b.type === 'code') {
      return mark(el('pre', {class: 'sig-mono fp-aref-pre', tabindex: '0', role: 'region', 'aria-label': t('apiref_example')}, [el('code', {text: b.text})]), holds(b.text, q));
    }
    if (b.type === 'list') {
      return el('ul', {class: 'fp-aref-list'}, b.items.map(function (it) {
        return mark(el('li', {class: 'fp-aref-li fp-aref-d' + it.depth}, inline(it.text)), holds(it.text, q));
      }));
    }
    var id = 'fp-aref-t' + (++framed);
    var cols = b.head ? b.head.length : b.rows.reduce(function (n, r) { return Math.max(n, r.length); }, 0);
    var head = b.head ? el('thead', null, [el('tr', null, b.head.map(function (c) { return el('th', {scope: 'col'}, inline(c)); }))]) : null;
    var body = el('tbody', null, b.rows.map(function (r) {
      var cells = r.map(function (c, k) { return k === 0 && !b.head ? el('th', {scope: 'row'}, inline(c)) : el('td', null, inline(c)); });
      while (cells.length < cols) { cells.push(el('td')); }
      return mark(el('tr', null, cells), holds(r.join(' '), q));
    }));
    return el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-label': t('apiref_table', {n: framed}), id: id}, [el('table', {class: 'sig-table fp-aref-table'}, [head, body])]);
  }

  /* ---- the page ---- */
  function titleOf(u) { return u.level === 1 ? t('apiref_overview') : u.title; }
  function pickField() {
    var select = el('select', {class: 'sig-select', id: 'fp-aref-section', name: 'section'});
    var group = null;
    var last = '';
    A.units.forEach(function (u) {
      if (u.level === 3 && u.group && u.group !== last) { group = el('optgroup', {label: u.group}); select.appendChild(group); last = u.group; }
      var option = el('option', {value: String(u.id), text: titleOf(u), selected: u.id === A.current ? true : null});
      if (u.level === 3 && group) { group.appendChild(option); } else { select.appendChild(option); group = null; last = ''; }
    });
    select.addEventListener('change', function () { openSection(Number(select.value), false); });
    return M.field('fp-aref-section', t('apiref_section'), select, t('apiref_section_hint'));
  }
  function findField() {
    var input = el('input', {class: 'sig-input', id: 'fp-aref-find', name: 'find', type: 'search', maxlength: String(MAX_QUERY), autocomplete: 'off', spellcheck: 'false',
      autocapitalize: 'none', value: A.find, 'aria-describedby': 'fp-aref-find-hint fp-aref-found'});
    input.addEventListener('input', function () { A.find = input.value; drawFound(); });
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && input.value) { e.stopPropagation(); input.value = ''; A.find = ''; drawFound(); }
    });
    return M.field('fp-aref-find', t('apiref_find'), input, t('apiref_find_hint', {min: MIN_QUERY}));
  }
  function wanted() { var q = A.find.trim().toLowerCase(); return q.length >= MIN_QUERY ? q : ''; }
  function occurrences(text, q) {
    var n = 0;
    var at = text.indexOf(q);
    while (at >= 0 && n < MAX_COUNT) { n++; at = text.indexOf(q, at + q.length); }
    return n;
  }
  /* the sections that hold the text, the ones with most first; only this part is drawn again as someone types */
  function drawFound() {
    var box = A.page.querySelector('[data-fp-found]');
    var q = wanted();
    box.textContent = '';
    var line = A.page.querySelector('#fp-aref-found');
    if (!q) {
      line.textContent = A.find.trim() ? t('apiref_find_short', {min: MIN_QUERY}) : '';
      return;
    }
    var hits = A.units.map(function (u) { return {u: u, n: occurrences(u.lower, q)}; }).filter(function (x) { return x.n > 0; });
    hits.sort(function (a, b) { return b.n - a.n || a.u.id - b.u.id; });
    if (!hits.length) { line.textContent = t('apiref_find_none', {text: A.find.trim()}); return; }
    line.textContent = t(hits.length === 1 ? 'apiref_found_1' : 'apiref_found', {n: count(hits.length)});
    box.appendChild(el('ul', {class: 'fp-aref-results'}, hits.slice(0, MAX_RESULTS).map(function (x) {
      return el('li', null, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-aref-result', type: 'button', 'data-fp-act': 'open', 'data-fp-unit': String(x.u.id)}, [
        el('span', {class: 'fp-aref-result-title', text: titleOf(x.u)}),
        el('span', {class: 'fp-muted fp-row-note', text: t(x.n >= MAX_COUNT ? 'apiref_matches_many' : x.n === 1 ? 'apiref_matches_1' : 'apiref_matches', {n: count(x.n)})})])]);
    })));
    if (hits.length > MAX_RESULTS) { box.appendChild(el('p', {class: 'fp-muted fp-row-note', text: t('apiref_more', {n: count(hits.length - MAX_RESULTS)})})); }
  }
  function topCard() {
    return M.card('fp-aref-top-h', t('apiref_top_title'), [el('p', {class: 'fp-muted', text: t('apiref_what')}),
      el('div', {class: 'fp-aref-fields'}, [findField(), pickField()]),
      el('p', {class: 'fp-muted', id: 'fp-aref-found', role: 'status', 'data-fp-found-line': ''}), el('div', {class: 'fp-aref-found', 'data-fp-found': ''})], 'fp-aref-top');
  }
  function sectionCard() {
    var u = A.units[A.current];
    var q = wanted();
    var parts = blocksOf(u.lines).map(function (b) { return drawBlock(b, q); });
    if (!parts.length) { parts.push(el('p', {class: 'fp-muted', text: t('apiref_section_empty')})); }
    var prev = A.current > 0 ? A.units[A.current - 1] : null;
    var next = A.current < A.units.length - 1 ? A.units[A.current + 1] : null;
    var nav = el('div', {class: 'fp-actions fp-aref-nav'}, [
      prev ? el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'open', 'data-fp-unit': String(prev.id), 'aria-label': t('apiref_prev_of', {title: titleOf(prev)}), text: t('apiref_prev')}) : null,
      next ? el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'open', 'data-fp-unit': String(next.id), 'aria-label': t('apiref_next_of', {title: titleOf(next)}), text: t('apiref_next')}) : null]);
    return M.card('fp-aref-sec-h', titleOf(u), parts.concat([nav]), 'fp-aref-section');
  }
  function drawSection(focus) {
    var old = A.page.querySelector('.fp-aref-section');
    framed = 0;
    var fresh = sectionCard();
    if (old) { A.page.replaceChild(fresh, old); } else { A.page.appendChild(fresh); }
    var select = A.page.querySelector('#fp-aref-section');
    if (select) { select.value = String(A.current); }
    var hit = fresh.querySelector('.fp-aref-hit');
    if (hit && hit.scrollIntoView) { hit.scrollIntoView({block: 'center'}); }
    if (focus) { fresh.querySelector('#fp-aref-sec-h').focus({preventScroll: Boolean(hit)}); }
  }
  function openSection(id, focus) {
    if (id >= 0 && id < A.units.length) { A.current = id; drawSection(focus); }
  }
  function onClick(e) {
    var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !A || !A.page.contains(b)) { return; }
    var act = b.getAttribute('data-fp-act');
    if (act === 'open') { openSection(Number(b.getAttribute('data-fp-unit')), true); } else if (act === 'again') { start(true); }
  }

  /* ---- loading the reference ---- */
  /* It comes from the API (GET /server/api-reference), which only a signed-in server admin may call: it is not a file of the panel. */
  function load() {
    if (LOADED) { return LOADED; }
    var p = FP.call('get', 'apiReference').then(function (r) {
      var text = r && r.format === 'markdown' && typeof r.text === 'string' ? r.text : '';
      var units = parse(text);
      if (!units.length) { throw {status: 0, message: t('apiref_failed', {status: 'empty'})}; }
      return units;
    }, function (err) {
      /* a server that has no such route (older than this panel) says so in words of its own; everything else is the panel's usual words */
      throw err && err.status === 404 ? {status: 404, message: t('apiref_missing')} : err;
    });
    /* a failed read is tried again next time, not remembered */
    LOADED = p;
    p.then(null, function () { if (LOADED === p) { LOADED = null; } });
    return p;
  }

  function start(again) {
    A = null;
    var tool = FP.tools.api_reference;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('apiref_desc'), cls: 'fp-mail fp-rpp fp-aref-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    var mine = A = {page: page, units: [], current: 0, find: ''};
    page.addEventListener('click', onClick);
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    if (again) { document.getElementById('fp-h1').focus(); }
    load().then(function (units) {
      if (A !== mine) { return; }
      mine.units = units;
      mine.current = 0;
      page.textContent = '';
      page.appendChild(topCard());
      drawSection(false);
    }, function (err) {
      if (A !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err && err.message ? err.message : t('api_failed'), el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'again', text: t('apiref_try_again')})));
    });
  }
  FP.view('tool:api_reference', function () { start(false); });
})();

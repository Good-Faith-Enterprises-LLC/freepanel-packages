/* freePanel remote database hosts (docs/api.md, "Remote database hosts"): the customer panel's page (#/tool/remote_db) that lists the
   addresses the account's MySQL users may also connect from, adds one (an IPv4 address or a range of /16 or narrower) and takes one away.
   The server's admin switches remote access on; while it is off no host can be added and the listed ones are not in force, and the page
   says so. A host is the only control (MariaDB does not lock a user out after wrong passwords), and the traffic is not encrypted: the
   page says both. Everything the server sends is shown as text. The pieces of a page come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  /* the address a page's paths are built from; FP.account() is the member-aware name (#329), the login until that is on the panel */
  function accountName() { return typeof FP.account === 'function' ? FP.account() : FP.session.user['username']; }

  /* an IPv4 address, or an address with a prefix of 16 to 32: what the server keeps, written as it keeps it */
  var HOST_RE = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9]{2}|[1-9]?[0-9])(?:\/(?:1[6-9]|2[0-9]|3[0-2]))?$/;
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var hosts = (Array.isArray(r.hosts) ? r.hosts : []).filter(function (h) { return typeof h === 'string' && HOST_RE.test(h); }).slice(0, 100);
    var max = typeof r.max === 'number' && r.max > 0 && isFinite(r.max) ? Math.floor(r.max) : 10;
    var port = typeof r.port === 'number' && r.port > 0 && r.port < 65536 ? Math.floor(r.port) : 3306;
    return {allowed: r.allowed === true, hosts: hosts, max: max, port: port};
  }

  var RD = {page: null, state: null, account: ''};

  function hostRow(h) {
    return el('li', {class: 'fp-rdh-item', 'data-fp-host': h}, [el('span', {class: 'sig-mono fp-rdh-name', text: h}),
      el('div', {class: 'fp-rdh-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'rd-remove',
        'aria-label': t('rdh_remove_of', {host: h}), text: t('rdh_remove')})])]);
  }
  function addForm() {
    var input = el('input', {class: 'sig-input sig-mono', id: 'fp-rdh-host', name: 'host', type: 'text', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none',
      maxlength: '18', 'aria-describedby': 'fp-rdh-host-hint'});
    var form = el('form', {class: 'fp-form fp-rdh-form', novalidate: ''}, [M.errorLine(),
      M.field('fp-rdh-host', t('rdh_host'), input, t('rdh_host_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('rdh_add')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var v = input.value.trim();
      if (!HOST_RE.test(v)) { M.fieldError(form, input, t('rdh_bad_host')); return; }
      var mine = RD.page;
      UI.setBusy(b, true);
      var before = RD.state.hosts;
      FP.call('post', 'acctRemoteHosts', {host: v}, RD.account).then(function (r) {
        if (RD.page !== mine) { return; }
        RD.state = clean(r);
        /* the server keeps a range as its network address (203.0.113.7/24 is 203.0.113.0/24): the page names what was kept */
        var kept = RD.state.hosts.filter(function (h) { return before.indexOf(h) < 0; })[0] || v;
        render();
        M.say(RD.page.querySelector('.fp-rdh-card'), t('rdh_added', {host: kept}));
        RD.page.querySelector('#fp-rdh-host').focus();
      }, function (err) {
        if (RD.page !== mine) { return; }
        UI.setBusy(b, false);
        /* a refusal with no field (the switch is off, already listed, too many) is about the host */
        if (err && !err.field && err.status === 409) { M.fieldError(form, input, err.message); } else { M.failed(form, err); }
      });
    });
    return form;
  }
  function card() {
    var S = RD.state;
    var parts = [M.statusLine()];
    if (!S.allowed) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-rdh-off': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('rdh_off')})]));
    }
    parts.push(el('p', {class: 'fp-muted', text: t('rdh_what', {port: S.port})}));
    parts.push(el('p', {class: 'fp-muted', 'data-fp-rdh-care': '', text: t('rdh_care')}));
    if (S.allowed) {
      parts.push(S.hosts.length >= S.max ? el('p', {class: 'fp-muted', 'data-fp-rdh-full': '', text: t('rdh_full', {max: S.max})}) : addForm());
    }
    if (!S.hosts.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t(S.allowed ? 'rdh_none' : 'rdh_none_off')}));
    } else {
      parts.push(el('p', {class: 'fp-muted fp-rdh-count', 'data-fp-count': '', text: t(S.hosts.length === 1 ? 'rdh_count_1' : 'rdh_count', {n: S.hosts.length, max: S.max})}),
        el('ul', {class: 'fp-rdh-list', 'aria-labelledby': 'fp-rdh-h'}, S.hosts.map(hostRow)));
      if (!S.allowed) { parts.push(el('p', {class: 'fp-muted', text: t('rdh_kept_off')})); }
    }
    return M.card('fp-rdh-h', t('rdh_title'), parts, 'fp-rdh-card');
  }
  function render() {
    RD.page.textContent = '';
    RD.page.appendChild(card());
  }

  document.addEventListener('click', function (e) {
    var node = e.target.closest ? e.target : null;
    var b = node && node.closest('[data-fp-act]');
    if (!b || !RD.page || !RD.page.contains(b) || !RD.state) { return; }
    var a = b.getAttribute('data-fp-act');
    var li = b.closest('li[data-fp-host]');
    var host = li ? li.getAttribute('data-fp-host') : '';
    var mine = RD.page;
    if (a === 'rd-remove' && host) {
      M.confirmIn(li.querySelector('.fp-rdh-acts'), t('rdh_remove_ask', {host: host}), 'rd-remove-yes', t('rdh_remove'));
    } else if (a === 'confirm-no' && host) {
      var again = hostRow(host);
      li.replaceWith(again);
      again.querySelector('[data-fp-act="rd-remove"]').focus();
    } else if (a === 'rd-remove-yes' && host) {
      UI.setBusy(b, true);
      FP.call('del', 'acctRemoteHost', undefined, {name: RD.account, host: host}).then(function (r) {
        if (RD.page !== mine) { return; }
        var i = RD.state.hosts.indexOf(host);
        RD.state = clean(r);
        render();
        M.say(RD.page.querySelector('.fp-rdh-card'), t('rdh_removed', {host: host}));
        var next = RD.state.hosts[Math.min(i, RD.state.hosts.length - 1)];
        var target = next ? RD.page.querySelector('li[data-fp-host="' + window.CSS.escape(next) + '"] [data-fp-act="rd-remove"]') : RD.page.querySelector('#fp-rdh-host');
        (target || RD.page.querySelector('#fp-rdh-h')).focus();
      }, function (err) {
        if (RD.page !== mine) { return; }
        if (err && err.status === 404) {
          /* not listed any more: the row goes, and the server's words say so */
          RD.state.hosts = RD.state.hosts.filter(function (x) { return x !== host; });
          render();
          UI.showError(RD.page.querySelector('.fp-rdh-card'), err.message);
          return;
        }
        var back = hostRow(host);
        li.replaceWith(back);
        back.querySelector('[data-fp-act="rd-remove"]').focus();
        UI.showError(RD.page.querySelector('.fp-rdh-card'), err.message);
      });
    }
  });

  FP.view('tool:remote_db', function () {
    RD.page = null;
    var tool = FP.tools.remote_db;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('rdh_desc'), cls: 'fp-mail fp-rdh-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    RD.page = body;
    RD.account = accountName();
    RD.state = null;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'acctRemoteHosts', undefined, RD.account).then(function (r) {
      if (RD.page !== body) { return; }
      RD.state = clean(r);
      render();
    }, function (err) {
      if (RD.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

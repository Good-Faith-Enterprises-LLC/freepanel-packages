/* freePanel backup destinations (#/tool/backup_targets), the admin panel's page for copying archives to other places
   (docs/api.md, "Remote copies"): the switch that allows it (off until the admin turns it on, and nothing connects out
   while it is off), the SFTP servers and S3-compatible buckets archives are copied to, a server's host key checked and
   accepted by comparing its fingerprint, and a test of a destination. Passwords, keys and secret keys are typed in,
   sent, and never shown again: the page only knows that one is saved, leaving it empty keeps it, and a box removes it.
   Everything the server says is drawn as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;
  var BK = FP.bk;

  var str = BK.str;
  var MAX_NAME = 60;

  var T = null;

  /* ---------- what the server says, kept to the shapes the page draws ---------- */
  function int(v, d) { return typeof v === 'number' && isFinite(v) ? Math.floor(v) : d; }
  function clip(v, n) { return str(v).slice(0, n); }
  function cleanDest(d) {
    if (!d || typeof d !== 'object' || (d.kind !== 'sftp' && d.kind !== 's3') || int(d.id, 0) < 1) { return null; }
    var out = {id: int(d.id, 0), name: clip(d.name, MAX_NAME), kind: d.kind, enabled: d.enabled === true, keep_local: d.keep_local === true,
      problem: clip(d.problem, 300), sftp: null, s3: null};
    var s = d.sftp && typeof d.sftp === 'object' ? d.sftp : null;
    var b = d.s3 && typeof d.s3 === 'object' ? d.s3 : null;
    if (d.kind === 'sftp') {
      s = s || {};
      out.sftp = {host: clip(s.host, 253), port: int(s.port, 22), user: clip(s.user, 64), dir: clip(s.dir, 255), host_key: clip(s.host_key, 2048),
        fingerprint: clip(s.host_key_fingerprint, 100), password_set: s.password_set === true, private_key_set: s.private_key_set === true,
        passphrase_set: s.passphrase_set === true};
    } else {
      b = b || {};
      out.s3 = {endpoint: clip(b.endpoint, 300), region: clip(b.region, 32), bucket: clip(b.bucket, 63), prefix: clip(b.prefix, 200),
        access_key: clip(b.access_key, 128), path_style: b.path_style === true, secret_key_set: b.secret_key_set === true};
    }
    return out;
  }
  function cleanList(r) {
    r = r && typeof r === 'object' ? r : {};
    return {allowed: r.allowed === true, max: Math.min(Math.max(int(r.max, 10), 1), 100),
      dests: (Array.isArray(r.destinations) ? r.destinations : []).map(cleanDest).filter(Boolean)};
  }
  function take(list) {
    T.allowed = list.allowed;
    T.max = list.max;
    T.dests = list.dests;
  }
  function find(id) { return T.dests.filter(function (d) { return d.id === id; })[0] || null; }

  function where(d) {
    if (d.kind === 'sftp') {
      var s = d.sftp;
      return t('bkt_where_sftp', {user: s.user, host: s.host, port: s.port, dir: s.dir || t('bkt_home')});
    }
    var b = d.s3;
    return t('bkt_where_s3', {bucket: b.bucket, endpoint: b.endpoint, prefix: b.prefix || t('bkt_root')});
  }

  /* ---------- the switch ---------- */
  function switchCard() {
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t('bkt_switch_desc')}),
      el('p', {'data-fp-bkt-state': '', class: T.allowed ? '' : 'fp-muted', text: t(T.allowed ? 'bkt_on' : 'bkt_off')}),
      el('div', {class: 'fp-actions', 'data-fp-bkt-switch-acts': ''}, [el('button', {class: 'sig-btn ' + (T.allowed ? 'sig-btn--secondary' : 'sig-btn--primary'),
        type: 'button', 'data-fp-act': T.allowed ? 'switch-off' : 'switch-on', text: t(T.allowed ? 'bkt_turn_off' : 'bkt_turn_on')})])];
    return M.card('fp-bkt-switch-h', t('bkt_switch_title'), parts, 'fp-bkt-switch');
  }
  function askSwitch() {
    var acts = T.page.querySelector('[data-fp-bkt-switch-acts]');
    acts.textContent = '';
    var yes = el('button', {class: 'sig-btn sig-btn--danger', type: 'button', 'data-fp-act': 'switch-yes', text: t('bkt_turn_on_yes'), 'aria-describedby': 'fp-bkt-ask'});
    var no = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'switch-no', text: t('cancel'), 'aria-describedby': 'fp-bkt-ask'});
    acts.appendChild(el('p', {class: 'fp-mail-confirm', id: 'fp-bkt-ask', text: t('bkt_ask_on')}));
    acts.appendChild(yes);
    acts.appendChild(no);
    no.focus();
  }
  function setSwitch(allowed, button) {
    var card = T.page.querySelector('.fp-bkt-switch');
    UI.showError(card, '');
    M.say(card, '');
    UI.setBusy(button, true);
    var mine = T;
    FP.call('put', 'backupRemote', {allowed: allowed}).then(function (r) {
      if (T !== mine) { return; }
      take(cleanList(r));
      drawAll();
      M.say(T.page.querySelector('.fp-bkt-switch'), t(T.allowed ? 'bkt_now_on' : 'bkt_now_off'));
      T.page.querySelector('#fp-bkt-switch-h').focus();
    }, function (err) {
      if (T !== mine) { return; }
      UI.setBusy(button, false);
      UI.showError(card, err.message);
      button.focus();
    });
  }

  /* ---------- the destinations ---------- */
  function listCard() {
    var parts = [M.errorLine(), M.statusLine()];
    if (!T.allowed) { parts.push(el('p', {class: 'fp-muted', 'data-fp-bkt-offnote': '', text: t('bkt_off_note')})); }
    if (!T.dests.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('bkt_none')}));
    } else {
      var tbody = el('tbody', null, T.dests.map(function (d) {
        var notes = [d.enabled ? t('bkt_enabled') : t('bkt_disabled'), d.keep_local ? t('bkt_keeps_local') : t('bkt_drops_local')];
        return el('tr', {'data-fp-dest': String(d.id)}, [
          el('th', {scope: 'row', class: 'fp-mail-name'}, [el('span', {text: d.name}), d.problem ? el('p', {class: 'fp-bk-bad', 'data-fp-bkt-problem': '', text: t('bkt_problem', {why: d.problem})}) : null]),
          el('td', {text: t('bkt_kind_' + d.kind)}),
          el('td', {class: 'fp-bkt-where', text: where(d)}),
          el('td', {text: notes.join(', ')}),
          el('td', {class: 'fp-mail-acts'}, [
            el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'test', 'aria-label': t('bkt_test_of', {name: d.name}), text: t('bkt_test')}),
            el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'edit', 'aria-label': t('bkt_edit_of', {name: d.name}), text: t('bkt_edit')}),
            el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'delete', 'aria-label': t('bkt_delete_of', {name: d.name}), text: t('bkt_delete')})])]);
      }));
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-bkt-list-h'}, [
        el('table', {class: 'sig-table fp-mail-table fp-bk-table'}, [el('thead', null, [el('tr', null, [
          el('th', {scope: 'col', text: t('bkt_name')}), el('th', {scope: 'col', text: t('bkt_type')}), el('th', {scope: 'col', text: t('bkt_where')}),
          el('th', {scope: 'col', text: t('bkt_settings')}), el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]), tbody])]));
    }
    var full = T.dests.length >= T.max;
    parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'add', disabled: full,
      'aria-describedby': full ? 'fp-bkt-full' : null, text: t('bkt_add')}), full ? el('span', {class: 'sig-hint', id: 'fp-bkt-full', text: t('bkt_full', {max: T.max})}) : null]));
    return M.card('fp-bkt-list-h', t('bkt_list_title'), parts, 'fp-bkt-list');
  }
  function askDelete(row) {
    var d = find(parseInt(row.getAttribute('data-fp-dest'), 10));
    if (!d) { return; }
    var cell = row.querySelector('.fp-mail-acts');
    cell.textContent = '';
    var yes = el('button', {class: 'sig-btn sig-btn--danger sig-btn--sm', type: 'button', 'data-fp-act': 'delete-yes', text: t('bkt_delete'), 'aria-describedby': 'fp-bkt-del-q'});
    var no = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'delete-no', text: t('cancel'), 'aria-describedby': 'fp-bkt-del-q'});
    cell.appendChild(el('span', {class: 'fp-mail-confirm', id: 'fp-bkt-del-q', text: t('bkt_ask_delete', {name: d.name})}));
    cell.appendChild(yes);
    cell.appendChild(no);
    no.focus();
  }
  function rowButton(id, act) {
    return T.page.querySelector('[data-fp-dest="' + id + '"] [data-fp-act="' + act + '"]');
  }
  function testSaved(id, button) {
    var d = find(id);
    var card = T.page.querySelector('.fp-bkt-list');
    UI.showError(card, '');
    M.say(card, '');
    UI.setBusy(button, true);
    var mine = T;
    FP.call('post', 'backupDestinationTest', undefined, {id: String(id)}).then(function (r) {
      if (T !== mine) { return; }
      UI.setBusy(button, false);
      if (r && r.ok === true) { M.say(card, t('bkt_test_ok', {name: d ? d.name : ''})); } else {
        UI.showError(card, t('bkt_test_failed', {name: d ? d.name : '', error: clip(r && r.error, 600) || t('api_failed')}));
      }
      button.focus();
    }, function (err) {
      if (T !== mine) { return; }
      UI.setBusy(button, false);
      UI.showError(card, err.message);
      button.focus();
    });
  }
  function remove(id, button) {
    var d = find(id);
    var card = T.page.querySelector('.fp-bkt-list');
    UI.showError(card, '');
    M.say(card, '');
    UI.setBusy(button, true);
    var mine = T;
    FP.call('del', 'backupDestination', undefined, {id: String(id)}).then(function () {
      if (T !== mine) { return; }
      T.dests = T.dests.filter(function (x) { return x.id !== id; });
      if (T.form && T.form.id === id) { T.form = null; }
      drawAll();
      M.say(T.page.querySelector('.fp-bkt-list'), t('bkt_deleted', {name: d ? d.name : ''}));
      T.page.querySelector('#fp-bkt-list-h').focus();
    }, function (err) {
      if (T !== mine) { return; }
      drawAll();
      UI.showError(T.page.querySelector('.fp-bkt-list'), err.message);
      var again = rowButton(id, 'delete');
      (again || T.page.querySelector('#fp-bkt-list-h')).focus();
    });
  }

  /* ---------- the form ---------- */
  function check(id, name, label, checked, hint) {
    return el('div', {class: 'fp-bkt-check'}, [el('label', {class: 'fp-check', for: id}, [el('input', {type: 'checkbox', id: id, name: name, checked: checked,
      'aria-describedby': hint ? id + '-hint' : null}), el('span', {text: label})]), hint ? el('span', {class: 'sig-hint', id: id + '-hint', text: hint}) : null]);
  }
  function text(id, name, label, value, hint, extra) {
    var attrs = {class: 'sig-input', id: id, name: name, type: 'text', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', value: value};
    Object.keys(extra || {}).forEach(function (k) { attrs[k] = extra[k]; });
    return M.field(id, label, el('input', attrs), hint);
  }
  /* a secret: never filled in; empty keeps what is saved, a box removes it */
  function secret(id, name, label, saved, hint, multi) {
    var attrs = {class: multi ? 'sig-input' : 'sig-input', id: id, name: name, autocomplete: 'new-password', spellcheck: 'false', autocapitalize: 'none',
      placeholder: saved ? t('bkt_secret_saved') : null};
    var control = multi ? el('textarea', Object.assign({rows: '5'}, attrs)) : el('input', Object.assign({type: 'password'}, attrs));
    var nodes = [M.field(id, label, control, saved ? t('bkt_secret_keep') : hint)];
    if (saved) { nodes.push(check(id + '-clear', name + '_clear', t('bkt_secret_remove', {what: label.toLowerCase()}), false)); }
    return el('div', {class: 'fp-bkt-secret'}, nodes);
  }
  function sftpFields(d) {
    var s = d && d.sftp ? d.sftp : {host: '', port: 22, user: '', dir: '', host_key: '', fingerprint: '', password_set: false, private_key_set: false, passphrase_set: false};
    var box = el('div', {class: 'fp-bkt-kind', 'data-fp-kind': 'sftp'});
    box.appendChild(text('fp-bkt-host', 'host', t('bkt_host'), s.host, t('bkt_host_hint'), {maxlength: '253'}));
    box.appendChild(M.field('fp-bkt-port', t('bkt_port'), el('input', {class: 'sig-input fp-num-input', id: 'fp-bkt-port', name: 'port', type: 'number', inputmode: 'numeric',
      min: '1', max: '65535', step: '1', value: String(s.port)}), null));
    box.appendChild(text('fp-bkt-user', 'user', t('bkt_user'), s.user, null, {maxlength: '64'}));
    box.appendChild(text('fp-bkt-dir', 'dir', t('bkt_dir'), s.dir, t('bkt_dir_hint'), {maxlength: '255'}));
    box.appendChild(el('div', {class: 'fp-bkt-hostkey'}, [
      M.field('fp-bkt-hostkey', t('bkt_hostkey'), el('input', {class: 'sig-input sig-mono', id: 'fp-bkt-hostkey', name: 'host_key', type: 'text', autocomplete: 'off', spellcheck: 'false',
        autocapitalize: 'none', maxlength: '2048', value: s.host_key}), t('bkt_hostkey_hint')),
      el('p', {class: 'sig-mono fp-bkt-fp', 'data-fp-bkt-fp': '', hidden: s.fingerprint ? null : true, text: s.fingerprint ? t('bkt_fingerprint', {fingerprint: s.fingerprint}) : ''}),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'probe', text: t('bkt_probe')})]),
      el('div', {class: 'fp-bkt-probe', 'data-fp-bkt-probe': '', role: 'status'})]));
    box.appendChild(el('h3', {class: 'fp-h3', text: t('bkt_signin')}));
    box.appendChild(el('p', {class: 'fp-muted', text: t(d ? 'bkt_signin_desc_edit' : 'bkt_signin_desc')}));
    box.appendChild(secret('fp-bkt-password', 'password', t('bkt_password'), s.password_set, null, false));
    box.appendChild(secret('fp-bkt-key', 'private_key', t('bkt_private_key'), s.private_key_set, t('bkt_private_key_hint'), true));
    box.appendChild(secret('fp-bkt-passphrase', 'passphrase', t('bkt_passphrase'), s.passphrase_set, t('bkt_passphrase_hint'), false));
    return box;
  }
  function s3Fields(d) {
    var b = d && d.s3 ? d.s3 : {endpoint: '', region: '', bucket: '', prefix: '', access_key: '', path_style: false, secret_key_set: false};
    var box = el('div', {class: 'fp-bkt-kind', 'data-fp-kind': 's3'});
    box.appendChild(text('fp-bkt-endpoint', 'endpoint', t('bkt_endpoint'), b.endpoint, t('bkt_endpoint_hint'), {maxlength: '300', inputmode: 'url'}));
    box.appendChild(text('fp-bkt-region', 'region', t('bkt_region'), b.region, t('bkt_region_hint'), {maxlength: '32'}));
    box.appendChild(text('fp-bkt-bucket', 'bucket', t('bkt_bucket'), b.bucket, null, {maxlength: '63'}));
    box.appendChild(text('fp-bkt-prefix', 'prefix', t('bkt_prefix'), b.prefix, t('bkt_prefix_hint'), {maxlength: '200'}));
    box.appendChild(check('fp-bkt-pathstyle', 'path_style', t('bkt_pathstyle'), b.path_style, t('bkt_pathstyle_hint')));
    box.appendChild(el('h3', {class: 'fp-h3', text: t('bkt_signin')}));
    box.appendChild(el('p', {class: 'fp-muted', text: t(d ? 'bkt_s3_signin_desc_edit' : 'bkt_s3_signin_desc')}));
    box.appendChild(text('fp-bkt-access', 'access_key', t('bkt_access_key'), b.access_key, null, {maxlength: '128'}));
    box.appendChild(secret('fp-bkt-secretkey', 'secret_key', t('bkt_secret_key'), b.secret_key_set, null, false));
    return box;
  }
  function showKind(form, kind) {
    var boxes = form.querySelectorAll('[data-fp-kind]');
    for (var i = 0; i < boxes.length; i++) { boxes[i].hidden = boxes[i].getAttribute('data-fp-kind') !== kind; }
  }
  function formCard() {
    var f = T.form;
    var d = f.id ? find(f.id) : null;
    var form = el('form', {class: 'fp-form fp-mail-form fp-bkt-form', novalidate: '', 'data-fp-form': 'destination'}, [M.errorLine(), M.statusLine()]);
    form.appendChild(text('fp-bkt-name', 'name', t('bkt_name'), d ? d.name : '', t('bkt_name_hint'), {maxlength: String(MAX_NAME)}));
    if (d) {
      form.appendChild(el('p', {class: 'fp-bkt-fixed', text: t('bkt_kind_fixed', {kind: t('bkt_kind_' + d.kind)})}));
      form.appendChild(el('input', {type: 'hidden', name: 'kind', value: d.kind}));
    } else {
      var kind = el('select', {class: 'sig-select', id: 'fp-bkt-kind', name: 'kind'}, ['sftp', 's3'].map(function (k) {
        return el('option', {value: k, text: t('bkt_kind_' + k), selected: k === f.kind ? true : null});
      }));
      kind.addEventListener('change', function () { f.kind = kind.value; showKind(form, kind.value); });
      form.appendChild(M.field('fp-bkt-kind', t('bkt_type'), kind, null));
    }
    form.appendChild(sftpFields(d && d.kind === 'sftp' ? d : null));
    form.appendChild(s3Fields(d && d.kind === 's3' ? d : null));
    showKind(form, d ? d.kind : f.kind);
    form.appendChild(check('fp-bkt-enabled', 'enabled', t('bkt_enabled_label'), d ? d.enabled : true, t('bkt_enabled_hint')));
    form.appendChild(check('fp-bkt-keeplocal', 'keep_local', t('bkt_keeplocal'), d ? d.keep_local : true, t('bkt_keeplocal_hint')));
    form.appendChild(el('div', {class: 'fp-actions'}, [
      el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t(d ? 'bkt_save' : 'bkt_create')}),
      el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'form-test', text: t('bkt_test_form')}),
      el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'form-close', text: t('cancel')})]));
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      submit(form, d);
    });
    form.addEventListener('input', function (e) {
      if (e.target && e.target.name === 'host_key') {
        var fp = form.querySelector('[data-fp-bkt-fp]');
        fp.hidden = true;
        fp.textContent = '';
      }
    });
    return M.card('fp-bkt-form-h', d ? t('bkt_edit_title', {name: d.name}) : t('bkt_add_title'), [form], 'fp-bkt-formcard');
  }
  /* the form's values as the server takes them. A secret that is empty is left out (the saved one stays); a ticked box
     removes the saved one; text replaces it. A number or text that is wrong is for the server to say. */
  function read(form, d) {
    var val = function (n) { return form.querySelector('[name="' + n + '"]').value.trim(); };
    var on = function (n) { return form.querySelector('[name="' + n + '"]').checked; };
    var kind = d ? d.kind : val('kind');
    var body = {name: val('name'), kind: kind, enabled: on('enabled'), keep_local: on('keep_local')};
    var secretOf = function (n, trim) {
      var box = form.querySelector('[name="' + n + '_clear"]');
      var v = form.querySelector('[name="' + n + '"]').value;
      if (box && box.checked) { return ''; }
      if (!v) { return undefined; }
      return trim ? v.trim() : v;
    };
    if (kind === 'sftp') {
      var port = val('port');
      body.sftp = {host: val('host'), port: /^[0-9]{1,5}$/.test(port) ? parseInt(port, 10) : (port ? -1 : 22), user: val('user'), dir: val('dir'),
        host_key: val('host_key'), password: secretOf('password', false), private_key: secretOf('private_key', false), passphrase: secretOf('passphrase', false)};
    } else {
      body.s3 = {endpoint: val('endpoint'), region: val('region'), bucket: val('bucket'), prefix: val('prefix'), access_key: val('access_key'),
        path_style: on('path_style'), secret_key: secretOf('secret_key', true)};
    }
    return body;
  }
  function submit(form, d) {
    var b = M.start(form);
    if (!b) { return; }
    var body = read(form, d);
    var mine = T;
    UI.setBusy(b, true);
    FP.call(d ? 'put' : 'post', d ? 'backupDestination' : 'backupDestinations', body, d ? {id: String(d.id)} : undefined).then(function (r) {
      if (T !== mine) { return; }
      var saved = cleanDest(r);
      if (saved) {
        T.dests = d ? T.dests.map(function (x) { return x.id === saved.id ? saved : x; }) : T.dests.concat([saved]);
      }
      T.form = null;
      drawAll();
      M.say(T.page.querySelector('.fp-bkt-list'), t(d ? 'bkt_saved' : 'bkt_created', {name: saved ? saved.name : body.name}));
      var again = saved ? rowButton(saved.id, 'edit') : null;
      (again || T.page.querySelector('#fp-bkt-list-h')).focus();
    }, function (err) {
      if (T !== mine) { return; }
      UI.setBusy(b, false);
      M.failed(form, err);
    });
  }
  function testForm(form, button) {
    var d = T.form.id ? find(T.form.id) : null;
    if (!M.start(form)) { return; }
    var body = read(form, d);
    if (d) { body.id = d.id; }
    var mine = T;
    UI.setBusy(button, true);
    FP.call('post', 'backupDestinationsTest', body).then(function (r) {
      if (T !== mine) { return; }
      UI.setBusy(button, false);
      if (r && r.ok === true) { M.say(form, t('bkt_form_test_ok')); } else {
        UI.showError(form, t('bkt_form_test_failed', {error: clip(r && r.error, 600) || t('api_failed')}));
      }
      button.focus();
    }, function (err) {
      if (T !== mine) { return; }
      UI.setBusy(button, false);
      M.failed(form, err);
      if (!form.contains(document.activeElement)) { button.focus(); }
    });
  }
  function probe(form, button) {
    var box = form.querySelector('[data-fp-bkt-probe]');
    box.textContent = '';
    UI.showError(form, '');
    var host = form.querySelector('[name="host"]').value.trim();
    var port = form.querySelector('[name="port"]').value.trim();
    var body = {host: host};
    if (/^[0-9]{1,5}$/.test(port)) { body.port = parseInt(port, 10); }
    var mine = T;
    UI.setBusy(button, true);
    FP.call('post', 'backupDestinationsProbe', body).then(function (r) {
      if (T !== mine) { return; }
      UI.setBusy(button, false);
      var key = r && r.key && typeof r.key === 'object' ? {type: clip(r.key.type, 40), fingerprint: clip(r.key.fingerprint, 100), line: clip(r.key.line, 2048)} : null;
      if (!key || !key.fingerprint || !key.line) {
        box.appendChild(el('p', {class: 'fp-bk-bad', text: t('bkt_probe_failed', {error: clip(r && r.error, 600) || t('api_failed')})}));
        button.focus();
        return;
      }
      var use = el('button', {class: 'sig-btn sig-btn--primary sig-btn--sm', type: 'button', 'data-fp-act': 'use-key', text: t('bkt_use_key')});
      use.addEventListener('click', function () {
        form.querySelector('[name="host_key"]').value = key.line;
        var fp = form.querySelector('[data-fp-bkt-fp]');
        fp.hidden = false;
        fp.textContent = t('bkt_fingerprint', {fingerprint: key.fingerprint});
        box.textContent = '';
        box.appendChild(el('p', {text: t('bkt_key_used')}));
        form.querySelector('[name="host_key"]').focus();
      });
      box.appendChild(el('p', {text: t('bkt_probe_found', {type: key.type, fingerprint: key.fingerprint})}));
      box.appendChild(el('p', {class: 'fp-muted', text: t('bkt_probe_compare')}));
      box.appendChild(use);
    }, function (err) {
      if (T !== mine) { return; }
      UI.setBusy(button, false);
      M.failed(form, err);
      if (!form.contains(document.activeElement)) { button.focus(); }
    });
  }

  /* ---------- page ---------- */
  /* every card drawn again; the form stays as it is (what was typed in it too) unless a new one is asked for */
  function drawAll(freshForm) {
    var active = document.activeElement;
    var key = null;
    if (active && T.page.contains(active)) {
      var row = active.closest('[data-fp-dest]');
      key = {id: active.id, act: active.getAttribute('data-fp-act'), row: row ? row.getAttribute('data-fp-dest') : ''};
    }
    var keep = T.form && !freshForm ? T.page.querySelector('.fp-bkt-formcard') : null;
    var said = ['.fp-bkt-switch', '.fp-bkt-list'].map(function (c) {
      var n = T.page.querySelector(c + ' [data-fp-status]');
      return n ? n.textContent : '';
    });
    T.page.textContent = '';
    T.page.appendChild(switchCard());
    T.page.appendChild(listCard());
    if (T.form) { T.page.appendChild(keep || formCard()); }
    M.say(T.page.querySelector('.fp-bkt-switch'), said[0]);
    M.say(T.page.querySelector('.fp-bkt-list'), said[1]);
    if (key) {
      var again = key.id ? T.page.querySelector('#' + window.CSS.escape(key.id)) :
        key.row && key.act ? rowButton(key.row, key.act) : (key.act ? T.page.querySelector('[data-fp-act="' + key.act + '"]') : null);
      if (again) { again.focus(); }
    }
  }
  function openForm(id) {
    T.form = {id: id, kind: 'sftp'};
    T.back = id;
    drawAll(true);
    var h = T.page.querySelector('#fp-bkt-form-h');
    h.focus();
    if (h.scrollIntoView) { h.scrollIntoView({block: 'start'}); }
  }
  function onClick(e) {
    var target = e.target && e.target.closest ? e.target : null;
    var b = target && T && T.page && T.page.contains(target) ? target.closest('[data-fp-act]') : null;
    if (!b) { return; }
    var act = b.getAttribute('data-fp-act');
    var row = b.closest('[data-fp-dest]');
    var id = row ? parseInt(row.getAttribute('data-fp-dest'), 10) : 0;
    if (act === 'switch-on') {
      askSwitch();
    } else if (act === 'switch-off') {
      setSwitch(false, b);
    } else if (act === 'switch-yes') {
      setSwitch(true, b);
    } else if (act === 'switch-no') {
      drawAll();
      T.page.querySelector('[data-fp-act="switch-on"]').focus();
    } else if (act === 'add') {
      openForm(0);
    } else if (act === 'edit') {
      openForm(id);
    } else if (act === 'test') {
      testSaved(id, b);
    } else if (act === 'delete') {
      askDelete(row);
    } else if (act === 'delete-no') {
      drawAll();
      (rowButton(id, 'delete') || T.page.querySelector('#fp-bkt-list-h')).focus();
    } else if (act === 'delete-yes') {
      remove(id, b);
    } else if (act === 'form-close') {
      T.form = null;
      drawAll();
      var back = T.back ? rowButton(T.back, 'edit') : null;
      (back || T.page.querySelector('[data-fp-act="add"]')).focus();
    } else if (act === 'form-test') {
      testForm(b.closest('form'), b);
    } else if (act === 'probe') {
      probe(b.closest('form'), b);
    }
  }
  document.addEventListener('click', onClick);

  FP.view('tool:backup_targets', function () {
    var tool = FP.tools.backup_targets;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('bkt_desc'), cls: 'fp-mail fp-bk fp-bkt',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    T = {page: body, allowed: false, max: 10, dests: [], form: null, back: 0};
    var mine = T;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'backupDestinations').then(function (r) {
      if (T !== mine) { return; }
      take(cleanList(r));
      drawAll();
    }, function (err) {
      if (T !== mine) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

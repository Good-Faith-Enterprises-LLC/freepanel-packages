/* freePanel billing reports (#/tool/billing_reports; docs/api.md, "Billing: reports"; docs/billing/navigation-map.md, "Reports"): one page
   with a report picker, in order Income, Sales by plan, Aged debt and Tax; a range (from, to, by day, month or year) above a bar chart of
   the report's main figure and its table, and Download CSV of the same report. The chart is one series in the accent colour, drawn as SVG
   with no inline style; each bar says its value on hover, and the table below is the same figures in words. Amounts are whole cents. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;
  var M = FP.mail;
  var SVG = 'http://www.w3.org/2000/svg';

  var KINDS = ['income', 'sales', 'aged-debt', 'tax'];
  var PATH = {income: 'billingReportIncome', sales: 'billingReportSales', 'aged-debt': 'billingReportAged', tax: 'billingReportTax'};
  function sv(name, attrs, kids) {
    var n = document.createElementNS(SVG, name);
    Object.keys(attrs || {}).forEach(function (k) { if (attrs[k] !== null && attrs[k] !== undefined) { n.setAttribute(k, String(attrs[k])); } });
    (kids || []).forEach(function (k) { if (k) { n.appendChild(k); } });
    return n;
  }
  /* bars of one series: points [{label, value, text}]; money says whether value is cents. Bars below the baseline for a negative value */
  function chart(title, points) {
    var W = 640;
    var H = 220;
    var top = 12;
    var bottom = 4;
    var left = 8;
    var n = Math.max(points.length, 1);
    var max = Math.max.apply(null, [0].concat(points.map(function (p) { return p.value; })));
    var min = Math.min.apply(null, [0].concat(points.map(function (p) { return p.value; })));
    var span = max - min || 1;
    var plot = H - top - bottom;
    var y = function (v) { return top + (max - v) / span * plot; };
    var slot = (W - left * 2) / n;
    var bw = Math.max(2, Math.min(36, slot - 4));
    var base = y(0);
    var bars = points.map(function (p, i) {
      var x = left + i * slot + (slot - bw) / 2;
      var h = Math.max(p.value ? 1 : 0, Math.abs(y(p.value) - base));
      return sv('rect', {class: 'fp-brp-bar' + (p.value < 0 ? ' is-below' : ''), x: x.toFixed(1), y: (p.value < 0 ? base : base - h).toFixed(1), width: bw.toFixed(1), height: h.toFixed(1), rx: 2,
        'data-fp-bar': p.label}, [sv('title', null, [document.createTextNode(p.label + ': ' + p.text)])]);
    });
    var hi = points.reduce(function (a, p) { return !a || p.value > a.value ? p : a; }, null);
    return el('figure', {class: 'fp-brp-figure', 'data-fp-chart': ''}, [
      sv('svg', {class: 'fp-brp-chart', viewBox: '0 0 ' + W + ' ' + H, role: 'img', 'aria-label': title + (hi ? '. ' + t('brp_chart_high', {label: hi.label, value: hi.text}) : '') + ' ' + t('brp_chart_table'),
        preserveAspectRatio: 'none'}, [sv('line', {class: 'fp-brp-base', x1: 0, x2: W, y1: base.toFixed(1), y2: base.toFixed(1)})].concat(bars)),
      /* the first and the last period under the bars, as text that keeps its size at any width */
      points.length ? el('div', {class: 'fp-brp-ticks', 'aria-hidden': 'true'}, [el('span', {text: points[0].label}), points.length > 1 ? el('span', {text: points[points.length - 1].label}) : null]) : null,
      el('figcaption', {class: 'fp-muted fp-row-note', text: title})]);
  }
  function cents(r, k) { var c = B.cents(r && r[k]); return c === null ? 0 : c; }
  function money(c, cur) { return B.money(c, cur || 'USD'); }
  function n(v) { var w = B.whole(v); return w === null ? '—' : B.num(w); }
  function rate(bp) { return bp === null || bp === undefined ? '—' : B.bpText(bp) + '%'; }

  /* each report as a chart title, its points and its tables */
  var DRAW = {
    income: function (r, cur) {
      var periods = (Array.isArray(r.periods) ? r.periods : []).slice(0, 400).filter(function (p) { return p && typeof p.period === 'string'; });
      var out = [chart(t('brp_income_chart'), periods.map(function (p) { return {label: B.str(p.period, 20), value: cents(p, 'net_cents'), text: money(cents(p, 'net_cents'), cur)}; })),
        B.table('fp-brp-res-h', 'fp-brp-table', [B.th(t('brp_col_period')), B.th(t('brp_col_received'), 'fp-bil-num'), B.th(t('brp_col_refunded'), 'fp-bil-num'), B.th(t('brp_col_net'), 'fp-bil-num'),
          B.th(t('brp_col_payments'), 'fp-bil-num'), B.th(t('brp_col_invoices'), 'fp-bil-num'), B.th(t('brp_col_invoiced'), 'fp-bil-num'), B.th(t('brp_col_tax'), 'fp-bil-num')],
        periods.map(function (p) {
          return el('tr', null, [el('th', {scope: 'row', class: 'fp-bil-nowrap', text: B.str(p.period, 20)}), el('td', {class: 'fp-bil-num', text: money(cents(p, 'received_cents'), cur)}),
            el('td', {class: 'fp-bil-num', text: money(cents(p, 'refunded_cents'), cur)}), el('td', {class: 'fp-bil-num', text: money(cents(p, 'net_cents'), cur)}),
            el('td', {class: 'fp-bil-num', text: n(p.payments)}), el('td', {class: 'fp-bil-num', text: n(p.invoices)}), el('td', {class: 'fp-bil-num', text: money(cents(p, 'invoiced_cents'), cur)}),
            el('td', {class: 'fp-bil-num', text: money(cents(p, 'tax_cents'), cur)})]);
        }))];
      var gws = (Array.isArray(r.gateways) ? r.gateways : []).filter(Boolean);
      if (gws.length) {
        out.push(el('h3', {class: 'fp-h3 fp-brp-sub', id: 'fp-brp-gw-h', text: t('brp_by_gateway')}));
        out.push(B.table('fp-brp-gw-h', 'fp-brp-gw-table', [B.th(t('brp_col_gateway')), B.th(t('brp_col_received'), 'fp-bil-num'), B.th(t('brp_col_refunded'), 'fp-bil-num'), B.th(t('brp_col_net'), 'fp-bil-num')],
          gws.map(function (g) {
            return el('tr', null, [el('th', {scope: 'row', text: B.gatewayText(B.str(g.gateway, 40))}), el('td', {class: 'fp-bil-num', text: money(cents(g, 'received_cents'), cur)}),
              el('td', {class: 'fp-bil-num', text: money(cents(g, 'refunded_cents'), cur)}), el('td', {class: 'fp-bil-num', text: money(cents(g, 'net_cents'), cur)})]);
          })));
      }
      return out;
    },
    sales: function (r, cur) {
      var periods = (Array.isArray(r.periods) ? r.periods : []).slice(0, 400).filter(function (p) { return p && typeof p.period === 'string'; });
      var out = [chart(t('brp_sales_chart'), periods.map(function (p) { var v = B.whole(p.new_services) || 0; return {label: B.str(p.period, 20), value: v, text: B.num(v)}; })),
        B.table('fp-brp-res-h', 'fp-brp-table', [B.th(t('brp_col_period')), B.th(t('brp_col_new_clients'), 'fp-bil-num'), B.th(t('brp_col_new_services'), 'fp-bil-num'), B.th(t('brp_col_ended'), 'fp-bil-num')],
          periods.map(function (p) {
            return el('tr', null, [el('th', {scope: 'row', class: 'fp-bil-nowrap', text: B.str(p.period, 20)}), el('td', {class: 'fp-bil-num', text: n(p.new_customers)}), el('td', {class: 'fp-bil-num', text: n(p.new_services)}),
              el('td', {class: 'fp-bil-num', text: n(p.ended)})]);
          }))];
      var plans = (Array.isArray(r.plans) ? r.plans : []).filter(Boolean);
      out.push(el('h3', {class: 'fp-h3 fp-brp-sub', id: 'fp-brp-plans-h', text: t('brp_by_plan')}));
      out.push(plans.length ? B.table('fp-brp-plans-h', 'fp-brp-plans-table', [B.th(t('brp_col_plan')), B.th(t('brp_col_new_services'), 'fp-bil-num'), B.th(t('brp_col_invoiced'), 'fp-bil-num'),
        B.th(t('brp_col_running'), 'fp-bil-num'), B.th(t('brp_col_monthly'), 'fp-bil-num')], plans.map(function (p) {
        return el('tr', null, [el('th', {scope: 'row', class: 'fp-bil-wrap', text: B.str(p.plan_name, 60) || '—'}), el('td', {class: 'fp-bil-num', text: n(p.new_services)}),
          el('td', {class: 'fp-bil-num', text: money(cents(p, 'invoiced_cents'), cur)}), el('td', {class: 'fp-bil-num', text: n(p.active_services)}), el('td', {class: 'fp-bil-num', text: money(cents(p, 'monthly_cents'), cur)})]);
      })) : el('p', {class: 'fp-muted', text: t('brp_no_plans')}));
      return out;
    },
    'aged-debt': function (r, cur) {
      var tot = r.totals || {};
      var buckets = [['not_due_cents', t('brp_not_due')], ['days_1_30_cents', t('brp_1_30')], ['days_31_60_cents', t('brp_31_60')], ['days_61_90_cents', t('brp_61_90')], ['over_90_cents', t('brp_over_90')]];
      var list = (Array.isArray(r.customers) ? r.customers : []).filter(Boolean);
      var out = [chart(t('brp_aged_chart', {day: B.day(r.on) || '—'}), buckets.map(function (k) { return {label: k[1], value: cents(tot, k[0]), text: money(cents(tot, k[0]), cur)}; })),
        list.length ? B.table('fp-brp-res-h', 'fp-brp-table', [B.th(t('brp_col_client'))].concat(buckets.map(function (k) { return B.th(k[1], 'fp-bil-num'); })).concat([B.th(t('brp_col_owed'), 'fp-bil-num'),
          B.th(t('brp_col_oldest'))]), list.map(function (c) {
          return el('tr', null, [el('th', {scope: 'row', class: 'fp-bil-wrap', text: B.str(c.name, 100) + (c.company ? ' (' + B.str(c.company, 100) + ')' : '')})].concat(buckets.map(function (k) {
            return el('td', {class: 'fp-bil-num', text: money(cents(c, k[0]), cur)});
          })).concat([el('td', {class: 'fp-bil-num', text: money(cents(c, 'total_cents'), cur)}), el('td', {class: 'fp-bil-nowrap', text: B.day(c.oldest_due_on) || '—'})]));
        })) : el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('brp_no_debt')})];
      if (B.whole(r.more)) { out.push(el('p', {class: 'fp-muted fp-row-note', text: t('brp_more', {n: B.num(r.more)})})); }
      return out;
    },
    tax: function (r, cur) {
      var lines = (Array.isArray(r.lines) ? r.lines : []).filter(function (l) { return l && typeof l.period === 'string'; });
      var per = {};
      var order = [];
      lines.forEach(function (l) { var k = B.str(l.period, 20); if (!(k in per)) { per[k] = 0; order.push(k); } per[k] += cents(l, 'tax_cents'); });
      var reason = function (l) { return l.reason === 'exempt' ? t('brp_exempt') : l.reason === 'reverse_charge' ? t('brp_reverse') : ''; };
      return [chart(t('brp_tax_chart'), order.map(function (k) { return {label: k, value: per[k], text: money(per[k], cur)}; })),
        lines.length ? B.table('fp-brp-res-h', 'fp-brp-table', [B.th(t('brp_col_period')), B.th(t('brp_col_taxname')), B.th(t('brp_col_rate'), 'fp-bil-num'), B.th(t('brp_col_invoices'), 'fp-bil-num'),
          B.th(t('brp_col_taxable'), 'fp-bil-num'), B.th(t('brp_col_tax'), 'fp-bil-num'), B.th(t('brp_col_total'), 'fp-bil-num')], lines.map(function (l) {
          return el('tr', null, [el('th', {scope: 'row', class: 'fp-bil-nowrap', text: B.str(l.period, 20)}), el('td', {class: 'fp-bil-wrap', text: B.str(l.name, 60) || reason(l) || t('brp_no_tax')}),
            el('td', {class: 'fp-bil-num', text: l.name ? rate(B.whole(l.rate_bp)) : '—'}), el('td', {class: 'fp-bil-num', text: n(l.invoices)}), el('td', {class: 'fp-bil-num', text: money(cents(l, 'taxable_cents'), cur)}),
            el('td', {class: 'fp-bil-num', text: money(cents(l, 'tax_cents'), cur)}), el('td', {class: 'fp-bil-num', text: money(cents(l, 'total_cents'), cur)})]);
        })) : el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('brp_no_tax_lines')})];
    }
  };

  FP.view('tool:billing_reports', function () {
    var page = B.frame('billing_reports', 'fp-brp');
    if (!page) { return; }
    var alive = function () { return page.isConnected; };
    var kind = B.select('fp-brp-kind', 'kind', KINDS.map(function (k) { return [k, t('brp_kind_' + k.replace('-', '_'))]; }), 'income');
    var from = el('input', {class: 'sig-input fp-binv-date', type: 'date', id: 'fp-brp-from', name: 'from'});
    var to = el('input', {class: 'sig-input fp-binv-date', type: 'date', id: 'fp-brp-to', name: 'to'});
    var by = B.select('fp-brp-by', 'by', [['month', t('brp_by_month')], ['day', t('brp_by_day')], ['year', t('brp_by_year')]], 'month');
    var basis = B.select('fp-brp-basis', 'basis', [['issued', t('brp_basis_issued')], ['paid', t('brp_basis_paid')]], 'issued');
    var go = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('brp_show')});
    var csv = el('a', {class: 'sig-btn sig-btn--secondary', href: '#', download: '', 'data-fp-csv': ''}, [UI.icon(FP.ui, 'ui_download'), el('span', {text: t('brp_csv')})]);
    var rangeBits = el('div', {class: 'fp-bil-filter-row', 'data-fp-range': ''}, [M.field('fp-brp-from', t('brp_from'), from), M.field('fp-brp-to', t('brp_to'), to), M.field('fp-brp-by', t('brp_by'), by),
      el('div', {'data-fp-basis': ''}, [M.field('fp-brp-basis', t('brp_basis'), basis)])]);
    var form = el('form', {class: 'fp-form fp-bil-filters fp-brp-form', novalidate: '', 'aria-label': t('brp_choose')}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-bil-filter-row'}, [M.field('fp-brp-kind', t('brp_kind'), kind)]), rangeBits,
      el('p', {class: 'fp-muted fp-row-note', 'data-fp-range-note': '', text: t('brp_range_note')}), el('div', {class: 'fp-actions'}, [go, csv])]);
    var result = el('div', {'data-fp-result': ''});
    function query() {
      var q = {};
      if (kind.value !== 'aged-debt') {
        if (from.value) { q.from = from.value; }
        if (to.value) { q.to = to.value; }
        q.by = by.value;
        if (kind.value === 'tax') { q.basis = basis.value; }
      }
      return q;
    }
    function shape() {
      var aged = kind.value === 'aged-debt';
      rangeBits.hidden = aged;
      form.querySelector('[data-fp-range-note]').textContent = t(aged ? 'brp_aged_note' : 'brp_range_note');
      form.querySelector('[data-fp-basis]').hidden = kind.value !== 'tax';
      var q = query();
      csv.setAttribute('href', '/api/v1/billing/reports/' + kind.value + '?format=csv' + Object.keys(q).map(function (k) { return '&' + k + '=' + encodeURIComponent(q[k]); }).join(''));
    }
    var first = true;
    function show(b) {
      if (!B.begin(form, b)) { return; }
      if (kind.value !== 'aged-debt' && from.value && to.value && from.value > to.value) { M.fieldError(form, from, t('brp_from_after')); return; }
      UI.setBusy(b, true);
      var k = kind.value;
      FP.call('get', PATH[k], undefined, query()).then(function (r) {
        if (!alive()) { return; }
        UI.setBusy(b, false);
        var cur = /^[A-Z]{3}$/.test(r && r.currency) ? r.currency : 'USD';
        result.textContent = '';
        var head = k === 'aged-debt' ? t('brp_aged_on', {day: B.day(r.on) || '—'}) : t('brp_range_of', {from: B.day(r.from) || '—', to: B.day(r.to) || '—'});
        result.appendChild(B.card('fp-brp-res-h', t('brp_kind_' + k.replace('-', '_')), [el('p', {class: 'fp-muted', 'data-fp-range-said': '', text: head})].concat(DRAW[k](r || {}, cur)), 'fp-brp-result', 'result'));
        M.say(form, t('brp_shown'));
      }, function (err) {
        if (!alive()) { return; }
        UI.setBusy(b, false);
        if (first) {
          B.screen(page, [FP.empty(t('brp_title'), err.message, B.button('reload', t('bil_try_again')))]);
          page.querySelector('[data-fp-act="reload"]').addEventListener('click', function () { FP.route(true); });
          return;
        }
        B.failed(form, err);
      }).then(function () { first = false; });
    }
    kind.addEventListener('change', shape);
    form.addEventListener('input', shape);
    form.addEventListener('change', shape);
    form.addEventListener('submit', function (e) { e.preventDefault(); show(go); });
    B.screen(page, [B.card('fp-brp-h', t('brp_title'), [el('p', {class: 'fp-muted', text: t('brp_what')}), form], 'fp-brp-pick', 'pick'), result]);
    shape();
    show(go);
  });
})();

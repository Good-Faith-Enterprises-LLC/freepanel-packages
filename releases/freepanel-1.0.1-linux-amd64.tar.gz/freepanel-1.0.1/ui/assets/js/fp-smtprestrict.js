/* freePanel SMTP restrictions (docs/api.md, "Email", GET and PUT /email/smtp-restrictions): the administrators' panel's page (#/tool/mail_smtp_restrictions)
   for making the programs on this server send their mail through it. Switched on, no program but the mail server and root can connect to another
   server's mail ports (25, 465 and 587), whatever user ID it runs as: it is refused at once. Mail still goes through the sendmail command or the local submission port, which sign
   it and count it toward the hourly limit. An account may be left out (up to 100) and keep its connection, for a customer who sends through an outside
   mail service. root and the mail server are always let through. The page says whether the rules can be used here (they need
   nftables), whether they are loaded in the kernel now, and how many attempts they have refused since. Turning it on is asked about first, because a
   customer's script that sends through an outside service stops working. The switch and the list are one choice, saved together. What the server sends
   is shown as text. The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var USER_RE = /^[a-z][a-z0-9]{0,15}$/;
  var MAX_ALLOW = 100;

  function obj(v) { return v && typeof v === 'object' && !Array.isArray(v) ? v : {}; }
  function num(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.floor(v) : 0; }
  function count(n) { return Number(n).toLocaleString('en'); }
  function pill(kind, text) { return el('span', {class: 'sig-pill' + (kind ? ' sig-pill--' + kind : ''), text: text}); }

  function clean(r) {
    r = obj(r);
    var seen = {};
    var allow = (Array.isArray(r.allow) ? r.allow : []).filter(function (n) {
      if (typeof n !== 'string' || !USER_RE.test(n) || seen[n]) { return false; }
      seen[n] = true;
      return true;
    }).slice(0, MAX_ALLOW).sort();
    var ports = (Array.isArray(r.ports) ? r.ports : []).filter(function (p) { return typeof p === 'number' && p >= 1 && p <= 65535 && Math.floor(p) === p; }).slice(0, 6);
    return {available: r.available === true, enabled: r.enabled === true, loaded: r.loaded === true, blocked: num(r.blocked), allow: allow,
      ports: ports.length ? ports : [25, 465, 587], warning: typeof r.warning === 'string' ? r.warning.slice(0, 400) : ''};
  }

  var S = {page: null, data: null, draft: null, accounts: null, busy: false};

  function dirty() {
    var a = S.draft.allow.join(',');
    return S.draft.enabled !== S.data.enabled || a !== S.data.allow.join(',');
  }
  function portsText() { return S.data.ports.join(', '); }

  /* ---- what is true now ---- */
  function stateOf() {
    var d = S.data;
    if (!d.available) { return {kind: 'warn', label: t('smtpr_s_unavailable'), text: t('smtpr_unavailable')}; }
    if (d.enabled && d.loaded) {
      return {kind: 'ok', label: t('smtpr_s_on'), text: t('smtpr_on', {ports: portsText()}) + ' ' + t(d.blocked === 1 ? 'smtpr_blocked_1' : 'smtpr_blocked', {n: count(d.blocked)})};
    }
    if (d.enabled) { return {kind: 'danger', label: t('smtpr_s_not_loaded'), text: t('smtpr_not_loaded')}; }
    return {kind: '', label: t('smtpr_s_off'), text: t('smtpr_off', {ports: portsText()})};
  }
  function stateCard() {
    var s = stateOf();
    var parts = [el('div', {class: 'fp-smtpr-state', 'data-fp-state': ''}, [pill(s.kind, s.label), el('span', {class: 'fp-smtpr-state-text', text: s.text})])];
    if (S.data.warning) { parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-warning': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: S.data.warning})])); }
    parts.push(el('dl', {class: 'fp-smtpr-what'}, ['does', 'still', 'never'].reduce(function (out, k) {
      return out.concat([el('dt', {text: t('smtpr_k_' + k)}), el('dd', {text: t('smtpr_v_' + k, {ports: portsText()})})]);
    }, [])));
    return M.card('fp-smtpr-state-h', t('smtpr_state_title'), parts, 'fp-smtpr-state-card');
  }

  /* ---- the choice: the switch and the accounts left out ---- */
  function allowList() {
    if (!S.draft.allow.length) { return el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('smtpr_none')}); }
    return el('ul', {class: 'fp-smtpr-list', 'aria-labelledby': 'fp-smtpr-allow-h'}, S.draft.allow.map(function (n) {
      return el('li', {class: 'fp-smtpr-item', 'data-fp-account': n}, [el('span', {class: 'sig-mono fp-smtpr-name', text: n}),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'smtpr-remove', 'aria-label': t('smtpr_remove_of', {name: n}), text: t('smtpr_remove')})]);
    }));
  }
  function formCard() {
    var d = S.data;
    var on = el('input', {type: 'checkbox', id: 'fp-smtpr-on', name: 'enabled', 'aria-describedby': 'fp-smtpr-on-hint'});
    on.checked = S.draft.enabled;
    if (!d.available) { on.disabled = true; }
    var options = (S.accounts || []).slice(0, 300).map(function (n) { return el('option', {value: n}); });
    var add = el('input', {class: 'sig-input sig-mono', id: 'fp-smtpr-add', name: 'allow', type: 'text', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', maxlength: '16',
      list: options.length ? 'fp-smtpr-accounts' : null, 'aria-describedby': 'fp-smtpr-add-hint'});
    var addButton = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'smtpr-add', text: t('smtpr_add')});
    var ask = el('div', {class: 'fp-smtpr-ask'});
    var form = el('form', {class: 'fp-form fp-mail-form fp-smtpr-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-smtpr-switch'}, [el('label', {class: 'fp-check', for: 'fp-smtpr-on'}, [on, el('span', {text: t('smtpr_switch')})]),
        el('span', {class: 'sig-hint', id: 'fp-smtpr-on-hint', text: d.available ? t('smtpr_switch_hint') : t('smtpr_switch_hint_off')})]),
      el('h3', {class: 'fp-h3', id: 'fp-smtpr-allow-h', text: t('smtpr_allow_title')}),
      el('p', {class: 'fp-muted', text: t('smtpr_allow_what', {n: MAX_ALLOW})}),
      allowList(),
      el('div', {class: 'fp-smtpr-adder'}, [M.field('fp-smtpr-add', t('smtpr_add_label'), add, t('smtpr_add_hint', {n: S.draft.allow.length, max: MAX_ALLOW})), addButton]),
      options.length ? el('datalist', {id: 'fp-smtpr-accounts'}, options) : null,
      ask, el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('smtpr_save')}),
        el('span', {class: 'fp-muted fp-smtpr-dirty', 'data-fp-dirty': '', role: 'status', text: dirty() ? t('smtpr_unsaved') : ''})])]);
    on.addEventListener('change', function () { S.draft.enabled = on.checked; ask.textContent = ''; form.querySelector('[data-fp-dirty]').textContent = dirty() ? t('smtpr_unsaved') : ''; });
    add.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        addName(form, add);
      }
    });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || S.busy) { return; }
      S.draft.enabled = on.checked;
      if (!dirty()) { M.say(form, t('smtpr_nothing')); return; }
      if (S.draft.enabled && !d.enabled) {
        if (!ask.firstChild) { M.confirmIn(ask, t('smtpr_ask', {ports: portsText()}), 'smtpr-yes', t('smtpr_ask_yes')); }
        return;
      }
      save(form, b);
    });
    form.addEventListener('click', function (e) {
      var a = e.target.closest ? e.target.closest('[data-fp-act]') : null;
      if (!a) { return; }
      var act = a.getAttribute('data-fp-act');
      if (act === 'smtpr-add') {
        addName(form, add);
      } else if (act === 'smtpr-remove') {
        removeName(a.closest('li').getAttribute('data-fp-account'));
      } else if (act === 'confirm-no') {
        ask.textContent = '';
        form.querySelector('.fp-submit').focus();
      } else if (act === 'smtpr-yes' && !S.busy) {
        ask.textContent = '';
        save(form, form.querySelector('.fp-submit'));
      }
    });
    return M.card('fp-smtpr-form-h', t('smtpr_form_title'), [form], 'fp-smtpr-choice');
  }

  /* the accounts left out are a draft until Save: Add and Remove change the list on the page, and the form is drawn again with the focus kept */
  function addName(form, input) {
    M.start(form);
    var v = input.value.trim().toLowerCase();
    if (!v) { M.fieldError(form, input, t('smtpr_add_empty')); return; }
    if (!USER_RE.test(v)) { M.fieldError(form, input, t('smtpr_add_bad')); return; }
    if (S.accounts && S.accounts.indexOf(v) < 0) { M.fieldError(form, input, t('smtpr_add_unknown', {name: v})); return; }
    if (S.draft.allow.indexOf(v) >= 0) { M.fieldError(form, input, t('smtpr_add_twice', {name: v})); return; }
    if (S.draft.allow.length >= MAX_ALLOW) { M.fieldError(form, input, t('smtpr_add_many', {max: MAX_ALLOW})); return; }
    S.draft.allow.push(v);
    S.draft.allow.sort();
    draw();
    S.page.querySelector('#fp-smtpr-add').focus();
    M.say(S.page.querySelector('.fp-smtpr-form'), t('smtpr_added', {name: v}));
  }
  function removeName(name) {
    S.draft.allow = S.draft.allow.filter(function (n) { return n !== name; });
    draw();
    var next = S.page.querySelector('.fp-smtpr-list [data-fp-act="smtpr-remove"]');
    (next || S.page.querySelector('#fp-smtpr-add')).focus();
    M.say(S.page.querySelector('.fp-smtpr-form'), t('smtpr_removed', {name: name}));
  }
  function save(form, b) {
    var mine = S.page;
    S.busy = true;
    UI.setBusy(b, true);
    var body = {enabled: S.draft.enabled, allow: S.draft.allow.slice()};
    FP.call('put', 'mailSmtpRestrictions', body).then(function (r) {
      S.busy = false;
      if (S.page !== mine) { return; }
      S.data = clean(r);
      S.draft = {enabled: S.data.enabled, allow: S.data.allow.slice()};
      draw();
      M.say(S.page.querySelector('.fp-smtpr-form'), t(S.data.enabled ? (S.data.loaded ? 'smtpr_saved_on' : 'smtpr_saved_on_unloaded') : 'smtpr_saved_off'));
      S.page.querySelector('#fp-smtpr-state-h').focus();
    }, function (err) {
      S.busy = false;
      if (S.page !== mine) { return; }
      UI.setBusy(b, false);
      var unsure = !err || err.status === 0 || err.status >= 500;
      M.failed(form, unsure ? {field: err && err.field, message: (err && err.message ? err.message : t('api_failed')) + ' ' + t('smtpr_nothing_changed')} : err);
    });
  }

  function draw() {
    S.page.textContent = '';
    S.page.appendChild(stateCard());
    S.page.appendChild(formCard());
  }

  FP.view('tool:mail_smtp_restrictions', function () {
    S = {page: null, data: null, draft: null, accounts: null, busy: false};
    var tool = FP.tools.mail_smtp_restrictions;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('mail_smtp_restrictions_desc'), cls: 'fp-mail fp-ml fp-smtpr-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    S.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all([FP.call('get', 'mailSmtpRestrictions'), FP.call('get', 'accounts').then(function (r) {
      return (r && Array.isArray(r.accounts) ? r.accounts : []).map(function (a) { return typeof (a && a.username) === 'string' ? a.username : ''; }).filter(function (n) { return USER_RE.test(n); }).sort();
    }, function () { return null; })]).then(function (r) {
      if (S.page !== body) { return; }
      S.data = clean(r[0]);
      S.draft = {enabled: S.data.enabled, allow: S.data.allow.slice()};
      S.accounts = r[1];
      draw();
    }, function (err) {
      if (S.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

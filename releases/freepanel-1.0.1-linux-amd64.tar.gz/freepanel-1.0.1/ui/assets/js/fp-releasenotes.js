/* freePanel release notes, in the admin panel (docs/api.md, "Server logs viewer": the release notes in the panel): #/tool/release_notes, the server admin's
   alone. It shows what an admin should know before upgrading, as the build that runs carries it: the version running, what the next release will say
   (changes this build already has) and the releases so far, newest first, each a heading with its changes. The newest release and the changes not yet in
   a release are open; an older release opens when asked. A search narrows every list to the changes that hold some text. The notes are written in
   plain text with `code` and [links](https://…); the page draws exactly those two (a link only to an https address) and everything else as text.
   Nothing here changes anything on the server. Page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var MAX_RELEASES = 60;
  var MAX_ENTRIES = 200;
  var MAX_UNRELEASED = 400;
  var MAX_TITLE = 300;
  var MAX_TEXT = 3000;
  var MAX_FIND = 100;
  var VERSION_RE = /^[0-9A-Za-z][0-9A-Za-z._+-]{0,39}$/;
  var DATE_RE = /^(\d{4})-(\d{2})-(\d{2})$/;
  var LINK_RE = /^https:\/\/[A-Za-z0-9.-]+(:[0-9]{1,5})?(\/[A-Za-z0-9._~:/?#@!$&*+,;=%-]*)?$/;

  var S = null;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  function arr(v) { return Array.isArray(v) ? v : []; }
  function count(n) { return Math.round(n).toLocaleString('en'); }
  function sameVersion(a, b) { return a !== '' && a.replace(/^v/i, '') === b.replace(/^v/i, ''); }
  function dayOf(v) {
    var m = DATE_RE.exec(str(v, 10));
    var d = m ? new Date(Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3]))) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleDateString('en', {dateStyle: 'long', timeZone: 'UTC'}) : '';
  }

  /* ---- what the server sends, cleaned to the shapes drawn ---- */
  function cleanEntry(e) {
    if (!e || typeof e !== 'object') { return null; }
    var title = str(e.title, MAX_TITLE).trim();
    if (!title) { return null; }
    var pr = typeof e.pr === 'number' && isFinite(e.pr) && e.pr >= 1 && e.pr <= 999999 ? Math.floor(e.pr) : 0;
    return {title: title, text: str(e.text, MAX_TEXT).trim(), pr: pr};
  }
  function cleanRelease(r) {
    if (!r || typeof r !== 'object' || !VERSION_RE.test(str(r.version, 40))) { return null; }
    return {version: r.version, date: dayOf(r.date), entries: arr(r.entries).map(cleanEntry).filter(Boolean).slice(0, MAX_ENTRIES)};
  }
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var version = VERSION_RE.test(str(r.version, 40)) ? r.version : '';
    return {version: version, releases: arr(r.releases).map(cleanRelease).filter(Boolean).slice(0, MAX_RELEASES),
      unreleased: arr(r.unreleased).map(cleanEntry).filter(Boolean).slice(0, MAX_UNRELEASED)};
  }

  /* `code` and [text](https://address) are drawn; every other character is text */
  function inline(text) {
    var out = [];
    text.split(/(`[^`]+`)/).forEach(function (part) {
      if (part.length > 2 && part.charAt(0) === '`' && part.charAt(part.length - 1) === '`') {
        out.push(el('code', {class: 'sig-mono fp-rnote-code', text: part.slice(1, -1)}));
        return;
      }
      var rest = part;
      var m;
      while ((m = /\[([^\]]{1,200})\]\(([^)\s]{1,300})\)/.exec(rest))) {
        if (m.index > 0) { out.push(rest.slice(0, m.index)); }
        if (LINK_RE.test(m[2])) {
          out.push(el('a', {class: 'sig-link', href: m[2], target: '_blank', rel: 'noopener noreferrer', text: m[1]}));
        } else {
          out.push(m[0]);
        }
        rest = rest.slice(m.index + m[0].length);
      }
      if (rest) { out.push(rest); }
    });
    return out;
  }

  /* ---- finding ---- */
  function holds(e, q) { return !q || (e.title + ' ' + e.text).toLowerCase().indexOf(q) >= 0; }
  function wanted() { return S.find.trim().toLowerCase(); }
  function total() {
    var n = S.data.unreleased.length;
    S.data.releases.forEach(function (r) { n += r.entries.length; });
    return n;
  }
  function matching() {
    var q = wanted();
    var n = S.data.unreleased.filter(function (e) { return holds(e, q); }).length;
    S.data.releases.forEach(function (r) { n += r.entries.filter(function (e) { return holds(e, q); }).length; });
    return n;
  }

  /* ---- drawing ---- */
  function entry(e) {
    return el('li', {class: 'fp-rnote-entry', 'data-fp-entry': ''}, [
      el('p', {class: 'fp-rnote-title', text: e.title}),
      e.text ? el('p', {class: 'fp-rnote-text'}, inline(e.text)) : null,
      e.pr ? el('p', {class: 'fp-muted fp-row-note fp-rnote-pr', text: t('rnote_pr', {pr: e.pr})}) : null]);
  }
  function entryList(list, none) {
    var q = wanted();
    var shown = list.filter(function (e) { return holds(e, q); });
    if (!shown.length) { return el('p', {class: 'fp-muted', 'data-fp-none': '', text: none}); }
    return el('ul', {class: 'fp-rnote-list'}, shown.map(entry));
  }
  function unreleasedCard() {
    var q = wanted();
    var parts = [el('p', {class: 'fp-muted', text: t('rnote_unreleased_intro')})];
    if (!S.data.unreleased.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': 'unreleased', text: t('rnote_unreleased_none')}));
    } else if (q && !S.data.unreleased.some(function (e) { return holds(e, q); })) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': 'unreleased', text: t('rnote_none_here')}));
    } else {
      parts.push(entryList(S.data.unreleased, t('rnote_none_here')));
    }
    return M.card('fp-rnote-next-h', t('rnote_unreleased_title'), parts, 'fp-rnote-next');
  }
  function releaseCard(r, index) {
    var q = wanted();
    var id = 'fp-rnote-r' + index;
    var open = q ? true : Boolean(S.open[r.version]);
    var kept = r.entries.filter(function (e) { return holds(e, q); });
    var head = el('div', {class: 'fp-rnote-head'}, [
      el('h2', {class: 'fp-h2', id: id + '-h', tabindex: '-1', text: t('rnote_release_head', {version: r.version})}),
      sameVersion(S.data.version, r.version) ? el('span', {class: 'sig-pill sig-pill--ok', 'data-fp-running': '', text: t('rnote_running')}) : null,
      r.date ? el('span', {class: 'fp-muted', text: t('rnote_release_date', {date: r.date})}) : null,
      el('span', {class: 'fp-muted fp-row-note', text: t(r.entries.length === 1 ? 'rnote_n_changes_1' : 'rnote_n_changes', {n: count(r.entries.length)})}),
      q ? null : el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-rnote-toggle', type: 'button', 'data-fp-act': 'toggle', 'data-fp-version': r.version,
        'aria-expanded': open ? 'true' : 'false', 'aria-controls': id + '-body', 'aria-label': t(open ? 'rnote_hide_of' : 'rnote_show_of', {version: r.version}), text: t(open ? 'rnote_hide' : 'rnote_show')})]);
    var body = el('div', {class: 'fp-rnote-body', id: id + '-body', hidden: !open}, open ? [entryList(r.entries, r.entries.length ? t('rnote_none_here') : t('rnote_release_empty'))] : []);
    return el('section', {class: 'sig-card fp-mail-card fp-rnote-release', 'aria-labelledby': id + '-h', 'data-fp-release': r.version, hidden: q && !kept.length ? true : null}, [
      el('div', {class: 'sig-card-body'}, [head, body])]);
  }
  function releasesNone() {
    return M.card('fp-rnote-none-h', t('rnote_releases_title'), [el('p', {class: 'fp-muted', 'data-fp-none': 'releases', text: t('rnote_releases_none')})], 'fp-rnote-noreleases');
  }
  function countLine() {
    var q = wanted();
    var all = total();
    if (!q) { return t(all === 1 ? 'rnote_count_1' : 'rnote_count', {n: count(all)}); }
    var n = matching();
    return n ? t('rnote_count_match', {n: count(n), total: count(all)}) : t('rnote_count_none', {text: S.find.trim()});
  }
  function findCard() {
    var inp = el('input', {class: 'sig-input', id: 'fp-rnote-find', name: 'find', type: 'search', maxlength: String(MAX_FIND), autocomplete: 'off', spellcheck: 'false',
      autocapitalize: 'none', value: S.find, 'aria-describedby': 'fp-rnote-find-hint fp-rnote-count'});
    inp.addEventListener('input', function () { S.find = inp.value; drawLists(); });
    inp.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && inp.value) { e.stopPropagation(); inp.value = ''; S.find = ''; drawLists(); }
    });
    var version = S.data.version ? t('rnote_version_title', {version: S.data.version}) : t('rnote_version_unknown');
    return M.card('fp-rnote-top-h', version, [
      el('p', {class: 'fp-muted', text: t('rnote_version_what')}),
      el('div', {class: 'sig-field fp-rnote-find'}, [el('label', {class: 'sig-label', for: 'fp-rnote-find', text: t('rnote_find')}), inp,
        el('span', {class: 'sig-hint', id: 'fp-rnote-find-hint', text: t('rnote_find_hint')})]),
      el('p', {class: 'fp-muted', id: 'fp-rnote-count', role: 'status', 'data-fp-count': '', text: countLine()})], 'fp-rnote-top');
  }
  /* the lists are drawn again as someone types; the search box and its card stay as they are */
  function drawLists() {
    var box = S.page.querySelector('[data-fp-lists]');
    box.textContent = '';
    box.appendChild(unreleasedCard());
    if (S.data.releases.length) {
      S.data.releases.forEach(function (r, i) { box.appendChild(releaseCard(r, i)); });
    } else {
      box.appendChild(releasesNone());
    }
    S.page.querySelector('[data-fp-count]').textContent = countLine();
  }
  function draw() {
    S.page.textContent = '';
    if (!S.data.unreleased.length && !S.data.releases.length) {
      S.page.appendChild(emptyCard());
      return;
    }
    S.page.appendChild(findCard());
    S.page.appendChild(el('div', {class: 'fp-rnote-lists', 'data-fp-lists': ''}));
    drawLists();
  }
  function emptyCard() {
    var version = S.data.version ? t('rnote_version_title', {version: S.data.version}) : t('rnote_version_unknown');
    return M.card('fp-rnote-top-h', version, [el('p', {class: 'fp-muted', 'data-fp-empty': 'notes', text: t('rnote_empty')})], 'fp-rnote-top');
  }

  function onClick(e) {
    var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !S || !S.page.contains(b)) { return; }
    var act = b.getAttribute('data-fp-act');
    if (act === 'toggle') {
      var v = b.getAttribute('data-fp-version');
      S.open[v] = !S.open[v];
      drawLists();
      var again = S.page.querySelector('.fp-rnote-toggle[data-fp-version="' + v.replace(/[^A-Za-z0-9._+-]/g, '') + '"]');
      if (again) { again.focus(); }
    } else if (act === 'again') {
      start(true);
    }
  }

  function start(again) {
    S = null;
    var tool = FP.tools.release_notes;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('rnote_desc'), cls: 'fp-mail fp-rpp fp-rnote-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    var mine = S = {page: page, data: null, find: '', open: {}};
    page.addEventListener('click', onClick);
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    if (again) { document.getElementById('fp-h1').focus(); }
    FP.call('get', 'releaseNotes').then(function (r) {
      if (S !== mine) { return; }
      mine.data = clean(r);
      if (mine.data.releases.length) {
        var running = mine.data.releases.filter(function (x) { return sameVersion(mine.data.version, x.version); })[0];
        mine.open[(running || mine.data.releases[0]).version] = true;
      }
      draw();
    }, function (err) {
      if (S !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err.message, el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'again', text: t('rnote_try_again')})));
    });
  }
  FP.view('tool:release_notes', function () { start(false); });
})();

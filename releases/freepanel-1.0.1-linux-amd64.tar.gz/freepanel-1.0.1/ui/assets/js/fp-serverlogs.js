/* freePanel server logs viewer, in the admin panel (docs/api.md, "Server logs viewer"): #/tool/server_logs, the server admin's alone.
   It lists the short, closed list of logs the server offers (a log is named only by its id) and shows the newest lines of one, with a
   limit on the lines and, if asked, only the lines that hold some text. A log holds what other programs wrote, among it addresses and
   the names people typed at a sign-in, so nothing from it is trusted: each line is cleaned (controls and direction marks out), cut to
   2000 characters, the whole is held to 1000 lines and 1 MiB, and it is put on the page as text in a box with a limit on its height.
   Nothing here changes a log. Page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var ID_RE = /^[a-z0-9-]{1,32}$/;
  var KINDS = {file: 'slog_kind_file', journal: 'slog_kind_journal'};
  var LINE_CHOICES = [100, 200, 500, 1000];
  var MAX_LINES = 1000;
  var MAX_LINE = 2000;
  var MAX_TEXT = 1048576;
  var MAX_MATCH = 100;
  var UNITS = ['B', 'KiB', 'MiB', 'GiB', 'TiB'];
  /* control characters (a tab stays) and the marks that change the direction of text, which a line could use to make the rest read otherwise */
  var UNSAFE = /[\u0000-\u0008\u000a-\u001f\u007f-\u009f\u061c\u200b-\u200f\u2028-\u202e\u2066-\u2069\ufeff]/g;   // eslint-disable-line no-control-regex -- the point of the pattern
  var CONTROL = /[\u0000-\u001f\u007f-\u009f]/;   // eslint-disable-line no-control-regex -- the point of the pattern

  var S = null;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function whole(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.round(v) : 0; }
  function arr(v) { return Array.isArray(v) ? v : []; }
  function count(n) { return Math.round(n).toLocaleString('en'); }
  function size(n) {
    var u = 0;
    while (n >= 1024 && u < UNITS.length - 1) { n /= 1024; u++; }
    return (n < 10 && u > 0 ? n.toFixed(1) : Math.round(n).toLocaleString('en')) + ' ' + UNITS[u];
  }
  function when(v) {
    var d = typeof v === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(v) ? new Date(v) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }

  function cleanLog(l) {
    if (!l || typeof l !== 'object' || !ID_RE.test(str(l.id))) { return null; }
    return {id: l.id, title: str(l.title, 120) || l.id, kind: KINDS[l.kind] ? l.kind : '', available: l.available === true, size: whole(l.size), modified: when(l.modified)};
  }
  function cleanList(r) {
    return arr(r && r.logs).map(cleanLog).filter(Boolean).slice(0, 50);
  }
  /* what a log sent, kept to lines of text that are safe to show and bounded in number and size; a line that was changed shows a replacement mark where it was */
  function cleanLines(list) {
    var out = [];
    var total = 0;
    var cut = false;
    arr(list).slice(-MAX_LINES).forEach(function (l) {
      if (typeof l !== 'string' || cut) { return; }
      var line = l.slice(0, MAX_LINE).replace(UNSAFE, '�');
      if (total + line.length + 1 > MAX_TEXT) { cut = true; return; }
      total += line.length + 1;
      out.push(line);
    });
    return out;
  }
  function cleanRead(r, id) {
    r = r && typeof r === 'object' ? r : {};
    return {id: id, title: str(r.title, 120), lines: cleanLines(r.lines), truncated: r.truncated === true, size: whole(r.size)};
  }

  function logOf(id) {
    for (var i = 0; i < S.logs.length; i++) { if (S.logs[i].id === id) { return S.logs[i]; } }
    return null;
  }

  /* ---- the list of logs ---- */
  function logItem(l) {
    var reading = S.id === l.id;
    var meta = [];
    if (l.kind) { meta.push(el('span', {class: 'sig-pill', text: t(KINDS[l.kind])})); }
    if (!l.available) {
      meta.push(el('span', {class: 'fp-muted fp-row-note', 'data-fp-gone': '', text: t('slog_unavailable')}));
    } else {
      if (l.kind === 'file' && l.size) { meta.push(el('span', {class: 'fp-muted fp-row-note', text: t('slog_size', {size: size(l.size)})})); }
      if (l.modified) { meta.push(el('span', {class: 'fp-muted fp-row-note', text: t('slog_modified', {when: l.modified})})); }
    }
    var acts = l.available ? el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'read',
      'aria-label': t(reading ? 'slog_reading_of' : 'slog_read_of', {title: l.title}), text: t(reading ? 'slog_reading' : 'slog_read')}) : null;
    return el('li', {class: 'fp-slog-item' + (reading ? ' is-reading' : '') + (l.available ? '' : ' is-gone'), 'data-fp-log': l.id}, [
      el('div', {class: 'fp-rpp-main'}, [el('span', {class: 'fp-rpp-title', text: l.title}), el('span', {class: 'fp-slog-meta'}, meta)]),
      acts ? el('span', {class: 'fp-rpp-acts'}, [acts]) : null]);
  }
  function listCard() {
    var parts = [M.errorLine(), el('p', {class: 'fp-muted', text: t('slog_intro')})];
    if (!S.logs.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': 'logs', text: t('slog_none')}));
    } else {
      parts.push(el('ul', {class: 'fp-slog-list'}, S.logs.map(logItem)));
      if (!S.logs.some(function (l) { return l.available; })) { parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': 'available', text: t('slog_none_here')})); }
    }
    return M.card('fp-slog-list-h', t('slog_list_title'), parts, 'fp-slog-listcard');
  }

  /* ---- the log being read ---- */
  function linesField() {
    var sel = el('select', {class: 'sig-select', id: 'fp-slog-lines', name: 'lines'}, LINE_CHOICES.map(function (n) {
      return el('option', {value: String(n), text: t('slog_lines_n', {n: count(n)})});
    }));
    sel.value = String(S.lines);
    return M.field('fp-slog-lines', t('slog_lines'), sel, t('slog_lines_hint'));
  }
  function matchField() {
    var inp = el('input', {class: 'sig-input', id: 'fp-slog-match', name: 'match', type: 'search', maxlength: String(MAX_MATCH), autocomplete: 'off', spellcheck: 'false',
      autocapitalize: 'none', value: S.match});
    return M.field('fp-slog-match', t('slog_match'), inp, t('slog_match_hint', {max: MAX_MATCH}));
  }
  function viewCard() {
    var l = logOf(S.id);
    if (!l) {
      return M.card('fp-slog-view-h', t('slog_view_title'), [el('p', {class: 'fp-muted', 'data-fp-pick': '', text: t('slog_pick')})], 'fp-slog-viewcard');
    }
    var form = el('form', {class: 'fp-form fp-slog-form', novalidate: ''}, [M.errorLine(),
      el('div', {class: 'fp-slog-fields'}, [linesField(), matchField()]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('slog_show')})])]);
    form.addEventListener('submit', function (e) { e.preventDefault(); show(form); });
    var parts = [form];
    if (S.read) {
      parts.push(el('div', {class: 'fp-slog-out', 'data-fp-out': ''}, outputOf(S.read)));
    } else if (S.busy) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-reading': '', text: t('slog_reading_now')}));
    }
    var card = M.card('fp-slog-view-h', t('slog_view_of', {title: l.title}), parts, 'fp-slog-viewcard');
    return card;
  }
  function outputOf(r) {
    var parts = [];
    var asked = S.shown;
    var line;
    if (!r.lines.length) {
      line = asked.match ? t('slog_nothing_match', {text: asked.match}) : t('slog_nothing');
    } else if (asked.match) {
      line = t(r.lines.length === 1 ? 'slog_count_match_1' : 'slog_count_match', {n: count(r.lines.length), text: asked.match});
    } else {
      line = t(r.lines.length === 1 ? 'slog_count_1' : 'slog_count', {n: count(r.lines.length)});
    }
    parts.push(el('p', {class: 'fp-muted fp-slog-count', 'data-fp-count': '', role: 'status', text: line + (S.at ? ' ' + t('slog_at', {when: S.at}) : '')}));
    if (r.lines.length) {
      parts.push(el('pre', {class: 'fp-slog-text sig-mono', tabindex: '0', role: 'region', 'aria-label': t('slog_text_of', {title: logOf(S.id).title}), 'data-fp-text': '', text: r.lines.join('\n')}));
    }
    if (r.truncated) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-truncated': '', text: t(asked.lines >= MAX_LINES || asked.match ? 'slog_truncated_narrow' : 'slog_truncated')}));
    }
    return parts;
  }
  function draw() {
    S.page.textContent = '';
    S.page.appendChild(listCard());
    S.page.appendChild(viewCard());
    if (S.rot) { S.page.appendChild(rotationCard()); }
  }
  /* how the panel's own logs are rotated: the closed list the server sends, how often, how many kept, compressed, an early size, the journal's room */
  function rotationCard() {
    var R = S.rot;
    var parts = [M.statusLine(), el('p', {class: 'fp-muted', text: t('slog_rot_intro')})];
    var boxes = R.available.map(function (l) {
      var id = 'fp-slog-rot-' + l.id;
      var box = el('input', {type: 'checkbox', id: id, name: 'log', value: l.id});
      box.checked = l.on;
      return el('div', {class: 'fp-check'}, [box, el('label', {for: id, text: l.title + ' (' + l.path + ')'})]);
    });
    var freq = el('select', {class: 'sig-select', id: 'fp-slog-rot-freq', name: 'frequency'}, ['daily', 'weekly', 'monthly'].map(function (f) {
      var o = el('option', {value: f, text: t('slog_rot_' + f)});
      if (R.frequency === f) { o.selected = true; }
      return o;
    }));
    var keep = el('input', {class: 'sig-input', id: 'fp-slog-rot-keep', name: 'keep', type: 'number', min: '1', max: '365', value: String(R.keep)});
    var maxs = el('input', {class: 'sig-input', id: 'fp-slog-rot-size', name: 'max_size_mb', type: 'number', min: '0', max: '10240', value: String(R.max_size_mb)});
    var jmax = el('input', {class: 'sig-input', id: 'fp-slog-rot-journal', name: 'journal_max_mb', type: 'number', min: '0', max: '102400', value: String(R.journal_max_mb)});
    var comp = el('input', {type: 'checkbox', id: 'fp-slog-rot-comp', name: 'compress'});
    comp.checked = R.compress;
    var form = el('form', {class: 'fp-form fp-slog-rotform', novalidate: ''}, [M.errorLine(),
      el('fieldset', {class: 'fp-fieldset'}, [el('legend', {text: t('slog_rot_logs')})].concat(boxes)),
      M.field('fp-slog-rot-freq', t('slog_rot_freq'), freq, ''), M.field('fp-slog-rot-keep', t('slog_rot_keep'), keep, t('slog_rot_keep_hint')),
      el('div', {class: 'fp-check'}, [comp, el('label', {for: 'fp-slog-rot-comp', text: t('slog_rot_compress')})]),
      M.field('fp-slog-rot-size', t('slog_rot_size'), maxs, t('slog_rot_size_hint')), M.field('fp-slog-rot-journal', t('slog_rot_journal'), jmax, t('slog_rot_journal_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('slog_rot_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var body = {logs: [].slice.call(form.querySelectorAll('input[name="log"]:checked')).map(function (x) { return x.value; }), frequency: freq.value,
        keep: parseInt(keep.value, 10), compress: comp.checked, max_size_mb: parseInt(maxs.value || '0', 10), journal_max_mb: parseInt(jmax.value || '0', 10)};
      if (!(body.keep >= 1 && body.keep <= 365)) { M.fieldError(form, keep, t('slog_rot_keep_hint')); return; }
      if (!(body.max_size_mb >= 0)) { M.fieldError(form, maxs, t('slog_rot_size_hint')); return; }
      if (!(body.journal_max_mb === 0 || (body.journal_max_mb >= 64 && body.journal_max_mb <= 102400))) { M.fieldError(form, jmax, t('slog_rot_journal_hint')); return; }
      var mine = S;
      UI.setBusy(b, true);
      FP.call('put', 'logRotation', body).then(function (r) {
        if (S !== mine) { return; }
        mine.rot = cleanRot(r);
        draw();
        M.say(mine.page.querySelector('.fp-slog-rot'), t('slog_rot_saved'));
        mine.page.querySelector('#fp-slog-rot-h').focus();
      }, function (err) {
        UI.setBusy(b, false);
        if (S === mine) { M.failed(form, err); }
      });
    });
    parts.push(form);
    return M.card('fp-slog-rot-h', t('slog_rot_title'), parts, 'fp-slog-rot');
  }
  function cleanRot(r) {
    r = r && typeof r === 'object' ? r : {};
    return {frequency: ['daily', 'weekly', 'monthly'].indexOf(r.frequency) >= 0 ? r.frequency : 'weekly', keep: whole(r.keep) || 4, compress: r.compress === true,
      max_size_mb: whole(r.max_size_mb), journal_max_mb: whole(r.journal_max_mb),
      available: arr(r.available).filter(function (l) { return l && ID_RE.test(str(l.id, 40)); }).slice(0, 20).map(function (l) {
        return {id: l.id, title: str(l.title, 100), path: str(l.path, 200), on: l.on === true};
      })};
  }
  /* only the log's own card is drawn again, so a focused list button stays where it is; a focus inside the card goes to the same place in the new one */
  function drawView() {
    var old = S.page.querySelector('.fp-slog-viewcard');
    var at = document.activeElement;
    var had = old.contains(at);
    var id = had && at.id ? at.id : '';
    /* what is typed while the log is being read is kept: the card is drawn again when the answer comes */
    var typed = old.querySelector('.fp-slog-form');
    var lines = typed && typed.querySelector('[name="lines"]');
    var match = typed && typed.querySelector('[name="match"]');
    var fresh = viewCard();
    if (lines && match) {
      fresh.querySelector('[name="lines"]').value = lines.value;
      fresh.querySelector('[name="match"]').value = match.value;
    }
    S.page.replaceChild(fresh, old);
    var text = fresh.querySelector('[data-fp-text]');
    if (text) { text.scrollTop = text.scrollHeight; }
    if (had) {
      var back = (id && document.getElementById(id)) || fresh.querySelector('.fp-submit');
      if (back) { back.focus({preventScroll: true}); }
    }
  }

  /* ---- reading ---- */
  function readyForm(form) {
    var lines = parseInt(form.querySelector('[name="lines"]').value, 10);
    var matchField = form.querySelector('[name="match"]');
    var match = matchField.value;
    if (LINE_CHOICES.indexOf(lines) < 0) { M.fieldError(form, form.querySelector('[name="lines"]'), t('slog_lines_bad')); return null; }
    if (match.length > MAX_MATCH || CONTROL.test(match)) { M.fieldError(form, matchField, t('slog_match_bad', {max: MAX_MATCH})); return null; }
    return {lines: lines, match: match};
  }
  function show(form) {
    var b = M.start(form);
    if (!b) { return; }
    var want = readyForm(form);
    if (!want) { return; }
    S.lines = want.lines;
    S.match = want.match;
    load(b);
  }
  function load(button) {
    var mine = S;
    var id = S.id;
    var seq = ++S.seq;
    var asked = {lines: S.lines, match: S.match};
    UI.setBusy(button, true);
    S.busy = true;
    var arg = {id: id, lines: String(asked.lines), match: asked.match};
    return FP.call('get', 'serverLog', undefined, arg).then(function (r) {
      if (S !== mine || mine.seq !== seq) { return; }
      mine.busy = false;
      mine.read = cleanRead(r, id);
      mine.shown = asked;
      mine.at = new Date().toLocaleTimeString('en', {timeStyle: 'short'});
      drawView();
      UI.announce(t('slog_updated'));
    }, function (err) {
      if (S !== mine || mine.seq !== seq) { return; }
      mine.busy = false;
      UI.setBusy(button, false);
      var live = mine.page.querySelector('.fp-slog-form');
      if (err && err.status === 404) {
        /* the log is not on this server (any more): the list says so and the card goes */
        var l = logOf(id);
        if (l) { l.available = false; }
        mine.id = '';
        mine.read = null;
        draw();
        UI.showError(mine.page.querySelector('.fp-slog-listcard'), err.message);
        return;
      }
      if (live) { M.failed(live, err); }
    });
  }
  function pick(id) {
    if (S.id === id) {
      var current = S.page.querySelector('.fp-slog-form .fp-submit');
      if (current) { current.focus(); }
      return;
    }
    S.id = id;
    S.read = null;
    S.seq++;
    S.busy = true;
    draw();
    var form = S.page.querySelector('.fp-slog-form');
    S.page.querySelector('#fp-slog-view-h').focus();
    load(form.querySelector('.fp-submit'));
  }
  function onClick(e) {
    var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !S || !S.page.contains(b)) { return; }
    var act = b.getAttribute('data-fp-act');
    if (act === 'read') { pick(b.closest('li').getAttribute('data-fp-log')); }
    if (act === 'again') { start(true); }
  }

  function start(again) {
    S = null;
    var tool = FP.tools.server_logs;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('slog_desc'), cls: 'fp-mail fp-rpp fp-slog-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    var mine = S = {page: page, logs: [], id: '', read: null, shown: {lines: 200, match: ''}, at: '', lines: 200, match: '', busy: false, seq: 0};
    page.addEventListener('click', onClick);
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    if (again) { document.getElementById('fp-h1').focus(); }
    FP.call('get', 'serverLogs').then(function (r) {
      if (S !== mine) { return; }
      mine.logs = cleanList(r);
      draw();
      FP.call('get', 'logRotation').then(function (x) {
        if (S !== mine) { return; }
        mine.rot = cleanRot(x);
        mine.page.appendChild(rotationCard());
      }, function () {});
    }, function (err) {
      if (S !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err.message, el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'again', text: t('slog_try_again')})));
    });
  }
  FP.view('tool:server_logs', function () { start(false); });
})();

/* freePanel mail routing (docs/api.md, "Email", PUT .../email/routing/{domain}): the customer panel's Mail routing page (#/tool/mail_routing).
   For each domain of the account it shows where the domain's mail goes now (to the mailboxes here, on to the domain's real mail servers, held
   here only to be passed on, or held until the domain is proven) and lets the customer choose: follow the domain's DNS (what every domain
   starts with), always deliver here, never deliver here, or act as a backup for another mail server. Backup is the host's to offer, so the
   page says when it is off and why. A change that stops mail reaching the mailboxes the domain has here is asked about first. The choice is
   live when the call returns; a call that fails leaves the saved choice as it was, and the page says so. Everything the server sends is shown
   as text. The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var DOMAIN_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var MODES = ['auto', 'local', 'remote', 'backup'];
  var DELIVERY = ['local', 'remote', 'backup', 'held'];
  var PILL = {local: 'ok', remote: '', backup: 'accent', held: 'warn'};

  function str(v) { return typeof v === 'string' ? v : ''; }
  function when(v) {
    if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}T/.test(v)) { return ''; }
    var d = new Date(v);
    return isNaN(d.getTime()) ? '' : d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'});
  }
  /* the domains of an answer, in order, each once, in the shapes the page draws */
  function cleanRouting(v) {
    var seen = {};
    var rows = [];
    (v && Array.isArray(v.routing) ? v.routing : []).forEach(function (r) {
      if (!r || typeof r !== 'object' || !DOMAIN_RE.test(str(r.domain)) || MODES.indexOf(r.mode) < 0 || seen[r.domain]) { return; }
      seen[r.domain] = true;
      rows.push({domain: r.domain, mode: r.mode, delivery: DELIVERY.indexOf(r.delivery) >= 0 ? r.delivery : '',
        dnsHere: typeof r.dns_here === 'boolean' ? r.dns_here : null, checked: when(r.dns_checked)});
    });
    return rows.sort(function (a, b) { return a.domain < b.domain ? -1 : 1; });
  }

  var R = {page: null, account: '', mail: null, rows: [], backup: false, pick: '', busy: false};
  function rowOf(domain) { return R.rows.filter(function (r) { return r.domain === domain; })[0]; }
  function settle(reply) {
    R.mail = M.clean(reply);
    R.rows = cleanRouting(reply);
    R.backup = reply && reply.backup_allowed === true;
    if (!rowOf(R.pick)) { R.pick = R.rows.length ? R.rows[0].domain : ''; }
  }

  /* the mailboxes and forwarders a domain has here: what stops receiving mail when the domain's mail is sent elsewhere */
  function addressesAt(domain) {
    var at = function (a) { return a.slice(a.lastIndexOf('@') + 1) === domain; };
    return {
      boxes: R.mail.mailboxes.filter(function (b) { return at(b.address); }).length,
      forwarders: R.mail.forwarders.filter(function (f) { return at(f.source); }).length
    };
  }

  /* "2 mailboxes and 1 forwarder": what a domain has here, for the question before its mail is sent elsewhere */
  function countsText(n) {
    var parts = [];
    if (n.boxes) { parts.push(t(n.boxes === 1 ? 'mrt_n_box' : 'mrt_n_boxes', {n: n.boxes})); }
    if (n.forwarders) { parts.push(t(n.forwarders === 1 ? 'mrt_n_forwarder' : 'mrt_n_forwarders', {n: n.forwarders})); }
    return parts.join(' ' + t('mrt_and') + ' ');
  }

  function pill(kind, text) { return el('span', {class: 'sig-pill' + (kind ? ' sig-pill--' + kind : ''), text: text}); }
  function deliveryPill(r) { return r.delivery ? pill(PILL[r.delivery], t('mrt_pill_' + r.delivery)) : null; }
  function dnsText(r) {
    if (r.dnsHere === null) { return t('mrt_dns_unknown'); }
    return t(r.dnsHere ? 'mrt_dns_here' : 'mrt_dns_elsewhere') + (r.checked ? ' ' + t('mrt_dns_checked', {when: r.checked}) : '');
  }
  /* why a domain's mail goes where it does, in a sentence */
  function whyText(r) {
    if (r.delivery === 'held') { return t('mrt_why_held'); }
    if (r.mode === 'backup' && !R.backup) { return t('mrt_why_backup_off'); }
    if (r.mode === 'auto') { return t(r.delivery === 'local' ? 'mrt_why_auto_local' : 'mrt_why_auto_remote'); }
    return t('mrt_why_' + r.mode);
  }

  /* ---- the list ---- */
  function item(r) {
    return el('li', {class: 'fp-mrt-item', 'data-fp-domain': r.domain}, [
      el('div', {class: 'fp-mrt-who'}, [
        el('span', {class: 'fp-mrt-head'}, [el('span', {class: 'sig-mono fp-mrt-name', text: r.domain}), deliveryPill(r)]),
        el('span', {class: 'fp-mrt-why', text: whyText(r)}),
        el('span', {class: 'fp-muted fp-row-note', text: t('mrt_choice', {choice: t('mrt_mode_' + r.mode)}) + ' · ' + dnsText(r)})]),
      el('div', {class: 'fp-mrt-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'mrt-change',
        'aria-label': t('mrt_change_of', {domain: r.domain}), text: t('mrt_change')})])]);
  }
  function listCard() {
    var parts = [M.errorLine(), M.statusLine()];
    if (!R.rows.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('mrt_none')}));
    } else {
      parts.push(el('p', {class: 'fp-muted', text: t('mrt_intro')}));
      parts.push(el('ul', {class: 'fp-mrt-list', 'aria-labelledby': 'fp-mrt-h'}, R.rows.map(item)));
    }
    return M.card('fp-mrt-h', t('mrt_title'), parts, 'fp-mrt-list-card');
  }

  /* ---- the form ---- */
  function option(mode) {
    var id = 'fp-mrt-' + mode;
    var off = mode === 'backup' && !R.backup;
    var hint = t('mrt_hint_' + mode) + (off ? ' ' + t('mrt_hint_backup_off') : '');
    var input = el('input', {type: 'radio', id: id, name: 'mode', value: mode, 'aria-describedby': id + '-hint'});
    if (off) { input.disabled = true; }
    return el('div', {class: 'fp-mrt-choice' + (off ? ' is-off' : '')}, [
      el('label', {class: 'fp-check', for: id}, [input, el('span', {text: t('mrt_opt_' + mode)})]),
      el('span', {class: 'sig-hint', id: id + '-hint', text: hint})]);
  }
  function formCard() {
    var pick = el('select', {class: 'sig-select', id: 'fp-mrt-domain', name: 'domain'}, R.rows.map(function (r) {
      var o = el('option', {value: r.domain, text: r.domain});
      if (r.domain === R.pick) { o.selected = true; }
      return o;
    }));
    var now = el('div', {class: 'fp-mrt-now', 'data-fp-now': '', 'aria-live': 'polite'});
    var ask = el('div', {class: 'fp-mrt-ask'});
    var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('mrt_save')});
    var form = el('form', {class: 'fp-form fp-mail-form fp-mrt-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-mrt-domain', t('mrt_for_domain'), pick), now,
      el('fieldset', {class: 'fp-mrt-modes'}, [el('legend', {class: 'sig-label', text: t('mrt_mode')})].concat(MODES.map(option))),
      ask, el('div', {class: 'fp-actions'}, [save])]);
    function chosen() { var c = form.querySelector('[name="mode"]:checked'); return c ? c.value : ''; }
    /* the form shows the chosen domain's setting as the server has it */
    function load() {
      var r = rowOf(pick.value);
      R.pick = pick.value;
      ask.textContent = '';
      var c = r ? form.querySelector('[name="mode"][value="' + r.mode + '"]') : null;
      if (c) { c.checked = true; }
      now.textContent = '';
      if (r) {
        now.appendChild(el('span', {class: 'fp-mrt-now-k', text: t('mrt_now')}));
        now.appendChild(deliveryPill(r));
        now.appendChild(el('span', {class: 'fp-mrt-now-why', text: whyText(r)}));
      }
    }
    pick.addEventListener('change', function () { M.start(form); load(); });
    form.addEventListener('change', function (e) { if (e.target.name === 'mode') { ask.textContent = ''; } });
    load();
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || R.busy) { return; }
      var domain = pick.value;
      var r = rowOf(domain);
      var mode = chosen();
      if (!r || MODES.indexOf(mode) < 0) { M.fieldError(form, form.querySelector('[name="mode"]'), t('mrt_pick_mode')); return; }
      if (mode === r.mode) { M.say(form, t('mrt_unchanged_choice', {domain: domain, choice: t('mrt_mode_' + mode)})); return; }
      /* sending the mail elsewhere stops the mailboxes and forwarders this domain has here from receiving it: ask first */
      var n = addressesAt(domain);
      if ((mode === 'remote' || mode === 'backup') && r.delivery === 'local' && (n.boxes || n.forwarders)) {
        if (!ask.firstChild) { M.confirmIn(ask, t('mrt_ask', {domain: domain, what: countsText(n)}), 'mrt-yes', t('mrt_ask_yes')); }
        return;
      }
      send(form, b, domain, mode);
    });
    form.addEventListener('click', function (e) {
      var a = e.target.closest ? e.target.closest('[data-fp-act]') : null;
      if (!a) { return; }
      if (a.getAttribute('data-fp-act') === 'confirm-no') { ask.textContent = ''; save.focus(); }
      if (a.getAttribute('data-fp-act') === 'mrt-yes' && !R.busy) {
        var m = chosen();
        ask.textContent = '';
        send(form, save, pick.value, m);
      }
    });
    return M.card('fp-mrt-form-h', t('mrt_form_title'), [form], 'fp-mrt-change');
  }
  /* a failed save leaves the saved choice as it was: the page says so, and keeps what was picked */
  function send(form, b, domain, mode) {
    var mine = R.page;
    R.busy = true;
    UI.setBusy(b, true);
    FP.call('put', 'mailRouting', {mode: mode}, {name: R.account, domain: domain}).then(function (reply) {
      R.busy = false;
      if (R.page !== mine) { return; }
      settle(reply);
      R.pick = domain;
      render();
      var r = rowOf(domain);
      M.say(R.page.querySelector('.fp-mrt-list-card'), t('mrt_saved', {domain: domain, what: r ? whyText(r) : ''}));
      R.page.querySelector('#fp-mrt-h').focus();
    }, function (err) {
      R.busy = false;
      if (R.page !== mine) { return; }
      UI.setBusy(b, false);
      var unsure = !err || err.status === 0 || err.status >= 500;
      M.failed(form, unsure ? {field: err && err.field, message: (err && err.message ? err.message : t('api_failed')) + ' ' + t('mrt_nothing_changed')} : err);
    });
  }

  function helpCard() {
    return M.card('fp-mrt-help-h', t('mrt_help_title'), [el('dl', {class: 'fp-mrt-help'}, MODES.reduce(function (out, m) {
      return out.concat([el('dt', {text: t('mrt_opt_' + m)}), el('dd', {text: t('mrt_help_' + m)})]);
    }, []))], 'fp-mrt-help-card');
  }

  function render() {
    R.page.textContent = '';
    if (R.mail.suspended) { R.page.appendChild(M.suspendedBanner(t('mail_suspended'))); }
    R.page.appendChild(listCard());
    if (R.rows.length) {
      R.page.appendChild(formCard());
      R.page.appendChild(helpCard());
    }
  }

  document.addEventListener('click', function (e) {
    if (!R.page) { return; }
    var b = e.target.closest ? e.target.closest('[data-fp-act="mrt-change"]') : null;
    if (!b || !R.page.contains(b)) { return; }
    var pick = R.page.querySelector('#fp-mrt-domain');
    pick.value = b.closest('li').getAttribute('data-fp-domain');
    pick.dispatchEvent(new Event('change'));
    var chosen = R.page.querySelector('.fp-mrt-form [name="mode"]:checked');
    (chosen && !chosen.disabled ? chosen : pick).focus();
    R.page.querySelector('.fp-mrt-change').scrollIntoView({block: 'nearest'});
  });

  FP.view('tool:mail_routing', function () {
    R = {page: null, account: '', mail: null, rows: [], backup: false, pick: '', busy: false};
    var body = M.frame('mail_routing', 'fp-mrt-page');
    if (!body) { return; }
    R.page = body;
    R.account = FP.account();
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'mail', undefined, R.account).then(function (reply) {
      if (R.page !== body) { return; }
      settle(reply);
      render();
    }, function (err) {
      if (R.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(FP.tools.mail_routing.label, err.message));
    });
  });
})();

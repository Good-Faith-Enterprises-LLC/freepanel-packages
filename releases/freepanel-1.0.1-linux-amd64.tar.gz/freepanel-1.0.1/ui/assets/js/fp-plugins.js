/* freePanel plugins (docs/api.md, "Plugins"; docs/plugins.md), in the admin panel: #/tool/plugins, the server admin's alone. A plugin adds pages to this panel. It is
   data in a signed package: the server checks the signature against the keys the admin trusts before it reads anything from the package, and the admin reads what the
   plugin asks for and approves exactly that before it can be turned on (and again when an update asks for more). This page trusts and removes keys, uploads a package,
   approves, turns on and off and removes plugins, each as the server says, with the admin's own password for what grants trust. A plugin's pages are drawn here from
   data the server sends, block by block, with this panel's own code and the text set as text: a block is a heading, text, a list, a table or live server status, and
   nothing else, so a plugin cannot put markup, a link or a script in the panel. What the server sends is cleaned to those shapes. Page pieces come from FP.mail
   (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var MAX_PLUGINS = 20;
  var MAX_KEYS = 10;
  var MAX_PACKAGE = 16 * 1024 * 1024;
  var STATUSES = ['needs_approval', 'disabled', 'enabled'];
  var KEY_NAME_RE = /^[A-Za-z0-9][A-Za-z0-9 ._-]{0,39}$/;
  var ID_RE = /^[a-z][a-z0-9]*(-[a-z0-9]+)*$/;
  var FINGERPRINT_RE = /^[0-9a-f]{16}$/;
  var DIGEST_RE = /^[0-9a-f]{64}$/;
  var PUBLIC_KEY_RE = /^[A-Za-z0-9+/]{43}=$/;
  var VERSION_RE = /^\d{1,4}\.\d{1,4}\.\d{1,4}$/;
  var PERM_RE = /^[a-z][a-z._]{0,39}$/;
  var BLOCKS = ['heading', 'text', 'list', 'table', 'data'];
  var RUN_STATES = ['ok', 'failed', 'timeout', 'stopped', 'bad_output', 'too_large', 'not_running'];
  var CONFIRM_STATES = ['confirmed', 'waiting', 'unknown'];

  var P = null;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function arr(v) { return Array.isArray(v) ? v : []; }
  function when(v) {
    var d = typeof v === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(v) ? new Date(v) : null;
    return d && !isNaN(d.getTime()) ? d : null;
  }
  function dateText(d) { return d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'}); }
  function count(n) { return Math.round(n).toLocaleString('en'); }

  /* ---- what the server sends, cleaned to the shapes this page draws ---- */
  function cleanKey(x) {
    if (!x || typeof x !== 'object' || !FINGERPRINT_RE.test(str(x.fingerprint, 16))) { return null; }
    return {fingerprint: x.fingerprint, name: str(x.name, 40), created: when(x.created_at)};
  }
  function cleanBlock(b) {
    if (!b || typeof b !== 'object' || BLOCKS.indexOf(b.type) < 0) { return null; }
    var out = {type: b.type};
    if (b.type === 'heading' || b.type === 'text') { out.text = str(b.text, 2000); }
    if (b.type === 'list') { out.items = arr(b.items).slice(0, 50).map(function (i) { return str(i, 300); }); }
    if (b.type === 'table') {
      out.columns = arr(b.columns).slice(0, 8).map(function (c) { return str(c, 60); });
      out.rows = arr(b.rows).slice(0, 100).map(function (r) { return arr(r).slice(0, out.columns.length).map(function (c) { return str(c, 200); }); });
    }
    if (b.type === 'data') {
      out.source = b.source === 'server_status' ? b.source : '';
      if (!out.source) { return null; }
    }
    return out;
  }
  function cleanPage(pg) {
    if (!pg || typeof pg !== 'object') { return null; }
    return {id: str(pg.id, 30), title: str(pg.title, 60), blocks: arr(pg.blocks).slice(0, 40).map(cleanBlock).filter(Boolean)};
  }
  function cleanPlugin(x) {
    if (!x || typeof x !== 'object' || !ID_RE.test(str(x.id, 40)) || STATUSES.indexOf(x.status) < 0) { return null; }
    return {id: x.id, name: str(x.name, 60), description: str(x.description, 300), author: str(x.author, 80), version: VERSION_RE.test(str(x.version, 14)) ? x.version : '',
      status: x.status, signer: FINGERPRINT_RE.test(str(x.signer, 16)) ? x.signer : '', signerName: str(x.signer_name, 40), trusted: x.trusted === true,
        signerKey: PUBLIC_KEY_RE.test(str(x.signer_key, 44)) ? x.signer_key : '', digest: DIGEST_RE.test(str(x.digest, 64)) ? x.digest : '', canRun: x.can_run === true, runConfirm: cleanConfirm(x.run_confirm),
      perms: arr(x.permissions).slice(0, 10).filter(function (p) { return p && typeof p === 'object' && PERM_RE.test(str(p.id, 40)); }).map(function (p) {
        return {id: p.id, title: str(p.title, 100), detail: str(p.detail, 400), approved: p.approved === true};
      }),
      pages: arr(x.pages).slice(0, 5).map(cleanPage).filter(Boolean), installed: when(x.installed_at), updated: when(x.updated_at)};
  }
  /* where the program of a plugin stands with the root agent, as the server tells it: root approves it on the server, and these are the commands for that (plain text) */
  function cleanConfirm(c) {
    if (!c || typeof c !== 'object' || CONFIRM_STATES.indexOf(c.state) < 0) { return null; }
    return {state: c.state, message: str(c.message, 200),
      commands: arr(c.commands).slice(0, 3).map(function (x) { return str(x, 400); }).filter(function (x) { return /^freepanelctl plugin /.test(x); })};
  }
  /* how a run went, as the server tells it: the blocks are only those a page may hold (never a data block) and only for a run that is ok */
  function cleanRun(r) {
    if (!r || typeof r !== 'object') { return null; }
    var state = RUN_STATES.indexOf(r.state) >= 0 ? r.state : '';
    var blocks = arr(r.blocks).slice(0, 40).map(cleanBlock).filter(function (b) { return b && b.type !== 'data'; });
    return {state: state, ms: isFinite(r.duration_ms) ? Math.max(0, r.duration_ms) : 0, blocks: state === 'ok' ? blocks : [], stderr: str(r.stderr, 2100), message: str(r.message, 300)};
  }
  function cleanList(r) {
    return {plugins: arr(r && r.plugins).map(cleanPlugin).filter(Boolean).slice(0, MAX_PLUGINS * 2), keys: arr(r && r.keys).map(cleanKey).filter(Boolean).slice(0, MAX_KEYS * 2),
      ready: !r || r.ready !== false};
  }

  /* ---- a plugin's pages, drawn from data ---- */
  function statusValue(st) {
    var mem = st && st.memory && isFinite(st.memory.total_bytes) && isFinite(st.memory.available_bytes) ? st.memory : null;
    var disk = st && st.home_disk && isFinite(st.home_disk.total_bytes) && isFinite(st.home_disk.free_bytes) ? st.home_disk : null;
    var gib = function (n) { return (Math.round(n / 107374182.4) / 10).toLocaleString('en') + ' GiB'; };
    var days = st && isFinite(st.uptime_seconds) ? Math.floor(st.uptime_seconds / 86400) : null;
    var hours = st && isFinite(st.uptime_seconds) ? Math.floor(st.uptime_seconds % 86400 / 3600) : null;
    return [[t('plug_st_host'), str(st && st.hostname, 80)],
      [t('plug_st_uptime'), days === null ? '' : t('plug_st_uptime_v', {d: count(days), h: hours})],
      [t('plug_st_load'), st && Array.isArray(st.load) ? st.load.slice(0, 3).map(function (n) { return isFinite(n) ? n.toFixed(2) : '?'; }).join(' ') : ''],
      [t('plug_st_memory'), mem ? t('plug_st_of', {used: gib(mem.total_bytes - mem.available_bytes), total: gib(mem.total_bytes)}) : ''],
      [t('plug_st_disk'), disk ? t('plug_st_of', {used: gib(disk.total_bytes - disk.free_bytes), total: gib(disk.total_bytes)}) : '']].filter(function (r) { return r[1]; });
  }
  function blockNode(b) {
    if (b.type === 'heading') { return el('h4', {class: 'fp-h3 fp-plug-block-h', text: b.text}); }
    if (b.type === 'text') {
      return el('div', {class: 'fp-plug-text'}, b.text.split('\n').map(function (line) { return el('p', {class: 'fp-plug-p', text: line}); }));
    }
    if (b.type === 'list') { return el('ul', {class: 'fp-plug-ul'}, b.items.map(function (i) { return el('li', {text: i}); })); }
    if (b.type === 'table') {
      var head = el('thead', null, [el('tr', null, b.columns.map(function (c) { return el('th', {scope: 'col', text: c}); }))]);
      var body = el('tbody', null, b.rows.map(function (r) {
        return el('tr', null, b.columns.map(function (c, i) { return el('td', {text: r[i] || ''}); }));
      }));
      return el('div', {class: 'fp-table-wrap fp-plug-table', role: 'region', tabindex: '0', 'aria-label': t('plug_table')}, [el('table', {class: 'sig-table'}, [head, body])]);
    }
    return el('dl', {class: 'fp-plug-data', 'data-fp-source': b.source}, [el('dd', {class: 'fp-muted', text: t('loading')})]);
  }
  function pagesNode(p) {
    /* each page is a sheet that says whose it is, so that a heading a plugin writes cannot pass for the panel's own */
    return el('div', {class: 'fp-plug-pages', 'data-fp-pages': p.id}, p.pages.map(function (pg) {
      return el('section', {class: 'fp-plug-sheet', 'aria-label': t('plug_page_label', {title: pg.title, name: p.name})}, [
        el('p', {class: 'fp-plug-from', 'data-fp-from': p.id, text: t('plug_from', {name: p.name})}),
        el('h3', {class: 'fp-h3', text: pg.title})].concat(pg.blocks.map(blockNode)));
    }));
  }
  /* the live server status some pages show: read once for the page, and put in each place that asks */
  function fillStatus(mine) {
    var holes = mine.page.querySelectorAll('.fp-plug-data[data-fp-source="server_status"]');
    if (!holes.length) { return; }
    FP.call('get', 'serverStatus').then(function (r) {
      if (P !== mine) { return; }
      var rows = statusValue(r && r.status);
      [].forEach.call(holes, function (h) {
        h.textContent = '';
        if (!rows.length) { h.appendChild(el('dd', {class: 'fp-muted', text: t('plug_st_none')})); }
        rows.forEach(function (row) { h.appendChild(el('dt', {text: row[0]})); h.appendChild(el('dd', {text: row[1]})); });
      });
    }, function () {
      if (P !== mine) { return; }
      [].forEach.call(holes, function (h) { h.textContent = ''; h.appendChild(el('dd', {class: 'fp-muted', text: t('plug_st_none')})); });
    });
  }

  /* ---- the plugins ---- */
  function permList(p) {
    if (!p.perms.length) { return el('p', {class: 'fp-muted fp-row-note', 'data-fp-perms': 'none', text: t('plug_perm_none')}); }
    return el('ul', {class: 'fp-plug-perms', 'data-fp-perms': String(p.perms.length)}, p.perms.map(function (m) {
      return el('li', {class: 'fp-plug-perm', 'data-fp-perm': m.id}, [el('span', {class: 'fp-plug-perm-t', text: m.title || m.id}),
        el('span', {class: 'sig-pill' + (m.approved ? ' sig-pill--ok' : ''), text: t(m.approved ? 'plug_perm_ok' : 'plug_perm_not')}),
        m.detail ? el('span', {class: 'fp-muted fp-row-note', text: m.detail}) : null]);
    }));
  }
  function signerText(p) {
    if (!p.signer) { return ''; }
    return p.trusted ? t('plug_signed_by', {name: p.signerName, fp: p.signer}) : t('plug_signed_untrusted', {fp: p.signer});
  }
  function passwordForm(p, act, label, said) {
    var id = 'fp-plug-pw-' + p.id;
    var pw = el('input', {class: 'sig-input', id: id, name: 'current_password', type: 'password', autocomplete: 'current-password'});
    var form = el('form', {class: 'fp-form fp-plug-form', novalidate: '', 'data-fp-act-form': act, 'data-fp-id': p.id}, [M.errorLine(),
      M.field(id, t('plug_password'), pw, said),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: label})])]);
    form.addEventListener('submit', function (e) { e.preventDefault(); act === 'approve' ? approve(form, p) : enable(form, p); });
    return form;
  }
  /* the program of a plugin that has the run permission: a button that runs it once, a button that stops it, and what it printed */
  function runBox(p) {
    var run = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'run', 'data-fp-id': p.id, 'aria-label': t('plug_run_of', {name: p.name}), text: t('plug_run')});
    var stop = el('button', {class: 'sig-btn sig-btn--secondary fp-btn-danger-text', type: 'button', 'data-fp-act': 'run-stop', 'data-fp-id': p.id, 'aria-label': t('plug_run_stop_of', {name: p.name}), text: t('plug_run_stop')});
    stop.hidden = true;
    return el('div', {class: 'fp-plug-run', 'data-fp-run': p.id}, [el('h4', {class: 'fp-h3 fp-plug-run-h', text: t('plug_run_title')}),
      el('p', {class: 'fp-muted fp-row-note', text: t('plug_run_intro')}), M.errorLine(),
      el('div', {class: 'fp-actions'}, [run, stop]),
      el('p', {class: 'fp-row-note', role: 'status', 'data-fp-run-status': ''}),
      el('div', {class: 'fp-plug-run-out', 'data-fp-run-out': ''})]);
  }
  /* what only root can do: approve the program on the server. The panel says where it stands and shows the exact commands; it cannot make them happen */
  function confirmBox(p) {
    var c = p.runConfirm;
    var approved = p.perms.some(function (x) { return x.id === 'run' && x.approved; });
    if (!c || c.state === 'confirmed' || !approved) { return null; }
    var kids = [el('h4', {class: 'fp-h3 fp-plug-run-h', text: t('plug_confirm_title')})];
    if (c.state === 'unknown') {
      kids.push(el('p', {class: 'fp-muted fp-row-note', 'data-fp-confirm': 'unknown', text: t('plug_confirm_unknown', {why: c.message || t('plug_confirm_unknown_why')})}));
    } else {
      kids.push(el('p', {class: 'fp-muted fp-row-note', 'data-fp-confirm': 'waiting', text: t('plug_confirm_intro')}));
      c.commands.forEach(function (cmd) { kids.push(el('pre', {class: 'fp-plug-cmd sig-mono', 'data-fp-confirm-cmd': '', text: cmd})); });
      kids.push(el('p', {class: 'fp-muted fp-row-note', text: t('plug_confirm_after')}));
    }
    return el('div', {class: 'fp-plug-run fp-plug-confirm', 'data-fp-confirm-box': p.id}, kids);
  }
  function showRun(box, p, run) {
    var out = box.querySelector('[data-fp-run-out]');
    out.textContent = '';
    box.querySelector('[data-fp-run-status]').textContent = run.state ? t('plug_run_' + run.state, {s: (run.ms / 1000).toFixed(1)}) : '';
    if (run.message && run.state !== 'ok') { out.appendChild(el('p', {class: 'fp-muted fp-row-note', 'data-fp-run-message': '', text: run.message})); }
    if (run.blocks.length) {
      out.appendChild(el('section', {class: 'fp-plug-sheet fp-plug-output', 'aria-label': t('plug_run_from_label', {name: p.name})},
        [el('p', {class: 'fp-plug-from', 'data-fp-from-run': p.id, text: t('plug_run_from', {name: p.name})})].concat(run.blocks.map(blockNode))));
    }
    if (run.stderr) {
      out.appendChild(el('div', {class: 'fp-plug-stderr-box'}, [el('p', {class: 'fp-muted fp-row-note', text: t('plug_run_stderr')}),
        el('pre', {class: 'fp-plug-stderr sig-mono', 'data-fp-run-stderr': '', text: run.stderr})]));
    }
  }
  function pluginItem(p) {
    var parts = [];
    var headId = 'fp-plug-h-' + p.id;
    var acts = el('div', {class: 'fp-actions fp-plug-acts'});
    if (p.status === 'needs_approval') {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-note': 'approval'}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: p.perms.length === 1 ? t('plug_approve_note_1') : p.perms.length === 0 ? t('plug_approve_note_0') : t('plug_approve_note', {n: p.perms.length})})]));
    }
    parts.push(permList(p));
    if (!p.trusted && p.status !== 'needs_approval') {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-note': 'untrusted'}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('plug_untrusted_note')})]));
    }
    if (p.status === 'needs_approval') {
      parts.push(p.trusted ? passwordForm(p, 'approve', p.perms.length === 1 ? t('plug_approve_1') : p.perms.length === 0 ? t('plug_approve_0') : t('plug_approve', {n: p.perms.length}), t('plug_approve_hint')) :
        el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-note': 'untrusted'}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('plug_untrusted_note')})]));
    } else if (p.status === 'disabled' && p.trusted) {
      parts.push(passwordForm(p, 'enable', t('plug_enable'), t('plug_enable_hint')));
    } else if (p.status === 'enabled') {
      acts.appendChild(el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'disable', 'data-fp-id': p.id, 'aria-label': t('plug_disable_of', {name: p.name}), text: t('plug_disable')}));
    }
    acts.appendChild(el('span', {class: 'fp-plug-remove', 'data-fp-remove': p.id}, [el('button', {class: 'sig-btn sig-btn--secondary fp-btn-danger-text', type: 'button', 'data-fp-act': 'remove',
      'data-fp-id': p.id, 'aria-label': t('plug_remove_of', {name: p.name}), text: t('plug_remove')})]));
    parts.push(acts);
    if (p.canRun) { parts.push(runBox(p)); } else if (confirmBox(p)) { parts.push(confirmBox(p)); }
    if (p.status === 'enabled' && p.trusted) {
      parts.push(p.pages.length ? pagesNode(p) : el('p', {class: 'fp-muted fp-row-note', 'data-fp-pages': 'none', text: t('plug_pages_none')}));
    }
    return el('li', {class: 'fp-plug-item', 'data-fp-plugin': p.id, 'data-fp-plugin-state': p.status}, [
      el('div', {class: 'fp-plug-head'}, [el('h3', {class: 'fp-h3 fp-plug-name', id: headId, tabindex: '-1', text: p.name}),
        p.version ? el('span', {class: 'sig-pill', text: t('plug_version', {v: p.version})}) : null,
        el('span', {class: 'sig-pill' + (p.status === 'enabled' ? ' sig-pill--ok' : p.status === 'needs_approval' ? ' sig-pill--warn' : ''), 'data-fp-state': p.status, text: t('plug_status_' + p.status)})]),
      p.author ? el('p', {class: 'fp-muted fp-row-note', text: t('plug_by', {author: p.author})}) : null,
      p.description ? el('p', {class: 'fp-plug-desc', text: p.description}) : null,
      signerText(p) ? el('p', {class: 'fp-muted fp-row-note', 'data-fp-signer': p.trusted ? 'trusted' : 'untrusted', text: signerText(p)}) : null,
        p.digest ? el('p', {class: 'fp-muted fp-row-note sig-mono', 'data-fp-digest': '', text: t('plug_digest', {d: p.digest})}) : null].concat(parts));
  }
  function listCard() {
    var parts = [M.errorLine(), M.statusLine()];
    if (!P.plugins.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': 'plugins', text: t('plug_none')}));
    } else {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-count': '', text: t(P.plugins.length === 1 ? 'plug_count_1' : 'plug_count', {n: P.plugins.length, max: MAX_PLUGINS})}));
      parts.push(el('ul', {class: 'fp-plug-list-items'}, P.plugins.map(pluginItem)));
    }
    return M.card('fp-plug-list-h', t('plug_list_title'), parts, 'fp-plug-list');
  }

  /* ---- uploading a package ---- */
  function installCard() {
    if (!P.ready) { return M.card('fp-plug-install-h', t('plug_install_title'), [el('p', {class: 'fp-muted', 'data-fp-notready': '', text: t('plug_not_ready')})], 'fp-plug-install'); }
    if (!P.keys.length) {
      return M.card('fp-plug-install-h', t('plug_install_title'), [el('p', {class: 'fp-muted', 'data-fp-nokeys': '', text: t('plug_install_nokeys')})], 'fp-plug-install');
    }
    var file = el('input', {class: 'sig-input', id: 'fp-plug-file', name: 'package', type: 'file', accept: '.fpplugin,application/octet-stream'});
    var form = el('form', {class: 'fp-form fp-plug-form', novalidate: '', 'data-fp-install': ''}, [M.errorLine(),
      M.field('fp-plug-file', t('plug_file'), file, t('plug_file_hint', {mb: MAX_PACKAGE / 1048576})),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('plug_install')})])]);
    form.addEventListener('submit', function (e) { e.preventDefault(); install(form); });
    return M.card('fp-plug-install-h', t('plug_install_title'), [el('p', {class: 'fp-muted', text: t('plug_install_intro')}), form], 'fp-plug-install');
  }
  function install(form) {
    var b = M.start(form);
    if (!b) { return; }
    var input = UI.fieldNamed(form, 'package');
    var f = input.files && input.files[0];
    if (!f) { M.fieldError(form, input, t('plug_file_none')); return; }
    if (f.size < 1 || f.size > MAX_PACKAGE) { M.fieldError(form, input, t('plug_file_size', {mb: MAX_PACKAGE / 1048576})); return; }
    var mine = P;
    UI.setBusy(b, true);
    window.FPAPI.upload('plugins', f, 'application/octet-stream', undefined, function () { /* a small file: no progress is shown */ }).done.then(function (r) {
      if (P !== mine) { return; }
      var p = cleanPlugin(r);
      var waits = p && p.status === 'needs_approval';
      var said = !p ? t('plug_installed_unseen') : waits ? t('plug_installed_wait', {name: p.name, v: p.version}) : t('plug_installed', {name: p.name, v: p.version});
      reload(said, p ? p.id : '');
    }, function (err) {
      UI.setBusy(b, false);
      if (P !== mine) { return; }
      if (err && err.status === 401) { FP.signedOut(true); return; }
      /* the reason the package was refused is the server's: it names the key, the entry or the limit */
      M.fieldError(form, input, err && err.message ? err.message : t('api_failed'));
    });
  }

  /* ---- trusted keys ---- */
  function keyRow(k) {
    return el('li', {class: 'fp-rpp-row fp-plug-key', 'data-fp-key': k.fingerprint}, [
      el('div', {class: 'fp-rpp-main'}, [el('span', {class: 'fp-rpp-title', text: k.name}),
        el('span', {class: 'fp-muted sig-mono fp-row-note', text: t('plug_key_fp', {fp: k.fingerprint})}),
        k.created ? el('span', {class: 'fp-muted fp-row-note', text: t('plug_key_added', {when: dateText(k.created)})}) : null]),
      el('span', {class: 'fp-rpp-acts fp-plug-key-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'key-remove',
        'data-fp-fp': k.fingerprint, 'aria-label': t('plug_key_remove_of', {name: k.name}), text: t('plug_key_remove')})])]);
  }
  function keysCard() {
    var parts = [el('p', {class: 'fp-muted', text: t('plug_keys_intro')}), M.errorLine(), M.statusLine()];
    parts.push(P.keys.length ? el('ul', {class: 'fp-rpp-list fp-plug-keys'}, P.keys.map(keyRow)) : el('p', {class: 'fp-muted', 'data-fp-empty': 'keys', text: t('plug_keys_none')}));
    if (P.keys.length >= MAX_KEYS) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-full': '', text: t('plug_keys_full', {max: MAX_KEYS})}));
    } else {
      var name = el('input', {class: 'sig-input', id: 'fp-plug-key-name', name: 'name', type: 'text', maxlength: '40', autocomplete: 'off', spellcheck: 'false'});
      var pub = el('textarea', {class: 'sig-input sig-mono', id: 'fp-plug-key-pub', name: 'public_key', rows: '2', spellcheck: 'false', autocapitalize: 'none', autocomplete: 'off', maxlength: '200'});
      var pw = el('input', {class: 'sig-input', id: 'fp-plug-key-pw', name: 'current_password', type: 'password', autocomplete: 'current-password'});
      var form = el('form', {class: 'fp-form fp-plug-form fp-plug-keyform', novalidate: ''}, [M.errorLine(),
        M.field('fp-plug-key-name', t('plug_key_name'), name, t('plug_key_name_hint')), M.field('fp-plug-key-pub', t('plug_key_pub'), pub, t('plug_key_pub_hint')),
        M.field('fp-plug-key-pw', t('plug_password'), pw, t('plug_key_pw_hint')),
        el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('plug_key_add')})])]);
      form.addEventListener('submit', function (e) { e.preventDefault(); addKey(form); });
      parts.push(form);
    }
    return M.card('fp-plug-keys-h', t('plug_keys_title'), parts, 'fp-plug-keys-card');
  }
  function addKey(form) {
    var b = M.start(form);
    if (!b) { return; }
    var name = UI.fieldNamed(form, 'name');
    var pub = UI.fieldNamed(form, 'public_key');
    var pw = UI.fieldNamed(form, 'current_password');
    var n = name.value.trim();
    var key = pub.value.replace(/\s+/g, '');
    if (!KEY_NAME_RE.test(n)) { M.fieldError(form, name, t('plug_key_name_bad')); return; }
    if (!/^[A-Za-z0-9+/]{43}=$/.test(key)) { M.fieldError(form, pub, t('plug_key_pub_bad')); return; }
    if (!pw.value) { M.fieldError(form, pw, t('plug_need_password')); return; }
    var mine = P;
    UI.setBusy(b, true);
    FP.call('post', 'pluginKeys', {name: n, public_key: key, current_password: pw.value}).then(function () {
      if (P !== mine) { return; }
      reload(t('plug_key_added_ok', {name: n}), '', '#fp-plug-keys-h');
    }, function (err) {
      UI.setBusy(b, false);
      if (P !== mine) { return; }
      pw.value = '';
      if (err && err.status === 403) { M.fieldError(form, pw, err.message); return; }
      M.failed(form, err);
    });
  }

  /* ---- what is done to a plugin ---- */
  function approve(form, p) {
    var b = M.start(form);
    if (!b) { return; }
    var pw = UI.fieldNamed(form, 'current_password');
    if (!pw.value) { M.fieldError(form, pw, t('plug_need_password')); return; }
    var mine = P;
    UI.setBusy(b, true);
    /* exactly what was shown: the package (its version, its digest and the key that signed it) and every permission of it */
    FP.call('post', 'pluginApprove', {version: p.version, digest: p.digest, signer_key: p.signerKey, permissions: p.perms.map(function (m) { return m.id; }), current_password: pw.value}, {id: p.id}).then(function () {
      if (P !== mine) { return; }
      reload(t('plug_approved', {name: p.name}), p.id);
    }, function (err) { failedAt(mine, form, b, pw, err, p.id); });
  }
  function enable(form, p) {
    var b = M.start(form);
    if (!b) { return; }
    var pw = UI.fieldNamed(form, 'current_password');
    if (!pw.value) { M.fieldError(form, pw, t('plug_need_password')); return; }
    var mine = P;
    UI.setBusy(b, true);
    FP.call('post', 'pluginEnable', {current_password: pw.value}, {id: p.id}).then(function () {
      if (P !== mine) { return; }
      reload(t('plug_enabled', {name: p.name}), p.id);
    }, function (err) { failedAt(mine, form, b, pw, err, p.id); });
  }
  /* a refusal is told where it was made; a plugin that changed under the admin (409) is read again */
  function failedAt(mine, form, b, pw, err, id) {
    UI.setBusy(b, false);
    if (P !== mine) { return; }
    pw.value = '';
    if (err && err.status === 403) { M.fieldError(form, pw, err.message); return; }
    M.failed(form, err);
    if (err && (err.status === 409 || err.status === 404)) { reload(err.message, id, null, true); }
  }
  function simple(btn, method, name, arg, said, id, focus) {
    var mine = P;
    btn.disabled = true;
    FP.call(method, name, undefined, arg).then(function () {
      if (P !== mine) { return; }
      reload(said, id, focus);
    }, function (err) {
      if (P !== mine) { return; }
      btn.disabled = false;
      var line = mine.page.querySelector('.fp-plug-list [data-fp-error]');
      UI.showError(mine.page.querySelector('.fp-plug-list'), err.message);
      if (line && line.scrollIntoView) { line.scrollIntoView({block: 'nearest'}); }
      if (err.status === 409 || err.status === 404) { reload(err.message, id, null, true); }
    });
  }

  function draw() {
    P.page.textContent = '';
    P.page.appendChild(listCard());
    P.page.appendChild(installCard());
    P.page.appendChild(keysCard());
    fillStatus(P);
  }
  /* read the lists again, then say what happened and put the focus where it belongs */
  function reload(said, id, focus, isError) {
    var mine = P;
    FP.call('get', 'plugins').then(function (r) {
      if (P !== mine) { return; }
      var l = cleanList(r);
      mine.plugins = l.plugins;
      mine.keys = l.keys;
      mine.ready = l.ready;
      draw();
      var at = mine.page.querySelector(focus || (id ? '#fp-plug-h-' + id : '#fp-plug-list-h'));
      if (at) { at.focus({preventScroll: false}); }
      if (said) {
        var scope = mine.page.querySelector(focus === '#fp-plug-keys-h' ? '.fp-plug-keys-card' : '.fp-plug-list');
        if (isError) { UI.showError(scope, said); } else { M.say(scope, said); }
      }
    }, function (err) {
      if (P !== mine) { return; }
      UI.showError(mine.page.querySelector('.fp-plug-list'), err.message);
    });
  }

  /* run the program: the call takes as long as the program does (at most about 25 seconds); a second press while it runs does nothing */
  function runNow(btn, p) {
    var box = btn.closest('[data-fp-run]');
    if (!box || box.getAttribute('data-fp-busy')) { return; }
    var mine = P;
    var stop = box.querySelector('[data-fp-act="run-stop"]');
    var status = box.querySelector('[data-fp-run-status]');
    box.setAttribute('data-fp-busy', 'yes');
    btn.setAttribute('aria-disabled', 'true');
    stop.hidden = false;
    UI.showError(box, '');
    box.querySelector('[data-fp-run-out]').textContent = '';
    status.textContent = t('plug_run_running');
    var done = function () { box.removeAttribute('data-fp-busy'); btn.removeAttribute('aria-disabled'); stop.hidden = true; };
    FP.call('post', 'pluginRun', {action: 'run'}, {id: p.id}).then(function (r) {
      if (P !== mine) { return; }
      done();
      var run = cleanRun(r);
      if (run) { showRun(box, p, run); } else { status.textContent = ''; UI.showError(box, t('api_failed')); }
    }, function (err) {
      if (P !== mine) { return; }
      done();
      status.textContent = '';
      if (err && err.status === 401) { FP.signedOut(true); return; }
      UI.showError(box, err && err.message ? err.message : t('api_failed'));
      if (err && err.status === 404) { reload(err.message, p.id, null, true); }
    });
  }
  function runStop(btn, p) {
    var box = btn.closest('[data-fp-run]');
    if (!box) { return; }
    var mine = P;
    FP.call('post', 'pluginRun', {action: 'stop'}, {id: p.id}).then(function () { return null; }, function (err) {
      if (P !== mine) { return; }
      if (err && err.status === 401) { FP.signedOut(true); return; }
      UI.showError(box, err && err.message ? err.message : t('api_failed'));
    });
  }
  function onClick(e) {
    var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !P || !P.page.contains(b)) { return; }
    var a = b.getAttribute('data-fp-act');
    var id = b.getAttribute('data-fp-id') || '';
    var p = P.plugins.filter(function (x) { return x.id === id; })[0];
    if (a === 'again') {
      start(true);
    } else if (a === 'run' && p) {
      runNow(b, p);
    } else if (a === 'run-stop' && p) {
      runStop(b, p);
    } else if (a === 'disable' && p) {
      simple(b, 'post', 'pluginDisable', {id: p.id}, t('plug_disabled', {name: p.name}), p.id);
    } else if (a === 'remove' && p) {
      var cell = b.parentNode;
      M.confirmIn(cell, t('plug_remove_ask', {name: p.name}), 'remove-yes', t('plug_remove'));
      cell.setAttribute('data-fp-asking', p.id);
    } else if (a === 'remove-yes') {
      var holder = b.closest('[data-fp-asking]');
      var rid = holder ? holder.getAttribute('data-fp-asking') : '';
      var rp = P.plugins.filter(function (x) { return x.id === rid; })[0];
      if (rp) { simple(b, 'del', 'plugin', {id: rp.id}, t('plug_removed', {name: rp.name}), ''); }
    } else if (a === 'key-remove') {
      var fp = b.getAttribute('data-fp-fp');
      var k = P.keys.filter(function (x) { return x.fingerprint === fp; })[0];
      if (k) {
        var kcell = b.parentNode;
        M.confirmIn(kcell, t('plug_key_remove_ask', {name: k.name}), 'key-remove-yes', t('plug_key_remove'));
        kcell.setAttribute('data-fp-asking', fp);
      }
    } else if (a === 'key-remove-yes') {
      var kh = b.closest('[data-fp-asking]');
      var kfp = kh ? kh.getAttribute('data-fp-asking') : '';
      if (FINGERPRINT_RE.test(kfp)) { simple(b, 'del', 'pluginKey', {fingerprint: kfp}, t('plug_key_removed'), '', '#fp-plug-keys-h'); }
    } else if (a === 'confirm-no') {
      var who = b.closest('[data-fp-asking]');
      var then = who ? who.getAttribute('data-fp-asking') : '';
      draw();
      var again = then ? P.page.querySelector('[data-fp-id="' + then + '"][data-fp-act="remove"], [data-fp-fp="' + then + '"]') : null;
      if (again) { again.focus(); }
    }
  }

  function start(again) {
    P = null;
    var tool = FP.tools.plugins;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('plug_desc'), cls: 'fp-mail fp-rpp fp-plug-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    var mine = P = {page: page, plugins: [], keys: [], ready: true};
    page.addEventListener('click', onClick);
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    if (again) { document.getElementById('fp-h1').focus(); }
    FP.call('get', 'plugins').then(function (r) {
      if (P !== mine) { return; }
      var l = cleanList(r);
      mine.plugins = l.plugins;
      mine.keys = l.keys;
      mine.ready = l.ready;
      draw();
    }, function (err) {
      if (P !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err.message, el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'again', text: t('plug_try_again')})));
    });
  }
  FP.view('tool:plugins', function () { start(false); });
})();

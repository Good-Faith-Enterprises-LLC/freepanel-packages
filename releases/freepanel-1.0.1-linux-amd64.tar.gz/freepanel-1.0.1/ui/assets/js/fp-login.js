/* freePanel sign-in: password, then the two-factor code (or a recovery code) when the login has it, and the
   forgotten-password request. The same page serves both panels; body[data-realm] says which one ("admin" or
   "user") and body[data-shell] where to go once signed in. */
(function () {
  'use strict';
  var UI = window.FPUI;
  var API = window.FPAPI;
  var body = document.body;
  var realm = body.getAttribute('data-realm') === 'admin' ? 'admin' : 'user';
  var shell = body.getAttribute('data-shell') || '/';
  var params = new URLSearchParams(window.location.search);
  var next = UI.safeNext(params.get('next'));
  var ticket = '';
  var ticketAt = 0;
  var ticketTries = 0;
  var TICKET_MS = 5 * 60 * 1000;   /* docs/api.md: a ticket lasts 5 minutes and allows 5 tries */
  var TICKET_TRIES = 5;
  var mfaMode = 'code';

  function $(sel, scope) { return (scope || document).querySelector(sel); }
  function step(name) { return document.getElementById('fp-step-' + name); }

  function show(name, focusHeading) {
    ['login', 'mfa', 'forgot', 'sent'].forEach(function (n) {
      var s = step(n);
      s.hidden = n !== name;
      if (n !== name) { UI.showError(s, ''); }
    });
    if (focusHeading) { $('h1', step(name)).focus(); }
  }

  function go() { window.location.replace(shell + next); }

  function invalid(input, message, scope) {
    input.setAttribute('aria-invalid', 'true');
    UI.showError(scope, message);
    input.focus();
  }
  function clearInvalid(form) {
    var inputs = form.querySelectorAll('[aria-invalid]');
    for (var i = 0; i < inputs.length; i++) { inputs[i].removeAttribute('aria-invalid'); }
  }

  /* ---- password ---- */
  function onLogin(form) {
    var scope = step('login');
    var user = $('#fp-username');
    var pass = $('#fp-password');
    clearInvalid(form);
    UI.showError(scope, '');
    if (!user.value.trim()) { invalid(user, UI.t('need_username'), scope); return; }
    if (!pass.value) { invalid(pass, UI.t('need_password'), scope); return; }
    var button = $('.fp-submit', form);
    UI.setBusy(button, true);
    API.post('login', {realm: realm, username: user.value.trim(), password: pass.value}).then(function (r) {
      if (r.status === 'two_factor_required' && typeof r.ticket === 'string' && r.ticket) {
        pass.value = '';
        UI.setBusy(button, false);
        beginMfa(r.ticket);
        return;
      }
      if (r.status === 'ok') { go(); return; }
      UI.setBusy(button, false);
      UI.showError(scope, UI.t('api_failed'));
    }, function (err) {
      UI.setBusy(button, false);
      if (err.code === 'unauthorized') {   /* a wrong realm looks the same as a wrong password */
        pass.value = '';
        invalid(pass, UI.t('bad_credentials'), scope);
        return;
      }
      UI.showError(scope, err.message);
    });
  }

  /* the step that asks for the code, after a password or after the provider */
  function beginMfa(value) {
    ticket = value;
    ticketAt = Date.now();
    ticketTries = 0;
    setMfaMode('code');
    show('mfa', false);
    $('#fp-code').focus();
  }

  /* ---- two-factor code ---- */
  function setMfaMode(mode) {
    mfaMode = mode;
    var scope = step('mfa');
    ['code', 'recovery'].forEach(function (m) {
      $('[data-fp-mfa-field="' + m + '"]', scope).hidden = m !== mode;
      $('[data-fp-mfa-desc="' + m + '"]', scope).hidden = m !== mode;
    });
    $('[data-fp-mfa-toggle]', scope).textContent = mode === 'code' ? 'Use a recovery code instead' : 'Use the code from your app';
    $('#fp-code').value = '';
    $('#fp-recovery').value = '';
    clearInvalid(scope);
    UI.showError(scope, '');
  }

  function onMfa(form) {
    var scope = step('mfa');
    var input = mfaMode === 'code' ? $('#fp-code') : $('#fp-recovery');
    var value = input.value.replace(/\s+/g, '');
    clearInvalid(form);
    UI.showError(scope, '');
    if (mfaMode === 'code' && !/^[0-9]{6}$/.test(value)) { invalid(input, UI.t('need_code'), scope); return; }
    if (mfaMode === 'recovery' && !value) { invalid(input, UI.t('need_recovery'), scope); return; }
    if (!ticket || Date.now() - ticketAt > TICKET_MS || ticketTries >= TICKET_TRIES) { expired(); return; }
    var button = $('.fp-submit', form);
    UI.setBusy(button, true);
    var payload = {ticket: ticket};
    payload[mfaMode === 'code' ? 'code' : 'recovery_code'] = value;
    ticketTries++;
    API.post('twoFactorLogin', payload).then(function (r) {
      if (r.status === 'ok') { go(); return; }
      UI.setBusy(button, false);
      UI.showError(scope, UI.t('api_failed'));
    }, function (err) {
      UI.setBusy(button, false);
      if (err.code === 'unauthorized' && ticketTries >= TICKET_TRIES) { expired(); return; }
      if (err.code === 'unauthorized') {
        input.value = '';
        invalid(input, mfaMode === 'recovery' ? UI.t('bad_recovery_code') : UI.t('bad_code'), scope);
        return;
      }
      UI.showError(scope, err.message);
    });
  }

  /* the ticket is used up or too old: start again from the password */
  function expired() {
    ticket = '';
    show('login', false);
    UI.showError(step('login'), UI.t('challenge_expired'));
    $('#fp-password').focus();
  }

  /* ---- forgotten password ---- */
  function onForgot(form) {
    var scope = step('forgot');
    var user = $('#fp-forgot-username');
    clearInvalid(form);
    UI.showError(scope, '');
    if (!user.value.trim()) { invalid(user, UI.t('need_username'), scope); return; }
    var button = $('.fp-submit', form);
    UI.setBusy(button, true);
    API.post('forgot', {realm: realm, username: user.value.trim()}).then(function () {
      UI.setBusy(button, false);
      show('sent', true);
    }, function (err) {
      UI.setBusy(button, false);
      UI.showError(scope, err.message);
    });
  }

  document.addEventListener('submit', function (e) {
    var form = e.target;
    var kind = form.getAttribute && form.getAttribute('data-fp-form');
    if (!kind) { return; }
    e.preventDefault();
    if ($('.fp-submit', form).disabled) { return; }
    if (kind === 'login') { onLogin(form); } else if (kind === 'mfa') { onMfa(form); } else if (kind === 'forgot') { onForgot(form); }
  });

  document.addEventListener('click', function (e) {
    var target = e.target.closest ? e.target : null;
    if (!target) { return; }
    var goto = target.closest('[data-fp-goto]');
    if (goto) {
      e.preventDefault();
      var name = goto.getAttribute('data-fp-goto');
      if (name === 'forgot') {
        var typed = $('#fp-username').value.trim();
        if (typed && !$('#fp-forgot-username').value) { $('#fp-forgot-username').value = typed; }
      }
      if (name === 'login') { ticket = ''; }
      show(name, true);
      return;
    }
    if (target.closest('[data-fp-mfa-toggle]')) {
      setMfaMode(mfaMode === 'code' ? 'recovery' : 'code');
      (mfaMode === 'code' ? $('#fp-code') : $('#fp-recovery')).focus();
    }
  });

  /* six digits typed or pasted: send without waiting for Enter */
  $('#fp-code').addEventListener('input', function () {
    var digits = this.value.replace(/[^0-9]/g, '').slice(0, 6);
    if (digits !== this.value) { this.value = digits; }
    var form = this.form;
    if (digits.length === 6 && !$('.fp-submit', form).disabled) { onMfa(form); }
  });

  /* ---- single sign-on through the provider (docs/api.md, "Single sign-on") ---- */
  function showNote(text) {
    var n = $('[data-fp-note]');
    n.textContent = text;
    n.hidden = false;
  }
  /* the button, when the panel offers the provider; the name is the admin's, shown as text */
  function ssoOffer() {
    API.get('ssoOffer').then(function (r) {
      if (!r || r.enabled !== true) { return; }
      var name = typeof r.name === 'string' && r.name ? r.name.slice(0, 60) : 'single sign-on';
      $('[data-fp-sso-start]').textContent = UI.t('oidc_button', {name: name});
      $('[data-fp-sso]').hidden = false;
    }, function () { /* no button */ });
  }
  /* the provider sent the browser back with a token in the address's fragment: take it up once, and take it off the address */
  function ssoToken() {
    var m = /^#oidc=([A-Za-z0-9_-]{20,200})$/.exec(window.location.hash);
    if (!m) { return false; }
    window.history.replaceState(null, '', window.location.pathname + window.location.search);
    showNote(UI.t('oidc_signing_in'));
    API.post('ssoExchange', {token: m[1]}).then(function (r) {
      if (r.status === 'two_factor_required' && typeof r.ticket === 'string' && r.ticket) { $('[data-fp-note]').hidden = true; beginMfa(r.ticket); return; }
      if (r.status === 'ok') { go(); return; }
      $('[data-fp-note]').hidden = true;
      UI.showError(step('login'), UI.t('api_failed'));
    }, function (err) {
      $('[data-fp-note]').hidden = true;
      if (err.code === 'unauthorized') { UI.showError(step('login'), UI.t('oidc_expired')); return; }
      UI.showError(step('login'), err.message);
    });
    return true;
  }
  var OIDC_ERRORS = ['denied', 'expired', 'not_linked', 'refused', 'failed', 'busy', 'off', 'taken'];
  function ssoError() {
    var m = /[?&]oidc_error=([a-z_]+)/.exec(window.location.search);
    if (!m) { return; }
    window.history.replaceState(null, '', window.location.pathname + window.location.hash);
    if (OIDC_ERRORS.indexOf(m[1]) >= 0) { UI.showError(step('login'), UI.t('oidc_' + m[1])); }
  }

  /* ---- first paint ---- */
  UI.loadBrand();
  var note = $('[data-fp-note]');
  if (params.get('signed_out') === '1') { note.textContent = UI.t('signed_out'); note.hidden = false; }
  if (params.get('expired') === '1') { note.textContent = UI.t('session_expired'); note.hidden = false; }
  ssoOffer();
  ssoError();
  if (window.location.hash === '#forgot') { show('forgot', false); $('#fp-forgot-username').focus(); } else { $('#fp-username').focus(); }
  ssoToken();
  /* already signed in to this panel: straight through */
  UI.toServedPanel(realm, 'login').then(function (leaving) {
    if (leaving) { return; }
    API.get('session').then(function (s) { if (UI.realmOf(s) === realm) { go(); } }, function () { /* sign in as usual */ });
  });
})();

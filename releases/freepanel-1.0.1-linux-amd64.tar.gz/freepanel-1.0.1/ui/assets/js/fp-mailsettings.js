/* freePanel mail server settings (#/tool/mail_settings), the admin panel's page for the limits the mail server keeps
   (docs/api.md, "ServerMailSettings"): the largest message, the most recipients one message may name and the days a
   message waits in the queue. Nothing changes until an admin saves, and a value left empty is the mail server's own.
   The page shows what Postfix really runs, read back from it, beside what was saved. The spam settings page shares the
   saving (FP.mailset.save): a save replaces every choice, so each page sends the others as the server holds them now.
   A second card holds the one switch that is not a limit: whether customers may make this server a backup mail server for
   a domain (allow_backup_mx), which is off until an administrator turns it on, asked about first, and saved with the
   limits sent back as they are. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  /* the choices and the least and most of each (the server's own bounds are used when it sends them) */
  var FIELDS = [
    {name: 'max_message_mb', id: 'fp-mss-mb', bounds: [1, 200], key: 'mb'},
    {name: 'max_recipients', id: 'fp-mss-rcpt', bounds: [1, 1000], key: 'rcpt'},
    {name: 'queue_days', id: 'fp-mss-days', bounds: [1, 30], key: 'days'}
  ];
  var HOURLY = 'max_hourly_recipients';
  var HOURLY_BOUNDS = [1, 100000];
  /* whether accounts may choose backup mail routing: the backup card's switch; a save from any page sends it back as it is */
  var BACKUP = 'allow_backup_mx';

  var V = null;

  function whole(v) { return typeof v === 'number' && isFinite(v) && v >= 0 && Math.floor(v) === v ? v : 0; }
  function amount(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? v : null; }
  function pair(v, d) {
    return Array.isArray(v) && v.length === 2 && whole(v[0]) >= 1 && whole(v[1]) >= whole(v[0]) && v[0] === whole(v[0]) && v[1] === whole(v[1]) ? v : d;
  }

  /* what the server says, kept to the shapes the pages draw */
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var s = r.settings && typeof r.settings === 'object' ? r.settings : {};
    var e = r.effective && typeof r.effective === 'object' ? r.effective : null;
    var b = r.bounds && typeof r.bounds === 'object' ? r.bounds : {};
    var p = r.postfix && typeof r.postfix === 'object' ? r.postfix : {};
    var out = {installed: p.installed !== false, active: p.active !== false, settings: {}, effective: null, bounds: {},
      hourly: typeof s[HOURLY] === 'number' ? whole(s[HOURLY]) : null, hourlyBounds: pair(b[HOURLY], HOURLY_BOUNDS),
      backup: typeof s[BACKUP] === 'boolean' ? s[BACKUP] : null,
      warning: typeof r.warning === 'string' ? r.warning.slice(0, 400) : ''};
    FIELDS.forEach(function (f) {
      out.settings[f.name] = whole(s[f.name]);
      out.bounds[f.name] = pair(b[f.name], f.bounds);
    });
    if (e) {
      out.effective = {};
      FIELDS.forEach(function (f) { out.effective[f.name] = amount(e[f.name]); });
    }
    return out;
  }

  /* A save replaces every choice. The choices this page does not own are read fresh just before and sent back as they
     are (the hourly limit too, whenever the server has one: a save without it would clear it; and the switch for backup
     routing, which a save without it would turn off). */
  function save(patch) {
    return FP.call('get', 'mailServerSettings').then(function (r) {
      var cur = clean(r);
      var body = {};
      FIELDS.forEach(function (f) { body[f.name] = cur.settings[f.name]; });
      if (cur.hourly !== null) { body[HOURLY] = cur.hourly; }
      if (cur.backup !== null) { body[BACKUP] = cur.backup; }
      Object.keys(patch).forEach(function (k) {
        if (k !== HOURLY || cur.hourly !== null) { body[k] = patch[k]; }
      });
      return FP.call('put', 'mailServerSettings', body);
    });
  }
  FP.mailset = {clean: clean, save: save, HOURLY: HOURLY, HOURLY_BOUNDS: HOURLY_BOUNDS};

  /* ---------- what the mail server runs ---------- */
  function figure(f, n) {
    if (f.key === 'mb') { return t('mss_mb', {n: String(Math.round(n * 10) / 10)}); }
    if (f.key === 'days') { return t(n === 1 ? 'mss_day' : 'mss_days', {n: n.toLocaleString('en')}); }
    return n.toLocaleString('en');
  }
  function runsCard() {
    var e = V.effective;
    var rows = FIELDS.map(function (f) {
      var shown = e && e[f.name] !== null ? figure(f, e[f.name]) + ' ' + t(V.settings[f.name] ? 'mss_chosen' : 'mss_own') : t('mss_unknown');
      return [t('mss_f_' + f.key), shown, f.key];
    });
    var parts = [];
    if (!V.installed) {
      parts.push(el('p', {class: 'fp-warn-line', 'data-fp-nopostfix': '', text: t('mss_nopostfix')}));
    } else if (!V.active) {
      parts.push(el('p', {class: 'fp-warn-line', 'data-fp-inactive': '', text: t('mss_inactive')}));
    }
    if (V.warning) { parts.push(el('p', {class: 'fp-warn-line', 'data-fp-warning': '', text: t('mss_warning', {why: V.warning})})); }
    parts.push(el('dl', {class: 'fp-mail-facts fp-mss-facts'}, rows.reduce(function (out, r) {
      return out.concat([el('dt', {text: r[0]}), el('dd', {'data-fp-fact': r[2], text: r[1]})]);
    }, [])));
    /* a value that was saved and is not what Postfix runs is shown, not hidden */
    FIELDS.forEach(function (f) {
      var want = V.settings[f.name];
      var got = e ? e[f.name] : null;
      if (want && got !== null && got !== want) {
        parts.push(el('p', {class: 'fp-warn-line', 'data-fp-differs': f.name, text: t('mss_differs', {field: t('mss_f_' + f.key), saved: figure(f, want), runs: figure(f, got)})}));
      }
    });
    return M.card('fp-mss-runs-h', t('mss_runs_title'), parts, 'fp-mss-runs');
  }
  function drawRuns() {
    var old = V.page.querySelector('.fp-mss-runs');
    var fresh = runsCard();
    if (old) { old.replaceWith(fresh); } else { V.page.insertBefore(fresh, V.page.firstChild); }
  }

  /* ---------- the choices ---------- */
  function formCard() {
    var form = el('form', {class: 'fp-form fp-mail-form fp-mss-form', novalidate: '', 'data-fp-form': 'settings'}, [M.errorLine(), M.statusLine()]);
    FIELDS.forEach(function (f) {
      var b = V.bounds[f.name];
      var value = V.settings[f.name];
      form.appendChild(M.field(f.id, t('mss_l_' + f.key), el('input', {class: 'sig-input fp-num-input', id: f.id, name: f.name, type: 'number', inputmode: 'numeric',
        min: String(b[0]), max: String(b[1]), step: '1', value: value ? String(value) : ''}), t('mss_h_' + f.key, {min: b[0].toLocaleString('en'), max: b[1].toLocaleString('en')})));
    });
    form.appendChild(el('p', {class: 'fp-muted', 'data-fp-webmail': '', text: t('mss_webmail')}));
    form.appendChild(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('mss_save')})]));
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      submit(form);
    });
    return M.card('fp-mss-form-h', t('mss_form_title'), [el('p', {class: 'fp-muted', text: t('mss_form_desc')}), form], 'fp-mss-choices');
  }
  /* ---------- backup mail servers: whether customers may choose backup routing for their domains ---------- */
  function backupCard() {
    var known = V.backup !== null;
    var on = el('input', {type: 'checkbox', id: 'fp-mss-backup', name: 'allow_backup_mx', 'aria-describedby': 'fp-mss-backup-hint'});
    on.checked = V.backup === true;
    if (!known) { on.disabled = true; }
    var ask = el('div', {class: 'fp-mss-ask'});
    var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('mss_bk_save')});
    var state = !known ? t('mss_bk_unknown') : t(V.backup ? 'mss_bk_is_on' : 'mss_bk_is_off');
    var form = el('form', {class: 'fp-form fp-mail-form fp-mss-backup-form', novalidate: '', 'data-fp-form': 'backup'}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-mss-bk-state', 'data-fp-bk-state': ''}, [el('span', {class: 'sig-pill' + (V.backup ? ' sig-pill--ok' : ''), text: t(V.backup ? 'mss_bk_on' : 'mss_bk_off')}),
        el('span', {class: 'fp-mss-bk-text', text: state})]),
      el('div', {class: 'fp-mss-bk-switch'}, [el('label', {class: 'fp-check', for: 'fp-mss-backup'}, [on, el('span', {text: t('mss_bk_switch')})]),
        el('span', {class: 'sig-hint', id: 'fp-mss-backup-hint', text: t('mss_bk_hint')})]),
      ask, el('div', {class: 'fp-actions'}, [save])]);
    on.addEventListener('change', function () { ask.textContent = ''; });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      if (on.checked === (V.backup === true)) { M.say(form, t('mss_bk_nothing')); return; }
      /* turning it on lets customers use this server to hold other servers' mail: asked first */
      if (on.checked) {
        if (!ask.firstChild) { M.confirmIn(ask, t('mss_bk_ask'), 'mss-bk-yes', t('mss_bk_ask_yes')); }
        return;
      }
      backupSave(form, b, false);
    });
    form.addEventListener('click', function (e) {
      var a = e.target.closest ? e.target.closest('[data-fp-act]') : null;
      if (!a) { return; }
      if (a.getAttribute('data-fp-act') === 'confirm-no') {
        ask.textContent = '';
        save.focus();
      } else if (a.getAttribute('data-fp-act') === 'mss-bk-yes') {
        ask.textContent = '';
        backupSave(form, save, true);
      }
    });
    return M.card('fp-mss-bk-h', t('mss_bk_title'), [el('p', {class: 'fp-muted', text: t('mss_bk_what')}), el('p', {class: 'fp-muted', text: t('mss_bk_cost')}), form], 'fp-mss-backup');
  }
  /* the switch is saved with the limits sent back as the server holds them; a save that fails changes nothing, and the page says so */
  function backupSave(form, b, value) {
    var mine = V;
    UI.setBusy(b, true);
    save({allow_backup_mx: value}).then(function (r) {
      UI.setBusy(b, false);
      if (V !== mine) { return; }
      var kept = clean(r);
      mine.backup = kept.backup;
      mine.settings = kept.settings;
      mine.effective = kept.effective;
      mine.bounds = kept.bounds;
      mine.warning = kept.warning;
      var old = V.page.querySelector('.fp-mss-backup');
      var fresh = backupCard();
      old.replaceWith(fresh);
      drawRuns();
      M.say(fresh, t(kept.backup ? 'mss_bk_saved_on' : 'mss_bk_saved_off'));
      fresh.querySelector('#fp-mss-bk-h').focus();
    }, function (err) {
      UI.setBusy(b, false);
      if (V !== mine) { return; }
      var unsure = !err || err.status === 0 || err.status >= 500;
      M.failed(form, unsure ? {field: err && err.field, message: (err && err.message ? err.message : t('api_failed')) + ' ' + t('mss_bk_nothing_changed')} : err);
    });
  }

  /* the form's values as the server takes them (empty is 0, not chosen); null, with the field marked, when one is plainly wrong */
  function read(form) {
    var body = {};
    for (var i = 0; i < FIELDS.length; i++) {
      var f = FIELDS[i];
      var b = V.bounds[f.name];
      var raw = form.querySelector('[name="' + f.name + '"]').value.trim();
      var n = raw === '' ? 0 : (/^[0-9]{1,6}$/.test(raw) ? parseInt(raw, 10) : -1);
      if (n < 0 || (n !== 0 && (n < b[0] || n > b[1]))) {
        M.fieldError(form, UI.fieldNamed(form, f.name), t('mss_bad', {field: t('mss_l_' + f.key), min: b[0].toLocaleString('en'), max: b[1].toLocaleString('en')}));
        return null;
      }
      body[f.name] = n;
    }
    return body;
  }
  function submit(form) {
    var b = M.start(form);
    if (!b) { return; }
    var body = read(form);
    if (!body) { return; }
    var mine = V;
    UI.setBusy(b, true);
    save(body).then(function (r) {
      UI.setBusy(b, false);
      if (V !== mine) { return; }
      var kept = clean(r);
      mine.settings = kept.settings;
      mine.effective = kept.effective;
      mine.bounds = kept.bounds;
      mine.installed = kept.installed;
      mine.active = kept.active;
      mine.warning = kept.warning;
      mine.backup = kept.backup;
      FIELDS.forEach(function (f) { form.querySelector('[name="' + f.name + '"]').value = kept.settings[f.name] ? String(kept.settings[f.name]) : ''; });
      drawRuns();
      var chosen = FIELDS.some(function (f) { return kept.settings[f.name]; });
      M.say(form, t(chosen ? 'mss_saved' : 'mss_saved_own'));
    }, function (err) {
      UI.setBusy(b, false);
      if (V !== mine) { return; }
      M.failed(form, err);
    });
  }

  FP.view('tool:mail_settings', function () {
    var tool = FP.tools.mail_settings;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('mss_desc'), cls: 'fp-mail fp-mss',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    var mine = V = clean(null);
    mine.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'mailServerSettings').then(function (r) {
      if (V !== mine) { return; }
      var kept = clean(r);
      kept.page = body;
      V = kept;
      body.textContent = '';
      body.appendChild(runsCard());
      body.appendChild(formCard());
      body.appendChild(backupCard());
    }, function (err) {
      if (V !== mine) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

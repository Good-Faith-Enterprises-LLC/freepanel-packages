/* freePanel web application firewall (docs/api.md, "PHP settings" and Apache, the firewall). The admin's page (#/tool/web_firewall_admin)
   installs the firewall from the system's own packages (a job it follows to its end), turns it on, chooses whether it only logs or also
   refuses, sets the request body limit, turns single rules off for the whole server, shows what it caught, and exempts or sets rules off
   for one site. The customer's page (#/tool/web_firewall) has one switch per site. What the server sends is cleaned to the shapes drawn
   here and shown as text: a request's address, address bar and what matched can hold whatever a visitor sent. Page pieces come from
   FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var JOB_STATES = ['idle', 'running', 'succeeded', 'failed'];
  var POLL_MS = 3000;
  var RULES_PAGE = 50;
  var SITES_PAGE = 50;
  var HITS_LIMIT = 100;
  var MAX_ID = 99999999;
  var DOMAIN_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var ADDR_RE = /^[0-9a-fA-F:.]{2,45}$/;
  var USER_RE = /^[A-Za-z0-9_.@-]{1,60}$/;
  var SEV_RE = /^[A-Za-z]{3,12}$/;
  var FILE_RE = /^[A-Za-z0-9_.-]{1,80}$/;
  var METHOD_RE = /^[A-Z]{3,10}$/;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 400) : ''; }
  function whole(v) { return typeof v === 'number' && isFinite(v) && v >= 0 && v === Math.floor(v) ? v : 0; }
  function ruleId(v) { return typeof v === 'number' && v === Math.floor(v) && v >= 1 && v <= MAX_ID ? v : 0; }
  function when(iso) {
    var d = iso ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString(undefined, {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }
  function size(n) {
    if (n < 1024) { return t('wf_size_b', {n: n}); }
    return n < 1048576 ? t('wf_size_kb', {n: (n / 1024).toFixed(1)}) : t('wf_size_mb', {n: (n / 1048576).toFixed(1)});
  }
  function pill(text, kind) { return el('span', {class: 'sig-pill' + (kind ? ' sig-pill--' + kind : ''), text: text}); }
  function severity(s) { return s ? pill(s, /^(CRITICAL|ERROR|EMERGENCY|ALERT)$/i.test(s) ? 'danger' : '') : null; }

  /* ---- what the server sends, cleaned ---- */
  function cleanStatus(r) {
    r = r && typeof r === 'object' ? r : {};
    var mb = whole(r.request_body_mb);
    return {installed: r.installed === true, installable: r.installable === true, enabled: r.enabled === true, mode: r.mode === 'block' ? 'block' : 'detect',
      body: mb >= 1 && mb <= 128 ? mb : 13, version: str(r.version, 60), rules: whole(r.rules), disabled: whole(r.disabled), sites: whole(r.sites), bytes: whole(r.hit_bytes),
      reason: str(r.reason), warning: str(r.warning)};
  }
  function cleanJob(r) {
    r = r && typeof r === 'object' ? r : {};
    return {state: JOB_STATES.indexOf(r.state) >= 0 ? r.state : 'idle', ended: str(r.ended, 40),
      code: typeof r.exit_code === 'number' && isFinite(r.exit_code) ? Math.round(r.exit_code) : null, timedOut: r.timed_out === true,
      log: (Array.isArray(r.log) ? r.log : []).filter(function (l) { return typeof l === 'string'; }).slice(-200).map(function (l) { return l.slice(0, 400); }),
      truncated: r.log_truncated === true};
  }
  function cleanRules(r) {
    r = r && typeof r === 'object' ? r : {};
    var list = (Array.isArray(r.rules) ? r.rules : []).map(function (x) {
      if (!x || typeof x !== 'object' || !ruleId(x.id)) { return null; }
      return {id: x.id, message: str(x.message, 300), severity: SEV_RE.test(str(x.severity)) ? x.severity : '', file: FILE_RE.test(str(x.file)) ? x.file : '',
        tags: (Array.isArray(x.tags) ? x.tags : []).filter(function (g) { return typeof g === 'string' && g; }).slice(0, 8).map(function (g) { return g.slice(0, 60); }),
        off: x.disabled === true, note: str(x.note, 200)};
    }).filter(Boolean);
    return {list: list, total: Math.max(whole(r.total), list.length), files: (Array.isArray(r.files) ? r.files : []).filter(function (f) { return FILE_RE.test(str(f)); }).slice(0, 100),
      stale: (Array.isArray(r.stale) ? r.stale : []).map(function (x) { return x && ruleId(x.id) ? {id: x.id, note: str(x.note, 200)} : null; }).filter(Boolean).slice(0, 100)};
  }
  function cleanHits(r) {
    r = r && typeof r === 'object' ? r : {};
    var list = (Array.isArray(r.hits) ? r.hits : []).map(function (h) {
      if (!h || typeof h !== 'object' || !ADDR_RE.test(str(h.address))) { return null; }
      return {time: when(h.time), address: h.address, host: str(h.host, 253), method: METHOD_RE.test(str(h.method)) ? h.method : '', uri: str(h.uri, 400), blocked: h.blocked === true,
        rules: (Array.isArray(h.rules) ? h.rules : []).slice(0, 20).map(function (x) {
          return x && typeof x === 'object' ? {id: whole(x.id), message: str(x.message, 300), severity: SEV_RE.test(str(x.severity)) ? x.severity : '', data: str(x.data, 200)} : null;
        }).filter(Boolean)};
    }).filter(Boolean);
    return {list: list, total: list.length, bytes: whole(r.bytes), truncated: r.truncated === true};
  }
  function cleanSite(x) {
    if (!x || typeof x !== 'object' || !DOMAIN_RE.test(str(x.domain)) || !USER_RE.test(str(x.account))) { return null; }
    return {domain: x.domain, account: x.account, exempt: x.exempt === true, off: x.off === true,
      rules: (Array.isArray(x.rules) ? x.rules : []).map(ruleId).filter(Boolean).slice(0, 100)};
  }
  function cleanSites(r) {
    r = r && typeof r === 'object' ? r : {};
    var list = (Array.isArray(r.sites) ? r.sites : []).map(cleanSite).filter(Boolean);
    return {list: list, total: Math.max(whole(r.total), list.length)};
  }

  var W = null;

  /* ================= the admin's page ================= */
  function stateLine(s) {
    var parts = [t('wf_state_rules', {version: s.version || t('wf_state_set'), n: s.rules, off: s.disabled})];
    if (s.sites) { parts.push(t(s.sites === 1 ? 'wf_state_sites_1' : 'wf_state_sites', {n: s.sites})); }
    parts.push(t('wf_state_log', {size: size(s.bytes)}));
    return parts.join(' ');
  }
  function drawState() {
    var p = W.page.querySelector('[data-fp-wf-state]');
    if (p && W.status.installed) { p.textContent = stateLine(W.status); }
  }
  /* the numbers on the page follow a change made on it */
  function refreshState() {
    var mine = W;
    return FP.call('get', 'webWaf').then(function (r) { if (W === mine) { W.status = cleanStatus(r); drawState(); } }, function () { /* the numbers stay as they were */ });
  }
  function choice(id, name, value, current, label, hint) {
    return el('div', {class: 'fp-acct-choice'}, [el('label', {class: 'fp-check', for: id}, [
      el('input', {type: 'radio', id: id, name: name, value: value, checked: value === current ? true : null, 'aria-describedby': id + '-hint'}), el('span', {text: label})]),
    el('span', {class: 'sig-hint', id: id + '-hint', text: hint})]);
  }
  function settingsForm() {
    var s = W.status;
    var on = el('input', {type: 'checkbox', id: 'fp-wf-on', name: 'enabled', checked: s.enabled ? true : null, 'aria-describedby': 'fp-wf-on-hint'});
    var body = el('input', {class: 'sig-input fp-num-input', id: 'fp-wf-body', name: 'request_body_mb', type: 'number', inputmode: 'numeric', min: '1', max: '128', step: '1', autocomplete: 'off', value: String(s.body)});
    var form = el('form', {class: 'fp-form fp-mail-form fp-wf-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('div', null, [el('label', {class: 'fp-check', for: 'fp-wf-on'}, [on, el('span', {text: t('wf_on')})]), el('span', {class: 'sig-hint', id: 'fp-wf-on-hint', text: t('wf_on_hint')})]),
      el('fieldset', {class: 'fp-acct-kinds'}, [el('legend', {class: 'sig-label', text: t('wf_mode')}),
        choice('fp-wf-mode-detect', 'mode', 'detect', s.mode, t('wf_mode_detect'), t('wf_mode_detect_hint')),
        choice('fp-wf-mode-block', 'mode', 'block', s.mode, t('wf_mode_block'), t('wf_mode_block_hint'))]),
      M.field('fp-wf-body', t('wf_body'), body, t('wf_body_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('wf_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var mb = body.value.trim();
      if (!/^[0-9]{1,3}$/.test(mb) || Number(mb) < 1 || Number(mb) > 128) { M.fieldError(form, body, t('wf_body_bad')); return; }
      var mode = form.querySelector('[name="mode"]:checked').value;
      var change = {};
      if (on.checked !== s.enabled) { change.enabled = on.checked; }
      if (mode !== s.mode) { change.mode = mode; }
      if (Number(mb) !== s.body) { change.request_body_mb = Number(mb); }
      if (!Object.keys(change).length) { M.say(form, t('wf_nothing')); return; }
      var mine = W;
      UI.setBusy(b, true);
      FP.call('put', 'webWaf', change).then(function (r) {
        if (W !== mine) { return; }
        W.status = cleanStatus(r);
        redrawSettings();
        M.say(W.page.querySelector('.fp-wf-set'), t(!W.status.enabled ? 'wf_saved_off' : (W.status.mode === 'block' ? 'wf_saved_block' : 'wf_saved_detect')));
      }, function (err) {
        if (W !== mine) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return form;
  }
  function settingsCard() {
    var s = W.status;
    var parts = [el('p', {class: 'fp-muted', text: t('wf_what')}), s.installed ? null : M.errorLine(), s.installed ? null : M.statusLine()].filter(Boolean);
    if (s.warning) { parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-wf-warning': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: s.warning})])); }
    if (s.installed) {
      parts.push(el('p', {'data-fp-wf-state': '', text: stateLine(s)}), settingsForm());
    } else if (s.installable) {
      parts.push(el('p', {'data-fp-wf-state': '', text: t('wf_not_installed')}), el('p', {class: 'fp-muted', text: t('wf_install_what')}),
        el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'install', disabled: running() ? true : null, text: t('wf_install')})]));
    } else {
      parts.push(el('p', {'data-fp-wf-state': '', text: t('wf_not_installed')}), el('p', {class: 'fp-warn-line', 'data-fp-wf-reason': '', text: s.reason || t('wf_cannot_install')}));
    }
    return M.card('fp-wf-set-h', t('wf_title'), parts, 'fp-wf-set');
  }
  function redrawSettings(focus) {
    var old = W.page.querySelector('.fp-wf-set');
    var fresh = settingsCard();
    if (old) { old.replaceWith(fresh); } else { W.page.insertBefore(fresh, W.page.firstChild); }
    var target = focus ? fresh.querySelector(focus) : null;
    if (target) { target.focus(); }
  }

  /* ---- the install, followed until it ends ---- */
  function running() { return Boolean(W.job && W.job.state === 'running'); }
  function jobCard() {
    var j = W.job;
    if (!j || j.state === 'idle') { return null; }
    var parts = [];
    if (j.state === 'running') {
      parts.push(el('p', {class: 'fp-wf-now', 'data-fp-job-state': 'running', text: t('wf_job_running')}), el('p', {class: 'fp-muted', text: t('wf_job_running_hint')}));
    } else if (j.state === 'succeeded') {
      parts.push(el('p', {class: 'fp-wf-now', 'data-fp-job-state': 'succeeded', text: t('wf_job_done')}),
        el('p', {class: 'fp-muted', text: t('wf_job_done_hint') + (j.ended ? ' ' + t('wf_job_ended', {when: when(j.ended)}) : '')}));
    } else {
      var why = j.timedOut ? t('wf_job_timed_out') : (j.code === null ? t('wf_job_cut_off') : t('wf_job_code', {code: String(j.code)}));
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-job-state': 'failed'}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('wf_job_failed') + ' ' + why})]));
      if (j.ended) { parts.push(el('p', {class: 'fp-muted', text: t('wf_job_ended', {when: when(j.ended)})})); }
    }
    if (j.log.length) {
      parts.push(el('pre', {class: 'fp-wf-log sig-mono', tabindex: '0', 'data-fp-job-log': '', 'aria-label': t('wf_job_log'), text: j.log.join('\n')}));
      if (j.truncated) { parts.push(el('p', {class: 'fp-muted', text: t('wf_job_truncated')})); }
    }
    return M.card('fp-wf-job-h', t('wf_job_title'), parts, 'fp-wf-job');
  }
  function drawJob() {
    var old = W.page.querySelector('.fp-wf-job');
    var fresh = jobCard();
    var active = document.activeElement;
    var inLog = Boolean(old && active && active.hasAttribute && active.hasAttribute('data-fp-job-log') && old.contains(active));
    if (!fresh) { if (old) { old.remove(); } return; }
    if (old) { old.replaceWith(fresh); } else { W.page.querySelector('.fp-wf-set').after(fresh); }
    var log = fresh.querySelector('[data-fp-job-log]');
    if (log && running()) { log.scrollTop = log.scrollHeight; }
    if (inLog && log) { log.focus(); }
  }
  function follow() {
    window.clearTimeout(W.timer);
    var mine = W;
    W.timer = window.setTimeout(function () {
      if (W !== mine || !document.body.contains(mine.page)) { return; }
      FP.call('get', 'webWafInstall').then(function (r) {
        if (W !== mine) { return; }
        W.job = cleanJob(r);
        if (running()) { drawJob(); follow(); return; }
        ended(mine);
      }, function () { if (W === mine) { follow(); } });
    }, POLL_MS);
  }
  /* the install has ended: the firewall is read again (it is installed now), and the page says how it ended */
  function ended(mine) {
    var j = W.job;
    var done = function () {
      if (W !== mine) { return; }
      redrawSettings();
      drawJob();
      if (W.status.installed) { loadAll(); }
      UI.announce(t(j.state === 'succeeded' ? 'wf_job_done' : 'wf_job_failed'));
    };
    FP.call('get', 'webWaf').then(function (r) { if (W === mine) { W.status = cleanStatus(r); } done(); }, done);
  }
  function install(b) {
    var mine = W;
    var card = W.page.querySelector('.fp-wf-set');
    UI.showError(card, '');
    M.say(card, '');
    UI.setBusy(b, true);
    FP.call('post', 'webWafInstall').then(function (r) {
      if (W !== mine) { return; }
      W.job = cleanJob(r);
      redrawSettings();
      drawJob();
      M.say(W.page.querySelector('.fp-wf-set'), t('wf_install_started'));
      var h = W.page.querySelector('#fp-wf-job-h');
      if (h) { h.focus(); }
      if (running()) { follow(); }
    }, function (err) {
      if (W !== mine) { return; }
      UI.setBusy(b, false);
      UI.showError(card, err.message);
      b.focus();
    });
  }

  /* ---- a list read a page at a time, with a filter: the rules, the hits and the sites ---- */
  function makeList(spec) {
    var L = {key: spec.key, q: spec.q0(), offsets: [0], page: spec.clean(null), out: null, filter: null};
    L.offset = function () { return L.offsets[L.offsets.length - 1]; };
    L.card = function () {
      L.out = el('div', {'data-fp-wf-list': spec.key}, [M.errorLine(), M.statusLine(), el('div', {class: 'fp-wf-body'}, [el('p', {class: 'fp-muted', text: t('loading')})])]);
      var form = spec.form(L);
      L.filter = form;
      var parts = [el('p', {class: 'fp-muted', text: spec.what}), form, L.out];
      return M.card(spec.id + '-h', spec.title, parts, spec.cls);
    };
    L.draw = function () {
      var body = L.out.querySelector('.fp-wf-body');
      body.textContent = '';
      spec.draw(L).forEach(function (n) { if (n) { body.appendChild(n); } });
      if (spec.size) {
        var more = L.offset() + L.page.list.length < L.page.total;
        if (L.offsets.length > 1 || more) {
          body.appendChild(el('div', {class: 'fp-actions'}, [
            el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'prev', disabled: L.offsets.length > 1 ? null : true, text: t('wf_prev')}),
            el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'next', disabled: more ? null : true, text: t('wf_next')})]));
        }
      }
    };
    L.load = function (offset, form, button) {
      var mine = W;
      if (button) { UI.setBusy(button, true); }
      return FP.call('get', spec.path, undefined, spec.args(L.q, offset)).then(function (r) {
        if (W !== mine) { return false; }
        L.page = spec.clean(r);
        L.draw();
        if (spec.onLoad) { spec.onLoad(L); }
        if (button) { UI.setBusy(button, false); }
        return true;
      }, function (err) {
        if (W !== mine) { return false; }
        if (button) { UI.setBusy(button, false); }
        if (form) { M.failed(form, err); } else { UI.showError(L.out, err.message); }
        if (!L.page.list.length) { L.draw(); }
        return false;
      });
    };
    /* the filter form's submit: its fields are read by spec.read, which answers a message when one is wrong */
    L.submit = function (form, read) {
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var b = M.start(form);
        if (!b) { return; }
        var got = read();
        if (got.error) { M.fieldError(form, got.field, got.error); return; }
        L.q = got.q;
        L.offsets = [0];
        L.editing = '';
        UI.showError(L.out, '');
        M.say(L.out, '');
        L.load(0, form, b);
      });
    };
    return L;
  }
  function filterShell(id, fields, show) {
    return el('form', {class: 'fp-form fp-mail-form fp-wf-filter', novalidate: ''}, [M.errorLine(), el('div', {class: 'fp-wf-filter-row'}, fields),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary fp-submit', type: 'submit', text: show})])]);
  }
  function text(id, name, value, max) {
    return el('input', {class: 'sig-input', id: id, name: name, type: 'text', maxlength: String(max), autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', value: value});
  }
  function select(id, name, value, options) {
    return el('select', {class: 'sig-select', id: id, name: name}, options.map(function (o) { return el('option', {value: o[0], text: o[1], selected: o[0] === value ? true : null}); }));
  }
  function head(cols) {
    return el('thead', null, [el('tr', null, cols.map(function (c) {
      return c.vh ? el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: c.text})]) : el('th', {scope: 'col', text: c.text});
    }))]);
  }
  function wrap(label, cls, cols, rows) {
    return el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': label}, [
      el('table', {class: 'sig-table fp-mail-table fp-wf-table ' + cls}, [head(cols), el('tbody', null, rows)])]);
  }

  /* ---- the rules ---- */
  var rulesList = null;
  function ruleRow(r) {
    var meta = [r.severity ? severity(r.severity) : null, r.file ? el('span', {class: 'fp-muted fp-row-note', text: r.file}) : null,
      r.tags.length ? el('span', {class: 'fp-muted fp-row-note', text: r.tags.join(', ')}) : null];
    var acts = el('td', {class: 'fp-mail-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': r.off ? 'rule-on' : 'rule-off',
      'aria-label': t(r.off ? 'wf_rule_on_named' : 'wf_rule_off_named', {id: r.id}), text: t(r.off ? 'wf_rule_on' : 'wf_rule_off')})]);
    return el('tr', {'data-fp-rule': String(r.id)}, [
      el('th', {scope: 'row', class: 'fp-wf-rule'}, [el('span', {class: 'sig-mono', text: String(r.id)}), el('span', {class: 'fp-wf-msg', text: r.message}), el('span', {class: 'fp-wf-meta'}, meta)]),
      el('td', null, [pill(t(r.off ? 'wf_rule_is_off' : 'wf_rule_is_on'), r.off ? 'accent' : ''), r.note ? el('span', {class: 'fp-row-note', text: t('wf_note_is', {note: r.note})}) : null]), acts]);
  }
  function rulesDraw(L) {
    var p = L.page;
    var parts = [el('p', {class: 'fp-muted', 'data-fp-summary': '', text: p.list.length ? t('wf_showing', {from: L.offset() + 1, to: L.offset() + p.list.length, total: p.total}) : t('wf_rules_none')})];
    if (p.list.length) { parts.push(wrap('fp-wf-rules-h', 'fp-wf-rules-table', [{text: t('wf_col_rule')}, {text: t('wf_col_state')}, {text: t('mail_actions'), vh: true}], p.list.map(ruleRow))); }
    if (p.stale.length) {
      parts.push(el('div', {class: 'fp-wf-stale', 'data-fp-stale': ''}, [el('h3', {class: 'fp-h3', text: t('wf_stale_title')}), el('p', {class: 'fp-muted', text: t('wf_stale_what')}),
        el('ul', {class: 'fp-wf-stale-list'}, p.stale.map(function (s) {
          return el('li', {'data-fp-stale-rule': String(s.id)}, [el('span', {class: 'sig-mono', text: String(s.id)}), el('span', {class: 'fp-muted fp-row-note', text: s.note}),
            el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'rule-on', 'aria-label': t('wf_rule_on_named', {id: s.id}), text: t('wf_rule_on')})]);
        }))]));
    }
    return parts;
  }
  function rulesFiles(L) {
    var sel = L.filter && L.filter.querySelector('#fp-wf-rfile');
    if (!sel) { return; }
    var keep = sel.value;
    sel.textContent = '';
    [['', t('wf_any')]].concat(L.page.files.map(function (f) { return [f, f]; })).forEach(function (o) { sel.appendChild(el('option', {value: o[0], text: o[1], selected: o[0] === keep ? true : null})); });
  }
  function makeRules() {
    return makeList({key: 'rules', id: 'fp-wf-rules', title: t('wf_rules_title'), what: t('wf_rules_what'), cls: 'fp-wf-rules', path: 'webWafRules', size: RULES_PAGE,
      q0: function () { return {q: '', file: '', state: ''}; }, clean: cleanRules, draw: rulesDraw, onLoad: rulesFiles,
      args: function (q, offset) { return {limit: String(RULES_PAGE), offset: String(offset), q: q.q, file: q.file, disabled: q.state === 'off' ? 'true' : (q.state === 'on' ? 'false' : '')}; },
      form: function (L) {
        var q = text('fp-wf-rq', 'q', L.q.q, 60);
        var file = select('fp-wf-rfile', 'file', L.q.file, [['', t('wf_any')]]);
        var state = select('fp-wf-rstate', 'state', L.q.state, [['', t('wf_any')], ['on', t('wf_rule_is_on')], ['off', t('wf_rule_is_off')]]);
        var form = filterShell('fp-wf-rules', [M.field('fp-wf-rq', t('wf_f_search'), q, t('wf_f_search_hint')), M.field('fp-wf-rfile', t('wf_f_file'), file), M.field('fp-wf-rstate', t('wf_f_state'), state)], t('wf_show'));
        L.submit(form, function () { return {q: {q: q.value.trim(), file: file.value, state: state.value}}; });
        return form;
      }});
  }
  function ruleSet(L, id, disabled, note, button) {
    var mine = W;
    UI.setBusy(button, true);
    var body = {disabled: disabled};
    if (note) { body.note = note; }
    return FP.call('put', 'webWafRule', body, {id: String(id)}).then(function () {
      if (W !== mine) { return; }
      M.say(L.out, t(disabled ? 'wf_rule_turned_off' : 'wf_rule_turned_on', {id: id}));
      L.load(L.offset(), null, null).then(function () { if (W === mine) { refreshState(); } });
    }, function (err) {
      if (W !== mine) { return; }
      L.draw();
      UI.showError(L.out, err.message);
      var again = L.out.querySelector('tr[data-fp-rule="' + id + '"] .sig-btn');
      if (again) { again.focus(); }
    });
  }
  function askNote(L, tr, id) {
    var cell = tr.querySelector('.fp-mail-acts');
    cell.textContent = '';
    var note = el('input', {class: 'sig-input', type: 'text', name: 'note', maxlength: '200', autocomplete: 'off', 'aria-label': t('wf_note_label', {id: id}), placeholder: t('wf_note_ph')});
    var yes = el('button', {class: 'sig-btn sig-btn--danger sig-btn--sm', type: 'button', 'data-fp-act': 'rule-off-yes', text: t('wf_rule_off')});
    var no = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'rule-off-no', text: t('cancel')});
    var ask = el('span', {class: 'fp-mail-confirm', id: 'fp-wf-ask-' + id, text: t('wf_rule_off_ask', {id: id})});
    cell.appendChild(ask);
    cell.appendChild(note);
    cell.appendChild(yes);
    cell.appendChild(no);
    note.setAttribute('aria-describedby', ask.id);
    note.focus();
  }

  /* ---- what it caught ---- */
  var hitsList = null;
  function hitRow(h) {
    var rules = el('ul', {class: 'fp-wf-hit-rules'}, h.rules.map(function (r) {
      return el('li', null, [el('span', {class: 'sig-mono', text: String(r.id)}), el('span', {class: 'fp-wf-hit-msg', text: ' ' + r.message}), r.severity ? severity(r.severity) : null,
        r.data ? el('span', {class: 'fp-muted fp-row-note fp-wf-data', text: r.data}) : null]);
    }));
    return el('tr', {'data-fp-hit': ''}, [
      el('th', {scope: 'row', class: 'fp-wf-when', text: h.time}),
      el('td', {class: 'fp-wf-req'}, [el('span', {class: 'sig-mono fp-wf-uri', text: (h.method ? h.method + ' ' : '') + h.uri}),
        el('span', {class: 'fp-muted fp-row-note', text: t('wf_hit_from', {host: h.host || '—', address: h.address})})]),
      el('td', null, [pill(t(h.blocked ? 'wf_hit_refused' : 'wf_hit_logged'), h.blocked ? 'danger' : '')]), el('td', null, [rules])]);
  }
  function hitsDraw(L) {
    var p = L.page;
    var parts = [el('p', {class: 'fp-muted', 'data-fp-summary': '', text: p.list.length ? t(p.list.length === 1 ? 'wf_hits_1' : 'wf_hits', {n: p.list.length, size: size(p.bytes)}) : t('wf_hits_none', {size: size(p.bytes)})})];
    if (p.list.length) { parts.push(wrap('fp-wf-hits-h', 'fp-wf-hits-table', [{text: t('wf_col_when')}, {text: t('wf_col_request')}, {text: t('wf_col_outcome')}, {text: t('wf_col_matched')}], p.list.map(hitRow))); }
    if (p.list.length >= HITS_LIMIT) { parts.push(el('p', {class: 'fp-muted', 'data-fp-hits-cap': '', text: t('wf_hits_cap', {n: HITS_LIMIT})})); }
    if (p.truncated) { parts.push(el('p', {class: 'fp-muted', 'data-fp-truncated': '', text: t('wf_hits_truncated')})); }
    if (p.bytes) {
      parts.push(el('div', {class: 'fp-actions fp-wf-clear'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'hits-clear', text: t('wf_hits_clear')})]));
    }
    return parts;
  }
  function makeHits() {
    return makeList({key: 'hits', id: 'fp-wf-hits', title: t('wf_hits_title'), what: t('wf_hits_what'), cls: 'fp-wf-hits', path: 'webWafHits', size: 0,
      q0: function () { return {domain: '', ip: '', rule: '', outcome: ''}; }, clean: cleanHits, draw: hitsDraw,
      args: function (q) { return {limit: String(HITS_LIMIT), domain: q.domain, ip: q.ip, rule: q.rule, blocked: q.outcome === 'refused' ? 'true' : (q.outcome === 'logged' ? 'false' : '')}; },
      form: function (L) {
        var domain = text('fp-wf-hdomain', 'domain', L.q.domain, 253);
        var ip = text('fp-wf-hip', 'ip', L.q.ip, 45);
        var rule = text('fp-wf-hrule', 'rule', L.q.rule, 8);
        var out = select('fp-wf-hout', 'blocked', L.q.outcome, [['', t('wf_any')], ['refused', t('wf_hit_refused')], ['logged', t('wf_hit_logged')]]);
        var form = filterShell('fp-wf-hits', [M.field('fp-wf-hdomain', t('wf_f_site'), domain, t('wf_f_site_hint')), M.field('fp-wf-hip', t('wf_f_address'), ip),
          M.field('fp-wf-hrule', t('wf_f_rule'), rule), M.field('fp-wf-hout', t('wf_f_outcome'), out)], t('wf_show'));
        L.submit(form, function () {
          var d = domain.value.trim().toLowerCase();
          var a = ip.value.trim();
          var r = rule.value.trim();
          if (d && !DOMAIN_RE.test(d)) { return {error: t('wf_site_bad'), field: domain}; }
          if (a && !ADDR_RE.test(a)) { return {error: t('wf_address_bad'), field: ip}; }
          if (r && !/^[0-9]{1,8}$/.test(r)) { return {error: t('wf_rule_bad'), field: rule}; }
          return {q: {domain: d, ip: a, rule: r, outcome: out.value}};
        });
        return form;
      }});
  }

  /* ---- the sites ---- */
  var sitesList = null;
  function siteState(s) { return s.exempt ? t('wf_site_exempt') : (s.off ? t('wf_site_off') : t('wf_site_on')); }
  function siteRow(L, s) {
    var rows = [el('tr', {'data-fp-site': s.domain}, [
      el('th', {scope: 'row', class: 'fp-mail-name'}, [el('span', {text: s.domain}), el('span', {class: 'fp-muted fp-row-note', text: t('wf_site_of', {account: s.account})})]),
      el('td', null, [pill(siteState(s), s.exempt ? 'accent' : (s.off ? '' : 'ok'))]),
      el('td', {class: 'fp-wf-site-rules', text: s.rules.length ? s.rules.join(', ') : '—'}),
      el('td', {class: 'fp-mail-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'site-edit', 'aria-expanded': L.editing === s.domain ? 'true' : 'false',
        'aria-label': t('wf_site_change_named', {domain: s.domain}), text: t('wf_site_change')})])])];
    if (L.editing === s.domain) { rows.push(el('tr', {class: 'fp-wf-edit', 'data-fp-site-edit': s.domain}, [el('td', {colspan: '4'}, [siteForm(L, s)])])); }
    return rows;
  }
  function parseIds(v) {
    var out = [];
    var bad = '';
    v.split(/[\s,;]+/).filter(Boolean).forEach(function (w) {
      if (!/^[0-9]{1,8}$/.test(w) || Number(w) < 1) { bad = bad || w; } else if (out.indexOf(Number(w)) < 0) { out.push(Number(w)); }
    });
    return {ids: out, bad: bad};
  }
  function siteForm(L, s) {
    var exempt = el('input', {type: 'checkbox', id: 'fp-wf-sexempt', name: 'exempt', checked: s.exempt ? true : null, 'aria-describedby': 'fp-wf-sexempt-hint'});
    var rules = el('textarea', {class: 'sig-input', id: 'fp-wf-srules', name: 'rules', rows: '3', spellcheck: 'false', autocomplete: 'off'});
    rules.value = s.rules.join(' ');
    var form = el('form', {class: 'fp-form fp-mail-form fp-wf-site-form', novalidate: ''}, [M.errorLine(),
      el('div', null, [el('label', {class: 'fp-check', for: 'fp-wf-sexempt'}, [exempt, el('span', {text: t('wf_site_f_exempt', {domain: s.domain})})]), el('span', {class: 'sig-hint', id: 'fp-wf-sexempt-hint', text: t('wf_site_f_exempt_hint')})]),
      M.field('fp-wf-srules', t('wf_site_f_rules'), rules, t('wf_site_f_rules_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('wf_save')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'site-close', text: t('cancel')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var got = parseIds(rules.value);
      if (got.bad) { M.fieldError(form, rules, t('wf_site_rules_bad', {id: got.bad})); return; }
      if (got.ids.length > 100) { M.fieldError(form, rules, t('wf_site_rules_many')); return; }
      var mine = W;
      UI.setBusy(b, true);
      FP.call('put', 'webWafSite', {exempt: exempt.checked, rules: got.ids}, {domain: s.domain}).then(function (r) {
        if (W !== mine) { return; }
        var fresh = cleanSite(r) || s;
        L.page.list = L.page.list.map(function (x) { return x.domain === s.domain ? fresh : x; });
        L.editing = '';
        L.draw();
        M.say(L.out, t('wf_site_saved', {domain: s.domain}));
        var btn = L.out.querySelector('tr[data-fp-site="' + s.domain + '"] [data-fp-act="site-edit"]');
        if (btn) { btn.focus(); }
        refreshState();
      }, function (err) {
        if (W !== mine) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return form;
  }
  function sitesDraw(L) {
    var p = L.page;
    var parts = [el('p', {class: 'fp-muted', 'data-fp-summary': '', text: p.list.length ? t('wf_showing_sites', {from: L.offset() + 1, to: L.offset() + p.list.length, total: p.total}) : t('wf_sites_none')})];
    if (p.list.length) {
      var rows = [];
      p.list.forEach(function (s) { siteRow(L, s).forEach(function (r) { rows.push(r); }); });
      parts.push(wrap('fp-wf-sites-h', 'fp-wf-sites-table', [{text: t('wf_col_site')}, {text: t('wf_col_firewall')}, {text: t('wf_col_site_rules')}, {text: t('mail_actions'), vh: true}], rows));
    }
    return parts;
  }
  function makeSites() {
    return makeList({key: 'sites', id: 'fp-wf-sites', title: t('wf_sites_title'), what: t('wf_sites_what'), cls: 'fp-wf-sites', path: 'webWafSites', size: SITES_PAGE,
      q0: function () { return {q: ''}; }, clean: cleanSites, draw: sitesDraw,
      args: function (q, offset) { return {limit: String(SITES_PAGE), offset: String(offset), q: q.q}; },
      form: function (L) {
        L.editing = '';
        var q = text('fp-wf-sq', 'q', L.q.q, 120);
        var form = filterShell('fp-wf-sites', [M.field('fp-wf-sq', t('wf_f_search_site'), q, t('wf_f_search_site_hint'))], t('wf_show'));
        L.submit(form, function () { return {q: {q: q.value.trim()}}; });
        return form;
      }});
  }

  /* ---- the whole admin page ---- */
  function loadAll() {
    var mine = W;
    ['rules', 'hits', 'sites'].forEach(function (k) {
      var old = W.page.querySelector('[data-fp-wf-card="' + k + '"]');
      if (old) { old.remove(); }
    });
    rulesList = makeRules();
    hitsList = makeHits();
    sitesList = makeSites();
    W.lists = {rules: rulesList, hits: hitsList, sites: sitesList};
    [rulesList, hitsList, sitesList].forEach(function (L) {
      var c = L.card();
      c.setAttribute('data-fp-wf-card', L.key);
      W.page.appendChild(c);
      L.load(0, null, null);
    });
    return mine;
  }
  function onClick(e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !W || !W.page.contains(b) || b.disabled) { return; }
    var act = b.getAttribute('data-fp-act');
    var box = b.closest('[data-fp-wf-list]');
    var L = box && W.lists ? W.lists[box.getAttribute('data-fp-wf-list')] : null;
    var tr = b.closest('tr[data-fp-rule]');
    var id = tr ? tr.getAttribute('data-fp-rule') : (b.closest('[data-fp-stale-rule]') ? b.closest('[data-fp-stale-rule]').getAttribute('data-fp-stale-rule') : '');
    if (act === 'install') {
      install(b);
    } else if (!L) {
      return;
    } else if (act === 'next') {
      L.offsets.push(L.offset() + L.page.list.length);
      L.editing = '';
      L.load(L.offset(), null, null);
    } else if (act === 'prev' && L.offsets.length > 1) {
      L.offsets.pop();
      L.editing = '';
      L.load(L.offset(), null, null);
    } else if (act === 'rule-off' && tr) {
      askNote(L, tr, id);
    } else if (act === 'rule-off-no') {
      L.draw();
      var back = L.out.querySelector('tr[data-fp-rule="' + id + '"] .sig-btn');
      if (back) { back.focus(); }
    } else if (act === 'rule-off-yes' && tr) {
      ruleSet(L, id, true, tr.querySelector('[name="note"]').value.trim(), b);
    } else if (act === 'rule-on') {
      ruleSet(L, id, false, '', b);
    } else if (act === 'site-edit') {
      var domain = b.closest('tr[data-fp-site]').getAttribute('data-fp-site');
      L.editing = L.editing === domain ? '' : domain;
      L.draw();
      var f = L.out.querySelector('#fp-wf-sexempt');
      if (f) { f.focus(); } else { var again = L.out.querySelector('tr[data-fp-site="' + domain + '"] [data-fp-act="site-edit"]'); if (again) { again.focus(); } }
    } else if (act === 'site-close') {
      var d = L.editing;
      L.editing = '';
      L.draw();
      var opener = L.out.querySelector('tr[data-fp-site="' + d + '"] [data-fp-act="site-edit"]');
      if (opener) { opener.focus(); }
    } else if (act === 'hits-clear') {
      M.confirmIn(b.parentNode, t('wf_hits_clear_ask'), 'hits-clear-yes', t('wf_hits_clear'));
    } else if (act === 'confirm-no') {
      L.draw();
      var clear = L.out.querySelector('[data-fp-act="hits-clear"]');
      if (clear) { clear.focus(); }
    } else if (act === 'hits-clear-yes') {
      var mine = W;
      UI.setBusy(b, true);
      FP.call('del', 'webWafHitsClear').then(function () {
        if (W !== mine) { return; }
        L.load(0, null, null).then(function () { if (W === mine) { M.say(L.out, t('wf_hits_cleared')); refreshState(); } });
      }, function (err) {
        if (W !== mine) { return; }
        L.draw();
        UI.showError(L.out, err.message);
      });
    }
  }
  document.addEventListener('click', onClick);

  FP.view('tool:web_firewall_admin', function () {
    window.clearTimeout(W && W.timer);
    W = null;
    var tool = FP.tools.web_firewall_admin;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('wf_desc'), cls: 'fp-mail fp-wf',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    W = {page: page, status: cleanStatus(null), job: null, timer: 0, lists: null};
    var mine = W;
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all([FP.call('get', 'webWaf'), FP.call('get', 'webWafInstall').then(function (j) { return cleanJob(j); }, function () { return null; })]).then(function (r) {
      if (W !== mine) { return; }
      W.status = cleanStatus(r[0]);
      W.job = r[1];
      page.textContent = '';
      page.appendChild(settingsCard());
      var j = jobCard();
      if (j) { page.appendChild(j); }
      if (running()) { follow(); }
      if (W.status.installed) { loadAll(); }
    }, function (err) {
      if (W !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err.message));
    });
  });

  /* ================= the customer's page ================= */
  var C = null;
  function cleanCustomer(r) {
    r = r && typeof r === 'object' ? r : {};
    return {available: r.available === true, suspended: r.suspended === true,
      sites: (Array.isArray(r.sites) ? r.sites : []).filter(function (s) { return s && typeof s === 'object' && DOMAIN_RE.test(str(s.domain)); })
        .map(function (s) { return {domain: s.domain, on: s.enabled === true, locked: s.locked === true}; })};
  }
  function customerRow(s, frozen) {
    var action;
    if (s.locked) {
      action = el('span', {class: 'fp-muted fp-row-note', text: t('wfc_locked')});
    } else {
      action = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': s.on ? 'off' : 'on', disabled: frozen ? true : null,
        'aria-label': t(s.on ? 'wfc_off_named' : 'wfc_on_named', {domain: s.domain}), text: t(s.on ? 'wfc_off' : 'wfc_on')});
    }
    return el('tr', {'data-fp-site': s.domain}, [el('th', {scope: 'row', class: 'fp-mail-name', text: s.domain}),
      el('td', null, [pill(t(s.on ? 'wfc_is_on' : 'wfc_is_off'), s.on ? 'ok' : '')]), el('td', {class: 'fp-mail-acts'}, [action])]);
  }
  function customerCard() {
    var d = C.data;
    var frozen = !d.available || d.suspended;
    var parts = [el('p', {class: 'fp-muted', text: t('wfc_what')}), M.errorLine(), M.statusLine()];
    if (d.suspended) { parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-wfc-note': 'suspended'}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('wfc_suspended')})])); }
    else if (!d.available) { parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-wfc-note': 'off'}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('wfc_unavailable')})])); }
    if (!d.sites.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('wfc_none')}));
    } else {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-wfc-h'}, [el('table', {class: 'sig-table fp-mail-table fp-wfc-table'}, [
        head([{text: t('wfc_col_site')}, {text: t('wfc_col_state')}, {text: t('mail_actions'), vh: true}]), el('tbody', null, d.sites.map(function (s) { return customerRow(s, frozen); }))])]));
      parts.push(el('p', {class: 'fp-muted fp-wfc-note', text: t('wfc_note')}));
    }
    return M.card('fp-wfc-h', t('wfc_title'), parts, 'fp-wfc');
  }
  function onCustomerClick(e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !C || !C.page.contains(b) || b.disabled) { return; }
    var act = b.getAttribute('data-fp-act');
    if (act !== 'on' && act !== 'off') { return; }
    var domain = b.closest('tr[data-fp-site]').getAttribute('data-fp-site');
    var mine = C;
    var card = C.page.querySelector('.fp-wfc');
    UI.showError(card, '');
    M.say(card, '');
    UI.setBusy(b, true);
    FP.call('put', 'acctWafSite', {enabled: act === 'on'}, {name: C.account, domain: domain}).then(function (r) {
      if (C !== mine) { return; }
      /* the answer is the account's whole view, as the page was read: the switches, and whether the firewall is on and the account free */
      var fresh = cleanCustomer(r);
      if (fresh.sites.length) { C.data = fresh; }
      var old = C.page.querySelector('.fp-wfc');
      var next = customerCard();
      old.replaceWith(next);
      M.say(next, t(act === 'on' ? 'wfc_turned_on' : 'wfc_turned_off', {domain: domain}));
      var again = next.querySelector('tr[data-fp-site="' + domain + '"] .sig-btn');
      if (again) { again.focus(); }
    }, function (err) {
      if (C !== mine) { return; }
      UI.setBusy(b, false);
      UI.showError(card, err.message);
      b.focus();
    });
  }
  document.addEventListener('click', onCustomerClick);

  FP.view('tool:web_firewall', function () {
    C = null;
    var page = M.frame('web_firewall', 'fp-wfc-page');
    if (!page) { return; }
    C = {page: page, account: FP.account(), data: null};
    var mine = C;
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'acctWaf', undefined, C.account).then(function (r) {
      if (C !== mine) { return; }
      C.data = cleanCustomer(r);
      page.textContent = '';
      page.appendChild(customerCard());
    }, function (err) {
      if (C !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(FP.tools.web_firewall.label, err.message));
    });
  });
})();

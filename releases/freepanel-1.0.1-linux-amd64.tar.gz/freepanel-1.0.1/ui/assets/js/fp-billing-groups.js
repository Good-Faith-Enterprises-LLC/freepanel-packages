/* freePanel billing client lists of the Clients group (docs/api.md, "Billing: customers"; docs/billing/navigation-map.md, "Clients"):
   Client groups (#/tool/billing_groups), the named sets a client can be in, one at most, and Custom client fields (#/tool/billing_fields),
   the values every client can have, such as a tax number. Each is a table with a form to add or change a row; a removal is asked first on
   its row. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;

  var GROUP = {id: 'id', name: [60], description: [200], customers: 'n'};
  function simple(toolId, cls, make) {
    FP.view('tool:' + toolId, function () {
      var page = B.frame(toolId, cls);
      if (!page) { return; }
      page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
      make(page, function () { return page.isConnected; }).show();
    });
  }
  function crudStrings(pre) {
    return {none: t(pre + '_none'), addTitle: t(pre + '_add_title'), addSave: t(pre + '_add'), editTitle: function (n) { return t('bil_change_title', {name: n}); },
      added: function (n) { return t('bil_added', {name: n}); }, saved: function (n) { return t('bil_saved', {name: n}); }, removed: function (n) { return t('bil_removed', {name: n}); },
      removeAsk: function (n) { return t(pre + '_remove_ask', {name: n}); }, removeYes: t(pre + '_remove_yes'), formWhat: t(pre + '_form_what')};
  }

  /* ---- client groups ---- */
  simple('billing_groups', 'fp-bgp', function (page, alive) {
    return B.crud({page: page, pre: 'fp-bgp', title: t('bgp_title'), alive: alive,
      what: function () { return [el('p', {class: 'fp-muted', text: t('bgp_what')})]; },
      load: function () { return FP.call('get', 'billingGroups').then(function (r) { return B.pickAll(r && r.groups, GROUP, 'id'); }); },
      heads: [B.th(t('bgp_col_name')), B.th(t('bgp_col_desc')), B.th(t('bgp_col_clients'), 'fp-bil-num')],
      cells: function (g) {
        return [el('th', {scope: 'row', class: 'fp-bil-wrap', text: g.name}), el('td', {class: 'fp-bil-wrap', text: g.description || '—'}),
          el('td', {class: 'fp-bil-num', text: g.customers === null ? '—' : B.num(g.customers)})];
      },
      fields: [{name: 'name', label: t('bgp_col_name'), required: true, max: 60, hint: t('bgp_name_hint')},
        {name: 'description', label: t('bgp_col_desc'), max: 200, hint: t('bgp_desc_hint'), send_empty: false}],
      add: 'billingGroups', item: 'billingGroup', nameOf: function (g) { return g.name; },
      strings: crudStrings('bgp')});
  });

  /* ---- custom client fields: a field's kind is chosen once; a choice field's choices are typed one per line ---- */
  var KINDS = ['text', 'choice', 'yes_no'];
  function cleanField(x) {
    var v = B.pick(x, {id: 'id', name: [60], kind: ['=', KINDS], required: 'b', in_use: 'n'});
    if (!v || !v.id || !v.kind) { return null; }
    v.list = (Array.isArray(x.choices) ? x.choices : []).filter(function (c) { return typeof c === 'string'; }).slice(0, 20).map(function (c) { return c.slice(0, 60); });
    v.choices = v.list.join('\n');
    return v;
  }
  simple('billing_fields', 'fp-bcf', function (page, alive) {
    return B.crud({page: page, pre: 'fp-bcf', title: t('bcf_title'), alive: alive,
      what: function () { return [el('p', {class: 'fp-muted', text: t('bcf_what')})]; },
      load: function () { return FP.call('get', 'billingFields').then(function (r) { return (r && Array.isArray(r.fields) ? r.fields : []).map(cleanField).filter(Boolean); }); },
      heads: [B.th(t('bcf_col_name')), B.th(t('bcf_col_kind')), B.th(t('bcf_col_choices')), B.th(t('bcf_col_required')), B.th(t('bcf_col_in_use'), 'fp-bil-num')],
      cells: function (f) {
        return [el('th', {scope: 'row', class: 'fp-bil-wrap', text: f.name}), el('td', {text: t('bcf_kind_' + f.kind)}), el('td', {class: 'fp-bil-wrap', text: f.list.length ? f.list.join(', ') : '—'}),
          el('td', {text: t(f.required ? 'bil_yes' : 'bil_no')}), el('td', {class: 'fp-bil-num', text: f.in_use === null ? '—' : B.num(f.in_use)})];
      },
      fieldsFor: function (x) {
        var name = {name: 'name', label: t('bcf_col_name'), required: true, max: 60, hint: t('bcf_name_hint')};
        var choices = {name: 'choices', label: t('bcf_col_choices'), kind: 'textarea', rows: 4, max: 1300, hint: t(x ? 'bcf_choices_keep_hint' : 'bcf_choices_hint')};
        var required = {name: 'required', label: t('bcf_required'), kind: 'check', hint: t('bcf_required_hint')};
        if (x) { return x.kind === 'choice' ? [name, choices, required] : [name, required]; }
        return [name, {name: 'kind', label: t('bcf_col_kind'), kind: 'select', options: KINDS.map(function (k) { return [k, t('bcf_kind_' + k)]; }), hint: t('bcf_kind_hint')}, choices, required];
      },
      /* the choices as the API takes them: a list, one entry per line typed; a field that is not a choice sends none */
      check: function (body, x) {
        var kind = x ? x.kind : body.kind;
        if (body.choices === undefined) { return false; }
        if (kind !== 'choice') { delete body.choices; return false; }
        body.choices = body.choices.split('\n').map(function (c) { return c.trim(); }).filter(Boolean);
        return false;
      },
      add: 'billingFields', item: 'billingField', nameOf: function (f) { return f.name; }, clean: cleanField,
      strings: crudStrings('bcf')});
  });
})();

/* freePanel certificates bought from the host's vendor (docs/api.md, "Certificates from a vendor"): the customer's page (#/tool/ssl_buy).
   It lists the products the host offers, orders one for a site of the account (the server makes the key and the request; the key
   never leaves it), and follows each order: the proof the vendor asks for (a file or a DNS record the panel puts in place, or an
   email), its status, the end date and when a new one is due. An order can be checked now, reissued with a new key, or cancelled.
   What the server sends is cleaned to the shapes drawn here and shown as text. Page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var ORDER_ID = /^co-[0-9a-f]{12}$/;
  var NAME_RE = /^(\*\.)?([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var LEVELS = ['dv', 'ov', 'ev'];
  var KINDS = ['single', 'wildcard', 'multi'];
  var METHODS = ['http', 'dns_cname', 'dns_txt', 'email'];
  var STATUSES = ['placing', 'unclear', 'pending', 'issued', 'installing', 'installed', 'cancelled', 'rejected', 'failed', 'expired'];
  var PILL = {placing: '', unclear: 'warn', pending: 'accent', issued: 'accent', installing: 'accent', installed: 'ok', cancelled: '', rejected: 'danger', failed: 'danger', expired: 'warn'};

  function str(v, max) { return typeof v === 'string' ? v.slice(0, max || 400) : ''; }
  function int(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.floor(v) : 0; }
  function when(v) {
    if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}T/.test(v)) { return ''; }
    var d = new Date(v);
    return isNaN(d.getTime()) ? '' : d.toLocaleDateString('en', {dateStyle: 'medium'});
  }
  function cleanProduct(p) {
    if (!p || typeof p !== 'object' || !str(p.id, 80) || !str(p.name, 120)) { return null; }
    var months = (Array.isArray(p.months) ? p.months : []).filter(function (m) { return int(m) >= 1 && int(m) <= 120; }).map(int);
    var methods = (Array.isArray(p.methods) ? p.methods : []).filter(function (m) { return METHODS.indexOf(m) >= 0; });
    return {id: str(p.id, 80), name: str(p.name, 120), brand: str(p.brand, 60), level: LEVELS.indexOf(p.level) >= 0 ? p.level : 'dv',
      kind: KINDS.indexOf(p.kind) >= 0 ? p.kind : 'single', maxNames: Math.max(1, int(p.max_names)), months: months.length ? months : [12], methods: methods};
  }
  function cleanValidation(v) {
    if (!v || typeof v !== 'object' || METHODS.indexOf(v.method) < 0) { return null; }
    return {name: str(v.name, 260), method: v.method, filePath: str(v.file_path, 300), fileContent: str(v.file_content, 4096),
      recordName: str(v.record_name, 300), recordType: str(v.record_type, 10), recordValue: str(v.record_value, 600), email: str(v.email, 254),
      done: v.done === true, placed: v.placed === true};
  }
  function cleanOrder(o) {
    if (!o || typeof o !== 'object' || !ORDER_ID.test(str(o.id)) || STATUSES.indexOf(o.status) < 0) { return null; }
    return {id: o.id, domain: str(o.domain, 260), names: (Array.isArray(o.names) ? o.names : []).filter(function (n) { return NAME_RE.test(str(n)); }),
      vendorName: str(o.vendor_name, 60), vendorOrder: str(o.vendor_order_id, 60), product: str(o.product_name, 120), level: LEVELS.indexOf(o.level) >= 0 ? o.level : '',
      months: int(o.months), method: METHODS.indexOf(o.method) >= 0 ? o.method : '', status: o.status, message: str(o.message, 600),
      validations: (Array.isArray(o.validations) ? o.validations : []).map(cleanValidation).filter(Boolean),
      notAfter: when(o.not_after), renewDue: o.renew_due === true, expired: o.expired === true, canCancel: o.can_cancel === true,
      canReissue: o.can_reissue === true, created: when(o.created)};
  }
  function cleanOffer(r) {
    return {vendor: str(r && r.vendor, 40), vendorName: str(r && r.vendor_name, 60),
      products: (r && Array.isArray(r.products) ? r.products : []).map(cleanProduct).filter(Boolean)};
  }
  function sitesOf(r) {
    var out = [];
    (r && Array.isArray(r.sites) ? r.sites : []).forEach(function (s) {
      if (s && NAME_RE.test(str(s.domain)) && out.indexOf(s.domain) < 0) { out.push(s.domain); }
    });
    return out;
  }
  FP.co = {cleanOrder: cleanOrder, cleanProduct: cleanProduct};

  var S = null;
  function productOf(id) { return S.offer.products.filter(function (p) { return p.id === id; })[0]; }
  function orderOf(id) { return S.orders.filter(function (o) { return o.id === id; })[0]; }
  function pill(kind, text) { return el('span', {class: 'sig-pill' + (kind ? ' sig-pill--' + kind : ''), text: text}); }
  function productLabel(p) { return t('cvd_product_line', {name: p.name, level: t('cvd_level_' + p.level), kind: t('cvd_kind_' + p.kind)}); }

  /* ================= the order form ================= */
  function orderCard() {
    if (!S.offer.vendor) {
      return M.card('fp-co-new-h', t('cvd_new_title'), [el('p', {class: 'fp-muted', 'data-fp-empty': 'offer', text: t('cvd_not_offered')})], 'fp-co-new');
    }
    if (!S.offer.products.length || !S.sites.length) {
      return M.card('fp-co-new-h', t('cvd_new_title'), [el('p', {class: 'fp-muted', 'data-fp-empty': 'offer',
        text: S.offer.products.length ? t('cvd_no_sites') : t('cvd_no_products')})], 'fp-co-new');
    }
    var site = el('select', {class: 'sig-select', id: 'fp-co-domain', name: 'domain'}, S.sites.map(function (d) { return el('option', {value: d, text: d}); }));
    var product = el('select', {class: 'sig-select', id: 'fp-co-product', name: 'product'}, S.offer.products.map(function (p) {
      return el('option', {value: p.id, text: productLabel(p)});
    }));
    var term = el('select', {class: 'sig-select', id: 'fp-co-months', name: 'months'});
    var methods = el('div', {class: 'fp-co-methods', role: 'radiogroup', 'aria-labelledby': 'fp-co-method-l', id: 'fp-co-method'});
    var names = el('textarea', {class: 'sig-input sig-mono', id: 'fp-co-names', name: 'names', rows: '2', spellcheck: 'false', autocomplete: 'off', autocapitalize: 'none'});
    var namesField = M.field('fp-co-names', t('cvd_names'), names, t('cvd_names_hint'));
    var approver = el('select', {class: 'sig-select', id: 'fp-co-approver', name: 'approver_email'});
    var approverField = M.field('fp-co-approver', t('cvd_approver'), approver, t('cvd_approver_hint'));
    var contact = [['first_name', 'cvd_c_first', 64], ['last_name', 'cvd_c_last', 64], ['email', 'cvd_c_email', 254], ['phone', 'cvd_c_phone', 32],
      ['organization', 'cvd_c_org', 128], ['country', 'cvd_c_country', 2]].map(function (c) {
      return M.field('fp-co-c-' + c[0], t(c[1]), el('input', {class: 'sig-input', id: 'fp-co-c-' + c[0], name: 'contact.' + c[0], type: c[0] === 'email' ? 'email' : 'text',
        maxlength: String(c[2]), autocomplete: 'off', spellcheck: 'false'}));
    });
    var contactBox = el('div', {class: 'fp-co-contact', id: 'fp-co-contact', hidden: ''}, [el('p', {class: 'fp-muted', text: t('cvd_contact_hint')}),
      el('div', {class: 'fp-co-contact-grid'}, contact)]);
    var toggle = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'aria-expanded': 'false', 'aria-controls': 'fp-co-contact', text: t('cvd_contact_toggle')});
    toggle.addEventListener('click', function () {
      contactBox.hidden = !contactBox.hidden;
      toggle.setAttribute('aria-expanded', contactBox.hidden ? 'false' : 'true');
    });
    var form = el('form', {class: 'fp-form fp-mail-form fp-co-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('p', {class: 'fp-muted', text: t('cvd_new_lead', {vendor: S.offer.vendorName})}),
      M.field('fp-co-domain', t('cvd_domain'), site, t('cvd_domain_hint')),
      M.field('fp-co-product', t('cvd_product'), product),
      M.field('fp-co-months', t('cvd_months'), term),
      el('div', {class: 'sig-field'}, [el('span', {class: 'sig-label', id: 'fp-co-method-l', text: t('cvd_method')}), methods]),
      namesField, approverField, el('div', {class: 'fp-co-more'}, [toggle, contactBox]),
      el('p', {class: 'fp-muted fp-co-key', text: t('cvd_key_note')}),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('cvd_order')})])]);

    function method() { var c = methods.querySelector('input:checked'); return c ? c.value : ''; }
    function loadApprovers() {
      approver.textContent = '';
      approver.appendChild(el('option', {value: '', text: t('loading')}));
      var mine = S;
      FP.call('get', 'certVendorApprovers', undefined, {name: S.account, domain: site.value, product: product.value}).then(function (r) {
        if (S !== mine) { return; }
        approver.textContent = '';
        (r && Array.isArray(r.emails) ? r.emails : []).filter(function (e) { return M.isAddress(str(e, 254)); }).forEach(function (e) {
          approver.appendChild(el('option', {value: e, text: e}));
        });
      }, function (err) {
        if (S !== mine) { return; }
        approver.textContent = '';
        UI.showError(form, err.message);
      });
    }
    function sync() {
      var p = productOf(product.value);
      term.textContent = '';
      p.months.forEach(function (m) { term.appendChild(el('option', {value: String(m), text: t(m === 12 ? 'cvd_one_year' : 'cvd_years', {n: m / 12})})); });
      var was = method();
      methods.textContent = '';
      p.methods.forEach(function (m, i) {
        var id = 'fp-co-m-' + m;
        var input = el('input', {type: 'radio', id: id, name: 'method', value: m, 'aria-describedby': id + '-hint'});
        if (m === was || (!was && i === 0) || (p.methods.indexOf(was) < 0 && i === 0)) { input.checked = true; }
        methods.appendChild(el('div', {class: 'fp-co-choice'}, [el('label', {class: 'fp-check', for: id}, [input, el('span', {text: t('cvd_m_' + m)})]),
          el('span', {class: 'sig-hint', id: id + '-hint', text: t('cvd_mh_' + m)})]));
      });
      namesField.hidden = p.kind !== 'multi';
      approverField.hidden = method() !== 'email';
      if (method() === 'email') { loadApprovers(); }
    }
    product.addEventListener('change', sync);
    site.addEventListener('change', function () { if (method() === 'email') { loadApprovers(); } });
    methods.addEventListener('change', function () {
      approverField.hidden = method() !== 'email';
      if (method() === 'email') { loadApprovers(); }
    });
    sync();

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var p = productOf(product.value);
      var body = {domain: site.value, product: p.id, months: parseInt(term.value, 10), method: method()};
      if (p.kind === 'multi') {
        var list = names.value.split(/[\s,;]+/).map(function (n) { return n.trim().toLowerCase(); }).filter(Boolean);
        var odd = list.filter(function (n) { return !NAME_RE.test(n) || n.indexOf('*') === 0; })[0];
        if (odd) { M.fieldError(form, names, t('cvd_names_bad', {name: odd.slice(0, 80)})); return; }
        if (list.length + 1 > p.maxNames) { M.fieldError(form, names, t('cvd_names_many', {n: p.maxNames})); return; }
        body.names = list;
      }
      if (body.method === 'email') {
        if (!approver.value) { M.fieldError(form, approver, t('cvd_approver_none')); return; }
        body.approver_email = approver.value;
      }
      var c = {};
      var any = false;
      contact.forEach(function (f) {
        var input = f.querySelector('input');
        var v = input.value.trim();
        if (v) { c[input.name.slice(8)] = v; any = true; }
      });
      if (any) { body.contact = c; }
      var mine = S;
      UI.setBusy(b, true);
      M.say(form, t('cvd_ordering'));
      FP.call('post', 'certOrders', body, S.account).then(function (r) {
        if (S !== mine) { return; }
        UI.setBusy(b, false);
        M.say(form, '');
        var o = cleanOrder(r);
        if (o) { mine.orders = [o].concat(mine.orders.filter(function (x) { return x.id !== o.id; })); }
        drawOrders();
        var card = S.page.querySelector('.fp-co-orders');
        M.say(card, o ? t('cvd_ordered_' + (o.status === 'failed' ? 'failed' : 'ok'), {domain: o.domain}) : '');
        var row = o && S.page.querySelector('[data-fp-order="' + o.id + '"] h3');
        (row || S.page.querySelector('#fp-co-orders-h')).focus();
      }, function (err) {
        if (S !== mine) { return; }
        UI.setBusy(b, false);
        M.say(form, '');
        M.failed(form, err);
      });
    });
    return M.card('fp-co-new-h', t('cvd_new_title'), [form], 'fp-co-new');
  }

  /* ================= the orders ================= */
  function proof(v) {
    var parts = [el('span', {class: 'fp-co-proof-name sig-mono', text: v.name}), ' ',
      pill(v.done ? 'ok' : (v.placed || v.method === 'email' ? 'accent' : 'warn'), v.done ? t('cvd_proved') : (v.placed ? t('cvd_placed') : (v.method === 'email' ? t('cvd_waiting_mail') : t('cvd_yours'))))];
    var facts = [];
    if (v.method === 'http' && v.filePath) {
      facts.push(el('dt', {text: t('cvd_file')}), el('dd', {class: 'sig-mono', text: v.filePath}));
      if (!v.placed && !v.done) { facts.push(el('dt', {text: t('cvd_file_holds')}), el('dd', null, [el('pre', {class: 'fp-co-pre sig-mono', text: v.fileContent})])); }
    } else if ((v.method === 'dns_cname' || v.method === 'dns_txt') && v.recordName) {
      facts.push(el('dt', {text: t('cvd_record')}), el('dd', {class: 'sig-mono fp-co-wrap', text: v.recordName + ' ' + v.recordType + ' ' + v.recordValue}));
    } else if (v.method === 'email' && v.email) {
      facts.push(el('dt', {text: t('cvd_mail_to')}), el('dd', {class: 'sig-mono', text: v.email}));
    }
    return el('li', {class: 'fp-co-proof'}, [el('div', null, parts), facts.length ? el('dl', {class: 'fp-co-facts'}, facts) : null]);
  }
  function orderItem(o) {
    var head = el('div', {class: 'fp-co-head'}, [el('h3', {class: 'fp-h3 fp-co-domain', tabindex: '-1', text: o.domain}), pill(PILL[o.status], t('cvd_s_' + o.status))]);
    var facts = [el('dt', {text: t('cvd_f_product')}), el('dd', {text: o.product + (o.level ? ' · ' + t('cvd_level_' + o.level) : '')})];
    if (o.names.length > 1 || (o.names[0] && o.names[0] !== o.domain)) { facts.push(el('dt', {text: t('cvd_f_names')}), el('dd', {class: 'sig-mono fp-co-wrap', text: o.names.join(', ')})); }
    facts.push(el('dt', {text: t('cvd_f_ordered')}), el('dd', {text: o.created + (o.vendorOrder ? ' · ' + t('cvd_vendor_ref', {vendor: o.vendorName, id: o.vendorOrder}) : '')}));
    if (o.notAfter) { facts.push(el('dt', {text: t(o.expired ? 'cvd_f_ended' : 'cvd_f_ends')}), el('dd', {text: o.notAfter})); }
    var notes = [];
    if (o.status === 'unclear') { notes.push(el('p', {class: 'fp-muted', text: t('cvd_unclear')})); }
    if (o.renewDue) { notes.push(el('p', {class: 'sig-banner sig-banner--warn fp-co-renew', role: 'note', text: t('cvd_renew_due', {date: o.notAfter})})); }
    if (o.message) { notes.push(el('p', {class: 'fp-muted fp-co-message', text: o.message})); }
    var proofs = o.validations.length && ['pending', 'issued', 'installing', 'unclear'].indexOf(o.status) >= 0 ?
      [el('h4', {class: 'fp-co-h4', text: t('cvd_proof_title')}), el('ul', {class: 'fp-co-proofs'}, o.validations.map(proof))] : [];
    var acts = [];
    if (['unclear', 'pending', 'issued'].indexOf(o.status) >= 0) {
      acts.push(el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'co-check', 'aria-label': t('cvd_check_of', {domain: o.domain}), text: t('cvd_check')}));
    }
    if (o.canReissue) { acts.push(el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'co-reissue', 'aria-label': t('cvd_reissue_of', {domain: o.domain}), text: t('cvd_reissue')})); }
    if (o.canCancel) { acts.push(el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'co-cancel', 'aria-label': t('cvd_cancel_of', {domain: o.domain}), text: t('cvd_cancel')})); }
    return el('li', {class: 'fp-co-item', 'data-fp-order': o.id}, [head, el('dl', {class: 'fp-co-facts'}, facts)].concat(notes, proofs,
      [el('div', {class: 'fp-co-acts fp-mail-acts'}, acts)]));
  }
  function ordersCard() {
    var parts = [M.errorLine(), M.statusLine()];
    if (!S.orders.length) { parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': 'orders', text: t('cvd_orders_none')})); }
    else { parts.push(el('ul', {class: 'fp-co-list', 'aria-labelledby': 'fp-co-orders-h'}, S.orders.map(orderItem))); }
    var card = M.card('fp-co-orders-h', t('cvd_orders_title'), parts, 'fp-co-orders');
    if (S.ordersError) { UI.showError(card, S.ordersError); }
    return card;
  }
  function drawOrders() {
    var old = S.page.querySelector('.fp-co-orders');
    var fresh = ordersCard();
    if (old) { old.replaceWith(fresh); } else { S.page.appendChild(fresh); }
  }
  function replaced(r) {
    var o = cleanOrder(r);
    if (o) { S.orders = S.orders.map(function (x) { return x.id === o.id ? o : x; }); }
    return o;
  }
  function focusAct(id, act) {
    var n = S.page.querySelector('[data-fp-order="' + id + '"] [data-fp-act="' + act + '"]') || S.page.querySelector('[data-fp-order="' + id + '"] h3');
    if (n) { n.focus(); }
  }

  function onClick(e) {
    if (!S || !S.page) { return; }
    var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !S.page.contains(b) || b.disabled || b.getAttribute('data-fp-act').indexOf('co-') !== 0 && b.getAttribute('data-fp-act') !== 'confirm-no') { return; }
    var item = b.closest('[data-fp-order]');
    if (!item) { return; }
    var id = item.getAttribute('data-fp-order');
    var o = orderOf(id);
    var act = b.getAttribute('data-fp-act');
    var card = S.page.querySelector('.fp-co-orders');
    var mine = S;
    function run(method, key, body, done, again) {
      UI.showError(card, '');
      UI.setBusy(b, true);
      FP.call(method, key, body, {name: S.account, id: id}).then(function (r) {
        if (S !== mine) { return; }
        var fresh = replaced(r);
        drawOrders();
        M.say(S.page.querySelector('.fp-co-orders'), fresh ? t(done, {domain: fresh.domain, status: t('cvd_s_' + fresh.status)}) : '');
        focusAct(id, again);
      }, function (err) {
        if (S !== mine) { return; }
        drawOrders();
        UI.showError(S.page.querySelector('.fp-co-orders'), err.message);
        focusAct(id, again);
      });
    }
    if (!o) { return; }
    if (act === 'co-check') {
      run('post', 'certOrderCheck', {}, 'cvd_checked', 'co-check');
    } else if (act === 'co-cancel') {
      M.confirmIn(item.querySelector('.fp-co-acts'), t('cvd_cancel_ask', {domain: o.domain, vendor: o.vendorName}), 'co-cancel-yes', t('cvd_cancel'));
    } else if (act === 'co-cancel-yes') {
      run('post', 'certOrderCancel', {}, 'cvd_cancelled', 'co-check');
    } else if (act === 'co-reissue') {
      M.confirmIn(item.querySelector('.fp-co-acts'), t('cvd_reissue_ask', {domain: o.domain}), 'co-reissue-yes', t('cvd_reissue'));
    } else if (act === 'co-reissue-yes') {
      run('post', 'certOrderReissue', {}, 'cvd_reissued', 'co-check');
    } else if (act === 'confirm-no') {
      drawOrders();
      focusAct(id, 'co-cancel');
    }
  }
  document.addEventListener('click', onClick);

  FP.view('tool:ssl_buy', function () {
    S = null;
    var body = M.frame('ssl_buy', 'fp-co');
    if (!body) { return; }
    S = {page: body, account: FP.account(), offer: cleanOffer(null), sites: [], orders: [], ordersError: ''};
    var mine = S;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    var wrap = function (p) { return p.then(function (r) { return {r: r}; }, function (err) { return {err: err}; }); };
    Promise.all([wrap(FP.call('get', 'certVendorOffer', undefined, S.account)), wrap(FP.call('get', 'domains', undefined, S.account)),
      wrap(FP.call('get', 'certOrders', undefined, S.account))]).then(function (all) {
      if (S !== mine) { return; }
      body.textContent = '';
      if (all[0].err) { body.appendChild(FP.empty(FP.tools.ssl_buy.label, all[0].err.message)); return; }
      mine.offer = cleanOffer(all[0].r);
      mine.sites = all[1].err ? [] : sitesOf(all[1].r);
      mine.orders = all[2].err ? [] : (all[2].r && Array.isArray(all[2].r.orders) ? all[2].r.orders : []).map(cleanOrder).filter(Boolean);
      mine.ordersError = all[2].err ? all[2].err.message : '';
      body.appendChild(orderCard());
      drawOrders();
    });
  });
})();

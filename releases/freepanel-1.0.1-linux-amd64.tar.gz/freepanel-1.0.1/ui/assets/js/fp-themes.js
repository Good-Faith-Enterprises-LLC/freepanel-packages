/* freePanel's Themes page for the admin panel (#/tool/site_themes, docs/api.md, "Themes"; docs/themes.md): the themes of the customer-facing
   site. It lists the installed themes with their check, which is active and which is the previous one; uploads a zip with its progress and lists
   every problem the check found by file and line; opens a preview in a new tab; activates, rolls back and deletes, each after a question on
   the page; and downloads the theme kit to start a theme from. What the server answers is cleaned to the shapes drawn and shown as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var el = UI.el;
  var M = FP.mail;
  var t = UI.t;

  var MAX_UPLOAD = 16 * 1024 * 1024;
  var ID_RE = /^[a-z][a-z0-9-]{1,39}$/;
  var PAGE_RE = /^[a-z][a-z0-9-]{0,39}$/;
  var LANG_RE = /^[a-z]{2,3}(-[a-z0-9]{2,8})?$/;

  var P = null;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  function id(v) { return typeof v === 'string' && (v === 'default' || ID_RE.test(v)) ? v : ''; }
  function list(v, n, each) { return (Array.isArray(v) ? v : []).slice(0, n).map(each).filter(Boolean); }
  function problems(v) {
    return list(v, 100, function (p) {
      if (!p || typeof p !== 'object' || typeof p.message !== 'string') { return null; }
      return {file: str(p.file, 200), line: typeof p.line === 'number' && isFinite(p.line) && p.line > 0 ? Math.floor(p.line) : 0, message: str(p.message, 500)};
    });
  }
  function urls(v) { return list(v, 50, function (u) { return typeof u === 'string' && /^https:\/\//.test(u) ? u.slice(0, 300) : null; }); }
  function cleanTheme(x) {
    x = x && typeof x === 'object' ? x : {};
    var tid = id(x.id);
    if (!tid) { return null; }
    return {id: tid, name: str(x.name, 80) || tid, version: str(x.version, 32), author: str(x.author, 120), licence: str(x.licence, 200),
      scripts: urls(x.scripts), off: urls(x.scripts_off), builtIn: x.built_in === true, active: x.active === true, previous: x.previous === true,
      ok: x.status === 'ok', problems: problems(x.problems), kept: str(x.kept_version, 32)};
  }
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var seen = {};
    var themes = list(r.themes, 200, function (x) {
      var c = cleanTheme(x);
      if (!c || seen[c.id]) { return null; }
      seen[c.id] = true;
      return c;
    });
    var prev = r.previous && typeof r.previous === 'object' && id(r.previous.id) ? {id: id(r.previous.id), version: str(r.previous.version, 32)} : null;
    var pages = list(r.pages, 100, function (p) { return typeof p === 'string' && PAGE_RE.test(p) ? p : null; });
    return {active: id(r.active) || 'default', serving: id(r.serving) || 'default', previous: prev, problem: problems(r.problem), themes: themes,
      pages: pages.length ? pages : ['home']};
  }
  function byId(tid) {
    for (var i = 0; i < P.data.themes.length; i++) { if (P.data.themes[i].id === tid) { return P.data.themes[i]; } }
    return null;
  }
  function label(th) { return th ? th.name + (th.version ? ' ' + th.version : '') : ''; }
  function previewHref(tid, page, lang) {
    return window.FPAPI.paths.themePreview.replace('{id}', encodeURIComponent(tid)).replace('{page}', encodeURIComponent(page)) +
      (lang && LANG_RE.test(lang) ? '?lang=' + encodeURIComponent(lang) : '');
  }

  /* problems as a list of file:line: words, the way an author finds them */
  function problemList(ps, cls) {
    if (!ps.length) { return null; }
    return el('ul', {class: 'fp-thm-problems' + (cls ? ' ' + cls : '')}, ps.map(function (p) {
      var where = p.file ? p.file + (p.line ? ':' + p.line : '') : '';
      return el('li', {}, [where ? el('span', {class: 'sig-mono fp-thm-where', text: where}) : null, where ? ' ' : null, el('span', {text: p.message})]);
    }));
  }

  /* ---- what the site serves, and the rollback ---- */
  function statusCard() {
    var d = P.data;
    var act = byId(d.active);
    var serving = byId(d.serving);
    var parts = [M.errorLine(), M.statusLine()];
    parts.push(el('p', {class: 'fp-thm-serving', 'data-fp-thm-serving': ''}, [t('thm_serving') + ' ', el('strong', {text: label(serving) || d.serving})]));
    if (d.active !== d.serving) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn fp-thm-fallback', role: 'note', 'data-fp-thm-fallback': ''}, [UI.icon(FP.ui, 'ui_warning'),
        el('div', {}, [el('p', {text: t('thm_fallback', {theme: label(act) || d.active})}), problemList(d.problem)])]));
    }
    var acts = el('div', {class: 'fp-actions', 'data-fp-thm-rb': ''}, [el('a', {class: 'sig-btn sig-btn--secondary',
      href: window.FPAPI.paths.themeDownload.replace('{id}', encodeURIComponent(d.serving)), download: '', 'data-fp-thm-live': '',
      text: d.serving === 'default' ? t('thm_live_kit') : t('thm_live')})]);
    if (d.previous) {
      var prev = byId(d.previous.id);
      var what = (prev ? prev.name : d.previous.id) + (d.previous.version ? ' ' + d.previous.version : '');
      parts.push(el('p', {class: 'fp-muted', text: t('thm_previous', {theme: what})}));
      acts.appendChild(el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'rollback', 'data-fp-what': what, text: t('thm_rollback')}));
    } else {
      parts.push(el('p', {class: 'fp-muted', text: t('thm_no_previous')}));
    }
    parts.push(acts);
    return M.card('fp-thm-status-h', t('thm_status_title'), parts, 'fp-thm-status');
  }

  /* ---- the installed themes ---- */
  function themeRow(th) {
    var pills = el('span', {class: 'fp-thm-pills'}, [
      th.active ? el('span', {class: 'sig-pill sig-pill--accent', text: t('thm_active')}) : null,
      th.previous ? el('span', {class: 'sig-pill', text: t('thm_prev_pill')}) : null,
      th.builtIn ? el('span', {class: 'sig-pill', text: t('thm_builtin')}) : null,
      el('span', {class: 'sig-pill ' + (th.ok ? 'sig-pill--ok' : 'sig-pill--warn'), text: th.ok ? t('thm_ok') : t('thm_failed')})]);
    var meta = [];
    if (th.author) { meta.push(t('thm_by', {author: th.author})); }
    if (th.licence) { meta.push(t('thm_licence', {licence: th.licence})); }
    var body = [
      el('div', {class: 'fp-thm-head'}, [el('h3', {class: 'fp-h3 fp-thm-name', id: 'fp-thm-n-' + th.id, tabindex: '-1', text: label(th)}), pills]),
      el('p', {class: 'fp-muted fp-thm-meta'}, [el('span', {class: 'sig-mono', text: th.id}), meta.length ? ' · ' + meta.join(' · ') : '']),
      th.kept ? el('p', {class: 'fp-muted', text: t('thm_kept', {version: th.kept})}) : null,
      th.off.length ? el('p', {class: 'fp-thm-off'}, [t('thm_scripts_off') + ' ', el('a', {href: '#/tool/theme_scripts', text: t('thm_scripts_link')})]) : null,
      th.ok ? null : problemList(th.problems)
    ];
    var acts = el('div', {class: 'fp-actions fp-thm-acts', 'data-fp-thm-acts': th.id});
    if (th.ok) {
      acts.appendChild(el('a', {class: 'sig-btn sig-btn--secondary sig-btn--sm', href: previewHref(th.id, P.data.pages[0], ''), target: '_blank', rel: 'noopener',
        'aria-label': t('thm_preview_of', {theme: label(th)}), text: t('thm_preview')}));
    }
    if (!th.active && th.ok) {
      acts.appendChild(el('button', {class: 'sig-btn sig-btn--primary sig-btn--sm', type: 'button', 'data-fp-act': 'activate', 'data-fp-id': th.id,
        'aria-label': t('thm_activate_of', {theme: label(th)}), text: t('thm_activate')}));
    }
    if (!th.active && !th.builtIn) {
      acts.appendChild(el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'delete', 'data-fp-id': th.id,
        'aria-label': t('thm_delete_of', {theme: label(th)}), text: t('thm_delete')}));
    }
    body.push(acts);
    return el('li', {class: 'fp-thm-item' + (th.active ? ' is-active' : ''), 'data-fp-thm': th.id}, body);
  }
  function listCard() {
    var items = P.data.themes.map(themeRow);
    return M.card('fp-thm-list-h', t('thm_list_title'), [M.errorLine(), M.statusLine(), el('ul', {class: 'fp-thm-list'}, items)], 'fp-thm-installed');
  }

  /* ---- upload ---- */
  function uploadCard() {
    var file = el('input', {class: 'sig-input fp-up-file', id: 'fp-thm-file', name: 'zip', type: 'file', accept: '.zip,application/zip', disabled: P.sending ? true : null});
    var acts = el('div', {class: 'fp-actions', 'data-fp-thm-up-acts': ''}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('thm_upload'),
      disabled: P.sending ? true : null})]);
    var form = el('form', {class: 'fp-form fp-thm-upload', novalidate: ''}, [el('p', {class: 'fp-muted', text: t('thm_upload_desc')}),
      M.field('fp-thm-file', t('thm_file'), file, t('thm_file_hint')), M.errorLine(), el('div', {'data-fp-thm-up-problems': ''}), M.statusLine(), acts]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (P.sending) { return; }
      var go = M.start(form);
      if (!go) { return; }
      form.querySelector('[data-fp-thm-up-problems]').textContent = '';
      var f = file.files && file.files[0];
      if (!f) { M.fieldError(form, file, t('thm_file_none')); return; }
      if (!/\.zip$/i.test(f.name)) { M.fieldError(form, file, t('thm_file_bad')); return; }
      if (!f.size) { M.fieldError(form, file, t('thm_file_empty')); return; }
      if (f.size > MAX_UPLOAD) { M.fieldError(form, file, t('thm_file_big')); return; }
      send(form, f);
    });
    return M.card('fp-thm-up-h', t('thm_upload_title'), [form], 'fp-thm-up');
  }

  /* ---- the theme kit: the built-in default theme as a zip, with the authors' guide, to start a theme from ---- */
  function kitCard() {
    return M.card('fp-thm-kit-h', t('thm_kit_title'), [el('p', {class: 'fp-muted', text: t('thm_kit_desc')}),
      el('div', {class: 'fp-actions'}, [el('a', {class: 'sig-btn sig-btn--secondary', href: window.FPAPI.paths.themeKit, download: '',
        'data-fp-thm-kit': '', text: t('thm_kit')})])], 'fp-thm-kit');
  }
  function send(form, f) {
    var mine = P;
    var acts = form.querySelector('[data-fp-thm-up-acts]');
    var bar = el('progress', {class: 'fp-up-bar', id: 'fp-thm-bar', max: '100', value: '0', 'aria-labelledby': 'fp-thm-sending'});
    var line = el('span', {id: 'fp-thm-sending', text: t('thm_sending', {file: f.name, n: '0'})});
    var stop = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'stop', text: t('thm_stop')});
    acts.textContent = '';
    acts.appendChild(el('div', {class: 'fp-up-progress', 'data-fp-thm-progress': ''}, [line, bar]));
    acts.appendChild(stop);
    form.querySelector('#fp-thm-file').disabled = true;
    stop.focus();
    var shown = -1;
    P.sending = window.FPAPI.upload('themeUpload', f, 'application/zip', undefined, function (x) {
      var n = Math.floor(x * 100);
      bar.value = n;
      /* in steps of ten, so a screen reader is not told every percent */
      if (n - shown >= 10 || n === 100) { shown = n; line.textContent = n === 100 ? t('thm_checking') : t('thm_sending', {file: f.name, n: String(n)}); }
    });
    P.sending.done.then(function (r) {
      if (P !== mine) { return; }
      P.sending = null;
      var it = cleanTheme(r && r.installed);
      P.data = clean(r && r.list);
      var said = it ? t('thm_installed', {theme: label(it)}) : t('thm_installed_some');
      if (r && typeof r.replaced === 'string' && r.replaced) { said += ' ' + t('thm_replaced', {version: str(r.replaced, 32)}); }
      draw('#fp-thm-up-h', said, '.fp-thm-up');
    }, function (err) {
      if (P !== mine) { return; }
      P.sending = null;
      if (err && err.status === 401) { FP.signedOut(true); return; }
      draw('', '', '');
      var now = P.page.querySelector('.fp-thm-upload');
      if (err && err.code === 'aborted') { M.say(now, t('thm_stopped')); now.querySelector('#fp-thm-file').focus(); return; }
      var ps = err && Array.isArray(err.problems) ? err.problems : [];
      M.fieldError(now, now.querySelector('#fp-thm-file'), ps.length ? t('thm_refused', {n: String(ps.length)}) : (err && err.message) || t('api_failed'));
      var box = now.querySelector('[data-fp-thm-up-problems]');
      if (ps.length) { box.appendChild(problemList(ps, 'fp-thm-up-list')); }
      if (err && /allow-list/.test(err.message + ' ' + ps.map(function (p) { return p.message; }).join(' '))) {
        box.appendChild(el('p', {}, [el('a', {href: '#/tool/theme_scripts', text: t('thm_scripts_link')})]));
      }
    });
  }

  /* ---- the questions and the changes ---- */
  function ask(cell, question, act, yes, extra) {
    M.confirmIn(cell, question, act, yes);
    var b = cell.querySelector('[data-fp-act="' + act + '"]');
    Object.keys(extra || {}).forEach(function (k) { b.setAttribute(k, extra[k]); });
    b.classList.remove('sig-btn--sm');
    if (act !== 'delete-yes') { b.classList.remove('sig-btn--danger'); b.classList.add('sig-btn--primary'); }
  }
  function change(method, name, arg, said, scope) {
    var mine = P;
    var buttons = P.page.querySelectorAll('button');
    Array.prototype.forEach.call(buttons, function (b) { b.disabled = true; });
    FP.call(method, name, method === 'del' ? undefined : {}, arg).then(function (r) {
      if (P !== mine) { return; }
      P.data = clean(r);
      draw(scope === 'status' ? '#fp-thm-status-h' : '#fp-thm-list-h', said, scope === 'status' ? '.fp-thm-status' : '.fp-thm-installed');
    }, function (err) {
      if (P !== mine) { return; }
      draw('', '', '');
      var card = P.page.querySelector(scope === 'status' ? '.fp-thm-status' : '.fp-thm-installed');
      var ps = err && Array.isArray(err.problems) ? err.problems : [];
      UI.showError(card, (err && err.message) || t('api_failed'));
      var line = card.querySelector('[data-fp-error]');
      if (ps.length && line) { line.appendChild(problemList(ps)); }
      if (line && line.scrollIntoView) { line.scrollIntoView({block: 'nearest'}); }
      var head = card.querySelector('.fp-h2');
      if (head) { head.focus({preventScroll: true}); }
    });
  }
  function onClick(e) {
    var b = e.target.closest('[data-fp-act]');
    if (!b || !P.page.contains(b)) { return; }
    var act = b.getAttribute('data-fp-act');
    var tid = id(b.getAttribute('data-fp-id'));
    var th = byId(tid);
    if (act === 'stop') { if (P.sending) { P.sending.abort(); } return; }
    if (act === 'confirm-no') { var keep = b.closest('[data-fp-thm-acts]'); draw(keep ? '#fp-thm-n-' + keep.getAttribute('data-fp-thm-acts') : '#fp-thm-status-h', '', ''); return; }
    if (act === 'activate' && th) { ask(b.parentNode, t('thm_activate_ask', {theme: label(th)}), 'activate-yes', t('thm_activate_yes'), {'data-fp-id': th.id}); return; }
    if (act === 'delete' && th) { ask(b.parentNode, t('thm_delete_ask', {theme: label(th)}), 'delete-yes', t('thm_delete_yes'), {'data-fp-id': th.id}); return; }
    if (act === 'rollback') { ask(b.parentNode, t('thm_rollback_ask', {theme: b.getAttribute('data-fp-what') || ''}), 'rollback-yes', t('thm_rollback_yes')); return; }
    if (act === 'activate-yes' && th) { change('post', 'themeActivate', {id: th.id}, t('thm_activated', {theme: label(th)}), 'list'); return; }
    if (act === 'delete-yes' && th) { change('del', 'theme', {id: th.id}, t('thm_deleted', {theme: label(th)}), 'list'); return; }
    if (act === 'rollback-yes') { change('post', 'themeRollback', undefined, t('thm_rolled_back'), 'status'); }
  }

  function draw(focus, said, sayIn) {
    var page = P.page;
    page.textContent = '';
    page.appendChild(statusCard());
    page.appendChild(listCard());
    page.appendChild(uploadCard());
    page.appendChild(kitCard());
    if (said) { M.say(sayIn ? page.querySelector(sayIn) : page, said); }
    var target = focus ? page.querySelector(focus) : null;
    if (target) { target.focus(); }
  }

  FP.view('tool:site_themes', function () {
    if (P && P.sending) { P.sending.abort(); }
    P = null;
    var tool = FP.tools.site_themes;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('thm_desc'), cls: 'fp-mail fp-thm-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    if (!page) { return; }
    P = {page: page, data: clean({}), sending: null};
    var mine = P;
    page.addEventListener('click', onClick);
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'themes').then(function (r) {
      if (P !== mine) { return; }
      P.data = clean(r);
      draw('', '', '');
    }, function (err) {
      if (P !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err && err.message ? err.message : t('thm_unavailable')));
    });
  });
})();

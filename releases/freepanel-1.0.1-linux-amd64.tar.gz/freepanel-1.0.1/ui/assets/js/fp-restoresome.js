/* freePanel restore of some items (the admin panel's Back up and restore page, fp-backups.js; docs/api.md, "Accounts":
   the restore's `select` and GET .../backups/{name}/contents): puts back only the files and folders, databases and mail
   settings the admin picks from one archive, and leaves the rest of the account as it is. The card reads the archive
   through `contents` (the entries of one folder at a time, the databases it holds and its mail items), keeps what is
   picked in its own list, and asks before it sends. What it asks about is a copy taken when the button was pressed: the
   question lists it, the picker is switched off while the question is open, and a Yes sends that copy, never what the
   boxes show by then. The archive's account must exist (a removed account is made again by the whole-archive restore
   first); an archive of an earlier account with the name goes in only when the admin says so (other_account). Declares
   only FP.restoreSome.card. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var MAX_ITEMS = 100;
  var MAX_PATH_BYTES = 1024;
  var MAX_ENTRIES = 1000;
  var PAGE = 50;
  var ENGINES = ['mysql', 'postgres'];
  var MAIL_KNOWN = ['mailboxes', 'forwarders', 'filters', 'defaults', 'spam'];
  var KINDS = ['file', 'dir', 'link', 'other'];
  var ITEM_RE = /^[a-z][a-z0-9_-]{0,31}$/;
  var BIG = 1024 * 1024 * 1024;

  function plain(s, max) {
    if (typeof s !== 'string' || !s || s.length > max) { return false; }
    for (var i = 0; i < s.length; i++) {
      var c = s.charCodeAt(i);
      if (c < 32 || c === 127) { return false; }
    }
    return true;
  }
  function bytesOf(s) { return window.TextEncoder ? new window.TextEncoder().encode(s).length : s.length; }
  function join(dir, name) { return dir ? dir + '/' + name : name; }
  /* a path as the API takes it: below the home folder, no leading slash, no empty, . or .. element */
  function pathProblem(p) {
    if (!plain(p, 4 * MAX_PATH_BYTES)) { return 'bad'; }
    if (bytesOf(p) > MAX_PATH_BYTES) { return 'long'; }
    var parts = p.split('/');
    for (var i = 0; i < parts.length; i++) {
      if (!parts[i] || parts[i] === '.' || parts[i] === '..') { return 'bad'; }
    }
    return '';
  }
  function entryName(n) { return plain(n, 255) && n.indexOf('/') < 0 && n !== '.' && n !== '..'; }
  function unique(list) { return list.filter(function (v, i) { return list.indexOf(v) === i; }); }

  /* what the server says an archive holds, in the shapes this card draws */
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var entries = (Array.isArray(r.entries) ? r.entries : []).filter(function (e) {
      return e && typeof e === 'object' && entryName(e.name) && KINDS.indexOf(e.kind) >= 0;
    }).slice(0, MAX_ENTRIES).map(function (e) {
      return {name: e.name, kind: e.kind, size: typeof e.size === 'number' && isFinite(e.size) && e.size >= 0 ? e.size : null};
    });
    var dbs = {};
    ENGINES.forEach(function (en) {
      var list = r.databases && typeof r.databases === 'object' && Array.isArray(r.databases[en]) ? r.databases[en] : [];
      list = unique(list.filter(function (n) { return plain(n, 128); })).slice(0, MAX_ITEMS);
      if (list.length) { dbs[en] = list; }
    });
    var mail = unique((Array.isArray(r.mail) ? r.mail : []).filter(function (m) { return typeof m === 'string' && ITEM_RE.test(m); }));
    /* the kinds this card has words for first, then any other by its key, so one added later is not dropped */
    mail = MAIL_KNOWN.filter(function (m) { return mail.indexOf(m) >= 0; }).concat(mail.filter(function (m) { return MAIL_KNOWN.indexOf(m) < 0; })).slice(0, 20);
    return {entries: entries, databases: dbs, mail: mail, truncated: r.truncated === true};
  }

  /* the card for one archive: opts {account: it exists now, other: the archive is of an earlier account with the name,
     onClose(), onStarted(result, said)}; returns {node, stop()} */
  function card(a, opts) {
    var S = {dir: '', shown: PAGE, listing: null, loading: true, failed: '', token: 0, files: [], dbs: {mysql: [], postgres: []}, mail: [],
      holds: {databases: {}, mail: []}, seen: false, dead: false, asking: false, other: Boolean(opts.other)};
    var form = el('form', {class: 'fp-form fp-mail-form', novalidate: ''}, [M.errorLine()]);
    var head = el('h2', {class: 'fp-h2', id: 'fp-ars-h', tabindex: '-1', text: t('arst_title', {archive: a.name})});

    /* ---------- files and folders ---------- */
    var trail = el('nav', {class: 'fp-ars-trail', 'aria-label': t('arst_trail')});
    var listBox = el('div', {class: 'fp-ars-listbox'});
    var loadError = el('div', {class: 'fp-alert', role: 'alert', 'data-fp-ars-load': ''});
    var more = el('p', {class: 'sig-hint', 'data-fp-ars-truncated': '', hidden: true, text: t('arst_truncated')});
    var chosenBox = el('div', {class: 'fp-ars-chosen-box'});
    var pathInput = el('input', {class: 'sig-input', id: 'fp-ars-path', name: 'path', type: 'text', autocomplete: 'off', spellcheck: 'false',
      autocapitalize: 'none', maxlength: '1100'});
    var addBtn = el('button', {class: 'sig-btn sig-btn--secondary', id: 'fp-ars-add', type: 'button', 'data-fp-act': 'add-path', text: t('arst_add')});
    var addErr = el('p', {class: 'fp-ars-pathmsg', id: 'fp-ars-path-err', role: 'alert', hidden: true});
    var filesGroup = el('fieldset', {class: 'fp-ars-group', 'data-fp-ars-group': 'home'}, [
      el('legend', {class: 'sig-label', text: t('arst_files')}), el('p', {class: 'sig-hint', text: t('arst_files_hint')}),
      trail, loadError, listBox, more,
      el('div', {class: 'fp-ars-add'}, [
        el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: 'fp-ars-path', text: t('arst_add_label')}),
          el('div', {class: 'fp-ars-addrow'}, [pathInput, addBtn]), addErr,
          el('span', {class: 'sig-hint', id: 'fp-ars-path-hint', text: t('arst_add_hint')})])]),
      chosenBox]);
    pathInput.setAttribute('aria-describedby', 'fp-ars-path-hint');

    /* ---------- databases and mail ---------- */
    var dbBox = el('fieldset', {class: 'fp-ars-group', 'data-fp-ars-group': 'databases'});
    var mailBox = el('fieldset', {class: 'fp-ars-group', 'data-fp-ars-group': 'mail'});
    var count = el('p', {class: 'fp-muted fp-ars-count', 'data-fp-ars-count': ''});
    var picker = el('div', {class: 'fp-ars-picker'}, [filesGroup, dbBox, mailBox, count]);
    var acts = el('div', {class: 'fp-actions', 'data-fp-ars-acts': ''});

    function say(box, msg) { box.textContent = msg || ''; box.classList.toggle('is-shown', Boolean(msg)); }

    function counts() {
      return {files: S.files.length, dbs: S.dbs.mysql.length + S.dbs.postgres.length, mail: S.mail.length};
    }
    function drawCount() {
      var c = counts();
      count.textContent = t('arst_count', {files: c.files, dbs: c.dbs, mail: c.mail});
    }

    /* ----- the folder shown ----- */
    function drawTrail() {
      trail.textContent = '';
      var list = el('ol', {class: 'fp-ars-crumbs'});
      var parts = S.dir ? S.dir.split('/') : [];
      var steps = [{label: t('arst_home'), path: ''}];
      parts.forEach(function (p, i) { steps.push({label: p, path: parts.slice(0, i + 1).join('/')}); });
      steps.forEach(function (s, i) {
        var last = i === steps.length - 1;
        list.appendChild(el('li', null, [last ? el('span', {class: 'fp-ars-here', id: 'fp-ars-here', tabindex: '-1', 'aria-current': 'location', text: s.label}) :
          el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'go', 'data-fp-path': s.path, id: 'fp-ars-go-' + i,
            'aria-label': t('arst_go_to', {folder: s.label}), text: s.label})]));
      });
      trail.appendChild(list);
    }
    function entryIcon(e) {
      return UI.icon(FP.ui, e.kind === 'dir' ? 'ui_folder' : e.kind === 'link' ? 'ui_link' : e.kind === 'file' ? 'ui_file' : 'ui_other', 'fp-fm-ico');
    }
    function drawList() {
      listBox.textContent = '';
      if (S.loading) {
        listBox.appendChild(el('p', {class: 'fp-muted', role: 'status', 'data-fp-ars-reading': '', text: t('arst_reading')}));
        return;
      }
      if (S.failed) {
        listBox.appendChild(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', id: 'fp-ars-retry',
          'data-fp-act': 'reload', text: t('arst_retry')})]));
        return;
      }
      var entries = S.listing ? S.listing.entries : [];
      if (!entries.length) {
        listBox.appendChild(el('p', {class: 'fp-muted', 'data-fp-ars-empty': '', text: t('arst_empty_folder')}));
        return;
      }
      var ul = el('ul', {class: 'fp-ars-list', id: 'fp-ars-list', 'aria-label': t('arst_list_label', {folder: S.dir || t('arst_home')})});
      entries.slice(0, S.shown).forEach(function (e, i) {
        var full = join(S.dir, e.name);
        var meta = e.kind === 'file' ? (e.size === null ? '' : FP.bk.size(e.size)) : e.kind === 'link' ? t('arst_kind_link') : e.kind === 'other' ? t('arst_kind_other') : '';
        var box = el('input', {type: 'checkbox', id: 'fp-ars-pick-' + i, 'data-fp-path': full, checked: S.files.indexOf(full) >= 0 ? true : null});
        ul.appendChild(el('li', {class: 'fp-ars-entry', 'data-fp-entry': e.name}, [
          el('label', {class: 'fp-check fp-ars-pick', for: 'fp-ars-pick-' + i}, [box, entryIcon(e), el('span', {class: 'fp-ars-name', text: e.name}),
            meta ? el('span', {class: 'fp-ars-meta', text: meta}) : null]),
          e.kind === 'dir' ? el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', id: 'fp-ars-dir-' + i, 'data-fp-act': 'open-dir',
            'data-fp-path': full, 'aria-label': t('arst_open_dir_of', {name: e.name}), text: t('arst_open_dir')}) : null]));
      });
      listBox.appendChild(ul);
      if (entries.length > S.shown) {
        listBox.appendChild(el('div', {class: 'fp-ars-more'}, [el('span', {class: 'sig-hint', 'data-fp-ars-showing': '',
          text: t('arst_showing', {shown: S.shown, total: entries.length})}), el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button',
          id: 'fp-ars-more', 'data-fp-act': 'more', text: t('arst_more')})]));
      }
    }
    function draw() {
      drawTrail();
      drawList();
      more.hidden = !(S.listing && S.listing.truncated && !S.loading && !S.failed);
    }

    /* ----- the files and folders chosen ----- */
    function drawChosen() {
      chosenBox.textContent = '';
      chosenBox.appendChild(el('h3', {class: 'fp-ars-sub', id: 'fp-ars-chosen-h', text: t('arst_chosen_files')}));
      if (!S.files.length) {
        chosenBox.appendChild(el('p', {class: 'fp-muted', 'data-fp-ars-nonechosen': '', text: t('arst_none_chosen')}));
        return;
      }
      chosenBox.appendChild(el('ul', {class: 'fp-ars-chosen', 'aria-labelledby': 'fp-ars-chosen-h'}, S.files.map(function (p, i) {
        return el('li', {class: 'fp-ars-chip', 'data-fp-chosen': p}, [el('span', {class: 'sig-mono fp-ars-chip-path', text: p}),
          el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', id: 'fp-ars-rm-' + i, 'data-fp-act': 'unpick',
            'data-fp-path': p, 'aria-label': t('arst_remove_of', {path: p}), text: t('arst_remove')})]);
      })));
    }
    function pick(p, on) {
      var i = S.files.indexOf(p);
      if (on && i < 0) { S.files.push(p); }
      if (!on && i >= 0) { S.files.splice(i, 1); }
      drawChosen();
      drawCount();
    }

    /* ----- the folder read from the archive ----- */
    function read(dir, focus) {
      var token = ++S.token;
      S.loading = true;
      S.failed = '';
      say(loadError, '');
      draw();
      var call = dir ? FP.call('get', 'backupContentsAt', undefined, {name: a.username, archive: a.name, path: dir}) :
        FP.call('get', 'backupContents', undefined, {name: a.username, archive: a.name});
      call.then(function (r) {
        if (S.dead || token !== S.token) { return; }
        var c = clean(r);
        S.dir = dir;
        S.shown = PAGE;
        S.listing = c;
        S.loading = false;
        if (!S.seen) {
          S.seen = true;
          S.holds = {databases: c.databases, mail: c.mail};
          drawDatabases();
          drawMail();
        }
        draw();
        if (focus) { var here = form.querySelector('#fp-ars-here'); if (here) { here.focus(); } }
      }, function (err) {
        if (S.dead || token !== S.token) { return; }
        S.loading = false;
        /* a folder that fails to open leaves the one shown before it; the first read failing leaves an empty card with a retry */
        if (S.listing) { say(loadError, t('arst_read_failed', {why: err.message})); } else { S.failed = err.message; say(loadError, t('arst_read_failed', {why: err.message})); }
        draw();
        var b = form.querySelector('#fp-ars-retry') || form.querySelector('#fp-ars-here');
        if (b && focus) { b.focus(); }
      });
    }

    /* ----- databases ----- */
    function drawDatabases() {
      dbBox.textContent = '';
      dbBox.appendChild(el('legend', {class: 'sig-label', text: t('arst_databases')}));
      var any = false;
      ENGINES.forEach(function (en) {
        var names = S.holds.databases[en] || [];
        if (!names.length) { return; }
        any = true;
        dbBox.appendChild(el('p', {class: 'fp-ars-sub', text: t('arst_db_' + en)}));
        names.forEach(function (n, i) {
          var id = 'fp-ars-db-' + en + '-' + i;
          dbBox.appendChild(el('label', {class: 'fp-check', for: id}, [el('input', {type: 'checkbox', id: id, name: 'db-' + en, value: n,
            'data-fp-engine': en, checked: S.dbs[en].indexOf(n) >= 0 ? true : null}), el('span', {class: 'fp-ars-name', text: n})]));
        });
      });
      dbBox.appendChild(any ? el('span', {class: 'sig-hint', text: t('arst_db_hint')}) : el('p', {class: 'fp-muted', 'data-fp-ars-nodb': '', text: t('arst_db_none')}));
    }
    function drawMail() {
      mailBox.textContent = '';
      mailBox.appendChild(el('legend', {class: 'sig-label', text: t('arst_mail')}));
      if (!S.holds.mail.length) {
        mailBox.appendChild(el('p', {class: 'fp-muted', 'data-fp-ars-nomail': '', text: t('arst_mail_none')}));
        return;
      }
      S.holds.mail.forEach(function (m) {
        var id = 'fp-ars-mail-' + m;
        var known = MAIL_KNOWN.indexOf(m) >= 0;
        var label = known ? t('arst_mail_' + m) : m;
        mailBox.appendChild(el('label', {class: 'fp-check fp-ars-mailpick', for: id}, [el('input', {type: 'checkbox', id: id, name: 'mail', value: m,
          checked: S.mail.indexOf(m) >= 0 ? true : null, 'aria-describedby': known ? id + '-hint' : null}), el('span', {class: 'fp-ars-name', text: label})]));
        if (known) { mailBox.appendChild(el('span', {class: 'sig-hint fp-ars-hint', id: id + '-hint', text: t('arst_mail_' + m + '_hint')})); }
      });
    }

    /* ----- the choice, as it is now ----- */
    function mailLabel(m) { return MAIL_KNOWN.indexOf(m) >= 0 ? t('arst_mail_' + m) : m; }
    /* a copy of what is picked: the part -> items the API takes, and the lines the question shows. Nothing reads the boxes after this. */
    function snapshot() {
      var select = {};
      var lines = [];
      if (S.files.length) {
        select.home = S.files.slice();
        S.files.forEach(function (p) { lines.push({kind: t('arst_ask_files'), what: p, mono: true}); });
      }
      ENGINES.forEach(function (en) {
        if (!S.dbs[en].length) { return; }
        select[en] = S.dbs[en].slice();
        S.dbs[en].forEach(function (n) { lines.push({kind: t('arst_ask_' + en), what: n, mono: true}); });
      });
      if (S.mail.length) {
        select.mail = S.mail.slice();
        S.mail.forEach(function (m) { lines.push({kind: t('arst_ask_mail'), what: mailLabel(m), mono: false}); });
      }
      return {select: select, lines: lines, other: S.other};
    }

    /* ----- the question, and the send ----- */
    function resetActs() {
      acts.textContent = '';
      S.asking = false;
      picker.removeAttribute('inert');
      acts.appendChild(el('button', {class: 'sig-btn sig-btn--primary fp-submit', id: 'fp-ars-submit', type: 'submit', text: t('arst_restore')}));
      acts.appendChild(el('button', {class: 'sig-btn sig-btn--secondary', id: 'fp-ars-close', type: 'button', 'data-fp-act': 'close', text: t('cancel')}));
    }
    function ask(snap) {
      acts.textContent = '';
      S.asking = true;
      picker.setAttribute('inert', '');
      var id = 'fp-ars-ask';
      var lead = t(snap.other ? 'arst_ask_other' : 'arst_ask', {archive: a.name, account: a.username});
      var list = el('ul', {class: 'fp-ars-asklist'}, snap.lines.map(function (l) {
        return el('li', null, [el('span', {class: 'fp-ars-askkind', text: l.kind + ': '}), el('span', {class: l.mono ? 'sig-mono' : '', text: l.what})]);
      }));
      var yes = el('button', {class: 'sig-btn sig-btn--danger', id: 'fp-ars-yes', type: 'button', 'aria-describedby': id,
        text: snap.other ? t('arst_restore_anyway') : t('arst_restore_yes')});
      var no = el('button', {class: 'sig-btn sig-btn--secondary', id: 'fp-ars-no', type: 'button', 'aria-describedby': id, text: t('cancel')});
      acts.appendChild(el('div', {class: 'fp-ars-ask', id: id}, [el('p', {class: 'fp-mail-confirm fp-ars-asklead', 'data-fp-ars-ask': '', text: lead}), list]));
      acts.appendChild(yes);
      acts.appendChild(no);
      no.addEventListener('click', function () {
        resetActs();
        form.querySelector('#fp-ars-submit').focus();
      });
      yes.addEventListener('click', function () { send(yes, snap); });
      no.focus();
    }
    function send(yes, snap) {
      var body = {select: snap.select};
      if (snap.other) { body.other_account = true; }
      UI.setBusy(yes, true);
      FP.call('post', 'backupRestore', body, {name: a.username, archive: a.name}).then(function (r) {
        if (S.dead) { return; }
        r = r && typeof r === 'object' ? r : {};
        var said = [t('arst_started', {archive: a.name, account: a.username})];
        if (r.created === true) { said.push(t(r.password === 'reset' ? 'bk_made_reset' : 'bk_made_kept', {account: a.username})); }
        opts.onStarted(r, said.join(' '));
      }, function (err) {
        if (S.dead) { return; }
        var other = err.status === 409 && (err.code === 'other_account' || /other_account/.test(err.message || ''));
        resetActs();
        if (other && !snap.other) {
          /* the archive is of an earlier account: ask again, about the same items, saying so; a Yes then adds other_account */
          UI.showError(form, '');
          var again = {select: snap.select, lines: snap.lines, other: true};
          ask(again);
          return;
        }
        M.failed(form, err.field === 'select' || err.status === 400 || err.status === 422 ? {message: t('arst_refused', {why: err.message})} : err);
        if (!form.contains(document.activeElement)) { form.querySelector('#fp-ars-submit').focus(); }
      });
    }

    /* ---------- the path field ---------- */
    function addPath() {
      var p = pathInput.value.trim();
      if (p.length > 1 && p.charAt(p.length - 1) === '/') { p = p.slice(0, -1); }
      var why = p ? pathProblem(p) : 'bad';
      if (!why && S.files.indexOf(p) >= 0) { why = 'dupe'; }
      if (!why && S.files.length >= MAX_ITEMS) { why = 'many'; }
      if (why) {
        addErr.textContent = why === 'dupe' ? t('arst_path_dupe', {path: p}) : why === 'many' ? t('arst_too_many') : why === 'long' ? t('arst_path_long') : t('arst_path_bad');
        addErr.hidden = false;
        pathInput.setAttribute('aria-invalid', 'true');
        pathInput.setAttribute('aria-describedby', 'fp-ars-path-hint fp-ars-path-err');
        pathInput.focus();
        return;
      }
      clearPathError();
      pathInput.value = '';
      pick(p, true);
      /* a box in the folder shown that names it is ticked */
      var boxes = listBox.querySelectorAll('input[type="checkbox"][data-fp-path]');
      for (var i = 0; i < boxes.length; i++) { if (boxes[i].getAttribute('data-fp-path') === p) { boxes[i].checked = true; } }
      pathInput.focus();
    }
    function clearPathError() {
      addErr.hidden = true;
      addErr.textContent = '';
      pathInput.removeAttribute('aria-invalid');
      pathInput.setAttribute('aria-describedby', 'fp-ars-path-hint');
    }

    /* ---------- events ---------- */
    form.addEventListener('change', function (e) {
      var box = e.target;
      if (!box || box.type !== 'checkbox' || S.asking) { return; }
      if (box.hasAttribute('data-fp-path')) {
        var p = box.getAttribute('data-fp-path');
        if (box.checked && S.files.length >= MAX_ITEMS) {
          box.checked = false;
          say(loadError, t('arst_too_many'));
          return;
        }
        say(loadError, '');
        pick(p, box.checked);
      } else if (box.getAttribute('data-fp-engine')) {
        var list = S.dbs[box.getAttribute('data-fp-engine')];
        var at = list.indexOf(box.value);
        if (box.checked && at < 0) { list.push(box.value); }
        if (!box.checked && at >= 0) { list.splice(at, 1); }
        drawCount();
      } else if (box.name === 'mail') {
        var m = S.mail.indexOf(box.value);
        if (box.checked && m < 0) { S.mail.push(box.value); }
        if (!box.checked && m >= 0) { S.mail.splice(m, 1); }
        S.mail = S.holds.mail.filter(function (x) { return S.mail.indexOf(x) >= 0; });
        drawCount();
      }
    });
    pathInput.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); addPath(); }
      if (e.key === 'Escape' && pathInput.value) { e.stopPropagation(); pathInput.value = ''; clearPathError(); }
    });
    pathInput.addEventListener('input', function () { if (!addErr.hidden) { clearPathError(); } });
    form.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
      if (!b || !form.contains(b) || S.asking) { return; }
      var act = b.getAttribute('data-fp-act');
      var p = b.getAttribute('data-fp-path') || '';
      if (act === 'open-dir' || act === 'go') {
        read(p, true);
      } else if (act === 'reload') {
        read(S.dir, true);
      } else if (act === 'more') {
        var was = S.shown;
        S.shown += PAGE;
        drawList();
        var next = form.querySelector('#fp-ars-pick-' + was);
        (next || form.querySelector('#fp-ars-list')).focus();
      } else if (act === 'add-path') {
        addPath();
      } else if (act === 'unpick') {
        var rows = chosenBox.querySelectorAll('[data-fp-act="unpick"]');
        var idx = Array.prototype.indexOf.call(rows, b);
        pick(p, false);
        var boxes = listBox.querySelectorAll('input[type="checkbox"][data-fp-path]');
        for (var i = 0; i < boxes.length; i++) { if (boxes[i].getAttribute('data-fp-path') === p) { boxes[i].checked = false; } }
        var left = chosenBox.querySelectorAll('[data-fp-act="unpick"]');
        (left[Math.min(idx, left.length - 1)] || pathInput).focus();
      } else if (act === 'close') {
        S.dead = true;
        opts.onClose();
      }
    });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var go = M.start(form);
      if (!go) { return; }
      var snap = snapshot();
      if (!snap.lines.length) { M.fieldError(form, pathInput, t('arst_pick_some')); return; }
      ask(snap);
    });

    /* ---------- the card ---------- */
    var body = [head, el('p', {class: 'fp-ars-lead', text: t('arst_lead', {account: a.username})})];
    if (a.bytes !== null && a.bytes >= BIG) {
      body.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-ars-cost': 'big'}, [UI.icon(FP.ui, 'ui_warning'),
        el('span', {text: t('arst_cost_big', {size: FP.bk.size(a.bytes)})})]));
    } else {
      body.push(el('p', {class: 'sig-hint fp-ars-cost', 'data-fp-ars-cost': '', text: t('arst_cost')}));
    }
    if (opts.other) {
      body.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-ars-other': ''}, [UI.icon(FP.ui, 'ui_warning'),
        el('span', {text: t('arst_other', {account: a.username})})]));
    }
    form.appendChild(picker);
    form.appendChild(acts);
    body.push(form);
    var node = el('section', {class: 'sig-card fp-mail-card fp-bk-some', 'aria-labelledby': 'fp-ars-h'}, [el('div', {class: 'sig-card-body'}, body)]);
    drawChosen();
    drawCount();
    drawDatabases();
    drawMail();
    resetActs();
    read('', false);
    return {node: node, stop: function () { S.dead = true; }};
  }

  FP.restoreSome = {card: card};
})();

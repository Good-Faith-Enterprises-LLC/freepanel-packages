/* freePanel's administrator pages for three server tools (docs/api.md, "Server" and "Database map"): the memory limit of each service
   (#/tool/service_memory), which addresses may reach each service (#/tool/host_access), who may run the compilers and the traceroute programs (#/tool/tool_access), and the database map, an
   account's record of its databases and users set against MariaDB (#/tool/db_map). What a server answers is shown as text and the
   panel names a service, a tool or an account only by what the server's own list or the typed name gave it. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var UNIT_RE = /^[a-z0-9][a-z0-9@.-]{0,63}$/;
  var ACCOUNT_RE = /^[a-z][a-z0-9]{0,15}$/;
  var TOOLS = {compilers: 'ta_compilers', traceroute: 'ta_traceroute'};
  var ENGINES = [['mysql', 'dm_mariadb'], ['postgres', 'dm_postgres']];

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 64) : ''; }
  function num(v, hi) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.min(Math.floor(v), hi || 1e12) : 0; }
  function count(n) { return Math.round(n).toLocaleString('en'); }
  function admin() { return FP.realm === 'admin' && FP.session.user.role === 'admin'; }
  function frame(id, cls) {
    var tool = FP.tools[id];
    if (!tool || !admin()) { FP.views['not-found']({view: 'not-found'}); return null; }
    var g = FP.group(tool.group);
    return FP.frame({title: tool.label, desc: t(id + '_desc'), cls: 'fp-mail fp-at ' + cls,
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
  }
  function scopeOf(page, sel) { return page.querySelector(sel); }
  /* a button of a row: key is its slot, which stays put when the buttons change, so focus can go back to it */
  function button(act, text, label, unit, key, cls) {
    return el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm' + (cls ? ' ' + cls : ''), type: 'button', 'data-fp-act': act, 'data-fp-unit': unit, 'data-fp-key': key, 'aria-label': label, text: text});
  }
  function say(card, what) { M.say(card, what); }
  function mb(n) { return t('at_mb', {n: count(n)}); }

  /* ================= Service memory ================= */
  var S = null;
  function cleanMemory(r) {
    r = r && typeof r === 'object' ? r : {};
    var list = (Array.isArray(r.services) ? r.services : []).filter(function (v) { return v && typeof v.unit === 'string' && UNIT_RE.test(v.unit); }).map(function (v) {
      return {unit: v.unit, active: str(v.active, 32), own: v.protected === true, limit: num(v.limit_mb), live: num(v.live_max_mb), current: num(v.current_mb), applied: v.applied !== false};
    });
    return {list: list, min: num(r.min_mb, 1e7) || 64, max: num(r.max_mb, 1e8) || 1048576};
  }
  function smFind(unit) {
    for (var i = 0; i < S.list.length; i++) { if (S.list[i].unit === unit) { return S.list[i]; } }
    return null;
  }
  function smLimit(v) {
    if (v.own) { return t('sm_own'); }
    if (!v.limit) { return v.live ? t('sm_live_only', {mb: mb(v.live)}) : t('sm_none'); }
    return v.applied ? mb(v.limit) : t('sm_not_yet', {mb: mb(v.limit)});
  }
  function smActions(v) {
    if (v.own) { return [el('span', {class: 'fp-muted', text: t('sm_own_note')})]; }
    var n = FP.services.label(v.unit);
    var btns = [button('set', v.limit ? t('sm_change') : t('sm_set'), t(v.limit ? 'sm_change_of' : 'sm_set_of', {name: n}), v.unit, 'limit')];
    if (v.limit) { btns.push(button('remove', t('sm_remove'), t('sm_remove_of', {name: n}), v.unit, 'remove', 'fp-btn-danger-text')); }
    return [el('div', {class: 'fp-at-btns'}, btns)];
  }
  function smRow(v) {
    var running = v.active === 'active';
    return el('tr', {'data-fp-service': v.unit}, [
      el('th', {scope: 'row'}, [el('span', {class: 'fp-srv-name', text: FP.services.label(v.unit)}), el('span', {class: 'sig-mono fp-muted fp-srv-unit', text: v.unit})]),
      el('td', {class: 'fp-num', text: running ? mb(v.current) : '—'}),
      el('td', {class: 'fp-at-limit', 'data-fp-limit': ''}, [el('span', {class: v.limit && !v.applied ? 'fp-at-warn' : '', text: smLimit(v)})]),
      el('td', {class: 'fp-at-acts'}, smActions(v))]);
  }
  function smCard() {
    var parts = [el('p', {class: 'fp-muted', text: t('sm_what')}), M.errorLine(), M.statusLine()];
    if (!S.list.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('sm_none_listed')}));
    } else {
      parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'refresh', text: t('status_again')})]),
        el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-sm-h'}, [
          el('table', {class: 'sig-table fp-mail-table fp-srv-table fp-sm-table'}, [el('thead', null, [el('tr', null, [
            el('th', {scope: 'col', text: t('svc_service')}), el('th', {scope: 'col', class: 'fp-num', text: t('sm_using')}), el('th', {scope: 'col', text: t('sm_limit')}),
            el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('acct_actions')})])])]),
          el('tbody', null, S.list.map(smRow))])]));
      parts.push(el('p', {class: 'fp-muted', text: t('sm_note')}));
    }
    return M.card('fp-sm-h', t('sm_title'), parts, 'fp-sm');
  }
  function smDraw(focus) {
    var old = S.page.querySelector('.fp-sm');
    var made = smCard();
    if (old) { old.replaceWith(made); } else { S.page.appendChild(made); }
    var target = focus ? S.page.querySelector(focus) : null;
    if (target) { target.focus(); }
  }
  function smLoad() {
    var mine = S;
    return FP.call('get', 'serverServiceMemory').then(function (r) {
      if (S !== mine) { return null; }
      var c = cleanMemory(r);
      S.list = c.list; S.min = c.min; S.max = c.max;
      return S.list;
    });
  }
  function smSlot(unit, key) { return '[data-fp-service="' + unit + '"] [data-fp-key="' + key + '"]'; }
  function smEdit(unit, b) {
    var v = smFind(unit);
    var cell = b.closest('.fp-at-acts');
    var id = 'fp-sm-' + unit.replace(/[^a-z0-9]/g, '-');
    var input = el('input', {class: 'sig-input fp-at-num', id: id, name: 'max_mb', type: 'number', inputmode: 'numeric', min: String(S.min), max: String(S.max), step: '1',
      value: v.limit ? String(v.limit) : '', autocomplete: 'off', 'aria-describedby': id + '-hint'});
    var form = el('form', {class: 'fp-at-edit', 'data-fp-edit': unit, novalidate: ''}, [
      el('label', {class: 'sig-label fp-at-edit-l', for: id, text: t('sm_edit_label', {name: FP.services.label(unit)})}),
      el('div', {class: 'fp-at-edit-row'}, [input, el('span', {class: 'fp-muted', text: t('at_mb_unit')}),
        el('button', {class: 'sig-btn sig-btn--primary sig-btn--sm fp-submit', type: 'submit', text: t('at_save')}),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'edit-no', text: t('cancel')})]),
      el('span', {class: 'sig-hint', id: id + '-hint', text: t('sm_edit_hint', {min: count(S.min), max: count(S.max)})}),
      el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': ''})]);
    cell.textContent = '';
    cell.appendChild(form);
    input.focus();
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var go = M.start(form);
      if (!go) { return; }
      var raw = input.value.trim();
      var n = Number(raw);
      if (!/^[0-9]{1,8}$/.test(raw) || n < S.min || n > S.max) { M.fieldError(form, input, t('sm_bad', {min: count(S.min), max: count(S.max)})); return; }
      smChange(unit, n, go, form);
    });
  }
  function smChange(unit, n, go, form) {
    var mine = S;
    var name = FP.services.label(unit);
    UI.setBusy(go, true);
    FP.call('put', 'serverServiceMemory', {unit: unit, max_mb: n}).then(function (r) {
      if (S !== mine) { return; }
      var got = r && r.service && typeof r.service === 'object' ? r.service : null;
      var applied = !got || got.applied !== false;
      return smLoad().then(function () {
        if (S !== mine) { return; }
        smDraw(smSlot(unit, 'limit'));
        if (n === 0) { say(scopeOf(S.page, '.fp-sm'), t('sm_removed', {name: name})); } else if (applied) { say(scopeOf(S.page, '.fp-sm'), t('sm_done', {name: name, mb: mb(n)})); } else {
          UI.showError(scopeOf(S.page, '.fp-sm'), t('sm_saved_not_live', {name: name, mb: mb(n)}));
        }
      });
    }, function (err) {
      if (S !== mine) { return; }
      UI.setBusy(go, false);
      if (form && form.isConnected) { M.failed(form, err); return; }
      UI.showError(scopeOf(S.page, '.fp-sm'), err && err.message ? err.message : t('api_failed'));
    });
  }
  function smClick(e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !S || !S.page.contains(b) || b.disabled) { return; }
    var a = b.getAttribute('data-fp-act');
    var tr = b.closest('tr[data-fp-service]');
    var unit = tr ? tr.getAttribute('data-fp-service') : '';
    if (a === 'refresh') {
      var mine = S;
      UI.setBusy(b, true);
      smLoad().then(function () {
        if (S !== mine) { return; }
        smDraw('[data-fp-act="refresh"]');
        say(scopeOf(S.page, '.fp-sm'), t('status_checked', {when: new Date().toLocaleTimeString('en', {timeStyle: 'short'})}));
      }, function (err) {
        if (S !== mine) { return; }
        UI.setBusy(b, false);
        UI.showError(scopeOf(S.page, '.fp-sm'), err.message);
        b.focus();
      });
      return;
    }
    if (!unit || !smFind(unit)) { return; }
    if (a === 'set') {
      smEdit(unit, b);
    } else if (a === 'edit-no') {
      var cell = tr.querySelector('.fp-at-acts');
      cell.textContent = '';
      smActions(smFind(unit)).forEach(function (n) { cell.appendChild(n); });
      var back = cell.querySelector('[data-fp-key="limit"]');
      if (back) { back.focus(); }
    } else if (a === 'remove') {
      var holder = b.closest('.fp-at-btns');
      M.confirmIn(holder, t('sm_ask_remove', {name: FP.services.label(unit)}), 'remove-yes', t('sm_remove'));
    } else if (a === 'remove-yes') {
      UI.setBusy(b, true);
      UI.showError(scopeOf(S.page, '.fp-sm'), '');
      smChange(unit, 0, b, null);
    } else if (a === 'confirm-no') {
      var c2 = tr.querySelector('.fp-at-acts');
      c2.textContent = '';
      smActions(smFind(unit)).forEach(function (n) { c2.appendChild(n); });
      var again = c2.querySelector('[data-fp-key="remove"]');
      if (again) { again.focus(); }
    }
  }
  document.addEventListener('click', smClick);
  FP.view('tool:service_memory', function () {
    S = null;
    var page = frame('service_memory', 'fp-sm-page');
    if (!page) { return; }
    S = {page: page, list: [], min: 64, max: 1048576};
    var mine = S;
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    smLoad().then(function () {
      if (S !== mine) { return; }
      page.textContent = '';
      smDraw();
    }, function (err) {
      if (S !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(FP.tools.service_memory.label, err.message));
    });
  });

  /* ================= Compiler and traceroute access ================= */
  var T = null;
  function cleanTools(r) {
    return (r && Array.isArray(r.tools) ? r.tools : []).filter(function (x) { return x && typeof x.tool === 'string' && TOOLS[x.tool]; }).map(function (x) {
      return {tool: x.tool, programs: (Array.isArray(x.programs) ? x.programs : []).filter(function (p) { return typeof p === 'string' && /^[A-Za-z0-9+._-]{1,32}$/.test(p); }).slice(0, 40),
        restricted: x.restricted === true, drifted: x.drifted === true};
    });
  }
  function taFind(tool) {
    for (var i = 0; i < T.list.length; i++) { if (T.list[i].tool === tool) { return T.list[i]; } }
    return null;
  }
  function taState(x) {
    if (!x.programs.length) { return ['', 'ta_absent']; }
    if (x.restricted && x.drifted) { return ['warn', 'ta_drifted']; }
    return x.restricted ? ['ok', 'ta_restricted'] : ['', 'ta_open'];
  }
  function taActions(x) {
    var n = t(TOOLS[x.tool]);
    if (!x.programs.length) { return [el('span', {class: 'fp-muted', text: t('ta_absent_note')})]; }
    var btns = [];
    if (!x.restricted) {
      btns.push(button('restrict', t('ta_restrict'), t('ta_restrict_of', {name: n.toLowerCase()}), x.tool, 'change'));
    } else {
      if (x.drifted) { btns.push(button('restrict-again', t('ta_again'), t('ta_again_of', {name: n.toLowerCase()}), x.tool, 'change')); }
      btns.push(button('allow', t('ta_allow'), t('ta_allow_of', {name: n.toLowerCase()}), x.tool, x.drifted ? 'other' : 'change'));
    }
    return [el('div', {class: 'fp-at-btns'}, btns)];
  }
  function taRow(x) {
    var s = taState(x);
    return el('tr', {'data-fp-tool': x.tool}, [
      el('th', {scope: 'row'}, [el('span', {class: 'fp-srv-name', text: t(TOOLS[x.tool])}), el('span', {class: 'fp-muted fp-srv-unit', text: t(TOOLS[x.tool] + '_what')})]),
      el('td', {class: 'sig-mono fp-at-programs', text: x.programs.length ? x.programs.join(', ') : '—'}),
      el('td', null, [el('span', {class: 'sig-pill' + (s[0] ? ' sig-pill--' + s[0] : ''), 'data-fp-state': '', text: t(s[1])})]),
      el('td', {class: 'fp-at-acts'}, taActions(x))]);
  }
  function taCard() {
    var parts = [el('p', {class: 'fp-muted', text: t('ta_what')}), M.errorLine(), M.statusLine()];
    if (!T.list.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('ta_none_listed')}));
    } else {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-ta-h'}, [
        el('table', {class: 'sig-table fp-mail-table fp-srv-table fp-ta-table'}, [el('thead', null, [el('tr', null, [
          el('th', {scope: 'col', text: t('ta_tool')}), el('th', {scope: 'col', text: t('ta_programs')}), el('th', {scope: 'col', text: t('svc_state')}),
          el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('acct_actions')})])])]),
        el('tbody', null, T.list.map(taRow))])]));
      parts.push(el('p', {class: 'fp-muted', text: t('ta_note')}));
    }
    return M.card('fp-ta-h', t('ta_title'), parts, 'fp-ta');
  }
  function taDraw(focus) {
    var old = T.page.querySelector('.fp-ta');
    var made = taCard();
    if (old) { old.replaceWith(made); } else { T.page.appendChild(made); }
    var target = focus ? T.page.querySelector(focus) : null;
    if (target) { target.focus(); }
  }
  function taLoad() {
    var mine = T;
    return FP.call('get', 'serverToolAccess').then(function (r) {
      if (T !== mine) { return null; }
      T.list = cleanTools(r);
      return T.list;
    });
  }
  function taChange(tool, restricted, b) {
    var mine = T;
    var card = T.page.querySelector('.fp-ta');
    var name = t(TOOLS[tool]).toLowerCase();
    UI.setBusy(b, true);
    UI.showError(card, '');
    say(card, t(restricted ? 'ta_doing_restrict' : 'ta_doing_allow', {name: name}));
    FP.call('put', 'serverToolAccess', {tool: tool, restricted: restricted}).then(function () {
      if (T !== mine) { return null; }
      return taLoad().then(function () {
        if (T !== mine) { return; }
        taDraw('[data-fp-tool="' + tool + '"] [data-fp-key="change"]');
        say(T.page.querySelector('.fp-ta'), t(restricted ? 'ta_done_restrict' : 'ta_done_allow', {name: name}));
      });
    }, function (err) {
      if (T !== mine) { return; }
      taLoad().then(function () {}, function () {}).then(function () {
        if (T !== mine) { return; }
        taDraw('[data-fp-tool="' + tool + '"] [data-fp-key="change"], #fp-ta-h');
        UI.showError(T.page.querySelector('.fp-ta'), err && err.message ? err.message : t('api_failed'));
      });
    });
  }
  function taClick(e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !T || !T.page.contains(b) || b.disabled) { return; }
    var a = b.getAttribute('data-fp-act');
    var tr = b.closest('tr[data-fp-tool]');
    var tool = tr ? tr.getAttribute('data-fp-tool') : '';
    var x = tool ? taFind(tool) : null;
    if (!x) { return; }
    if (a === 'restrict') {
      M.confirmIn(b.closest('.fp-at-btns'), t('ta_ask_restrict', {name: t(TOOLS[tool]).toLowerCase()}), 'restrict-yes', t('ta_restrict'));
    } else if (a === 'restrict-yes' || a === 'restrict-again') {
      taChange(tool, true, b);
    } else if (a === 'allow') {
      taChange(tool, false, b);
    } else if (a === 'confirm-no') {
      var cell = tr.querySelector('.fp-at-acts');
      cell.textContent = '';
      taActions(x).forEach(function (n) { cell.appendChild(n); });
      var back = cell.querySelector('[data-fp-key="change"]');
      if (back) { back.focus(); }
    }
  }
  document.addEventListener('click', taClick);
  FP.view('tool:tool_access', function () {
    T = null;
    var page = frame('tool_access', 'fp-ta-page');
    if (!page) { return; }
    T = {page: page, list: []};
    var mine = T;
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    taLoad().then(function () {
      if (T !== mine) { return; }
      page.textContent = '';
      taDraw();
    }, function (err) {
      if (T !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(FP.tools.tool_access.label, err.message));
    });
  });

  /* ================= Database map ================= */
  var D = null;
  function cleanGrants(l) {
    return (Array.isArray(l) ? l : []).slice(0, 200).filter(function (g) { return g && typeof g.user === 'string' && typeof g.database === 'string'; }).map(function (g) {
      return {user: g.user.slice(0, 80), database: g.database.slice(0, 80), privileges: (Array.isArray(g.privileges) ? g.privileges : []).filter(function (p) { return typeof p === 'string'; }).map(function (p) { return p.slice(0, 40); }).slice(0, 30)};
    });
  }
  function cleanNames(l) { return (Array.isArray(l) ? l : []).slice(0, 500).filter(function (n) { return typeof n === 'string' && n; }).map(function (n) { return n.slice(0, 80); }); }
  function cleanReport(r) {
    r = r && typeof r === 'object' ? r : {};
    return {account: str(r.account, 16), engine: 'mysql', databases: cleanNames(r.missing_databases), users: cleanNames(r.missing_users), grants: cleanGrants(r.foreign_grants),
      clean: r.clean === true, repaired: r.repaired === true, remaining: cleanGrants(r.remaining)};
  }
  function dList(label, items, render) {
    return el('div', {class: 'fp-dm-block'}, [el('h3', {class: 'fp-h3', text: label}), el('ul', {class: 'fp-dm-list'}, items.map(function (x) { return el('li', null, render(x)); }))]);
  }
  function dReport(rep) {
    var parts = [];
    if (rep.repaired) {
      parts.push(el('p', {'data-fp-dm-summary': '', text: rep.clean ? t('dm_repaired', {nd: String(rep.databases.length), nu: String(rep.users.length), ng: String(rep.grants.length - rep.remaining.length)}) :
        t('dm_repaired_left', {n: String(rep.remaining.length)})}));
    } else if (rep.clean) {
      parts.push(el('p', {'data-fp-dm-summary': '', text: t('dm_clean', {account: rep.account})}));
    } else {
      parts.push(el('p', {'data-fp-dm-summary': '', text: t('dm_found', {account: rep.account})}));
    }
    var show = rep.repaired ? {databases: rep.databases, users: rep.users, grants: rep.remaining} : {databases: rep.databases, users: rep.users, grants: rep.grants};
    if (show.databases.length) { parts.push(dList(t(rep.repaired ? 'dm_removed_dbs' : 'dm_missing_dbs'), show.databases, function (n) { return [el('span', {class: 'sig-mono', text: n})]; })); }
    if (show.users.length) { parts.push(dList(t(rep.repaired ? 'dm_removed_users' : 'dm_missing_users'), show.users, function (n) { return [el('span', {class: 'sig-mono', text: n})]; })); }
    if (show.grants.length) {
      parts.push(dList(t(rep.repaired ? 'dm_left_grants' : 'dm_foreign'), show.grants, function (g) {
        return [el('span', {class: 'sig-mono', text: g.user}), ' → ', el('span', {class: 'sig-mono', text: g.database}), g.privileges.length ? el('span', {class: 'fp-muted', text: ' (' + g.privileges.join(', ') + ')'}) : null];
      }));
    }
    if (!rep.repaired && !rep.clean) { parts.push(M.errorLine()); }
    if (!rep.repaired && !rep.clean) { parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'dm-repair', text: t('dm_repair')})])); }
    if (!rep.repaired && !rep.clean) { parts.push(el('p', {class: 'fp-muted', text: t('dm_repair_note')})); }
    return parts;
  }
  function dmDrawReport(focus) {
    var host = D.page.querySelector('.fp-dm-result');
    var made = D.report ? M.card('fp-dm-result-h', t('dm_result_title', {account: D.report.account}), dReport(D.report), 'fp-dm-result') : null;
    if (host) { host.remove(); }
    if (made) {
      D.page.appendChild(made);
      if (focus) { made.querySelector(focus).focus(); }
    }
  }
  function dmCheck(form, input, engine, go) {
    var mine = D;
    var account = input.value.trim();
    UI.setBusy(go, true);
    FP.call('get', 'dbMap', undefined, {account: account, engine: engine}).then(function (r) {
      if (D !== mine) { return; }
      UI.setBusy(go, false);
      D.report = cleanReport(r);
      D.report.account = D.report.account || account;
      D.report.engine = engine;
      dmDrawReport('#fp-dm-result-h');
      UI.announce(t(D.report.clean ? 'dm_announce_clean' : 'dm_announce_found'));
    }, function (err) {
      if (D !== mine) { return; }
      UI.setBusy(go, false);
      D.report = null;
      dmDrawReport('');
      M.failed(form, err);
    });
  }
  function dmRepair(b) {
    var mine = D;
    var rep = D.report;
    var card = D.page.querySelector('.fp-dm-result');
    UI.setBusy(b, true);
    UI.showError(card, '');
    FP.call('post', 'dbMapRepair', {account: rep.account, engine: rep.engine}).then(function (r) {
      if (D !== mine) { return; }
      var got = cleanReport(r);
      got.account = got.account || rep.account;
      got.engine = rep.engine;
      D.report = got;
      dmDrawReport('#fp-dm-result-h');
      UI.announce(t('dm_announce_repaired'));
    }, function (err) {
      if (D !== mine) { return; }
      UI.setBusy(b, false);
      UI.showError(card, err && err.message ? err.message : t('api_failed'));
    });
  }
  function dmClick(e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act="dm-repair"], [data-fp-act="dm-repair-yes"], [data-fp-act="dm-no"]') : null;
    if (!b || !D || !D.page.contains(b) || b.disabled) { return; }
    var a = b.getAttribute('data-fp-act');
    var holder = b.closest('.fp-actions');
    if (a === 'dm-repair') {
      M.confirmIn(holder, t('dm_ask_repair', {account: D.report.account}), 'dm-repair-yes', t('dm_repair'));
      holder.querySelector('[data-fp-act="confirm-no"]').setAttribute('data-fp-act', 'dm-no');
    } else if (a === 'dm-repair-yes') {
      dmRepair(b);
    } else if (a === 'dm-no') {
      holder.textContent = '';
      var again = el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'dm-repair', text: t('dm_repair')});
      holder.appendChild(again);
      again.focus();
    }
  }
  document.addEventListener('click', dmClick);
  FP.view('tool:db_map', function () {
    D = null;
    var page = frame('db_map', 'fp-dm-page');
    if (!page) { return; }
    D = {page: page, report: null};
    var input = el('input', {class: 'sig-input', id: 'fp-dm-account', name: 'account', type: 'text', maxlength: '16', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false', 'aria-describedby': 'fp-dm-account-hint'});
    var engine = el('select', {class: 'sig-select', id: 'fp-dm-engine', name: 'engine'}, ENGINES.map(function (e) { return el('option', {value: e[0], text: t(e[1])}); }));
    var form = el('form', {class: 'fp-dm-form', novalidate: ''}, [
      el('p', {class: 'fp-muted', text: t('dm_what')}),
      M.field('fp-dm-engine', t('dm_engine'), engine),
      M.field('fp-dm-account', t('dm_account'), input, t('dm_account_hint')),
      el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': ''}),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('dm_check')})])]);
    page.appendChild(M.card('fp-dm-h', t('dm_title'), [form], 'fp-dm-form-card'));
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var go = M.start(form);
      if (!go) { return; }
      var account = input.value.trim();
      if (!ACCOUNT_RE.test(account)) { M.fieldError(form, input, t('dm_bad_account')); return; }
      dmCheck(form, input, engine.value, go);
    });
  });
  /* ================= Who can reach each service, by address ================= */
  var HA = null;
  var HA_ACTIONS = ['allow', 'deny'];
  var HA_SOURCE_RE = /^(all|[0-9A-Fa-f:.]{2,39}(\/\d{1,3})?)$/i;
  function cleanHA(r) {
    r = r && typeof r === 'object' ? r : {};
    var services = (Array.isArray(r.services) ? r.services : []).filter(function (x) { return x && typeof x.id === 'string' && /^[a-z0-9_]{1,16}$/.test(x.id); }).map(function (x) {
      return {id: x.id, label: str(x.label, 80), ports: (Array.isArray(x.ports) ? x.ports : []).map(function (p) { return num(p, 65535); }).filter(Boolean).slice(0, 20)};
    });
    var known = {};
    services.forEach(function (x) { known[x.id] = x; });
    var rules = (Array.isArray(r.rules) ? r.rules : []).filter(function (x) {
      return x && known[x.service] && HA_ACTIONS.indexOf(x.action) >= 0 && typeof x.source === 'string' && HA_SOURCE_RE.test(x.source);
    }).slice(0, 500).map(function (x) { return {service: x.service, source: x.source, action: x.action, note: str(x.note, 200)}; });
    return {services: services, known: known, rules: rules, active: r.active === true, pending: str(r.pending, 300)};
  }
  function haPorts(x) { return x && x.ports.length ? x.ports.join(', ') : t('ha_no_ports'); }
  function haRow(x, i) {
    var n = HA.rules.length;
    var svc = HA.known[x.service];
    var btns = [];
    if (i > 0) { btns.push(button('ha-up', t('ha_up'), t('ha_up_of', {n: i + 1}), String(i), 'up')); }
    if (i < n - 1) { btns.push(button('ha-down', t('ha_down'), t('ha_down_of', {n: i + 1}), String(i), 'down')); }
    btns.push(button('ha-remove', t('ha_remove'), t('ha_remove_of', {n: i + 1}), String(i), 'remove', 'fp-btn-danger-text'));
    return el('tr', {'data-fp-rule': String(i)}, [
      el('td', {class: 'fp-num', text: String(i + 1)}),
      el('th', {scope: 'row'}, [el('span', {class: 'fp-srv-name', text: svc.label}), el('span', {class: 'fp-muted fp-srv-unit', text: t('ha_ports', {ports: haPorts(svc)})})]),
      el('td', {class: 'sig-mono', text: x.source === 'all' ? t('ha_everyone') : x.source}),
      el('td', null, [el('span', {class: 'sig-pill sig-pill--' + (x.action === 'allow' ? 'ok' : 'warn'), text: t(x.action === 'allow' ? 'ha_allow' : 'ha_deny')})]),
      el('td', {text: x.note || '—'}),
      el('td', {class: 'fp-at-acts'}, [el('div', {class: 'fp-at-btns'}, btns)])]);
  }
  function haCard() {
    var status = HA.pending ? t('ha_pending', {why: HA.pending}) : (HA.rules.length ? (HA.active ? t('ha_active') : t('ha_not_active')) : t('ha_none'));
    var parts = [el('p', {class: 'fp-muted', text: t('ha_what')}), el('p', {'data-fp-ha-state': '', text: status}), M.errorLine(), M.statusLine()];
    if (HA.rules.length) {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-ha-h'}, [
        el('table', {class: 'sig-table fp-mail-table fp-srv-table fp-ha-table'}, [el('thead', null, [el('tr', null, [
          el('th', {scope: 'col', class: 'fp-num', text: t('ha_order')}), el('th', {scope: 'col', text: t('ha_service')}), el('th', {scope: 'col', text: t('ha_source')}),
          el('th', {scope: 'col', text: t('ha_action')}), el('th', {scope: 'col', text: t('ha_note')}),
          el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('acct_actions')})])])]),
        el('tbody', null, HA.rules.map(haRow))])]));
    }
    parts.push(el('p', {class: 'fp-muted', text: t('ha_order_note')}));
    return M.card('fp-ha-h', t('ha_title'), parts, 'fp-ha');
  }
  function haForm() {
    var service = el('select', {class: 'sig-select', id: 'fp-ha-service', name: 'service'}, HA.services.map(function (x) {
      return el('option', {value: x.id, text: x.label + ' (' + haPorts(x) + ')'});
    }));
    var source = el('input', {class: 'sig-input', id: 'fp-ha-source', name: 'source', type: 'text', maxlength: '43', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false', 'aria-describedby': 'fp-ha-source-hint'});
    var action = el('select', {class: 'sig-select', id: 'fp-ha-action', name: 'action'}, [el('option', {value: 'allow', text: t('ha_allow')}), el('option', {value: 'deny', text: t('ha_deny')})]);
    var note = el('input', {class: 'sig-input', id: 'fp-ha-note', name: 'note', type: 'text', maxlength: '200', autocomplete: 'off'});
    var form = el('form', {class: 'fp-ha-form', novalidate: ''}, [
      M.field('fp-ha-service', t('ha_service'), service),
      M.field('fp-ha-source', t('ha_source'), source, t('ha_source_hint')),
      M.field('fp-ha-action', t('ha_action'), action),
      M.field('fp-ha-note', t('ha_note'), note),
      el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': ''}),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('ha_add')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var go = M.start(form);
      if (!go) { return; }
      var src = source.value.trim();
      if (!HA_SOURCE_RE.test(src)) { M.fieldError(form, source, t('ha_bad_source')); return; }
      var next = HA.rules.concat([{service: service.value, source: src.toLowerCase() === 'all' ? 'all' : src, action: action.value, note: note.value.trim()}]);
      haSave(next, go, form, function () { source.value = ''; note.value = ''; source.focus(); });
    });
    return M.card('fp-ha-add-h', t('ha_add_title'), [form], 'fp-ha-add');
  }
  function haDraw(focus) {
    var old = HA.page.querySelector('.fp-ha');
    var made = haCard();
    if (old) { old.replaceWith(made); } else { HA.page.insertBefore(made, HA.page.firstChild); }
    if (!HA.page.querySelector('.fp-ha-add')) { HA.page.appendChild(haForm()); }
    var target = focus ? HA.page.querySelector(focus) : null;
    if (target) { target.focus(); }
  }
  function haSave(rules, b, errAt, done, focus) {
    var mine = HA;
    UI.setBusy(b, true);
    UI.showError(errAt, '');
    FP.call('put', 'serverHostAccess', {rules: rules}).then(function (r) {
      if (HA !== mine) { return; }
      UI.setBusy(b, false);
      var keep = HA.services;
      HA = Object.assign(mine, cleanHA(r));
      if (!HA.services.length) { HA.services = keep; }
      haDraw(focus);
      say(HA.page.querySelector('.fp-ha'), t('ha_saved'));
      if (done) { done(); }
    }, function (err) {
      if (HA !== mine) { return; }
      UI.setBusy(b, false);
      UI.showError(errAt, err && err.message ? err.message : t('api_failed'));
    });
  }
  function haClick(e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act^="ha-"]') : null;
    if (!b || !HA || !HA.page.contains(b) || b.disabled) { return; }
    var a = b.getAttribute('data-fp-act');
    var i = parseInt(b.getAttribute('data-fp-unit'), 10);
    if (!(i >= 0 && i < HA.rules.length)) { return; }
    var card = HA.page.querySelector('.fp-ha');
    var next = HA.rules.slice();
    if (a === 'ha-up' && i > 0) {
      next.splice(i - 1, 0, next.splice(i, 1)[0]);
      haSave(next, b, card, null, '[data-fp-rule="' + (i - 1) + '"] [data-fp-key="up"], [data-fp-rule="' + (i - 1) + '"] [data-fp-key="down"]');
    } else if (a === 'ha-down' && i < next.length - 1) {
      next.splice(i + 1, 0, next.splice(i, 1)[0]);
      haSave(next, b, card, null, '[data-fp-rule="' + (i + 1) + '"] [data-fp-key="down"], [data-fp-rule="' + (i + 1) + '"] [data-fp-key="up"]');
    } else if (a === 'ha-remove') {
      next.splice(i, 1);
      haSave(next, b, card, null, '#fp-ha-h');
    }
  }
  document.addEventListener('click', haClick);
  FP.view('tool:host_access', function () {
    HA = null;
    var page = frame('host_access', 'fp-ha-page');
    if (!page) { return; }
    HA = {page: page, services: [], known: {}, rules: []};
    var mine = HA;
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'serverHostAccess').then(function (r) {
      if (HA !== mine) { return; }
      Object.assign(mine, cleanHA(r));
      page.textContent = '';
      haDraw();
    }, function (err) {
      if (HA !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(FP.tools.host_access.label, err.message));
    });
  });
})();

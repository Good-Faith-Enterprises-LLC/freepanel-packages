/* freePanel system packages (#/tool/server_packages), the admin panel's page for the distribution's own packages (docs/api.md,
   "System packages"): search the repositories the server has, see a package, install or remove one after seeing what the
   package manager would do, the job that runs it with the end of its output, what is installed, and the log of what was done
   from here. apt on Ubuntu and Debian, dnf on AlmaLinux and the like; the server picks. The packages the panel needs can't be
   removed here, and those that would take over one of its services can't be installed. Everything the package manager and
   the repositories say (names, versions, summaries, output) is shown as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var POLL_MS = 3000;
  var MAX_ROWS = 100;
  var MAX_SHOWN = 200;
  var MAX_LOG = 200;
  var NAME_RE = /^[A-Za-z0-9][A-Za-z0-9._+-]{0,99}$/;
  var STATES = ['idle', 'running', 'succeeded', 'failed'];
  var ACTIONS = ['install', 'remove', 'refresh', 'rebuild'];
  var UNITS = ['KB', 'MB', 'GB', 'TB'];
  var CARDS = ['fp-spk-status', 'fp-spk-search', 'fp-spk-info', 'fp-spk-plan', 'fp-spk-job', 'fp-spk-installed', 'fp-spk-history'];

  var S = null;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 400) : ''; }
  function obj(v) { return v && typeof v === 'object' ? v : {}; }
  function num(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.floor(v) : 0; }
  function list(v) { return Array.isArray(v) ? v : []; }
  function when(iso) {
    var d = typeof iso === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(iso) ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }
  function size(n) {
    if (!n) { return '—'; }
    if (n < 1024) { return t('size_bytes', {n: String(n)}); }
    var u = -1;
    do { n /= 1024; u++; } while (n >= 1024 && u < UNITS.length - 1);
    return (n < 10 ? n.toFixed(1) : Math.round(n).toLocaleString('en')) + ' ' + UNITS[u];
  }
  function names(v) { return list(v).filter(function (n) { return typeof n === 'string' && NAME_RE.test(n); }).slice(0, 10); }

  /* ---------- what the server says, kept to the shapes the page draws ---------- */
  function cleanPkg(p) {
    p = obj(p);
    if (!NAME_RE.test(str(p.name))) { return null; }
    return {name: p.name, version: str(p.version, 200), arch: str(p.arch, 40), summary: str(p.summary), repo: str(p.repo, 100), size: num(p.size),
      installed: str(p.installed, 200), protected: p.protected === true, noInstall: p.no_install === true};
  }
  function cleanJob(j) {
    j = obj(j);
    return {state: STATES.indexOf(j.state) >= 0 ? j.state : 'idle', action: ACTIONS.indexOf(j.action) >= 0 ? j.action : '', packages: names(j.packages),
      by: str(j.by, 64), started: str(j.started), ended: str(j.ended), exit: typeof j.exit_code === 'number' && isFinite(j.exit_code) ? Math.floor(j.exit_code) : null,
      timedOut: j.timed_out === true, log: list(j.log).filter(function (l) { return typeof l === 'string'; }).slice(-MAX_LOG).map(function (l) { return l.slice(0, 400); }),
      truncated: j.log_truncated === true};
  }
  function cleanStatus(r) {
    r = obj(r);
    return {supported: r.supported === true, family: r.family === 'apt' || r.family === 'dnf' ? r.family : '', reason: str(r.reason), checked: str(r.checked),
      busy: r.busy === true, job: cleanJob(r.job)};
  }
  function cleanChanges(v) {
    return list(v).map(obj).filter(function (c) { return NAME_RE.test(str(c.name)); }).slice(0, 500).map(function (c) { return {name: c.name, version: str(c.version, 200)}; });
  }
  function cleanPlan(p) {
    p = obj(p);
    return {action: p.action === 'remove' ? 'remove' : 'install', names: names(p.names), install: cleanChanges(p.install), upgrade: cleanChanges(p.upgrade),
      remove: cleanChanges(p.remove), download: str(p.download, 40), disk: str(p.disk, 40), refused: names(p.refused), why: str(p.why, 600), nothing: p.nothing === true};
  }
  function cleanInfo(i) {
    var p = cleanPkg(i);
    if (!p) { return null; }
    i = obj(i);
    p.description = str(i.description, 4000);
    p.installedSize = num(i.installed_size);
    p.license = str(i.license);
    p.url = str(i.url);
    p.section = str(i.section, 100);
    p.maintainer = str(i.maintainer);
    p.depends = list(i.depends).filter(function (d) { return typeof d === 'string'; }).slice(0, 100).map(function (d) { return d.slice(0, 200); });
    return p;
  }
  function cleanEntry(e) {
    e = obj(e);
    return {action: ACTIONS.indexOf(e.action) >= 0 ? e.action : '', packages: names(e.packages), by: str(e.by, 64), started: str(e.started),
      state: STATES.indexOf(e.state) >= 0 ? e.state : 'running', exit: typeof e.exit_code === 'number' ? Math.floor(e.exit_code) : null};
  }
  function running() { return S.status.busy || S.status.job.state === 'running'; }

  /* ---------- the cards ---------- */
  function statusCard() {
    var d = S.status;
    var parts = [M.errorLine(), M.statusLine()];
    if (!d.supported) {
      parts.push(el('p', {'data-fp-unsupported': '', text: d.reason ? t('spk_unsupported_why', {why: d.reason}) : t('spk_unsupported')}));
      return M.card('fp-spk-status-h', t('spk_title'), parts, 'fp-spk-status');
    }
    parts.push(el('p', {'data-fp-family': d.family, text: t(d.family === 'apt' ? 'spk_family_apt' : 'spk_family_dnf')}));
    parts.push(el('p', {class: 'fp-muted', 'data-fp-checked': '', text: d.checked ? t('spk_checked', {when: when(d.checked) || d.checked}) : t('spk_never')}));
    if (running()) { parts.push(el('p', {class: 'fp-muted', 'data-fp-busy': '', text: t('spk_busy')})); }
    parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'refresh',
      text: t('spk_refresh'), disabled: running()})]));
    parts.push(el('p', {class: 'fp-muted sig-hint', text: t('spk_refresh_hint')}));
    parts.push(el('p', {class: 'fp-muted sig-hint', text: t('spk_safety')}));
    return M.card('fp-spk-status-h', t('spk_title'), parts, 'fp-spk-status');
  }
  function pills(p) {
    var out = [];
    if (p.protected) { out.push(el('span', {class: 'sig-pill sig-pill--accent', 'data-fp-protected': '', text: t('spk_protected')})); }
    if (p.noInstall && !p.installed) { out.push(el('span', {class: 'sig-pill sig-pill--warn', 'data-fp-noinstall': '', text: t('spk_noinstall')})); }
    return out;
  }
  function actionButtons(p) {
    var out = [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'info', 'data-fp-name': p.name,
      text: t('spk_details'), 'aria-label': t('spk_details_of', {name: p.name})})];
    if (p.installed && !p.protected) {
      out.push(el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'ask-remove', 'data-fp-name': p.name,
        text: t('spk_remove'), 'aria-label': t('spk_remove_of', {name: p.name}), disabled: running()}));
    } else if (!p.installed && !p.noInstall) {
      out.push(el('button', {class: 'sig-btn sig-btn--primary sig-btn--sm', type: 'button', 'data-fp-act': 'ask-install', 'data-fp-name': p.name,
        text: t('spk_install'), 'aria-label': t('spk_install_of', {name: p.name}), disabled: running()}));
    }
    return el('div', {class: 'fp-actions fp-spk-row-acts'}, out);
  }
  function pkgTable(rows, label, installed) {
    var cols = installed ? ['spk_col_package', 'spk_col_version', 'spk_col_size', 'spk_col_actions'] : ['spk_col_package', 'spk_col_installed', 'spk_col_actions'];
    var head = el('tr', null, cols.map(function (k) { return el('th', {scope: 'col', text: t(k)}); }));
    var body = rows.map(function (p) {
      var first = el('th', {scope: 'row'}, [el('span', {class: 'sig-mono', text: p.name}), p.arch ? el('span', {class: 'fp-muted fp-upd-arch', text: p.arch}) : null,
        p.summary ? el('span', {class: 'fp-muted fp-spk-sum', text: p.summary}) : null].concat(pills(p)));
      var cells = installed ? [el('td', null, [el('span', {class: 'sig-mono', text: p.version || '—'})]), el('td', {text: size(p.size)})]
        : [el('td', null, [el('span', {class: p.installed ? 'sig-mono' : 'fp-muted', text: p.installed || t('spk_not_installed')})])];
      return el('tr', {'data-fp-pkg': p.name}, [first].concat(cells, [el('td', null, [actionButtons(p)])]));
    });
    return el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-label': label},
      [el('table', {class: 'sig-table fp-mail-table fp-upd-table fp-spk-table'}, [el('thead', null, [head]), el('tbody', null, body)])]);
  }
  function searchCard() {
    if (!S.status.supported) { return null; }
    var input = el('input', {class: 'sig-input', id: 'fp-spk-q', name: 'q', type: 'search', maxlength: '64', autocomplete: 'off', spellcheck: 'false', value: S.query || ''});
    var parts = [M.errorLine(), M.statusLine(),
      el('form', {class: 'fp-spk-find', 'data-fp-form': 'search', novalidate: ''}, [M.field('fp-spk-q', t('spk_search_label'), input, t('spk_search_hint')),
        el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary', type: 'submit', text: t('spk_search')})])])];
    var r = S.results;
    if (r) {
      var line = r.total === 0 ? t('spk_found_none', {q: r.q}) : (r.total === 1 ? t('spk_found_one', {q: r.q}) : t('spk_found_many', {n: r.total.toLocaleString('en'), q: r.q}));
      parts.push(el('p', {'data-fp-found': String(r.total), text: line}));
      if (r.truncated) { parts.push(el('p', {class: 'fp-muted', text: t('spk_found_cut', {n: r.rows.length.toLocaleString('en')})})); }
      if (r.rows.length) { parts.push(pkgTable(r.rows, t('spk_results'), false)); }
    }
    return M.card('fp-spk-search-h', t('spk_search_title'), parts, 'fp-spk-search');
  }
  function fact(label, value, mono) {
    return value ? [el('dt', {text: label}), el('dd', null, [el('span', {class: mono ? 'sig-mono' : '', text: value})])] : [];
  }
  function infoCard() {
    var i = S.info;
    if (!S.status.supported || !i) { return null; }
    var dl = el('dl', {class: 'fp-spk-facts'}, [].concat(
      fact(t('spk_f_version'), i.version, true), fact(t('spk_f_arch'), i.arch, true), fact(t('spk_f_repo'), i.repo, true),
      fact(t('spk_f_installed'), i.installed || t('spk_not_installed'), Boolean(i.installed)),
      fact(t('spk_f_download'), i.size ? size(i.size) : ''), fact(t('spk_f_disk'), i.installedSize ? size(i.installedSize) : ''),
      fact(t('spk_f_section'), i.section), fact(t('spk_f_license'), i.license), fact(t('spk_f_url'), i.url, true), fact(t('spk_f_maintainer'), i.maintainer)));
    var parts = [M.errorLine(), M.statusLine(), i.summary ? el('p', {'data-fp-summary': '', text: i.summary}) : null, el('div', {class: 'fp-actions'}, pills(i)), dl];
    if (i.description) { parts.push(el('p', {class: 'fp-spk-desc', text: i.description})); }
    if (i.depends.length) {
      parts.push(el('h3', {class: 'fp-h3', text: t('spk_depends')}));
      parts.push(el('ul', {class: 'fp-spk-deps'}, i.depends.slice(0, 40).map(function (d) { return el('li', null, [el('span', {class: 'sig-mono', text: d})]); })));
      if (i.depends.length > 40) { parts.push(el('p', {class: 'fp-muted', text: t('spk_depends_more', {n: String(i.depends.length - 40)})})); }
    }
    if (i.protected && i.installed) { parts.push(el('p', {class: 'fp-muted', text: t('spk_protected_note')})); }
    if (i.noInstall && !i.installed) { parts.push(el('p', {class: 'fp-muted', text: t('spk_noinstall_note')})); }
    parts.push(actionButtons(i));
    return M.card('fp-spk-info-h', t('spk_info_title', {name: i.name}), parts, 'fp-spk-info');
  }
  function changeList(key, rows) {
    if (!rows.length) { return null; }
    return el('div', {class: 'fp-spk-changes', 'data-fp-changes': key}, [el('h3', {class: 'fp-h3', text: t('spk_plan_' + key, {n: String(rows.length)})}),
      el('ul', null, rows.map(function (c) { return el('li', null, [el('span', {class: 'sig-mono', text: c.name}), c.version ? el('span', {class: 'fp-muted', text: ' ' + c.version}) : null]); }))]);
  }
  function planCard() {
    var p = S.plan;
    if (!S.status.supported || !p) { return null; }
    var what = p.names.join(', ');
    var parts = [M.errorLine(), M.statusLine()];
    if (p.why) {
      parts.push(el('p', {class: 'fp-bk-bad', 'data-fp-refused': '', text: p.why}));
    } else if (p.nothing) {
      parts.push(el('p', {'data-fp-nothing': '', text: t(p.action === 'remove' ? 'spk_plan_nothing_remove' : 'spk_plan_nothing_install', {names: what})}));
    } else {
      parts.push(el('p', {text: t(p.action === 'remove' ? 'spk_plan_intro_remove' : 'spk_plan_intro_install', {names: what})}));
      parts.push(changeList('install', p.install), changeList('upgrade', p.upgrade), changeList('remove', p.remove));
      if (p.download) { parts.push(el('p', {class: 'fp-muted', text: t('spk_plan_download', {size: p.download})})); }
      if (p.disk) { parts.push(el('p', {class: 'fp-muted', text: t(p.action === 'remove' ? 'spk_plan_freed' : 'spk_plan_disk', {size: p.disk})})); }
      if (p.action === 'remove' && p.remove.length > p.names.length) { parts.push(el('p', {class: 'fp-bk-bad', 'data-fp-more': '', text: t('spk_plan_more_removed')})); }
      parts.push(el('p', {class: 'fp-muted sig-hint', text: t('spk_plan_note')}));
    }
    var acts = [];
    if (!p.why && !p.nothing) {
      acts.push(el('button', {class: 'sig-btn ' + (p.action === 'remove' ? 'sig-btn--danger' : 'sig-btn--primary'), type: 'button', 'data-fp-act': 'go',
        text: t(p.action === 'remove' ? 'spk_go_remove' : 'spk_go_install'), disabled: running()}));
    }
    acts.push(el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'plan-close', text: t(p.why || p.nothing ? 'spk_close' : 'cancel')}));
    parts.push(el('div', {class: 'fp-actions'}, acts));
    return M.card('fp-spk-plan-h', t(p.action === 'remove' ? 'spk_plan_title_remove' : 'spk_plan_title_install'), parts, 'fp-spk-plan');
  }
  function whatOf(j) {
    if (j.action === 'refresh') { return t('spk_what_refresh'); }
    if (j.action === 'rebuild') { return t('spk_what_rebuild'); }
    if (!j.action) { return t('spk_what_other'); }
    return t(j.action === 'remove' ? 'spk_what_remove' : 'spk_what_install', {names: j.packages.join(', ') || '—'});
  }
  function jobCard() {
    if (!S.status.supported) { return null; }
    var j = S.status.job;
    var parts = [M.errorLine(), M.statusLine()];
    if (j.state === 'idle') {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-job': 'idle', text: t('spk_job_idle')}));
      return M.card('fp-spk-job-h', t('spk_job_title'), parts, 'fp-spk-job');
    }
    var at = when(j.state === 'running' ? j.started : j.ended) || '—';
    var key = j.state === 'running' ? 'spk_job_running' : (j.state === 'succeeded' ? 'spk_job_ok' : 'spk_job_failed');
    parts.push(el('p', {'data-fp-job': j.state, class: j.state === 'failed' ? 'fp-bk-bad' : '', text: t(key, {what: whatOf(j), when: at})}));
    if (j.by) { parts.push(el('p', {class: 'fp-muted', text: t('spk_job_by', {by: j.by})})); }
    if (j.state === 'failed') {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-job-why': '', text: j.timedOut ? t('spk_job_timeout') : (j.exit !== null ? t('spk_job_exit', {code: String(j.exit)}) : t('spk_job_noexit'))}));
    }
    if (j.log.length) {
      if (j.truncated) { parts.push(el('p', {class: 'fp-muted sig-hint', text: t('spk_log_cut')})); }
      parts.push(el('pre', {class: 'fp-upd-log sig-mono', tabindex: '0', role: 'region', 'aria-label': t('spk_log_label'), 'data-fp-log': '', text: j.log.join('\n')}));
    } else if (j.state === 'running') {
      parts.push(el('p', {class: 'fp-muted', text: t('spk_log_none')}));
    }
    return M.card('fp-spk-job-h', t('spk_job_title'), parts, 'fp-spk-job');
  }
  function installedCard() {
    if (!S.status.supported) { return null; }
    var parts = [M.errorLine(), M.statusLine()];
    var all = S.installed;
    if (!all) {
      parts.push(el('p', {class: 'fp-muted', text: t('spk_installed_desc')}));
      parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'installed', text: t('spk_installed_show')})]));
      return M.card('fp-spk-installed-h', t('spk_installed_title'), parts, 'fp-spk-installed');
    }
    var input = el('input', {class: 'sig-input', id: 'fp-spk-filter', type: 'search', maxlength: '64', autocomplete: 'off', spellcheck: 'false', value: S.filter || ''});
    parts.push(M.field('fp-spk-filter', t('spk_filter_label'), input, t('spk_filter_hint')));
    var f = (S.filter || '').toLowerCase();
    var hits = f ? all.rows.filter(function (p) { return p.name.toLowerCase().indexOf(f) >= 0; }) : all.rows;
    parts.push(el('p', {'data-fp-installed': String(hits.length), role: 'status', text: f ? t('spk_installed_match', {n: hits.length.toLocaleString('en'), all: all.total.toLocaleString('en')})
      : t('spk_installed_n', {n: all.total.toLocaleString('en')})}));
    if (hits.length > MAX_SHOWN) { parts.push(el('p', {class: 'fp-muted', text: t('spk_installed_cut', {n: String(MAX_SHOWN)})})); }
    if (hits.length) { parts.push(pkgTable(hits.slice(0, MAX_SHOWN), t('spk_installed_list'), true)); }
    return M.card('fp-spk-installed-h', t('spk_installed_title'), parts, 'fp-spk-installed');
  }
  function historyCard() {
    if (!S.status.supported) { return null; }
    var parts = [M.errorLine(), M.statusLine()];
    var h = S.history || [];
    if (!h.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-history': '0', text: t('spk_history_none')}));
    } else {
      var head = el('tr', null, ['spk_col_when', 'spk_col_what', 'spk_col_by', 'spk_col_result'].map(function (k) { return el('th', {scope: 'col', text: t(k)}); }));
      var rows = h.slice(0, 200).map(function (e) {
        var ok = e.state === 'succeeded';
        return el('tr', {'data-fp-entry': e.action}, [el('th', {scope: 'row', text: when(e.started) || '—'}), el('td', {text: whatOf(e)}), el('td', {text: e.by || '—'}),
          el('td', null, [el('span', {class: 'sig-pill ' + (ok ? 'sig-pill--ok' : (e.state === 'running' ? 'sig-pill--accent' : 'sig-pill--warn')), text: t('spk_result_' + e.state)})])]);
      });
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-spk-history-h', 'data-fp-history': String(h.length)},
        [el('table', {class: 'sig-table fp-mail-table fp-upd-table'}, [el('thead', null, [head]), el('tbody', null, rows)])]));
    }
    return M.card('fp-spk-history-h', t('spk_history_title'), parts, 'fp-spk-history');
  }
  var MAKERS = {'fp-spk-status': statusCard, 'fp-spk-search': searchCard, 'fp-spk-info': infoCard, 'fp-spk-plan': planCard, 'fp-spk-job': jobCard,
    'fp-spk-installed': installedCard, 'fp-spk-history': historyCard};

  /* puts a card in its place among the others; the focus goes back to the control that had it, or to the card's heading */
  function draw(cls, focusHeading) {
    var old = S.page.querySelector('.' + cls);
    var fresh = MAKERS[cls]();
    var focused = document.activeElement;
    var key = old && focused && old.contains(focused) ? (focused.id ? '#' + focused.id : (focused.getAttribute('data-fp-act') ? '[data-fp-act="' + focused.getAttribute('data-fp-act') + '"]' : '')) : '';
    if (!fresh) { if (old) { old.remove(); } return null; }
    if (old) {
      old.replaceWith(fresh);
    } else {
      var later = null;
      for (var i = CARDS.indexOf(cls) + 1; i < CARDS.length && !later; i++) { later = S.page.querySelector('.' + CARDS[i]); }
      S.page.insertBefore(fresh, later);
    }
    var log = fresh.querySelector('[data-fp-log]');
    if (log) { log.scrollTop = log.scrollHeight; }
    var back = focusHeading ? fresh.querySelector('.fp-h2') : (key ? fresh.querySelector(key + ':not([disabled])') : null);
    if (back) { back.focus(); }
    return fresh;
  }
  function drawAll() { CARDS.forEach(function (c) { draw(c, false); }); }
  function cardOf(node) { return CARDS.filter(function (c) { return node.closest('.' + c); })[0] || ''; }
  function say(cls, text) { var c = S.page.querySelector('.' + cls); if (c) { M.say(c, text); } }
  function fail(cls, err) {
    var c = S.page.querySelector('.' + cls);
    if (c) { UI.showError(c, err && err.message ? err.message : t('api_failed')); }
  }

  /* ---------- asking the server ---------- */
  function loadHistory() {
    var mine = S;
    return FP.call('get', 'sysPkgsHistory').then(function (r) {
      if (S !== mine) { return; }
      mine.history = list(obj(r).entries).map(cleanEntry);
      draw('fp-spk-history', false);
    }, function (err) { if (S === mine) { fail('fp-spk-history', err); } });
  }
  function loadInstalled(cls) {
    var mine = S;
    return FP.call('get', 'sysPkgsInstalled').then(function (r) {
      if (S !== mine) { return; }
      r = obj(r);
      mine.installed = {rows: list(r.packages).map(cleanPkg).filter(Boolean), total: num(r.total)};
      draw('fp-spk-installed', cls === 'fp-spk-installed');
    }, function (err) { if (S === mine) { fail('fp-spk-installed', err); } });
  }
  function search(q) {
    var mine = S;
    var card = S.page.querySelector('.fp-spk-search');
    var b = card.querySelector('button[type="submit"]');
    UI.showError(card, '');
    if (!/^[A-Za-z0-9][A-Za-z0-9._+-]{1,63}$/.test(q)) { UI.showError(card, t('spk_search_bad')); card.querySelector('#fp-spk-q').focus(); return; }
    S.query = q;
    UI.setBusy(b, true);
    FP.call('get', 'sysPkgsSearch', null, {q: q}).then(function (r) {
      if (S !== mine) { return; }
      r = obj(r);
      mine.results = {q: q, rows: list(r.results).slice(0, MAX_ROWS).map(cleanPkg).filter(Boolean), total: num(r.total), truncated: r.truncated === true};
      var fresh = draw('fp-spk-search', false);
      var line = fresh && fresh.querySelector('[data-fp-found]');
      if (line) { line.setAttribute('tabindex', '-1'); line.focus(); }
    }, function (err) {
      if (S !== mine) { return; }
      UI.setBusy(b, false);
      fail('fp-spk-search', err);
    });
  }
  function showInfo(name, from) {
    var mine = S;
    FP.call('get', 'sysPkgsInfo', null, {name: name}).then(function (r) {
      if (S !== mine) { return; }
      mine.info = cleanInfo(r);
      draw('fp-spk-info', true);
    }, function (err) { if (S === mine) { fail(from, err); } });
  }
  function preview(action, name, b, from) {
    var mine = S;
    UI.setBusy(b, true);
    FP.call('post', 'sysPkgsPreview', {action: action, packages: [name]}).then(function (r) {
      if (S !== mine) { return; }
      mine.plan = cleanPlan(r);
      draw(from, false);
      draw('fp-spk-plan', true);
    }, function (err) {
      if (S !== mine) { return; }
      UI.setBusy(b, false);
      fail(from, err);
      if (err && err.status === 409) { catchUp(); }
    });
  }
  function go(b) {
    var mine = S;
    var p = S.plan;
    UI.setBusy(b, true);
    FP.call('post', p.action === 'remove' ? 'sysPkgsRemove' : 'sysPkgsInstall', {packages: p.names}).then(function (r) {
      if (S !== mine) { return; }
      took(obj(r).job, t(p.action === 'remove' ? 'spk_started_remove' : 'spk_started_install'));
    }, function (err) {
      if (S !== mine) { return; }
      UI.setBusy(b, false);
      fail('fp-spk-plan', err);
      if (err && err.status === 409) { catchUp(); }
    });
  }
  function refresh(b) {
    var mine = S;
    UI.setBusy(b, true);
    FP.call('post', 'sysPkgsRefresh', {}).then(function (r) {
      if (S !== mine) { return; }
      took(obj(r).job, t('spk_started_refresh'));
    }, function (err) {
      if (S !== mine) { return; }
      UI.setBusy(b, false);
      fail('fp-spk-status', err);
      if (err && err.status === 409) { catchUp(); }
    });
  }
  /* a job started: the plan closes, the job's card says so and the page follows it */
  function took(job, message) {
    S.plan = null;
    S.status.job = cleanJob(job);
    S.status.busy = S.status.job.state === 'running';
    S.watching = true;
    drawAll();
    var c = S.page.querySelector('.fp-spk-job .fp-h2');
    if (c) { c.focus(); }
    say('fp-spk-job', message);
    loadHistory();
    poll();
  }
  function poll() {
    window.clearTimeout(S.timer);
    var mine = S;
    mine.timer = window.setTimeout(function () {
      if (S !== mine || !document.body.contains(mine.page)) { return; }
      FP.call('get', 'sysPkgs').then(function (r) {
        if (S !== mine) { return; }
        mine.status = cleanStatus(r);
        if (running()) { draw('fp-spk-job', false); draw('fp-spk-status', false); poll(); return; }
        ended();
      }, function () { if (S === mine) { poll(); } });
    }, POLL_MS);
  }
  /* the job ended: what it changed is read again */
  function ended() {
    var mine = S;
    var j = S.status.job;
    drawAll();
    if (mine.watching) { say('fp-spk-job', t(j.state === 'succeeded' ? 'spk_ended_ok' : 'spk_ended_bad')); }
    mine.watching = false;
    loadHistory();
    if (mine.installed) { loadInstalled(''); }
    if (mine.info && j.packages.indexOf(mine.info.name) >= 0) { showInfoQuiet(mine.info.name); }
    if (mine.results && j.action !== 'refresh') { searchQuiet(mine.results.q); }
  }
  function showInfoQuiet(name) {
    var mine = S;
    FP.call('get', 'sysPkgsInfo', null, {name: name}).then(function (r) { if (S === mine) { mine.info = cleanInfo(r); draw('fp-spk-info', false); } }, function () {});
  }
  function searchQuiet(q) {
    var mine = S;
    FP.call('get', 'sysPkgsSearch', null, {q: q}).then(function (r) {
      if (S !== mine) { return; }
      r = obj(r);
      mine.results = {q: q, rows: list(r.results).slice(0, MAX_ROWS).map(cleanPkg).filter(Boolean), total: num(r.total), truncated: r.truncated === true};
      draw('fp-spk-search', false);
    }, function () {});
  }
  /* reads the status again without saying anything: a refusal because a job runs brings the page up to date */
  function catchUp() {
    var mine = S;
    FP.call('get', 'sysPkgs').then(function (r) {
      if (S !== mine) { return; }
      mine.status = cleanStatus(r);
      ['fp-spk-status', 'fp-spk-job'].forEach(function (c) { draw(c, false); });
      if (running()) { mine.watching = true; poll(); }
    }, function () {});
  }

  function onClick(e) {
    var target = e.target && e.target.closest ? e.target : null;
    var b = target && S && S.page && S.page.contains(target) ? target.closest('[data-fp-act]') : null;
    if (!b || b.disabled) { return; }
    var act = b.getAttribute('data-fp-act');
    var name = b.getAttribute('data-fp-name') || '';
    var from = cardOf(b);
    if (from) { UI.showError(S.page.querySelector('.' + from), ''); }
    if (act === 'refresh') {
      refresh(b);
    } else if (act === 'info' && NAME_RE.test(name)) {
      showInfo(name, from);
    } else if ((act === 'ask-install' || act === 'ask-remove') && NAME_RE.test(name)) {
      preview(act === 'ask-remove' ? 'remove' : 'install', name, b, from);
    } else if (act === 'go' && S.plan) {
      go(b);
    } else if (act === 'plan-close') {
      S.plan = null;
      draw('fp-spk-plan', false);
      var h = S.page.querySelector((S.info ? '.fp-spk-info' : '.fp-spk-search') + ' .fp-h2');
      if (h) { h.focus(); }
    } else if (act === 'installed') {
      UI.setBusy(b, true);
      loadInstalled('fp-spk-installed');
    }
  }
  function onSubmit(e) {
    var form = e.target;
    if (!S || !S.page || !S.page.contains(form) || form.getAttribute('data-fp-form') !== 'search') { return; }
    e.preventDefault();
    search(String(form.querySelector('#fp-spk-q').value || '').trim());
  }
  var filterTimer = 0;
  function onInput(e) {
    if (!S || !e.target || e.target.id !== 'fp-spk-filter' || !S.page.contains(e.target)) { return; }
    window.clearTimeout(filterTimer);
    var v = String(e.target.value || '').slice(0, 64);
    filterTimer = window.setTimeout(function () { S.filter = v; draw('fp-spk-installed', false); }, 200);
  }
  document.addEventListener('click', onClick);
  document.addEventListener('submit', onSubmit);
  document.addEventListener('input', onInput);

  FP.view('tool:server_packages', function () {
    var tool = FP.tools.server_packages;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('spk_desc'), cls: 'fp-mail fp-upd fp-spk',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    if (S) { window.clearTimeout(S.timer); }
    S = {page: body, status: null, results: null, info: null, plan: null, installed: null, history: null, query: '', filter: '', timer: 0, watching: false};
    var mine = S;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'sysPkgs').then(function (r) {
      if (S !== mine) { return; }
      mine.status = cleanStatus(r);
      body.textContent = '';
      drawAll();
      if (mine.status.supported) { loadHistory(); }
      if (running()) { mine.watching = true; poll(); }
    }, function (err) {
      if (S !== mine) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

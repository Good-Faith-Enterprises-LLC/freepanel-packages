/* freePanel server resolvers (docs/api.md, "Server", GET, PUT and DELETE /server/resolver): the admin panel's page (#/tool/server_resolver) for
   the name servers and search domains the server's own programs ask. It shows who keeps the file (systemd-resolved, NetworkManager or a plain
   file), what is asked now, and what the panel set. Setting up to three servers and six search domains first has the server ask each one a
   question: the change goes ahead only if one answers, and a first server that does not answer is a warning. The answers come back and are
   shown. Taking the setting away puts back what the system had. Admin only: the server refuses these calls to anyone else. Everything the
   server sends is shown as text. The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var MODES = ['systemd-resolved', 'networkmanager', 'file'];
  var IP4_RE = /^((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$/;
  var IP6_RE = /^[0-9A-Fa-f:]{2,39}$/;
  var DOMAIN_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*$/;
  var MAX_SERVERS = 3;
  var MAX_SEARCH = 6;
  var MAX_SEARCH_LEN = 256;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  function list(v, n, max) { return (Array.isArray(v) ? v : []).filter(function (x) { return typeof x === 'string' && x; }).map(function (x) { return x.slice(0, n); }).slice(0, max); }
  function isAddress(a) { return IP4_RE.test(a) || (a.indexOf(':') > 0 && IP6_RE.test(a)); }
  function clean(v) {
    v = v && typeof v === 'object' ? v : {};
    var c = v.configured && typeof v.configured === 'object' ? {nameservers: list(v.configured.nameservers, 45, MAX_SERVERS), search: list(v.configured.search, 253, MAX_SEARCH)} : null;
    return {mode: MODES.indexOf(v.mode) >= 0 ? v.mode : 'file', active: list(v.active, 45, 20), activeSearch: list(v.active_search, 253, 20), upstream: list(v.upstream, 45, 20),
      configured: c, drift: v.drift === true, canSet: v.can_set === true, reason: str(v.reason, 400)};
  }
  function probes(v) {
    return (v && Array.isArray(v.probes) ? v.probes : []).filter(function (p) { return p && typeof p === 'object' && typeof p.server === 'string'; }).slice(0, 6).map(function (p) {
      return {server: p.server.slice(0, 45), ok: p.ok === true, note: str(p.note, 300)};
    });
  }

  var R = {page: null, S: null, busy: false, probes: null, warnings: null};

  function names(listOf, none) { return listOf.length ? listOf.join(', ') : none; }
  function fact(label, value, attr) { return el('div', {}, [el('dt', {text: label}), el('dd', attr || {}, [value])]); }
  function nowCard() {
    var S = R.S;
    var facts = [fact(t('rsv_kept_by'), t('rsv_mode_' + S.mode.replace('-', '_')), {'data-fp-kept': S.mode}),
      fact(t('rsv_asked'), names(S.active, t('rsv_none')), {'data-fp-active': ''}),
      fact(t('rsv_search'), names(S.activeSearch, t('rsv_none_search')), {'data-fp-active-search': ''})];
    if (S.upstream.length) { facts.push(fact(t('rsv_upstream'), S.upstream.join(', '), {'data-fp-upstream': ''})); }
    var parts = [el('dl', {class: 'fp-rsv-facts'}, facts)];
    if (S.configured) {
      parts.push(el('p', {class: 'fp-rsv-set', 'data-fp-configured': ''}, [el('span', {class: 'sig-pill sig-pill--accent', text: t('rsv_pill_set')}), ' ',
        el('span', {text: t('rsv_set_by_panel', {servers: S.configured.nameservers.join(', ') || '?', search: S.configured.search.length ? S.configured.search.join(', ') : t('rsv_none_search')})})]));
    } else {
      parts.push(el('p', {class: 'fp-rsv-set', 'data-fp-configured': ''}, [el('span', {class: 'sig-pill', text: t('rsv_pill_system')}), ' ', el('span', {text: t('rsv_not_set')})]));
    }
    if (S.configured && S.drift) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-rsv-drift': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('rsv_drift')})]));
    }
    parts.push(el('p', {class: 'fp-muted', text: t('rsv_mode_what_' + S.mode.replace('-', '_'))}));
    return M.card('fp-rsv-now-h', t('rsv_now_title'), parts, 'fp-rsv-now');
  }
  function field(id, name, label, hint, value) {
    var input = el('input', {class: 'sig-input sig-mono', id: id, name: name, type: 'text', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', maxlength: '300', value: value || ''});
    return M.field(id, label, input, hint);
  }
  function readForm(form) {
    var get = function (n) { return form.querySelector('[name="' + n + '"]'); };
    var servers = [];
    for (var i = 1; i <= MAX_SERVERS; i++) {
      var v = get('server' + i).value.trim();
      if (!v) { continue; }
      if (!isAddress(v)) { M.fieldError(form, get('server' + i), t('rsv_bad_server')); return null; }
      if (servers.indexOf(v) >= 0) { M.fieldError(form, get('server' + i), t('rsv_twice')); return null; }
      servers.push(v);
    }
    if (!servers.length) { M.fieldError(form, get('server1'), t('rsv_need_one')); return null; }
    var search = get('search').value.toLowerCase().split(/[\s,]+/).filter(Boolean);
    if (search.length > MAX_SEARCH) { M.fieldError(form, get('search'), t('rsv_too_many_search', {n: MAX_SEARCH})); return null; }
    for (var j = 0; j < search.length; j++) {
      if (!DOMAIN_RE.test(search[j])) { M.fieldError(form, get('search'), t('rsv_bad_search', {name: search[j].slice(0, 60)})); return null; }
    }
    if (search.join(' ').length > MAX_SEARCH_LEN) { M.fieldError(form, get('search'), t('rsv_search_long', {n: MAX_SEARCH_LEN})); return null; }
    return {nameservers: servers, search: search};
  }
  function setCard() {
    var S = R.S;
    if (!S.canSet) {
      return M.card('fp-rsv-set-h', t('rsv_set_title'), [el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-rsv-cannot': ''}, [UI.icon(FP.ui, 'ui_warning'),
        el('span', {text: t('rsv_cannot', {reason: S.reason || t('rsv_no_reason')})})])], 'fp-rsv-setcard');
    }
    /* the boxes start from what the system really asks: where systemd-resolved keeps the file it holds resolved's own stub address (127.0.0.53), which is not
       a server to set, so they start from the servers resolved asks (`upstream`, none when it has none) and never from the stub */
    var viaStub = !S.configured && S.mode === 'systemd-resolved';
    var src = S.configured ? S.configured.nameservers : viaStub ? S.upstream : S.active;
    var searchSrc = S.configured ? S.configured.search : S.activeSearch;
    var form = el('form', {class: 'fp-form fp-rsv-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      viaStub ? el('p', {class: 'fp-muted sig-hint', 'data-fp-rsv-start': '', text: t('rsv_start_upstream')}) : null,
      field('fp-rsv-s1', 'server1', t('rsv_server_n', {n: 1}), t('rsv_server_hint'), src[0]),
      field('fp-rsv-s2', 'server2', t('rsv_server_n', {n: 2}), null, src[1]),
      field('fp-rsv-s3', 'server3', t('rsv_server_n', {n: 3}), null, src[2]),
      field('fp-rsv-search', 'search', t('rsv_search_label'), t('rsv_search_hint', {n: MAX_SEARCH}), searchSrc.join(' ')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('rsv_apply')}),
        S.configured ? el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'rsv-reset', text: t('rsv_reset')}) : null])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || R.busy) { return; }
      var body = readForm(form);
      if (!body) { return; }
      R.busy = true;
      UI.setBusy(b, true);
      var mine = R.page;
      FP.call('put', 'serverResolver', body).then(function (r) {
        R.busy = false;
        if (R.page !== mine) { return; }
        R.S = clean(r);
        R.probes = probes(r);
        R.warnings = list(r && r.warnings, 300, 10);
        render();
        M.say(R.page.querySelector('.fp-rsv-setcard'), t('rsv_applied'));
        R.page.querySelector('#fp-rsv-s1').focus();
      }, function (err) {
        R.busy = false;
        if (R.page !== mine) { return; }
        UI.setBusy(b, false);
        if (err && (err.field === 'nameservers' || err.field === 'search')) {
          M.fieldError(form, UI.fieldNamed(form, err.field === 'nameservers' ? 'server1' : 'search'), err.message);
        } else {
          M.failed(form, err);
        }
      });
    });
    return M.card('fp-rsv-set-h', t('rsv_set_title'), [el('p', {class: 'fp-muted', text: t('rsv_set_what')}), form], 'fp-rsv-setcard');
  }
  function resultCard() {
    if (!R.probes) { return null; }
    var parts = [el('ul', {class: 'fp-rsv-probes', 'data-fp-probes': ''}, R.probes.map(function (p) {
      return el('li', {class: 'fp-rsv-probe'}, [el('span', {class: 'sig-mono', text: p.server}), ' ', el('span', {class: 'sig-pill ' + (p.ok ? 'sig-pill--ok' : 'sig-pill--warn'), text: p.ok ? t('rsv_answered') : t('rsv_no_answer')}),
        p.note ? el('span', {class: 'fp-muted', text: ' ' + p.note}) : null]);
    }))];
    if (R.warnings && R.warnings.length) {
      parts.push(el('ul', {class: 'fp-rsv-warnings', 'data-fp-warnings': ''}, R.warnings.map(function (w) {
        return el('li', {}, [el('div', {class: 'sig-banner sig-banner--warn', role: 'note'}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: w})])]);
      })));
    }
    return M.card('fp-rsv-res-h', t('rsv_result_title'), parts, 'fp-rsv-result');
  }
  function render() {
    R.page.textContent = '';
    R.page.appendChild(nowCard());
    R.page.appendChild(setCard());
    var res = resultCard();
    if (res) { R.page.appendChild(res); }
  }

  document.addEventListener('click', function (e) {
    var node = e.target.closest ? e.target : null;
    var b = node && node.closest('[data-fp-act]');
    if (!b || !R.page || !R.page.contains(b) || !R.S) { return; }
    var a = b.getAttribute('data-fp-act');
    var mine = R.page;
    if (a === 'rsv-reset') {
      M.confirmIn(b.parentNode, t('rsv_reset_ask'), 'rsv-reset-yes', t('rsv_reset_yes'));
    } else if (a === 'confirm-no') {
      render();
      var back = R.page.querySelector('[data-fp-act="rsv-reset"]');
      if (back) { back.focus(); }
    } else if (a === 'rsv-reset-yes' && !R.busy) {
      R.busy = true;
      UI.setBusy(b, true);
      FP.call('del', 'serverResolver').then(function (r) {
        R.busy = false;
        if (R.page !== mine) { return; }
        R.S = clean(r);
        R.probes = null;
        R.warnings = list(r && r.warnings, 300, 10);
        render();
        M.say(R.page.querySelector('.fp-rsv-setcard'), t('rsv_reset_done'));
        R.page.querySelector('#fp-rsv-s1').focus();
      }, function (err) {
        R.busy = false;
        if (R.page !== mine) { return; }
        render();
        UI.showError(R.page.querySelector('.fp-rsv-setcard'), err.message);
        var f = R.page.querySelector('#fp-rsv-s1');
        if (f) { f.focus(); }
      });
    }
  });

  FP.view('tool:server_resolver', function () {
    var tool = FP.tools.server_resolver;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    R.S = null;
    R.busy = false;
    R.probes = null;
    R.warnings = null;
    var body = FP.frame({title: tool.label, desc: t('rsv_desc'), cls: 'fp-mail fp-srv fp-rsv-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    R.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'serverResolver').then(function (r) {
      if (R.page !== body) { return; }
      R.S = clean(r);
      render();
    }, function (err) {
      if (R.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

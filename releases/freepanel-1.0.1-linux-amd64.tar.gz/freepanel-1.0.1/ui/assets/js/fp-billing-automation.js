/* freePanel billing automation (#/tool/billing_automation; docs/api.md, "Billing: automation"; docs/billing/navigation-map.md, "Automation"):
   the daily run's settings (what runs and when) beside the history of runs; a run opens its events; Run now runs it at once after a question,
   since a run issues renewals, sends reminders and can suspend and end services. Off until an admin turns it on. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;
  var M = FP.mail;

  var NUMS = ['run_hour', 'invoice_days_ahead', 'reminder_days_before', 'overdue_notice_days', 'suspend_after_days', 'terminate_after_days', 'ticket_close_days', 'domain_renew_days',
    'charge_retry_days', 'charge_attempts'];
  var SUMMARY = ['invoices_made', 'reminders', 'overdue_notices', 'suspended', 'unsuspended', 'terminated', 'cancelled', 'messages_sent', 'tickets_closed', 'domain_renewals', 'charged',
    'charges_failed', 'quotes_expired', 'commissions_made'];
  var RUN = {id: 'id', trigger: [20], by: [64], status: [20], started: 'w', finished: 'w'};
  function cleanRun(x) {
    var r = B.pick(x, RUN);
    if (!r || !r.id) { return null; }
    r.summary = {};
    var s = x.summary && typeof x.summary === 'object' ? x.summary : {};
    SUMMARY.forEach(function (k) { r.summary[k] = B.whole(s[k]) || 0; });
    r.errors = (Array.isArray(s.errors) ? s.errors : []).filter(function (e) { return typeof e === 'string'; }).map(function (e) { return e.slice(0, 300); }).slice(0, 20);
    return r;
  }
  function said(r) {
    var bits = SUMMARY.filter(function (k) { return r.summary[k]; }).map(function (k) { return t('bau_sum_' + k, {n: B.num(r.summary[k])}); });
    return bits.length ? bits.join(', ') : t('bau_sum_nothing');
  }
  FP.view('tool:billing_automation', function () {
    var page = B.frame('billing_automation', 'fp-bau');
    if (!page) { return; }
    var alive = function () { return page.isConnected; };
    var runs = [];
    function settingsCard(v) {
      var specs = [{name: 'enabled', label: t('bau_enabled'), kind: 'check', hint: t('bau_enabled_hint')}].concat(NUMS.map(function (k) {
        return {name: k, label: t('bau_' + k), kind: 'number', max: 3, hint: t('bau_' + k + '_hint')};
      })).concat([{name: 'unsuspend_on_payment', label: t('bau_unsuspend_on_payment'), kind: 'check'}, {name: 'auto_charge', label: t('bau_auto_charge'), kind: 'check', hint: t('bau_auto_charge_hint')}]);
      var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bil_save_changes')});
      var form = el('form', {class: 'fp-form fp-bil-crud-form fp-bau-form', novalidate: '', 'aria-labelledby': 'fp-bau-set-h'}, [M.errorLine(), M.statusLine(),
        el('div', {class: 'fp-bil-grid'}, B.fieldsOf('fp-bau-s', specs, v)), el('div', {class: 'fp-actions'}, [save])]);
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!B.begin(form, save)) { return; }
        var body = B.readFields(form, specs, v);
        if (!body) { return; }
        if (!Object.keys(body).length) { M.say(form, t('bil_nothing_changed')); return; }
        UI.setBusy(save, true);
        FP.call('patch', 'billingAutomation', body).then(function () {
          if (alive()) { load(t('bau_saved'), '#fp-bau-set-h'); }
        }, function (err) {
          if (!alive()) { return; }
          UI.setBusy(save, false);
          B.failed(form, err);
        });
      });
      return B.card('fp-bau-set-h', t('bau_settings'), [el('p', {class: 'fp-muted', text: t('bau_settings_what')}), form], 'fp-bau-set', 'settings');
    }
    function runsCard() {
      var parts = [M.errorLine(), M.statusLine(), el('div', {class: 'fp-bil-toolbar', 'data-fp-acts': ''}, [B.button('run-now', t('bau_run_now'), 'sig-btn--secondary')])];
      parts.push(runs.length ? B.table('fp-bau-runs-h', 'fp-bau-table', [B.th(t('bau_col_started')), B.th(t('bau_col_trigger')), B.th(t('bau_col_status')), B.th(t('bau_col_did')),
        el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('acct_actions')})])], runs.map(function (r) {
        return el('tr', {'data-fp-run': String(r.id)}, [el('td', {class: 'fp-bil-nowrap', text: B.when(r.started) || '—'}),
          el('td', {text: r.trigger === 'admin' ? t('bau_by_admin', {who: r.by || '—'}) : t('bau_by_schedule')}),
          el('td', null, [B.pill(t(r.status === 'ok' ? 'bau_ok' : r.status === 'errors' ? 'bau_errors' : 'bau_running'), r.status === 'ok' ? 'ok' : r.status === 'errors' ? 'danger' : 'warn')]),
          el('td', {class: 'fp-bil-wrap', text: said(r)}),
          el('td', {class: 'fp-bil-acts'}, [B.button('events', t('bau_events'), 'sig-btn--secondary sig-btn--sm', {'data-fp-id': String(r.id), 'aria-label': t('bau_events_of', {when: B.when(r.started)})})])]);
      })) : el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('bau_no_runs')}));
      return B.card('fp-bau-runs-h', t('bau_runs'), parts, 'fp-bau-runs', 'runs');
    }
    function load(sayText, focus) {
      return Promise.all([FP.call('get', 'billingAutomation'), FP.call('get', 'billingAutomationRuns', undefined, {limit: '30'})]).then(function (r) {
        if (!alive()) { return; }
        var v = B.pick(r[0], {enabled: 'b', unsuspend_on_payment: 'b', auto_charge: 'b'}) || {};
        NUMS.forEach(function (k) { v[k] = B.whole(r[0] && r[0][k]); });
        runs = (r[1] && Array.isArray(r[1].runs) ? r[1].runs : []).map(cleanRun).filter(Boolean);
        B.screen(page, [el('div', {class: 'fp-bau-layout'}, [settingsCard(v), runsCard()])]);
        if (sayText) { M.say(page.querySelector(focus === '#fp-bau-runs-h' ? '.fp-bau-runs' : '.fp-bau-form'), sayText); }
        var f = focus ? page.querySelector(focus) : null;
        if (f) { f.focus(); }
      }, function (err) {
        if (!alive()) { return; }
        B.screen(page, [FP.empty(t('bau_settings'), err.message, B.button('reload', t('bil_try_again')))]);
      });
    }
    page.addEventListener('click', function (e) {
      var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
      if (!b || b.disabled || !alive()) { return; }
      var a = b.getAttribute('data-fp-act');
      if (a === 'reload') {
        load();
      } else if (a === 'run-now') {
        M.confirmIn(b.closest('[data-fp-acts]'), t('bau_run_ask'), 'run-yes', t('bau_run_yes'));
      } else if (a === 'confirm-no') {
        var box = b.closest('[data-fp-acts]');
        box.textContent = '';
        var again = B.button('run-now', t('bau_run_now'), 'sig-btn--secondary');
        box.appendChild(again);
        again.focus();
      } else if (a === 'run-yes') {
        UI.setBusy(b, true);
        FP.call('post', 'billingAutomationRun', {}).then(function (r) {
          if (!alive()) { return; }
          var run = cleanRun(r);
          load(run ? t('bau_ran', {did: said(run)}) : t('bau_ran_plain'), '#fp-bau-runs-h');
        }, function (err) {
          if (!alive()) { return; }
          load().then(function () { UI.showError(page.querySelector('.fp-bau-runs'), err.message); });
        });
      } else if (a === 'events') {
        var rid = Number(b.getAttribute('data-fp-id'));
        UI.setBusy(b, true);
        FP.call('get', 'billingAutomationEvents', undefined, {id: String(rid)}).then(function (r) {
          if (!alive()) { return; }
          UI.setBusy(b, false);
          var ev = B.pickAll(r && r.events, {kind: [30], invoice_id: 'id', service_id: 'id', detail: [300]});
          var run = runs.filter(function (x) { return x.id === rid; })[0];
          var old = page.querySelector('[data-fp-card="events"]');
          var made = B.card('fp-bau-ev-h', t('bau_events_title', {when: run ? B.when(run.started) : ''}), [ev.length ? B.table('fp-bau-ev-h', 'fp-bau-ev-table', [B.th(t('bau_col_event')),
            B.th(t('bau_col_about')), B.th(t('bau_col_detail'))], ev.map(function (x) {
            var about = [x.invoice_id ? t('binv_invoice_ref', {id: String(x.invoice_id)}) : '', x.service_id ? t('bau_service_n', {id: String(x.service_id)}) : ''].filter(Boolean).join(', ');
            return el('tr', null, [el('td', {text: B.word('event', x.kind)}), el('td', {text: about || '—'}), el('td', {class: 'fp-bil-wrap', text: x.detail || '—'})]);
          })) : el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('bau_no_events')}),
          run && run.errors.length ? el('ul', {class: 'fp-bau-errors'}, run.errors.map(function (x) { return el('li', {text: x}); })) : null].filter(Boolean), 'fp-bau-ev', 'events');
          if (old) { old.replaceWith(made); } else { page.querySelector('.fp-bau-runs').after(made); }
          made.querySelector('#fp-bau-ev-h').focus();
        }, function (err) {
          if (!alive()) { return; }
          UI.setBusy(b, false);
          UI.showError(page.querySelector('.fp-bau-runs'), err.message);
        });
      }
    });
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    load();
  });
})();

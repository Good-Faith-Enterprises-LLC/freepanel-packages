/* freePanel backup guide (#/tool/backup_guide), the customer panel's step-by-step way to back up or put back an account
   (docs/api.md, "Backups"). Step 1 asks whether to back up or restore. Backing up asks what to copy (everything, the
   files or the mail settings) and asks the server for that download (POST .../backups/download), which the Backups page
   then hands over; restoring says which way fits (a backup the server keeps, or a files archive from the computer) and
   opens the Backups page where that is done. Page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var KINDS = ['full', 'home', 'mail'];
  var G = null;

  function radios(name, values, picked, label) {
    return values.map(function (v) {
      var id = 'fp-bkg-' + name + '-' + v;
      return el('div', {class: 'fp-radio-row'}, [el('label', {class: 'fp-check', for: id}, [
        el('input', {type: 'radio', name: 'bkg-' + name, id: id, value: v, checked: picked === v ? true : null, 'aria-describedby': id + '-note'}),
        el('span', {text: t(label + v)})]), el('span', {class: 'fp-muted fp-row-note', id: id + '-note', text: t(label + v + '_note')})]);
    });
  }
  function step(id, n, title, parts) { return M.card(id, t('bkg_step', {n: n, title: title}), parts, 'fp-bkg-step'); }

  function draw(focus) {
    var page = G.page;
    page.textContent = '';
    var what = el('fieldset', {class: 'fp-fieldset fp-bkg-do'}, [el('legend', {text: t('bkg_do')})].concat(radios('do', ['backup', 'restore'], G.do, 'bkg_do_')));
    what.addEventListener('change', function (e) {
      if (e.target && e.target.name === 'bkg-do') { G.do = e.target.value; G.made = ''; draw('#fp-bkg-do-' + G.do); }
    });
    page.appendChild(step('fp-bkg-1-h', 1, t('bkg_step1'), [what]));
    if (G.do === 'backup') {
      var form = el('form', {class: 'fp-form fp-mail-form fp-bkg-make', novalidate: ''}, [M.errorLine(), M.statusLine(),
        el('fieldset', {class: 'fp-fieldset'}, [el('legend', {text: t('bkg_what')})].concat(radios('kind', KINDS, G.kind, 'bkg_kind_'))),
        el('p', {class: 'sig-hint', text: t('bkg_replaces')}),
        el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bkg_make')})])]);
      form.addEventListener('change', function (e) { if (e.target && e.target.name === 'bkg-kind') { G.kind = e.target.value; } });
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var b = M.start(form);
        if (!b) { return; }
        var mine = G;
        var kind = G.kind;
        UI.setBusy(b, true);
        FP.call('post', 'backupDownload', {kind: kind}, mine.account).then(function () {
          if (G !== mine) { return; }
          mine.made = kind;
          draw('#fp-bkg-3-h');
        }, function (err) {
          if (G !== mine) { return; }
          UI.setBusy(b, false);
          M.failed(form, err);
        });
      });
      page.appendChild(step('fp-bkg-2-h', 2, t('bkg_step2_backup'), [form]));
      if (G.made) {
        page.appendChild(step('fp-bkg-3-h', 3, t('bkg_step3_backup'), [el('p', {role: 'status', 'data-fp-made': '', text: t('bkg_made', {kind: t('bkg_kind_' + G.made)})}),
          el('p', null, [el('a', {class: 'sig-link', href: '#/tool/backups', text: t('bkg_open')})])]));
      }
    } else if (G.do === 'restore') {
      var from = el('fieldset', {class: 'fp-fieldset fp-bkg-from'}, [el('legend', {text: t('bkg_from')})].concat(radios('from', ['kept', 'upload'], G.from, 'bkg_from_')));
      from.addEventListener('change', function (e) {
        if (e.target && e.target.name === 'bkg-from') { G.from = e.target.value; draw('#fp-bkg-from-' + G.from); }
      });
      page.appendChild(step('fp-bkg-2-h', 2, t('bkg_step2_restore'), [from]));
      if (G.from) {
        page.appendChild(step('fp-bkg-3-h', 3, t('bkg_step3_restore'), [el('p', {text: t('bkg_how_' + G.from)}),
          el('p', null, [el('a', {class: 'sig-link', href: '#/tool/backups', text: t('bkg_open')})])]));
      }
    }
    var target = focus ? page.querySelector(focus) : null;
    if (target) { target.focus(); }
  }

  FP.view('tool:backup_guide', function () {
    G = null;
    var tool = FP.tools.backup_guide;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('bkg_desc'), cls: 'fp-mail fp-bkg-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    G = {page: body, account: FP.account(), do: '', kind: 'full', made: '', from: ''};
    draw();
  });
})();

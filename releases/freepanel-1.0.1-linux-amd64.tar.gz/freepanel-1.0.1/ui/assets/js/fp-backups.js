/* freePanel backups (#/tool/backup_restore), the admin panel's page for account backups (docs/api.md, "Accounts":
   backups; plans/backups.md): the run in progress, each account's newest archive and how its latest run ended, a
   backup started now, and every kept archive, including those of removed accounts, with a restore. One run goes at a
   time, so while one runs the page asks the server every few seconds and shows how it ended. A restore of a removed
   account makes the account again first, on the archive's owner and package unless others are chosen. An archive of
   an earlier account with the same name goes into the account that has the name now only when the admin says so
   (other_account): the page asks when it knows, and when the server refuses for that reason. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var USER_RE = /^[a-z][a-z0-9]{0,15}$/;
  var ARCHIVE_RE = /^[a-z][a-z0-9]{0,15}-[A-Za-z0-9._-]{1,100}\.tar\.gz$/;
  var PART_RE = /^[a-z0-9_-]{1,32}$/;
  var FILE_RE = /^[A-Za-z0-9.-]{1,255}$/;
  /* the runs that share the one slot: an import's reading names the archive's file, not an account; an upload's
     restore (downloads have their own slots) */
  var KINDS = ['backup', 'restore', 'import', 'import-read', 'upload'];
  /* the parts a restore can put back: the home folder and each module's own */
  var PARTS = ['home', 'web', 'mail', 'mysql', 'postgres', 'dns', 'cron'];
  var POLL_MS = 3000;
  var UNITS = ['KB', 'MB', 'GB', 'TB', 'PB'];

  var B = null;

  function str(v) { return typeof v === 'string' ? v : ''; }
  function size(n) {
    if (n < 1024) { return t('size_bytes', {n: String(Math.round(n))}); }
    var u = -1;
    do { n /= 1024; u++; } while (n >= 1024 && u < UNITS.length - 1);
    return (n < 10 ? n.toFixed(1) : Math.round(n).toLocaleString('en')) + ' ' + UNITS[u];
  }
  function when(iso) {
    var d = iso ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString(undefined, {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }
  function partName(p) { return PARTS.indexOf(p) >= 0 ? t('bk_part_' + p) : p; }

  function cleanArchives(r) {
    return (r && Array.isArray(r.backups) ? r.backups : []).filter(function (b) {
      return b && USER_RE.test(str(b.username)) && ARCHIVE_RE.test(str(b.name)) && b.name.indexOf(b.username + '-') === 0;
    }).map(function (b) {
      return {username: b.username, name: b.name, bytes: typeof b.bytes === 'number' && isFinite(b.bytes) && b.bytes >= 0 ? b.bytes : null,
        created: str(b.created), removed: b.removed === true};
    });
  }
  function cleanRun(v) {
    if (!v || typeof v !== 'object' || KINDS.indexOf(v.kind) < 0) { return null; }
    if (v.kind === 'import-read') { return FILE_RE.test(str(v.file)) ? {kind: v.kind, username: '', file: v.file, started: str(v.started)} : null; }
    return USER_RE.test(str(v.username)) ? {kind: v.kind, username: v.username, file: '', started: str(v.started)} : null;
  }
  function cleanStatus(r) {
    r = r && typeof r === 'object' ? r : {};
    var last = {};
    var src = r.last && typeof r.last === 'object' ? r.last : {};
    Object.keys(src).forEach(function (u) {
      var v = src[u];
      if (!USER_RE.test(u) || !v || typeof v !== 'object') { return; }
      var failed = [];
      if (v.failed && typeof v.failed === 'object') {
        Object.keys(v.failed).sort().forEach(function (p) {
          if (PART_RE.test(p)) { failed.push({part: p, why: str(v.failed[p]).slice(0, 1024)}); }
        });
      }
      if (['backup', 'restore', 'import'].indexOf(v.kind) < 0) { return; }
      last[u] = {kind: v.kind, ended: str(v.ended), archive: ARCHIVE_RE.test(str(v.archive)) ? v.archive : '',
        restored: (Array.isArray(v.restored) ? v.restored : []).filter(function (p) { return PART_RE.test(str(p)); }), failed: failed,
        notes: (Array.isArray(v.notes) ? v.notes : []).filter(function (n) { return typeof n === 'string' && n; }).slice(0, 50).map(function (n) { return n.slice(0, 500); }),
        error: str(v.error).slice(0, 1024)};
    });
    return {running: cleanRun(r.running), last: last};
  }
  function cleanAccounts(r) {
    return (r && Array.isArray(r.accounts) ? r.accounts : []).map(function (a) { return a && str(a.username); })
      .filter(function (u) { return USER_RE.test(u); }).sort();
  }

  /* ---------- the run in progress ---------- */
  function runText(run) {
    var w = when(run.started);
    return t('bk_running_' + run.kind.replace('-', '_'), {account: run.username, file: run.file, when: w || run.started || '—'});
  }
  /* how an account's latest run ended, in one or more sentences */
  function lastText(l) {
    var w = when(l.ended) || l.ended || '—';
    if (l.kind === 'backup') {
      return l.error ? t('bk_last_backup_failed', {when: w, error: l.error}) : t('bk_last_backup', {when: w, archive: l.archive || '—'});
    }
    if (l.error) { return t('bk_last_' + l.kind + '_failed', {when: w, error: l.error}); }
    var out = t('bk_last_' + l.kind, {when: w, parts: l.restored.length ? l.restored.map(partName).join(', ') : t('bk_parts_none')});
    if (l.failed.length) {
      out += ' ' + t('bk_last_restore_some', {parts: l.failed.map(function (f) { return partName(f.part) + ' (' + f.why + ')'; }).join('; ')});
    }
    if (l.notes.length) { out += ' ' + t('bk_last_notes', {notes: l.notes.join('; ')}); }
    return out;
  }
  function nowCard() {
    var parts = [M.errorLine(), M.statusLine()];
    parts.push(el('p', {'data-fp-bk-running': '', class: B.status.running ? '' : 'fp-muted',
      text: B.status.running ? runText(B.status.running) : t('bk_idle')}));
    return M.card('fp-bk-now-h', t('bk_now_title'), parts, 'fp-bk-now');
  }

  /* ---------- accounts ---------- */
  function newest(u) {
    return B.archives.filter(function (a) { return a.username === u && !a.removed; })[0] || null;
  }
  function accountsCard() {
    var parts = [M.errorLine()];
    if (!B.accounts.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('bk_no_accounts')}));
      return M.card('fp-bk-acct-h', t('bk_accounts_title'), parts, 'fp-bk-accounts');
    }
    var filter = el('input', {class: 'sig-input', id: 'fp-bk-filter', type: 'search', autocomplete: 'off', spellcheck: 'false', maxlength: '16',
      value: B.filter});
    var none = el('p', {class: 'fp-muted', 'data-fp-bk-none': '', hidden: true, text: t('bk_no_match')});
    var tbody = el('tbody', null, B.accounts.map(function (u) {
      var n = newest(u);
      var l = B.status.last[u];
      return el('tr', {'data-fp-account': u}, [el('th', {scope: 'row', class: 'fp-mail-name', text: u}),
        el('td', {class: 'fp-bk-when', text: n ? t('bk_newest', {when: when(n.created) || n.created, size: n.bytes === null ? '—' : size(n.bytes)}) : t('bk_none_kept')}),
        el('td', {class: 'fp-bk-last' + (l && (l.error || l.failed.length) ? ' fp-bk-bad' : ''), text: l ? lastText(l) : t('bk_last_none')}),
        el('td', {class: 'fp-mail-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'backup',
          'aria-label': t('bk_backup_of', {account: u}), text: t('bk_backup')}),
        FP.backupDownload ? el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'download',
          'aria-label': t('dl_open_of', {account: u}), text: t('dl_open')}) : null])]);
    }));
    var table = el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-bk-acct-h'}, [
      el('table', {class: 'sig-table fp-mail-table fp-bk-table'}, [el('thead', null, [el('tr', null, [
        el('th', {scope: 'col', text: t('bk_account')}), el('th', {scope: 'col', text: t('bk_newest_col')}),
        el('th', {scope: 'col', text: t('bk_last_col')}), el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]), tbody])]);
    function apply() {
      B.filter = filter.value.trim().toLowerCase();
      var shown = 0;
      for (var i = 0; i < tbody.children.length; i++) {
        var hit = !B.filter || B.accounts[i].indexOf(B.filter) >= 0;
        tbody.children[i].hidden = !hit;
        if (hit) { shown++; }
      }
      table.hidden = shown === 0;
      none.hidden = shown !== 0;
    }
    filter.addEventListener('input', apply);
    filter.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && filter.value) { e.stopPropagation(); filter.value = ''; apply(); }
    });
    parts.push(el('div', {class: 'sig-field fp-zones-filter'}, [el('label', {class: 'sig-label', for: 'fp-bk-filter', text: t('bk_filter')}), filter]));
    parts.push(table, none);
    apply();
    return M.card('fp-bk-acct-h', t('bk_accounts_title'), parts, 'fp-bk-accounts');
  }

  /* ---------- archives ---------- */
  function archivesCard() {
    var parts = [M.errorLine(), el('p', {class: 'fp-muted', text: t('bk_archives_desc')})];
    if (!B.archives.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('bk_no_archives')}));
      return M.card('fp-bk-arch-h', t('bk_archives_title'), parts, 'fp-bk-archives');
    }
    var names = [];
    B.archives.forEach(function (a) { if (names.indexOf(a.username) < 0) { names.push(a.username); } });
    names.sort();
    if (B.only && names.indexOf(B.only) < 0) { B.only = ''; }
    var pick = el('select', {class: 'sig-select', id: 'fp-bk-only'}, [el('option', {value: '', text: t('bk_all_accounts')})].concat(names.map(function (u) {
      return el('option', {value: u, text: u, selected: u === B.only ? true : null});
    })));
    var tbody = el('tbody', null, B.archives.map(function (a) {
      return el('tr', {'data-fp-archive': a.name, hidden: B.only && a.username !== B.only ? true : null}, [
        el('th', {scope: 'row', class: 'fp-bk-name'}, [el('span', {class: 'sig-mono', text: a.name})]),
        el('td', null, [el('span', {text: a.username}), a.removed ? el('span', {class: 'sig-pill sig-pill--warn fp-bk-pill', text: t('bk_removed')}) : null]),
        el('td', {class: 'fp-bk-when', text: when(a.created) || a.created || '—'}),
        el('td', {class: 'fp-num', text: a.bytes === null ? '—' : size(a.bytes)}),
        el('td', {class: 'fp-mail-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'restore',
          'aria-label': t('bk_restore_of', {archive: a.name}), text: t('bk_restore')}),
        /* some items go into an account that is here; a removed account is made again by the whole-archive restore first */
        FP.restoreSome && B.accounts.indexOf(a.username) >= 0 ? el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button',
          'data-fp-act': 'restore-some', 'aria-label': t('arst_open_of', {archive: a.name}), text: t('arst_open')}) : null])]);
    }));
    pick.addEventListener('change', function () {
      B.only = pick.value;
      for (var i = 0; i < tbody.children.length; i++) { tbody.children[i].hidden = Boolean(B.only) && B.archives[i].username !== B.only; }
    });
    parts.push(el('div', {class: 'sig-field fp-zones-filter'}, [el('label', {class: 'sig-label', for: 'fp-bk-only', text: t('bk_only')}), pick]));
    parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-bk-arch-h'}, [
      el('table', {class: 'sig-table fp-mail-table fp-bk-table'}, [el('thead', null, [el('tr', null, [
        el('th', {scope: 'col', text: t('bk_archive')}), el('th', {scope: 'col', text: t('bk_account')}),
        el('th', {scope: 'col', text: t('bk_made')}), el('th', {scope: 'col', class: 'fp-num', text: t('bk_size')}),
        el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]), tbody])]));
    return M.card('fp-bk-arch-h', t('bk_archives_title'), parts, 'fp-bk-archives');
  }

  /* ---------- restore ---------- */
  /* what the restore will do to the account: put parts into the account the archive is of, make a removed account
     again, or (known ahead) put an earlier account's archive into the one that has the name now */
  function caseOf(a) {
    if (B.accounts.indexOf(a.username) < 0) { return 'remake'; }
    return a.removed ? 'other' : 'same';
  }
  function restoreCard() {
    var a = B.restoring;
    if (!a) { return null; }
    var kind = caseOf(a);
    var form = el('form', {class: 'fp-form fp-mail-form', novalidate: ''}, [M.errorLine()]);
    form.appendChild(el('p', {class: 'fp-bk-what', text: t('bk_restore_' + kind, {account: a.username, archive: a.name})}));
    var boxes = el('fieldset', {class: 'fp-bk-parts'}, [el('legend', {class: 'sig-label', text: t('bk_parts')})].concat(PARTS.map(function (p) {
      return el('label', {class: 'fp-check', for: 'fp-bk-part-' + p}, [el('input', {type: 'checkbox', id: 'fp-bk-part-' + p, name: 'parts', value: p, checked: true}),
        el('span', {text: partName(p)})]);
    })).concat([el('span', {class: 'sig-hint', text: t('bk_parts_hint')})]));
    form.appendChild(boxes);
    if (kind === 'remake') {
      var owner = el('select', {class: 'sig-select', id: 'fp-bk-owner', name: 'owner'}, [el('option', {value: '', text: t('bk_as_archived')})].concat(
        [FP.session.user.username].concat(B.resellers).map(function (u) { return el('option', {value: u, text: u}); })));
      var pkg = el('select', {class: 'sig-select', id: 'fp-bk-package', name: 'package'}, [el('option', {value: '', text: t('bk_as_archived')})].concat(
        B.packages.map(function (p) { return el('option', {value: p, text: p}); })));
      form.appendChild(M.field('fp-bk-owner', t('bk_owner'), owner, t('bk_owner_hint')));
      form.appendChild(M.field('fp-bk-package', t('bk_package'), pkg, t('bk_package_hint')));
    }
    form.appendChild(el('div', {class: 'fp-actions', 'data-fp-bk-acts': ''}));
    resetActs(form);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var chosen = PARTS.filter(function (p) { return form.querySelector('#fp-bk-part-' + p).checked; });
      if (!chosen.length) { M.fieldError(form, form.querySelector('#fp-bk-part-home'), t('bk_parts_pick')); return; }
      var body = {};
      if (chosen.length < PARTS.length) { body.parts = chosen; }
      if (kind === 'remake') {
        if (form.querySelector('#fp-bk-owner').value) { body.owner = form.querySelector('#fp-bk-owner').value; }
        if (form.querySelector('#fp-bk-package').value) { body.package = form.querySelector('#fp-bk-package').value; }
      }
      if (kind === 'other') { body.other_account = true; }
      ask(form, t(kind === 'other' ? 'bk_ask_other' : kind === 'remake' ? 'bk_ask_remake' : 'bk_ask_same', {account: a.username, archive: a.name,
        parts: chosen.map(partName).join(', ')}), kind === 'other' ? t('bk_restore_anyway') : t('bk_restore'), function (yes) {
        send(form, yes, body);
      });
    });
    return M.card('fp-bk-restore-h', t('bk_restore_title', {archive: a.name}), [form], 'fp-bk-restore');
  }
  function resetActs(form) {
    var acts = form.querySelector('[data-fp-bk-acts]');
    acts.textContent = '';
    acts.appendChild(el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bk_restore')}));
    acts.appendChild(el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'restore-close', text: t('cancel')}));
  }
  /* a question in place of the form's buttons: the answer runs go(yesButton); Cancel puts the buttons back */
  function ask(form, question, yesLabel, go) {
    var acts = form.querySelector('[data-fp-bk-acts]');
    acts.textContent = '';
    var yes = el('button', {class: 'sig-btn sig-btn--danger', type: 'button', text: yesLabel, 'aria-describedby': 'fp-bk-ask'});
    var no = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', text: t('cancel'), 'aria-describedby': 'fp-bk-ask'});
    acts.appendChild(el('p', {class: 'fp-mail-confirm', id: 'fp-bk-ask', text: question}));
    acts.appendChild(yes);
    acts.appendChild(no);
    no.addEventListener('click', function () {
      resetActs(form);
      acts.querySelector('.fp-submit').focus();
    });
    yes.addEventListener('click', function () { go(yes); });
    no.focus();
  }
  /* a restore the server accepted: the run it started is shown, with what it said, and followed until it ends */
  function restoreStarted(account, r, said) {
    B.status.running = cleanRun(r.run) || {kind: 'restore', username: account, started: ''};
    if (r.created === true && B.accounts.indexOf(account) < 0) { B.accounts.push(account); B.accounts.sort(); }
    B.watching = true;
    renderAll();
    M.say(B.page.querySelector('.fp-bk-now'), said);
    B.page.querySelector('#fp-bk-now-h').focus();
    poll();
  }
  function closeSome() {
    if (B.some) { B.some.stop(); }
    B.some = null;
  }
  function send(form, yes, body) {
    var a = B.restoring;
    UI.setBusy(yes, true);
    FP.call('post', 'backupRestore', body, {name: a.username, archive: a.name}).then(function (r) {
      r = r && typeof r === 'object' ? r : {};
      var said = [t('bk_restore_started', {account: a.username, archive: a.name})];
      if (r.created === true) { said.push(t(r.password === 'reset' ? 'bk_made_reset' : 'bk_made_kept', {account: a.username})); }
      var left = (Array.isArray(r.not_restored) ? r.not_restored : []).filter(function (n) { return typeof n === 'string' && n.length <= 253; });
      if (left.length) { said.push(t('bk_not_restored', {names: left.join(', ')})); }
      B.restoring = null;
      restoreStarted(a.username, r, said.join(' '));
    }, function (err) {
      var other = err.status === 409 && (err.code === 'other_account' || /other_account/.test(err.message || ''));
      resetActs(form);
      if (other && !body.other_account) {
        UI.showError(form, '');
        ask(form, t('bk_ask_other', {account: a.username, archive: a.name, parts: body.parts ? body.parts.map(partName).join(', ') : t('bk_parts_all')}),
          t('bk_restore_anyway'), function (y) {
            body.other_account = true;
            send(form, y, body);
          });
        return;
      }
      M.failed(form, err.field === 'parts' ? {message: err.message} : err);
      if (!form.contains(document.activeElement)) { form.querySelector('.fp-submit').focus(); }
    });
  }

  /* ---------- page ---------- */
  /* the cards drawn again, keeping the focus on the same control and the restore form as it is */
  function renderAll() {
    var active = document.activeElement;
    var key = null;
    if (active && B.page.contains(active)) {
      var row = active.closest('[data-fp-account], [data-fp-archive]');
      key = {id: active.id, act: active.getAttribute('data-fp-act'), row: row ? (row.hasAttribute('data-fp-account') ?
        '[data-fp-account="' + window.CSS.escape(row.getAttribute('data-fp-account')) + '"]' :
        '[data-fp-archive="' + window.CSS.escape(row.getAttribute('data-fp-archive')) + '"]') : ''};
    }
    var keep = B.page.querySelector('.fp-bk-restore');
    var said = B.page.querySelector('.fp-bk-now [data-fp-status]');
    var saidText = said ? said.textContent : '';
    B.page.textContent = '';
    B.page.appendChild(nowCard());
    M.say(B.page.querySelector('.fp-bk-now'), saidText);
    if (B.restoring) { B.page.appendChild(keep && B.keepForm ? keep : restoreCard()); }
    if (B.some) { B.page.appendChild(B.some.node); }
    if (B.dl) { B.page.appendChild(B.dl.node); }
    B.page.appendChild(accountsCard());
    B.page.appendChild(archivesCard());
    B.keepForm = false;
    if (key) {
      var again = key.id ? B.page.querySelector('#' + window.CSS.escape(key.id)) :
        key.row && key.act ? B.page.querySelector(key.row + ' [data-fp-act="' + key.act + '"]') : null;
      if (again) { again.focus(); }
    }
  }
  function load() {
    return Promise.all([FP.call('get', 'backups'), FP.call('get', 'backupStatus'), FP.call('get', 'accounts')]).then(function (r) {
      B.archives = cleanArchives(r[0]);
      B.status = cleanStatus(r[1]);
      B.accounts = cleanAccounts(r[2]);
    });
  }
  /* while a run goes on, asks how it is every few seconds; when it ends, says how and shows the new lists */
  function poll() {
    window.clearTimeout(B.timer);
    var page = B.page;
    B.timer = window.setTimeout(function () {
      if (!B || B.page !== page || !document.body.contains(page)) { return; }
      FP.call('get', 'backupStatus').then(function (r) {
        if (B.page !== page) { return; }
        var st = cleanStatus(r);
        if (st.running) {
          B.status = st;
          poll();
          return;
        }
        var was = B.status.running;
        load().then(function () {
          if (B.page !== page) { return; }
          B.keepForm = true;
          renderAll();
          var l = was ? B.status.last[was.username] : null;
          if (was && B.watching) {
            var ended = was.kind === 'import-read' ? t('bk_ended_read', {file: was.file}) : t('bk_ended', {account: was.username});
            M.say(page.querySelector('.fp-bk-now'), l ? ended + ' ' + lastText(l) : ended);
          }
          B.watching = false;
        }, function () { poll(); });
      }, function () { poll(); });
    }, POLL_MS);
  }

  function onClick(e) {
    var target = e.target.closest ? e.target : null;
    var b = target && B && B.page && B.page.contains(target) ? target.closest('[data-fp-act]') : null;
    if (!b) { return; }
    var a = b.getAttribute('data-fp-act');
    if (a === 'backup') {
      var u = b.closest('[data-fp-account]').getAttribute('data-fp-account');
      var cardNode = B.page.querySelector('.fp-bk-accounts');
      UI.showError(cardNode, '');
      UI.setBusy(b, true);
      FP.call('post', 'accountBackup', undefined, u).then(function (r) {
        B.status.running = cleanRun(r && r.run) || {kind: 'backup', username: u, started: ''};
        B.watching = true;
        B.keepForm = true;
        renderAll();
        M.say(B.page.querySelector('.fp-bk-now'), t('bk_backup_started', {account: u}));
        /* the button was busy, so the focus left it: back to the same account's */
        var again = B.page.querySelector('[data-fp-account="' + window.CSS.escape(u) + '"] [data-fp-act="backup"]');
        if (again) { again.focus(); }
        poll();
      }, function (err) {
        UI.setBusy(b, false);
        UI.showError(cardNode, err.message);
        b.focus();
      });
    } else if (a === 'download') {
      var who = b.closest('[data-fp-account]').getAttribute('data-fp-account');
      if (B.dl) { B.dl.stop(); }
      /* the download card of one account at a time, under the run in progress; Close goes back to its row */
      B.dl = FP.backupDownload.card(who, {onClose: function () {
        B.dl = null;
        renderAll();
        var row = B.page.querySelector('[data-fp-account="' + window.CSS.escape(who) + '"] [data-fp-act="download"]');
        (row || B.page.querySelector('#fp-bk-acct-h')).focus();
      }});
      renderAll();
      B.dl.node.querySelector('#fp-dl-h').focus();
    } else if (a === 'restore') {
      var name = b.closest('[data-fp-archive]').getAttribute('data-fp-archive');
      B.restoring = B.archives.filter(function (x) { return x.name === name; })[0] || null;
      B.back = name;
      closeSome();
      renderAll();
      B.page.querySelector('#fp-bk-restore-h').focus();
    } else if (a === 'restore-close') {
      B.restoring = null;
      renderAll();
      var back = B.page.querySelector('[data-fp-archive="' + window.CSS.escape(B.back || '') + '"] [data-fp-act="restore"]');
      (back || B.page.querySelector('#fp-bk-arch-h')).focus();
    } else if (a === 'restore-some') {
      var some = b.closest('[data-fp-archive]').getAttribute('data-fp-archive');
      var arch = B.archives.filter(function (x) { return x.name === some; })[0];
      if (!arch) { return; }
      closeSome();
      B.restoring = null;
      B.back = some;
      /* the card of one archive at a time, under the run in progress; Cancel goes back to the row's button */
      B.some = FP.restoreSome.card(arch, {other: arch.removed && B.accounts.indexOf(arch.username) >= 0, onClose: function () {
        closeSome();
        renderAll();
        var row = B.page.querySelector('[data-fp-archive="' + window.CSS.escape(some) + '"] [data-fp-act="restore-some"]');
        (row || B.page.querySelector('#fp-bk-arch-h')).focus();
      }, onStarted: function (r, said) {
        closeSome();
        restoreStarted(arch.username, r, said);
      }});
      renderAll();
      B.page.querySelector('#fp-ars-h').focus();
    }
  }
  document.addEventListener('click', onClick);
  /* the pieces the backup settings and destinations pages share */
  FP.bk = {str: str, when: when, size: size};

  FP.view('tool:backup_restore', function () {
    var tool = FP.tools.backup_restore;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('bk_desc'), cls: 'fp-mail fp-bk',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    if (B) { window.clearTimeout(B.timer); if (B.dl) { B.dl.stop(); } if (B.some) { B.some.stop(); } }
    B = {page: body, archives: [], status: {running: null, last: {}}, accounts: [], resellers: [], packages: [], filter: '', only: '',
      restoring: null, some: null, back: '', timer: 0, watching: false, keepForm: false, dl: null};
    var mine = B;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    /* the owners and packages a removed account can be made again on; without them the archive's are used */
    var extra = Promise.all([FP.call('get', 'resellers').then(function (r) {
      return (r && Array.isArray(r.resellers) ? r.resellers : []).map(function (x) { return x && str(x.username); }).filter(function (u) { return USER_RE.test(u); }).sort();
    }, function () { return []; }), FP.call('get', 'packages').then(function (r) {
      return (r && Array.isArray(r.packages) ? r.packages : []).map(function (p) { return p && str(p.name); }).filter(function (n) { return n && n.length <= 64; }).sort();
    }, function () { return []; })]);
    Promise.all([load(), extra]).then(function (r) {
      if (B !== mine) { return; }
      B.resellers = r[1][0];
      B.packages = r[1][1];
      renderAll();
      if (B.status.running) { poll(); }
    }, function (err) {
      if (B !== mine) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

/* freePanel mail filters (docs/api.md, "Email": filters): the customer panel's Account-wide mail filters
   (#/tool/global_filters), which run on every mailbox's mail first, and Mail filters (#/tool/mail_filters), one
   mailbox's own. A filter has a name, rules that must all (or any) match, and up to five actions; filters run in the
   order listed. Each change sends the whole list back (PUT), the way the server keeps it. Uses FP.mail from fp-mail.js. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var M = FP.mail;
  var t = UI.t;
  var el = UI.el;

  var PARTS = ['from', 'to', 'subject', 'reply-to', 'body', 'message'];
  var OPS = ['contains', 'not-contains', 'is', 'begins', 'ends'];
  var KINDS = ['folder', 'redirect', 'pipe', 'discard', 'fail', 'stop'];
  var ARG = {folder: 'flt_arg_folder', redirect: 'flt_arg_redirect', fail: 'flt_arg_fail', pipe: 'flt_arg_program'};
  var PROGRAM_RE = /^[a-z0-9][a-z0-9._-]{0,47}$/;
  /* a program runs in one mailbox's own pipe folder, so the account's filters, which run on every mailbox, can't name one; and the server
     says whether it can run one at all, so the action is left out where it would fail (a filter that already has one keeps it listed) */
  function kindsHere(current) { return KINDS.filter(function (k) { return k !== 'pipe' || current === 'pipe' || (F.scope !== 'account' && F.state && F.state.programs); }); }
  var FOLDER_RE = /^[\p{L}\p{N} _.-]+(\/[\p{L}\p{N} _.-]+)*$/u;
  var MAX_FILTERS = 100;
  var MAX_RULES = 20;
  var MAX_ACTIONS = 5;
  var CONTROL = /[\u0000-\u001f\u007f]/;   // eslint-disable-line no-control-regex -- values are one line

  var F = {page: null, state: null, account: '', scope: '', address: '', editing: null};

  function str(v) { return typeof v === 'string' ? v : ''; }
  /* a filter as the page shows and sends it; null for one it can't read (kept, shown as such, and sent back as it came) */
  function cleanFilter(f) {
    var rules = Array.isArray(f.rules) ? f.rules : [];
    var acts = Array.isArray(f.actions) ? f.actions : [];
    var ok = rules.length && acts.length && rules.every(function (r) { return r && PARTS.indexOf(r.part) >= 0 && (r.part === 'message' || (OPS.indexOf(r.op) >= 0 && typeof r.value === 'string')); }) &&
      acts.every(function (a) { return a && KINDS.indexOf(a.kind) >= 0; });
    if (!ok) { return null; }
    return {name: str(f.name), match: f.match === 'any' ? 'any' : 'all',
      rules: rules.map(function (r) { return r.part === 'message' ? {part: 'message', op: '', value: ''} : {part: r.part, op: r.op, value: r.value}; }),
      actions: acts.map(function (a) { return a.kind === 'discard' || a.kind === 'stop' ? {kind: a.kind} : {kind: a.kind, arg: str(a.arg)}; })};
  }
  function list() {
    if (F.scope === 'account') { return F.state.filters; }
    var m = F.state.mailboxes.filter(function (x) { return x.address === F.address; })[0];
    return m ? m.filters : [];
  }
  /* what a filter does, in a line each for its rules and its actions */
  function whenText(f) {
    return f.rules.map(function (r) { return r.part === 'message' ? t('flt_rule_message') : t('flt_rule_text', {part: t('flt_part_' + r.part), op: t('flt_op_' + r.op), value: r.value}); })
      .join(f.match === 'any' ? t('flt_or') : t('flt_and'));
  }
  function thenText(f) {
    var s = f.actions.map(function (a) { return t('flt_do_' + a.kind, {arg: a.arg || ''}); }).join(t('flt_then'));
    return s.charAt(0).toUpperCase() + s.slice(1);
  }

  /* ---- the list ---- */
  function row(f, i, n) {
    var c = cleanFilter(f);
    var name = c ? c.name : t('flt_unreadable');
    return el('tr', {'data-fp-filter': String(i)}, [
      el('td', {class: 'fp-num', text: String(i + 1)}),
      el('th', {scope: 'row', class: 'fp-flt-name', text: name}),
      el('td', {class: 'fp-flt-text', text: c ? whenText(c) : '—'}),
      el('td', {class: 'fp-flt-text', text: c ? thenText(c) : '—'}),
      el('td', {class: 'fp-mail-acts'}, [
        i > 0 ? el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'up', 'aria-label': t('flt_up_of', {name: name}),
          text: t('flt_up')}) : null,
        i < n - 1 ? el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'down', 'aria-label': t('flt_down_of', {name: name}),
          text: t('flt_down')}) : null,
        c ? el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'edit', 'aria-label': t('flt_change_of', {name: name}),
          text: t('flt_change')}) : null,
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'remove',
          'aria-label': t('flt_remove_of', {name: name}), text: t('flt_remove')})])]);
  }
  function listCard() {
    var fs = list();
    var parts = [M.errorLine(), M.statusLine()];
    if (!fs.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: F.scope === 'account' ? t('flt_none_account') : t('flt_none_box')}));
    } else {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-flt-list-h'}, [
        el('table', {class: 'sig-table fp-mail-table fp-flt-table'}, [el('thead', null, [el('tr', null, [
          el('th', {scope: 'col', class: 'fp-num', text: t('flt_order')}), el('th', {scope: 'col', text: t('flt_name')}),
          el('th', {scope: 'col', text: t('flt_when')}), el('th', {scope: 'col', text: t('flt_then_col')}),
          el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]),
        el('tbody', null, fs.map(function (f, i) { return row(f, i, fs.length); }))])]));
    }
    var add = fs.length < MAX_FILTERS && F.editing === null ?
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'new', text: t('flt_new')})]) : null;
    var title = F.scope === 'account' ? t('flt_list_account') : t('flt_list_box', {address: F.address});
    return M.card('fp-flt-list-h', title, parts.concat([add]), 'fp-flt-list');
  }

  /* ---- the editor ---- */
  function options(values, prefix, chosen) {
    return values.map(function (v) { return el('option', {value: v, text: t(prefix + v), selected: v === chosen ? true : null}); });
  }
  function ruleRow(r, n) {
    var id = 'fp-flt-r' + n;
    return el('li', {class: 'fp-flt-line', 'data-fp-rule': ''}, [
      el('select', {class: 'sig-select', id: id + '-part', name: 'part', 'aria-label': t('flt_rule_part', {n: n + 1})}, options(PARTS, 'flt_part_', r.part)),
      el('select', {class: 'sig-select', id: id + '-op', name: 'op', 'aria-label': t('flt_rule_op', {n: n + 1}), hidden: r.part === 'message' ? true : null}, options(OPS, 'flt_op_', r.op || 'contains')),
      el('input', {class: 'sig-input', id: id + '-value', name: 'value', type: 'text', maxlength: '255', autocomplete: 'off', spellcheck: 'false',
        value: r.value, 'aria-label': t('flt_rule_value', {n: n + 1}), hidden: r.part === 'message' ? true : null}),
      el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'rule-remove',
        'aria-label': t('flt_rule_remove', {n: n + 1}), text: t('flt_remove')})]);
  }
  function actionRow(a, n) {
    var id = 'fp-flt-a' + n;
    var arg = el('input', {class: 'sig-input', id: id + '-arg', name: 'arg', type: 'text', maxlength: '255', autocomplete: 'off', spellcheck: 'false',
      value: a.arg || '', 'aria-label': t(ARG[a.kind] || 'flt_arg_folder', {n: n + 1}), hidden: ARG[a.kind] ? null : true});
    return el('li', {class: 'fp-flt-line', 'data-fp-action': ''}, [
      el('select', {class: 'sig-select', id: id + '-kind', name: 'kind', 'aria-label': t('flt_action_kind', {n: n + 1})}, options(kindsHere(a.kind), 'flt_kind_', a.kind)), arg,
      el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'action-remove',
        'aria-label': t('flt_action_remove', {n: n + 1}), text: t('flt_remove')})]);
  }
  /* the draft as the form holds it, so adding or removing a line keeps what was typed */
  function readDraft(form) {
    var rules = Array.prototype.map.call(form.querySelectorAll('[data-fp-rule]'), function (li) {
      return {part: li.querySelector('[name="part"]').value, op: li.querySelector('[name="op"]').value, value: li.querySelector('[name="value"]').value};
    });
    var actions = Array.prototype.map.call(form.querySelectorAll('[data-fp-action]'), function (li) {
      return {kind: li.querySelector('[name="kind"]').value, arg: li.querySelector('[name="arg"]').value};
    });
    var match = form.querySelector('[name="match"]:checked');
    return {name: form.querySelector('[name="name"]').value, match: match ? match.value : 'all', rules: rules, actions: actions};
  }
  function editCard() {
    var d = F.editing.draft;
    var match = el('fieldset', {class: 'fp-flt-set'}, [el('legend', {class: 'sig-label', text: t('flt_match')})].concat(['all', 'any'].map(function (v) {
      return el('label', {class: 'fp-check'}, [el('input', {type: 'radio', name: 'match', value: v, checked: d.match === v ? true : null}),
        el('span', {text: t('flt_match_' + v)})]);
    })));
    var rules = el('fieldset', {class: 'fp-flt-set'}, [el('legend', {class: 'sig-label', id: 'fp-flt-rules-h', text: t('flt_rules')}),
      el('ol', {class: 'fp-flt-lines'}, d.rules.map(ruleRow)),
      d.rules.length < MAX_RULES ? el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'rule-add', text: t('flt_rule_add')}) : null]);
    var actions = el('fieldset', {class: 'fp-flt-set'}, [el('legend', {class: 'sig-label', id: 'fp-flt-actions-h', text: t('flt_actions')}),
      el('p', {class: 'sig-hint', text: t('flt_actions_hint')}),
      F.scope !== 'account' && F.state && !F.state.programs ? el('p', {class: 'sig-hint', 'data-fp-programs-note': '', text: t('flt_no_programs', {why: F.state.programsWhy || t('flt_no_programs_why')})}) : null,
      el('ol', {class: 'fp-flt-lines'}, d.actions.map(actionRow)),
      d.actions.length < MAX_ACTIONS ? el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'action-add', text: t('flt_action_add')}) : null]);
    var form = el('form', {class: 'fp-form fp-flt-form', novalidate: ''}, [M.errorLine(),
      M.field('fp-flt-name', t('flt_name'), el('input', {class: 'sig-input', id: 'fp-flt-name', name: 'name', type: 'text', maxlength: '64', value: d.name,
        autocomplete: 'off'})), match, rules, actions,
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('flt_save')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'close', text: t('cancel')})])]);
    form.addEventListener('change', function (e) {
      if (e.target.name === 'part') {
        var rule = e.target.closest('[data-fp-rule]');
        var whole = e.target.value === 'message';
        rule.querySelector('[name="op"]').hidden = whole;
        rule.querySelector('[name="value"]').hidden = whole;
        return;
      }
      if (e.target.name !== 'kind') { return; }
      var li = e.target.closest('[data-fp-action]');
      var arg = li.querySelector('[name="arg"]');
      var n = Array.prototype.indexOf.call(li.parentNode.children, li);
      arg.hidden = !ARG[e.target.value];
      if (ARG[e.target.value]) { arg.setAttribute('aria-label', t(ARG[e.target.value], {n: n + 1})); } else { arg.value = ''; }
    });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var f = check(form, readDraft(form));
      if (!f) { return; }
      var fs = list().slice();
      var at = F.editing.index;
      if (at === -1) { fs.push(f); } else { fs[at] = f; }
      UI.setBusy(b, true);
      save(fs).then(function () {
        F.editing = null;
        render();
        M.say(F.page.querySelector('.fp-flt-list'), at === -1 ? t('flt_added', {name: f.name}) : t('flt_saved', {name: f.name}));
        var i = at === -1 ? list().length - 1 : at;
        var back = F.page.querySelector('tr[data-fp-filter="' + i + '"] [data-fp-act="edit"]');
        (back || F.page.querySelector('#fp-flt-list-h')).focus();
      }, function (err) {
        UI.setBusy(b, false);
        M.failed(form, err.field === 'filters' ? {message: err.message} : err);
      });
    });
    var title = F.editing.index === -1 ? t('flt_new_title') : t('flt_edit_title', {name: d.name});
    return M.card('fp-flt-edit-h', title, [form], 'fp-flt-edit');
  }
  /* the server's rules (docs/api.md), checked before sending so the message names the line */
  function check(form, d) {
    var name = d.name.trim();
    var nameField = form.querySelector('[name="name"]');
    if (!name) { M.fieldError(form, nameField, t('flt_need_name')); return null; }
    if (CONTROL.test(name)) { M.fieldError(form, nameField, t('flt_one_line')); return null; }
    var lines = form.querySelectorAll('[data-fp-rule]');
    if (!d.rules.length) { M.fieldError(form, form.querySelector('[data-fp-act="rule-add"]'), t('flt_need_rule')); return null; }
    for (var i = 0; i < d.rules.length; i++) {
      var v = lines[i].querySelector('[name="value"]');
      if (d.rules[i].part === 'message') { continue; }
      if (!d.rules[i].value.trim()) { M.fieldError(form, v, t('flt_need_value', {n: i + 1})); return null; }
      if (CONTROL.test(d.rules[i].value)) { M.fieldError(form, v, t('flt_one_line_n', {n: i + 1})); return null; }
    }
    var acts = form.querySelectorAll('[data-fp-action]');
    if (!d.actions.length) { M.fieldError(form, form.querySelector('[data-fp-act="action-add"]'), t('flt_need_action')); return null; }
    var out = [];
    for (var j = 0; j < d.actions.length; j++) {
      var a = d.actions[j];
      var arg = acts[j].querySelector('[name="arg"]');
      var val = a.arg.trim();
      if (a.kind === 'folder') {
        if (!val || val.length > 64 || !FOLDER_RE.test(val) || val.indexOf('..') >= 0) { M.fieldError(form, arg, t('flt_folder_bad', {n: j + 1})); return null; }
        if (/^inbox(\/|$)/i.test(val)) { M.fieldError(form, arg, t('flt_folder_inbox', {n: j + 1})); return null; }
        out.push({kind: 'folder', arg: val});
      } else if (a.kind === 'redirect') {
        val = val.toLowerCase();
        if (!M.isAddress(val)) { M.fieldError(form, arg, t('flt_redirect_bad', {n: j + 1})); return null; }
        out.push({kind: 'redirect', arg: val});
      } else if (a.kind === 'pipe') {
        if (!PROGRAM_RE.test(val) || val.indexOf('..') >= 0) { M.fieldError(form, arg, t('flt_program_bad', {n: j + 1})); return null; }
        out.push({kind: 'pipe', arg: val});
      } else if (a.kind === 'fail') {
        if (!val) { M.fieldError(form, arg, t('flt_need_reason', {n: j + 1})); return null; }
        if (CONTROL.test(val)) { M.fieldError(form, arg, t('flt_one_line_n', {n: j + 1})); return null; }
        out.push({kind: 'fail', arg: val});
      } else {
        out.push({kind: a.kind});
      }
    }
    return {name: name, match: d.match === 'any' ? 'any' : 'all', rules: d.rules.map(function (r) { return r.part === 'message' ? {part: 'message'} : {part: r.part, op: r.op, value: r.value.trim()}; }),
      actions: out};
  }
  function save(fs) {
    var call = F.scope === 'account' ? FP.call('put', 'mailFilters', {filters: fs}, F.account) :
      FP.call('put', 'mailboxFilters', {filters: fs}, {name: F.account, address: F.address});
    return call.then(function (r) { F.state = M.clean(r); });
  }

  /* ---- the page ---- */
  function pickerCard() {
    var pick = el('select', {class: 'sig-select', id: 'fp-flt-box', name: 'mailbox'}, F.state.mailboxes.map(function (m) {
      return el('option', {value: m.address, text: m.address, selected: m.address === F.address ? true : null});
    }));
    pick.addEventListener('change', function () {
      F.address = pick.value;
      F.editing = null;
      render();
      F.page.querySelector('#fp-flt-box').focus();
    });
    return el('div', {class: 'fp-flt-pick'}, [M.field('fp-flt-box', t('flt_mailbox'), pick, t('flt_mailbox_hint'))]);
  }
  function render() {
    F.page.textContent = '';
    if (!F.state.filtersOn) {
      F.page.appendChild(FP.empty(t('flt_unavailable_title'), t('flt_unavailable')));
      return;
    }
    if (F.scope === 'mailbox') {
      if (!F.state.mailboxes.length) {
        F.page.appendChild(FP.empty(t('flt_no_mailboxes_title'), t('flt_no_mailboxes'),
          el('a', {class: 'sig-btn sig-btn--primary', href: '#/tool/mailboxes', text: t('flt_go_mailboxes')})));
        return;
      }
      if (!F.state.mailboxes.some(function (m) { return m.address === F.address; })) { F.address = F.state.mailboxes[0].address; }
      F.page.appendChild(pickerCard());
    }
    F.page.appendChild(listCard());
    if (F.editing) { F.page.appendChild(editCard()); }
  }
  function focusRow(i, act, other) {
    var b = F.page.querySelector('tr[data-fp-filter="' + i + '"] [data-fp-act="' + act + '"]') ||
      F.page.querySelector('tr[data-fp-filter="' + i + '"] [data-fp-act="' + other + '"]');
    if (b) { b.focus(); }
  }
  function listError(err, i, act) {
    render();
    UI.showError(F.page.querySelector('.fp-flt-list'), err.message);
    focusRow(i, act, 'remove');
  }

  document.addEventListener('click', function (e) {
    var target = e.target.closest ? e.target : null;
    if (!target || !F.page || !F.page.contains(target)) { return; }
    var b = target.closest('[data-fp-act]');
    if (!b) { return; }
    var a = b.getAttribute('data-fp-act');
    var tr = b.closest('tr[data-fp-filter]');
    var i = tr ? Number(tr.getAttribute('data-fp-filter')) : -1;
    var fs = list();
    var form = b.closest('form');
    if (a === 'new') {
      F.editing = {index: -1, draft: {name: '', match: 'all', rules: [{part: 'from', op: 'contains', value: ''}], actions: [{kind: 'folder', arg: ''}]}};
      render();
      F.page.querySelector('#fp-flt-name').focus();
    } else if (a === 'edit') {
      var c = cleanFilter(fs[i]);
      F.editing = {index: i, draft: {name: c.name, match: c.match, rules: c.rules, actions: c.actions}};
      render();
      F.page.querySelector('#fp-flt-name').focus();
    } else if (a === 'close') {
      var was = F.editing.index;
      F.editing = null;
      render();
      if (was >= 0) { focusRow(was, 'edit', 'remove'); } else { F.page.querySelector('[data-fp-act="new"]').focus(); }
    } else if (a === 'rule-add' || a === 'action-add' || a === 'rule-remove' || a === 'action-remove') {
      var d = readDraft(form);
      var li = b.closest('li');
      var n = li ? Array.prototype.indexOf.call(li.parentNode.children, li) : -1;
      if (a === 'rule-add') { d.rules.push({part: 'subject', op: 'contains', value: ''}); }
      if (a === 'action-add') { d.actions.push({kind: 'stop'}); }
      if (a === 'rule-remove') { d.rules.splice(n, 1); }
      if (a === 'action-remove') { d.actions.splice(n, 1); }
      F.editing.draft = d;
      render();
      var key = a.indexOf('rule') === 0 ? 'r' : 'a';
      var count = key === 'r' ? d.rules.length : d.actions.length;
      var at = /add$/.test(a) ? count - 1 : Math.min(n, count - 1);
      var next = at >= 0 ? document.getElementById('fp-flt-' + key + at + (key === 'r' ? '-part' : '-kind')) : null;
      (next || F.page.querySelector('[data-fp-act="' + (key === 'r' ? 'rule-add' : 'action-add') + '"]') || F.page.querySelector('#fp-flt-edit-h')).focus();
    } else if (a === 'up' || a === 'down') {
      var j = a === 'up' ? i - 1 : i + 1;
      var moved = fs.slice();
      moved.splice(j, 0, moved.splice(i, 1)[0]);
      UI.setBusy(b, true);
      save(moved).then(function () {
        if (F.editing && F.editing.index === i) { F.editing.index = j; } else if (F.editing && F.editing.index === j) { F.editing.index = i; }
        render();
        var name = cleanFilter(list()[j]);
        M.say(F.page.querySelector('.fp-flt-list'), t('flt_moved', {name: name ? name.name : '', n: j + 1}));
        focusRow(j, a, a === 'up' ? 'down' : 'up');
      }, function (err) { listError(err, i, a); });
    } else if (a === 'remove') {
      var c2 = cleanFilter(fs[i]);
      M.confirmIn(tr.querySelector('.fp-mail-acts'), t('flt_remove_ask', {name: c2 ? c2.name : t('flt_unreadable')}), 'remove-yes', t('flt_remove'));
    } else if (a === 'confirm-no') {
      render();
      focusRow(i, 'remove', 'edit');
    } else if (a === 'remove-yes') {
      var c3 = cleanFilter(fs[i]);
      var left = fs.slice();
      left.splice(i, 1);
      UI.setBusy(b, true);
      save(left).then(function () {
        if (F.editing && F.editing.index === i) { F.editing = null; } else if (F.editing && F.editing.index > i) { F.editing.index--; }
        render();
        M.say(F.page.querySelector('.fp-flt-list'), t('flt_removed', {name: c3 ? c3.name : t('flt_unreadable')}));
        F.page.querySelector('#fp-flt-list-h').focus();
      }, function (err) { listError(err, i, 'remove'); });
    }
  });

  function view(id, scope) {
    FP.view('tool:' + id, function () {
      F.page = null;
      var body = M.frame(id, 'fp-flt');
      if (!body) { return; }
      F.page = body;
      F.scope = scope;
      F.account = FP.account();
      F.editing = null;
      body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
      FP.call('get', 'mail', undefined, F.account).then(function (r) {
        if (F.page !== body) { return; }
        F.state = M.clean(r);
        render();
      }, function (err) {
        if (F.page !== body) { return; }
        body.textContent = '';
        body.appendChild(FP.empty(FP.tools[id].label, err.message));
      });
    });
  }
  view('global_filters', 'account');
  view('mail_filters', 'mailbox');
})();

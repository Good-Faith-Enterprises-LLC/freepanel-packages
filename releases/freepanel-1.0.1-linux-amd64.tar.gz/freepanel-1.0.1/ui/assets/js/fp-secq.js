/* freePanel security questions (#/tool/security_questions), on both panels (docs/api.md, "Authentication"): a login answers two or three
   questions, and a password reset then asks for the answers as well as the emailed link. The administrator also keeps the list of questions
   and what a reset asks (admin only), and clears another login's answers (admin; a reseller for its own logins). Answers are only ever
   sent, never shown again. Question texts, login names and counts are shown as text, never as markup. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var MAX_Q = 50;
  var LOGIN_RE = /^[a-z][a-z0-9._@-]{0,63}$/;
  var S = null;

  function str(v) { return typeof v === 'string' ? v : ''; }
  function whole(v, lo, hi, dflt) { return typeof v === 'number' && isFinite(v) && v >= lo && v <= hi ? Math.floor(v) : dflt; }
  function questions(list) {
    return (Array.isArray(list) ? list : []).slice(0, MAX_Q).filter(function (q) { return q && whole(q.id, 1, 1e12, 0) && str(q.text); }).map(function (q) {
      return {id: q.id, text: str(q.text).slice(0, 200), answered: whole(q.answered, 0, 1e9, 0)};
    });
  }
  function cleanMine(r) {
    r = r && typeof r === 'object' ? r : {};
    return {offered: questions(r.questions), mine: questions(r.mine), min: whole(r.min_answers, 1, 3, 2), max: whole(r.max_answers, 1, 3, 3), enforce: r.enforce_on_reset !== false};
  }
  function cleanAdmin(r) {
    r = r && typeof r === 'object' ? r : {};
    var s = r.settings && typeof r.settings === 'object' ? r.settings : {};
    return {list: questions(r.questions), enforce: s.enforce_on_reset !== false, min: whole(s.min_answers, 1, 3, 2), maxQuestions: whole(r.max_questions, 3, 500, MAX_Q)};
  }
  function isAdmin() { return FP.realm === 'admin' && FP.session.user.role === 'admin'; }
  function isStaff() { return FP.realm === 'admin'; }

  /* ---------- your own answers ---------- */
  function mineCard() {
    var d = S.mine;
    var parts = [M.errorLine(), M.statusLine()];
    if (d.mine.length) {
      parts.push(el('p', {class: 'fp-sq-state', 'data-fp-sq-state': ''}, [el('span', {class: 'sig-pill sig-pill--ok', text: t('sq_set')}), ' ',
        el('span', {text: t('sq_set_n', {n: String(d.mine.length)})})]));
      parts.push(el('ul', {class: 'fp-sq-mine', 'aria-label': t('sq_mine_list')}, d.mine.map(function (q) { return el('li', {'data-fp-sq-mine': String(q.id), text: q.text}); })));
    } else {
      parts.push(el('p', {class: 'fp-sq-state', 'data-fp-sq-state': ''}, [el('span', {class: 'sig-pill', text: t('sq_not_set')}), ' ', el('span', {text: t('sq_not_set_why')})]));
    }
    if (!d.enforce) { parts.push(el('p', {class: 'fp-muted', 'data-fp-sq-off': '', text: t('sq_off')})); }
    var rows = [];
    for (var i = 0; i < d.max; i++) {
      var sel = el('select', {class: 'sig-select', id: 'fp-sq-q' + i, name: 'q' + i}, [el('option', {value: '', text: t('sq_choose')})].concat(
        d.offered.map(function (q) { return el('option', {value: String(q.id), text: q.text}); })));
      var ans = el('input', {class: 'sig-input', id: 'fp-sq-a' + i, name: 'a' + i, type: 'text', maxlength: '64', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none'});
      rows.push(el('fieldset', {class: 'fp-sq-pair'}, [el('legend', {class: 'sig-label', text: t(i < d.min ? 'sq_pair' : 'sq_pair_opt', {n: String(i + 1)})}),
        M.field('fp-sq-q' + i, t('sq_question'), sel), M.field('fp-sq-a' + i, t('sq_answer'), ans, i === 0 ? t('sq_answer_hint') : null)]));
    }
    var pw = el('input', {class: 'sig-input', id: 'fp-sq-pw', name: 'password', type: 'password', autocomplete: 'current-password', maxlength: '1024'});
    var form = el('form', {class: 'fp-form fp-mail-form fp-sq-set', novalidate: ''}, [M.errorLine(), M.statusLine()].concat(rows, [
      M.field('fp-sq-pw', t('sq_password'), pw, t('sq_password_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t(d.mine.length ? 'sq_replace' : 'sq_save')})])]));
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var answers = [];
      var seen = {};
      var seenAnswer = {};
      for (var i = 0; i < d.max; i++) {
        var q = form.querySelector('[name="q' + i + '"]');
        var a = form.querySelector('[name="a' + i + '"]');
        if (!q.value && !a.value.trim()) { continue; }
        if (!q.value) { M.fieldError(form, q, t('sq_need_question', {n: String(i + 1)})); return; }
        if (seen[q.value]) { M.fieldError(form, q, t('sq_twice')); return; }
        seen[q.value] = true;
        var len = Array.from(a.value.trim().replace(/\s+/g, ' ')).length;
        if (len < 3 || len > 64) { M.fieldError(form, a, t('sq_answer_len', {n: String(i + 1)})); return; }
        /* as the server takes them: case and spacing do not make an answer a different one */
        var norm = a.value.trim().replace(/\s+/g, ' ').toLowerCase();
        if (seenAnswer[norm]) { M.fieldError(form, a, t('sq_answer_twice', {n: String(i + 1)})); return; }
        seenAnswer[norm] = true;
        answers.push({question_id: Number(q.value), answer: a.value});
      }
      if (answers.length < d.min) { M.fieldError(form, form.querySelector('[name="q0"]'), t('sq_need_n', {n: String(d.min)})); return; }
      if (!pw.value) { M.fieldError(form, pw, t('sq_need_password')); return; }
      UI.setBusy(b, true);
      M.say(form, t('sq_saving'));
      FP.call('put', 'secq', {current_password: pw.value, answers: answers}).then(function () {
        return reload(t('sq_saved'));
      }, function (err) { UI.setBusy(b, false); M.say(form, ''); M.failed(form, inputOf(err)); });
    });
    var parts2 = parts.concat([form]);
    if (d.mine.length) { parts2.push(clearForm()); }
    return M.card('fp-sq-mine-h', t('sq_mine_title'), parts2, 'fp-sq-mine-card');
  }
  /* the server names an answer's fields answers[0].answer and answers[0].question_id; the form's are a0 and q0 */
  function inputOf(err) {
    var m = /^answers\[([0-9])\]\.(answer|question_id)$/.exec(err && typeof err.field === 'string' ? err.field : '');
    if (!m) { return err; }
    var e = Object.create(err);
    e.field = (m[2] === 'answer' ? 'a' : 'q') + m[1];
    return e;
  }
  function clearForm() {
    var pw = el('input', {class: 'sig-input', id: 'fp-sq-cpw', name: 'password', type: 'password', autocomplete: 'current-password', maxlength: '1024'});
    var form = el('form', {class: 'fp-form fp-mail-form fp-sq-clear', novalidate: ''}, [el('h3', {class: 'fp-h3', id: 'fp-sq-clear-h', text: t('sq_clear_title')}), M.errorLine(),
      M.field('fp-sq-cpw', t('sq_password'), pw),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--danger fp-submit', type: 'submit', text: t('sq_clear')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      if (!pw.value) { M.fieldError(form, pw, t('sq_need_password')); return; }
      UI.setBusy(b, true);
      FP.call('post', 'secqClear', {current_password: pw.value}).then(function () {
        return reload(t('sq_cleared'));
      }, function (err) { UI.setBusy(b, false); M.failed(form, err); });
    });
    return form;
  }

  /* ---------- the administrator's list ---------- */
  function listCard() {
    var A = S.admin;
    var parts = [M.errorLine(), M.statusLine()];
    parts.push(el('ul', {class: 'fp-sq-list', 'aria-label': t('sq_list_label')}, A.list.map(function (q) {
      return el('li', {class: 'fp-sq-item', 'data-fp-sq-q': String(q.id)}, [
        el('span', {class: 'fp-sq-text', text: q.text}),
        el('span', {class: 'fp-muted fp-sq-count', text: t('sq_answered', {n: String(q.answered)})}),
        el('span', {class: 'fp-sq-acts'}, [el('button', {class: 'sig-btn sig-btn--danger sig-btn--sm', type: 'button', 'data-fp-act': 'remove',
          'aria-label': t('sq_remove_of', {question: q.text}), text: t('sq_remove')})])]);
    })));
    var text = el('input', {class: 'sig-input', id: 'fp-sq-new', name: 'text', type: 'text', maxlength: '150', autocomplete: 'off'});
    var form = el('form', {class: 'fp-form fp-mail-form fp-sq-add', novalidate: ''}, [el('h3', {class: 'fp-h3', id: 'fp-sq-add-h', text: t('sq_add_title')}), M.errorLine(),
      M.field('fp-sq-new', t('sq_new'), text, t('sq_new_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('sq_add')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var v = text.value.trim().replace(/\s+/g, ' ');
      var n = Array.from(v).length;
      if (n < 10 || n > 150) { M.fieldError(form, text, t('sq_new_len')); return; }
      if (A.list.length >= A.maxQuestions) { M.fieldError(form, text, t('sq_full', {n: String(A.maxQuestions)})); return; }
      UI.setBusy(b, true);
      FP.call('post', 'secqAdmin', {text: v}).then(function () { return reload(t('sq_added'), 'list'); }, function (err) { UI.setBusy(b, false); M.failed(form, err); });
    });
    return M.card('fp-sq-list-h', t('sq_list_title'), parts.concat([el('p', {class: 'fp-muted', text: t('sq_list_note')}), form]), 'fp-sq-list-card');
  }
  function settingsCard() {
    var A = S.admin;
    var on = el('input', {type: 'checkbox', id: 'fp-sq-enforce', name: 'enforce', checked: A.enforce ? true : null, 'aria-describedby': 'fp-sq-enforce-hint'});
    var min = el('select', {class: 'sig-select', id: 'fp-sq-min', name: 'min'}, [1, 2, 3].map(function (n) {
      return el('option', {value: String(n), selected: n === A.min ? true : null, text: t('sq_min_n', {n: String(n)})});
    }));
    var form = el('form', {class: 'fp-form fp-mail-form fp-sq-settings', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'sig-field'}, [el('label', {class: 'fp-check', for: 'fp-sq-enforce'}, [on, el('span', {text: t('sq_enforce')})]),
        el('span', {class: 'sig-hint', id: 'fp-sq-enforce-hint', text: t('sq_enforce_hint')})]),
      M.field('fp-sq-min', t('sq_min'), min, t('sq_min_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('sq_settings_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      UI.setBusy(b, true);
      FP.call('put', 'secqSettings', {enforce_on_reset: on.checked, min_answers: Number(min.value)}).then(function () {
        return reload(t('sq_settings_saved'), 'settings');
      }, function (err) { UI.setBusy(b, false); M.failed(form, err); });
    });
    return M.card('fp-sq-settings-h', t('sq_settings_title'), [form], 'fp-sq-settings-card');
  }

  /* ---------- clearing another login's answers ---------- */
  function otherCard() {
    var login = el('input', {class: 'sig-input', id: 'fp-sq-login', name: 'login', type: 'text', maxlength: '64', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none'});
    var form = el('form', {class: 'fp-form fp-mail-form fp-sq-other', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-sq-login', t('sq_login'), login, t(isAdmin() ? 'sq_login_hint_admin' : 'sq_login_hint_reseller')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--danger fp-submit', type: 'submit', text: t('sq_other_clear')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var v = login.value.trim().toLowerCase();
      if (!LOGIN_RE.test(v)) { M.fieldError(form, login, t('sq_login_bad')); return; }
      UI.setBusy(b, true);
      FP.call('post', 'secqLogin', {}, {login: v}).then(function () {
        UI.setBusy(b, false);
        login.value = '';
        M.say(form, t('sq_other_done', {login: v}));
        login.focus();
      }, function (err) { UI.setBusy(b, false); M.failed(form, err); });
    });
    return M.card('fp-sq-other-h', t('sq_other_title'), [el('p', {class: 'fp-muted', text: t('sq_other_desc')}), form], 'fp-sq-other-card');
  }

  /* ---------- page ---------- */
  function render() {
    S.page.textContent = '';
    S.page.appendChild(mineCard());
    if (S.admin) {
      S.page.appendChild(listCard());
      S.page.appendChild(settingsCard());
    }
    if (isStaff()) { S.page.appendChild(otherCard()); }
  }
  function fetchAll() {
    var calls = [FP.call('get', 'secq')];
    if (isAdmin()) { calls.push(FP.call('get', 'secqAdmin')); }
    return Promise.all(calls).then(function (r) {
      S.mine = cleanMine(r[0]);
      S.admin = r[1] ? cleanAdmin(r[1]) : null;
    });
  }
  /* the lists as the server has them now, and a line under the first card */
  function reload(said, where) {
    var mine = S;
    var at = where || 'mine';
    return fetchAll().then(function () {
      if (S !== mine) { return; }
      render();
      M.say(S.page.querySelector('.fp-sq-' + at + '-card'), said);
      S.page.querySelector('#fp-sq-' + at + '-h').focus();
    });
  }

  document.addEventListener('click', function (e) {
    var target = e.target.closest ? e.target : null;
    var b = target && S && S.page && S.page.contains(target) ? target.closest('[data-fp-act]') : null;
    if (!b) { return; }
    var a = b.getAttribute('data-fp-act');
    var item = b.closest('[data-fp-sq-q]');
    var card = S.page.querySelector('.fp-sq-list-card');
    if (a === 'remove' && item) {
      var q = S.admin.list.filter(function (x) { return String(x.id) === item.getAttribute('data-fp-sq-q'); })[0];
      if (!q) { return; }
      M.confirmIn(b.parentNode, t('sq_remove_ask', {n: String(q.answered)}), 'remove-yes', t('sq_remove'));
    } else if (a === 'confirm-no' && item) {
      var cell = b.parentNode;
      cell.textContent = '';
      cell.appendChild(el('button', {class: 'sig-btn sig-btn--danger sig-btn--sm', type: 'button', 'data-fp-act': 'remove', 'aria-label': t('sq_remove_of', {question: item.querySelector('.fp-sq-text').textContent}), text: t('sq_remove')}));
      cell.firstChild.focus();
    } else if (a === 'remove-yes' && item) {
      UI.setBusy(b, true);
      UI.showError(card, '');
      FP.call('del', 'secqQuestion', undefined, {id: item.getAttribute('data-fp-sq-q')}).then(function (r) {
        var n = whole(r && r.answers_removed, 0, 1e9, 0);
        return reload(t('sq_removed', {n: String(n)}), 'list');
      }, function (err) { UI.setBusy(b, false); UI.showError(card, err.message); b.focus(); });
    }
  });

  FP.view('tool:security_questions', function () {
    var tool = FP.tools.security_questions;
    if (!tool) { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('sq_desc'), cls: 'fp-mail fp-sq',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    S = {page: body, mine: null, admin: null};
    var mine = S;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    fetchAll().then(function () {
      if (S !== mine) { return; }
      render();
    }, function (err) {
      if (S !== mine) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

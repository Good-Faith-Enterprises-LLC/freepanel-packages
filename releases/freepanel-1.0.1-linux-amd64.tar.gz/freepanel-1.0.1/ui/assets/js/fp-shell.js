/* freePanel shell, shared by the admin panel and the customer panel (body[data-realm]): the session check, the main
   menu (drawer below 1024px, foldable to icons at 1024px and wider), the account menu, sign-out and the hash router
   (#/, #/group/<id>, #/tool/<id>, #/two-factor). Views register with FP.view(name, render) and fp-start.js starts it.
   Declares only window.FP. */
(function () {
  'use strict';
  var UI = window.FPUI;
  var API = window.FPAPI;
  var t = UI.t;
  var el = UI.el;
  var root = document.documentElement;
  var body = document.body;
  var realm = body.getAttribute('data-realm') === 'admin' ? 'admin' : 'user';
  var loginUrl = body.getAttribute('data-login') || '/login.html';
  var main = document.getElementById('sig-main');
  var WIDE = '(min-width: 1024px)';

  var FP = {
    realm: realm,
    sprite: UI.sprite(realm),
    ui: UI.sprite('ui'),
    session: null,
    groups: [],
    tools: {},
    views: {},
    started: false,
    locked: false,   /* the panel is locked: the licence is not in order (docs/api.md, "Licence") */
    mustChange: false,   /* the login was told to choose a new password and has not (docs/api.md, "Other logins") */
    held: false,     /* the login must set two-factor up before anything else (docs/api.md, "Two-factor policy") */
    notice: null,    /* a function that makes a banner for the top of every page, or null */
    beforeStart: null,   /* a function that makes the session's extra reads, resolved before the first view */
    current: null
  };

  FP.view = function (name, render) { FP.views[name] = render; };

  /* what a page must finish before the session ends, as it is no longer allowed afterwards (the terminal closes its shell): each function
     returns a promise, and a sign-out waits for them for at most a few seconds, whatever they do */
  FP.beforeSignOut = [];
  FP.signOutReady = function () {
    var waits = FP.beforeSignOut.map(function (f) {
      try { return Promise.resolve(f()).catch(function () { /* the sign-out goes on */ }); } catch (e) { return Promise.resolve(); }
    });
    return Promise.race([Promise.all(waits), new Promise(function (resolve) { window.setTimeout(resolve, 3000); })]);
  };

  /* ---- signed out ---- */
  FP.signedOut = function (expired) {
    var next = UI.safeNext(window.location.hash);
    var q = [];
    if (expired) { q.push('expired=1'); }
    if (next) { q.push('next=' + encodeURIComponent(next)); }
    window.location.replace(loginUrl + (q.length ? '?' + q.join('&') : ''));
  };
  /* an API call from a view: a 401 means the session ended, anything else goes back to the view; raw ({body, type})
     sends a file or a text file's content as it is, by PUT or POST */
  FP.call = function (method, name, payload, arg, raw) {
    var call = raw ? API.send(method === 'put' ? 'PUT' : 'POST', name, arg, raw) : method === 'get' ? API.get(name, arg) : method === 'put' ? API.put(name, payload, arg) :
      method === 'del' ? API.del(name, arg) : method === 'patch' ? API.patch(name, payload, arg) : API.post(name, payload, arg);
    return call.catch(function (err) {
      if (err && err.status === 401) { FP.signedOut(true); }
      throw err;
    });
  };
  /* the home's info card: the customer's own account; for an admin the server's status; for a reseller (who may not
     see the server) the panel version and how many accounts it has */
  /* the name an account's paths are built from. A team member signs in as name@account and works in its owner's account, which the
     session names in user.account (docs/api.md, "Team members"); anyone else's login is the account. */
  var ACCOUNT_RE = /^[a-z][a-z0-9]{0,15}$/;
  FP.account = function () {
    var u = FP.session && FP.session.user ? FP.session.user : {};
    return typeof u.account === 'string' && ACCOUNT_RE.test(u.account) ? u.account : u.username;
  };
  var summary = null;
  FP.summary = function () {
    if (!summary) {
      if (realm === 'admin' && FP.session.user.role === 'admin') {
        summary = FP.call('get', 'serverStatus');
      } else if (realm === 'admin') {
        summary = Promise.all([UI.health(), FP.call('get', 'accounts')]).then(function (r) {
          return {version: r[0].version, accounts: Array.isArray(r[1].accounts) ? r[1].accounts : null};
        });
      } else {
        summary = FP.call('get', 'account', undefined, FP.account());
      }
      summary.catch(function () { summary = null; });
    }
    return summary;
  };

  /* ---- tools the session may use ---- */
  function safeLink(u) { return typeof u === 'string' && /^(https:\/\/[^\s"'<>]+|\/[^\s"'<>/][^\s"'<>]*)$/.test(u) ? u : ''; }
  function buildTools(registry, session) {
    var features = {};
    (Array.isArray(session.features) ? session.features : []).forEach(function (f) { if (typeof f === 'string') { features[f] = true; } });
    /* a locked panel offers its administrator the Licence page, so that a key can be entered, and nobody else anything */
    var keep = FP.locked && !FP.mustChange && realm === 'admin' && session.user.role === 'admin' ? 'licence' : '';
    var links = session.links && typeof session.links === 'object' ? session.links : {};
    FP.groups = [];
    FP.tools = {};
    (registry.groups || []).forEach(function (g) {
      var tools = (g.tools || []).filter(function (tool) {
        /* a held login is offered the set-up page and nothing else */
        return FP.locked || FP.mustChange ? tool.id === keep : FP.held ? tool.route === 'two-factor' : tool.always || features[tool.feature || tool.id];
      }).map(function (tool) {
        var link = tool.external ? safeLink(links[tool.id]) : '';
        var item = {id: tool.id, label: tool.label, desc: tool.desc || '', keywords: tool.keywords || [], group: g.id,
          groupLabel: g.label, href: link || (tool.route ? '#/' + tool.route : '#/tool/' + tool.id), external: Boolean(link),
          route: tool.route || ''};
        FP.tools[tool.id] = item;
        return item;
      });
      if (tools.length) { FP.groups.push({id: g.id, label: g.label, tools: tools}); }
    });
  }
  FP.group = function (id) {
    for (var i = 0; i < FP.groups.length; i++) { if (FP.groups[i].id === id) { return FP.groups[i]; } }
    return null;
  };
  /* a link to a tool: external ones open in a new tab and say so */
  FP.toolLink = function (tool, cls, withIcon, iconCls) {
    var a = el('a', {class: cls, href: tool.href}, withIcon ? [UI.icon(FP.sprite, tool.id, iconCls)] : []);
    a.appendChild(el('span', {class: cls === 'sig-tile' ? 'sig-tile-name' : 'fp-link-text', text: tool.label}));
    if (tool.external) {
      a.target = '_blank';
      a.rel = 'noopener';
      a.appendChild(UI.icon(FP.ui, 'ui_external', 'sig-ext'));
      a.appendChild(el('span', {class: 'sig-vh', text: ' ' + t('opens_new')}));
    }
    return a;
  };

  /* ---- page frame ---- */
  FP.frame = function (opts) {
    main.textContent = '';
    var page = el('div', {class: 'fp-page' + (opts.cls ? ' ' + opts.cls : '')});
    if (opts.crumbs && opts.crumbs.length) {
      var ol = el('ol', {class: 'sig-crumbs'});
      opts.crumbs.forEach(function (c) {
        ol.appendChild(el('li', null, [c.href ? el('a', {href: c.href, text: c.label}) : el('span', {'aria-current': 'page', text: c.label})]));
      });
      page.appendChild(el('nav', {'aria-label': 'Breadcrumb'}, [ol]));
    }
    var notice = FP.notice ? FP.notice() : null;
    if (notice) { page.insertBefore(notice, page.firstChild); }
    if (FP.held) { page.insertBefore(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-held': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('held_banner')})]), page.firstChild); }
    var heading = el('div', {class: 'fp-title-text'}, [
      el('h1', {class: 'sig-h1', id: 'fp-h1', tabindex: '-1', text: opts.title}),
      opts.desc ? el('p', {class: 'sig-desc', text: opts.desc}) : null
    ]);
    page.appendChild(el('div', {class: 'sig-title-row'}, [heading]));
    var bodyEl = el('div', {class: 'sig-frame-body'});
    page.appendChild(bodyEl);
    main.appendChild(page);
    document.title = t('title_suffix', {page: opts.title, brand: UI.brand.name});
    return bodyEl;
  };
  FP.empty = function (title, text, action) {
    return el('div', {class: 'sig-card sig-empty'}, [el('b', {text: title}), el('p', {class: 'fp-empty-text', text: text}), action || null]);
  };

  /* ---- router ---- */
  function parse(hash) {
    var m = /^#\/([a-z0-9-]+)?(?:\/([a-z0-9_]+))?\/?$/.exec(hash || '#/');
    if (!hash || hash === '#' || hash === '#/') { return {view: 'home'}; }
    if (!m) { return {view: 'not-found'}; }
    if (m[1] === 'group' && m[2]) { return {view: 'group', id: m[2]}; }
    if (m[1] === 'tool' && m[2]) { return {view: 'tool', id: m[2]}; }
    if (m[1] && !m[2] && FP.views[m[1]] && ['home', 'group', 'tool', 'not-found'].indexOf(m[1]) < 0) { return {view: m[1]}; }
    return {view: 'not-found'};
  }
  function route(focus) {
    var r = parse(window.location.hash);
    /* a held login (two-factor is required of it and it has none) may only set it up: every address shows that page */
    if (FP.held && FP.views['two-factor'] && r.view !== 'two-factor') {
      r = {view: 'two-factor'};
      window.history.replaceState(null, '', '#/two-factor');
    }
    FP.current = r;
    closeDrawer(false);
    var render = FP.views[r.view] || FP.views['not-found'];
    if (r.view === 'tool' && FP.views['tool:' + r.id]) { render = FP.views['tool:' + r.id]; }
    if (FP.locked && FP.views['license-lock']) { render = FP.views['license-lock']; }
    /* a login told to choose a new password sees only that screen (fp-passwordchange.js), whatever else is wrong */
    if (FP.mustChange && FP.views['password-must-change']) { render = FP.views['password-must-change']; }
    render(r, main);
    markMenu(r);
    if (focus) {
      var h = document.getElementById('fp-h1');
      if (h) { h.focus(); }
      window.scrollTo(0, 0);
    }
  }
  FP.route = route;

  /* ---- main menu ---- */
  var openGroups = {};
  function menuItem(href, iconSprite, iconId, label, attrs) {
    var a = el('a', Object.assign({class: 'sig-mi', href: href}, attrs || {}), [
      UI.icon(iconSprite, iconId), el('span', {class: 'sig-mi-label', text: label})]);
    return a;
  }
  function renderMenu() {
    var menu = document.getElementById('fp-menu');
    menu.textContent = '';
    menu.appendChild(el('li', null, [menuItem('#/', FP.ui, realm === 'admin' ? 'ui_home' : 'ui_tools', t('menu_home'), {'data-fp-route': 'home'})]));
    if (realm === 'admin') {
      openGroups = {};
      (UI.store.json('fp.admin.open', []) || []).forEach(function (id) { if (typeof id === 'string') { openGroups[id] = true; } });
    }
    FP.groups.forEach(function (g) {
      var li = el('li', {class: 'fp-nav-grp', 'data-fp-group': g.id});
      var row = el('div', {class: 'fp-nav-row'}, [menuItem('#/group/' + g.id, FP.sprite, 'grp_' + g.id, g.label, {'data-fp-route': 'group:' + g.id})]);
      li.appendChild(row);
      if (realm === 'admin') {
        var listId = 'fp-nav-' + g.id;
        var open = Boolean(openGroups[g.id]);
        var toggle = el('button', {class: 'fp-nav-toggle', type: 'button', 'aria-expanded': String(open), 'aria-controls': listId,
          'aria-label': t('group_toggle', {group: g.label})}, [UI.icon(FP.ui, 'ui_caret_down')]);
        row.appendChild(toggle);
        var fns = el('ul', {class: 'fp-nav-fns', id: listId});
        fns.hidden = !open;
        g.tools.forEach(function (tool) {
          var a = FP.toolLink(tool, 'fp-nav-fn', false);
          a.setAttribute('data-fp-route', 'tool:' + tool.id);
          fns.appendChild(el('li', {'data-fp-fn': tool.id}, [a]));
        });
        li.appendChild(fns);
      }
      menu.appendChild(li);
    });
  }
  function setGroupOpen(li, open, remember) {
    var toggle = li.querySelector('.fp-nav-toggle');
    var fns = li.querySelector('.fp-nav-fns');
    if (!toggle || !fns) { return; }
    toggle.setAttribute('aria-expanded', String(open));
    fns.hidden = !open;
    if (remember) {
      var id = li.getAttribute('data-fp-group');
      if (open) { openGroups[id] = true; } else { delete openGroups[id]; }
      UI.store.set('fp.admin.open', JSON.stringify(Object.keys(openGroups)));
    }
  }
  function markMenu(r) {
    var key = r.view === 'home' ? 'home' : r.view === 'group' ? 'group:' + r.id : r.view === 'tool' ? 'tool:' + r.id : '';
    var tool = r.view === 'tool' ? FP.tools[r.id] : r.view !== 'home' && r.view !== 'group' ? findRouteTool(r.view) : null;
    var parent = tool ? 'group:' + tool.group : '';
    if (tool && !key) { key = 'tool:' + tool.id; }
    var links = document.querySelectorAll('#fp-menu [data-fp-route]');
    for (var i = 0; i < links.length; i++) {
      var k = links[i].getAttribute('data-fp-route');
      if (k === key) { links[i].setAttribute('aria-current', 'page'); } else if (k === parent) { links[i].setAttribute('aria-current', 'true'); } else { links[i].removeAttribute('aria-current'); }
    }
    if (realm === 'admin' && tool) {
      var li = document.querySelector('#fp-menu [data-fp-group="' + tool.group + '"]');
      if (li && !filterActive()) { setGroupOpen(li, true, false); }
    }
  }
  function findRouteTool(view) {
    for (var id in FP.tools) { if (FP.tools[id].route === view) { return FP.tools[id]; } }
    return null;
  }

  /* admin: the function filter in the main menu */
  function filterActive() {
    var input = document.getElementById('fp-nav-filter');
    return Boolean(input && input.value.trim());
  }
  FP.matches = function (tool, q) {
    if (!q) { return true; }
    var hay = (tool.label + ' ' + tool.groupLabel + ' ' + tool.keywords.join(' ')).toLowerCase();
    return q.split(/\s+/).every(function (w) { return hay.indexOf(w) >= 0; });
  };
  function initNavFilter() {
    var box = document.querySelector('[data-fp-nav-filter]');
    var input = document.getElementById('fp-nav-filter');
    var empty = document.querySelector('[data-fp-nav-empty]');
    if (realm !== 'admin' || !box || !input) { return; }
    box.hidden = false;
    input.addEventListener('input', function () {
      var q = input.value.trim().toLowerCase();
      var any = false;
      var groups = document.querySelectorAll('#fp-menu .fp-nav-grp');
      for (var i = 0; i < groups.length; i++) {
        var li = groups[i];
        var g = FP.group(li.getAttribute('data-fp-group'));
        var hits = 0;
        var items = li.querySelectorAll('[data-fp-fn]');
        for (var j = 0; j < items.length; j++) {
          var ok = FP.matches(FP.tools[items[j].getAttribute('data-fp-fn')], q);
          items[j].hidden = !ok;
          if (ok) { hits++; }
        }
        li.hidden = Boolean(q) && hits === 0;
        if (q) { setGroupOpen(li, hits > 0, false); } else { setGroupOpen(li, Boolean(openGroups[g.id]), false); }
        if (hits) { any = true; }
      }
      document.querySelector('#fp-menu > li:first-child').hidden = Boolean(q);
      empty.hidden = !q || any;
      empty.textContent = q && !any ? t('filter_none') : '';
    });
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && input.value) { e.stopPropagation(); input.value = ''; input.dispatchEvent(new Event('input')); }
    });
  }

  /* ---- drawer below 1024px, fold to icons at 1024px and wider (same button) ---- */
  function isWide() { return Boolean(window.matchMedia && window.matchMedia(WIDE).matches); }
  var drawerBtn = document.querySelector('[data-sig-drawer]');
  var side = document.getElementById('sig-side');
  function closeDrawer(returnFocus) {
    if (!body.classList.contains('is-drawer-open')) { return; }
    body.classList.remove('is-drawer-open');
    syncMenuButton();
    if (returnFocus) { drawerBtn.focus(); }
  }
  function collapsed() { return root.getAttribute('data-sig-side') === 'collapsed'; }
  function syncMenuButton() {
    var open = isWide() ? !collapsed() : body.classList.contains('is-drawer-open');
    drawerBtn.setAttribute('aria-expanded', String(open));
  }
  function initMenuButton() {
    drawerBtn.addEventListener('click', function () {
      if (isWide()) {
        if (collapsed()) { root.removeAttribute('data-sig-side'); UI.store.del('fp.side'); } else { root.setAttribute('data-sig-side', 'collapsed'); UI.store.set('fp.side', 'collapsed'); }
        side.removeAttribute('data-sig-tips');
      } else {
        var open = !body.classList.contains('is-drawer-open');
        body.classList.toggle('is-drawer-open', open);
        if (open) { var first = side.querySelector('a, input'); if (first) { first.focus(); } }
      }
      syncMenuButton();
    });
    document.addEventListener('click', function (e) {
      if (e.target.closest && e.target.closest('[data-sig-drawer-close]')) { closeDrawer(true); }
    });
    document.addEventListener('keydown', function (e) {
      if (e.key !== 'Escape') { return; }
      if (body.classList.contains('is-drawer-open')) { closeDrawer(true); }
      if (isWide() && collapsed()) { side.setAttribute('data-sig-tips', 'off'); }
    });
    side.addEventListener('focusin', function () { side.removeAttribute('data-sig-tips'); });
    side.addEventListener('mouseover', function (e) {
      var item = e.target.closest ? e.target.closest('.sig-mi') : null;
      if (item && !(e.relatedTarget && item.contains(e.relatedTarget))) { side.removeAttribute('data-sig-tips'); }
    });
    if (window.matchMedia) {
      var mq = window.matchMedia(WIDE);
      var onChange = function () { body.classList.remove('is-drawer-open'); syncMenuButton(); };
      if (mq.addEventListener) { mq.addEventListener('change', onChange); } else if (mq.addListener) { mq.addListener(onChange); }
    }
    syncMenuButton();
  }

  /* ---- popovers (account menu) ---- */
  var openPop = null;
  function closePop(returnFocus) {
    if (!openPop) { return; }
    openPop.panel.hidden = true;
    openPop.button.setAttribute('aria-expanded', 'false');
    if (returnFocus) { openPop.button.focus(); }
    openPop = null;
  }
  function initPops() {
    document.addEventListener('click', function (e) {
      var btn = e.target.closest ? e.target.closest('[data-sig-pop]') : null;
      if (btn) {
        var panel = document.getElementById(btn.getAttribute('data-sig-pop'));
        var wasOpen = openPop && openPop.panel === panel;
        closePop(false);
        if (!wasOpen && panel) {
          panel.hidden = false;
          btn.setAttribute('aria-expanded', 'true');
          openPop = {button: btn, panel: panel};
          var first = panel.querySelector('button, a');
          if (first) { first.focus(); }
        }
        return;
      }
      if (openPop && !openPop.panel.contains(e.target)) { closePop(false); return; }
      if (openPop && e.target.closest && e.target.closest('a.sig-pop-item')) { closePop(false); }
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && openPop) { closePop(true); }
    });
    document.addEventListener('focusin', function (e) {
      if (openPop && !openPop.panel.contains(e.target) && e.target !== openPop.button) { closePop(false); }
    });
  }

  function initLogout() {
    document.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('[data-fp-logout]') : null;
      if (!b) { return; }
      var pop = b.closest('.sig-pop') || document;
      UI.showError(pop, '');
      UI.setBusy(b, true);
      var done = function () { window.location.replace(loginUrl + '?signed_out=1'); };
      FP.signOutReady().then(function () { return API.post('logout', {}); }).then(done, function (err) {
        /* 401: the session is already gone. Anything else: it may still be live, so stay and offer a retry */
        if (err && err.code === 'unauthorized') { done(); return; }
        UI.setBusy(b, false);
        UI.showError(pop, UI.t('signout_failed'));
      });
    });
  }

  /* menu clicks: admin group toggles */
  function initMenuClicks() {
    document.getElementById('fp-menu').addEventListener('click', function (e) {
      var toggle = e.target.closest ? e.target.closest('.fp-nav-toggle') : null;
      if (!toggle) { return; }
      var li = toggle.closest('.fp-nav-grp');
      setGroupOpen(li, toggle.getAttribute('aria-expanded') !== 'true', !filterActive());
    });
  }

  function roleLabel(role) { return t(role === 'admin' ? 'role_admin' : role === 'reseller' ? 'role_reseller' : 'role_user'); }

  /* ---- start: session, branding and tool list, then the first view ---- */
  /* a call answered 403 license_required: the panel locked since this page loaded. Load again, so the session says so and the
     lock screen shows; once in half a minute, so a session that disagrees with the calls cannot loop. */
  function initLock() {
    document.addEventListener('fp:locked', function () {
      if (FP.locked || !FP.started) { return; }
      var last = Number(UI.store.get('fp.lockreload')) || 0;
      if (Date.now() - last < 30000) { return; }
      UI.store.set('fp.lockreload', String(Date.now()));
      window.location.reload();
    });
  }

  /* a call answered 403 password_change_required: the login was told to choose a new password since this page loaded. Load again,
     so the session says so and the screen shows; once in half a minute, like the lock. */
  function initMustChange() {
    document.addEventListener('fp:mustchange', function () {
      if (FP.mustChange || !FP.started) { return; }
      var last = Number(UI.store.get('fp.mustreload')) || 0;
      if (Date.now() - last < 30000) { return; }
      UI.store.set('fp.mustreload', String(Date.now()));
      window.location.reload();
    });
  }

  FP.start = function () {
    initLock();
    initMustChange();
    initPops();
    initMenuButton();
    initLogout();
    UI.toServedPanel(realm, 'shell').then(function (leaving) {
      return leaving ? new Promise(function () { /* the other panel's page is loading */ }) : API.get('session');
    }).then(function (session) {
      if (UI.realmOf(session) !== realm || typeof session.user.username !== 'string') { FP.signedOut(false); return null; }
      FP.session = session;
      FP.locked = Boolean(session.license && session.license.locked === true);
      FP.mustChange = session.password_change_required === true;
      FP.held = session.two_factor_setup_required === true;
      API.setCsrf(session.csrf_token);
      document.querySelector('[data-fp-user]').textContent = session.user.username;
      document.querySelector('[data-fp-role]').textContent = roleLabel(session.user.role);
      return Promise.all([
        fetch('/assets/registry/' + realm + '.json', {credentials: 'same-origin'}).then(function (r) {
          if (!r.ok) { throw new Error('registry'); }
          return r.json();
        }),
        UI.loadBrand(),
        FP.beforeStart ? FP.beforeStart(session) : null
      ]);
    }, function (err) {
      if (err && err.status === 401) { FP.signedOut(false); return null; }
      throw err;
    }).then(function (res) {
      if (!res) { return; }
      buildTools(res[0], FP.session);
      var host = document.querySelector('[data-fp-host]');
      if (host && realm === 'admin' && window.location.hostname) { host.textContent = window.location.hostname; host.hidden = false; }
      renderMenu();
      initMenuClicks();
      initNavFilter();
      var foot = document.querySelector('[data-fp-footer]');
      if (foot) { foot.textContent = UI.brand.name; }
      var powered = document.querySelector('[data-fp-powered]');
      if (powered) { powered.textContent = t('footer_powered'); }
      body.classList.remove('is-loading');
      FP.started = true;
      route(false);
      window.addEventListener('hashchange', function () { route(true); });
      document.dispatchEvent(new CustomEvent('fp:ready'));
    }).catch(function () {
      body.classList.remove('is-loading');
      main.textContent = '';
      main.appendChild(FP.empty(t('api_failed'), t('api_unreachable')));
    });
  };

  window.FP = FP;
})();

/* freePanel: the screen a login sees when its host has told it to choose a new password (docs/api.md, "Other logins": the session says
   password_change_required and every other call answers 403 password_change_required). It takes the place of every page, in both panels,
   until the login has chosen one: POST /auth/password with the current password and a new one that differs from it. Then the panel loads
   again and opens as usual. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;
  var MIN = 12;
  var MAX = 1024;

  function field(id, name, label, autocomplete, hint, reveal) {
    var input = el('input', {class: 'sig-input', id: id, name: name, type: 'password', autocomplete: autocomplete, maxlength: String(MAX), spellcheck: 'false', autocapitalize: 'none'});
    var control = reveal ? el('div', {class: 'fp-reveal-wrap'}, [input, el('button', {class: 'sig-ghost fp-reveal', type: 'button', 'data-overlap-ok': '',
      'data-fp-reveal': reveal, 'aria-pressed': 'false', 'aria-label': 'Show password'}, [UI.icon(FP.ui, 'ui_eye')])]) : input;
    return M.field(id, label, control, hint);
  }

  FP.view('password-must-change', function () {
    var page = FP.frame({title: t('pwm_title'), desc: t('pwm_desc'), cls: 'fp-mail fp-pwm'});
    var form = el('form', {class: 'fp-form fp-mail-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      field('fp-pwm-current', 'current_password', t('pw_current'), 'current-password', '', 'fp-pwm-current'),
      field('fp-pwm-new', 'new_password', t('pw_new'), 'new-password', t('pwm_new_hint'), 'fp-pwm-new,fp-pwm-again'),
      field('fp-pwm-again', 'again', t('pw_again'), 'new-password', ''),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('pwm_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var cur = form.querySelector('#fp-pwm-current');
      var next = form.querySelector('#fp-pwm-new');
      var again = form.querySelector('#fp-pwm-again');
      if (!cur.value) { M.fieldError(form, cur, t('pw_need_current')); return; }
      if (next.value.length < MIN) { M.fieldError(form, next, t('weak_password')); return; }
      if (next.value === cur.value) { M.fieldError(form, next, t('pwm_same')); return; }
      if (again.value !== next.value) { M.fieldError(form, again, t('passwords_differ')); return; }
      UI.setBusy(b, true);
      FP.call('post', 'password', {current_password: cur.value, new_password: next.value}).then(function () {
        cur.value = next.value = again.value = '';
        M.say(form, t('pwm_done'));
        /* the session no longer asks for it: the panel loads again and opens as usual */
        window.setTimeout(function () { window.location.reload(); }, 900);
      }, function (err) {
        UI.setBusy(b, false);
        if (err.code === 'forbidden') {
          cur.value = '';
          M.fieldError(form, cur, t('pw_wrong_current'));
        } else if (err.code === 'validation_failed' && err.field === 'new_password') {
          M.fieldError(form, next, t('pw_new') + ': ' + err.message);
        } else {
          M.fieldError(form, null, err.message);
        }
      });
    });
    page.appendChild(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-must': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('pwm_note')})]));
    page.appendChild(M.card('fp-pwm-h', t('pwm_card'), [form], 'fp-pwm-card'));
  });
})();

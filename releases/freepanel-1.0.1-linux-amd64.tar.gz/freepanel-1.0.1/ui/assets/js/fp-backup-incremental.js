/* freePanel incremental backups (#/tool/backup_incremental), the admin panel's page for chains of backups (docs/api.md, "Incremental
   backups"; docs/backups-incremental.md): whether the schedule's backups are incremental between full ones, the weekdays a full is made,
   and every kept archive of every account drawn as its chain: each one's type, date and size, what an incremental builds on, how much a
   restore of it reads, and an incremental that cannot be restored because a backup of its chain is gone, with why. Saving the choice
   starts nothing; the next backup follows it. Everything the server sends is shown as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;
  var BK = FP.bk;

  var USER_RE = /^[a-z][a-z0-9]{0,15}$/;
  var ARCHIVE_RE = /^[a-z][a-z0-9]{0,15}-[0-9]{8}-[0-9]{6}(-inc-[0-9]{8}-[0-9]{6})?\.tar\.gz$/;
  var DAYS = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];
  var MAX_ROWS = 2000;

  var I = null;
  var str = BK.str;
  function bytes(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? v : null; }

  /* ---------- what the server says, kept to the shapes the page draws ---------- */
  function cleanChoice(r) {
    r = r && typeof r === 'object' ? r : {};
    var days = Array.isArray(r.full_days) ? r.full_days : [];
    return {enabled: r.enabled === true, full_days: DAYS.filter(function (d) { return days.indexOf(d) >= 0; }), no_full_day: r.no_full_day === true};
  }
  function cleanSchedule(r) {
    r = r && typeof r === 'object' ? r : {};
    var days = Array.isArray(r.days) ? r.days : [];
    return {enabled: r.enabled === true, days: DAYS.filter(function (d) { return days.indexOf(d) >= 0; })};
  }
  function cleanArchives(r) {
    return (r && Array.isArray(r.backups) ? r.backups : []).filter(function (b) {
      return b && USER_RE.test(str(b.username)) && ARCHIVE_RE.test(str(b.name)) && b.name.indexOf(b.username + '-') === 0;
    }).slice(0, MAX_ROWS).map(function (b) {
      var name = function (v) { return ARCHIVE_RE.test(str(v)) && v.indexOf(b.username + '-') === 0 ? v : ''; };
      var inc = b.type === 'incremental' || b.name.indexOf('-inc-') > 0;
      return {username: b.username, name: b.name, bytes: bytes(b.bytes), created: str(b.created), removed: b.removed === true,
        inc: inc, base: name(b.base), full: name(b.full), baseCreated: str(b.base_created),
        chain: (Array.isArray(b.chain) ? b.chain : []).map(name).filter(Boolean).slice(0, 64), chainBytes: bytes(b.chain_bytes),
        broken: inc ? str(b.broken).slice(0, 400) : ''};
    });
  }

  /* the archives of one account's folder in chains, newest first: a full and the incrementals on it, then incrementals whose full is
     gone, alone */
  function chainsOf(list) {
    var byFull = {};
    var out = [];
    list.forEach(function (a) {
      if (!a.inc) {
        var c = {full: a, links: [], broken: false};
        byFull[a.name] = c;
        out.push(c);
      }
    });
    list.forEach(function (a) {
      if (!a.inc) { return; }
      var c = a.full && byFull[a.full];
      if (c) { c.links.push(a); return; }
      out.push({full: null, links: [a], broken: true});
    });
    out.forEach(function (c) {
      c.links.sort(function (x, y) { return x.created < y.created ? 1 : -1; });
      c.newest = c.links.length ? c.links[0].created : c.full.created;
    });
    return out.sort(function (x, y) { return x.newest < y.newest ? 1 : -1; });
  }
  /* the folders of archives: an account's own, then a removed account's of that name */
  function folders() {
    var keys = [];
    var by = {};
    I.archives.forEach(function (a) {
      if (I.only && a.username !== I.only) { return; }
      var k = a.username + (a.removed ? ' removed' : '');
      if (!by[k]) { by[k] = {username: a.username, removed: a.removed, list: []}; keys.push(k); }
      by[k].list.push(a);
    });
    return keys.sort().map(function (k) { return by[k]; });
  }

  function pill(kind, text) { return el('span', {class: 'sig-pill' + (kind ? ' sig-pill--' + kind : ''), text: text}); }
  function dayList(days) { return days.map(function (d) { return t('ibk_day_' + d); }).join(', '); }
  function size(n) { return n === null ? '—' : BK.size(n); }
  function when(v) { return BK.when(v) || v || '—'; }

  /* ---------- the choice ---------- */
  function warnings() {
    var c = I.choice;
    var out = [];
    if (!c.enabled) { return out; }
    var runs = c.full_days.filter(function (d) { return I.schedule.days.indexOf(d) >= 0; });
    if (c.no_full_day || !runs.length) {
      out.push(el('p', {class: 'sig-banner sig-banner--warn', 'data-fp-ibk-nofull': '', text: t('ibk_no_full_day', {days: dayList(I.schedule.days) || '—'})}));
    }
    if (!I.schedule.enabled) { out.push(el('p', {class: 'fp-muted', 'data-fp-ibk-off': '', text: t('ibk_schedule_off')})); }
    return out;
  }
  function formCard() {
    var c = I.choice;
    var form = el('form', {class: 'fp-form fp-mail-form fp-ibk-form', novalidate: '', 'data-fp-form': 'incremental'}, [M.errorLine(), M.statusLine()]);
    form.appendChild(el('div', {class: 'fp-ibk-warn'}, warnings()));
    form.appendChild(el('label', {class: 'fp-check', for: 'fp-ibk-enabled'}, [el('input', {type: 'checkbox', id: 'fp-ibk-enabled', name: 'enabled', checked: c.enabled,
      'aria-describedby': 'fp-ibk-enabled-hint'}), el('span', {text: t('ibk_enabled')})]));
    form.appendChild(el('p', {class: 'sig-hint fp-ibk-hint', id: 'fp-ibk-enabled-hint', text: t('ibk_enabled_hint')}));
    form.appendChild(el('fieldset', {class: 'fp-bk-parts fp-ibk-days', id: 'fp-ibk-days', 'aria-describedby': 'fp-ibk-days-hint'},
      [el('legend', {class: 'sig-label', text: t('ibk_full_days')})].concat(DAYS.map(function (d) {
        return el('label', {class: 'fp-check', for: 'fp-ibk-day-' + d}, [el('input', {type: 'checkbox', id: 'fp-ibk-day-' + d, name: 'full_days', value: d,
          checked: c.full_days.indexOf(d) >= 0}), el('span', {text: t('ibk_day_' + d)})]);
      })).concat([el('span', {class: 'sig-hint', id: 'fp-ibk-days-hint', text: t('ibk_full_days_hint')})])));
    form.appendChild(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('ibk_save')})]));
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      submit(form);
    });
    var what = el('dl', {class: 'fp-ibk-what'}, [
      el('dt', {text: t('ibk_what_home_k')}), el('dd', {text: t('ibk_what_home')}),
      el('dt', {text: t('ibk_what_rest_k')}), el('dd', {text: t('ibk_what_rest')}),
      el('dt', {text: t('ibk_what_restore_k')}), el('dd', {text: t('ibk_what_restore')}),
      el('dt', {text: t('ibk_what_keep_k')}), el('dd', {text: t('ibk_what_keep')})]);
    return M.card('fp-ibk-form-h', t('ibk_form_title'), [el('p', {class: 'fp-muted', text: t('ibk_form_desc')}), form,
      el('h3', {class: 'fp-h3', text: t('ibk_what_title')}), what], 'fp-ibk-choice');
  }
  function submit(form) {
    var b = M.start(form);
    if (!b) { return; }
    var days = DAYS.filter(function (d) { return form.querySelector('#fp-ibk-day-' + d).checked; });
    if (!days.length) {
      M.fieldError(form, UI.fieldNamed(form, 'full_days'), t('ibk_days_pick'));
      return;
    }
    var body = {enabled: form.querySelector('[name="enabled"]').checked, full_days: days};
    var mine = I;
    UI.setBusy(b, true);
    FP.call('put', 'backupIncremental', body).then(function (r) {
      UI.setBusy(b, false);
      if (I !== mine) { return; }
      mine.choice = cleanChoice(r);
      var warn = form.querySelector('.fp-ibk-warn');
      warn.textContent = '';
      warnings().forEach(function (n) { warn.appendChild(n); });
      M.say(form, mine.choice.enabled ? t('ibk_saved_on', {days: dayList(mine.choice.full_days)}) : t('ibk_saved_off'));
    }, function (err) {
      UI.setBusy(b, false);
      if (I !== mine) { return; }
      M.failed(form, err);
    });
  }

  /* ---------- the chains ---------- */
  function linkRow(a, full) {
    var head = el('div', {class: 'fp-ibk-row-head'}, [
      a.inc ? pill('accent', t('ibk_type_inc')) : pill('', t('ibk_type_full')),
      el('span', {class: 'fp-ibk-when', text: when(a.created)}),
      el('span', {class: 'fp-ibk-size', text: size(a.bytes)})]);
    var lines = [head, el('span', {class: 'fp-ibk-name', text: a.name})];
    if (a.inc && a.broken) {
      lines.push(el('p', {class: 'fp-bk-bad', 'data-fp-ibk-broken': '', text: t('ibk_broken', {why: a.broken})}));
    } else if (a.inc) {
      var base = I.archives.filter(function (x) { return x.name === a.base && x.username === a.username && x.removed === a.removed; })[0];
      lines.push(el('p', {class: 'fp-muted', text: t('ibk_builds_on', {when: base ? when(base.created) : (a.base || '—')})}));
      lines.push(el('p', {class: 'fp-muted', 'data-fp-ibk-reads': '', text: t('ibk_reads', {n: a.chain.length, size: size(a.chainBytes)})}));
    } else if (full) {
      lines.push(el('p', {class: 'fp-muted', text: t('ibk_full_alone')}));
    }
    return el('li', {class: 'fp-ibk-row' + (a.inc ? ' is-inc' : ''), 'data-fp-archive': a.name}, lines);
  }
  function chainBlock(c) {
    var all = (c.full ? [c.full] : []).concat(c.links.slice().reverse());
    var total = all.reduce(function (n, a) { return n + (a.bytes || 0); }, 0);
    var title = c.full ? t('ibk_chain_title', {when: when(c.full.created), n: all.length}) : t('ibk_chain_orphan');
    var head = el('div', {class: 'fp-ibk-chain-head'}, [el('h4', {class: 'fp-ibk-chain-title', text: title}),
      c.broken ? pill('danger', t('ibk_pill_broken')) : el('span', {class: 'fp-muted fp-ibk-total', text: t('ibk_chain_total', {size: size(total)})})]);
    return el('div', {class: 'fp-ibk-chain' + (c.broken ? ' is-broken' : '')}, [head,
      el('ol', {class: 'fp-ibk-links'}, all.map(function (a) { return linkRow(a, c.full && !c.links.length); }))]);
  }
  function chainsCard() {
    var parts = [M.errorLine()];
    var users = [];
    I.archives.forEach(function (a) { if (users.indexOf(a.username) < 0) { users.push(a.username); } });
    users.sort();
    if (!I.archives.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('ibk_none')}));
      return M.card('fp-ibk-chains-h', t('ibk_chains_title'), parts, 'fp-ibk-chains');
    }
    var pick = el('select', {class: 'sig-input fp-ibk-pick', id: 'fp-ibk-account', name: 'account'}, [el('option', {value: '', text: t('ibk_all_accounts')})]
      .concat(users.map(function (u) { return el('option', {value: u, text: u, selected: I.only === u}); })));
    pick.addEventListener('change', function () {
      I.only = USER_RE.test(pick.value) ? pick.value : '';
      drawChains(true);
    });
    parts.push(el('p', {class: 'fp-muted', text: t('ibk_chains_desc')}));
    parts.push(M.field('fp-ibk-account', t('ibk_account'), pick));
    folders().forEach(function (f) {
      parts.push(el('section', {class: 'fp-ibk-acct', 'data-fp-account': f.username, 'aria-labelledby': 'fp-ibk-a-' + f.username + (f.removed ? '-r' : '')}, [
        el('h3', {class: 'fp-h3', id: 'fp-ibk-a-' + f.username + (f.removed ? '-r' : ''), text: f.removed ? t('ibk_account_removed', {account: f.username}) : f.username})]
        .concat(chainsOf(f.list).map(chainBlock))));
    });
    return M.card('fp-ibk-chains-h', t('ibk_chains_title'), parts, 'fp-ibk-chains');
  }
  function drawChains(keepFocus) {
    var old = I.page.querySelector('.fp-ibk-chains');
    var fresh = chainsCard();
    if (old) { old.replaceWith(fresh); } else { I.page.appendChild(fresh); }
    if (keepFocus) { fresh.querySelector('#fp-ibk-account').focus(); }
  }

  FP.view('tool:backup_incremental', function () {
    var tool = FP.tools.backup_incremental;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('ibk_desc'), cls: 'fp-mail fp-bk fp-ibk',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    I = {page: body, choice: cleanChoice(null), schedule: cleanSchedule(null), archives: [], only: ''};
    var mine = I;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all([FP.call('get', 'backupIncremental'), FP.call('get', 'backupSettings'), FP.call('get', 'backups')]).then(function (r) {
      if (I !== mine) { return; }
      mine.choice = cleanChoice(r[0]);
      mine.schedule = cleanSchedule(r[1]);
      mine.archives = cleanArchives(r[2]);
      body.textContent = '';
      body.appendChild(formCard());
      drawChains(false);
    }, function (err) {
      if (I !== mine) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

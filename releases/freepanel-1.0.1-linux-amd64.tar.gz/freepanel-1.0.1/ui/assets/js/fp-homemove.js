/* freePanel's page for moving an account's home folder to another home root, in the administrators' panel (#/tool/home_move, docs/api.md,
   "Moving a home to another root"). The admin keeps the list of home roots (the base, /home, and others such as /home2 on a second disk),
   picks an account and a root, reads what the move changes (the plan) and starts it only after saying the account is suspended meanwhile.
   While the job runs the page asks how it goes every few seconds and shows its five steps, the copy's progress among them; a job that
   stopped part-way can be tried again from that step, undone or dismissed, an undo and a dismiss asked about first. Admins only. What the
   server sends is cleaned to the shapes drawn and shown as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var TOOL = 'home_move';
  var POLL_MS = 2500;
  var STEPS = ['check', 'hold', 'copy', 'switch', 'release'];
  var STATES = ['running', 'failed', 'done', 'undoing', 'undo_failed', 'undone', 'dismissed'];
  var USER_RE = /^[a-z][a-z0-9]{0,15}$/;
  var ROOT_RE = /^(\/[A-Za-z0-9_][A-Za-z0-9._-]*)+$/;
  var UNITS = ['KB', 'MB', 'GB', 'TB', 'PB'];
  /* the modules a plan names, as the admin reads them */
  var MODULES = {web: 'hmv_mod_web', mail: 'hmv_mod_mail', ftp: 'hmv_mod_ftp', resources: 'hmv_mod_resources'};

  var A = null;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function whole(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.floor(v) : 0; }
  function sentence(m) { return typeof m === 'string' && m ? m.charAt(0).toUpperCase() + m.slice(1) : m; }
  function root(v) { var s = str(v, 120); return ROOT_RE.test(s) && s.indexOf('/.') < 0 ? s : ''; }
  function size(n) {
    if (n < 1024) { return Math.round(n) + ' B'; }
    var u = -1;
    do { n /= 1024; u++; } while (n >= 1024 && u < UNITS.length - 1);
    return (n < 10 ? n.toFixed(1) : Math.round(n).toLocaleString('en')) + ' ' + UNITS[u];
  }
  function stamp(iso) {
    var d = typeof iso === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(iso) ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }
  function pill(kind, text) { return el('span', {class: 'sig-pill' + (kind ? ' sig-pill--' + kind : ''), text: text}); }
  function lines(v, n) { return (Array.isArray(v) ? v : []).slice(0, n || 20).map(function (x) { return str(x, 400); }).filter(Boolean); }
  function quotas(q) {
    q = q && typeof q === 'object' ? q : {};
    return {enforced: q.enforced === true, mount: str(q.mount, 120), reason: str(q.reason, 300)};
  }

  /* ---------- what the server sends ---------- */
  function cleanAccounts(r) {
    return (r && Array.isArray(r.accounts) ? r.accounts : []).filter(function (a) {
      return a && USER_RE.test(str(a.username, 20)) && (a.status === 'active' || a.status === 'suspended');
    }).map(function (a) { return {username: a.username, domain: str(a.domain, 260), suspended: a.status === 'suspended'}; })
      .sort(function (x, y) { return x.username < y.username ? -1 : 1; });
  }
  function cleanRoots(r) {
    var v = r && r.roots && typeof r.roots === 'object' ? r.roots : {};
    var list = (Array.isArray(v.roots) ? v.roots : []).slice(0, 20).filter(function (x) { return x && root(x.path); }).map(function (x) {
      return {path: x.path, base: x.base === true, accounts: whole(x.accounts), mount: str(x.mount, 120), same: x.same_disk === true,
        total: whole(x.total_bytes), free: whole(x.free_bytes), quotas: quotas(x.quotas), problem: str(x.problem, 300)};
    });
    return {roots: list, max: whole(v.max) || 8, selinux: v.selinux === true, notes: lines(v.notes, 6)};
  }
  function cleanPlan(p) {
    if (!p || typeof p !== 'object' || !USER_RE.test(str(p.account, 20)) || !root(p.root)) { return null; }
    return {account: p.account, status: str(p.status, 20), root: p.root, from: str(p.from, 200), to: str(p.to, 200), method: p.method === 'rename' ? 'rename' : 'copy',
      bytes: whole(p.bytes), files: whole(p.files), partial: p.partial === true, free: whole(p.free_bytes), quota: str(p.quota, 400), selinux: p.selinux === true,
      refs: (Array.isArray(p.refs) ? p.refs : []).slice(0, 12).map(function (x) { return {module: str(x && x.module, 30), lines: lines(x && x.lines, 8)}; })
        .filter(function (x) { return x.module && x.lines.length; }),
      notes: lines(p.notes, 10)};
  }
  function cleanJob(m) {
    if (!m || typeof m !== 'object' || STATES.indexOf(m.state) < 0 || !USER_RE.test(str(m.account, 20))) { return null; }
    return {state: m.state, step: STEPS.indexOf(m.step) >= 0 ? m.step : 'check', done: (Array.isArray(m.done) ? m.done : []).filter(function (s) { return STEPS.indexOf(s) >= 0; }),
      account: m.account, root: root(m.root), from: str(m.from, 200), to: str(m.to, 200), method: m.method === 'rename' ? 'rename' : 'copy',
      bytes: whole(m.bytes), total: whole(m.total), held: m.held === true, parked: str(m.parked_at, 300),
      error: str(m.error, 600), notes: lines(m.notes, 20), started: str(m.started, 40), ended: str(m.ended, 40)};
  }
  function going(j) { return j && (j.state === 'running' || j.state === 'undoing'); }
  function stopped(j) { return j && (j.state === 'failed' || j.state === 'undo_failed'); }

  /* ---------- the roots ---------- */
  function diskCell(r) {
    if (!r.total) { return el('td', {class: 'fp-muted', text: t('hmv_disk_unknown')}); }
    var used = r.total - r.free;
    var pct = Math.round(used / r.total * 100);
    var bar = el('i');
    bar.style.width = Math.min(100, Math.max(1, pct)) + '%';
    return el('td', {class: 'fp-hmv-disk'}, [el('span', {text: t('hmv_disk_free', {free: size(r.free), total: size(r.total)})}),
      el('div', {class: 'sig-meter' + (pct >= 90 ? ' is-danger' : pct >= 75 ? ' is-warn' : ''), 'aria-hidden': 'true'}, [bar])]);
  }
  function rootRow(r) {
    var tags = [];
    if (r.base) { tags.push(pill('', t('hmv_root_base'))); }
    if (!r.base && r.same) { tags.push(pill('', t('hmv_root_same'))); }
    var name = el('th', {scope: 'row', class: 'fp-hmv-root'}, [el('span', {class: 'sig-mono', text: r.path}), el('span', {class: 'fp-hmv-tags'}, tags)]);
    if (r.problem) { name.appendChild(el('span', {class: 'fp-hmv-problem', 'data-fp-problem': '', text: sentence(r.problem)})); }
    var act = el('td', {class: 'fp-hmv-act'});
    if (!r.base) {
      var b = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'hmv-remove', 'data-fp-root': r.path,
        text: t('hmv_remove'), 'aria-label': t('hmv_remove_label', {root: r.path})});
      if (r.accounts > 0) { b.disabled = true; b.title = t('hmv_remove_busy'); }
      act.appendChild(b);
    }
    return el('tr', {'data-fp-rootrow': r.path}, [name,
      el('td', {class: 'fp-num', text: String(r.accounts)}),
      diskCell(r),
      el('td', {}, [r.quotas.enforced ? pill('ok', t('hmv_quota_on')) : pill('warn', t('hmv_quota_off'))]),
      act]);
  }
  function rootsCard() {
    var R = A.roots;
    var path = el('input', {class: 'sig-input sig-mono', id: 'fp-hmv-path', name: 'path', type: 'text', maxlength: '100', placeholder: '/home2',
      autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none'});
    var add = el('form', {class: 'fp-form fp-hmv-add', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-hmv-path', t('hmv_add_path'), path, t('hmv_add_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('hmv_add')})])]);
    var table = el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-hmv-roots-h'}, [el('table', {class: 'sig-table fp-hmv-roots'}, [
      el('caption', {class: 'sig-vh', text: t('hmv_roots_title')}),
      el('thead', {}, [el('tr', {}, [el('th', {scope: 'col', text: t('hmv_col_root')}), el('th', {scope: 'col', class: 'fp-num', text: t('hmv_col_homes')}),
        el('th', {scope: 'col', text: t('hmv_col_disk')}), el('th', {scope: 'col', text: t('hmv_col_quotas')}),
        el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('hmv_col_actions')})])])]),
      el('tbody', {}, R.roots.map(rootRow))])]);
    var ask = el('div', {class: 'fp-hmv-ask'});
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t('hmv_roots_intro')}), table, ask];
    R.notes.forEach(function (n) { parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note'}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: sentence(n)})])); });
    if (R.selinux) { parts.push(el('p', {class: 'fp-muted fp-hmv-small', text: t('hmv_selinux')})); }
    if (R.roots.length - 1 < R.max) { parts.push(add); } else { parts.push(el('p', {class: 'fp-muted', text: t('hmv_roots_full', {n: String(R.max)})})); }
    var card = M.card('fp-hmv-roots-h', t('hmv_roots_title'), parts, 'fp-hmv-rootscard');
    var asked = '';
    card.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
      if (!b || b.disabled) { return; }
      var act = b.getAttribute('data-fp-act');
      if (act === 'hmv-remove') {
        asked = b.getAttribute('data-fp-root');
        M.confirmIn(ask, t('hmv_remove_ask', {root: asked}), 'hmv-remove-yes', t('hmv_remove_yes'));
      } else if (act === 'confirm-no') {
        ask.textContent = '';
        var back = card.querySelector('[data-fp-act="hmv-remove"][data-fp-root="' + asked + '"]');
        asked = '';
        if (back) { back.focus(); }
      } else if (act === 'hmv-remove-yes' && asked) {
        var r = asked;
        ask.textContent = '';
        changeRoots(card, b, 'homeRootRemove', r, t('hmv_removed', {root: r}));
      }
    });
    add.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(add);
      if (!b) { return; }
      var v = path.value.trim();
      if (!root(v) || v === '/') { M.fieldError(add, path, t('hmv_need_path')); return; }
      changeRoots(add, b, 'homeRoots', v, t('hmv_added', {root: v}));
    });
    return card;
  }
  function changeRoots(box, button, key, path, said) {
    var mine = A;
    UI.showError(box, '');
    UI.setBusy(button, true);
    FP.call('post', key, {path: path}).then(function (r) {
      if (A !== mine) { return; }
      A.roots = cleanRoots(r);
      draw('#fp-hmv-roots-h', '');
      M.say(A.page.querySelector('.fp-hmv-rootscard'), said);
    }, function (err) {
      if (A !== mine) { return; }
      UI.setBusy(button, false);
      if (box.tagName === 'FORM') { M.failed(box, err); } else { UI.showError(box, sentence(err.message)); }
    });
  }

  /* ---------- the job ---------- */
  function stepState(j, s) {
    if (j.done.indexOf(s) >= 0) { return 'done'; }
    if (s !== j.step) { return 'waiting'; }
    if (j.state === 'running') { return 'working'; }
    if (j.state === 'failed' || j.state === 'undo_failed' || j.state === 'dismissed') { return 'stopped'; }
    return 'waiting';
  }
  var STEP_PILL = {done: 'ok', working: 'accent', stopped: 'danger', waiting: ''};
  function stepRow(j, s, i) {
    var st = stepState(j, s);
    var what = el('span', {class: 'fp-hmv-step-text'}, [el('span', {class: 'fp-hmv-step-name', text: t('hmv_step_' + s)}),
      el('span', {class: 'fp-muted fp-hmv-step-what', text: t('hmv_step_' + s + '_what', {account: j.account, root: j.root})})]);
    if (s === 'copy' && j.method === 'copy' && (st === 'working' || st === 'stopped') && j.total > 0) {
      var pct = Math.min(100, Math.round(j.bytes / j.total * 100));
      var bar = el('i');
      bar.style.width = Math.max(1, pct) + '%';
      what.appendChild(el('span', {class: 'fp-hmv-progress', 'data-fp-progress': String(pct)}, [
        el('span', {class: 'fp-muted', text: t('hmv_copied', {done: size(j.bytes), total: size(j.total), pct: String(pct)})}),
        el('div', {class: 'sig-meter', role: 'progressbar', 'aria-valuemin': '0', 'aria-valuemax': '100', 'aria-valuenow': String(pct),
          'aria-label': t('hmv_copy_label')}, [bar])]));
    }
    return el('li', {class: 'fp-hmv-step is-' + st, 'data-fp-step': s, 'data-fp-state': st}, [
      el('span', {class: 'fp-hmv-num', 'aria-hidden': 'true', text: String(i + 1)}), what,
      st === 'waiting' ? el('span', {class: 'fp-muted fp-hmv-step-pill', text: t('hmv_st_waiting')}) : pill(STEP_PILL[st], t('hmv_st_' + st))]);
  }
  function jobCard() {
    var j = A.job;
    var when = stamp(j.ended) || stamp(j.started);
    var parts = [M.errorLine(), M.statusLine(),
      el('p', {class: 'fp-hmv-head' + (stopped(j) ? ' fp-bk-bad' : ''), 'data-fp-job': j.state,
        text: t('hmv_job_' + j.state, {account: j.account, root: j.root, step: t('hmv_step_' + j.step), when: when})}),
      el('p', {class: 'fp-hmv-route'}, [el('span', {class: 'sig-mono', text: j.from}), el('span', {class: 'fp-hmv-arrow', 'aria-hidden': 'true', text: '→'}),
        el('span', {class: 'sig-vh', text: t('hmv_to')}), el('span', {class: 'sig-mono', text: j.to})])];
    if (j.state === 'undoing') { parts.push(el('p', {class: 'fp-muted', 'data-fp-undoing': '', text: t('hmv_undoing_what')})); }
    else { parts.push(el('ol', {class: 'fp-hmv-steps', 'aria-label': t('hmv_steps_label')}, STEPS.map(function (s, i) { return stepRow(j, s, i); }))); }
    if (j.error) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-job-error': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: sentence(j.error)})]));
    }
    if (stopped(j) && j.held) { parts.push(el('p', {class: 'fp-muted', text: t('hmv_held_now', {account: j.account})})); }
    if (j.state === 'failed') { parts.push(el('p', {class: 'fp-muted', text: t('hmv_failed_what')})); }
    if (j.notes.length) {
      parts.push(el('h3', {class: 'fp-h3', text: t('hmv_notes')}));
      parts.push(el('ul', {class: 'fp-hmv-notes'}, j.notes.map(function (n) { return el('li', {text: sentence(n)}); })));
    }
    var acts = el('div', {class: 'fp-actions fp-hmv-acts'});
    if (j.state === 'failed') {
      acts.appendChild(el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'hmv-retry', text: t('hmv_retry', {step: t('hmv_step_' + j.step)})}));
      if (j.done.indexOf('switch') < 0) { acts.appendChild(el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'hmv-undo', text: t('hmv_undo')})); }
    }
    if (j.state === 'undo_failed') { acts.appendChild(el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'hmv-undo', text: t('hmv_undo_again')})); }
    if (stopped(j)) { acts.appendChild(el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'hmv-dismiss', text: t('hmv_dismiss')})); }
    if (acts.childNodes.length) { parts.push(acts); }
    var ask = el('div', {class: 'fp-hmv-ask'});
    parts.push(ask);
    var card = M.card('fp-hmv-job-h', t('hmv_job_title'), parts, 'fp-hmv-job');
    card.setAttribute('aria-busy', going(j) ? 'true' : 'false');
    card.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
      if (!b || b.disabled) { return; }
      var act = b.getAttribute('data-fp-act');
      if (act === 'hmv-retry') { resume(card, b, 'homeMoveRetry', t('hmv_retrying')); }
      else if (act === 'hmv-undo') { M.confirmIn(ask, t('hmv_undo_ask', {account: j.account, from: j.from}), 'hmv-undo-yes', t('hmv_undo_yes')); }
      else if (act === 'hmv-dismiss') { M.confirmIn(ask, t('hmv_dismiss_ask', {account: j.account}), 'hmv-dismiss-yes', t('hmv_dismiss_yes')); }
      else if (act === 'hmv-undo-yes') { ask.textContent = ''; resume(card, card.querySelector('[data-fp-act="hmv-undo"]'), 'homeMoveUndo', t('hmv_undo_started')); }
      else if (act === 'hmv-dismiss-yes') { ask.textContent = ''; resume(card, card.querySelector('[data-fp-act="hmv-dismiss"]'), 'homeMoveDismiss', t('hmv_dismissed')); }
      else if (act === 'confirm-no') { ask.textContent = ''; (card.querySelector('[data-fp-act="hmv-undo"]') || card.querySelector('[data-fp-act="hmv-dismiss"]') || card).focus(); }
    });
    return card;
  }
  /* a retry, an undo or a dismiss: the answer is the job as it is now */
  function resume(card, button, key, said) {
    var mine = A;
    UI.showError(card, '');
    M.say(card, '');
    UI.setBusy(button, true);
    FP.call('post', key, {}).then(function (r) {
      if (A !== mine) { return; }
      A.job = cleanJob(r && r.move) || A.job;
      draw('#fp-hmv-job-h', said);
      if (going(A.job)) { poll(); }
    }, function (err) {
      if (A !== mine) { return; }
      UI.setBusy(button, false);
      UI.showError(card, sentence(err.message));
      if (button) { button.focus(); }
    });
  }
  function poll() {
    window.clearTimeout(A.timer);
    var mine = A;
    A.timer = window.setTimeout(function () {
      if (A !== mine || !document.body.contains(mine.page)) { return; }
      FP.call('get', 'homeMoves').then(function (r) {
        if (A !== mine) { return; }
        A.job = cleanJob(r && r.move);
        if (!going(A.job)) {
          var j = A.job;
          FP.call('get', 'homeRoots').then(function (g) { if (A === mine) { A.roots = cleanRoots(g); draw('', t('hmv_ended_' + (j ? j.state : 'done'))); } },
            function () { if (A === mine) { draw('', t('hmv_ended_' + (j ? j.state : 'done'))); } });
          return;
        }
        redrawJob();
        poll();
      }, function () { if (A === mine) { poll(); } });
    }, POLL_MS);
  }
  /* the job's card again, keeping the focus where it was */
  function redrawJob() {
    var old = A.page.querySelector('.fp-hmv-job');
    if (!old || !A.job) { draw('', ''); return; }
    var hadFocus = old.contains(document.activeElement);
    var fresh = jobCard();
    old.replaceWith(fresh);
    if (hadFocus) { fresh.querySelector('#fp-hmv-job-h').focus(); }
  }

  /* ---------- the choice ---------- */
  function select(id, name, options, first) {
    return el('select', {class: 'sig-select', id: id, name: name}, [el('option', {value: '', text: first})].concat(options.map(function (o) {
      return el('option', {value: o.value, text: o.text});
    })));
  }
  function formCard() {
    if (stopped(A.job) || going(A.job)) {
      return M.card('fp-hmv-form-h', t('hmv_form_title'), [el('p', {class: 'fp-muted', 'data-fp-wait': '', text: t('hmv_one_at_a_time')})], 'fp-hmv-choose');
    }
    var usable = A.roots.roots.filter(function (r) { return !r.problem || r.base; });
    var acct = select('fp-hmv-account', 'account', A.accounts.map(function (a) {
      return {value: a.username, text: a.username + (a.domain ? ' (' + a.domain + ')' : '') + (a.suspended ? ' · ' + t('hmv_suspended') : '')};
    }), t('hmv_account_pick'));
    var to = select('fp-hmv-root', 'root', usable.map(function (r) {
      return {value: r.path, text: r.total ? t('hmv_root_option', {root: r.path, free: size(r.free)}) : r.path};
    }), t('hmv_root_pick'));
    var plan = el('div', {class: 'fp-hmv-plan', 'data-fp-plan': ''});
    var form = el('form', {class: 'fp-form fp-mail-form fp-hmv-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-hmv-account', t('hmv_account'), acct, t('hmv_account_hint')),
      M.field('fp-hmv-root', t('hmv_root'), to, usable.length > 1 ? t('hmv_root_hint') : t('hmv_root_hint_none')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('hmv_check')})]), plan]);
    [acct, to].forEach(function (f) { f.addEventListener('change', function () { plan.textContent = ''; }); });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      plan.textContent = '';
      var body = {account: acct.value, root: to.value};
      if (!body.account) { M.fieldError(form, acct, t('hmv_need_account')); return; }
      if (!body.root) { M.fieldError(form, to, t('hmv_need_root')); return; }
      var mine = A;
      UI.setBusy(b, true);
      M.say(form, t('hmv_checking'));
      FP.call('post', 'homeMoveCheck', body).then(function (r) {
        if (A !== mine) { return; }
        UI.setBusy(b, false);
        M.say(form, '');
        var p = cleanPlan(r && r.plan);
        if (!p) { M.fieldError(form, null, t('api_failed')); return; }
        drawPlan(form, plan, p, body);
      }, function (err) {
        if (A !== mine) { return; }
        UI.setBusy(b, false);
        M.say(form, '');
        M.failed(form, err);
      });
    });
    return M.card('fp-hmv-form-h', t('hmv_form_title'), [el('p', {class: 'fp-muted', text: t('hmv_intro')}), form], 'fp-hmv-choose');
  }
  function planRow(label, value, mono) {
    return [el('dt', {class: 'fp-hmv-k', text: label}), el('dd', {class: 'fp-hmv-v' + (mono ? ' sig-mono' : ''), text: value})];
  }
  function drawPlan(form, box, p, body) {
    box.textContent = '';
    var rows = [].concat(
      planRow(t('hmv_plan_from'), p.from, true),
      planRow(t('hmv_plan_to'), p.to, true),
      planRow(t('hmv_plan_how'), p.method === 'rename' ? t('hmv_how_rename') : t('hmv_how_copy')),
      planRow(t('hmv_plan_size'), t(p.partial ? 'hmv_size_partial' : 'hmv_size', {size: size(p.bytes), files: p.files.toLocaleString('en'), free: size(p.free)})),
      planRow(t('hmv_plan_quota'), p.quota));
    if (p.selinux) { rows = rows.concat(planRow(t('hmv_plan_selinux'), t('hmv_plan_selinux_v'))); }
    var refs = p.refs.length ? el('ul', {class: 'fp-hmv-refs'}, p.refs.map(function (r) {
      return el('li', {}, [el('span', {class: 'fp-hmv-mod', text: MODULES[r.module] ? t(MODULES[r.module]) : r.module}),
        el('span', {class: 'fp-muted', text: r.lines.map(sentence).join(' · ')})]);
    })) : el('p', {class: 'fp-muted', text: t('hmv_refs_none')});
    var ack = el('input', {type: 'checkbox', id: 'fp-hmv-ack', name: 'outage_ack'});
    var go = el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'hmv-go', text: t('hmv_go', {account: p.account, root: p.root})});
    var no = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'hmv-change', text: t('hmv_change')});
    box.appendChild(el('section', {class: 'fp-hmv-confirm', 'aria-labelledby': 'fp-hmv-plan-h'}, [
      el('h3', {class: 'fp-h3', id: 'fp-hmv-plan-h', tabindex: '-1', text: t('hmv_plan_title', {account: p.account, root: p.root})}),
      el('dl', {class: 'fp-hmv-vals'}, rows),
      el('h4', {class: 'fp-hmv-h4', text: t('hmv_refs_title')}), refs,
      el('h4', {class: 'fp-hmv-h4', text: t('hmv_plan_notes')}),
      el('ul', {class: 'fp-hmv-notes'}, p.notes.map(function (n) { return el('li', {text: sentence(n)}); })),
      el('div', {class: 'sig-banner sig-banner--warn', role: 'note'}, [UI.icon(FP.ui, 'ui_warning'),
        el('span', {text: p.status === 'suspended' ? t('hmv_warn_suspended', {account: p.account}) : t('hmv_warn_outage', {account: p.account})})]),
      el('label', {class: 'fp-check fp-hmv-ackrow', for: 'fp-hmv-ack'}, [ack, el('span', {text: t('hmv_ack', {account: p.account})})]),
      el('div', {class: 'fp-actions'}, [go, no])]));
    box.querySelector('#fp-hmv-plan-h').focus();
    no.addEventListener('click', function () { box.textContent = ''; form.querySelector('[name="account"]').focus(); });
    go.addEventListener('click', function () {
      if (go.disabled) { return; }
      if (!ack.checked) { M.fieldError(form, ack, t('hmv_ack_need')); return; }
      var mine = A;
      UI.setBusy(go, true);
      UI.setBusy(no, true);
      UI.showError(form, '');
      FP.call('post', 'homeMoves', {account: body.account, root: body.root, outage_ack: true}).then(function (r) {
        if (A !== mine) { return; }
        A.job = cleanJob(r && r.move);
        draw('#fp-hmv-job-h', t('hmv_started'));
        if (going(A.job)) { poll(); }
      }, function (err) {
        if (A !== mine) { return; }
        UI.setBusy(go, false);
        UI.setBusy(no, false);
        M.failed(form, err);
      });
    });
  }

  function draw(focus, said) {
    var page = A.page;
    page.textContent = '';
    if (A.job && A.job.state !== 'dismissed') { page.appendChild(jobCard()); }
    if (!A.accounts.length && !going(A.job) && !stopped(A.job)) {
      page.appendChild(FP.empty(t('hmv_empty_title'), t('hmv_empty_text')));
    } else {
      page.appendChild(formCard());
    }
    page.appendChild(rootsCard());
    if (said) { M.say(page.querySelector('.fp-hmv-job') || page.querySelector('.fp-hmv-choose') || page, said); }
    var target = focus ? page.querySelector(focus) : null;
    if (target) { target.focus(); }
  }

  FP.view('tool:' + TOOL, function () {
    if (A) { window.clearTimeout(A.timer); }
    A = null;
    var tool = FP.tools[TOOL];
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('hmv_desc'), cls: 'fp-mail fp-hmv',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    if (!page) { return; }
    A = {page: page, accounts: [], roots: cleanRoots(null), job: null, timer: 0};
    var mine = A;
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all([FP.call('get', 'homeMoves'), FP.call('get', 'homeRoots'), FP.call('get', 'accounts')]).then(function (r) {
      if (A !== mine) { return; }
      A.job = cleanJob(r[0] && r[0].move);
      A.roots = cleanRoots(r[1]);
      A.accounts = cleanAccounts(r[2]);
      draw('', '');
      if (going(A.job)) { poll(); }
    }, function (err) {
      if (A !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, sentence(err && err.message) || t('api_failed')));
    });
  });
})();

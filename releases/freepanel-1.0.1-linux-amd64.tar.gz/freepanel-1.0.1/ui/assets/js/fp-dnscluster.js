/* freePanel DNS cluster (docs/api.md, "DNS cluster"): the admin panel's page (#/tool/dns_cluster) for the name servers this server shares
   its zones with (secondaries) and takes zones from (primaries), by zone transfer and nothing else: no call goes to another panel.
   A secondary gets a TSIG key the server makes; its secret is shown once, on this page, while it is on screen, and never again: a new key
   replaces it. A primary's secret is the admin's to give and is never shown back. Each secondary is asked for the SOA of the newest
   shared zones, and the name server's log says when it was last notified and last took a zone. A primary's zones come from its catalog
   and are listed here, read-only, as from that primary. Which zones are shared, and whether the secondaries are named in the zones' NS
   records, is the last card. Admin only. Everything the server sends is shown as text. The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var HOST_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var KEY_RE = /^(?=.{1,200}$)[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*$/;
  var IP_RE = /^[0-9A-Fa-f:.]{2,45}$/;
  var IP4_RE = /^((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$/;
  var ID_RE = /^[0-9a-f]{8}$/;
  var SECRET_RE = /^[A-Za-z0-9+/]{16,120}={0,2}$/;
  var MAX_EXCLUDE = 1000;
  var MAX_ALLOW = 100;

  /* zone names typed one per line (or by spaces or commas): {list} once each, or {bad} the first that is not one */
  function zoneList(text) {
    var list = [];
    var seenZ = {};
    var parts = text.split(/[\s,]+/);
    for (var i = 0; i < parts.length; i++) {
      var z = parts[i].trim().toLowerCase().replace(/\.$/, '');
      if (!z) { continue; }
      if (!HOST_RE.test(z)) { return {bad: z.slice(0, 80)}; }
      if (!seenZ[z]) { seenZ[z] = true; list.push(z); }
    }
    return {list: list};
  }

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  function num(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.floor(v) : 0; }
  function when(v) {
    if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}T/.test(v)) { return ''; }
    var d = new Date(v.replace(/([+-]\d\d)(\d\d)$/, '$1:$2'));
    return isNaN(d.getTime()) ? '' : d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'});
  }
  function isIP(v) { return IP_RE.test(v) && (IP4_RE.test(v) || v.indexOf(':') >= 0); }
  function names(list, n) {
    return (Array.isArray(list) ? list : []).filter(function (z) { return typeof z === 'string' && z; }).slice(0, n).map(function (z) { return z.slice(0, 253); });
  }
  function seen(v) {
    if (!v || typeof v !== 'object' || !when(v.time)) { return null; }
    return {when: when(v.time), zone: str(v.zone, 253), serial: num(v.serial)};
  }
  function probe(p) {
    p = p && typeof p === 'object' ? p : {};
    return {checked: num(p.checked), inStep: num(p.in_step), unknown: p.unknown === true, why: str(p.why, 300), missing: names(p.missing, 10),
      behind: (Array.isArray(p.behind) ? p.behind : []).filter(function (b) { return b && typeof b.zone === 'string'; }).slice(0, 10).map(function (b) {
        return {zone: b.zone.slice(0, 253), ours: num(b.ours), theirs: num(b.theirs)};
      })};
  }
  function peerBase(p) {
    if (!p || typeof p !== 'object' || !ID_RE.test(str(p.id, 8)) || !isIP(str(p.address, 45))) { return null; }
    return {id: p.id, address: p.address, key: str(p.key, 200), fingerprint: str(p.fingerprint, 32), added: when(p.added), rotated: when(p.rotated)};
  }
  function clean(v) {
    v = v && typeof v === 'object' ? v : {};
    var ids = {};
    function once(p) {
      if (!p || ids[p.id]) { return false; }
      ids[p.id] = true;
      return true;
    }
    return {available: v.available === true, why: str(v.why, 400), catalog: str(v.catalog, 253), algorithm: str(v.algorithm, 40) || 'hmac-sha256',
      error: str(v.error, 400), addNS: v.add_ns === true, exclude: names(v.exclude, MAX_EXCLUDE), shared: num(v.shared_zones), local: num(v.local_zones),
      secondaries: (Array.isArray(v.secondaries) ? v.secondaries : []).map(function (s) {
        var p = peerBase(s);
        if (!p) { return null; }
        p.ns = str(s.ns, 253);
        p.noNotify = s.no_notify === true;
        p.notified = when(s.notified);
        p.lastNotify = seen(s.last_notify);
        p.notifyFailed = seen(s.notify_failed);
        p.lastTransfer = seen(s.last_transfer);
        p.probe = probe(s.probe);
        return p;
      }).filter(once).slice(0, 20),
      primaries: (Array.isArray(v.primaries) ? v.primaries : []).map(function (s) {
        var p = peerBase(s);
        if (!p) { return null; }
        p.catalog = str(s.catalog, 253);
        p.allow = names(s.allow, MAX_ALLOW);
        p.zones = names(s.zones, 5000);
        p.skipped = names(s.skipped, 50).map(function (x) { return x.slice(0, 400); });
        p.synced = when(s.synced);
        p.syncError = str(s.sync_error, 400);
        p.serial = num(s.catalog_serial);
        p.lastTransfer = seen(s.last_transfer);
        return p;
      }).filter(once).slice(0, 10)};
  }

  var C = {page: null, S: null, busy: false, fresh: null, rotating: '', allowing: '', open: {}};

  function pill(kind, text) { return el('span', {class: 'sig-pill' + (kind ? ' sig-pill--' + kind : ''), text: text}); }
  function fact(label, value, attr) {
    return el('div', {}, [el('dt', {text: label}), el('dd', attr || {}, Array.isArray(value) ? value : [value])]);
  }
  function seenText(s, withSerial) {
    if (!s) { return t('dcl_log_none'); }
    var parts = [s.when];
    if (s.zone) { parts.push(t('dcl_log_zone', {zone: s.zone})); }
    if (withSerial && s.serial) { parts.push(t('dcl_serial', {serial: s.serial})); }
    return parts.join(' · ');
  }
  function probeLine(p) {
    if (!p.checked && !p.unknown) { return [pill('', t('dcl_probe_nothing'))]; }
    if (p.unknown) { return [pill('warn', t('dcl_probe_unknown')), p.why ? el('span', {class: 'fp-muted fp-dcl-why', text: ' ' + t('dcl_probe_why', {why: p.why})}) : null]; }
    var ok = p.inStep === p.checked;
    return [pill(ok ? 'ok' : 'warn', ok ? t('dcl_probe_ok', {n: p.checked}) : t('dcl_probe_some', {n: p.inStep, of: p.checked}))];
  }
  function peerActs(p, kind) {
    return el('div', {class: 'fp-dcl-acts'}, [
      el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'dcl-key', 'aria-label': t('dcl_key_of', {address: p.address}),
        text: kind === 'secondary' ? t('dcl_key_new') : t('dcl_key_give')}),
      el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'dcl-remove',
        'aria-label': t('dcl_remove_of', {address: p.address}), text: t('dcl_remove')})]);
  }
  function peerHead(p, kind, sub) {
    var id = 'fp-dcl-' + p.id + '-h';
    return el('div', {class: 'fp-dcl-peer-head'}, [el('h3', {class: 'fp-dcl-peer-title', id: id, tabindex: '-1'}, [el('span', {class: 'sig-mono', text: p.address}),
      sub ? el('span', {class: 'fp-muted fp-dcl-sub', text: sub}) : null]), peerActs(p, kind)]);
  }
  function keyFacts(p) {
    return [fact(t('dcl_key_name'), el('span', {class: 'sig-mono', text: p.key || '?'})),
      fact(t('dcl_fingerprint'), el('span', {class: 'sig-mono', text: p.fingerprint || '?'}), {'data-fp-fingerprint': ''}),
      fact(t('dcl_added'), p.rotated ? t('dcl_added_rotated', {added: p.added, rotated: p.rotated}) : (p.added || '?'))];
  }
  function rotateForm(p) {
    var id = 'fp-dcl-rot-' + p.id;
    var input = el('input', {class: 'sig-input sig-mono', id: id, name: 'secret', type: 'password', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', maxlength: '120'});
    var form = el('form', {class: 'fp-form fp-dcl-rot', novalidate: '', 'data-fp-rotate': p.id}, [M.errorLine(), M.field(id, t('dcl_secret_new'), input, t('dcl_secret_new_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('dcl_secret_save')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'dcl-rot-cancel', text: t('cancel')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || C.busy) { return; }
      var v = input.value.trim();
      if (!SECRET_RE.test(v)) { M.fieldError(form, input, t('dcl_secret_bad')); return; }
      rotate(p, {secret: v}, form, b);
    });
    return form;
  }
  /* a list shown on demand: a button that says what it holds, and the list only while it is open */
  function more(id, what, label, list) {
    var key = id + ':' + what;
    var open = C.open[key] === true;
    var listId = 'fp-dcl-' + id + '-' + what;
    return el('div', {class: 'fp-dcl-more', 'data-fp-more': what}, [
      el('button', {class: 'sig-btn sig-btn--link fp-dcl-more-btn', type: 'button', 'data-fp-act': 'dcl-more', 'data-fp-key': key,
        'aria-expanded': open ? 'true' : 'false', 'aria-controls': open ? listId : null, text: label}),
      open ? el('div', {id: listId}, [list()]) : null]);
  }
  function secondaryItem(s) {
    var p = s.probe;
    var facts = [fact(t('dcl_in_step'), probeLine(p), {'data-fp-probe': p.unknown ? 'unknown' : (p.checked && p.inStep === p.checked ? 'ok' : (p.checked ? 'behind' : 'none'))}),
      fact(t('dcl_last_notify'), seenText(s.lastNotify), {'data-fp-last-notify': ''}),
      fact(t('dcl_last_transfer'), seenText(s.lastTransfer), {'data-fp-last-transfer': ''}),
      fact(t('dcl_notify_mode'), t(s.noNotify ? 'dcl_notify_off' : 'dcl_notify_on'), {'data-fp-notify-mode': s.noNotify ? 'off' : 'on'})].concat(keyFacts(s));
    if (s.notified) { facts.push(fact(t('dcl_notified'), s.notified)); }
    var parts = [peerHead(s, 'secondary', s.ns ? t('dcl_ns_is', {ns: s.ns}) : ''), M.statusLine(), el('dl', {class: 'fp-dcl-facts'}, facts)];
    if (s.notifyFailed) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-notify-failed': ''}, [UI.icon(FP.ui, 'ui_warning'),
        el('span', {text: t('dcl_notify_failed', {when: s.notifyFailed.when, zone: s.notifyFailed.zone})})]));
    }
    if (p.behind.length || p.missing.length) {
      var rows = p.behind.map(function (b) { return el('li', {}, [el('span', {class: 'sig-mono', text: b.zone}), ' ', el('span', {class: 'fp-muted', text: t('dcl_behind_row', {ours: b.ours, theirs: b.theirs})})]); })
        .concat(p.missing.map(function (z) { return el('li', {}, [el('span', {class: 'sig-mono', text: z}), ' ', el('span', {class: 'fp-muted', text: t('dcl_missing_row')})]); }));
      parts.push(more(s.id, 'behind', t('dcl_behind_title', {n: rows.length}), function () { return el('ul', {class: 'fp-dcl-zlist'}, rows); }));
    }
    return el('li', {class: 'fp-dcl-peer', 'data-fp-peer': s.id, 'data-fp-kind': 'secondary', 'aria-labelledby': 'fp-dcl-' + s.id + '-h'}, parts);
  }
  function allowForm(p) {
    var id = 'fp-dcl-allow-' + p.id;
    var text = el('textarea', {class: 'sig-input sig-mono fp-dcl-exclude', id: id, name: 'allow', rows: '4', spellcheck: 'false', autocapitalize: 'none', wrap: 'off'});
    text.value = p.allow.join('\n');
    var form = el('form', {class: 'fp-form fp-dcl-rot', novalidate: '', 'data-fp-allow': p.id}, [M.errorLine(), M.field(id, t('dcl_allow'), text, t('dcl_allow_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('dcl_allow_save')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'dcl-allow-cancel', text: t('cancel')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || C.busy) { return; }
      var got = zoneList(text.value);
      if (got.bad) { M.fieldError(form, text, t('dcl_allow_bad', {zone: got.bad})); return; }
      if (got.list.length > MAX_ALLOW) { M.fieldError(form, text, t('dcl_allow_many', {max: MAX_ALLOW})); return; }
      C.busy = true;
      UI.setBusy(b, true);
      var mine = C.page;
      FP.call('put', 'dnsClusterPrimaryAllow', {allow: got.list}, {id: p.id}).then(function () {
        C.busy = false;
        if (C.page !== mine) { return; }
        C.allowing = '';
        reload(function () {
          var li = C.page.querySelector('li[data-fp-peer="' + p.id + '"]');
          M.say(li, t('dcl_allow_saved', {address: p.address}));
          li.querySelector('h3').focus();
        });
      }, function (err) {
        C.busy = false;
        if (C.page !== mine) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return form;
  }
  function allowFact(p) {
    var value = p.allow.length ? el('span', {class: 'sig-mono', text: p.allow.join(', ')}) : pill('warn', t('dcl_allow_none'));
    return fact(t('dcl_allow'), [value, ' ', el('button', {class: 'sig-btn sig-btn--link fp-dcl-allow-btn', type: 'button', 'data-fp-act': 'dcl-allow',
      'aria-label': t('dcl_allow_change_of', {address: p.address}), 'aria-expanded': C.allowing === p.id ? 'true' : 'false', text: t('dcl_allow_change')})],
      {'data-fp-allow-list': p.allow.length ? 'set' : 'none'});
  }
  function primaryItem(p) {
    var facts = [fact(t('dcl_catalog'), el('span', {class: 'sig-mono', text: p.catalog})), allowFact(p),
      fact(t('dcl_zones_taken'), String(p.zones.length), {'data-fp-zone-count': ''}),
      fact(t('dcl_synced'), p.synced ? (p.serial ? t('dcl_synced_serial', {when: p.synced, serial: p.serial}) : p.synced) : t('dcl_synced_never')),
      fact(t('dcl_last_transfer_in'), seenText(p.lastTransfer, true), {'data-fp-last-transfer': ''})].concat(keyFacts(p));
    var parts = [peerHead(p, 'primary', t('dcl_from_catalog')), M.statusLine(), el('dl', {class: 'fp-dcl-facts'}, facts)];
    if (p.syncError) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-sync-error': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: p.syncError})]));
    }
    if (C.allowing === p.id) { parts.push(allowForm(p)); }
    if (C.rotating === p.id) { parts.push(rotateForm(p)); }
    if (p.zones.length) {
      parts.push(more(p.id, 'zones', t('dcl_zones_list', {n: p.zones.length, address: p.address}), function () {
        return el('ul', {class: 'fp-dcl-zlist fp-dcl-zcols'}, p.zones.map(function (z) {
          return el('li', {}, [el('span', {class: 'sig-mono', text: z}), ' ', el('span', {class: 'fp-muted', text: t('dcl_from', {address: p.address})})]);
        }));
      }));
    }
    if (p.skipped.length) {
      parts.push(more(p.id, 'skipped', t('dcl_skipped', {n: p.skipped.length}), function () {
        return el('ul', {class: 'fp-dcl-zlist'}, p.skipped.map(function (x) { return el('li', {text: x}); }));
      }));
    }
    return el('li', {class: 'fp-dcl-peer', 'data-fp-peer': p.id, 'data-fp-kind': 'primary', 'aria-labelledby': 'fp-dcl-' + p.id + '-h'}, parts);
  }

  /* ---- the cards ---- */
  function introCard() {
    var S = C.S;
    var parts = [el('p', {class: 'fp-muted', text: t('dcl_what')}),
      el('ul', {class: 'fp-dcl-stats', 'aria-label': t('dcl_stats')}, [
        el('li', {}, [el('strong', {text: String(S.secondaries.length)}), el('span', {text: t('dcl_stat_secondaries')})]),
        el('li', {}, [el('strong', {text: String(S.primaries.length)}), el('span', {text: t('dcl_stat_primaries')})]),
        el('li', {'data-fp-shared': ''}, [el('strong', {text: S.shared + ' / ' + S.local}), el('span', {text: t('dcl_stat_shared')})])])];
    if (S.catalog) { parts.push(el('p', {class: 'fp-muted', 'data-fp-catalog': ''}, [t('dcl_catalog_is') + ' ', el('span', {class: 'sig-mono', text: S.catalog})])); }
    if (!S.available) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-dcl-unavailable': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('dcl_unavailable', {why: S.why || '?'})})]));
    }
    if (S.error) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-dcl-error': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('dcl_meta_error', {error: S.error})})]));
    }
    parts.push(el('p', {class: 'fp-muted fp-dcl-scope', text: t('dcl_scope')}));
    return M.card('fp-dcl-intro-h', t('dcl_title'), parts, 'fp-dcl-intro');
  }
  function freshCard() {
    var f = C.fresh;
    var conf = 'key "' + f.key + '" {\n  algorithm ' + f.algorithm + ';\n  secret "' + f.secret + '";\n};';
    var parts = [el('p', {class: 'fp-muted', text: t(f.renewed ? 'dcl_fresh_renewed' : 'dcl_fresh_what', {address: f.address})}),
      el('div', {class: 'sig-banner sig-banner--warn', role: 'note'}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('dcl_once')})]),
      el('dl', {class: 'fp-dcl-facts'}, [fact(t('dcl_key_name'), el('span', {class: 'sig-mono', 'data-fp-key-name': '', text: f.key})),
        fact(t('dcl_algorithm'), el('span', {class: 'sig-mono', text: f.algorithm}))]),
      el('div', {class: 'fp-ddn-token-row'}, [el('code', {class: 'sig-mono fp-ddn-token', id: 'fp-dcl-secret', tabindex: '0', 'data-fp-secret': '', 'aria-label': t('dcl_secret'), text: f.secret}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'dcl-copy', text: t('dcl_copy')})]),
      el('p', {class: 'fp-muted', text: t('dcl_fresh_how', {catalog: C.S.catalog})}),
      el('pre', {class: 'sig-mono fp-ddn-code', tabindex: '0', 'aria-label': t('dcl_conf_label'), text: conf}),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'dcl-done', text: t('dcl_done')})])];
    return M.card('fp-dcl-fresh-h', t('dcl_fresh_title', {address: f.address}), [M.statusLine()].concat(parts), 'fp-dcl-fresh');
  }
  function secondariesCard() {
    var S = C.S;
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t('dcl_sec_what')})];
    if (!S.secondaries.length) {
      parts.push(el('p', {class: 'fp-muted fp-dcl-empty', 'data-fp-empty': 'secondaries', text: t('dcl_sec_none')}));
    } else {
      parts.push(el('ul', {class: 'fp-dcl-peers', 'aria-labelledby': 'fp-dcl-sec-h'}, S.secondaries.map(secondaryItem)));
      parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'dcl-notify', text: t('dcl_notify')})]));
    }
    if (S.available) { parts.push(secondaryForm()); }
    return M.card('fp-dcl-sec-h', t('dcl_sec_title'), parts, 'fp-dcl-sec');
  }
  function secondaryForm() {
    var addr = el('input', {class: 'sig-input sig-mono', id: 'fp-dcl-sec-addr', name: 'address', type: 'text', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', maxlength: '45'});
    var ns = el('input', {class: 'sig-input sig-mono', id: 'fp-dcl-sec-ns', name: 'ns', type: 'text', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', maxlength: '253'});
    var poll = el('input', {type: 'checkbox', id: 'fp-dcl-sec-poll', name: 'no_notify', 'aria-describedby': 'fp-dcl-sec-poll-hint'});
    var form = el('form', {class: 'fp-form fp-dcl-form', novalidate: '', 'data-fp-form': 'secondary'}, [el('h3', {class: 'fp-dcl-form-h', text: t('dcl_sec_add_title')}), M.errorLine(),
      el('div', {class: 'sig-banner', role: 'note', 'data-fp-notify-window': ''}, [UI.icon(FP.ui, 'ui_info'), el('span', {text: t('dcl_notify_window')})]),
      el('div', {class: 'fp-dcl-grid'}, [M.field('fp-dcl-sec-addr', t('dcl_address'), addr, t('dcl_sec_address_hint')), M.field('fp-dcl-sec-ns', t('dcl_ns'), ns, t('dcl_ns_hint'))]),
      el('label', {class: 'fp-check', for: 'fp-dcl-sec-poll'}, [poll, el('span', {text: t('dcl_no_notify')})]),
      el('p', {class: 'sig-hint', id: 'fp-dcl-sec-poll-hint', text: t('dcl_no_notify_hint')}),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('dcl_sec_add')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || C.busy) { return; }
      var a = addr.value.trim();
      var n = ns.value.trim().toLowerCase().replace(/\.$/, '');
      if (!isIP(a)) { M.fieldError(form, addr, t('dcl_address_bad')); return; }
      if (n && !HOST_RE.test(n)) { M.fieldError(form, ns, t('dcl_ns_bad')); return; }
      var body = {address: a};
      if (n) { body.ns = n; }
      if (poll.checked) { body.no_notify = true; }
      C.busy = true;
      UI.setBusy(b, true);
      var mine = C.page;
      FP.call('post', 'dnsClusterSecondaries', body).then(function (r) {
        C.busy = false;
        if (C.page !== mine) { return; }
        C.fresh = freshOf(r, false);
        reload(focusFresh);
      }, function (err) {
        C.busy = false;
        if (C.page !== mine) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return form;
  }
  function primariesCard() {
    var S = C.S;
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t('dcl_pri_what')})];
    if (!S.primaries.length) {
      parts.push(el('p', {class: 'fp-muted fp-dcl-empty', 'data-fp-empty': 'primaries', text: t('dcl_pri_none')}));
    } else {
      parts.push(el('ul', {class: 'fp-dcl-peers', 'aria-labelledby': 'fp-dcl-pri-h'}, S.primaries.map(primaryItem)));
      parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'dcl-sync', text: t('dcl_sync')})]));
    }
    if (S.available) { parts.push(primaryForm()); }
    return M.card('fp-dcl-pri-h', t('dcl_pri_title'), parts, 'fp-dcl-pri');
  }
  function primaryForm() {
    function input(name, attrs) {
      return el('input', Object.assign({class: 'sig-input sig-mono', id: 'fp-dcl-pri-' + name, name: name, type: 'text', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none'}, attrs));
    }
    var addr = input('address', {maxlength: '45'});
    var key = input('key', {maxlength: '200'});
    var secret = input('secret', {maxlength: '120', type: 'password'});
    var catalog = input('catalog', {maxlength: '253'});
    var allow = el('textarea', {class: 'sig-input sig-mono fp-dcl-exclude', id: 'fp-dcl-pri-allow', name: 'allow', rows: '3', spellcheck: 'false', autocapitalize: 'none', wrap: 'off'});
    var form = el('form', {class: 'fp-form fp-dcl-form', novalidate: '', 'data-fp-form': 'primary'}, [el('h3', {class: 'fp-dcl-form-h', text: t('dcl_pri_add_title')}), M.errorLine(),
      el('div', {class: 'fp-dcl-grid'}, [M.field('fp-dcl-pri-address', t('dcl_address'), addr, t('dcl_pri_address_hint')),
        M.field('fp-dcl-pri-catalog', t('dcl_catalog'), catalog, t('dcl_catalog_hint')),
        M.field('fp-dcl-pri-key', t('dcl_key_name'), key, t('dcl_key_hint')),
        M.field('fp-dcl-pri-secret', t('dcl_secret'), secret, t('dcl_secret_hint'))]),
      M.field('fp-dcl-pri-allow', t('dcl_allow'), allow, t('dcl_allow_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('dcl_pri_add')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || C.busy) { return; }
      var body = {address: addr.value.trim(), key: key.value.trim().toLowerCase().replace(/\.$/, ''), secret: secret.value.trim(),
        catalog: catalog.value.trim().toLowerCase().replace(/\.$/, '')};
      if (!isIP(body.address)) { M.fieldError(form, addr, t('dcl_address_bad')); return; }
      if (!HOST_RE.test(body.catalog)) { M.fieldError(form, catalog, t('dcl_catalog_bad')); return; }
      if (!KEY_RE.test(body.key)) { M.fieldError(form, key, t('dcl_key_bad')); return; }
      if (!SECRET_RE.test(body.secret)) { M.fieldError(form, secret, t('dcl_secret_bad')); return; }
      var got = zoneList(allow.value);
      if (got.bad) { M.fieldError(form, allow, t('dcl_allow_bad', {zone: got.bad})); return; }
      if (got.list.length > MAX_ALLOW) { M.fieldError(form, allow, t('dcl_allow_many', {max: MAX_ALLOW})); return; }
      body.allow = got.list;
      C.busy = true;
      UI.setBusy(b, true);
      var mine = C.page;
      FP.call('post', 'dnsClusterPrimaries', body).then(function () {
        C.busy = false;
        if (C.page !== mine) { return; }
        reload(function () {
          var card = C.page.querySelector('.fp-dcl-pri');
          M.say(card, t('dcl_pri_added', {address: body.address}));
          card.querySelector('#fp-dcl-pri-h').focus();
        });
      }, function (err) {
        C.busy = false;
        if (C.page !== mine) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return form;
  }
  function settingsCard() {
    var S = C.S;
    var text = el('textarea', {class: 'sig-input sig-mono fp-dcl-exclude', id: 'fp-dcl-exclude', name: 'exclude', rows: '5', spellcheck: 'false', autocapitalize: 'none', wrap: 'off'});
    text.value = S.exclude.join('\n');
    var ns = el('input', {type: 'checkbox', id: 'fp-dcl-addns', name: 'add_ns', checked: S.addNS ? true : null});
    var form = el('form', {class: 'fp-form fp-dcl-settings', novalidate: ''}, [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t('dcl_set_what')}),
      M.field('fp-dcl-exclude', t('dcl_exclude'), text, t('dcl_exclude_hint')),
      el('label', {class: 'fp-check', for: 'fp-dcl-addns'}, [ns, el('span', {text: t('dcl_addns')})]),
      el('p', {class: 'sig-hint', text: t('dcl_addns_hint')}),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('dcl_set_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || C.busy) { return; }
      var got = zoneList(text.value);
      if (got.bad) { M.fieldError(form, text, t('dcl_exclude_bad', {zone: got.bad})); return; }
      var list = got.list;
      if (list.length > MAX_EXCLUDE) { M.fieldError(form, text, t('dcl_exclude_many', {max: MAX_EXCLUDE})); return; }
      C.busy = true;
      UI.setBusy(b, true);
      var mine = C.page;
      FP.call('put', 'dnsClusterSettings', {exclude: list, add_ns: ns.checked}).then(function () {
        C.busy = false;
        if (C.page !== mine) { return; }
        reload(function () {
          var card = C.page.querySelector('.fp-dcl-set');
          M.say(card, t('dcl_set_saved'));
          card.querySelector('#fp-dcl-set-h').focus();
        });
      }, function (err) {
        C.busy = false;
        if (C.page !== mine) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return M.card('fp-dcl-set-h', t('dcl_set_title'), [form], 'fp-dcl-set');
  }

  function render() {
    C.page.textContent = '';
    C.page.appendChild(introCard());
    if (C.fresh) { C.page.appendChild(freshCard()); }
    C.page.appendChild(secondariesCard());
    C.page.appendChild(primariesCard());
    if (C.S.available || C.S.secondaries.length || C.S.exclude.length) { C.page.appendChild(settingsCard()); }
  }
  function freshOf(r, renewed) {
    var s = r && r.secondary && typeof r.secondary === 'object' ? r.secondary : {};
    var secret = r && typeof r.secret === 'string' && SECRET_RE.test(r.secret) ? r.secret : '';
    if (!secret) { return null; }
    return {address: str(s.address, 45), key: str(s.key, 200), algorithm: str(r.algorithm, 40) || 'hmac-sha256', secret: secret, renewed: renewed};
  }
  function focusFresh() {
    var h = C.page && (C.page.querySelector('#fp-dcl-fresh-h') || C.page.querySelector('#fp-dcl-sec-h'));
    if (h) { h.focus(); }
  }
  function reload(done) {
    var mine = C.page;
    FP.call('get', 'dnsCluster').then(function (r) {
      if (C.page !== mine) { return; }
      C.S = clean(r);
      render();
      if (done) { done(); }
    }, function (err) {
      if (C.page !== mine) { return; }
      render();
      UI.showError(C.page.querySelector('.fp-dcl-sec'), err.message);
    });
  }
  function rotate(p, body, form, b) {
    C.busy = true;
    UI.setBusy(b, true);
    var mine = C.page;
    FP.call('post', 'dnsClusterPeerKey', body, {id: p.id}).then(function (r) {
      C.busy = false;
      if (C.page !== mine) { return; }
      C.rotating = '';
      var f = freshOf(r, true);
      if (f) { C.fresh = f; }
      reload(function () {
        if (f) { focusFresh(); return; }
        var li = C.page.querySelector('li[data-fp-peer="' + p.id + '"]');
        M.say(li, t('dcl_secret_saved'));
        li.querySelector('h3').focus();
      });
    }, function (err) {
      C.busy = false;
      if (C.page !== mine) { return; }
      UI.setBusy(b, false);
      if (form) { M.failed(form, err); return; }
      render();
      var li = C.page.querySelector('li[data-fp-peer="' + p.id + '"]');
      UI.showError(li.closest('.sig-card'), err.message);
      li.querySelector('h3').focus();
    });
  }
  function copy() {
    var scope = C.page.querySelector('.fp-dcl-fresh');
    var node = C.page.querySelector('#fp-dcl-secret');
    function selected() {
      var range = document.createRange();
      range.selectNodeContents(node);
      var sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
      M.say(scope, t('dcl_selected'));
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(C.fresh.secret).then(function () { M.say(scope, t('dcl_copied')); }, selected);
    } else {
      selected();
    }
  }
  function cardAction(b, call, okText) {
    var card = b.closest('.sig-card');
    C.busy = true;
    UI.setBusy(b, true);
    var mine = C.page;
    var cls = card.classList.contains('fp-dcl-pri') ? '.fp-dcl-pri' : '.fp-dcl-sec';
    call.then(function (r) {
      C.busy = false;
      if (C.page !== mine) { return; }
      reload(function () {
        var c = C.page.querySelector(cls);
        M.say(c, okText(r));
        c.querySelector('h2').focus();
      });
    }, function (err) {
      C.busy = false;
      if (C.page !== mine) { return; }
      UI.setBusy(b, false);
      UI.showError(card, err.message);
    });
  }

  document.addEventListener('click', function (e) {
    var node = e.target.closest ? e.target : null;
    var b = node && node.closest('[data-fp-act]');
    if (!b || !C.page || !C.page.contains(b) || !C.S) { return; }
    var a = b.getAttribute('data-fp-act');
    var li = b.closest('li[data-fp-peer]');
    var id = li ? li.getAttribute('data-fp-peer') : '';
    var kind = li ? li.getAttribute('data-fp-kind') : '';
    var peer = (kind === 'primary' ? C.S.primaries : C.S.secondaries).filter(function (x) { return x.id === id; })[0];
    var mine = C.page;
    if (a === 'dcl-more') {
      var key = b.getAttribute('data-fp-key');
      C.open[key] = C.open[key] !== true;
      render();
      var back = C.page.querySelector('[data-fp-act="dcl-more"][data-fp-key="' + window.CSS.escape(key) + '"]');
      if (back) { back.focus(); }
    } else if (a === 'dcl-copy' && C.fresh) {
      copy();
    } else if (a === 'dcl-done') {
      C.fresh = null;
      render();
      C.page.querySelector('#fp-dcl-sec-h').focus();
    } else if (a === 'dcl-notify' && !C.busy) {
      cardAction(b, FP.call('post', 'dnsClusterNotify', {}), function (r) { return t('dcl_notified_n', {n: num(r && r.zones)}); });
    } else if (a === 'dcl-sync' && !C.busy) {
      cardAction(b, FP.call('post', 'dnsClusterSync', {}), function () { return t('dcl_synced_now'); });
    } else if (!peer) {
      return;
    } else if (a === 'dcl-allow' && kind === 'primary') {
      C.allowing = C.allowing === peer.id ? '' : peer.id;
      render();
      var opened = C.page.querySelector('form[data-fp-allow="' + peer.id + '"] textarea');
      if (opened) { opened.focus(); } else { C.page.querySelector('li[data-fp-peer="' + id + '"] [data-fp-act="dcl-allow"]').focus(); }
    } else if (a === 'dcl-allow-cancel') {
      C.allowing = '';
      render();
      C.page.querySelector('li[data-fp-peer="' + id + '"] [data-fp-act="dcl-allow"]').focus();
    } else if (a === 'dcl-key' && kind === 'primary') {
      C.rotating = peer.id;
      render();
      C.page.querySelector('form[data-fp-rotate="' + peer.id + '"] input').focus();
    } else if (a === 'dcl-rot-cancel') {
      C.rotating = '';
      render();
      C.page.querySelector('li[data-fp-peer="' + id + '"] [data-fp-act="dcl-key"]').focus();
    } else if (a === 'dcl-key') {
      M.confirmIn(li.querySelector('.fp-dcl-acts'), t('dcl_key_ask', {address: peer.address}), 'dcl-key-yes', t('dcl_key_new'));
    } else if (a === 'dcl-remove') {
      M.confirmIn(li.querySelector('.fp-dcl-acts'), t(kind === 'primary' ? 'dcl_remove_ask_pri' : 'dcl_remove_ask_sec', {address: peer.address}), 'dcl-remove-yes', t('dcl_remove'));
    } else if (a === 'confirm-no') {
      var opener = li.querySelector('[data-fp-act="dcl-key-yes"]') ? 'dcl-key' : 'dcl-remove';
      render();
      var again = C.page.querySelector('li[data-fp-peer="' + id + '"] [data-fp-act="' + opener + '"]');
      if (again) { again.focus(); }
    } else if (a === 'dcl-key-yes' && !C.busy) {
      rotate(peer, {}, null, b);
    } else if (a === 'dcl-remove-yes' && !C.busy) {
      C.busy = true;
      UI.setBusy(b, true);
      FP.call('del', 'dnsClusterPeer', undefined, {id: id}).then(function () {
        C.busy = false;
        if (C.page !== mine) { return; }
        if (C.rotating === id) { C.rotating = ''; }
        if (C.allowing === id) { C.allowing = ''; }
        reload(function () {
          var card = C.page.querySelector(kind === 'primary' ? '.fp-dcl-pri' : '.fp-dcl-sec');
          M.say(card, t('dcl_removed', {address: peer.address}));
          card.querySelector('h2').focus();
        });
      }, function (err) {
        C.busy = false;
        if (C.page !== mine) { return; }
        var shown = function () {
          var card = C.page.querySelector(kind === 'primary' ? '.fp-dcl-pri' : '.fp-dcl-sec');
          UI.showError(card, err.message);
          card.querySelector('h2').focus();
        };
        if (err && err.status === 404) { reload(shown); return; }
        render();
        shown();
      });
    }
  });

  FP.view('tool:dns_cluster', function () {
    var tool = FP.tools.dns_cluster;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    C.S = null;
    C.busy = false;
    C.fresh = null;
    C.rotating = '';
    C.allowing = '';
    C.open = {};
    var body = FP.frame({title: tool.label, desc: t('dcl_desc'), cls: 'fp-mail fp-srv fp-dcl-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    C.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'dnsCluster').then(function (r) {
      if (C.page !== body) { return; }
      C.S = clean(r);
      render();
    }, function (err) {
      if (C.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

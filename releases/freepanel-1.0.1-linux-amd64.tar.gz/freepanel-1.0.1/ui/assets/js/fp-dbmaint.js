/* freePanel check and repair for a database (docs/api.md, "Check and repair a database"): a card on the customer panel's MariaDB and
   PostgreSQL pages (fp-databases.js) that runs one action on every table of one database and lists what the server said for each
   table. Nothing runs until the customer chooses an action and asks. A run can take minutes, so the page says so and keeps the choices
   off until it ends. What the server sends is cleaned to the shapes drawn and shown as text. Page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var ACTIONS = {mysql: ['check', 'repair', 'analyze', 'optimize'], postgres: ['analyze', 'vacuum', 'reindex']};
  var STATUS = ['ok', 'warning', 'error', 'skipped'];
  var RANK = {error: 0, warning: 1, ok: 2, skipped: 2};
  var MAX_TABLES = 1000;
  var CUR = null; /* {engine, db, action, running, result, error} while the card is open */

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  function num(v) { return typeof v === 'number' && isFinite(v) && v > 0 ? Math.round(v) : 0; }
  function count(n) { return n.toLocaleString('en'); }
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var tables = (Array.isArray(r.tables) ? r.tables : []).filter(function (x) { return x && typeof x === 'object'; }).slice(0, MAX_TABLES).map(function (x, i) {
      var s = str(x.status, 20);
      return {table: str(x.table, 200), status: STATUS.indexOf(s) >= 0 ? s : 'warning', message: str(x.message, 500), at: i};
    });
    /* the tables with a problem first, each group in the order the server went through them */
    tables.sort(function (a, b) { return (RANK[a.status] - RANK[b.status]) || (a.at - b.at); });
    return {checked: num(r.checked) || tables.length, problems: num(r.problems), incomplete: r.incomplete === true, tables: tables};
  }
  function label(action) { return t('dbm_a_' + action); }
  /* what MariaDB says of a table whose storage engine (InnoDB, the usual one) cannot be repaired: the run is ok and the table was left as it is */
  var NO_REPAIR = /storage engine for the table does(?:n't| not) support repair/i;

  function resultSection(c) {
    var r = c.result;
    var args = {action: label(c.action), name: c.db, checked: count(r.checked), problems: count(r.problems)};
    var parts = [el('h3', {class: 'fp-h3', id: 'fp-dbm-result-h', tabindex: '-1', text: t('dbm_result_title', {action: label(c.action)})})];
    var key = !r.checked && !r.tables.length ? 'dbm_done_none' : r.problems ? 'dbm_done_problems' : 'dbm_done_ok';
    /* a repair that could not run on some or all of the tables says so, and does not say "done" as if it had mended them */
    if (c.engine === 'mysql' && c.action === 'repair') {
      var looked = r.tables.filter(function (x) { return x.status !== 'skipped'; }).length;
      var stuck = r.tables.filter(function (x) { return x.status === 'ok' && NO_REPAIR.test(x.message); }).length;
      if (stuck) {
        args.n = count(looked);
        args.stuck = count(stuck);
        args.repaired = count(looked - stuck);
        key = r.problems ? 'dbm_done_repair_problems' : stuck >= looked ? 'dbm_done_repair_none' : 'dbm_done_repair_some';
      }
    }
    parts.push(el('p', {class: r.problems ? 'sig-banner sig-banner--warn' : 'fp-muted', 'data-fp-summary': r.problems ? 'problems' : 'ok', text: t(key, args)}));
    if (r.incomplete) { parts.push(el('p', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-incomplete': '', text: t('dbm_incomplete')})); }
    if (r.tables.length) {
      var rows = r.tables.map(function (x) {
        return el('tr', {'data-fp-table': x.table, 'data-fp-status': x.status}, [el('th', {scope: 'row', class: 'sig-mono', text: x.table}),
          el('td', null, [el('span', {class: 'sig-pill' + (x.status === 'ok' ? ' sig-pill--ok' : x.status === 'skipped' ? '' : x.status === 'error' ? ' sig-pill--danger' : ' sig-pill--warn'), text: t('dbm_s_' + x.status)})]),
          el('td', {class: 'fp-dbm-msg', text: x.message || '—'})]);
      });
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-dbm-result-h'}, [el('table', {class: 'sig-table fp-dbm-table'}, [
        el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('dbm_col_table')}), el('th', {scope: 'col', text: t('dbm_col_result')}), el('th', {scope: 'col', text: t('dbm_col_message')})])]),
        el('tbody', null, rows)])]));
    }
    return el('section', {class: 'fp-dbm-result', 'aria-labelledby': 'fp-dbm-result-h'}, parts);
  }

  /* the card for the database the customer chose, or null; ctx is {engine, page, has(name), call(), render()} from fp-databases.js */
  function card(ctx) {
    if (!CUR) { return null; }
    if (CUR.engine !== ctx.engine || !ctx.has(CUR.db)) { CUR = null; return null; }
    var c = CUR;
    var pg = c.engine === 'postgres';
    var radios = ACTIONS[c.engine].map(function (a) {
      var id = 'fp-dbm-a-' + a;
      var input = el('input', {type: 'radio', id: id, name: 'action', value: a, 'aria-describedby': id + '-hint', checked: a === c.action ? true : null, disabled: c.running ? true : null});
      input.addEventListener('change', function () { c.action = a; run.textContent = t('dbm_run', {action: label(a)}); });
      return el('div', {class: 'fp-dbm-choice'}, [el('label', {class: 'fp-check', for: id}, [input, el('span', {text: label(a)})]), el('span', {class: 'sig-hint', id: id + '-hint', text: t('dbm_h_' + a)})]);
    });
    var run = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', id: 'fp-dbm-run', text: t('dbm_run', {action: label(c.action)})});
    var close = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'maint-close', disabled: c.running ? true : null, text: t('dbm_close')});
    var form = el('form', {class: 'fp-form fp-dbm-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('fieldset', {class: 'fp-dbm-actions'}, [el('legend', {class: 'sig-label', text: t('dbm_what')})].concat(radios)),
      el('div', {class: 'fp-actions'}, [run, close])]);
    if (c.running) {
      UI.setBusy(run, true);
      M.say(form, t('dbm_running', {action: label(c.action), name: c.db}));
    }
    if (c.error) { UI.showError(form, c.error); }
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || c.running || CUR !== c) { return; }
      c.running = true;
      c.result = null;
      c.error = '';
      var action = c.action;
      var again = form.querySelectorAll('input[name="action"]');
      for (var i = 0; i < again.length; i++) { again[i].disabled = true; }
      close.disabled = true;
      UI.setBusy(b, true);
      M.say(form, t('dbm_running', {action: label(action), name: c.db}));
      ctx.call('post', 'Maintenance', {action: action}, {db: c.db}).then(function (r) {
        c.running = false;
        if (CUR !== c) { return; }
        c.result = clean(r);
        ctx.render();
        var h = ctx.page.querySelector('#fp-dbm-result-h');
        if (h) { h.focus(); }
      }, function (err) {
        c.running = false;
        if (CUR !== c) { return; }
        c.error = err && err.message ? err.message : t('api_failed');
        ctx.render();
        var rb = ctx.page.querySelector('#fp-dbm-run');
        if (rb) { rb.focus(); }
      });
    });
    var parts = [el('p', {class: 'fp-muted fp-dbm-intro', text: t(pg ? 'dbm_intro_pg' : 'dbm_intro')}), form];
    if (c.result) { parts.push(resultSection(c)); }
    var node = M.card('fp-dbm-h', t(pg ? 'dbm_title_pg' : 'dbm_title', {name: c.db}), parts, 'fp-dbm');
    node.setAttribute('data-fp-maint-of', c.db);
    return node;
  }
  /* the customer chose a database: its card opens (or is shown again) and takes the focus */
  function open(ctx, db) {
    if (!CUR || CUR.db !== db || CUR.engine !== ctx.engine) {
      CUR = {engine: ctx.engine, db: db, action: ACTIONS[ctx.engine][0], running: false, result: null, error: ''};
    }
    ctx.render();
    ctx.page.querySelector('#fp-dbm-h').focus();
  }
  /* the card is closed; the database's own button gets the focus back */
  function close(ctx) {
    var db = CUR ? CUR.db : '';
    CUR = null;
    ctx.render();
    var b = ctx.page.querySelector('tr[data-fp-db="' + window.CSS.escape(db) + '"] [data-fp-act="maintain"]');
    if (b) { b.focus(); }
  }
  function reset() { CUR = null; }

  FP.dbMaint = {card: card, open: open, close: close, reset: reset};
})();

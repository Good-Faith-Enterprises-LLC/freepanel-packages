/* freePanel DNS records (docs/api.md, "DNS zones"): the customer panel's editor for the zones of the account's domains
   (#/tool/dns). A zone is read with its serial and saved whole: every add, change or remove sends the full record list
   with that serial, so a change made elsewhere meanwhile is never overwritten (the server answers 409 and the page
   loads the zone again). A domain the account holds without a zone here can be given one; a zone other than the main
   domain's can be removed. The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var ZONE_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var LABEL_RE = /^(\*|_?[a-z0-9]([a-z0-9_-]{0,61}[a-z0-9])?)$/;
  var IP4_RE = /^((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$/;
  var TYPES = ['A', 'AAAA', 'CNAME', 'MX', 'TXT', 'SRV', 'CAA', 'NS'];
  var PRIORITY = {MX: true, SRV: true};
  var MIN_TTL = 60;
  var MAX_TTL = 604800;
  var DEFAULT_TTL = 14400;
  var MAX_RECORDS = 1000;

  function str(v) { return typeof v === 'string' ? v : ''; }
  function int(v) { return typeof v === 'number' && isFinite(v) && Math.floor(v) === v ? v : null; }
  /* a record as the server sent it, or null when it isn't one this page can show and send back unchanged */
  function cleanRecord(r) {
    if (!r || typeof r !== 'object' || TYPES.indexOf(r.type) < 0 || typeof r.name !== 'string' || typeof r.content !== 'string') { return null; }
    var ttl = int(r.ttl);
    var p = r.priority === undefined || r.priority === null ? null : int(r.priority);
    if (ttl === null || (PRIORITY[r.type] ? p === null : (r.priority !== undefined && r.priority !== null))) { return null; }
    return {name: r.name, type: r.type, ttl: ttl, priority: p, content: r.content};
  }
  function cleanZone(v) {
    v = v && typeof v === 'object' ? v : {};
    var raw = Array.isArray(v.records) ? v.records : [];
    var records = raw.map(cleanRecord);
    var readable = records.every(Boolean);
    return {zone: str(v.zone), primary: v.primary === true, serial: int(v.serial), readable: readable && int(v.serial) !== null,
      nameservers: (Array.isArray(v.nameservers) ? v.nameservers : []).filter(function (n) { return ZONE_RE.test(str(n)); }),
      records: records.filter(Boolean)};
  }
  function cleanZones(v) {
    return (v && Array.isArray(v.zones) ? v.zones : []).filter(function (z) { return z && ZONE_RE.test(str(z.zone)); }).map(function (z) {
      return {zone: z.zone, primary: z.primary === true};
    }).sort(function (a, b) { return (b.primary - a.primary) || (a.zone < b.zone ? -1 : 1); });
  }
  /* names the account holds (from the Domains list) that could have a zone: not a subdomain, not under a zone it has */
  function zoneless(sites, zones) {
    var have = zones.map(function (z) { return z.zone; });
    var out = [];
    (Array.isArray(sites) ? sites : []).forEach(function (s) {
      if (!s || s.kind === 'sub' || s.kind === 'subdomain') { return; }
      [s.domain].concat(Array.isArray(s.aliases) ? s.aliases : []).forEach(function (d) {
        if (!ZONE_RE.test(str(d)) || out.indexOf(d) >= 0) { return; }
        if (have.some(function (z) { return d === z || d.slice(-z.length - 1) === '.' + z; })) { return; }
        out.push(d);
      });
    });
    return out.sort();
  }
  function fullName(zone, name) { return name === '@' ? zone : name + '.' + zone; }
  function ttlText(s) {
    if (s % 86400 === 0) { return t(s === 86400 ? 'dns_ttl_day' : 'dns_ttl_days', {n: s / 86400}); }
    if (s % 3600 === 0) { return t(s === 3600 ? 'dns_ttl_hour' : 'dns_ttl_hours', {n: s / 3600}); }
    if (s % 60 === 0) { return t(s === 60 ? 'dns_ttl_minute' : 'dns_ttl_minutes', {n: s / 60}); }
    return t('dns_ttl_seconds', {n: s});
  }

  var Z = {page: null, account: '', zones: [], spare: [], cur: null, open: -1, filter: '', busy: false};

  /* ---- the record form, for adding and for changing one ---- */
  function recordForm(prefix, rec, inline) {
    var zone = Z.cur.zone;
    var name = el('input', {class: 'sig-input', id: prefix + '-name', name: 'name', type: 'text', autocomplete: 'off', spellcheck: 'false',
      autocapitalize: 'none', maxlength: '253', value: rec ? rec.name : '', placeholder: '@', 'aria-describedby': prefix + '-name-hint'});
    var type = el('select', {class: 'sig-select', id: prefix + '-type', name: 'type'}, TYPES.map(function (x) {
      return el('option', {value: x, text: x});
    }));
    type.value = rec ? rec.type : 'A';
    var ttl = el('input', {class: 'sig-input fp-dns-num', id: prefix + '-ttl', name: 'ttl', type: 'number', inputmode: 'numeric', min: String(MIN_TTL),
      max: String(MAX_TTL), step: '1', value: String(rec ? rec.ttl : DEFAULT_TTL)});
    var prio = el('input', {class: 'sig-input fp-dns-num', id: prefix + '-priority', name: 'priority', type: 'number', inputmode: 'numeric', min: '0',
      max: '65535', step: '1', value: rec && rec.priority !== null ? String(rec.priority) : '10'});
    var content = el('input', {class: 'sig-input', id: prefix + '-content', name: 'content', type: 'text', autocomplete: 'off', spellcheck: 'false',
      autocapitalize: 'none', maxlength: '4000', value: rec ? rec.content : '', 'aria-describedby': prefix + '-content-hint'});
    var prioField = M.field(prefix + '-priority', t('dns_priority'), prio, t('dns_priority_hint'));
    var contentHint = el('span', {class: 'sig-hint', id: prefix + '-content-hint'});
    var form = el('form', {class: 'fp-form fp-dns-form' + (inline ? ' fp-mail-inline' : ' fp-mail-form'), novalidate: ''}, [
      inline ? el('h3', {class: 'fp-h3', id: prefix + '-h', text: t('dns_change_title', {name: fullName(zone, rec.name), type: rec.type})}) : null,
      M.errorLine(), inline ? null : M.statusLine(),
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: prefix + '-name', text: t('dns_name')}),
        el('div', {class: 'fp-dns-namebox'}, [name, el('span', {class: 'fp-dns-zone sig-mono', text: '.' + zone})]),
        el('span', {class: 'sig-hint', id: prefix + '-name-hint', text: t('dns_name_hint')})]),
      el('div', {class: 'fp-mail-pair'}, [M.field(prefix + '-type', t('dns_type'), type), M.field(prefix + '-ttl', t('dns_ttl'), ttl, t('dns_ttl_hint'))]),
      prioField,
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: prefix + '-content', text: t('dns_content')}), content, contentHint]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: inline ? t('dns_save') : t('dns_add')}),
        inline ? el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'close', text: t('cancel')}) : null])]);
    if (inline) { form.setAttribute('aria-labelledby', prefix + '-h'); }
    function sync() {
      prioField.hidden = !PRIORITY[type.value];
      contentHint.textContent = t('dns_hint_' + type.value.toLowerCase());
    }
    type.addEventListener('change', sync);
    sync();
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || Z.busy) { return; }
      var r = readRecord(form, zone);
      if (!r) { return; }
      var list = Z.cur.records.slice();
      var at;
      if (inline) { at = Z.open; list[at] = r; } else { at = list.length; list.push(r); }
      if (list.length > MAX_RECORDS) { M.fieldError(form, null, t('dns_too_many', {n: MAX_RECORDS})); return; }
      save(list, at, b, form, inline ? t('dns_changed_one', {name: fullName(zone, r.name), type: r.type}) :
        t('dns_added', {name: fullName(zone, r.name), type: r.type}), inline);
    });
    return form;
  }
  /* the record a form holds, in the server's shape; null (and a message on the form) when it can't be one */
  function readRecord(form, zone) {
    var get = function (n) { return form.querySelector('[name="' + n + '"]'); };
    var name = get('name').value.trim().toLowerCase().replace(/\.$/, '');
    if (name === '' || name === zone) { name = '@'; } else if (name.slice(-zone.length - 1) === '.' + zone) { name = name.slice(0, -zone.length - 1); }
    if (name !== '@' && (fullName(zone, name).length > 253 || name.split('.').some(function (l, i) { return !LABEL_RE.test(l) || (l === '*' && i > 0); }))) {
      M.fieldError(form, get('name'), t('dns_name_bad')); return null;
    }
    var type = get('type').value;
    var ttlV = get('ttl').value.trim();
    if (!/^[0-9]{1,6}$/.test(ttlV) || Number(ttlV) < MIN_TTL || Number(ttlV) > MAX_TTL) { M.fieldError(form, get('ttl'), t('dns_ttl_bad')); return null; }
    var r = {name: name, type: type, ttl: Number(ttlV), priority: null, content: ''};
    if (PRIORITY[type]) {
      var p = get('priority').value.trim();
      if (!/^[0-9]{1,5}$/.test(p) || Number(p) > 65535) { M.fieldError(form, get('priority'), t('dns_priority_bad')); return null; }
      r.priority = Number(p);
    }
    var c = get('content').value;
    c = type === 'TXT' ? c.replace(/^"(.*)"$/, '$1') : c.trim();
    if (type === 'A' && !IP4_RE.test(c)) { M.fieldError(form, get('content'), t('dns_bad_a')); return null; }
    if (type === 'AAAA' && (c.indexOf(':') < 0 || !/^[0-9a-fA-F:.]+$/.test(c))) { M.fieldError(form, get('content'), t('dns_bad_aaaa')); return null; }
    if ((type === 'CNAME' || type === 'MX' || type === 'NS') && !ZONE_RE.test(c.toLowerCase().replace(/\.$/, ''))) { M.fieldError(form, get('content'), t('dns_bad_host')); return null; }
    if (type === 'TXT' && (!c || c.length > 4000 || /[^\x20-\x7e]/.test(c))) { M.fieldError(form, get('content'), t('dns_bad_txt')); return null; }
    if (!c) { M.fieldError(form, get('content'), t('dns_content_none')); return null; }
    if ((type === 'CNAME' || type === 'NS') && name === '@') { M.fieldError(form, get('name'), t(type === 'CNAME' ? 'dns_cname_apex' : 'dns_ns_apex')); return null; }
    r.content = c;
    return r;
  }
  function wire(r) {
    var o = {name: r.name, type: r.type, ttl: r.ttl, content: r.content};
    if (r.priority !== null) { o.priority = r.priority; }
    return o;
  }
  /* the server's "record N: …" in the words of the record it is about */
  function errorText(err, list) {
    var m = /^record (\d+): (.*)$/.exec(err.message || '');
    var r = m ? list[Number(m[1]) - 1] : null;
    return r ? t('dns_record_error', {name: fullName(Z.cur.zone, r.name), type: r.type, message: m[2]}) : err.message;
  }
  /* saves the whole list; focus goes back to where the change started */
  function save(list, at, b, form, done, inline) {
    Z.busy = true;
    UI.setBusy(b, true);
    FP.call('put', 'accountZone', {serial: Z.cur.serial, records: list.map(wire)}, {name: Z.account, zone: Z.cur.zone}).then(function (r) {
      Z.busy = false;
      Z.cur = cleanZone(r);
      Z.open = -1;
      render();
      if (inline) {
        M.say(Z.page.querySelector('.fp-dns-list'), done);
        Z.page.querySelector('#fp-dns-list-h').focus();
      } else {
        M.say(Z.page.querySelector('.fp-dns-add'), done);
        Z.page.querySelector('#fp-dns-new-name').focus();
      }
    }, function (err) {
      Z.busy = false;
      if (err.status === 409) { reload(t('dns_changed')); return; }
      UI.setBusy(b, false);
      if (form) { M.fieldError(form, null, errorText(err, list)); return; }
      render();
      UI.showError(Z.page.querySelector('.fp-dns-list'), errorText(err, list));
      Z.page.querySelector('#fp-dns-list-h').focus();
    });
  }
  /* loads the zone again after it changed elsewhere, and says so */
  function reload(message) {
    var zone = Z.cur.zone;
    FP.call('get', 'accountZone', undefined, {name: Z.account, zone: zone}).then(function (r) {
      Z.cur = cleanZone(r);
      Z.open = -1;
      render();
      UI.showError(Z.page.querySelector('.fp-dns-list'), message);
      Z.page.querySelector('#fp-dns-list-h').focus();
    }, function (err) {
      Z.page.textContent = '';
      Z.page.appendChild(FP.empty(t('dns_title_zone', {zone: zone}), err.message));
    });
  }

  /* ---- cards ---- */
  function pickCard() {
    var pick = el('select', {class: 'sig-select', id: 'fp-dns-zone', name: 'zone'}, Z.zones.map(function (z) {
      return el('option', {value: z.zone, text: z.primary ? t('dns_zone_main', {zone: z.zone}) : z.zone});
    }));
    pick.value = Z.cur.zone;
    pick.addEventListener('change', function () { open(pick.value, true); });
    var parts = [M.field('fp-dns-zone', t('dns_zone'), pick)];
    if (Z.cur.nameservers.length) {
      parts.push(el('p', {class: 'fp-muted fp-dns-ns'}, [el('span', {text: t('dns_ns') + ' '}),
        el('span', {class: 'sig-mono', text: Z.cur.nameservers.join(', ')})]));
    }
    return el('section', {class: 'sig-card fp-mail-card fp-dns-pick', 'aria-label': t('dns_zone')}, [el('div', {class: 'sig-card-body'}, parts)]);
  }
  function recordRow(r, i) {
    var label = fullName(Z.cur.zone, r.name) + ' ' + r.type;
    return el('tr', {'data-fp-record': String(i)}, [
      el('th', {scope: 'row', class: 'fp-dns-name sig-mono', text: fullName(Z.cur.zone, r.name)}),
      el('td', null, [el('span', {class: 'sig-pill', text: r.type})]),
      el('td', {class: 'fp-dns-ttl', text: ttlText(r.ttl)}),
      el('td', {class: 'fp-num', text: r.priority === null ? '—' : String(r.priority)}),
      el('td', {class: 'fp-dns-content sig-mono', text: r.content}),
      el('td', {class: 'fp-mail-acts'}, Z.cur.readable ? [
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'change', 'aria-expanded': String(Z.open === i),
          'aria-label': t('dns_change_of', {record: label}), text: t('dns_change')}),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'remove',
          'aria-label': t('dns_remove_of', {record: label}), text: t('dns_remove')})] : [])]);
  }
  function listCard() {
    var head = el('div', {class: 'fp-dlv-head'}, [el('h2', {class: 'fp-h2', id: 'fp-dns-list-h', tabindex: '-1', text: t('dns_title_zone', {zone: Z.cur.zone})}),
      Z.cur.primary ? null : el('span', {class: 'fp-mail-acts fp-dns-zone-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text',
        type: 'button', 'data-fp-act': 'zone-remove', text: t('dns_zone_remove')})])]);
    var parts = [head, M.errorLine(), M.statusLine()];
    var apply = null;
    if (!Z.cur.readable) { parts.push(M.suspendedBanner(t('dns_unreadable'))); }
    if (!Z.cur.records.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('dns_no_records')}));
    } else {
      var filter = el('input', {class: 'sig-input', id: 'fp-dns-filter', type: 'search', autocomplete: 'off', spellcheck: 'false', maxlength: '253',
        value: Z.filter, 'aria-describedby': 'fp-dns-count'});
      var count = el('p', {class: 'fp-muted', id: 'fp-dns-count', role: 'status', 'aria-live': 'polite'});
      var rows = [];
      Z.cur.records.forEach(function (r, i) {
        rows.push(recordRow(r, i));
        if (Z.open === i) {
          rows.push(el('tr', {class: 'fp-mail-formrow', 'data-fp-form-for': String(i)}, [el('td', {colspan: '6'}, [recordForm('fp-dns-edit', r, true)])]));
        }
      });
      var tbody = el('tbody', null, rows);
      var none = el('p', {class: 'fp-muted', hidden: true, text: t('dns_no_match')});
      var wrap = el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-dns-list-h'}, [
        el('table', {class: 'sig-table fp-mail-table fp-dns-table'}, [el('thead', null, [el('tr', null, [
          el('th', {scope: 'col', text: t('dns_name')}), el('th', {scope: 'col', text: t('dns_type')}), el('th', {scope: 'col', text: t('dns_ttl')}),
          el('th', {scope: 'col', class: 'fp-num', text: t('dns_priority')}), el('th', {scope: 'col', text: t('dns_content')}),
          el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]), tbody])]);
      apply = function () {
        var q = filter.value.trim().toLowerCase();
        Z.filter = filter.value;
        var shown = 0;
        Z.cur.records.forEach(function (r, i) {
          var hit = !q || fullName(Z.cur.zone, r.name).indexOf(q) >= 0 || r.type.toLowerCase() === q || r.content.toLowerCase().indexOf(q) >= 0;
          var tr = tbody.querySelector('tr[data-fp-record="' + i + '"]');
          var form = tbody.querySelector('tr[data-fp-form-for="' + i + '"]');
          tr.hidden = !hit;
          if (form) { form.hidden = !hit; }
          if (hit) { shown++; }
        });
        wrap.hidden = shown === 0;
        none.hidden = shown !== 0;
        var n = Z.cur.records.length;
        count.textContent = q ? t('dns_count_filtered', {n: shown, total: n}) : t(n === 1 ? 'dns_count_1' : 'dns_count', {n: n});
      };
      filter.addEventListener('input', apply);
      filter.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && filter.value) { e.stopPropagation(); filter.value = ''; apply(); }
      });
      parts.push(el('div', {class: 'sig-field fp-zones-filter'}, [el('label', {class: 'sig-label', for: 'fp-dns-filter', text: t('dns_filter')}), filter]),
        count, wrap, none);
    }
    var card = el('section', {class: 'sig-card fp-mail-card fp-dns-list', 'aria-labelledby': 'fp-dns-list-h'}, [el('div', {class: 'sig-card-body'}, parts)]);
    if (apply) { apply(); }
    return card;
  }
  function addCard() {
    return M.card('fp-dns-add-h', t('dns_add_title'), [el('p', {class: 'fp-muted', text: t('dns_add_desc')}), recordForm('fp-dns-new', null, false)], 'fp-dns-add');
  }
  function spareCard() {
    var pick = el('select', {class: 'sig-select', id: 'fp-dns-spare', name: 'zone'}, Z.spare.map(function (d) { return el('option', {value: d, text: d}); }));
    var form = el('form', {class: 'fp-form fp-mail-form', novalidate: ''}, [M.errorLine(), M.statusLine(), M.field('fp-dns-spare', t('dns_spare_domain'), pick),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary fp-submit', type: 'submit', text: t('dns_spare_add')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var zone = pick.value;
      UI.setBusy(b, true);
      FP.call('post', 'accountZones', {zone: zone}, Z.account).then(function (r) {
        Z.zones.push({zone: zone, primary: false});
        Z.zones = cleanZones({zones: Z.zones});
        Z.spare = Z.spare.filter(function (d) { return d !== zone && d.slice(-zone.length - 1) !== '.' + zone; });
        Z.cur = cleanZone(r);
        Z.open = -1;
        Z.filter = '';
        render();
        M.say(Z.page.querySelector('.fp-dns-list'), t('dns_spare_added', {zone: zone}));
        Z.page.querySelector('#fp-dns-list-h').focus();
      }, function (err) {
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return M.card('fp-dns-spare-h', t('dns_spare_title'), [el('p', {class: 'fp-muted', text: t('dns_spare_desc')}), form], 'fp-dns-spare');
  }
  function render() {
    Z.page.textContent = '';
    if (Z.cur) {
      Z.page.appendChild(pickCard());
      Z.page.appendChild(listCard());
      if (Z.cur.readable) { Z.page.appendChild(addCard()); }
    } else {
      Z.page.appendChild(FP.empty(t('dns_none_title'), t('dns_none')));
    }
    if (Z.spare.length) { Z.page.appendChild(spareCard()); }
  }
  /* shows a zone; focus stays on the zone list when the customer picked it there */
  function open(zone, fromPick) {
    var mine = Z.page;
    var pick = Z.page.querySelector('#fp-dns-zone');
    if (pick) { pick.disabled = true; }
    return FP.call('get', 'accountZone', undefined, {name: Z.account, zone: zone}).then(function (r) {
      if (Z.page !== mine) { return; }
      Z.cur = cleanZone(r);
      Z.open = -1;
      Z.filter = '';
      render();
      if (fromPick) { Z.page.querySelector('#fp-dns-zone').focus(); }
    }, function (err) {
      if (Z.page !== mine) { return; }
      if (pick) { pick.disabled = false; pick.value = Z.cur ? Z.cur.zone : zone; }
      var list = Z.page.querySelector('.fp-dns-list');
      if (list) { UI.showError(list, err.message); } else { Z.page.textContent = ''; Z.page.appendChild(FP.empty(t('dns_title_zone', {zone: zone}), err.message)); }
    });
  }
  function focusRecord(i, act) {
    var b = Z.page.querySelector('tr[data-fp-record="' + i + '"] [data-fp-act="' + act + '"]');
    if (b) { b.focus(); }
  }

  document.addEventListener('click', function (e) {
    var target = e.target.closest ? e.target : null;
    var b = target && target.closest('[data-fp-act]');
    if (!b || !Z.page || !Z.page.contains(b)) { return; }
    var a = b.getAttribute('data-fp-act');
    var tr = b.closest('tr[data-fp-record]');
    var i = tr ? Number(tr.getAttribute('data-fp-record')) : -1;
    if (a === 'change') {
      Z.open = Z.open === i ? -1 : i;
      render();
      if (Z.open >= 0) { Z.page.querySelector('#fp-dns-edit-name').focus(); } else { focusRecord(i, 'change'); }
    } else if (a === 'close') {
      var was = Z.open;
      Z.open = -1;
      render();
      focusRecord(was, 'change');
    } else if (a === 'remove') {
      var r = Z.cur.records[i];
      M.confirmIn(tr.querySelector('.fp-mail-acts'), t('dns_remove_ask', {name: fullName(Z.cur.zone, r.name), type: r.type}), 'remove-yes', t('dns_remove'));
    } else if (a === 'confirm-no') {
      render();
      if (i >= 0) { focusRecord(i, 'remove'); } else { Z.page.querySelector('[data-fp-act="zone-remove"]').focus(); }
    } else if (a === 'remove-yes' && !Z.busy) {
      var gone = Z.cur.records[i];
      var list = Z.cur.records.filter(function (x, j) { return j !== i; });
      save(list, -1, b, null, t('dns_removed', {name: fullName(Z.cur.zone, gone.name), type: gone.type}), true);
    } else if (a === 'zone-remove') {
      M.confirmIn(b.parentNode, t('dns_zone_remove_ask', {zone: Z.cur.zone}), 'zone-remove-yes', t('dns_zone_remove'));
    } else if (a === 'zone-remove-yes') {
      var zone = Z.cur.zone;
      UI.setBusy(b, true);
      FP.call('del', 'accountZone', undefined, {name: Z.account, zone: zone}).then(function () {
        Z.zones = Z.zones.filter(function (z) { return z.zone !== zone; });
        Z.spare = Z.spare.concat([zone]).sort();
        var next = Z.zones[0];
        if (!next) { Z.cur = null; render(); return; }
        open(next.zone, false).then(function () {
          var list = Z.page.querySelector('.fp-dns-list');
          if (list) { M.say(list, t('dns_zone_removed', {zone: zone})); Z.page.querySelector('#fp-dns-zone').focus(); }
        });
      }, function (err) {
        render();
        UI.showError(Z.page.querySelector('.fp-dns-list'), err.message);
        Z.page.querySelector('[data-fp-act="zone-remove"]').focus();
      });
    }
  });

  FP.view('tool:dns', function () {
    Z.page = null;
    var tool = FP.tools.dns;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('dns_desc'), cls: 'fp-mail fp-dns',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    Z.page = body;
    Z.account = FP.account();
    Z.cur = null;
    Z.open = -1;
    Z.filter = '';
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all([FP.call('get', 'accountZones', undefined, Z.account),
      FP.call('get', 'domains', undefined, Z.account).then(function (r) { return r && r.sites; }, function () { return null; })]).then(function (r) {
      if (Z.page !== body) { return; }
      Z.zones = cleanZones(r[0]);
      Z.spare = zoneless(r[1], Z.zones);
      if (!Z.zones.length) { render(); return; }
      open(Z.zones[0].zone, false);
    }, function (err) {
      if (Z.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

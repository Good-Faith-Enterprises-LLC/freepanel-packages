/* freePanel's Reseller panel address page of the administrators' panel (#/tool/reseller_domain; docs/api.md, "Resellers: a reseller's own
   panel address"): the name, such as panel.example.com, on which a reseller's customers reach their customer panel and the reseller's store,
   with the reseller's own sign-in page there and a free certificate of its own. The name must be one of the reseller's accounts' proven domains
   or a name under one; the admin works on any reseller, a reseller on itself. What the server sends is drawn as text. The page pieces come from
   FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var USER_RE = /^[a-z][a-z0-9]{0,15}$/;
  /* a host name as the server takes it: letters, digits and hyphens in labels, at least two labels */
  var NAME_RE = /^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var STATES = {active: true, pending: true, unavailable: true};
  var P = {page: null, who: '', view: null, names: []};

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function isAdmin() { return FP.session.user.role === 'admin'; }
  function httpsUrl(u) { return /^https:\/\/[^\s"'<>]+$/.test(u) ? u : ''; }
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var c = r.certificate && typeof r.certificate === 'object' ? r.certificate : null;
    var name = str(r.domain, 253).toLowerCase();
    return {
      domain: NAME_RE.test(name) ? name : '', live: r.live === true, setBy: USER_RE.test(str(r.set_by, 20)) ? r.set_by : '',
      setAt: str(r.set_at, 40), url: httpsUrl(str(r.url, 300)), storeUrl: httpsUrl(str(r.store_url, 300)),
      cert: c ? {state: STATES[c.state] ? c.state : 'pending', reason: str(c.reason, 300), notAfter: str(c.not_after, 40), lastError: str(c.last_error, 500)} : null
    };
  }
  function frame() {
    var tool = FP.tools.reseller_domain;
    if (!tool || FP.realm !== 'admin') { FP.views['not-found']({view: 'not-found'}); return null; }
    var g = FP.group(tool.group);
    return FP.frame({title: tool.label, desc: t('reseller_domain_desc' + (isAdmin() ? '' : '_reseller')), cls: 'fp-mail fp-rp fp-rd',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
  }
  function resellers() {
    return FP.call('get', 'resellers').then(function (r) {
      return (r && Array.isArray(r.resellers) ? r.resellers : []).map(function (x) { return str(x && x.username, 20); })
        .filter(function (n) { return USER_RE.test(n); }).sort();
    });
  }
  function picker(names, current) {
    var select = el('select', {class: 'sig-select', id: 'fp-rd-pick', name: 'reseller'}, names.map(function (n) {
      return el('option', {value: n, selected: n === current ? true : null, text: n});
    }));
    select.addEventListener('change', function () { load(select.value); });
    return M.card('fp-rd-pick-h', t('rp_pick_title'), [M.field('fp-rd-pick', t('rp_pick'), select, t('rp_pick_hint'))], 'fp-rp-pick');
  }
  function day(iso) {
    var d = new Date(iso);
    return isNaN(d.getTime()) ? '' : d.toISOString().slice(0, 10);
  }

  function noteCard() {
    return M.card('fp-rd-note-h', t('rpd_note_title'), [
      el('p', {class: 'fp-muted', text: t(isAdmin() ? 'rpd_what_admin' : 'rpd_what', {name: P.who})}),
      el('p', {class: 'fp-muted', text: t('rpd_rule')})], 'fp-rd-note');
  }
  function formCard() {
    var input = el('input', {class: 'sig-input sig-mono', id: 'fp-rd-name', name: 'domain', type: 'text', inputmode: 'url', maxlength: '253', autocomplete: 'off',
      spellcheck: 'false', autocapitalize: 'none', value: P.view.domain, placeholder: 'panel.example.com'});
    var acts = [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('rpd_save')})];
    if (P.view.domain) {
      acts.push(el('span', {class: 'fp-mail-acts fp-rd-remove'}, [el('button', {class: 'sig-btn sig-btn--secondary fp-btn-danger-text', type: 'button',
        'data-fp-act': 'rd-clear', text: t('rpd_clear')})]));
    }
    var form = el('form', {class: 'fp-form fp-mail-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-rd-name', t('rpd_name'), input, t('rpd_name_hint')), el('div', {class: 'fp-actions'}, acts)]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var name = input.value.trim().toLowerCase().replace(/\.$/, '');
      if (!name) { M.fieldError(form, input, t('rpd_name_none')); return; }
      if (!NAME_RE.test(name)) { M.fieldError(form, input, t('rpd_name_bad')); return; }
      UI.setBusy(b, true);
      FP.call('put', 'resellerPanelDomain', {domain: name}, P.who).then(function (r) {
        P.view = clean(r);
        render();
        M.say(P.page.querySelector('.fp-rd-form'), t('rpd_saved', {name: P.view.domain}));
        P.page.querySelector('#fp-rd-form-h').focus();
      }, function (err) {
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return M.card('fp-rd-form-h', t('rpd_form_title'), [form], 'fp-rd-form');
  }
  function pill(state) {
    var cls = state === 'active' ? ' sig-pill--ok' : ' sig-pill--warn';
    return el('span', {class: 'sig-pill' + cls, 'data-fp-cert': state, text: t('rpd_cert_' + state)});
  }
  function link(u) {
    return u ? el('a', {class: 'sig-mono', href: u, target: '_blank', rel: 'noopener noreferrer', text: u}) : document.createTextNode(t('rpd_none'));
  }
  function statusCard() {
    var v = P.view;
    if (!v.domain) {
      return M.card('fp-rd-state-h', t('rpd_state_title'), [el('p', {class: 'fp-muted', 'data-fp-none': '', text: t(isAdmin() ? 'rpd_unset_admin' : 'rpd_unset', {name: P.who})})], 'fp-rd-state');
    }
    var rows = [
      el('dt', {class: 'fp-rp-k', text: t('rpd_name')}), el('dd', {class: 'fp-rp-v sig-mono', text: v.domain}),
      el('dt', {class: 'fp-rp-k', text: t('rpd_answers')}), el('dd', {class: 'fp-rp-v'}, [el('span', {class: 'sig-pill' + (v.live ? ' sig-pill--ok' : ' sig-pill--warn'),
        'data-fp-live': v.live ? 'yes' : 'no', text: t(v.live ? 'rpd_live' : 'rpd_dead')})]),
      el('dt', {class: 'fp-rp-k', text: t('rpd_panel_link')}), el('dd', {class: 'fp-rp-v'}, [link(v.url)]),
      el('dt', {class: 'fp-rp-k', text: t('rpd_store_link')}), el('dd', {class: 'fp-rp-v'}, [link(v.storeUrl)])
    ];
    if (v.cert) {
      rows.push(el('dt', {class: 'fp-rp-k', text: t('rpd_cert')}), el('dd', {class: 'fp-rp-v'}, [pill(v.cert.state)]));
      if (v.cert.state === 'active' && day(v.cert.notAfter)) {
        rows.push(el('dt', {class: 'fp-rp-k', text: t('rpd_cert_until')}), el('dd', {class: 'fp-rp-v', text: day(v.cert.notAfter)}));
      }
      if (v.cert.reason) { rows.push(el('dt', {class: 'fp-rp-k', text: t('rpd_cert_why')}), el('dd', {class: 'fp-rp-v', 'data-fp-reason': '', text: v.cert.reason})); }
      if (v.cert.lastError) { rows.push(el('dt', {class: 'fp-rp-k', text: t('rpd_cert_error')}), el('dd', {class: 'fp-rp-v', 'data-fp-last-error': '', text: v.cert.lastError})); }
    }
    if (v.setBy) { rows.push(el('dt', {class: 'fp-rp-k', text: t('rpd_set_by')}), el('dd', {class: 'fp-rp-v', text: v.setBy + (day(v.setAt) ? ', ' + day(v.setAt) : '')})); }
    var parts = [el('dl', {class: 'fp-rp-vals'}, rows)];
    if (!v.live) { parts.push(el('p', {class: 'fp-warn-line', 'data-fp-dead': '', text: t('rpd_dead_note')})); }
    return M.card('fp-rd-state-h', t('rpd_state_title'), parts, 'fp-rd-state');
  }
  function dnsCard() {
    return M.card('fp-rd-dns-h', t('rpd_dns_title'), [el('p', {class: 'fp-muted', text: t('rpd_dns', {name: P.view.domain || 'panel.example.com'})}),
      el('p', {class: 'fp-muted', text: t('rpd_dns_cert')})], 'fp-rd-dns');
  }
  function render() {
    P.page.textContent = '';
    if (isAdmin()) { P.page.appendChild(picker(P.names, P.who)); }
    P.page.appendChild(noteCard());
    P.page.appendChild(formCard());
    P.page.appendChild(statusCard());
    P.page.appendChild(dnsCard());
  }
  function fail(body, err) {
    body.textContent = '';
    body.appendChild(FP.empty(FP.tools.reseller_domain.label, err.message));
  }
  function load(who) {
    var page = P.page;
    P.who = who;
    FP.call('get', 'resellerPanelDomain', undefined, who).then(function (r) {
      if (P.page !== page || P.who !== who) { return; }
      P.view = clean(r);
      render();
      var sel = P.page.querySelector('#fp-rd-pick');
      if (sel && document.activeElement && document.activeElement.id === 'fp-rd-pick') { sel.focus(); }
    }, function (err) {
      if (P.page !== page || P.who !== who) { return; }
      fail(page, err);
    });
  }
  FP.view('tool:reseller_domain', function () {
    P.page = null;
    var body = frame();
    if (!body) { return; }
    P.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    if (!isAdmin()) { load(FP.account()); return; }
    resellers().then(function (names) {
      if (P.page !== body) { return; }
      P.names = names;
      if (!names.length) {
        body.textContent = '';
        body.appendChild(M.card('fp-rp-none-h', t('rp_none_title'), [el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('rp_none')})], 'fp-rp-none'));
        return;
      }
      load(names[0]);
    }, function (err) {
      if (P.page !== body) { return; }
      fail(body, err);
    });
  });

  document.addEventListener('click', function (e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !P.page || !P.page.contains(b)) { return; }
    var a = b.getAttribute('data-fp-act');
    if (a === 'rd-clear') {
      M.confirmIn(b.parentNode, t(isAdmin() ? 'rpd_clear_ask_admin' : 'rpd_clear_ask', {name: P.who, domain: P.view.domain}), 'rd-clear-yes', t('rpd_clear'));
    } else if (a === 'confirm-no' && b.closest('.fp-rd-remove')) {
      render();
      P.page.querySelector('[data-fp-act="rd-clear"]').focus();
    } else if (a === 'rd-clear-yes') {
      UI.setBusy(b, true);
      FP.call('del', 'resellerPanelDomain', undefined, P.who).then(function () {
        P.view = clean({});
        render();
        M.say(P.page.querySelector('.fp-rd-form'), t('rpd_cleared'));
        P.page.querySelector('#fp-rd-form-h').focus();
      }, function (err) {
        render();
        UI.showError(P.page.querySelector('.fp-rd-form'), err.message);
        P.page.querySelector('[data-fp-act="rd-clear"]').focus();
      });
    }
  });
})();

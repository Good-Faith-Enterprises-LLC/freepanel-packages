/* freePanel domains (docs/api.md, "Domains and sites"): the customer panel's Domains (#/tool/domains) and Subdomains
   (#/tool/subdomains) pages. A domain is either a website of its own, with its own folder, or another name for one of
   the account's websites; a subdomain is a website of its own under one of the account's names. Every change answers
   with the whole list again. Removing a website is one request; the server gives back its other names with it. A name
   a customer adds awaits proof that they control it (docs/domain-proof.md) while the host has that check on: the lists
   mark it, and the Domains page shows the TXT record that proves it and a button to look for it now. The page pieces
   come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var DOMAIN_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var LABELS_RE = /^([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*$/;
  var DIR_RE = /^[A-Za-z0-9_][A-Za-z0-9_.-]{0,127}$/;
  var RESERVED = ['etc', 'mail', 'tmp', 'logs', 'ssl', 'access-logs', 'perl5', 'cache', 'backups'];

  function str(v) { return typeof v === 'string' ? v : ''; }
  /* the server says "sub" in lists and takes "subdomain" in a POST; either reads as a subdomain */
  function kindOf(k) { return k === 'main' || k === 'addon' ? k : (k === 'sub' || k === 'subdomain' ? 'sub' : ''); }
  var ORDER = {main: 0, addon: 1, sub: 2};
  function clean(v) {
    v = v && typeof v === 'object' ? v : {};
    var sites = (Array.isArray(v.sites) ? v.sites : []).filter(function (s) {
      return s && DOMAIN_RE.test(str(s.domain)) && kindOf(s.kind);
    }).map(function (s) {
      return {domain: s.domain, kind: kindOf(s.kind), docroot: str(s.docroot), problem: str(s.problem).slice(0, 300),
        aliases: (Array.isArray(s.aliases) ? s.aliases : []).filter(function (a) { return DOMAIN_RE.test(str(a)); }).sort()};
    }).sort(function (a, b) { return ORDER[a.kind] - ORDER[b.kind] || (a.domain < b.domain ? -1 : 1); });
    var main = sites.filter(function (s) { return s.kind === 'main'; })[0];
    var home = main && /^\/.+\/public_html$/.test(main.docroot) ? main.docroot.slice(0, -'/public_html'.length) : '';
    return {suspended: v.suspended === true, sites: sites, home: home};
  }
  /* the account's proof of control (GET /accounts/{u}/domain-proof): whether the check is on, and each name's state */
  function cleanProof(v) {
    v = v && typeof v === 'object' ? v : {};
    var out = {on: v.proof_on === true, names: {}};
    (Array.isArray(v.domains) ? v.domains : []).forEach(function (d) {
      if (!d || !DOMAIN_RE.test(str(d.name))) { return; }
      var rec = d.record && typeof d.record === 'object' ? d.record : {};
      out.names[d.name] = {name: d.name, verified: d.verified === true, checked: str(d.checked_at), note: str(d.note).slice(0, 300),
        record: {name: str(rec.name).slice(0, 300), type: str(rec.type).slice(0, 16), value: str(rec.value).slice(0, 300)}};
    });
    return out;
  }
  /* null when the account's proof can't be read: the pages then show nothing about it */
  function fetchProof(account) {
    return FP.call('get', 'domainProof', undefined, account).then(cleanProof, function () { return null; });
  }
  function awaiting(P, name) {
    var n = P.proof && P.proof.on ? P.proof.names[name] : null;
    return Boolean(n && !n.verified);
  }
  function pendingNames(P) {
    if (!P.proof || !P.proof.on) { return []; }
    return Object.keys(P.proof.names).filter(function (n) { return !P.proof.names[n].verified; }).sort();
  }
  function when(iso) {
    var d = iso ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString(undefined, {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }
  /* a row's name, marked while it awaits proof */
  function nameCell(P, name, extra) {
    return el('th', {scope: 'row', class: 'fp-mail-name'}, [el('span', {text: name}),
      awaiting(P, name) ? el('span', {class: 'sig-pill sig-pill--warn fp-proof-pill', text: t('dom_proof_pill')}) : null, extra || null]);
  }
  /* a site's folder as the customer sees it in their home */
  function folderOf(state, docroot) {
    return state.home && docroot.indexOf(state.home + '/') === 0 ? docroot.slice(state.home.length + 1) : docroot;
  }
  /* a folder typed into a form: '' when left empty, null (and a message on the form) when it can't be one */
  function readFolder(form) {
    var f = form.querySelector('[name="docroot"]');
    if (!f) { return ''; }
    var v = f.value.trim().replace(/^\/+|\/+$/g, '');
    if (!v) { return ''; }
    var parts = v.split('/');
    if (parts.length > 2 || parts.some(function (p) { return !DIR_RE.test(p); })) { M.fieldError(form, f, t('dom_folder_bad')); return null; }
    if (RESERVED.indexOf(parts[0]) >= 0) { M.fieldError(form, f, t('dom_folder_reserved', {folder: parts[0]})); return null; }
    return v;
  }
  function readDomain(v) {
    v = v.trim().toLowerCase().replace(/\.$/, '');
    return DOMAIN_RE.test(v) ? v : '';
  }
  function folderField(id, state, hint) {
    var input = el('input', {class: 'sig-input', id: id, name: 'docroot', type: 'text', autocomplete: 'off', spellcheck: 'false',
      autocapitalize: 'none', maxlength: '257', 'aria-describedby': id + '-hint'});
    return el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: id, text: t('dom_folder')}),
      el('div', {class: 'fp-dom-path'}, [state.home ? el('span', {class: 'fp-dom-home sig-mono', text: state.home + '/'}) : null, input]),
      el('span', {class: 'sig-hint', id: id + '-hint', text: hint})]);
  }
  /* the folder cell of a row, with the server's word when the site can't be served as set up */
  function folderCell(state, s) {
    return el('td', {class: 'fp-dom-folder'}, [el('span', {class: 'sig-mono', text: folderOf(state, s.docroot) || '—'}),
      s.problem ? el('span', {class: 'fp-dom-problem'}, [el('span', {class: 'sig-pill sig-pill--warn', text: t('dom_problem')}),
        el('span', {class: 'fp-muted fp-row-note', text: s.problem})]) : null]);
  }
  function frame(id, cls) {
    var tool = FP.tools[id];
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return null; }
    var g = FP.group(tool.group);
    return FP.frame({title: tool.label, desc: t(id + '_desc'), cls: 'fp-mail fp-dom ' + cls,
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
  }
  function actsCell(name, labelKey) {
    return el('td', {class: 'fp-mail-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button',
      'data-fp-act': 'remove', 'aria-label': t(labelKey, {domain: name}), text: t('dom_remove')})]);
  }
  /* removes a name; the server releases a website's other names with it. Resolves with the new list, or rejects with
     the error and the list as the server has it then */
  function removeName(P, name) {
    return FP.call('del', 'domain', undefined, {name: P.account, domain: name}).then(function (r) {
      return withProof(P, r);
    }, function (err) {
      return FP.call('get', 'domains', undefined, P.account).then(function (r) {
        return withProof(P, r).then(function () { throw {err: err, list: r}; });
      }, function () { throw {err: err, list: null}; });
    });
  }
  /* reads the account's proof again after a change, then resolves with r */
  function withProof(P, r) {
    return fetchProof(P.account).then(function (pr) {
      if (pr) { P.proof = pr; }
      return r;
    });
  }
  function askRemove(P, tr, name) {
    var site = P.state.sites.filter(function (s) { return s.domain === name; })[0];
    var q;
    if (!site) {
      q = t('dom_remove_ask_alias', {domain: name});
    } else if (site.aliases.length) {
      q = t('dom_remove_ask_names', {domain: name, names: site.aliases.join(', '), folder: folderOf(P.state, site.docroot)});
    } else {
      q = t('dom_remove_ask', {domain: name, folder: folderOf(P.state, site.docroot)});
    }
    M.confirmIn(tr.querySelector('.fp-mail-acts'), q, 'remove-yes', t('dom_remove'));
  }
  function focusRow(P, name, act) {
    var b = P.page.querySelector('tr[data-fp-domain="' + window.CSS.escape(name) + '"] [data-fp-act="' + act + '"]');
    if (b) { b.focus(); }
  }
  /* a row's Remove, its question and the answer, the same on both pages */
  function rowClick(P, b, a, tr, listSel, headId) {
    var name = tr ? tr.getAttribute('data-fp-domain') : '';
    if (a === 'remove') {
      askRemove(P, tr, name);
    } else if (a === 'confirm-no') {
      P.render();
      focusRow(P, name, 'remove');
    } else if (a === 'remove-yes') {
      UI.setBusy(b, true);
      removeName(P, name).then(function (r) {
        P.state = clean(r);
        P.render();
        M.say(P.page.querySelector(listSel), t('dom_removed', {domain: name}));
        P.page.querySelector('#' + headId).focus();
      }, function (x) {
        if (x.list) { P.state = clean(x.list); }
        P.render();
        UI.showError(P.page.querySelector(listSel), x.err.message);
        if (P.page.querySelector('tr[data-fp-domain="' + window.CSS.escape(name) + '"]')) { focusRow(P, name, 'remove'); } else { P.page.querySelector('#' + headId).focus(); }
      });
    }
  }

  /* ================= Domains ================= */
  var D = {page: null, state: null, proof: null, account: '', render: null};

  function dAddCard() {
    var sites = D.state.sites;
    var name = el('input', {class: 'sig-input', id: 'fp-dom-name', name: 'domain', type: 'text', inputmode: 'url', autocomplete: 'off',
      spellcheck: 'false', autocapitalize: 'none', maxlength: '253', placeholder: 'example.com'});
    var own = el('input', {type: 'radio', id: 'fp-dom-own', name: 'kind', value: 'addon', checked: ''});
    var same = el('input', {type: 'radio', id: 'fp-dom-same', name: 'kind', value: 'alias'});
    var site = el('select', {class: 'sig-select', id: 'fp-dom-site', name: 'site'}, sites.map(function (s) {
      return el('option', {value: s.domain, text: s.domain});
    }));
    var siteField = M.field('fp-dom-site', t('dom_same_as'), site);
    var folder = folderField('fp-dom-folder', D.state, t('dom_folder_hint'));
    var form = el('form', {class: 'fp-form fp-mail-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-dom-name', t('dom_name'), name, t('dom_name_hint')),
      el('fieldset', {class: 'fp-dom-kind'}, [el('legend', {class: 'sig-label', text: t('dom_kind')}),
        el('label', {class: 'fp-check', for: 'fp-dom-own'}, [own, el('span', {text: t('dom_kind_own')})]),
        el('label', {class: 'fp-check', for: 'fp-dom-same'}, [same, el('span', {text: t('dom_kind_same')})])]),
      folder, siteField,
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('dom_add')})])]);
    function sync() {
      folder.hidden = same.checked;
      siteField.hidden = !same.checked;
      var d = readDomain(name.value);
      folder.querySelector('input').setAttribute('placeholder', d || t('dom_folder_placeholder'));
    }
    form.addEventListener('change', sync);
    name.addEventListener('input', sync);
    sync();
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var d = readDomain(name.value);
      if (!d) { M.fieldError(form, name, t('dom_name_bad')); return; }
      var body = {domain: d, kind: same.checked ? 'alias' : 'addon'};
      if (same.checked) {
        body.site = site.value;
      } else {
        var f = readFolder(form);
        if (f === null) { return; }
        if (f) { body.docroot = f; }
      }
      UI.setBusy(b, true);
      FP.call('post', 'domains', body, D.account).then(function (r) {
        return withProof(D, r);
      }).then(function (r) {
        D.state = clean(r);
        D.render();
        var added = D.state.sites.filter(function (s) { return s.domain === d; })[0];
        M.say(D.page.querySelector('.fp-dom-add'), (same.checked ? t('dom_added_same', {domain: d, site: body.site}) :
          t('dom_added_own', {domain: d, folder: added ? folderOf(D.state, added.docroot) : (body.docroot || d)})) +
          (awaiting(D, d) ? ' ' + t('dom_added_proof') : ''));
        D.page.querySelector('#fp-dom-name').focus();
      }, function (err) {
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return M.card('fp-dom-add-h', t('dom_add_title'), [el('p', {class: 'fp-muted', text: t('dom_add_desc')}), form], 'fp-dom-add');
  }
  function dKind(s) {
    return s.kind === 'main' ? el('span', {class: 'sig-pill sig-pill--accent', text: t('dom_kind_main')}) : el('span', {text: t('dom_kind_own_short')});
  }
  function dListCard() {
    var parts = [M.errorLine(), M.statusLine()];
    var rows = [];
    D.state.sites.forEach(function (s) {
      if (s.kind === 'sub') { return; }
      rows.push(el('tr', {'data-fp-domain': s.domain}, [nameCell(D, s.domain),
        el('td', null, [dKind(s)]), folderCell(D.state, s), s.kind === 'main' ? el('td', {class: 'fp-mail-acts'}) : actsCell(s.domain, 'dom_remove_of')]));
      s.aliases.forEach(function (a) {
        rows.push(el('tr', {'data-fp-domain': a}, [nameCell(D, a),
          el('td', {text: t('dom_kind_same_as', {site: s.domain})}),
          el('td', {class: 'fp-dom-folder'}, [el('span', {class: 'sig-mono', text: folderOf(D.state, s.docroot) || '—'})]),
          actsCell(a, 'dom_remove_of')]));
      });
    });
    parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-dom-list-h'}, [
      el('table', {class: 'sig-table fp-mail-table fp-dom-table'}, [el('thead', null, [el('tr', null, [
        el('th', {scope: 'col', text: t('dom_name')}), el('th', {scope: 'col', text: t('dom_kind_col')}),
        el('th', {scope: 'col', text: t('dom_folder')}), el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]),
      el('tbody', null, rows)])]));
    return M.card('fp-dom-list-h', t('dom_list_title'), parts, 'fp-dom-list');
  }
  /* the names awaiting proof, each with the record that proves it and a button to look for it now */
  function proofCard() {
    var names = pendingNames(D);
    if (!names.length) { return null; }
    function val(label, text, copyLabel) {
      return [el('span', {class: 'fp-dlv-k', text: label}), el('span', {class: 'fp-proof-val'}, [el('code', {class: 'sig-mono fp-dlv-v', text: text || '—'}),
        text && copyLabel ? el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'proof-copy',
          'data-fp-copy': text, 'aria-label': copyLabel, text: t('dom_proof_copy')}) : null])];
    }
    return M.card('fp-proof-h', t('dom_proof_title'), [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t('dom_proof_desc')}),
      el('dl', {class: 'fp-dlv-list'}, names.map(function (name) {
        var n = D.proof.names[name];
        var seen = n.checked ? t('dom_proof_checked', {when: when(n.checked) || n.checked}) : t('dom_proof_never');
        return el('div', {class: 'fp-dlv-item', 'data-fp-proof': name}, [
          el('dt', {class: 'fp-dlv-name'}, [el('span', {class: 'fp-dlv-label', text: name}),
            el('span', {class: 'sig-pill sig-pill--warn', text: t('dom_proof_pill')})]),
          el('dd', {class: 'fp-dlv-detail'}, [el('p', {class: 'fp-muted fp-dlv-what', text: seen}),
            n.note ? el('p', {class: 'fp-dlv-what fp-proof-note', text: n.note}) : null,
            el('div', {class: 'fp-dlv-vals'}, val(t('dom_proof_rec_name'), n.record.name, t('dom_proof_copy_name', {domain: name}))
              .concat(val(t('dom_proof_rec_type'), n.record.type))
              .concat(val(t('dom_proof_rec_value'), n.record.value, t('dom_proof_copy_value', {domain: name})))),
            el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary sig-btn--sm', type: 'button', 'data-fp-act': 'proof-check',
              'aria-label': t('dom_proof_check_of', {domain: name}), text: t('dom_proof_check')})])])]);
      }))], 'fp-proof');
  }
  function focusProof(name) {
    var b = D.page.querySelector('[data-fp-proof="' + window.CSS.escape(name) + '"] [data-fp-act="proof-check"]');
    if (b) { b.focus(); }
  }
  /* looks for a name's record now: a proven name leaves the list, one still waiting shows why */
  function proofCheck(b) {
    var name = b.closest('[data-fp-proof]').getAttribute('data-fp-proof');
    var cardNode = D.page.querySelector('.fp-proof');
    UI.showError(cardNode, '');
    M.say(cardNode, '');
    UI.setBusy(b, true);
    FP.call('post', 'domainCheck', undefined, {name: D.account, domain: name}).then(function (d) {
      var ok = Boolean(d && d.verified === true);
      return FP.call('get', 'domains', undefined, D.account).then(function (r) { D.state = clean(r); }, function () {}).then(function () {
        return withProof(D);
      }).then(function () {
        D.render();
        var c = D.page.querySelector('.fp-proof');
        if (ok || !c) {
          var where = c || D.page.querySelector('.fp-dom-list');
          M.say(where, t('dom_proof_ok', {domain: name}));
          where.querySelector('h2').focus();
        } else {
          M.say(c, t('dom_proof_not_yet', {domain: name}));
          focusProof(name);
        }
      });
    }, function (err) {
      UI.setBusy(b, false);
      UI.showError(cardNode, err.message);
      b.focus();
    });
  }
  function proofCopy(b) {
    var cardNode = b.closest('.fp-proof');
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(b.getAttribute('data-fp-copy')).then(function () { M.say(cardNode, t('copied')); }, function () { M.say(cardNode, t('copy_failed')); });
    } else {
      M.say(cardNode, t('copy_failed'));
    }
  }
  D.render = function () {
    D.page.textContent = '';
    if (D.state.suspended) { D.page.appendChild(M.suspendedBanner(t('dom_suspended'))); }
    D.page.appendChild(dAddCard());
    var proof = proofCard();
    if (proof) { D.page.appendChild(proof); }
    D.page.appendChild(dListCard());
  };

  /* ================= Subdomains ================= */
  var S = {page: null, state: null, proof: null, account: '', render: null};

  function sAddCard() {
    var label = el('input', {class: 'sig-input', id: 'fp-sub-name', name: 'label', type: 'text', autocomplete: 'off', spellcheck: 'false',
      autocapitalize: 'none', maxlength: '200', placeholder: 'blog', 'aria-describedby': 'fp-sub-name-hint'});
    var parent = el('select', {class: 'sig-select', id: 'fp-sub-parent', name: 'parent', 'aria-label': t('sub_parent')}, S.state.sites.map(function (s) {
      return el('option', {value: s.domain, text: s.domain});
    }));
    var folder = folderField('fp-sub-folder', S.state, t('sub_folder_hint'));
    var form = el('form', {class: 'fp-form fp-mail-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: 'fp-sub-name', text: t('sub_name')}),
        el('div', {class: 'fp-mail-addr'}, [label, el('span', {class: 'fp-mail-at', 'aria-hidden': 'true', text: '.'}), parent]),
        el('span', {class: 'sig-hint', id: 'fp-sub-name-hint', text: t('sub_name_hint')})]),
      folder,
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('sub_add')})])]);
    function sync() { folder.querySelector('input').setAttribute('placeholder', full() || t('dom_folder_placeholder')); }
    function full() {
      var l = label.value.trim().toLowerCase().replace(/\.+$/, '');
      return LABELS_RE.test(l) && DOMAIN_RE.test(l + '.' + parent.value) ? l + '.' + parent.value : '';
    }
    label.addEventListener('input', sync);
    parent.addEventListener('change', sync);
    sync();
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var d = full();
      if (!d) { M.fieldError(form, label, t('sub_name_bad')); return; }
      var body = {domain: d, kind: 'subdomain'};
      var f = readFolder(form);
      if (f === null) { return; }
      if (f) { body.docroot = f; }
      UI.setBusy(b, true);
      FP.call('post', 'domains', body, S.account).then(function (r) {
        return withProof(S, r);
      }).then(function (r) {
        S.state = clean(r);
        S.render();
        var added = S.state.sites.filter(function (s) { return s.domain === d; })[0];
        M.say(S.page.querySelector('.fp-sub-add'), t('dom_added_own', {domain: d, folder: added ? folderOf(S.state, added.docroot) : (body.docroot || d)}) +
          (awaiting(S, d) ? ' ' + t('sub_added_proof') : ''));
        S.page.querySelector('#fp-sub-name').focus();
      }, function (err) {
        UI.setBusy(b, false);
        M.failed(form, err.field === 'domain' ? {field: 'label', message: err.message} : err);
      });
    });
    return M.card('fp-sub-add-h', t('sub_add_title'), [form], 'fp-sub-add');
  }
  function sListCard() {
    var parts = [M.errorLine(), M.statusLine()];
    var subs = S.state.sites.filter(function (s) { return s.kind === 'sub'; });
    if (!subs.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('sub_none')}));
    } else {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-sub-list-h'}, [
        el('table', {class: 'sig-table fp-mail-table fp-sub-table'}, [el('thead', null, [el('tr', null, [
          el('th', {scope: 'col', text: t('sub_name')}), el('th', {scope: 'col', text: t('dom_folder')}),
          el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]),
        el('tbody', null, subs.map(function (s) {
          return el('tr', {'data-fp-domain': s.domain}, [nameCell(S, s.domain,
            s.aliases.length ? el('span', {class: 'fp-muted fp-row-note', text: t('sub_also', {names: s.aliases.join(', ')})}) : null),
          folderCell(S.state, s), actsCell(s.domain, 'dom_remove_of')]);
        }))])]));
    }
    if (subs.some(function (s) { return awaiting(S, s.domain); })) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-proof-elsewhere': ''}, [t('sub_proof_note') + ' ',
        el('a', {href: '#/tool/domains', text: t('sub_proof_link')})]));
    }
    return M.card('fp-sub-list-h', t('sub_list_title'), parts, 'fp-sub-list');
  }
  S.render = function () {
    S.page.textContent = '';
    if (S.state.suspended) { S.page.appendChild(M.suspendedBanner(t('dom_suspended'))); }
    S.page.appendChild(sAddCard());
    S.page.appendChild(sListCard());
  };

  document.addEventListener('click', function (e) {
    var target = e.target.closest ? e.target : null;
    var b = target && target.closest('[data-fp-act]');
    if (!b) { return; }
    var a = b.getAttribute('data-fp-act');
    var tr = b.closest('tr');
    if (D.page && D.page.contains(b) && a === 'proof-check') { proofCheck(b); return; }
    if (D.page && D.page.contains(b) && a === 'proof-copy') { proofCopy(b); return; }
    if (D.page && D.page.contains(b)) { rowClick(D, b, a, tr, '.fp-dom-list', 'fp-dom-list-h'); } else if (S.page && S.page.contains(b)) { rowClick(S, b, a, tr, '.fp-sub-list', 'fp-sub-list-h'); }
  });

  function view(id, cls, P) {
    FP.view('tool:' + id, function () {
      D.page = S.page = null;
      var body = frame(id, cls);
      if (!body) { return; }
      P.page = body;
      P.account = FP.account();
      body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
      Promise.all([FP.call('get', 'domains', undefined, P.account), fetchProof(P.account)]).then(function (r) {
        if (P.page !== body) { return; }
        P.state = clean(r[0]);
        P.proof = r[1];
        P.render();
      }, function (err) {
        if (P.page !== body) { return; }
        body.textContent = '';
        body.appendChild(FP.empty(FP.tools[id].label, err.message));
      });
    });
  }
  view('domains', 'fp-dom-page', D);
  view('subdomains', 'fp-sub-page', S);

  FP.domains = {clean: clean};
})();

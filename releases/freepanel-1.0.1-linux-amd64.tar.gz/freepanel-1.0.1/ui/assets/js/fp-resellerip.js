/* freePanel reseller IP delegation, the reseller's side (docs/api.md, "Resellers": the addresses the admin gave a reseller; "Server": an account's own
   address): the card of the Reseller addresses page (fp-resellerpages.js draws it for a reseller, under the list of the addresses it was given) in which a
   reseller puts one of those addresses on one of its own accounts, and takes it off again. An account on an address of its own has all its sites listen on that
   IPv4 address alone, and the names of its web sites in its own DNS zones follow; the answer says how many sites moved and what happened to the records, and a
   failure of the records is shown as a warning, because the sites have moved. The server decides what a reseller may do: an address it was not given, the
   shared one, or one that another account is on, is refused in its words. What the server sends is cleaned to the shapes drawn and shown as text. Page pieces
   come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var USER_RE = /^[a-z][a-z0-9]{0,15}$/;
  var ADDR_RE = /^(?:25[0-5]|2[0-4]\d|1?\d?\d)(?:\.(?:25[0-5]|2[0-4]\d|1?\d?\d)){3}$/;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function whole(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.floor(v) : 0; }
  function count(n) { return Math.round(n).toLocaleString('en'); }
  function plural(n, one, many) { return t(n === 1 ? one : many, {n: count(n)}); }

  /* what the records did, in words: how many were changed and where, and the IPv6 ones the move took away or gave back */
  function dnsPart(d) {
    if (!d || typeof d !== 'object') { return {text: '', error: ''}; }
    var records = whole(d.records);
    var bits = [];
    if (records) {
      bits.push(t('rip_dns_changed', {records: plural(records, 'rip_records_1', 'rip_records'), zones: plural(whole(d.zones), 'rip_zones_1', 'rip_zones')}));
    } else if (!str(d.error)) {
      bits.push(t('rip_dns_none'));
    }
    if (whole(d.dropped)) { bits.push(plural(whole(d.dropped), 'rip_dns_dropped_1', 'rip_dns_dropped')); }
    if (whole(d.restored)) { bits.push(plural(whole(d.restored), 'rip_dns_restored_1', 'rip_dns_restored')); }
    return {text: bits.join(' '), error: str(d.error) ? t('rip_dns_error', {error: str(d.error)}) : ''};
  }

  /* the state of the card on the page; a new one each time the page draws it. opts: {addresses: the reseller's addresses as that page has cleaned them,
     reload: a function that reads them again and answers a promise of the new list, which that page draws above} */
  function make(opts) {
    var R = {holder: el('div', {class: 'fp-rip'}), addresses: opts.addresses, accounts: null, accountsError: '', account: '', ip: undefined, ipError: '', busy: false,
      note: null, seq: 0, asking: false};

    function usable() { return R.addresses.filter(function (a) { return a.present; }); }
    /* an account of the reseller's, other than the one chosen, that is on the address */
    function ownerOf(a) {
      for (var i = 0; i < a.accounts.length; i++) { if (a.accounts[i] !== R.account) { return a.accounts[i]; } }
      return '';
    }

    function accountField() {
      var select = el('select', {class: 'sig-select', id: 'fp-rip-account', name: 'account'}, R.accounts.map(function (n) {
        return el('option', {value: n, selected: n === R.account ? true : null, text: n});
      }));
      select.addEventListener('change', function () { choose(select.value); });
      return M.field('fp-rip-account', t('rip_account'), select, t('rip_account_hint'));
    }
    function nowLine() {
      if (R.ipError) { return el('p', {class: 'fp-warn-line', role: 'status', 'data-fp-now': 'failed', text: R.ipError}); }
      if (R.ip === undefined) { return el('p', {class: 'fp-muted', 'data-fp-now': 'loading', text: t('loading')}); }
      return el('p', {'data-fp-now': R.ip ? 'own' : 'shared', text: R.ip ? t('rip_now_own', {account: R.account, address: R.ip}) : t('rip_now_shared', {account: R.account})});
    }
    /* the addresses of the reseller's that the server has, each free, this account's own, or marked with the account that has it */
    function addressField() {
      var free = 0;
      var options = [el('option', {value: '', text: t('rip_choose')})].concat(usable().map(function (a) {
        var other = ownerOf(a);
        if (!other) { free++; }
        return el('option', {value: a.address, disabled: other ? true : null, selected: a.address === R.ip ? true : null,
          text: other ? t('rip_option_used', {address: a.address, account: other}) : a.address === R.ip ? t('rip_option_this', {address: a.address}) : a.address});
      }));
      if (!free) { return {field: el('p', {class: 'fp-muted', 'data-fp-no-free': '', text: t('rip_no_free')}), free: 0}; }
      return {field: M.field('fp-rip-address', t('rip_address'), el('select', {class: 'sig-select', id: 'fp-rip-address', name: 'address'}, options), t('rip_address_hint')), free: free};
    }
    function form() {
      var a = addressField();
      var acts = [];
      if (a.free) { acts.push(el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', disabled: R.ip === undefined ? true : null, text: t('rip_give')})); }
      if (R.ip) { acts.push(el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'back', text: t('rip_back')})); }
      var f = el('form', {class: 'fp-form fp-rip-form', novalidate: ''}, [M.errorLine(), accountField(), nowLine(), a.field, acts.length ? el('div', {class: 'fp-actions fp-rip-acts'}, acts) : null]);
      f.addEventListener('submit', function (e) {
        e.preventDefault();
        var b = M.start(f);
        if (!b || R.busy) { return; }
        var address = f.querySelector('[name="address"]');
        if (!address || !ADDR_RE.test(address.value)) { M.fieldError(f, address, t('rip_choose')); return; }
        change(f, b, 'put', address.value);
      });
      return f;
    }
    function resultLines() {
      if (!R.note) { return []; }
      var out = [el('p', {class: 'fp-ok-line', role: 'status', 'data-fp-said': '', text: R.note.text})];
      if (R.note.error) { out.push(el('p', {class: 'fp-warn-line', role: 'status', 'data-fp-warning': '', text: R.note.error})); }
      return out;
    }
    function askBox() {
      return el('div', {class: 'fp-rip-ask'}, [el('p', {class: 'fp-mail-confirm', id: 'fp-rip-ask', text: t('rip_back_ask', {account: R.account})}),
        el('button', {class: 'sig-btn sig-btn--danger sig-btn--sm', type: 'button', 'data-fp-act': 'back-yes', 'aria-describedby': 'fp-rip-ask', text: t('rip_back_yes')}),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'back-no', 'aria-describedby': 'fp-rip-ask', text: t('cancel')})]);
    }

    function draw(focus) {
      R.holder.textContent = '';
      var parts = [el('p', {class: 'fp-muted', text: t('rip_what')})];
      if (!usable().length) {
        parts.push(el('p', {class: 'fp-muted', 'data-fp-none': 'addresses', text: t('rip_none')}));
      } else if (R.accountsError) {
        parts.push(el('p', {class: 'fp-alert is-shown', role: 'alert', 'data-fp-accounts-error': '', text: R.accountsError}));
      } else if (R.accounts === null) {
        parts.push(el('p', {class: 'fp-muted', 'data-fp-loading': '', text: t('rip_loading')}));
      } else if (!R.accounts.length) {
        parts.push(el('p', {class: 'fp-muted', 'data-fp-none': 'accounts', text: t('rip_accounts_none')}));
      } else {
        parts = parts.concat(resultLines(), [form()]);
        if (R.asking) { parts.push(askBox()); }
      }
      R.holder.appendChild(M.card('fp-rip-h', t('rip_title'), parts, 'fp-rip-card'));
      var target = focus ? R.holder.querySelector(focus) : null;
      if (target) { target.focus(); }
    }

    /* where the chosen account answers now; a later choice makes an earlier answer stale, and it is dropped */
    function readIp() {
      var who = R.account;
      var seq = ++R.seq;
      R.ip = undefined;
      R.ipError = '';
      return FP.call('get', 'acctIp', undefined, who).then(function (r) {
        if (R.seq !== seq) { return; }
        R.ip = r && typeof r.ip === 'string' && ADDR_RE.test(r.ip) ? r.ip : null;
      }, function (err) {
        if (R.seq !== seq) { return; }
        R.ip = undefined;
        R.ipError = t('rip_now_failed', {account: who}) + ' ' + (err && err.message ? err.message : '');
      });
    }
    function choose(who) {
      R.account = who;
      R.note = null;
      R.asking = false;
      var read = readIp();
      draw('#fp-rip-account');
      read.then(function () { if (R.account === who) { draw('#fp-rip-account'); } });
    }

    function said(r, asked) {
      var ip = r && typeof r.ip === 'string' && ADDR_RE.test(r.ip) ? r.ip : null;
      var changed = r && r.changed === true;
      var text = !changed ? t(ip ? 'rip_same_set' : 'rip_same_cleared', {account: R.account, address: ip || asked}) : t(ip ? 'rip_set' : 'rip_cleared', {account: R.account, address: ip || asked});
      var sites = whole(r && r.sites);
      if (changed && sites) { text += ' ' + plural(sites, 'rip_sites_1', 'rip_sites'); }
      var dns = changed ? dnsPart(r.dns) : {text: '', error: ''};
      return {text: text + (dns.text ? ' ' + dns.text : ''), error: dns.error, ip: ip};
    }
    /* the list of addresses above says which account is on which, so it is read again after a change and the card is drawn from what it says */
    function refresh() {
      return Promise.resolve(opts.reload()).then(function (fresh) { if (fresh) { R.addresses = fresh; } }, function () { /* the card keeps what it had */ });
    }
    function change(f, button, how, address) {
      var who = R.account;
      R.busy = true;
      UI.setBusy(button, true);
      var call = how === 'put' ? FP.call('put', 'acctIpSet', {address: address}, who) : FP.call('del', 'acctIpSet', undefined, who);
      call.then(function (r) {
        R.busy = false;
        if (R.account !== who) { return; }
        var s = said(r && typeof r === 'object' ? r : {}, address);
        R.note = {text: s.text, error: s.error};
        R.ip = s.ip;
        R.asking = false;
        refresh().then(function () { draw('#fp-rip-account'); });
      }, function (err) {
        R.busy = false;
        UI.setBusy(button, false);
        if (R.account !== who) { return; }
        R.asking = false;
        if (err && (err.status === 409 || err.status === 404)) {
          /* the address or the account is not as it was: what the server now says is read again and the refusal told */
          R.note = null;
          refresh().then(readIp).then(function () { draw(); UI.showError(R.holder, err.message); });
          return;
        }
        if (f && f.isConnected) { M.failed(f, err); } else { draw(); UI.showError(R.holder, err.message); }
      });
    }

    R.holder.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
      if (!b || !R.holder.contains(b)) { return; }
      var act = b.getAttribute('data-fp-act');
      if (act === 'back') {
        R.asking = true;
        draw('[data-fp-act="back-no"]');
      } else if (act === 'back-no') {
        R.asking = false;
        draw('[data-fp-act="back"]');
      } else if (act === 'back-yes' && !R.busy) {
        change(null, b, 'del', '');
      }
    });

    draw();
    FP.call('get', 'accounts').then(function (r) {
      var list = r && Array.isArray(r.accounts) ? r.accounts : [];
      R.accounts = list.map(function (x) { return str(x && x.username, 20); }).filter(function (n) { return USER_RE.test(n); }).sort().slice(0, 1000);
      if (!R.accounts.length) { draw(); return; }
      R.account = R.accounts[0];
      var read = readIp();
      draw();
      read.then(function () { if (R.holder.isConnected) { draw(); } });
    }, function (err) {
      R.accounts = [];
      R.accountsError = t('rip_accounts_failed') + ' ' + (err && err.message ? err.message : '');
      draw();
    });
    return R.holder;
  }

  FP.resellerIp = {card: make};
})();

/* freePanel's administrator page for the server's profile (docs/api.md, "Server profile"): the roles this server plays, from the services
   it runs (#/tool/server_profile). Read only. What a server answers is shown as text, a role is named only from the list drawn here, and a
   service only by the server's own list through FP.services. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var el = UI.el;
  var M = FP.mail;

  var t = UI.t;

  var ROLES = ['panel', 'web', 'php', 'email', 'dns', 'mysql', 'postgres', 'ftp', 'protection'];
  var STATES = {running: ['ok', 'pf_state_running'], partial: ['warn', 'pf_state_partial'], stopped: ['danger', 'pf_state_stopped'], not_installed: ['', 'pf_state_not_installed']};
  var UNIT_RE = /^[A-Za-z0-9][A-Za-z0-9._@-]{0,63}$/;

  function num(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.min(Math.floor(v), 1000) : 0; }
  function admin() { return FP.realm === 'admin' && FP.session.user.role === 'admin'; }

  /* what a server answers, cleaned to the roles drawn here and the shapes of their parts */
  function clean(r) {
    var by = {};
    (r && Array.isArray(r.roles) ? r.roles : []).forEach(function (x) {
      if (x && typeof x.id === 'string' && ROLES.indexOf(x.id) >= 0 && !by[x.id]) { by[x.id] = x; }
    });
    return ROLES.map(function (id) {
      var x = by[id] || {};
      var units = (Array.isArray(x.units) ? x.units : []).slice(0, 40).filter(function (u) { return u && typeof u.unit === 'string' && UNIT_RE.test(u.unit); }).map(function (u) {
        return {unit: u.unit, active: typeof u.active === 'string' ? u.active.slice(0, 32) : ''};
      });
      var state = STATES[x.state] ? x.state : 'not_installed';
      return {id: id, installed: x.installed === true && units.length > 0, state: units.length ? state : 'not_installed', running: num(x.running), total: units.length, units: units};
    });
  }
  function pill(state) {
    var s = STATES[state];
    return el('span', {class: 'sig-pill' + (s[0] ? ' sig-pill--' + s[0] : ''), 'data-fp-state': '', text: t(s[1])});
  }
  function unitRow(u) {
    var s = FP.services.state({active: u.active});
    return el('li', {class: 'fp-pf-unit', 'data-fp-unit': u.unit}, [
      el('span', {class: 'fp-pf-unit-name'}, [el('span', {class: 'fp-srv-name', text: FP.services.label(u.unit)}), ' ', el('span', {class: 'sig-mono fp-muted', text: u.unit})]),
      s ? el('span', {class: 'sig-pill' + (s[0] ? ' sig-pill--' + s[0] : ''), text: t(s[1])}) : el('span', {class: 'fp-muted', text: u.active || '—'})]);
  }
  function roleItem(r) {
    var head = [el('h3', {class: 'fp-h3 fp-pf-name', text: t('pf_r_' + r.id)}), pill(r.state)];
    var parts = [el('div', {class: 'fp-pf-head'}, head), el('p', {class: 'fp-muted fp-pf-desc', text: t('pf_d_' + r.id)})];
    if (r.installed) {
      parts.push(el('p', {class: 'fp-pf-count', text: t('pf_count', {running: String(r.running), total: String(r.total)})}));
      parts.push(el('ul', {class: 'fp-pf-units', 'aria-label': t('pf_services') + ': ' + t('pf_r_' + r.id)}, r.units.map(unitRow)));
    } else {
      parts.push(el('p', {class: 'fp-muted fp-pf-none', text: t('pf_none_here')}));
    }
    return el('li', {class: 'fp-pf-role', 'data-fp-role': r.id}, parts);
  }

  FP.view('tool:server_profile', function () {
    var tool = FP.tools.server_profile;
    if (!tool || !admin()) { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('server_profile_desc'), cls: 'fp-mail fp-pf-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    if (!page) { return; }
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'serverProfile').then(function (r) {
      if (!page.isConnected) { return; }
      var roles = clean(r);
      var here = roles.filter(function (x) { return x.installed; }).length;
      page.textContent = '';
      page.appendChild(M.card('fp-pf-h', t('pf_srv_title'), [
        el('p', {class: 'fp-muted', text: t('pf_what')}),
        el('p', {class: 'fp-pf-sum', 'data-fp-sum': '', text: t(here === roles.length ? 'pf_summary_all' : 'pf_summary', {n: String(here), total: String(roles.length)})}),
        el('ul', {class: 'fp-pf-list'}, roles.map(roleItem)),
        el('p', {class: 'fp-muted fp-pf-foot'}, [t('pf_open_note'), ' ', el('a', {href: '#/tool/service_manager', text: t('pf_srv_open')})])], 'fp-pf'));
    }, function (err) {
      if (!page.isConnected) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err && err.message ? err.message : t('api_failed')));
    });
  });
})();

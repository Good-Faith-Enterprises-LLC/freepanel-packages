/* freePanel spam settings (docs/api.md, "Email", PUT .../email/spam and .../email/spam/senders): the customer panel's
   Spam protection page (#/tool/spam_protection). Spam filtering scores mail arriving from other servers: from the mark
   score a message is filed as spam, from the refuse score it is refused while it is being sent. Allowed senders are
   never filed as spam (yet still refused from the refuse score, since a From address is easy to forge); blocked
   senders are refused while they send. Senders are addresses or whole domains (@example.com) matched on the From
   address, ignoring case. Each change of a list sends both lists, as the API replaces them together. Until spam
   filtering is on for the server (spam null), the page says so and changes nothing. Page pieces come from FP.mail. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var MARK = 6;
  var REJECT = 15;
  var MAX_SENDERS = 500;
  var DOMAIN = '(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]';
  var SENDER_RE = new RegExp('^(?:[a-z0-9._%=-]+)?@' + DOMAIN + '$');
  var LISTS = ['allow', 'block'];

  function score(v, d) { return typeof v === 'number' && v >= 1 && v <= 100 ? v : d; }
  function senders(v) {
    var out = (Array.isArray(v) ? v : []).filter(function (e) { return typeof e === 'string' && SENDER_RE.test(e); });
    return out.filter(function (e, i) { return out.indexOf(e) === i; }).sort().slice(0, MAX_SENDERS);
  }
  function cleanSpam(r) {
    var s = r && r.spam;
    if (!s || typeof s !== 'object') { return null; }
    return {enabled: s.enabled === true, mark: score(s.mark_score, MARK), reject: score(s.reject_score, REJECT), allow: senders(s.allow), block: senders(s.block)};
  }
  /* what the person typed, as the server keeps it: lower case, "*@domain" as "@domain"; '' when it is no sender */
  function normal(v) {
    var e = v.trim().toLowerCase();
    if (e.indexOf('*@') === 0) { e = e.slice(1); }
    return e;
  }
  function num(v) { return String(Math.round(v * 10) / 10); }

  var P = {page: null, account: '', spam: null, suspended: false};

  /* ---------- scores ---------- */
  function stateText(s) {
    return s.enabled ? t('sp_state_on', {mark: num(s.mark), reject: num(s.reject)}) : t('sp_state_off');
  }
  function scoreInput(id, name, value) {
    return el('input', {class: 'sig-input fp-sp-score', id: id, name: name, type: 'number', min: '1', max: '100', step: '0.1', inputmode: 'decimal',
      value: num(value)});
  }
  function settingsCard() {
    var s = P.spam;
    var on = el('input', {type: 'checkbox', id: 'fp-sp-on', name: 'enabled', checked: s.enabled ? true : null, 'aria-describedby': 'fp-sp-on-hint'});
    var mark = scoreInput('fp-sp-mark', 'mark_score', s.mark);
    var reject = scoreInput('fp-sp-reject', 'reject_score', s.reject);
    var scores = el('div', {class: 'fp-sp-scores'}, [M.field('fp-sp-mark', t('sp_mark'), mark, t('sp_mark_hint', {n: MARK})),
      M.field('fp-sp-reject', t('sp_reject'), reject, t('sp_reject_hint', {n: REJECT}))]);
    var form = el('form', {class: 'fp-form fp-mail-form fp-sp-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('p', {class: 'fp-sp-state', 'data-fp-sp-state': '', text: stateText(s)}),
      el('div', {class: 'sig-field'}, [el('label', {class: 'fp-check', for: 'fp-sp-on'}, [on, el('span', {text: t('sp_on')})]),
        el('span', {class: 'sig-hint', id: 'fp-sp-on-hint', text: t('sp_on_hint')})]),
      scores,
      el('p', {class: 'sig-hint', text: t('sp_scores_note')}),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('sp_save')})])]);
    function sync() { scores.hidden = !on.checked; }
    on.addEventListener('change', sync);
    sync();
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      /* the scores always go along: a PUT without them puts back the usual ones */
      var body = {enabled: on.checked, mark_score: s.mark, reject_score: s.reject};
      if (on.checked) {
        var m = Number(mark.value);
        var r = Number(reject.value);
        var bad = function (v) { return !isFinite(v) || v < 1 || v > 100 || Math.abs(v * 10 - Math.round(v * 10)) > 1e-9; };
        if (mark.value.trim() === '' || bad(m)) { M.fieldError(form, mark, t('sp_score_bad', {label: t('sp_mark')})); return; }
        if (reject.value.trim() === '' || bad(r)) { M.fieldError(form, reject, t('sp_score_bad', {label: t('sp_reject')})); return; }
        if (m >= r) { M.fieldError(form, mark, t('sp_mark_above')); return; }
        body.mark_score = m;
        body.reject_score = r;
      }
      UI.setBusy(b, true);
      FP.call('put', 'mailSpam', body, P.account).then(function (res) {
        settle(res);
        render();
        var now = P.page.querySelector('.fp-sp-form');
        M.say(now, body.enabled ? t('sp_saved_on', {mark: num(P.spam.mark), reject: num(P.spam.reject)}) : t('sp_saved_off'));
        now.querySelector('#fp-sp-on').focus();
      }, function (err) {
        UI.setBusy(b, false);
        failed(form, err);
      });
    });
    return M.card('fp-sp-h', t('sp_title'), [form], 'fp-sp-settings');
  }

  /* ---------- sender lists ---------- */
  function listPart(kind) {
    var s = P.spam;
    var list = s[kind];
    var id = 'fp-sp-' + kind;
    var input = el('input', {class: 'sig-input sig-mono', id: id + '-add', name: kind, type: 'text', autocomplete: 'off', spellcheck: 'false',
      autocapitalize: 'none', inputmode: 'email', placeholder: kind === 'allow' ? t('sp_allow_placeholder') : t('sp_block_placeholder'),
      'aria-describedby': id + '-hint'});
    var form = el('form', {class: 'fp-form fp-sp-add', 'data-fp-sp-list': kind, novalidate: ''}, [
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: id + '-add', text: t('sp_' + kind + '_add')}),
        el('div', {class: 'fp-sp-add-row'}, [input,
          el('button', {class: 'sig-btn sig-btn--secondary fp-submit', type: 'submit', text: t('sp_add')})]),
        el('span', {class: 'sig-hint', id: id + '-hint', text: t('sp_sender_hint')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var card = P.page.querySelector('.fp-sp-senders');
      var b = M.start(form);
      if (!b) { return; }
      UI.showError(card, '');
      var v = normal(input.value);
      var other = kind === 'allow' ? 'block' : 'allow';
      if (!v) { M.fieldError(card, input, t('sp_sender_none')); return; }
      if (v.split('@')[0].indexOf('+') >= 0) { M.fieldError(card, input, t('sp_sender_tag', {sender: v.replace(/\+[^@]*@/, '@')})); return; }
      if (!SENDER_RE.test(v)) { M.fieldError(card, input, t('sp_sender_bad', {sender: v})); return; }
      if (list.indexOf(v) >= 0) { M.fieldError(card, input, t('sp_sender_there', {sender: v})); return; }
      if (s[other].indexOf(v) >= 0) { M.fieldError(card, input, t('sp_sender_other_' + kind, {sender: v})); return; }
      if (list.length >= MAX_SENDERS) { M.fieldError(card, input, t('sp_sender_full', {n: MAX_SENDERS})); return; }
      var next = {allow: s.allow.slice(), block: s.block.slice()};
      next[kind].push(v);
      UI.setBusy(b, true);
      save(next, t('sp_added_' + kind, {sender: v}), '#' + id + '-add', kind, function (err) {
        UI.setBusy(b, false);
        M.fieldError(card, input, err.message);
      });
    });
    var items = list.length ? el('ul', {class: 'fp-sp-list', 'aria-labelledby': id + '-h'}, list.map(function (e) {
      return el('li', {'data-fp-sender': e, 'data-fp-sp-kind': kind}, [el('span', {class: 'sig-mono fp-sp-sender', text: e}),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'sp-remove',
          'aria-label': t('sp_remove_of_' + kind, {sender: e}), text: t('sp_remove')})]);
    })) : el('p', {class: 'fp-muted', 'data-fp-sp-empty': kind, text: t('sp_' + kind + '_none')});
    return el('div', {class: 'fp-sp-part', 'data-fp-sp-part': kind}, [
      el('h3', {class: 'fp-h3', id: id + '-h', tabindex: '-1', text: t('sp_' + kind + '_title', {n: list.length})}),
      el('p', {class: 'fp-muted fp-sp-what', text: kind === 'allow' ? t('sp_allow_what', {reject: num(s.reject)}) : t('sp_block_what')}),
      items, form]);
  }
  function sendersCard() {
    var parts = [M.errorLine(), M.statusLine()];
    if (!P.spam.enabled) { parts.push(el('p', {class: 'fp-warn-line', 'data-fp-sp-unused': '', text: t('sp_lists_unused')})); }
    parts.push(el('p', {class: 'fp-muted', text: t('sp_senders_note')}));
    parts.push(listPart('allow'));
    parts.push(listPart('block'));
    return M.card('fp-sp-senders-h', t('sp_senders_title'), parts, 'fp-sp-senders');
  }
  /* sends both lists; on success redraws and says what changed on the senders card */
  function save(next, said, focus, sent, onError) {
    FP.call('put', 'mailSpamSenders', next, P.account).then(function (res) {
      settle(res);
      render(sent);
      var card = P.page.querySelector('.fp-sp-senders');
      if (!card) { return; }
      M.say(card, said);
      (card.querySelector(focus) || card.querySelector('#fp-sp-senders-h')).focus();
    }, onError);
  }

  /* a server answer on a form: a 503 means spam filtering went off for the server meanwhile, so the page says so */
  function failed(form, err) {
    if (err.status === 503) { reload(err.message); return; }
    M.failed(form, err);
  }
  function settle(r) {
    P.spam = cleanSpam(r);
    P.suspended = Boolean(r && r.suspended === true);
  }
  /* a redraw keeps what is typed in the add fields, but for the one whose sender was just saved */
  function render(sent) {
    var typed = {};
    LISTS.forEach(function (k) {
      var f = P.page.querySelector('#fp-sp-' + k + '-add');
      typed[k] = f && k !== sent ? f.value : '';
    });
    P.page.textContent = '';
    if (P.suspended) { P.page.appendChild(M.suspendedBanner(t('mail_suspended'))); }
    if (!P.spam) {
      P.page.appendChild(M.card('fp-sp-h', t('sp_title'), [el('p', {class: 'fp-muted', 'data-fp-sp-off': '', text: t('sp_server_off')})], 'fp-sp-settings'));
      return;
    }
    P.page.appendChild(settingsCard());
    P.page.appendChild(sendersCard());
    LISTS.forEach(function (k) { if (typed[k]) { P.page.querySelector('#fp-sp-' + k + '-add').value = typed[k]; } });
  }
  function reload(said) {
    var page = P.page;
    FP.call('get', 'mail', undefined, P.account).then(function (r) {
      if (P.page !== page) { return; }
      settle(r);
      render();
      var h = P.page.querySelector('#fp-sp-h');
      if (said && P.spam) { UI.showError(P.page.querySelector('.fp-sp-settings'), said); }
      h.focus();
    }, function () {});
  }

  function onClick(e) {
    var b = e.target.closest ? e.target.closest('[data-fp-act="sp-remove"]') : null;
    if (!b || !P.page || !P.page.contains(b)) { return; }
    var li = b.closest('[data-fp-sender]');
    var kind = li.getAttribute('data-fp-sp-kind');
    var gone = li.getAttribute('data-fp-sender');
    var card = P.page.querySelector('.fp-sp-senders');
    var next = {allow: P.spam.allow.slice(), block: P.spam.block.slice()};
    var at = next[kind].indexOf(gone);
    next[kind].splice(at, 1);
    /* the focus goes to the entry that takes its place, or to the list's heading */
    var after = next[kind][Math.min(at, next[kind].length - 1)];
    UI.showError(card, '');
    UI.setBusy(b, true);
    save(next, t('sp_removed_' + kind, {sender: gone}),
      after ? '[data-fp-sender="' + window.CSS.escape(after) + '"][data-fp-sp-kind="' + kind + '"] [data-fp-act="sp-remove"]' : '#fp-sp-' + kind + '-h', null,
      function (err) {
        UI.setBusy(b, false);
        if (err.status === 503) { reload(err.message); return; }
        UI.showError(card, err.message);
        b.focus();
      });
  }

  FP.view('tool:spam_protection', function () {
    P.page = null;
    var body = M.frame('spam_protection', 'fp-sp');
    if (!body) { return; }
    P.page = body;
    P.account = FP.account();
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'mail', undefined, P.account).then(function (r) {
      if (P.page !== body) { return; }
      settle(r);
      render();
    }, function (err) {
      if (P.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(FP.tools.spam_protection.label, err.message));
    });
  });
  document.addEventListener('click', onClick);
})();

/* freePanel connect a device (docs/api.md, "Email": GET .../email/mailboxes/{address}/client and .../client/apple): the customer panel's Connect a
   device page (#/tool/connect_device). For one mailbox it shows what a mail program connects to (the incoming and outgoing servers, the ports, how the
   connection is secured and the user name, which is the whole address; never the password), an Apple configuration profile to download for iPhone,
   iPad and Mac, and the DNS records that let programs find these settings on their own (autoconfig and the service records). Nothing is added to the
   zone from here: the records are shown to copy, with a link to the DNS page where the customer has it. The profile is fetched by the page, not
   linked to, so a refusal is shown in words instead of being saved as the file. A mailbox whose domain's mail does not come here is said so: a program
   can sign in but nothing arrives. Everything the server sends is shown as text. The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var HOST_RE = /^(?=.{1,253}$)[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?(\.[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*$/;
  var ZONE_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var NAME_RE = /^[A-Za-z0-9_]([A-Za-z0-9_.-]{0,250})$/;
  var CONTENT_RE = /^[A-Za-z0-9 ._:-]{1,300}$/;
  var PROTOCOLS = ['imap', 'pop3', 'smtp'];
  var SECURITY = ['ssl', 'starttls'];
  var MAX_NAME = 80;

  function obj(v) { return v && typeof v === 'object' && !Array.isArray(v) ? v : {}; }
  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  /* a control character or a line separator cannot be in the name shown on outgoing mail */
  function hasControl(v) {
    for (var i = 0; i < v.length; i++) {
      var c = v.charCodeAt(i);
      if (c < 32 || (c >= 127 && c < 160) || c === 0x2028 || c === 0x2029) { return true; }
    }
    return false;
  }

  function cleanServer(s) {
    s = obj(s);
    var port = typeof s.port === 'number' && Math.floor(s.port) === s.port && s.port >= 1 && s.port <= 65535 ? s.port : 0;
    if (PROTOCOLS.indexOf(s.protocol) < 0 || !HOST_RE.test(str(s.host, 253)) || !port || SECURITY.indexOf(s.security) < 0 || !M.isAddress(str(s.username, 254))) { return null; }
    return {protocol: s.protocol, host: s.host, port: port, security: s.security, username: s.username};
  }
  function cleanRecord(r) {
    r = obj(r);
    if (!NAME_RE.test(str(r.name, 253)) || ['CNAME', 'SRV'].indexOf(r.type) < 0 || !CONTENT_RE.test(str(r.content, 300))) { return null; }
    return {name: r.name, type: r.type, priority: typeof r.priority === 'number' && r.priority >= 0 && r.priority <= 65535 ? Math.floor(r.priority) : null, content: r.content};
  }
  function clean(r) {
    r = obj(r);
    return {address: M.isAddress(str(r.address, 254)) ? r.address : '', served: r.served === true,
      zone: ZONE_RE.test(str(r.zone, 253)) ? r.zone : '',
      servers: (Array.isArray(r.servers) ? r.servers : []).slice(0, 6).map(cleanServer).filter(Boolean),
      records: (Array.isArray(r.records) ? r.records : []).slice(0, 12).map(cleanRecord).filter(Boolean)};
  }

  var C = {page: null, account: '', mail: null, address: '', data: null, loading: false, seq: 0, failure: '', profileBusy: false};

  /* ---- copying ---- */
  function copyOf(text, scopeEl, b, node) {
    function selected() {
      var range = document.createRange();
      range.selectNodeContents(node);
      var sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
      M.say(scopeEl, t('cdev_selected'));
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(function () { M.say(scopeEl, t('cdev_copied')); }, selected);
    } else {
      selected();
    }
    b.focus();
  }

  /* ---- the mailbox ---- */
  function pickCard() {
    var select = el('select', {class: 'sig-select', id: 'fp-cdev-address', name: 'address'}, C.mail.mailboxes.map(function (m) {
      var o = el('option', {value: m.address, text: m.address});
      if (m.address === C.address) { o.selected = true; }
      return o;
    }));
    select.addEventListener('change', function () { C.address = select.value; load(); });
    return M.card('fp-cdev-pick-h', t('cdev_pick_title'), [el('p', {class: 'fp-muted', text: t('cdev_pick_what')}),
      el('div', {class: 'fp-cdev-pick'}, [M.field('fp-cdev-address', t('cdev_mailbox'), select)])], 'fp-cdev-pick-card');
  }

  /* ---- the settings ---- */
  function settingsText(s) {
    var kind = s.protocol === 'smtp' ? 'out' : s.protocol;
    return [t('cdev_k_' + kind), t('cdev_server') + ': ' + s.host, t('cdev_port') + ': ' + s.port, t('cdev_security') + ': ' + t('cdev_sec_' + s.security),
      t('cdev_username') + ': ' + s.username, t('cdev_password') + ': ' + t('cdev_password_v')].join('\n');
  }
  function serverBlock(s, i) {
    var kind = s.protocol === 'smtp' ? 'out' : s.protocol;
    var facts = el('dl', {class: 'fp-cdev-facts', id: 'fp-cdev-server-' + i}, [
      el('dt', {text: t('cdev_server')}), el('dd', {class: 'sig-mono', text: s.host}),
      el('dt', {text: t('cdev_port')}), el('dd', {class: 'sig-mono', text: String(s.port)}),
      el('dt', {text: t('cdev_security')}), el('dd', {text: t('cdev_sec_' + s.security)}),
      el('dt', {text: t('cdev_username')}), el('dd', {class: 'sig-mono', text: s.username}),
      el('dt', {text: t('cdev_password')}), el('dd', {text: t('cdev_password_v')})]);
    var b = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'cdev-copy', 'data-fp-i': String(i),
      'aria-label': t('cdev_copy_of', {what: t('cdev_k_' + kind)}), text: t('cdev_copy')});
    return el('div', {class: 'fp-cdev-server', 'data-fp-protocol': s.protocol}, [el('h3', {class: 'fp-h3', id: 'fp-cdev-server-h-' + i, text: t('cdev_k_' + kind)}), facts,
      el('div', {class: 'fp-actions'}, [b])]);
  }
  function settingsCard() {
    var d = C.data;
    var parts = [M.errorLine(), M.statusLine()];
    if (!d.served) { parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-not-served': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('cdev_not_served', {address: d.address})})])); }
    if (!d.servers.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('cdev_no_servers')}));
    } else {
      parts.push(el('p', {class: 'fp-muted', text: t('cdev_settings_what')}));
      parts.push(el('div', {class: 'fp-cdev-servers'}, d.servers.map(function (s, i) { return serverBlock(s, i); })));
    }
    return M.card('fp-cdev-settings-h', t('cdev_settings_title', {address: d.address}), parts, 'fp-cdev-settings');
  }

  /* ---- the Apple profile ---- */
  function profileCard() {
    var name = el('input', {class: 'sig-input', id: 'fp-cdev-name', name: 'name', type: 'text', maxlength: String(MAX_NAME), autocomplete: 'name'});
    var form = el('form', {class: 'fp-form fp-mail-form fp-cdev-form', novalidate: ''}, [M.errorLine(), M.statusLine(), M.field('fp-cdev-name', t('cdev_name'), name, t('cdev_name_hint', {n: MAX_NAME})),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit'}, [UI.icon(FP.ui, 'ui_download'), el('span', {text: t('cdev_download')})])])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || C.profileBusy) { return; }
      var v = name.value.trim();
      if (v.length > MAX_NAME) { M.fieldError(form, name, t('cdev_name_long', {n: MAX_NAME})); return; }
      if (hasControl(v)) { M.fieldError(form, name, t('cdev_name_bad')); return; }
      download(form, b, v);
    });
    return M.card('fp-cdev-apple-h', t('cdev_apple_title'), [el('p', {class: 'fp-muted', text: t('cdev_apple_what')}), form,
      el('ol', {class: 'fp-cdev-steps'}, [1, 2, 3, 4].map(function (n) { return el('li', {text: t('cdev_apple_step' + n)}); })),
      el('p', {class: 'fp-muted fp-row-note', text: t('cdev_apple_unsigned')})], 'fp-cdev-apple');
  }
  function profileURL(address, name) {
    return '/api/v1/accounts/' + encodeURIComponent(C.account) + '/email/mailboxes/' + encodeURIComponent(address) + '/client/apple' + (name ? '?name=' + encodeURIComponent(name) : '');
  }
  /* the profile is fetched and saved by the page: a refusal (the mailbox gone, the server without a mail name, a name that is not accepted) arrives as JSON,
     which a plain link would have saved as the file */
  function download(form, b, name) {
    var mine = C.page;
    var address = C.data.address;
    C.profileBusy = true;
    UI.setBusy(b, true);
    M.say(form, t('cdev_making'));
    var fail = function (message, field) {
      C.profileBusy = false;
      if (C.page !== mine) { return; }
      UI.setBusy(b, false);
      M.say(form, '');
      M.failed(form, {field: field, message: message});
    };
    window.fetch(profileURL(address, name), {credentials: 'same-origin', cache: 'no-store'}).then(function (r) {
      if (r.ok) {
        return r.blob().then(function (blob) {
          C.profileBusy = false;
          if (C.page !== mine) { return; }
          UI.setBusy(b, false);
          var url = window.URL.createObjectURL(new window.Blob([blob], {type: 'application/x-apple-aspen-config'}));
          /* not made with el(): its address check passes only addresses on the panel's own site, and this one is a blob of the page's own */
          var a = document.createElement('a');
          a.href = url;
          a.download = address + '.mobileconfig';
          document.body.appendChild(a);
          a.click();
          a.remove();
          window.setTimeout(function () { window.URL.revokeObjectURL(url); }, 10000);
          M.say(form, t('cdev_downloaded', {file: address + '.mobileconfig'}));
          b.focus();
        });
      }
      if (r.status === 401) { FP.signedOut(true); return undefined; }
      return r.text().then(function (text) {
        var j;
        try { j = JSON.parse(text); } catch (e) { j = null; }
        var err = j && j.error && typeof j.error === 'object' ? j.error : {};
        var message = typeof err.message === 'string' && err.message.trim() ? err.message.trim().slice(0, 300) : t(r.status === 404 ? 'cdev_gone' : 'api_failed');
        fail(message, err.field === 'name' ? 'name' : undefined);
      });
    }, function () { fail(t('api_unreachable')); });
  }

  /* ---- the records that let programs find the settings ---- */
  function recordText(r) {
    return [r.name, r.type, r.priority !== null ? String(r.priority) : '', r.content].filter(function (x) { return x !== ''; }).join('\t');
  }
  function recordsCard() {
    var d = C.data;
    var parts = [M.statusLine(), el('p', {class: 'fp-muted', text: t('cdev_auto_what', {zone: d.zone || d.address.slice(d.address.indexOf('@') + 1)})})];
    if (!d.records.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('cdev_no_records')}));
    } else {
      var zone = d.zone;
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-cdev-auto-h'}, [el('table', {class: 'sig-table fp-mail-table fp-cdev-table', id: 'fp-cdev-records'}, [
        el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('cdev_r_name')}), el('th', {scope: 'col', text: t('cdev_r_type')}), el('th', {scope: 'col', text: t('cdev_r_priority')}),
          el('th', {scope: 'col', text: t('cdev_r_value')})])]),
        el('tbody', null, d.records.map(function (r) {
          return el('tr', {'data-fp-record': r.name}, [
            el('th', {scope: 'row', class: 'fp-cdev-rname'}, [el('span', {class: 'sig-mono', text: r.name}), zone ? el('span', {class: 'fp-muted fp-row-note', text: r.name + '.' + zone}) : null]),
            el('td', {'data-label': t('cdev_r_type'), text: r.type}), el('td', {class: 'fp-num', 'data-label': t('cdev_r_priority'), text: r.priority !== null ? String(r.priority) : '—'}),
            el('td', {class: 'sig-mono fp-cdev-rvalue', 'data-label': t('cdev_r_value'), text: r.content})]);
        }))])]));
      var acts = [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'cdev-copy-records', text: t('cdev_copy_records')})];
      if (FP.tools.dns) { acts.push(el('a', {class: 'sig-btn sig-btn--secondary', href: FP.tools.dns.href, text: t('cdev_open_dns')})); }
      parts.push(el('div', {class: 'fp-actions'}, acts));
      parts.push(el('p', {class: 'fp-muted fp-row-note', text: t('cdev_auto_apps')}));
    }
    return M.card('fp-cdev-auto-h', t('cdev_auto_title'), parts, 'fp-cdev-auto');
  }

  function helpCard() {
    return M.card('fp-cdev-help-h', t('cdev_help_title'), [el('dl', {class: 'fp-cdev-help'}, ['phone', 'desktop', 'outlook'].reduce(function (out, k) {
      return out.concat([el('dt', {text: t('cdev_help_' + k)}), el('dd', {text: t('cdev_help_' + k + '_text')})]);
    }, []))], 'fp-cdev-help-card');
  }

  function render() {
    C.page.textContent = '';
    if (C.mail.suspended) { C.page.appendChild(M.suspendedBanner(t('mail_suspended'))); }
    C.page.appendChild(pickCard());
    var slot = el('div', {class: 'fp-cdev-slot', 'data-fp-slot': ''});
    C.page.appendChild(slot);
    drawSlot();
    C.page.appendChild(helpCard());
  }
  function drawSlot() {
    var slot = C.page.querySelector('[data-fp-slot]');
    slot.textContent = '';
    if (C.loading) {
      slot.appendChild(el('p', {class: 'fp-muted', role: 'status', text: t('loading')}));
    } else if (C.data) {
      slot.appendChild(settingsCard());
      if (C.data.servers.length) { slot.appendChild(profileCard()); }
      slot.appendChild(recordsCard());
    } else if (C.failure) {
      slot.appendChild(FP.empty(t('cdev_failed_title'), C.failure));
    }
  }
  function load() {
    var mine = C.page;
    var address = C.address;
    var seq = ++C.seq;
    C.loading = true;
    C.data = null;
    C.failure = '';
    drawSlot();
    FP.call('get', 'mailClient', undefined, {name: C.account, address: address}).then(function (r) {
      if (C.page !== mine || C.seq !== seq) { return; }
      C.loading = false;
      C.data = clean(r);
      if (C.data.address !== address) { C.data = null; C.failure = t('api_failed'); }
      drawSlot();
    }, function (err) {
      if (C.page !== mine || C.seq !== seq) { return; }
      C.loading = false;
      C.failure = err.message;
      drawSlot();
    });
  }

  document.addEventListener('click', function (e) {
    if (!C.page) { return; }
    var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !C.page.contains(b) || !C.data) { return; }
    var act = b.getAttribute('data-fp-act');
    if (act === 'cdev-copy') {
      var i = Number(b.getAttribute('data-fp-i'));
      var s = C.data.servers[i];
      if (s) { copyOf(settingsText(s), C.page.querySelector('.fp-cdev-settings'), b, C.page.querySelector('#fp-cdev-server-' + i)); }
    } else if (act === 'cdev-copy-records') {
      copyOf(C.data.records.map(recordText).join('\n'), C.page.querySelector('.fp-cdev-auto'), b, C.page.querySelector('#fp-cdev-records'));
    }
  });

  FP.view('tool:connect_device', function () {
    C = {page: null, account: '', mail: null, address: '', data: null, loading: false, seq: 0, failure: '', profileBusy: false};
    var body = M.frame('connect_device', 'fp-cdev-page');
    if (!body) { return; }
    C.page = body;
    C.account = FP.account();
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'mail', undefined, C.account).then(function (r) {
      if (C.page !== body) { return; }
      C.mail = M.clean(r);
      body.textContent = '';
      if (!C.mail.mailboxes.length) {
        body.appendChild(FP.empty(t('cdev_none_title'), t('cdev_none'), el('a', {class: 'sig-btn sig-btn--primary', href: FP.tools.mailboxes ? FP.tools.mailboxes.href : '#/', text: t('cdev_none_action')})));
        return;
      }
      C.address = C.mail.mailboxes[0].address;
      render();
      load();
    }, function (err) {
      if (C.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(FP.tools.connect_device.label, err.message));
    });
  });
})();

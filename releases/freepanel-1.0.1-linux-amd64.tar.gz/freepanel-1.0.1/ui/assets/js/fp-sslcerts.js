/* freePanel certificates in use (docs/api.md, "Domains and sites": the certificate lists): the admin's page
   (#/tool/ssl_installed) lists the certificate of every website of every account, free or installed, with who it is for,
   who issued it and when it ends, and filters by account, source and how soon it ends. The list is read a page at a time:
   a page can be shorter than asked when the names are long, and Next starts after the last one shown. What the server sends
   is cleaned to the shapes drawn here and shown as text. Page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var PAGE = 100;
  var DOMAIN_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var NAME_RE = /^(\*\.)?([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var USER_RE = /^[A-Za-z0-9_.@-]{1,60}$/;
  var FINGERPRINT = /^[0-9a-f]{64}$/;
  var WITHIN = ['30', '60', '90'];

  function str(v) { return typeof v === 'string' ? v : ''; }
  function whole(n) { return typeof n === 'number' && isFinite(n) && n >= 0 && n === Math.floor(n) ? n : 0; }
  function day(iso) {
    var d = new Date(str(iso));
    return isNaN(d.getTime()) ? '' : d.toLocaleDateString('en', {dateStyle: 'medium'});
  }
  function cleanCert(c) {
    if (!c || typeof c !== 'object' || !USER_RE.test(str(c.account)) || !DOMAIN_RE.test(str(c.domain)) || (c.source !== 'free' && c.source !== 'installed')) { return null; }
    return {account: c.account, domain: c.domain, source: c.source,
      names: (Array.isArray(c.names) ? c.names : []).filter(function (n) { return NAME_RE.test(str(n)); }).slice(0, 100),
      issuer: str(c.issuer).slice(0, 200), end: day(c.not_after), days: whole(c.days_left), expired: c.expired === true,
      print: FINGERPRINT.test(str(c.key_fingerprint)) ? c.key_fingerprint : '', hasKey: /^k-[0-9a-f]{12}$/.test(str(c.key_id))};
  }
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var list = (Array.isArray(r.certificates) ? r.certificates : []).map(cleanCert).filter(Boolean);
    return {list: list, total: Math.max(whole(r.total), list.length), offset: whole(r.offset), truncated: r.truncated === true};
  }

  var CS = null;

  function endCell(c) {
    return el('td', null, [c.expired ? el('span', {class: 'sig-pill sig-pill--danger', text: t('cin_expired')}) : null,
      el('span', {class: 'fp-row-note', text: c.end ? t(c.expired ? 'cin_ended_on' : 'cin_ends_on', {date: c.end}) : ''}),
      c.expired ? null : el('span', {class: 'fp-muted fp-row-note' + (c.days <= 30 ? ' fp-ci-soon' : ''), text: t(c.days === 1 ? 'cin_day_left' : 'cin_days_left', {n: c.days})})]);
  }
  function table() {
    return el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-ci-list-h'}, [
      el('table', {class: 'sig-table fp-mail-table fp-ci-certs'}, [el('thead', null, [el('tr', null, [
        el('th', {scope: 'col', text: t('cin_col_site')}), el('th', {scope: 'col', text: t('cin_col_cert')}), el('th', {scope: 'col', text: t('cin_col_ends')})])]),
      el('tbody', null, CS.page.list.map(function (c) {
        return el('tr', {'data-fp-cert': c.domain, 'data-fp-account': c.account}, [
          el('th', {scope: 'row', class: 'fp-mail-name'}, [el('span', {text: c.domain}), el('span', {class: 'fp-muted fp-row-note', text: t('cin_account', {account: c.account})})]),
          el('td', {class: 'fp-ci-cert'}, [el('span', {class: 'sig-pill' + (c.source === 'free' ? ' sig-pill--accent' : ''), text: t(c.source === 'free' ? 'ssl_free' : 'ssl_installed')}),
            c.issuer ? el('span', {class: 'fp-row-note', text: t('cin_issuer', {issuer: c.issuer})}) : null,
            c.names.length ? el('span', {class: 'fp-muted fp-row-note fp-ssl-names', text: t('ssl_covers', {names: c.names.join(', ')})}) : null,
            c.hasKey ? el('span', {class: 'fp-muted fp-row-note', text: t('cin_own_key')}) : null]),
          endCell(c)]);
      }))])]);
  }
  function summary() {
    var p = CS.page;
    if (!p.list.length) { return t('cin_none'); }
    return t('cin_showing', {from: p.offset + 1, to: p.offset + p.list.length, total: p.total});
  }
  function filterForm() {
    var q = CS.q;
    var account = el('input', {class: 'sig-input', id: 'fp-ci-account', name: 'account', type: 'text', maxlength: '60', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', value: q.account});
    var source = el('select', {class: 'sig-select', id: 'fp-ci-source', name: 'source'}, [['', 'cin_any'], ['free', 'ssl_free'], ['installed', 'ssl_installed']].map(function (o) {
      return el('option', {value: o[0], text: t(o[1]), selected: q.source === o[0] ? true : null});
    }));
    var status = el('select', {class: 'sig-select', id: 'fp-ci-status', name: 'status'}, [['', t('cin_any')], ['valid', t('cin_valid')], ['expired', t('cin_expired')]].concat(WITHIN.map(function (n) {
      return ['within' + n, t('cin_within', {n: n})];
    })).map(function (o) { return el('option', {value: o[0], text: o[1], selected: q.status === o[0] ? true : null}); }));
    var form = el('form', {class: 'fp-form fp-mail-form fp-ci-filter', novalidate: ''}, [M.errorLine(),
      el('div', {class: 'fp-ci-filter-row'}, [M.field('fp-ci-account', t('cin_f_account'), account, t('cin_f_account_hint')), M.field('fp-ci-source', t('cin_f_source'), source),
        M.field('fp-ci-status', t('cin_f_status'), status)]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('cin_show')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var who = account.value.trim();
      if (who && !USER_RE.test(who)) { M.fieldError(form, account, t('cin_account_bad')); return; }
      CS.q = {account: who, source: source.value, status: status.value};
      CS.offsets = [0];
      load(0, form, b);
    });
    return form;
  }
  function query(offset) {
    var q = CS.q;
    var args = {limit: String(PAGE), offset: String(offset), account: q.account, source: q.source};
    if (q.status === 'valid') { args.expired = 'false'; }
    else if (q.status === 'expired') { args.expired = 'true'; }
    else if (/^within[0-9]+$/.test(q.status)) { args.expired = 'false'; args.expires_within_days = q.status.slice(6); }
    return args;
  }
  function listCard() {
    var p = CS.page;
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', 'data-fp-ci-summary': '', text: summary()})];
    if (p.list.length) { parts.push(table()); }
    if (p.truncated) { parts.push(el('p', {class: 'fp-muted', 'data-fp-ci-truncated': '', text: t('cin_truncated')})); }
    var more = p.offset + p.list.length < p.total;
    if (CS.offsets.length > 1 || more) {
      parts.push(el('div', {class: 'fp-actions'}, [
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'prev', disabled: CS.offsets.length > 1 ? null : true, text: t('cin_prev')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'next', disabled: more ? null : true, text: t('cin_next')})]));
    }
    return M.card('fp-ci-list-h', t('cin_list_title'), parts, 'fp-ci-list');
  }
  function draw() {
    var old = CS.root.querySelector('.fp-ci-list');
    var fresh = listCard();
    if (old) { old.replaceWith(fresh); } else { CS.root.appendChild(fresh); }
  }
  /* a page of the list; from a filter's Show, the filter keeps its place and its message */
  function load(offset, form, button) {
    var mine = CS;
    if (button) { UI.setBusy(button, true); }
    return FP.call('get', 'webCertificates', undefined, query(offset)).then(function (r) {
      if (CS !== mine) { return; }
      mine.page = clean(r);
      /* the server answers with the offset asked for; a page that is empty past the end goes back to the first */
      draw();
      if (button) { UI.setBusy(button, false); }
      if (!form) { var h = CS.root.querySelector('#fp-ci-list-h'); if (h) { h.focus(); } }
    }, function (err) {
      if (CS !== mine) { return; }
      if (button) { UI.setBusy(button, false); }
      if (form) { M.failed(form, err); } else { UI.showError(CS.root.querySelector('.fp-ci-list'), err.message); }
    });
  }

  function onClick(e) {
    if (!CS || !CS.root) { return; }
    var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !CS.root.contains(b) || b.disabled) { return; }
    var act = b.getAttribute('data-fp-act');
    if (act === 'next') {
      CS.offsets.push(CS.page.offset + CS.page.list.length);
      load(CS.offsets[CS.offsets.length - 1], null, null);
    } else if (act === 'prev' && CS.offsets.length > 1) {
      CS.offsets.pop();
      load(CS.offsets[CS.offsets.length - 1], null, null);
    }
  }
  document.addEventListener('click', onClick);

  FP.view('tool:ssl_installed', function () {
    CS = null;
    var tool = FP.tools.ssl_installed;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('ssl_installed_desc'), cls: 'fp-mail fp-ci',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    CS = {root: body, q: {account: '', source: '', status: ''}, page: clean(null), offsets: [0]};
    var mine = CS;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'webCertificates', undefined, query(0)).then(function (r) {
      if (CS !== mine) { return; }
      mine.page = clean(r);
      body.textContent = '';
      body.appendChild(M.card('fp-ci-filter-h', t('cin_filter_title'), [filterForm()], 'fp-ci-filter-card'));
      body.appendChild(listCard());
    }, function (err) {
      if (CS !== mine) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

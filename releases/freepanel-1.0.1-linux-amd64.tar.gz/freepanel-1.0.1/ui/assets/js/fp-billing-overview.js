/* freePanel billing overview (#/tool/billing_overview; docs/api.md, "Billing: automation", the overview; docs/billing/navigation-map.md,
   "Overview"): what needs action now, as tiles: unpaid and overdue invoices (count and amount), drafts, orders waiting, tickets by state,
   services by state with the open cancellations, the notices waiting, and the daily run (on or off, the next run and the last). Each tile
   opens the page it counts, when this login has it. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;

  var SVC = ['active', 'suspended', 'cancelled', 'terminated'];
  var TICKETS = ['open', 'customer_reply', 'answered', 'on_hold'];
  function counts(v, keys) { var out = {}; keys.forEach(function (k) { out[k] = B.whole(v && v[k]) || 0; }); return out; }
  function clean(r) {
    if (!r || typeof r !== 'object') { return null; }
    var v = B.pick(r, {currency: [3], drafts: 'n', unpaid: 'n', unpaid_cents: 'c', overdue: 'n', overdue_cents: 'c', pending_orders: 'n', open_cancellations: 'n', queued_notices: 'n'});
    v.currency = B.str(v.currency, 3) || 'USD';
    v.services = counts(r.services, SVC);
    v.tickets = counts(r.tickets, TICKETS);
    var a = r.automation && typeof r.automation === 'object' ? r.automation : {};
    v.automation = {enabled: a.enabled === true, next_run: B.str(a.next_run, 40), last: a.last_run && typeof a.last_run === 'object' ? B.pick(a.last_run, {id: 'id', status: ['=', ['ok', 'errors', 'running']], started: 'w'}) : null};
    return v;
  }
  /* a tile: its name, the figure, a line under it, and the page it opens */
  function tile(key, label, figure, line, tool, linkText, warn) {
    var link = tool && FP.tools[tool] ? el('a', {class: 'sig-link fp-bov-link', href: '#/tool/' + tool, text: linkText}) : null;
    return el('li', {class: 'fp-bov-tile' + (warn ? ' is-warn' : ''), 'data-fp-tile': key}, [el('h3', {class: 'fp-bov-label', id: 'fp-bov-' + key, text: label}),
      el('p', {class: 'fp-bov-figure', text: figure}), line ? el('p', {class: 'fp-muted fp-bov-line', text: line}) : null, link]);
  }
  FP.view('tool:billing_overview', function () {
    var page = B.frame('billing_overview', 'fp-bov');
    if (!page) { return; }
    var alive = function () { return page.isConnected; };
    function draw(v) {
      var n = function (x) { return B.num(x || 0); };
      var waiting = v.tickets.open + v.tickets.customer_reply;
      var a = v.automation;
      var run = !a.enabled ? t('bov_auto_off') : a.next_run ? t('bov_auto_next', {when: B.when(a.next_run)}) : t('bov_auto_soon');
      var last = a.last ? t('bov_auto_last', {when: B.when(a.last.started) || '—', status: t('bov_run_' + (a.last.status || 'ok'))}) : t('bov_auto_never');
      var tiles = [
        tile('unpaid', t('bov_unpaid'), B.money(v.unpaid_cents, v.currency), v.unpaid === 1 ? t('bov_invoices_1') : t('bov_invoices_n', {n: n(v.unpaid)}), 'billing_invoices', t('bov_open_invoices')),
        tile('overdue', t('bov_overdue'), B.money(v.overdue_cents, v.currency), v.overdue === 1 ? t('bov_invoices_1') : t('bov_invoices_n', {n: n(v.overdue)}), 'billing_invoices', t('bov_open_invoices'), v.overdue > 0),
        tile('drafts', t('bov_drafts'), n(v.drafts), t('bov_drafts_line'), 'billing_invoices', t('bov_open_invoices')),
        tile('orders', t('bov_orders'), n(v.pending_orders), t('bov_orders_line'), 'billing_orders', t('bov_open_orders'), v.pending_orders > 0),
        tile('tickets', t('bov_tickets'), n(waiting), t('bov_tickets_line', {answered: n(v.tickets.answered), hold: n(v.tickets.on_hold)}), 'billing_tickets', t('bov_open_tickets'), waiting > 0),
        tile('services', t('bov_services'), n(v.services.active), t('bov_services_line', {suspended: n(v.services.suspended), cancellations: n(v.open_cancellations)}), 'billing_clients', t('bov_open_clients')),
        tile('notices', t('bov_notices'), n(v.queued_notices), t('bov_notices_line'), 'billing_notices', t('bov_open_notices')),
        tile('automation', t('bov_automation'), run, last, 'billing_automation', t('bov_open_automation'), a.last && a.last.status === 'errors')];
      B.screen(page, [B.card('fp-bov-h', t('bov_title'), [el('p', {class: 'fp-muted', text: t('bov_what')}), el('ul', {class: 'fp-bov-tiles', role: 'list'}, tiles),
        el('div', {class: 'fp-actions'}, [B.button('reload', t('bov_refresh'), 'sig-btn--secondary sig-btn--sm')])], 'fp-bov-card', 'overview'), storeCard(store)]);
    }
    /* a reseller's own store (GET /billing/store): where its clients sign up, sign in and order, in its own billing book. The admin's
       page is as it was: the server's store has its own settings pages. */
    var store = null;
    function storeCard(s) {
      if (!s) { return null; }
      return B.card('fp-bov-store-h', t('bov_store_title'), [el('p', {class: 'fp-muted', text: t('bov_store_what')}),
        el('dl', {class: 'fp-bov-store'}, [el('dt', {text: t('bov_store_path')}), el('dd', {}, [el('code', {class: 'fp-bov-store-path', text: s.path})]),
          el('dt', {text: t('bov_store_key')}), el('dd', {}, [el('code', {text: s.key})])]),
        el('p', {class: 'fp-muted', text: t('bov_store_note')})], 'fp-bov-store-card', 'store');
    }
    function readStore() {
      if (FP.session.user.role !== 'reseller') { return Promise.resolve(null); }
      return FP.call('get', 'billingStore').then(function (r) {
        var key = r && /^[A-Za-z0-9_-]{1,100}$/.test(r.store_key) ? r.store_key : '';
        var path = r && typeof r.path === 'string' && /^\/store\?store=[A-Za-z0-9_-]{1,100}$/.test(r.path) ? r.path : '';
        return key && path ? {key: key, path: path} : null;
      }, function () { return null; });
    }
    function load(b) {
      if (b) { UI.setBusy(b, true); }
      Promise.all([FP.call('get', 'billingOverview'), readStore()]).then(function (all) {
        if (!alive()) { return; }
        var v = clean(all[0]);
        store = all[1];
        if (!v) { throw {message: t('api_failed')}; }
        draw(v);
        if (b) { var again = page.querySelector('[data-fp-act="reload"]'); if (again) { again.focus(); } }
      }).catch(function (err) {
        if (!alive()) { return; }
        B.screen(page, [FP.empty(t('bov_title'), err.message, B.button('reload', t('bil_try_again')))]);
      });
    }
    page.addEventListener('click', function (e) {
      var b = e.target && e.target.closest ? e.target.closest('[data-fp-act="reload"]') : null;
      if (b && !b.disabled && alive()) { load(b); }
    });
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    load();
  });
})();

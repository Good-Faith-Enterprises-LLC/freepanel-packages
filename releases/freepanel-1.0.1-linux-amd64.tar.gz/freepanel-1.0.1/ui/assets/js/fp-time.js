/* freePanel time (#/tool/server_time), the admin panel's page for the server's clock (docs/api.md, "Server"): the time and
   zone it keeps, whether it is kept right and by what, correcting the clock now, and changing the time zone, with what the
   change did and a way to put the old zone back. The server answers with the zones it knows and the panel offers only
   those. What the server sends is drawn as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var ZONE_RE = /^[A-Za-z0-9_+-]+(\/[A-Za-z0-9_+-]+){0,2}$/;
  var SERVICES = ['chronyd', 'chrony', 'systemd-timesyncd'];
  var V = null;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function stamp(iso) {
    var d = typeof iso === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(iso) ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d : null;
  }
  function cleanTime(r) {
    var now = r && typeof r === 'object' ? stamp(r.now) : null;
    if (!now) { return null; }
    var off = typeof r.utc_offset_seconds === 'number' && isFinite(r.utc_offset_seconds) && Math.abs(r.utc_offset_seconds) <= 18 * 3600 ? Math.round(r.utc_offset_seconds) : 0;
    var zone = str(r.timezone, 64);
    return {now: now, offset: off, zone: ZONE_RE.test(zone) ? zone : '', automatic: r.automatic === true, synced: r.synchronized === true,
      service: SERVICES.indexOf(r.service) >= 0 ? r.service : '', canZone: r.can_set_zone === true, canSync: r.can_sync === true, rtcLocal: r.rtc_local === true};
  }
  function cleanZones(r) {
    var list = r && typeof r === 'object' && Array.isArray(r.zones) ? r.zones : null;
    if (!list) { return null; }
    return list.filter(function (z, i) { return typeof z === 'string' && z.length <= 64 && ZONE_RE.test(z) && list.indexOf(z) === i; }).slice(0, 1500);
  }
  function cleanEffects(list) {
    return (Array.isArray(list) ? list : []).filter(function (e) { return e && typeof e === 'object' && typeof e.what === 'string'; }).slice(0, 20).map(function (e) {
      return {id: str(e.id, 40), what: str(e.what), from: str(e.from, 64), to: str(e.to, 64), how: str(e.how, 20), note: str(e.note, 600), done: e.done === true};
    });
  }
  function cleanResult(r) {
    if (!r || typeof r !== 'object' || typeof r.timezone !== 'string' || !ZONE_RE.test(r.timezone)) { return null; }
    return {zone: r.timezone, from: ZONE_RE.test(str(r.from, 64)) ? r.from : '', effects: cleanEffects(r.effects),
      warnings: (Array.isArray(r.warnings) ? r.warnings : []).filter(function (w) { return typeof w === 'string' && w; }).slice(0, 10).map(function (w) { return w.slice(0, 300); })};
  }

  /* an offset in seconds as UTC+13:00, UTC-05:30, or UTC */
  function offsetText(sec) {
    if (!sec) { return 'UTC'; }
    var a = Math.abs(sec);
    var h = Math.floor(a / 3600);
    var m = Math.floor((a % 3600) / 60);
    return 'UTC' + (sec < 0 ? '-' : '+') + (h < 10 ? '0' : '') + h + ':' + (m < 10 ? '0' : '') + m;
  }
  function shown(date, offsetSeconds) {
    return new Date(date.getTime() + offsetSeconds * 1000).toLocaleString('en', {timeZone: 'UTC', dateStyle: 'medium', timeStyle: 'medium'});
  }

  function clockCard() {
    var d = V.time;
    var zoneText = d.zone ? t('tm_zone_is', {zone: d.zone, offset: offsetText(d.offset)}) : t('tm_zone_unknown', {offset: offsetText(d.offset)});
    var service = d.automatic ? (d.service ? t('tm_svc_on', {name: d.service}) : t('tm_svc_system')) : t('tm_svc_none');
    var rows = [[t('tm_f_zone'), zoneText, 'zone'], [t('tm_f_utc'), shown(d.now, 0) + ' UTC', 'utc'], [t('tm_f_service'), service, 'service'],
      [t('tm_f_checked'), d.synced ? t('tm_checked_yes') : t('tm_checked_no'), 'checked'], [t('tm_f_hw'), d.rtcLocal ? t('tm_hw_local') : t('tm_hw_utc'), 'hardware']];
    var parts = [el('p', {class: 'fp-tm-now sig-mono', 'data-fp-now': '', text: shown(d.now, d.offset)}),
      el('p', {class: 'fp-muted', text: t('tm_now_note')}), M.errorLine(), M.statusLine()];
    if (!d.automatic) { parts.push(el('p', {class: 'fp-warn-line', 'data-fp-manual': '', text: t('tm_manual')})); }
    if (d.automatic && !d.synced) { parts.push(el('p', {class: 'fp-muted', 'data-fp-unchecked': '', text: t('tm_unchecked')})); }
    parts.push(el('dl', {class: 'fp-mail-facts fp-tm-facts'}, rows.reduce(function (out, r) {
      return out.concat([el('dt', {text: r[0]}), el('dd', {'data-fp-fact': r[2], text: r[1]})]);
    }, [])));
    var acts = [];
    if (d.canSync) { acts.push(el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'sync', text: t('tm_sync')})); }
    acts.push(el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'refresh', text: t('status_again')}));
    parts.push(el('div', {class: 'fp-actions'}, acts));
    if (!d.canSync) { parts.push(el('p', {class: 'fp-muted', 'data-fp-nosync': '', text: t('tm_nosync')})); }
    return M.card('fp-tm-h', t('tm_clock_title'), parts, 'fp-tm');
  }

  /* ---------------- the time zone ---------------- */
  function zoneSelect() {
    var current = V.time.zone;
    var zones = V.zones.slice();
    if (current && zones.indexOf(current) < 0) { zones.unshift(current); }
    var select = el('select', {class: 'sig-select', id: 'fp-tz-zone', name: 'timezone', 'aria-describedby': 'fp-tz-zone-hint'});
    var groups = {};
    var order = [];
    zones.forEach(function (z) {
      var cut = z.indexOf('/');
      var region = cut > 0 ? z.slice(0, cut) : t('tm_other_zones');
      var label = (cut > 0 ? z.slice(cut + 1) : z).replace(/_/g, ' ');
      if (!groups[region]) { groups[region] = el('optgroup', {label: region}); order.push(region); }
      var o = el('option', {value: z, text: label});
      if (z === (V.draft || current)) { o.selected = true; }
      groups[region].appendChild(o);
    });
    /* the regions in the server's order, the names with no region last */
    order.filter(function (r) { return r !== t('tm_other_zones'); }).concat(groups[t('tm_other_zones')] ? [t('tm_other_zones')] : []).forEach(function (r) { select.appendChild(groups[r]); });
    return select;
  }
  function effectItem(e) {
    var parts = [el('span', {class: 'fp-hn-what', text: e.what})];
    var values = e.from && e.to ? t('tm_values', {from: e.from, to: e.to}) : '';
    if (values) { parts.push(el('span', {class: 'sig-mono fp-hn-values', text: values})); }
    if (e.note) { parts.push(el('span', {class: 'fp-muted fp-hn-note', text: e.note})); }
    return el('li', {'data-fp-effect': e.id || null}, parts);
  }
  function group(title, list, kind) {
    if (!list.length) { return null; }
    return el('div', {class: 'fp-hn-group', 'data-fp-group': kind}, [el('h3', {class: 'fp-h3', text: title}), el('ul', {class: 'fp-hn-effects'}, list.map(effectItem))]);
  }
  function formView() {
    var parts = [el('p', {class: 'fp-muted', text: t('tm_zone_what')}), M.statusLine()];
    if (!V.time.canZone) {
      parts.push(el('p', {class: 'fp-warn-line', 'data-fp-nozone': '', text: t('tm_nozone')}));
      return parts;
    }
    if (!V.zones) {
      parts.push(el('p', {class: 'fp-warn-line', 'data-fp-nolist': '', text: t('tm_nolist')}),
        el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'zones', text: t('tm_load_list')})]));
      return parts;
    }
    var select = zoneSelect();
    var form = el('form', {class: 'fp-form fp-tm-form', novalidate: ''}, [M.errorLine(),
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: 'fp-tz-zone', text: t('tm_zone')}), select,
        el('span', {class: 'sig-hint', id: 'fp-tz-zone-hint', text: t('tm_zone_hint')})]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('tm_change')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = form.querySelector('.fp-submit');
      if (b.disabled || V.busy) { return; }
      var zone = select.value;
      V.draft = zone;
      UI.showError(form, '');
      select.removeAttribute('aria-invalid');
      if (!zone || zone === V.time.zone) {
        UI.showError(form, t('tm_same', {zone: V.time.zone}));
        select.setAttribute('aria-invalid', 'true');
        select.focus();
        return;
      }
      change(zone, b, form);
    });
    parts.push(form);
    return parts;
  }
  function resultView() {
    var r = V.result;
    var done = r.effects.filter(function (e) { return e.done; });
    var kept = r.effects.filter(function (e) { return !e.done && e.how === 'kept'; });
    var undone = r.effects.filter(function (e) { return !e.done && e.how !== 'kept'; });
    var parts = [el('p', {class: 'fp-muted', text: t('tm_done_from', {from: r.from || t('tm_zone_unknown_short')})}), M.errorLine(), M.statusLine(),
      group(t('tm_done_list'), done, 'done'), group(t('tm_not_done'), undone, 'undone'), group(t('tm_kept'), kept, 'kept')];
    if (r.warnings.length) {
      parts.push(el('p', {class: 'fp-warn-line', text: t('tm_warn')}), el('ul', {class: 'fp-hn-lines', 'data-fp-lines': 'warnings'}, r.warnings.map(function (x) { return el('li', {text: x}); })));
    }
    var acts = [];
    if (V.kind === 'change' && r.from) {
      acts.push(el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'back', 'aria-label': t('tm_back_of', {zone: r.from}), text: t('tm_back', {zone: r.from})}));
    }
    acts.push(el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'result-close', text: t('tm_close')}));
    parts.push(el('div', {class: 'fp-actions'}, acts));
    return parts.filter(Boolean);
  }
  function zoneCard() {
    var title = t('tm_zone_title');
    var body;
    if (V.mode === 'result') {
      title = t(V.kind === 'back' ? 'tm_back_title' : 'tm_done_title', {zone: V.result.zone});
      body = resultView();
    } else {
      body = formView();
    }
    return M.card('fp-tz-h', title, body, 'fp-tz');
  }
  function drawZone(focus) {
    var old = V.page.querySelector('.fp-tz');
    var made = zoneCard();
    if (old) { old.replaceWith(made); } else { V.page.appendChild(made); }
    var target = focus ? V.page.querySelector(focus) : null;
    if (target) { target.focus(); }
  }
  function drawClock() {
    var old = V.page.querySelector('.fp-tm');
    var made = clockCard();
    if (old) { old.replaceWith(made); } else { V.page.insertBefore(made, V.page.firstChild); }
  }
  function clockCardEl() { return V.page.querySelector('.fp-tm'); }
  function zoneCardEl() { return V.page.querySelector('.fp-tz'); }

  function lock(on) {
    V.busy = on;
    var all = V.page.querySelectorAll('button, select');
    for (var i = 0; i < all.length; i++) { all[i].disabled = on; }
  }
  /* the clock is read again after the zone changed, so the card above shows the new zone */
  function reread() {
    var mine = V;
    return FP.call('get', 'serverTime').then(function (r) {
      var d = cleanTime(r);
      if (V === mine && d) { V.time = d; drawClock(); }
    }, function () {});
  }
  function change(zone, button, form) {
    var mine = V;
    var back = V.kind === 'change' && V.result && V.result.from === zone && V.mode === 'result';
    lock(true);
    UI.setBusy(button, true);
    UI.showError(zoneCardEl(), '');
    M.say(zoneCardEl(), t('tm_changing', {zone: zone}));
    FP.call('put', 'serverTimeZone', {timezone: zone}).then(function (r) {
      if (V !== mine) { return; }
      var result = cleanResult(r);
      lock(false);
      V.result = result || {zone: zone, from: V.time.zone, effects: [], warnings: []};
      V.kind = back ? 'back' : 'change';
      V.mode = 'result';
      V.draft = '';
      drawZone('#fp-tz-h');
      reread();
    }, function (err) {
      if (V !== mine) { return; }
      lock(false);
      UI.setBusy(button, false);
      M.say(zoneCardEl(), '');
      if (form && form.isConnected) {
        var select = form.querySelector('select');
        UI.showError(form, err.message);
        if (select && err.code === 'validation_failed') { select.setAttribute('aria-invalid', 'true'); select.focus(); }
      } else {
        UI.showError(zoneCardEl(), err.message);
        button.focus();
      }
    });
  }

  function onClick(e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !V || !V.page.contains(b) || b.disabled || V.busy) { return; }
    var a = b.getAttribute('data-fp-act');
    var mine = V;
    if (a === 'refresh') {
      UI.setBusy(b, true);
      FP.call('get', 'serverTime').then(function (r) {
        if (V !== mine) { return; }
        var d = cleanTime(r);
        if (!d) { UI.setBusy(b, false); UI.showError(clockCardEl(), t('api_failed')); return; }
        V.time = d;
        drawClock();
        V.page.querySelector('.fp-tm [data-fp-act="refresh"]').focus();
        M.say(clockCardEl(), t('status_checked', {when: new Date().toLocaleTimeString('en', {timeStyle: 'short'})}));
      }, function (err) {
        if (V !== mine) { return; }
        UI.setBusy(b, false);
        UI.showError(clockCardEl(), err.message);
        b.focus();
      });
    } else if (a === 'sync') {
      lock(true);
      UI.setBusy(b, true);
      UI.showError(clockCardEl(), '');
      M.say(clockCardEl(), t('tm_syncing'));
      FP.call('post', 'serverTimeSync').then(function (r) {
        if (V !== mine) { return; }
        lock(false);
        var d = r && typeof r === 'object' ? cleanTime(r.state) : null;
        var how = r && (r.method === 'chrony' || r.method === 'timesyncd') ? r.method : '';
        if (d) { V.time = d; }
        drawClock();
        var again = V.page.querySelector('.fp-tm [data-fp-act="sync"]');
        if (again) { again.focus(); }
        M.say(clockCardEl(), how ? t(how === 'chrony' ? 'tm_synced_chrony' : 'tm_synced_timesyncd') : t('tm_synced'));
      }, function (err) {
        if (V !== mine) { return; }
        lock(false);
        UI.setBusy(b, false);
        M.say(clockCardEl(), '');
        UI.showError(clockCardEl(), err.message);
        b.focus();
      });
    } else if (a === 'back' && V.result && V.result.from) {
      change(V.result.from, b, null);
    } else if (a === 'result-close') {
      V.mode = 'form';
      V.result = null;
      V.draft = '';
      drawZone('#fp-tz-h');
    } else if (a === 'zones') {
      UI.setBusy(b, true);
      FP.call('get', 'serverTimeZones').then(function (r) {
        if (V !== mine) { return; }
        var list = cleanZones(r);
        if (!list) { UI.setBusy(b, false); UI.showError(zoneCardEl(), t('api_failed')); return; }
        V.zones = list;
        drawZone('#fp-tz-zone');
      }, function (err) {
        if (V !== mine) { return; }
        UI.setBusy(b, false);
        UI.showError(zoneCardEl(), err.message);
        b.focus();
      });
    }
  }
  document.addEventListener('click', onClick);

  FP.view('tool:server_time', function () {
    var tool = FP.tools.server_time;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('tm_desc'), cls: 'fp-mail fp-srv fp-tm-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    V = {page: page, time: null, zones: null, mode: 'form', result: null, kind: '', draft: '', busy: false};
    var mine = V;
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'serverTime').then(function (r) {
      if (V !== mine) { return null; }
      var d = cleanTime(r);
      if (!d) {
        page.textContent = '';
        page.appendChild(FP.empty(tool.label, t('api_failed')));
        return null;
      }
      V.time = d;
      return FP.call('get', 'serverTimeZones').then(function (z) { return cleanZones(z); }, function () { return null; }).then(function (list) {
        if (V !== mine) { return; }
        V.zones = list;
        page.textContent = '';
        drawClock();
        drawZone();
      });
    }, function (err) {
      if (V !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

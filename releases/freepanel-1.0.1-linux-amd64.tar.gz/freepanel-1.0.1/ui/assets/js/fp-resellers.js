/* freePanel resellers in the admin panel (docs/api.md, "Resellers" and "Other logins"): #/tool/reseller_list lists
   the resellers with what they have used of their limits, makes new ones, and in each row changes the limits, turns
   the login off or on, turns off its two-factor sign-in (a lost phone), and removes a reseller that owns nothing.
   Admin only: the server refuses these calls to anyone else. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;

  var USER_RE = /^[a-z][a-z0-9]{0,15}$/;
  var EMAIL_RE = /^[^\s@,;"<>]+@[^\s@,;"<>]+\.[^\s@,;"<>]+$/;
  var DOMAIN_RE = /^(?=.{4,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/;
  var PKG_RE = /^[A-Za-z0-9][A-Za-z0-9_ .-]{0,63}$/;
  /* [field, label, usage field, in MB] */
  var LIMITS = [['max_accounts', 'rsl_max_accounts', 'accounts'], ['max_disk_mb', 'rsl_max_disk', 'disk_mb', true],
    ['max_bandwidth_mb', 'rsl_max_bandwidth', 'bandwidth_mb', true]];
  var MAX = 1e12;

  function str(v) { return typeof v === 'string' ? v : ''; }
  function whole(v) { return typeof v === 'number' && isFinite(v) && v >= 0 && v <= MAX && Math.floor(v) === v ? v : null; }
  function cleanReseller(r) {
    if (!r || !USER_RE.test(str(r.username))) { return null; }
    var l = r.limits && typeof r.limits === 'object' ? r.limits : {};
    var u = r.usage && typeof r.usage === 'object' ? r.usage : {};
    var out = {username: r.username, email: str(r.email).slice(0, 254), tf: r.two_factor === true, disabled: r.disabled === true,
      unlimited: u.unlimited === true, domain: DOMAIN_RE.test(str(r.domain)) ? r.domain : ''};
    LIMITS.forEach(function (x) { out[x[0]] = whole(l[x[0]]); out['used_' + x[2]] = whole(u[x[2]]) || 0; });
    return out;
  }
  function mb(n) {
    if (n < 1024) { return t('pkg_mb', {n: n.toLocaleString('en')}); }
    var g = n / 1024;
    if (g < 1024) { return t('pkg_gb', {n: (Math.round(g * 10) / 10).toLocaleString('en')}); }
    return t('pkg_tb', {n: (Math.round(g / 1024 * 10) / 10).toLocaleString('en')});
  }
  function amount(x, v) { return x[3] ? mb(v) : v.toLocaleString('en'); }
  /* "used of limit", or "used (no limit)"; disk and bandwidth say so when some accounts are on unlimited packages */
  function usageText(r, x) {
    var used = r['used_' + x[2]];
    var lim = r[x[0]];
    var s = lim === null ? t('used_no_limit', {used: amount(x, used)}) : t('of_limit', {used: amount(x, used), limit: amount(x, lim)});
    return x[3] && r.unlimited ? s + ' ' + t('rsl_plus_unlimited') : s;
  }

  function errorLine() { return el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': ''}); }
  function fieldError(form, f, message) {
    UI.showError(form, message);
    if (f) {
      f.setAttribute('aria-invalid', 'true');
      f.focus({preventScroll: true});
    }
    var line = form.querySelector('[data-fp-error]');
    if (line && line.scrollIntoView) { line.scrollIntoView({block: 'nearest'}); }
  }
  function failed(form, err) {
    var f = err && err.field ? UI.fieldNamed(form, err.field) : null;
    var label = f ? form.querySelector('label[for="' + f.id + '"]') : null;
    fieldError(form, f, (label ? label.textContent + ': ' : '') + (err ? err.message : t('api_failed')));
  }
  function start(form) {
    var b = form.querySelector('.fp-submit');
    if (b.disabled) { return null; }
    UI.showError(form, '');
    var bad = form.querySelectorAll('[aria-invalid]');
    for (var i = 0; i < bad.length; i++) { bad[i].removeAttribute('aria-invalid'); }
    return b;
  }
  function field(id, label, input, hint) {
    if (hint) { input.setAttribute('aria-describedby', id + '-hint'); }
    return el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: id, text: label}), input,
      hint ? el('span', {class: 'sig-hint', id: id + '-hint', text: hint}) : null]);
  }

  /* one limit: a whole number, or Unlimited, which turns the number off */
  function limitField(prefix, x, value) {
    var id = prefix + '-' + x[0];
    var input = el('input', {class: 'sig-input fp-num-input', id: id, name: x[0], type: 'number', inputmode: 'numeric', min: '0', step: '1',
      max: String(MAX), value: value === null ? '' : String(value), disabled: value === null ? true : null,
      'aria-describedby': x[3] ? id + '-hint' : null});
    var none = el('input', {type: 'checkbox', id: id + '-none', checked: value === null ? true : null});
    none.addEventListener('change', function () {
      input.disabled = none.checked;
      input.removeAttribute('aria-invalid');
      if (!none.checked) {
        if (input.value === '') { input.value = '0'; }
        input.focus();
        input.select();
      }
    });
    return el('div', {class: 'sig-field fp-pkg-limit'}, [el('label', {class: 'sig-label', for: id, text: t(x[1])}),
      el('div', {class: 'fp-pkg-limit-row'}, [input,
        el('label', {class: 'fp-check fp-pkg-none', for: id + '-none'}, [none, el('span', {text: t('unlimited')}),
          el('span', {class: 'sig-vh', text: ' ' + t(x[1])})])]),
      x[3] ? el('span', {class: 'sig-hint', id: id + '-hint', text: t('pkg_in_mb')}) : null]);
  }
  function limitFields(prefix, r) {
    return el('div', {class: 'fp-pkg-limits'}, LIMITS.map(function (x) { return limitField(prefix, x, r ? r[x[0]] : null); }));
  }
  function readLimits(form) {
    var out = {};
    for (var i = 0; i < LIMITS.length; i++) {
      var x = LIMITS[i];
      var input = form.querySelector('[name="' + x[0] + '"]');
      if (input.disabled) { out[x[0]] = null; continue; }
      var v = input.value.trim();
      if (!/^[0-9]{1,13}$/.test(v) || Number(v) > MAX) { fieldError(form, input, t('pkg_bad_number', {field: t(x[1])})); return null; }
      out[x[0]] = Number(v);
    }
    return out;
  }

  /* 20 characters any login form takes as they are */
  var GEN = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789-_.+=';
  function generate() {
    var out = '';
    var buf = new Uint8Array(1);
    while (out.length < 20) {
      window.crypto.getRandomValues(buf);
      if (buf[0] < 256 - (256 % GEN.length)) { out += GEN.charAt(buf[0] % GEN.length); }
    }
    return out;
  }

  var page = null;
  var resellers = [];
  /* the admin's packages, the ones a reseller's own account may be on (a package of no reseller's); null when the
     list can't be had */
  var adminPackages = null;
  /* for each reseller, how many accounts it owns other than its own; null when the account list can't be had */
  var others = null;
  var open = '';   /* the reseller whose limits form is open, or '+' for the new-reseller form */

  function newForm() {
    var user = el('input', {class: 'sig-input sig-mono', id: 'fp-rsl-user', name: 'username', type: 'text', autocomplete: 'off', spellcheck: 'false',
      autocapitalize: 'none', maxlength: '16'});
    var pw = el('input', {class: 'sig-input', id: 'fp-rsl-pw', name: 'password', type: 'password', autocomplete: 'new-password', maxlength: '1024',
      'aria-describedby': 'fp-rsl-pw-hint'});
    var again = el('input', {class: 'sig-input', id: 'fp-rsl-pw-again', name: 'again', type: 'password', autocomplete: 'new-password', maxlength: '1024'});
    var email = el('input', {class: 'sig-input', id: 'fp-rsl-email', name: 'email', type: 'email', autocomplete: 'off', maxlength: '254'});
    var domain = el('input', {class: 'sig-input sig-mono', id: 'fp-rsl-domain', name: 'domain', type: 'text', autocomplete: 'off', spellcheck: 'false',
      autocapitalize: 'none', maxlength: '253'});
    var pkgs = adminPackages || [];
    var pkg = pkgs.length ? el('select', {class: 'sig-select', id: 'fp-rsl-package', name: 'package'},
      [el('option', {value: '', text: t('acct_pick')})].concat(pkgs.map(function (p) { return el('option', {value: p, text: p}); }))) : null;
    var owns = el('input', {type: 'checkbox', id: 'fp-rsl-owns', name: 'owns_itself', 'aria-describedby': 'fp-rsl-owns-hint'});
    var eye = el('button', {class: 'sig-ghost fp-reveal', type: 'button', 'data-overlap-ok': '', 'data-fp-reveal': 'fp-rsl-pw,fp-rsl-pw-again',
      'aria-pressed': 'false', 'aria-label': 'Show password'}, [UI.icon(FP.ui, 'ui_eye')]);
    var gen = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', text: t('acct_generate')});
    gen.addEventListener('click', function () {
      var p = generate();
      pw.value = p;
      again.value = p;
      if (eye.getAttribute('aria-pressed') !== 'true') { eye.click(); }
      UI.announce(t('acct_generated'));
      pw.focus();
      pw.select();
    });
    var form = el('form', {class: 'fp-form fp-pkg-form', novalidate: '', 'aria-labelledby': 'fp-rsl-new-h'}, [
      el('h2', {class: 'fp-h2', id: 'fp-rsl-new-h', text: t('rsl_new')}), errorLine(),
      field('fp-rsl-user', t('acct_username'), user, t('rsl_username_hint')),
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: 'fp-rsl-pw', text: t('label_password')}),
        el('div', {class: 'fp-reveal-wrap'}, [pw, eye]), el('span', {class: 'sig-hint', id: 'fp-rsl-pw-hint', text: t('acct_password_hint')})]),
      field('fp-rsl-pw-again', t('acct_password_again'), again),
      el('div', {class: 'fp-acct-gen'}, [gen]),
      field('fp-rsl-email', t('acct_email'), email, t('rsl_email_hint')),
      el('h3', {class: 'fp-h3', text: t('rsl_own_title')}),
      el('p', {class: 'fp-muted', text: t('rsl_own_desc')}),
      field('fp-rsl-domain', t('acct_domain'), domain, t('acct_domain_hint')),
      pkg ? field('fp-rsl-package', t('acct_package'), pkg, t('rsl_package_hint')) :
        el('p', {class: 'fp-muted', 'data-fp-no-packages': '', text: adminPackages ? t('rsl_no_packages') : t('rsl_packages_failed')}),
      el('div', {class: 'sig-field'}, [el('label', {class: 'fp-check', for: 'fp-rsl-owns'}, [owns, el('span', {text: t('rsl_owns')})]),
        el('span', {class: 'sig-hint', id: 'fp-rsl-owns-hint', text: t('rsl_owns_hint')})]),
      el('h3', {class: 'fp-h3', text: t('rsl_limits_title')}),
      limitFields('fp-rsl-n', null),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('rsl_create'), disabled: pkg ? null : true}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'close', text: t('cancel')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = start(form);
      if (!b) { return; }
      var u = user.value.trim().toLowerCase();
      if (!USER_RE.test(u)) { fieldError(form, user, t('acct_bad_username')); return; }
      if (pw.value.length < 12) { fieldError(form, pw, t('acct_short_password')); return; }
      if (pw.value !== again.value) { fieldError(form, again, t('acct_password_mismatch')); return; }
      var em = email.value.trim();
      if (em && !EMAIL_RE.test(em)) { fieldError(form, email, t('acct_bad_email')); return; }
      var d = domain.value.trim().toLowerCase().replace(/\.$/, '');
      if (!DOMAIN_RE.test(d)) { fieldError(form, domain, t('acct_bad_domain')); return; }
      if (!pkg || !pkg.value) { fieldError(form, pkg, t('acct_pick_package')); return; }
      var limits = readLimits(form);
      if (!limits) { return; }
      var body = {username: u, password: pw.value, domain: d, package: pkg.value, owns_itself: owns.checked, limits: limits};
      if (em) { body.email = em; }
      UI.setBusy(b, true);
      FP.call('post', 'resellers', body).then(function (r) {
        var x = cleanReseller(r);
        if (x) { resellers = resellers.filter(function (y) { return y.username !== x.username; }).concat([x]).sort(byName); }
        if (others) { others[u] = 0; }
        open = '';
        draw(t('rsl_created', {name: u, domain: d}), u, 'limits');
      }, function (err) {
        UI.setBusy(b, false);
        failed(form, err);
      });
    });
    return el('section', {class: 'sig-card'}, [el('div', {class: 'sig-card-body'}, [form])]);
  }

  function limitsRow(r) {
    var form = el('form', {class: 'fp-form fp-pkg-inline', novalidate: ''}, [errorLine(),
      el('p', {class: 'fp-muted', text: t('rsl_limits_for', {name: r.username})}), limitFields('fp-rsl-c', r),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('pkg_save')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'close', text: t('cancel')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = start(form);
      if (!b) { return; }
      var limits = readLimits(form);
      if (!limits) { return; }
      UI.setBusy(b, true);
      FP.call('put', 'resellerLimits', limits, r.username).then(function (x) {
        replace(x, r.username);
        open = '';
        draw(t('pkg_saved', {name: r.username}), r.username, 'limits');
      }, function (err) {
        UI.setBusy(b, false);
        failed(form, err);
      });
    });
    return el('tr', {class: 'fp-pkg-formrow'}, [el('td', {colspan: '8'}, [form])]);
  }
  function replace(x, name) {
    var r = cleanReseller(x);
    if (r) { resellers = resellers.map(function (y) { return y.username === name ? r : y; }); }
  }

  function btn(act, label, aria, extra) {
    var b = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': act, 'aria-label': aria, text: label});
    if (extra) { Object.keys(extra).forEach(function (k) { b.setAttribute(k, extra[k]); }); }
    return b;
  }
  function row(r) {
    var n = r.username;
    return el('tr', {'data-fp-reseller': n}, [
      el('th', {scope: 'row', class: 'sig-mono', text: n}),
      el('td', {class: 'fp-acct-domain', text: r.domain || t('rsl_own_none')}),
      el('td', {class: 'fp-acct-domain', text: r.email || '–'})]
      .concat(LIMITS.map(function (x) { return el('td', {text: usageText(r, x)}); }), [
        el('td', null, [r.disabled ? el('span', {class: 'sig-pill sig-pill--warn', text: t('rsl_login_off')}) : el('span', {class: 'sig-pill sig-pill--ok', text: t('acct_active')}),
          r.tf ? el('span', {class: 'fp-muted fp-acct-reason', text: t('rsl_tf_on')}) : null]),
        el('td', {class: 'fp-pkg-acts'}, [
          btn('limits', t('rsl_limits'), t('rsl_limits_of', {name: n}), {'aria-expanded': String(open === n)}),
          r.disabled ? btn('enable', t('rsl_enable'), t('rsl_enable_of', {name: n})) : btn('disable', t('rsl_disable'), t('rsl_disable_of', {name: n})),
          r.tf ? btn('tf', t('rsl_tf_reset'), t('rsl_tf_reset_of', {name: n})) : null,
          el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'remove',
            'aria-label': t('pkg_remove_of', {name: n}), text: t('pkg_remove')})])]));
  }

  function byName(a, b) { return a.username < b.username ? -1 : 1; }
  function draw(message, focusName, focusAct) {
    page.textContent = '';
    var add = el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'new', 'aria-expanded': String(open === '+'), text: t('rsl_new')});
    var card = el('section', {class: 'sig-card fp-rsl-list'}, [el('div', {class: 'sig-card-body'}, [
      el('div', {class: 'fp-actions fp-pkg-top'}, [add]), errorLine(), el('p', {class: 'fp-ok-line', role: 'status', 'data-fp-status': ''})])]);
    var inner = card.firstChild;
    if (open === '+') { page.appendChild(newForm()); }
    page.appendChild(card);
    if (!resellers.length) {
      inner.appendChild(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('rsl_none')}));
    } else {
      var rows = [];
      resellers.forEach(function (r) {
        rows.push(row(r));
        if (open === r.username) { rows.push(limitsRow(r)); }
      });
      inner.appendChild(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-h1'}, [
        el('table', {class: 'sig-table fp-rsl-table'}, [el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('acct_username')}),
          el('th', {scope: 'col', text: t('rsl_own_account')}), el('th', {scope: 'col', text: t('acct_email')})]
          .concat(LIMITS.map(function (x) { return el('th', {scope: 'col', text: t(x[1])}); }), [
            el('th', {scope: 'col', text: t('acct_status')}),
            el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('acct_actions')})])]))]), el('tbody', null, rows)])]));
    }
    inner.querySelector('[data-fp-status]').textContent = message || '';
    var target = null;
    if (open === '+') {
      target = page.querySelector('#fp-rsl-user');
    } else if (open && open === focusName) {
      target = page.querySelector('.fp-pkg-formrow input:not([disabled])');
    } else if (focusName) {
      target = page.querySelector('tr[data-fp-reseller="' + focusName + '"] [data-fp-act="' + focusAct + '"]');
    } else if (focusAct === 'new') {
      target = add;
    }
    if (target) { target.focus(); }
  }

  /* a question in the row: Cancel takes focus, so a second Enter can't confirm it */
  function ask(tr, act, text, yesLabel) {
    var cell = tr.querySelector('.fp-pkg-acts');
    /* the question's id names its row, so with two open each row's buttons read their own */
    var id = 'fp-rsl-confirm-' + tr.getAttribute('data-fp-reseller');
    cell.textContent = '';
    var yes = el('button', {class: 'sig-btn sig-btn--danger sig-btn--sm', type: 'button', 'data-fp-act': act + '-yes', text: yesLabel});
    var no = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': act + '-no', text: t('cancel')});
    cell.appendChild(el('span', {class: 'fp-pkg-confirm', id: id, text: text}));
    cell.appendChild(yes);
    cell.appendChild(no);
    yes.setAttribute('aria-describedby', id);
    no.setAttribute('aria-describedby', id);
    no.focus();
  }
  function act(b, call, done, n, back) {
    UI.setBusy(b, true);
    call.then(done, function (err) {
      draw('', n, back);
      UI.showError(page.querySelector('.fp-rsl-list'), err.message);
    });
  }

  function onClick(e) {
    var target = e.target.closest ? e.target : null;
    if (!target || !page || !page.contains(target)) { return; }
    var b = target.closest('[data-fp-act]');
    if (!b) { return; }
    var a = b.getAttribute('data-fp-act');
    var tr = b.closest('tr[data-fp-reseller]');
    var n = tr ? tr.getAttribute('data-fp-reseller') : '';
    var r = resellers.filter(function (x) { return x.username === n; })[0];
    if (a === 'new') {
      open = open === '+' ? '' : '+';
      draw('', '', 'new');
    } else if (a === 'limits') {
      open = open === n ? '' : n;
      draw('', n, 'limits');
    } else if (a === 'close') {
      var was = open;
      open = '';
      draw('', was === '+' ? '' : was, was === '+' ? 'new' : 'limits');
    } else if (a === 'disable') {
      ask(tr, 'disable', t('rsl_disable_ask', {name: n}), t('rsl_disable'));
    } else if (a === 'disable-yes') {
      act(b, FP.call('post', 'loginDisable', {}, n), function () {
        r.disabled = true;
        draw(t('rsl_disabled_done', {name: n}), n, 'limits');
      }, n, 'disable');
    } else if (a === 'enable') {
      act(b, FP.call('post', 'loginEnable', {}, n), function () {
        r.disabled = false;
        draw(t('rsl_enabled_done', {name: n}), n, 'disable');
      }, n, 'enable');
    } else if (a === 'tf') {
      ask(tr, 'tf', t('rsl_tf_ask', {name: n}), t('rsl_tf_reset'));
    } else if (a === 'tf-yes') {
      act(b, FP.call('post', 'loginTfReset', {}, n), function () {
        r.tf = false;
        draw(t('rsl_tf_done', {name: n}), n, 'limits');
      }, n, 'tf');
    } else if (a === 'remove') {
      /* its own account doesn't hold up the removal, and goes with it; without the account list there is no count to
         give (the usage figure includes that own account), so the server's answer decides */
      var owned = others ? others[n] || 0 : 0;
      ask(tr, 'remove', owned ? t('rsl_remove_owns', {name: n, n: owned}) :
        r.domain ? t('rsl_remove_ask_own', {name: n, domain: r.domain}) : t('rsl_remove_ask', {name: n}), t('pkg_remove'));
    } else if (a === 'remove-yes') {
      act(b, FP.call('del', 'reseller', undefined, n), function () {
        resellers = resellers.filter(function (x) { return x.username !== n; });
        if (open === n) { open = ''; }
        draw(t('pkg_removed', {name: n}), '', 'new');
      }, n, 'remove');
    } else if (/-no$/.test(a)) {
      draw('', n, a.replace(/-no$/, ''));
    }
  }
  document.addEventListener('click', onClick);

  FP.view('tool:reseller_list', function () {
    var tool = FP.tools.reseller_list;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    open = '';
    page = FP.frame({title: tool.label, desc: t('rsl_desc'), cls: 'fp-rsl',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    var mine = page;
    /* the packages and accounts only shape the form and the remove question: a failed list leaves them out */
    Promise.all([FP.call('get', 'resellers'), FP.call('get', 'packages').catch(function () { return null; }),
      FP.call('get', 'accounts').catch(function () { return null; })]).then(function (x) {
      if (page !== mine) { return; }
      resellers = (x[0] && Array.isArray(x[0].resellers) ? x[0].resellers : []).map(cleanReseller).filter(Boolean).sort(byName);
      var names = {};
      resellers.forEach(function (r) { names[r.username] = true; });
      adminPackages = x[1] && Array.isArray(x[1].packages) ? x[1].packages.filter(function (p) {
        return p && PKG_RE.test(str(p.name)) && !names[str(p.owner)];
      }).map(function (p) { return p.name; }) : null;
      others = null;
      if (x[2] && Array.isArray(x[2].accounts)) {
        others = {};
        x[2].accounts.forEach(function (a) {
          if (a && names[str(a.owner)] && a.username !== a.owner) { others[a.owner] = (others[a.owner] || 0) + 1; }
        });
      }
      draw('');
    }, function (err) {
      if (page !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

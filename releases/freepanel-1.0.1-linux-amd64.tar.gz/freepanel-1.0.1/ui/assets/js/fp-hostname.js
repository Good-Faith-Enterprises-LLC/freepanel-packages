/* freePanel hostname (#/tool/server_hostname), the admin panel's page for the server's own name (docs/api.md, "Server"):
   what it is now and whether DNS, reverse DNS, the system and the certificates agree, a plan of what changing it does
   (nothing is changed until the admin confirms it), the change, and putting the old name back. The plan comes from the
   server, which makes it again for the change; the panel sends only the name. The panel and the server agent restart a
   few seconds after a change or a revert, so the page waits for the panel to answer again. What the server sends is
   drawn as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var NAME_RE = /^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$/;
  var POLL_MS = 1500;
  var WAIT_MS = 90000;
  var V = null;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function strs(list, n) {
    return (Array.isArray(list) ? list : []).filter(function (v) { return typeof v === 'string' && v; }).slice(0, n || 20).map(function (v) { return v.slice(0, 300); });
  }
  function when(iso) {
    var d = typeof iso === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(iso) ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'}) : '—';
  }
  function day(iso) {
    var d = typeof iso === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(iso) ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleDateString('en', {dateStyle: 'medium'}) : '—';
  }
  function cleanCert(c) {
    return c && typeof c === 'object' ? {names: strs(c.names, 20), source: str(c.source, 20), until: str(c.not_after, 40)} : null;
  }
  function cleanChange(c) {
    return c && typeof c === 'object' && typeof c.from === 'string' && typeof c.to === 'string' ?
      {from: str(c.from), to: str(c.to), at: str(c.at, 40), complete: c.complete !== false} : null;
  }
  function cleanInfo(r) {
    if (!r || typeof r !== 'object' || typeof r.hostname !== 'string') { return null; }
    return {name: str(r.hostname), system: str(r.system_hostname), matches: r.matches === true, checked: r.dns_checked === true, resolves: strs(r.resolves_to),
      here: r.points_here === true, reverse: strs(r.reverse), reverseOk: r.reverse_matches === true, panelUrl: str(r.panel_url), customerUrl: str(r.customer_url),
      panelCert: cleanCert(r.panel_certificate), serverCert: cleanCert(r.server_certificate), change: cleanChange(r.change)};
  }
  function cleanEffects(list) {
    return (Array.isArray(list) ? list : []).filter(function (e) { return e && typeof e === 'object' && typeof e.what === 'string'; }).slice(0, 40).map(function (e) {
      return {id: str(e.id, 40), what: str(e.what), from: str(e.from), to: str(e.to), how: str(e.how, 20), note: str(e.note, 600), done: e.done === true};
    });
  }
  function cleanPlan(r) {
    if (!r || typeof r !== 'object' || typeof r.hostname !== 'string') { return null; }
    return {name: str(r.hostname), from: str(r.from), blockers: strs(r.blockers), warnings: strs(r.warnings), effects: cleanEffects(r.effects)};
  }
  function cleanResult(r) {
    if (!r || typeof r !== 'object' || typeof r.hostname !== 'string') { return null; }
    return {name: str(r.hostname), from: str(r.from), effects: cleanEffects(r.effects), warnings: strs(r.warnings), restarting: r.restarting === true};
  }
  function normalize(v) { return v.trim().toLowerCase().replace(/\.$/, ''); }

  function card() { return V.page.querySelector('.fp-hn'); }
  function changeCard() { return V.page.querySelector('.fp-hc'); }

  /* ---------------- what the hostname is now ---------------- */
  function certLine(c) {
    if (!c) { return null; }
    var src = {'self-signed': 'hn_src_self', free: 'hn_src_free', installed: 'hn_src_installed'}[c.source];
    return t('hn_cert', {names: c.names.join(', ') || '—', source: src ? t(src) : c.source, date: day(c.until)});
  }
  function dnsLine(i) {
    if (!i.checked) { return t('hn_dns_unknown'); }
    if (i.here && i.resolves.length) { return t('hn_dns_here', {name: i.name, addresses: i.resolves.join(', ')}); }
    return i.resolves.length ? t('hn_dns_elsewhere', {name: i.name, addresses: i.resolves.join(', ')}) : t('hn_dns_none', {name: i.name});
  }
  function reverseLine(i) {
    if (i.reverseOk) { return t('hn_rev_ok', {name: i.name}); }
    return i.reverse.length ? t('hn_rev_other', {names: i.reverse.join(', '), name: i.name}) : t('hn_rev_none');
  }
  function facts(i) {
    var rows = [[t('hn_f_system'), i.system || t('hn_unknown'), true], [t('hn_f_panel'), i.panelUrl || '—', true], [t('hn_f_customers'), i.customerUrl || '—', true],
      [t('hn_f_dns'), dnsLine(i), false, 'dns'], [t('hn_f_reverse'), reverseLine(i), false, 'reverse'],
      [t('hn_f_panel_cert'), certLine(i.panelCert) || '—', false, 'panel-cert']];
    if (i.serverCert) { rows.push([t('hn_f_server_cert'), certLine(i.serverCert), false, 'server-cert']); }
    if (i.change) {
      rows.push([t('hn_f_change'), t('hn_change_line', {from: i.change.from, to: i.change.to, when: when(i.change.at)}), false, 'change']);
    }
    return el('dl', {class: 'fp-mail-facts fp-hn-facts'}, rows.reduce(function (out, r) {
      return out.concat([el('dt', {text: r[0]}), el('dd', {class: r[2] ? 'sig-mono' : null, 'data-fp-fact': r[3] || null, text: r[1]})]);
    }, []));
  }
  function revertArea(i) {
    if (!i.change) { return null; }
    var parts = [];
    if (!i.change.complete) { parts.push(el('p', {class: 'fp-warn-line', 'data-fp-unfinished': '', text: t('hn_change_unfinished')})); }
    parts.push(el('div', {class: 'fp-hn-revert', 'data-fp-revert': ''}, [revertButton(i)]));
    return el('div', null, parts);
  }
  function revertButton(i) {
    return el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'revert', 'aria-label': t('hn_revert_of', {from: i.change.from}),
      text: t('hn_revert', {from: i.change.from})});
  }
  function stateCard() {
    var i = V.info;
    var parts = [el('p', {class: 'fp-hn-name sig-mono', 'data-fp-hostname': '', text: i.name})];
    if (!i.matches && i.system) { parts.push(el('p', {class: 'fp-warn-line', 'data-fp-differs': '', text: t('hn_differs', {system: i.system, name: i.name})})); }
    parts.push(M.errorLine(), M.statusLine(), facts(i), revertArea(i),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'refresh', text: t('status_again')})]));
    return M.card('fp-hn-h', t('hn_now_title'), parts.filter(Boolean), 'fp-hn');
  }

  /* ---------------- the hostname's address record (docs/api.md, "The hostname's address record") ----------------
     Whether a zone this server serves has the A (and AAAA) record of the hostname, and adding it in one step; when no zone
     here holds the name, the records to add where the domain's DNS is kept. The server picks the name and the addresses;
     the panel sends only the zone's serial and whether other addresses are replaced. */
  var REC_TYPES = ['A', 'AAAA'];
  var REC_STATES = ['ok', 'missing', 'other'];
  var ADDR_RE = /^[0-9A-Fa-f:.]{2,45}$/;
  var REC_TTL = 14400;

  function whole(v) { return typeof v === 'number' && isFinite(v) && v >= 0 && Math.floor(v) === v ? v : 0; }
  function addr(v) { v = str(v, 45); return ADDR_RE.test(v) ? v : ''; }
  function cleanRecs(r) {
    if (!r || typeof r !== 'object' || typeof r.hostname !== 'string') { return null; }
    var host = str(r.hostname, 253).toLowerCase();
    return {can: r.can_serve === true, host: NAME_RE.test(host) ? host : '', zone: str(r.zone, 253), account: str(r.account, 64), name: str(r.name, 253),
      serial: whole(r.serial), held: r.held === true, blocked: str(r.blocked, 600), v6Reason: str(r.ipv6_reason, 300), ns: strs(r.nameservers, 8),
      records: (Array.isArray(r.records) ? r.records : []).filter(function (x) { return x && typeof x === 'object' && REC_TYPES.indexOf(x.type) >= 0 && addr(x.want); }).slice(0, 4)
        .map(function (x) {
          return {type: x.type, want: addr(x.want), have: strs(x.have, 20).map(addr).filter(Boolean), state: REC_STATES.indexOf(x.state) >= 0 ? x.state : ''};
        })};
  }
  function recCard() { return V.page.querySelector('.fp-hna'); }
  function recLines(r) {
    return r.records.map(function (x) { return r.host + '.  ' + REC_TTL + '  IN  ' + x.type + '  ' + x.want; }).join('\n');
  }
  function recItem(r, x) {
    var pill = {ok: ' sig-pill--ok', missing: ' sig-pill--warn', other: ' sig-pill--warn'}[x.state];
    var parts = [el('span', {class: 'fp-hna-rec'}, [el('span', {class: 'sig-mono fp-hna-type', text: x.type}), el('span', {class: 'sig-mono fp-hna-want', text: x.want}),
      el('span', {class: 'sig-pill' + pill, text: t('hna_st_' + x.state)})])];
    if (x.state === 'other') { parts.push(el('span', {class: 'fp-muted fp-hna-have', text: t('hna_have', {name: r.host, addresses: x.have.join(', ')})})); }
    return el('li', {'data-fp-rec': x.type, 'data-fp-state': x.state}, parts);
  }
  function addButton(r) {
    var need = r.records.filter(function (x) { return x.state !== 'ok'; });
    var other = need.some(function (x) { return x.state === 'other'; });
    var label = other ? t('hna_replace', {name: r.host}) : t(need.length > 1 ? 'hna_add_many' : 'hna_add_one');
    return el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': other ? 'rec-replace' : 'rec-add', text: label});
  }
  function recBody(r) {
    var parts = [];
    if (r.can && r.zone) {
      parts.push(el('p', {'data-fp-rec-zone': '', text: t('hna_in_zone', {name: r.host, zone: r.zone, account: r.account})}));
      if (r.held) { parts.push(el('p', {class: 'fp-warn-line', 'data-fp-held': '', text: t('hna_held', {zone: r.zone})})); }
      if (!r.records.length) { parts.push(el('p', {class: 'fp-warn-line', text: t('hna_no_address')})); return parts; }
      parts.push(el('ul', {class: 'fp-hna-recs'}, r.records.map(function (x) { return recItem(r, x); })));
      var hasV6 = r.records.some(function (x) { return x.type === 'AAAA'; });
      if (!hasV6 && r.v6Reason) { parts.push(el('p', {class: 'fp-muted', text: t('hna_no_v6', {why: r.v6Reason})})); }
      var need = r.records.some(function (x) { return x.state !== 'ok'; });
      if (r.blocked) {
        parts.push(el('div', {class: 'sig-banner sig-banner--warn fp-hna-blocked', role: 'note', 'data-fp-blocked': ''}, [UI.icon(FP.ui, 'ui_warning'),
          el('span', null, [document.createTextNode(t('hna_blocked', {why: r.blocked}) + ' '), el('a', {href: '#/tool/dns_zones', text: t('hna_zones_link')})])]));
      } else if (need) {
        parts.push(el('div', {class: 'fp-actions fp-hna-acts'}, [addButton(r)]));
      } else {
        parts.push(el('p', {class: 'fp-hna-done', 'data-fp-rec-done': ''}, [UI.icon(FP.ui, 'ui_check'), el('span', {text: t('hna_all_ok')})]));
      }
      if (r.ns.length) { parts.push(el('p', {class: 'fp-muted', text: t('hna_ns_note', {zone: r.zone, ns: r.ns.join(', ')})})); }
      return parts;
    }
    var parent = r.host.split('.').slice(1).join('.') || r.host;
    parts.push(el('p', {'data-fp-rec-elsewhere': '', text: t(r.can ? 'hna_not_here' : 'hna_no_dns', {name: r.host, parent: parent})}));
    if (!r.records.length) { parts.push(el('p', {class: 'fp-warn-line', text: t('hna_no_address')})); return parts; }
    var text = recLines(r);
    parts.push(el('pre', {class: 'sig-mono fp-hna-lines', tabindex: '0', role: 'region', 'aria-label': t('hna_records_label'), text: text}),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'rec-copy', 'data-fp-copy': text, text: t('hna_copy')})]));
    if (!r.records.some(function (x) { return x.type === 'AAAA'; }) && r.v6Reason) { parts.push(el('p', {class: 'fp-muted', text: t('hna_no_v6', {why: r.v6Reason})})); }
    return parts;
  }
  function recView() {
    var parts = [el('p', {class: 'fp-muted', text: t('hna_what')}), M.errorLine(), M.statusLine()];
    if (V.rec) { parts = parts.concat(recBody(V.rec)); } else if (!V.recErr) { parts.push(el('p', {class: 'fp-muted', 'data-fp-rec-loading': '', text: t('hna_loading')})); }
    if (V.rec || V.recErr) {
      parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'rec-refresh', text: t('hna_again')})]));
    }
    return M.card('fp-hna-h', t('hna_title'), parts, 'fp-hna');
  }
  function drawRec(focus) {
    var old = recCard();
    var made = recView();
    if (old) { old.replaceWith(made); } else { var s = card(); if (s) { s.after(made); } else { V.page.appendChild(made); } }
    if (V.recErr) { UI.showError(made, V.recErr); }
    var target = focus ? made.querySelector(focus) : null;
    if (target) { target.focus(); }
  }
  function loadRec(after) {
    var mine = V;
    return FP.call('get', 'dnsHostname').then(function (r) {
      if (V !== mine) { return; }
      var rec = cleanRecs(r);
      V.rec = rec && rec.host ? rec : null;
      V.recErr = V.rec ? '' : t('api_failed');
      drawRec();
      if (after) { after(); }
    }, function (err) {
      if (V !== mine) { return; }
      V.rec = null;
      V.recErr = err.message;
      drawRec();
      if (after) { after(); }
    });
  }
  function addRec(b, replace) {
    var mine = V;
    var r = V.rec;
    V.busy = true;
    UI.setBusy(b, true);
    UI.showError(recCard(), '');
    M.say(recCard(), t('hna_adding'));
    FP.call('post', 'dnsHostname', {serial: r.serial, replace: replace}).then(function (res) {
      if (V !== mine) { return; }
      V.busy = false;
      var rec = cleanRecs(res);
      if (rec && rec.host) { V.rec = rec; V.recErr = ''; }
      drawRec('#fp-hna-h');
      M.say(recCard(), t('hna_added'));
    }, function (err) {
      if (V !== mine) { return; }
      V.busy = false;
      drawRec();
      UI.showError(recCard(), err.message);
      var again = recCard().querySelector('[data-fp-act="rec-add"], [data-fp-act="rec-replace"], [data-fp-act="rec-refresh"]');
      if (again) { again.focus(); }
    });
  }
  function recClick(b, a) {
    var c = recCard();
    if (a === 'rec-refresh') {
      UI.setBusy(b, true);
      loadRec(function () {
        var again = recCard().querySelector('[data-fp-act="rec-refresh"]');
        if (again) { again.focus(); }
        if (!V.recErr) { M.say(recCard(), t('status_checked', {when: new Date().toLocaleTimeString('en', {timeStyle: 'short'})})); }
      });
    } else if (a === 'rec-add' && V.rec) {
      addRec(b, false);
    } else if (a === 'rec-replace' && V.rec) {
      var other = V.rec.records.filter(function (x) { return x.state === 'other'; });
      M.confirmIn(b.closest('.fp-hna-acts'), t('hna_replace_ask', {name: V.rec.host,
        have: other.map(function (x) { return x.have.join(', '); }).join(', '), want: other.map(function (x) { return x.want; }).join(', ')}), 'rec-replace-yes', t('hna_replace_yes'));
    } else if (a === 'rec-replace-yes' && V.rec) {
      addRec(b, true);
    } else if (a === 'confirm-no') {
      var acts = b.closest('.fp-hna-acts');
      acts.textContent = '';
      acts.appendChild(addButton(V.rec));
      acts.querySelector('button').focus();
    } else if (a === 'rec-copy') {
      var text = b.getAttribute('data-fp-copy');
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(function () { M.say(c, t('copied')); }, function () { M.say(c, t('copy_failed')); });
      } else {
        M.say(c, t('copy_failed'));
      }
    }
  }

  /* ---------------- changing it ---------------- */
  function effectItem(e) {
    var parts = [el('span', {class: 'fp-hn-what', text: e.what})];
    var values = e.from && e.to ? t('hn_values', {from: e.from, to: e.to}) : (e.to ? t('hn_to', {to: e.to}) : '');
    if (values) { parts.push(el('span', {class: 'sig-mono fp-hn-values', text: values})); }
    if (e.note) { parts.push(el('span', {class: 'fp-muted fp-hn-note', text: e.note})); }
    return el('li', {'data-fp-effect': e.id || null}, parts);
  }
  function group(title, list, kind) {
    if (!list.length) { return null; }
    return el('div', {class: 'fp-hn-group', 'data-fp-group': kind}, [el('h3', {class: 'fp-h3', text: title}), el('ul', {class: 'fp-hn-effects'}, list.map(effectItem))]);
  }
  function textList(list, kind) {
    return el('ul', {class: 'fp-hn-lines', 'data-fp-lines': kind}, list.map(function (x) { return el('li', {text: x}); }));
  }

  function formView() {
    var input = el('input', {class: 'sig-input', id: 'fp-hn-new', name: 'hostname', type: 'text', maxlength: '253', autocomplete: 'off', spellcheck: 'false',
      autocapitalize: 'none', 'aria-describedby': 'fp-hn-new-hint'});
    input.value = V.draft || '';
    var form = el('form', {class: 'fp-form fp-hn-form', novalidate: ''}, [M.errorLine(),
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: 'fp-hn-new', text: t('hn_new')}), input,
        el('span', {class: 'sig-hint', id: 'fp-hn-new-hint', text: t('hn_new_hint')})]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('hn_plan')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = form.querySelector('.fp-submit');
      if (b.disabled || V.busy) { return; }
      var mine = V;
      var name = normalize(input.value);
      V.draft = input.value;
      UI.showError(form, '');
      input.removeAttribute('aria-invalid');
      var mark = function (message) { UI.showError(form, message); input.setAttribute('aria-invalid', 'true'); input.focus(); };
      if (!name || name.length > 253 || !NAME_RE.test(name)) { mark(t('hn_bad_name')); return; }
      if (name === V.info.name.toLowerCase() && V.info.matches) { mark(t('hn_same_name', {name: name})); return; }
      UI.setBusy(b, true);
      V.busy = true;
      M.say(changeCard(), t('hn_planning'));
      FP.call('post', 'hostnamePlan', {hostname: name}).then(function (r) {
        if (V !== mine) { return; }
        V.busy = false;
        var plan = cleanPlan(r);
        if (!plan) { UI.setBusy(b, false); M.say(changeCard(), ''); UI.showError(form, t('api_failed')); return; }
        V.plan = plan;
        V.mode = 'plan';
        drawChange('#fp-hc-h');
      }, function (err) {
        if (V !== mine) { return; }
        V.busy = false;
        UI.setBusy(b, false);
        M.say(changeCard(), '');
        if (err.code === 'validation_failed') { mark(err.message); } else { UI.showError(form, err.message); }
      });
    });
    return [el('p', {class: 'fp-muted', text: t('hn_change_what')}), M.statusLine(), form];
  }
  function planView() {
    var p = V.plan;
    var by = function (how) { return p.effects.filter(function (e) { return e.how === how; }); };
    var parts = [M.errorLine(), M.statusLine()];
    if (p.blockers.length) {
      parts.push(el('p', {class: 'fp-warn-line', text: t('hn_blocked')}), textList(p.blockers, 'blockers'));
    } else {
      if (p.warnings.length) { parts.push(el('p', {class: 'fp-warn-line', text: t('hn_warn')}), textList(p.warnings, 'warnings')); }
      parts.push(group(t('hn_auto'), by('automatic'), 'automatic'), group(t('hn_kept'), by('kept'), 'kept'), group(t('hn_hand'), by('by_hand'), 'by_hand'),
        el('p', {class: 'fp-muted', text: t('hn_restart_note')}));
    }
    var acts = [];
    if (!p.blockers.length) {
      acts.push(el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'apply', text: t('hn_go', {to: p.name})}));
    }
    acts.push(el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'plan-back', text: p.blockers.length ? t('hn_close') : t('cancel')}));
    parts.push(el('div', {class: 'fp-actions'}, acts));
    return parts.filter(Boolean);
  }
  function newAddress(name) {
    try {
      var u = new URL(V.info.panelUrl);
      if (u.protocol !== 'https:' || !NAME_RE.test(name)) { return ''; }
      u.hostname = name;
      return u.href;
    } catch (e) {
      return '';
    }
  }
  function resultView() {
    var r = V.result;
    var done = r.effects.filter(function (e) { return e.done; });
    var left = r.effects.filter(function (e) { return !e.done && e.how === 'by_hand'; });
    var parts = [el('p', {class: 'fp-muted', text: t('hn_done_from', {from: r.from})}), M.errorLine(), M.statusLine()];
    if (r.restarting) {
      parts.push(el('p', {class: 'fp-hn-restart', role: 'status', 'data-fp-restart': '', text: V.restartText || t('hn_restarting')}));
      var url = V.slow && V.kind === 'change' ? newAddress(r.name) : '';
      if (url) { parts.push(el('p', {class: 'fp-hn-open'}, [el('a', {href: url, rel: 'noopener noreferrer', text: t('hn_open')})])); }
    }
    parts.push(group(t('hn_done_list'), done, 'done'));
    if (V.kind === 'change') {
      parts.push(left.length ? group(t('hn_todo'), left, 'todo') : el('p', {class: 'fp-muted', text: t('hn_nothing')}));
    }
    if (r.warnings.length && V.kind === 'change') { parts.push(el('p', {class: 'fp-warn-line', text: t('hn_warn_after')}), textList(r.warnings, 'warnings')); }
    parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'result-close', text: t('hn_close')})]));
    return parts.filter(Boolean);
  }
  function drawChange(focus) {
    var title = t('hn_change_title');
    var body;
    if (V.mode === 'plan') {
      title = t('hn_plan_title', {from: V.plan.from, to: V.plan.name});
      body = planView();
    } else if (V.mode === 'result') {
      title = t(V.kind === 'revert' ? 'hn_reverted' : 'hn_done_title', {name: V.result.name});
      body = resultView();
    } else {
      body = formView();
    }
    var old = changeCard();
    var made = M.card('fp-hc-h', title, body, 'fp-hc');
    if (old) { old.replaceWith(made); } else { V.page.appendChild(made); }
    var target = focus ? V.page.querySelector(focus) : null;
    if (target) { target.focus(); }
  }
  function drawState() {
    var old = card();
    var made = stateCard();
    if (old) { old.replaceWith(made); } else { V.page.insertBefore(made, V.page.firstChild); }
  }

  /* the panel restarts after a change or a revert; ask until it answers as the new name */
  function waitBack(name) {
    var mine = V;
    var started = Date.now();
    function say(text) {
      V.restartText = text;
      var line = V.page.querySelector('[data-fp-restart]');
      if (line) { line.textContent = text; }
    }
    function again() {
      if (V !== mine) { return; }
      if (Date.now() - started > WAIT_MS) {
        V.slow = true;
        var url = newAddress(name);
        say(url ? t('hn_slow', {url: url}) : t('hn_slow', {url: name}));
        if (V.mode === 'result') { drawChange(); }
        return;
      }
      window.setTimeout(poll, POLL_MS);
    }
    function poll() {
      if (V !== mine) { return; }
      FP.call('get', 'serverHostname').then(function (r) {
        if (V !== mine) { return; }
        var info = cleanInfo(r);
        if (!info || info.name.toLowerCase() !== name.toLowerCase()) { again(); return; }
        V.info = info;
        drawState();
        say(t('hn_back_up'));
        loadRec();
      }, again);
    }
    window.setTimeout(poll, POLL_MS);
  }

  function lock(on) {
    V.busy = on;
    var all = V.page.querySelectorAll('button, input');
    for (var i = 0; i < all.length; i++) { all[i].disabled = on; }
  }
  function finish(kind, r) {
    var mine = V;
    var result = cleanResult(r);
    lock(false);
    V.kind = kind;
    V.result = result || {name: V.plan ? V.plan.name : '', from: V.info.name, effects: [], warnings: [], restarting: true};
    V.mode = 'result';
    V.slow = false;
    V.restartText = '';
    drawChange('#fp-hc-h');
    if (V.result.restarting) {
      waitBack(V.result.name);
    } else {
      FP.call('get', 'serverHostname').then(function (r) {
        var info = cleanInfo(r);
        if (V === mine && info) { V.info = info; drawState(); loadRec(); }
      }, function () {});
    }
  }
  function onClick(e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !V || !V.page.contains(b) || b.disabled || V.busy) { return; }
    var a = b.getAttribute('data-fp-act');
    var mine = V;
    if (a.indexOf('rec-') === 0 || (a === 'confirm-no' && b.closest('.fp-hna'))) {
      recClick(b, a);
    } else if (a === 'refresh') {
      UI.setBusy(b, true);
      FP.call('get', 'serverHostname').then(function (r) {
        if (V !== mine) { return; }
        var info = cleanInfo(r);
        if (!info) { UI.setBusy(b, false); UI.showError(card(), t('api_failed')); return; }
        V.info = info;
        drawState();
        V.page.querySelector('.fp-hn [data-fp-act="refresh"]').focus();
        M.say(card(), t('status_checked', {when: new Date().toLocaleTimeString('en', {timeStyle: 'short'})}));
      }, function (err) {
        if (V !== mine) { return; }
        UI.setBusy(b, false);
        UI.showError(card(), err.message);
        b.focus();
      });
    } else if (a === 'revert' && V.info.change) {
      var holder = b.closest('.fp-hn-revert');
      M.confirmIn(holder, t('hn_revert_ask', {from: V.info.change.from}), 'revert-yes', t('hn_revert_yes'));
    } else if (a === 'confirm-no') {
      var area = b.closest('.fp-hn-revert');
      area.textContent = '';
      area.appendChild(revertButton(V.info));
      area.querySelector('button').focus();
    } else if (a === 'revert-yes') {
      var from = V.info.change.from;
      lock(true);
      UI.setBusy(b, true);
      UI.showError(card(), '');
      M.say(card(), t('hn_reverting', {from: from}));
      FP.call('post', 'hostnameRevert').then(function (r) {
        if (V !== mine) { return; }
        M.say(card(), '');
        finish('revert', r);
      }, function (err) {
        if (V !== mine) { return; }
        lock(false);
        UI.setBusy(b, false);
        M.say(card(), '');
        UI.showError(card(), err.message);
      });
    } else if (a === 'apply' && V.plan && !V.plan.blockers.length) {
      var plan = V.plan;
      lock(true);
      UI.setBusy(b, true);
      UI.showError(changeCard(), '');
      M.say(changeCard(), t('hn_changing', {to: plan.name}));
      FP.call('post', 'serverHostname', {hostname: plan.name}).then(function (r) {
        if (V !== mine) { return; }
        finish('change', r);
      }, function (err) {
        if (V !== mine) { return; }
        lock(false);
        UI.setBusy(b, false);
        M.say(changeCard(), '');
        UI.showError(changeCard(), err.message);
        b.focus();
      });
    } else if (a === 'plan-back') {
      V.mode = 'form';
      V.plan = null;
      drawChange('#fp-hn-new');
    } else if (a === 'result-close') {
      V.mode = 'form';
      V.plan = null;
      V.result = null;
      V.draft = '';
      drawChange('#fp-hc-h');
    }
  }
  document.addEventListener('click', onClick);

  FP.view('tool:server_hostname', function () {
    var tool = FP.tools.server_hostname;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('hn_desc'), cls: 'fp-mail fp-srv fp-hn-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    V = {page: page, info: null, mode: 'form', plan: null, result: null, kind: '', draft: '', busy: false, slow: false, restartText: '', rec: null, recErr: ''};
    var mine = V;
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'serverHostname').then(function (r) {
      if (V !== mine) { return; }
      var info = cleanInfo(r);
      page.textContent = '';
      if (!info) { page.appendChild(FP.empty(tool.label, t('api_failed'))); return; }
      V.info = info;
      drawState();
      drawRec();
      drawChange();
      loadRec();
    }, function (err) {
      if (V !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

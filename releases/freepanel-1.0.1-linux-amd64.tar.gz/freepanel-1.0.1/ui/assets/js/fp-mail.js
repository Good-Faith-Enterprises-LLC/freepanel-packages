/* freePanel email (docs/api.md, "Email"): the customer panel's Mailboxes (#/tool/mailboxes), Forwarding
   (#/tool/forwarding) and Auto-replies (#/tool/auto_replies) pages. Every page reads the account's mail with one call
   and every change answers with the whole of it again. A name the account's sites answer on can carry mail; the list
   says when a domain's mail goes to another server (its DNS doesn't send it here). FP.mail holds what the filters page
   (fp-mailfilters.js) shares. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;

  /* an address as the server keeps it: lowercase, letters, digits, '.', '_', '+' and '-' before the @ */
  var LOCAL_RE = /^[a-z0-9_+-]+(\.[a-z0-9_+-]+)*$/;
  var DOMAIN_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var MAX_QUOTA = 1048576;
  var MAX_TO = 20;

  function str(v) { return typeof v === 'string' ? v : ''; }
  function isAddress(a) {
    a = str(a);
    var i = a.lastIndexOf('@');
    return i > 0 && i <= 64 && a.length <= 254 && LOCAL_RE.test(a.slice(0, i)) && DOMAIN_RE.test(a.slice(i + 1));
  }
  function addresses(list) {
    return (Array.isArray(list) ? list : []).filter(isAddress);
  }
  /* a time from the server, or null */
  function when(v) {
    if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}T/.test(v)) { return null; }
    var d = new Date(v);
    return isNaN(d.getTime()) ? null : d;
  }
  function autoOf(a) {
    if (!a || typeof a !== 'object') { return null; }
    var hours = typeof a.interval_hours === 'number' && a.interval_hours >= 1 && a.interval_hours <= 720 ? Math.floor(a.interval_hours) : 8;
    return {from: str(a.from), subject: str(a.subject), body: str(a.body), hours: hours, start: when(a.start), stop: when(a.stop)};
  }
  /* filters stay as the server sent them, checked by the filters page before it shows them */
  function filtersOf(list) { return Array.isArray(list) ? list.filter(function (f) { return f && typeof f === 'object'; }) : []; }
  function clean(v) {
    v = v && typeof v === 'object' ? v : {};
    var boxes = (Array.isArray(v.mailboxes) ? v.mailboxes : []).filter(function (m) { return m && isAddress(m.address); }).map(function (m) {
      return {address: m.address, quota: typeof m.quota_mb === 'number' && m.quota_mb >= 0 && m.quota_mb <= MAX_QUOTA ? Math.floor(m.quota_mb) : null,
        served: m.served === true, filters: filtersOf(m.filters), auto: autoOf(m.autoresponder), responding: m.responding === true};
    }).sort(function (a, b) { return a.address < b.address ? -1 : 1; });
    var fwds = (Array.isArray(v.forwarders) ? v.forwarders : []).filter(function (f) { return f && isAddress(f.source); }).map(function (f) {
      return {source: f.source, to: addresses(f.to), served: f.served === true};
    }).sort(function (a, b) { return a.source < b.source ? -1 : 1; });
    return {suspended: v.suspended === true, filtersOn: v.filters_on === true, programs: v.program_filters === true,
      programsWhy: typeof v.program_filters_why === 'string' ? v.program_filters_why.slice(0, 300) : '', filters: filtersOf(v.filters), mailboxes: boxes, forwarders: fwds};
  }
  /* the names the account's sites answer on (docs/api.md, "Domains and sites"); null when that list can't be had */
  function domainsOf(v) {
    var out = [];
    (v && Array.isArray(v.sites) ? v.sites : []).forEach(function (s) {
      [s && s.domain].concat(s && Array.isArray(s.aliases) ? s.aliases : []).forEach(function (d) {
        if (typeof d === 'string' && DOMAIN_RE.test(d) && out.indexOf(d) < 0) { out.push(d); }
      });
    });
    return out.length ? out : null;
  }

  /* ---- page pieces ---- */
  function card(id, title, children, cls) {
    return el('section', {class: 'sig-card fp-mail-card' + (cls ? ' ' + cls : ''), 'aria-labelledby': id}, [el('div', {class: 'sig-card-body'},
      [el('h2', {class: 'fp-h2', id: id, tabindex: '-1', text: title})].concat(children))]);
  }
  function errorLine() { return el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': ''}); }
  function statusLine() { return el('p', {class: 'fp-ok-line', role: 'status', 'data-fp-status': ''}); }
  function say(scope, text) {
    var s = scope && scope.querySelector('[data-fp-status]');
    if (s) { s.textContent = text || ''; }
  }
  function field(id, label, control, hint) {
    if (hint) { control.setAttribute('aria-describedby', id + '-hint'); }
    return el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: id, text: label}), control,
      hint ? el('span', {class: 'sig-hint', id: id + '-hint', text: hint}) : null]);
  }
  /* an error line and the field it is about: the field is marked and focused, and the page scrolls so the line shows */
  function fieldError(form, f, message) {
    UI.showError(form, message);
    if (f) {
      f.setAttribute('aria-invalid', 'true');
      f.focus({preventScroll: true});
    }
    var line = form.querySelector('[data-fp-error]');
    if (line && line.scrollIntoView) { line.scrollIntoView({block: 'nearest'}); }
  }
  function failed(form, err) {
    var f = err && err.field ? UI.fieldNamed(form, err.field) : null;
    var label = f ? form.querySelector('label[for="' + f.id + '"]') : null;
    fieldError(form, f, (label ? label.textContent + ': ' : '') + (err ? err.message : t('api_failed')));
  }
  /* starts a submit: null while one is running; clears the last answer and marks */
  function start(form) {
    var b = form.querySelector('.fp-submit');
    if (b.disabled) { return null; }
    UI.showError(form, '');
    say(form, '');
    var bad = form.querySelectorAll('[aria-invalid]');
    for (var i = 0; i < bad.length; i++) { bad[i].removeAttribute('aria-invalid'); }
    return b;
  }
  /* an address field: the part before @ and, when the account's names are known, a list of them; else the whole address */
  function addressField(id, label, domains, hint) {
    if (!domains) {
      return field(id, label, el('input', {class: 'sig-input', id: id, name: 'address', type: 'email', autocomplete: 'off', spellcheck: 'false',
        autocapitalize: 'none', maxlength: '254'}), hint || t('mail_address_hint_full'));
    }
    var local = el('input', {class: 'sig-input', id: id, name: 'address', type: 'text', autocomplete: 'off', spellcheck: 'false',
      autocapitalize: 'none', maxlength: '64', 'aria-describedby': id + '-hint'});
    var pick = el('select', {class: 'sig-select', id: id + '-domain', name: 'domain', 'aria-label': t('mail_domain_of', {field: label})},
      domains.map(function (d) { return el('option', {value: d, text: d}); }));
    return el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: id, text: label}),
      el('div', {class: 'fp-mail-addr'}, [local, el('span', {class: 'fp-mail-at', 'aria-hidden': 'true', text: '@'}), pick]),
      el('span', {class: 'sig-hint', id: id + '-hint', text: hint || t('mail_address_hint')})]);
  }
  /* the address an address field holds, lowercased; '' when it isn't one */
  function readAddress(form) {
    var f = form.querySelector('[name="address"]');
    var d = form.querySelector('[name="domain"]');
    var v = f.value.trim().toLowerCase();
    if (d) {
      if (v.indexOf('@') >= 0) { return ''; }
      v = v + '@' + d.value;
    }
    return isAddress(v) ? v : '';
  }
  function passwordFields(id, optional) {
    return [el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: id, text: optional ? t('mail_new_password') : t('label_password')}),
      el('div', {class: 'fp-reveal-wrap'}, [
        el('input', {class: 'sig-input', id: id, name: 'password', type: 'password', autocomplete: 'new-password', maxlength: '72',
          'aria-describedby': id + '-hint'}),
        el('button', {class: 'sig-ghost fp-reveal', type: 'button', 'data-overlap-ok': '', 'data-fp-reveal': id + ',' + id + '-again',
          'aria-pressed': 'false', 'aria-label': 'Show password'}, [UI.icon(FP.ui, 'ui_eye')])]),
      el('span', {class: 'sig-hint', id: id + '-hint', text: optional ? t('mail_password_keep_hint') : t('mail_password_hint')})]),
    el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: id + '-again', text: t('mail_password_again')}),
      el('input', {class: 'sig-input', id: id + '-again', name: 'again', type: 'password', autocomplete: 'new-password', maxlength: '72'})]),
    el('div', {class: 'fp-mail-gen'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'generate',
      'data-fp-for': id, text: t('mail_generate')})])];
  }
  /* 20 characters any mail app takes as they are */
  var GEN = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789-_.+=';
  function generate() {
    var out = '';
    var buf = new Uint8Array(1);
    while (out.length < 20) {
      window.crypto.getRandomValues(buf);
      if (buf[0] < 256 - (256 % GEN.length)) { out += GEN.charAt(buf[0] % GEN.length); }
    }
    return out;
  }
  /* the password and its repeat; '' and a message on the form when they don't do */
  function readPassword(form, optional) {
    var pw = form.querySelector('[name="password"]');
    var again = form.querySelector('[name="again"]');
    if (optional && !pw.value && !again.value) { return {value: ''}; }
    if (pw.value.length < 12) { fieldError(form, pw, t('mail_password_short')); return null; }
    if (new window.TextEncoder().encode(pw.value).length > 72) { fieldError(form, pw, t('mail_password_long')); return null; }
    if (pw.value !== again.value) { fieldError(form, again, t('mail_password_mismatch')); return null; }
    return {value: pw.value};
  }
  function quotaField(id, value) {
    return field(id, t('mail_quota'), el('input', {class: 'sig-input fp-mail-quota', id: id, name: 'quota_mb', type: 'number', inputmode: 'numeric',
      min: '1', max: String(MAX_QUOTA), step: '1', value: String(value)}), t('mail_quota_hint'));
  }
  function readQuota(form) {
    var f = form.querySelector('[name="quota_mb"]');
    var v = f.value.trim();
    if (!/^[0-9]{1,7}$/.test(v) || Number(v) < 1 || Number(v) > MAX_QUOTA) { fieldError(form, f, t('mail_quota_bad')); return null; }
    return Number(v);
  }
  function quotaText(q) {
    if (q === null) { return '—'; }
    if (q === 0) { return t('mail_unlimited'); }
    return q >= 1024 && q % 1024 === 0 ? (q / 1024).toLocaleString('en') + ' GB' : q.toLocaleString('en') + ' MB';
  }
  function servedCell(served) {
    return el('td', null, [served ? el('span', {class: 'sig-pill sig-pill--ok', text: t('mail_served')}) :
      el('span', {class: 'fp-mail-elsewhere'}, [el('span', {class: 'sig-pill sig-pill--warn', text: t('mail_not_served')}),
        el('span', {class: 'fp-muted fp-row-note', text: t('mail_not_served_why')})])]);
  }
  function suspendedBanner(text) {
    return el('div', {class: 'sig-banner sig-banner--warn', role: 'note'}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: text})]);
  }
  /* a question in place of a row's buttons; Cancel takes focus, so a second Enter can't confirm it */
  /* each question has its own id, so with two open each button reads its own row's question */
  var asked = 0;
  function confirmIn(cell, question, act, yesLabel) {
    var id = 'fp-mail-confirm-' + (++asked);
    cell.textContent = '';
    var yes = el('button', {class: 'sig-btn sig-btn--danger sig-btn--sm', type: 'button', 'data-fp-act': act, text: yesLabel});
    var no = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'confirm-no', text: t('cancel')});
    cell.appendChild(el('span', {class: 'fp-mail-confirm', id: id, text: question}));
    cell.appendChild(yes);
    cell.appendChild(no);
    yes.setAttribute('aria-describedby', id);
    no.setAttribute('aria-describedby', id);
    no.focus();
  }
  function frame(id, cls) {
    var tool = FP.tools[id];
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return null; }
    var g = FP.group(tool.group);
    return FP.frame({title: tool.label, desc: t(id + '_desc'), cls: 'fp-mail ' + cls,
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
  }
  /* the account's mail and, when asked, the names it answers on */
  function fetchMail(account, withDomains) {
    var calls = [FP.call('get', 'mail', undefined, account)];
    if (withDomains) { calls.push(FP.call('get', 'domains', undefined, account).then(domainsOf, function () { return null; })); }
    return Promise.all(calls).then(function (r) { return {mail: clean(r[0]), domains: r[1] || null}; });
  }

  FP.mail = {clean: clean, isAddress: isAddress, card: card, errorLine: errorLine, statusLine: statusLine, say: say, field: field,
    fieldError: fieldError, failed: failed, start: start, confirmIn: confirmIn, frame: frame, suspendedBanner: suspendedBanner,
    addressField: addressField, readAddress: readAddress, passwordFields: passwordFields, readPassword: readPassword, domainsOf: domainsOf};

  /* ================= Mailboxes ================= */
  var MB = {page: null, state: null, domains: null, account: '', open: ''};

  function mbCreateCard() {
    var form = el('form', {class: 'fp-form fp-mail-form', novalidate: ''}, [errorLine(), statusLine(),
      addressField('fp-mb-address', t('mail_address'), MB.domains)].concat(passwordFields('fp-mb-pw', false), [
      quotaField('fp-mb-quota', 1024),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('mail_create')})])]));
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = start(form);
      if (!b) { return; }
      var addr = readAddress(form);
      if (!addr) { fieldError(form, form.querySelector('[name="address"]'), t('mail_address_bad')); return; }
      var pw = readPassword(form, false);
      if (!pw) { return; }
      var quota = readQuota(form);
      if (quota === null) { return; }
      UI.setBusy(b, true);
      FP.call('post', 'mailboxes', {address: addr, password: pw.value, quota_mb: quota}, MB.account).then(function (r) {
        MB.state = clean(r);
        mbRender();
        say(MB.page.querySelector('.fp-mb-create'), t('mail_created', {address: addr}));
        MB.page.querySelector('#fp-mb-address').focus();
      }, function (err) {
        UI.setBusy(b, false);
        failed(form, err);
      });
    });
    return card('fp-mb-create-h', t('mail_create_title'), [form], 'fp-mb-create');
  }
  function mbChangeRow(m) {
    var form = el('form', {class: 'fp-form fp-mail-inline', novalidate: '', 'aria-labelledby': 'fp-mb-change-h'}, [
      el('h3', {class: 'fp-h3', id: 'fp-mb-change-h', text: t('mail_change_title', {address: m.address})}), errorLine()].concat(
      passwordFields('fp-mb-cpw', true), [quotaField('fp-mb-cquota', m.quota || 1024),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('mail_save')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'close', text: t('cancel')})])]));
    if (m.quota === 0) {
      /* unlimited, set by the server's admin: kept unless the customer gives a number */
      var q = form.querySelector('[name="quota_mb"]');
      q.value = '';
      q.setAttribute('placeholder', t('mail_unlimited'));
    }
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = start(form);
      if (!b) { return; }
      var pw = readPassword(form, true);
      if (!pw) { return; }
      var body = {};
      if (pw.value) { body.password = pw.value; }
      var qf = form.querySelector('[name="quota_mb"]');
      if (!(m.quota === 0 && !qf.value.trim())) {
        var quota = readQuota(form);
        if (quota === null) { return; }
        if (quota !== m.quota) { body.quota_mb = quota; }
      }
      if (!body.password && body.quota_mb === undefined) { fieldError(form, form.querySelector('[name="password"]'), t('mail_nothing')); return; }
      UI.setBusy(b, true);
      FP.call('patch', 'mailbox', body, {name: MB.account, address: m.address}).then(function (r) {
        MB.state = clean(r);
        MB.open = '';
        mbRender();
        say(MB.page.querySelector('.fp-mb-list'), body.password ? (body.quota_mb !== undefined ? t('mail_saved', {address: m.address}) :
          t('mail_password_set', {address: m.address})) : t('mail_quota_set', {address: m.address}));
        mbFocus(m.address, 'change');
      }, function (err) {
        UI.setBusy(b, false);
        failed(form, err);
      });
    });
    return el('tr', {class: 'fp-mail-formrow'}, [el('td', {colspan: '4'}, [form])]);
  }
  function mbRow(m) {
    var a = m.address;
    var note = m.auto ? el('span', {class: 'sig-pill fp-mail-tag', text: m.responding ? t('mail_tag_replying') : t('mail_tag_reply_set')}) : null;
    return el('tr', {'data-fp-mailbox': a}, [
      el('th', {scope: 'row', class: 'fp-mail-name'}, [el('span', {text: a}), note]),
      el('td', {class: 'fp-num', text: quotaText(m.quota)}),
      servedCell(m.served),
      el('td', {class: 'fp-mail-acts'}, [
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'change', 'aria-expanded': String(MB.open === a),
          'aria-label': t('mail_change_of', {address: a}), text: t('mail_change')}),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'remove',
          'aria-label': t('mail_remove_of', {address: a}), text: t('mail_remove')})])]);
  }
  function mbListCard() {
    var parts = [errorLine(), statusLine()];
    if (!MB.state.mailboxes.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('mail_none')}));
    } else {
      var rows = [];
      MB.state.mailboxes.forEach(function (m) {
        rows.push(mbRow(m));
        if (MB.open === m.address) { rows.push(mbChangeRow(m)); }
      });
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-mb-list-h'}, [
        el('table', {class: 'sig-table fp-mail-table fp-mb-table'}, [el('thead', null, [el('tr', null, [
          el('th', {scope: 'col', text: t('mail_address')}), el('th', {scope: 'col', class: 'fp-num', text: t('mail_quota_short')}),
          el('th', {scope: 'col', text: t('mail_status')}), el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]),
        el('tbody', null, rows)])]));
    }
    return card('fp-mb-list-h', t('mail_list_title'), parts, 'fp-mb-list');
  }
  /* how a mail app connects (docs/api.md: IMAP on 993, sending on 587, the full address as the username) */
  function mbConnectCard() {
    var host = window.location.hostname;
    var rows = [[t('mail_conn_user'), t('mail_conn_user_v')], [t('mail_conn_in'), t('mail_conn_in_v', {host: host})],
      [t('mail_conn_out'), t('mail_conn_out_v', {host: host})]];
    return card('fp-mb-conn-h', t('mail_conn_title'), [el('p', {class: 'fp-muted', text: t('mail_conn_desc')}),
      el('dl', {class: 'fp-mail-facts'}, rows.reduce(function (out, r) {
        return out.concat([el('dt', {text: r[0]}), el('dd', {class: r[0] === t('mail_conn_user') ? null : 'sig-mono', text: r[1]})]);
      }, []))]);
  }
  function mbRender() {
    MB.page.textContent = '';
    if (MB.state.suspended) { MB.page.appendChild(suspendedBanner(t('mail_suspended'))); }
    MB.page.appendChild(mbCreateCard());
    MB.page.appendChild(mbListCard());
    MB.page.appendChild(mbConnectCard());
  }
  function mbFocus(address, act) {
    var b = MB.page.querySelector('tr[data-fp-mailbox="' + window.CSS.escape(address) + '"] [data-fp-act="' + act + '"]');
    if (b) { b.focus(); }
  }
  function mbClick(e, b, a, tr) {
    var addr = tr ? tr.getAttribute('data-fp-mailbox') : '';
    var list = MB.page.querySelector('.fp-mb-list');
    if (a === 'change') {
      MB.open = MB.open === addr ? '' : addr;
      mbRender();
      if (MB.open) { MB.page.querySelector('#fp-mb-cpw').focus(); } else { mbFocus(addr, 'change'); }
    } else if (a === 'close') {
      var was = MB.open;
      MB.open = '';
      mbRender();
      mbFocus(was, 'change');
    } else if (a === 'remove') {
      confirmIn(tr.querySelector('.fp-mail-acts'), t('mail_remove_ask', {address: addr}), 'remove-yes', t('mail_remove'));
    } else if (a === 'confirm-no') {
      mbRender();
      mbFocus(addr, 'remove');
    } else if (a === 'remove-yes') {
      UI.showError(list, '');
      UI.setBusy(b, true);
      FP.call('del', 'mailbox', undefined, {name: MB.account, address: addr}).then(function (r) {
        MB.state = clean(r);
        if (MB.open === addr) { MB.open = ''; }
        mbRender();
        say(MB.page.querySelector('.fp-mb-list'), t('mail_removed', {address: addr}));
        MB.page.querySelector('#fp-mb-list-h').focus();
      }, function (err) {
        mbRender();
        UI.showError(MB.page.querySelector('.fp-mb-list'), err.message);
        mbFocus(addr, 'remove');
      });
    }
  }

  /* ================= Forwarding ================= */
  var FW = {page: null, state: null, domains: null, account: ''};

  function fwCreateCard() {
    var to = el('textarea', {class: 'sig-input fp-mail-to', id: 'fp-fw-to', name: 'to', rows: '3', spellcheck: 'false', autocapitalize: 'none',
      autocomplete: 'off'});
    var form = el('form', {class: 'fp-form fp-mail-form', novalidate: ''}, [errorLine(), statusLine(),
      addressField('fp-fw-source', t('fwd_source'), FW.domains, t('fwd_source_hint')),
      field('fp-fw-to', t('fwd_to'), to, t('fwd_to_hint', {n: MAX_TO})),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('fwd_add')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = start(form);
      if (!b) { return; }
      var source = readAddress(form);
      if (!source) { fieldError(form, form.querySelector('[name="address"]'), t('mail_address_bad')); return; }
      var list = to.value.split(/[\s,;]+/).map(function (s) { return s.trim().toLowerCase(); }).filter(Boolean);
      var bad = list.filter(function (s) { return !isAddress(s); })[0];
      if (!list.length) { fieldError(form, to, t('fwd_to_none')); return; }
      if (bad) { fieldError(form, to, t('fwd_to_bad', {address: bad})); return; }
      list = list.filter(function (s, i) { return list.indexOf(s) === i; });
      if (list.length > MAX_TO) { fieldError(form, to, t('fwd_to_many', {n: MAX_TO})); return; }
      if (list.indexOf(source) >= 0) { fieldError(form, to, t('fwd_to_self')); return; }
      var had = FW.state.forwarders.some(function (f) { return f.source === source; });
      UI.setBusy(b, true);
      FP.call('post', 'forwarders', {source: source, to: list}, FW.account).then(function (r) {
        FW.state = clean(r);
        fwRender();
        say(FW.page.querySelector('.fp-fw-create'), had ? t('fwd_added_more', {address: source}) : t('fwd_added', {address: source}));
        FW.page.querySelector('#fp-fw-source').focus();
      }, function (err) {
        UI.setBusy(b, false);
        failed(form, err.field === 'source' ? {field: 'address', message: err.message} : err);
      });
    });
    return card('fp-fw-create-h', t('fwd_create_title'), [el('p', {class: 'fp-muted', text: t('fwd_create_desc')}), form], 'fp-fw-create');
  }
  function fwListCard() {
    var parts = [errorLine(), statusLine()];
    if (!FW.state.forwarders.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('fwd_none')}));
    } else {
      var boxes = FW.state.mailboxes.map(function (m) { return m.address; });
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-fw-list-h'}, [
        el('table', {class: 'sig-table fp-mail-table fp-fw-table'}, [el('thead', null, [el('tr', null, [
          el('th', {scope: 'col', text: t('fwd_source')}), el('th', {scope: 'col', text: t('fwd_to_short')}),
          el('th', {scope: 'col', text: t('mail_status')}), el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]),
        el('tbody', null, FW.state.forwarders.map(function (f) {
          return el('tr', {'data-fp-forwarder': f.source}, [
            el('th', {scope: 'row', class: 'fp-mail-name'}, [el('span', {text: f.source}),
              boxes.indexOf(f.source) >= 0 ? el('span', {class: 'fp-muted fp-row-note', text: t('fwd_keeps_copy')}) : null]),
            el('td', null, [el('ul', {class: 'fp-mail-to-list'}, f.to.map(function (a) { return el('li', {text: a}); }))]),
            servedCell(f.served),
            el('td', {class: 'fp-mail-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button',
              'data-fp-act': 'remove', 'aria-label': t('fwd_remove_of', {address: f.source}), text: t('fwd_remove')})])]);
        }))])]));
    }
    return card('fp-fw-list-h', t('fwd_list_title'), parts, 'fp-fw-list');
  }
  function fwRender() {
    FW.page.textContent = '';
    FW.page.appendChild(fwCreateCard());
    FW.page.appendChild(fwListCard());
  }
  function fwClick(e, b, a, tr) {
    var src = tr ? tr.getAttribute('data-fp-forwarder') : '';
    var focusBack = function () {
      var x = FW.page.querySelector('tr[data-fp-forwarder="' + window.CSS.escape(src) + '"] [data-fp-act="remove"]');
      if (x) { x.focus(); }
    };
    if (a === 'remove') {
      var keeps = FW.state.mailboxes.some(function (m) { return m.address === src; });
      confirmIn(tr.querySelector('.fp-mail-acts'), t(keeps ? 'fwd_remove_ask_box' : 'fwd_remove_ask', {address: src}), 'remove-yes', t('fwd_remove'));
    } else if (a === 'confirm-no') {
      fwRender();
      focusBack();
    } else if (a === 'remove-yes') {
      UI.setBusy(b, true);
      FP.call('del', 'forwarder', undefined, {name: FW.account, address: src}).then(function (r) {
        FW.state = clean(r);
        fwRender();
        say(FW.page.querySelector('.fp-fw-list'), t('fwd_removed', {address: src}));
        FW.page.querySelector('#fp-fw-list-h').focus();
      }, function (err) {
        fwRender();
        UI.showError(FW.page.querySelector('.fp-fw-list'), err.message);
        focusBack();
      });
    }
  }

  /* ================= Auto-replies ================= */
  var AR = {page: null, state: null, account: '', editing: ''};

  /* a time for a datetime-local field, in the browser's time zone */
  function localValue(d) {
    if (!d) { return ''; }
    var p = function (n) { return (n < 10 ? '0' : '') + n; };
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + 'T' + p(d.getHours()) + ':' + p(d.getMinutes());
  }
  function readLocal(f) {
    var v = f.value.trim();
    if (!v) { return {value: null}; }
    if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2})?$/.test(v)) { return null; }
    var d = new Date(v);
    return isNaN(d.getTime()) ? null : {value: d};
  }
  function iso(d) { return d.toISOString().replace(/\.\d{3}Z$/, 'Z'); }
  function shown(d) { return d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'}); }
  /* what the list says about a mailbox's auto-reply; "answering" only when the server says it is */
  function arStatus(m) {
    if (!m.auto) { return {pill: '', text: t('ar_off')}; }
    var now = Date.now();
    if (m.responding) {
      return {pill: 'ok', text: m.auto.stop ? t('ar_on_until', {when: shown(m.auto.stop)}) : t('ar_on')};
    }
    if (m.auto.stop && m.auto.stop.getTime() <= now) { return {pill: '', text: t('ar_ended', {when: shown(m.auto.stop)})}; }
    if (m.auto.start && m.auto.start.getTime() > now) { return {pill: 'accent', text: t('ar_starts', {when: shown(m.auto.start)})}; }
    return {pill: 'warn', text: t('ar_pending')};
  }
  function arEditCard() {
    var m = AR.state.mailboxes.filter(function (x) { return x.address === AR.editing; })[0];
    var a = m.auto || {from: '', subject: '', body: '', hours: 8, start: null, stop: null};
    var body = el('textarea', {class: 'sig-input fp-mail-body', id: 'fp-ar-body', name: 'body', rows: '8', maxlength: '16384'});
    body.value = a.body;
    var form = el('form', {class: 'fp-form fp-mail-form', novalidate: ''}, [errorLine(),
      field('fp-ar-from', t('ar_from'), el('input', {class: 'sig-input', id: 'fp-ar-from', name: 'from', type: 'text', maxlength: '128', value: a.from,
        autocomplete: 'off'}), t('ar_from_hint')),
      field('fp-ar-subject', t('ar_subject'), el('input', {class: 'sig-input', id: 'fp-ar-subject', name: 'subject', type: 'text', maxlength: '255',
        value: a.subject, autocomplete: 'off'})),
      field('fp-ar-body', t('ar_body'), body, t('ar_body_hint')),
      field('fp-ar-hours', t('ar_hours'), el('input', {class: 'sig-input fp-mail-quota', id: 'fp-ar-hours', name: 'interval_hours', type: 'number',
        inputmode: 'numeric', min: '1', max: '720', step: '1', value: String(a.hours)}), t('ar_hours_hint')),
      el('div', {class: 'fp-mail-pair'}, [
        field('fp-ar-start', t('ar_start'), el('input', {class: 'sig-input', id: 'fp-ar-start', name: 'start', type: 'datetime-local', value: localValue(a.start)}),
          t('ar_start_hint')),
        field('fp-ar-stop', t('ar_stop'), el('input', {class: 'sig-input', id: 'fp-ar-stop', name: 'stop', type: 'datetime-local', value: localValue(a.stop)}),
          t('ar_stop_hint'))]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('ar_save')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'close', text: t('cancel')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = start(form);
      if (!b) { return; }
      var get = function (n) { return form.querySelector('[name="' + n + '"]'); };
      var out = {from: get('from').value.trim(), subject: get('subject').value.trim(), body: body.value.replace(/\r\n/g, '\n')};
      if (/[\u0000-\u001f\u007f]/.test(out.from)) { fieldError(form, get('from'), t('ar_one_line')); return; }   // eslint-disable-line no-control-regex -- one line only
      if (!out.subject) { fieldError(form, get('subject'), t('ar_need_subject')); return; }
      if (/[\u0000-\u001f\u007f]/.test(out.subject)) { fieldError(form, get('subject'), t('ar_one_line')); return; }   // eslint-disable-line no-control-regex -- one line only
      if (!out.body.trim()) { fieldError(form, body, t('ar_need_body')); return; }
      if (new window.TextEncoder().encode(out.body).length > 16384) { fieldError(form, body, t('ar_body_long')); return; }
      var h = get('interval_hours').value.trim();
      if (!/^[0-9]{1,3}$/.test(h) || Number(h) < 1 || Number(h) > 720) { fieldError(form, get('interval_hours'), t('ar_hours_bad')); return; }
      out.interval_hours = Number(h);
      var s = readLocal(get('start'));
      if (!s) { fieldError(form, get('start'), t('ar_time_bad')); return; }
      var p = readLocal(get('stop'));
      if (!p) { fieldError(form, get('stop'), t('ar_time_bad')); return; }
      if (s.value && p.value && p.value <= s.value) { fieldError(form, get('stop'), t('ar_stop_before')); return; }
      if (p.value && p.value.getTime() <= Date.now()) { fieldError(form, get('stop'), t('ar_stop_past')); return; }
      if (s.value) { out.start = iso(s.value); }
      if (p.value) { out.stop = iso(p.value); }
      var addr = AR.editing;
      UI.setBusy(b, true);
      FP.call('put', 'autoresponder', out, {name: AR.account, address: addr}).then(function (r) {
        AR.state = clean(r);
        AR.editing = '';
        arRender();
        say(AR.page.querySelector('.fp-ar-list'), t('ar_saved', {address: addr}));
        arFocus(addr, 'edit');
      }, function (err) {
        UI.setBusy(b, false);
        failed(form, err);
      });
    });
    return card('fp-ar-edit-h', t('ar_edit_title', {address: m.address}), [form], 'fp-ar-edit');
  }
  function arListCard() {
    var parts = [errorLine(), statusLine()];
    if (!AR.state.mailboxes.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('ar_no_mailboxes')}));
    } else {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-ar-list-h'}, [
        el('table', {class: 'sig-table fp-mail-table fp-ar-table'}, [el('thead', null, [el('tr', null, [
          el('th', {scope: 'col', text: t('ar_mailbox')}), el('th', {scope: 'col', text: t('ar_status')}),
          el('th', {scope: 'col', text: t('ar_subject')}), el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]),
        el('tbody', null, AR.state.mailboxes.map(function (m) {
          var s = arStatus(m);
          return el('tr', {'data-fp-mailbox': m.address}, [
            el('th', {scope: 'row', class: 'fp-mail-name', text: m.address}),
            el('td', null, [s.pill ? el('span', {class: 'sig-pill sig-pill--' + s.pill, text: s.text}) : el('span', {class: 'fp-muted', text: s.text})]),
            el('td', {class: 'fp-ar-subject', text: m.auto ? m.auto.subject : '—'}),
            el('td', {class: 'fp-mail-acts'}, [
              el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'edit',
                'aria-label': t(m.auto ? 'ar_change_of' : 'ar_setup_of', {address: m.address}), text: m.auto ? t('ar_change') : t('ar_setup')}),
              m.auto ? el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'remove',
                'aria-label': t('ar_remove_of', {address: m.address}), text: t('ar_remove')}) : null])]);
        }))])]));
    }
    return card('fp-ar-list-h', t('ar_list_title'), parts, 'fp-ar-list');
  }
  function arRender() {
    AR.page.textContent = '';
    if (!AR.state.filtersOn) {
      AR.page.appendChild(FP.empty(t('ar_unavailable_title'), t('ar_unavailable')));
      return;
    }
    if (AR.editing && !AR.state.mailboxes.some(function (m) { return m.address === AR.editing; })) { AR.editing = ''; }
    AR.page.appendChild(arListCard());
    if (AR.editing) { AR.page.appendChild(arEditCard()); }
  }
  function arFocus(address, act) {
    var b = AR.page.querySelector('tr[data-fp-mailbox="' + window.CSS.escape(address) + '"] [data-fp-act="' + act + '"]');
    if (b) { b.focus(); }
  }
  function arClick(e, b, a, tr) {
    var addr = tr ? tr.getAttribute('data-fp-mailbox') : '';
    if (a === 'edit') {
      AR.editing = addr;
      arRender();
      AR.page.querySelector('#fp-ar-edit-h').focus();
    } else if (a === 'close') {
      var was = AR.editing;
      AR.editing = '';
      arRender();
      arFocus(was, 'edit');
    } else if (a === 'remove') {
      confirmIn(tr.querySelector('.fp-mail-acts'), t('ar_remove_ask', {address: addr}), 'remove-yes', t('ar_remove'));
    } else if (a === 'confirm-no') {
      arRender();
      arFocus(addr, 'remove');
    } else if (a === 'remove-yes') {
      UI.setBusy(b, true);
      FP.call('del', 'autoresponder', undefined, {name: AR.account, address: addr}).then(function (r) {
        AR.state = clean(r);
        if (AR.editing === addr) { AR.editing = ''; }
        arRender();
        say(AR.page.querySelector('.fp-ar-list'), t('ar_removed', {address: addr}));
        arFocus(addr, 'edit');
      }, function (err) {
        arRender();
        UI.showError(AR.page.querySelector('.fp-ar-list'), err.message);
        arFocus(addr, 'remove');
      });
    }
  }

  /* ---- one click handler for the three pages ---- */
  document.addEventListener('click', function (e) {
    var target = e.target.closest ? e.target : null;
    if (!target) { return; }
    var b = target.closest('[data-fp-act]');
    if (!b) { return; }
    var a = b.getAttribute('data-fp-act');
    if (a === 'generate' && b.closest('.fp-mail')) {
      var id = b.getAttribute('data-fp-for');
      var pw = document.getElementById(id);
      var again = document.getElementById(id + '-again');
      if (!pw || !again) { return; }
      pw.value = again.value = generate();
      var reveal = b.closest('form').querySelector('[data-fp-reveal]');
      if (reveal && reveal.getAttribute('aria-pressed') !== 'true') { reveal.click(); }
      pw.focus();
      return;
    }
    var tr = b.closest('tr');
    if (MB.page && MB.page.contains(b)) { mbClick(e, b, a, tr); } else if (FW.page && FW.page.contains(b)) { fwClick(e, b, a, tr); } else if (AR.page && AR.page.contains(b)) { arClick(e, b, a, tr); }
  });

  /* ---- the views ---- */
  function view(id, cls, holder, withDomains, render) {
    FP.view('tool:' + id, function () {
      MB.page = FW.page = AR.page = null;
      var body = frame(id, cls);
      if (!body) { return; }
      holder.page = body;
      holder.account = FP.account();
      body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
      var mine = body;
      fetchMail(holder.account, withDomains).then(function (r) {
        if (holder.page !== mine) { return; }
        holder.state = r.mail;
        if (withDomains) { holder.domains = r.domains; }
        render();
      }, function (err) {
        if (holder.page !== mine) { return; }
        body.textContent = '';
        body.appendChild(FP.empty(FP.tools[id].label, err.message));
      });
    });
  }
  view('mailboxes', 'fp-mb', MB, true, function () { MB.open = ''; mbRender(); });
  view('forwarding', 'fp-fw', FW, true, fwRender);
  view('auto_replies', 'fp-ar', AR, false, function () { AR.editing = ''; arRender(); });
})();

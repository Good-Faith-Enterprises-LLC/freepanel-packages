/* freePanel restart (#/tool/server_reboot), the admin panel's page for restarting the server (docs/api.md, "Server"):
   how long the server has been up, whether updates ask for a restart, what a restart would break off, scheduling one a
   number of minutes ahead (never at once, and only when the server's owner has switched it on), and taking a scheduled
   one back, which works with the switch off too. What the server sends is drawn as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var MAX_MINUTES = 1440;
  var V = null;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function stamp(iso) {
    var d = typeof iso === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(iso) ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) && d.getFullYear() > 2000 ? d : null;
  }
  function when(d) { return d ? d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'}) : '—'; }
  function whole(v, max) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.min(Math.floor(v), max) : 0; }
  function cleanInfo(r) {
    if (!r || typeof r !== 'object' || typeof r.enabled !== 'boolean') { return null; }
    var s = r.scheduled && typeof r.scheduled === 'object' ? r.scheduled : null;
    var at = s ? stamp(s.at) : null;
    return {
      enabled: r.enabled,
      scheduled: s ? {at: at, by: str(s.by, 40), left: Math.max(1, whole(s.minutes_left, 100000))} : null,
      boot: stamp(r.boot_time),
      up: whole(r.uptime_seconds, 100 * 365 * 86400),
      required: r.required === true ? true : (r.required === false ? false : null),
      reasons: (Array.isArray(r.reasons) ? r.reasons : []).filter(function (x) { return typeof x === 'string' && x; }).slice(0, 10).map(function (x) { return x.slice(0, 120); }),
      busy: (Array.isArray(r.preflight) ? r.preflight : []).filter(function (x) { return x && typeof x.what === 'string' && x.what; }).slice(0, 10)
        .map(function (x) { return {id: str(x.id, 40), what: x.what.slice(0, 200)}; })
    };
  }

  function plural(n, one, many) { return t(n === 1 ? one : many, {n: n}); }
  /* a length of time in whole minutes as "1 day 12 hours", "3 hours 5 minutes" or "12 minutes" */
  function span(minutes) {
    var d = Math.floor(minutes / 1440);
    var h = Math.floor((minutes % 1440) / 60);
    var m = minutes % 60;
    var parts = [];
    if (d) { parts.push(plural(d, 'rb_day', 'rb_days')); }
    if (h) { parts.push(plural(h, 'rb_hour', 'rb_hours')); }
    if (m && !d) { parts.push(plural(m, 'rb_minute', 'rb_minutes')); }
    return parts.length ? parts.join(' ') : t('rb_under_minute');
  }

  function stateCard() {
    var i = V.info;
    var required = i.required === true ? t('rb_required_yes') : (i.required === false ? t('rb_required_no') : t('rb_required_unknown'));
    var rows = [[t('rb_f_since'), when(i.boot), 'since'], [t('rb_f_up'), i.boot || i.up ? span(Math.floor(i.up / 60)) : '—', 'up'], [t('rb_f_required'), required, 'required']];
    var parts = [M.errorLine(), M.statusLine(), el('dl', {class: 'fp-mail-facts fp-rb-facts'}, rows.reduce(function (out, r) {
      return out.concat([el('dt', {text: r[0]}), el('dd', {'data-fp-fact': r[2], text: r[1]})]);
    }, []))];
    if (i.required === true && i.reasons.length) {
      parts.push(el('p', {class: 'fp-muted', text: t('rb_reasons')}), el('ul', {class: 'fp-hn-lines', 'data-fp-lines': 'reasons'}, i.reasons.map(function (x) { return el('li', {text: x}); })));
    }
    parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'refresh', text: t('status_again')})]));
    return M.card('fp-rb-h', t('rb_state_title'), parts, 'fp-rb');
  }

  /* ---------------- the restart itself ---------------- */
  function busyList(i) {
    if (!i.busy.length) { return [el('p', {class: 'fp-muted', 'data-fp-idle': '', text: t('rb_idle')})]; }
    return [el('p', {class: 'fp-warn-line', 'data-fp-busy-note': '', text: t('rb_busy')}),
      el('ul', {class: 'fp-hn-lines', 'data-fp-lines': 'busy'}, i.busy.map(function (x) { return el('li', {'data-fp-busy': x.id || null, text: x.what}); }))];
  }
  function scheduledView(i) {
    var s = i.scheduled;
    var line = s.at ? t('rb_scheduled', {when: when(s.at), left: span(s.left)}) : t('rb_scheduled_soon', {left: span(s.left)});
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-rb-when', 'data-fp-scheduled': '', text: line})];
    if (s.by) { parts.push(el('p', {class: 'fp-muted', 'data-fp-by': '', text: t('rb_by', {name: s.by})})); }
    if (!i.enabled) { parts.push(el('p', {class: 'fp-muted', 'data-fp-off-cancel': '', text: t('rb_off_cancel')})); }
    parts.push(el('p', {class: 'fp-muted', text: t('rb_told')}),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'cancel', text: t('rb_cancel')})]));
    return parts;
  }
  function offView() {
    return [M.errorLine(), M.statusLine(), el('p', {class: 'fp-warn-line', 'data-fp-off': '', text: t('rb_off')}), el('p', {class: 'fp-muted', text: t('rb_off_how')})];
  }
  function formView(i) {
    var input = el('input', {class: 'sig-input', id: 'fp-rb-minutes', name: 'minutes', type: 'text', inputmode: 'numeric', maxlength: '4', autocomplete: 'off',
      spellcheck: 'false', 'aria-describedby': 'fp-rb-minutes-hint'});
    input.value = V.draft;
    var ask = el('div', {class: 'fp-rb-ask', 'data-fp-ask': ''});
    var form = el('form', {class: 'fp-form fp-rb-form', novalidate: ''}, [M.errorLine(),
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: 'fp-rb-minutes', text: t('rb_minutes_label')}), input,
        el('span', {class: 'sig-hint', id: 'fp-rb-minutes-hint', text: t('rb_minutes_hint')})]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('rb_schedule')})]), ask]);
    input.addEventListener('input', function () {
      if (V.asking) { V.asking = 0; ask.textContent = ''; }
    });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (V.busy) { return; }
      var text = input.value.trim();
      V.draft = input.value;
      UI.showError(form, '');
      input.removeAttribute('aria-invalid');
      var n = /^\d{1,4}$/.test(text) ? parseInt(text, 10) : 0;
      if (n < 1 || n > MAX_MINUTES) {
        UI.showError(form, t('rb_bad_minutes'));
        input.setAttribute('aria-invalid', 'true');
        input.focus();
        return;
      }
      V.asking = n;
      M.confirmIn(ask, t('rb_ask', {left: span(n)}), 'schedule-yes', t('rb_yes'));
    });
    return [el('p', {class: 'fp-muted', text: t('rb_what')})].concat(busyList(i), [M.statusLine(), form]);
  }
  function restartCard() {
    var i = V.info;
    var body = i.scheduled ? scheduledView(i) : (i.enabled ? formView(i) : offView());
    return M.card('fp-rs-h', i.scheduled ? t('rb_scheduled_title') : t('rb_title'), body, 'fp-rs');
  }
  function draw(focus) {
    V.page.textContent = '';
    V.page.appendChild(stateCard());
    V.page.appendChild(restartCard());
    var target = focus ? V.page.querySelector(focus) : null;
    if (target) { target.focus(); }
  }
  function stateEl() { return V.page.querySelector('.fp-rb'); }
  function restartEl() { return V.page.querySelector('.fp-rs'); }

  function lock(on) {
    V.busy = on;
    var all = V.page.querySelectorAll('button, input');
    for (var i = 0; i < all.length; i++) { all[i].disabled = on; }
  }
  /* the state is read again after a refusal that says it changed under us (a restart already scheduled, the switch off) */
  function reread() {
    var mine = V;
    return FP.call('get', 'serverReboot').then(function (r) {
      var info = cleanInfo(r);
      if (V === mine && info) { V.info = info; }
    }, function () {});
  }
  function onClick(e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !V || !V.page.contains(b) || b.disabled || V.busy) { return; }
    var a = b.getAttribute('data-fp-act');
    var mine = V;
    if (a === 'refresh') {
      UI.setBusy(b, true);
      FP.call('get', 'serverReboot').then(function (r) {
        if (V !== mine) { return; }
        var info = cleanInfo(r);
        if (!info) { UI.setBusy(b, false); UI.showError(stateEl(), t('api_failed')); return; }
        V.info = info;
        draw();
        V.page.querySelector('.fp-rb [data-fp-act="refresh"]').focus();
        M.say(stateEl(), t('status_checked', {when: new Date().toLocaleTimeString('en', {timeStyle: 'short'})}));
      }, function (err) {
        if (V !== mine) { return; }
        UI.setBusy(b, false);
        UI.showError(stateEl(), err.message);
        b.focus();
      });
    } else if (a === 'confirm-no') {
      var ask = b.closest('[data-fp-ask]');
      if (ask) { ask.textContent = ''; }
      V.asking = 0;
      var field = V.page.querySelector('#fp-rb-minutes');
      if (field) { field.focus(); }
    } else if (a === 'schedule-yes' && V.asking) {
      var minutes = V.asking;
      lock(true);
      UI.setBusy(b, true);
      UI.showError(restartEl(), '');
      M.say(restartEl(), t('rb_scheduling'));
      FP.call('post', 'serverReboot', {minutes: minutes}).then(function (r) {
        if (V !== mine) { return; }
        var info = cleanInfo(r);
        lock(false);
        V.asking = 0;
        if (!info) {
          M.say(restartEl(), '');
          UI.setBusy(b, false);
          UI.showError(restartEl(), t('api_failed'));
          reread().then(function () { if (V === mine) { draw(); } });
          return;
        }
        V.info = info;
        V.draft = '';
        draw('#fp-rs-h');
        M.say(restartEl(), t('rb_now_scheduled'));
      }, function (err) {
        if (V !== mine) { return; }
        lock(false);
        V.asking = 0;
        reread().then(function () {
          if (V !== mine) { return; }
          draw('#fp-rs-h');
          UI.showError(restartEl(), err.message);
        });
      });
    } else if (a === 'cancel') {
      lock(true);
      UI.setBusy(b, true);
      UI.showError(restartEl(), '');
      M.say(restartEl(), t('rb_cancelling'));
      FP.call('del', 'serverReboot').then(function (r) {
        if (V !== mine) { return; }
        var info = cleanInfo(r);
        lock(false);
        if (info) { V.info = info; }
        draw('#fp-rs-h');
        M.say(restartEl(), info ? t('rb_cancelled') : '');
        if (!info) { UI.showError(restartEl(), t('api_failed')); }
      }, function (err) {
        if (V !== mine) { return; }
        lock(false);
        reread().then(function () {
          if (V !== mine) { return; }
          draw('#fp-rs-h');
          UI.showError(restartEl(), err.message);
        });
      });
    }
  }
  document.addEventListener('click', onClick);

  FP.view('tool:server_reboot', function () {
    var tool = FP.tools.server_reboot;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('rb_desc'), cls: 'fp-mail fp-srv fp-rb-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    V = {page: page, info: null, draft: '', asking: 0, busy: false};
    var mine = V;
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'serverReboot').then(function (r) {
      if (V !== mine) { return; }
      var info = cleanInfo(r);
      page.textContent = '';
      if (!info) { page.appendChild(FP.empty(tool.label, t('api_failed'))); return; }
      V.info = info;
      draw();
    }, function (err) {
      if (V !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

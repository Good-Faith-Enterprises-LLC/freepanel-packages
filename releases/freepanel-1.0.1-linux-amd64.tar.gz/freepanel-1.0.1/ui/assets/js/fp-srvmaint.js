/* freePanel server maintenance pages of the admin panel (docs/api.md): DNS maintenance (#/tool/dns_maintenance: put a zone back to the template,
   set the TTLs and drop repeated records across zones, and the name server report, with what the public DNS says), FTP server settings
   (#/tool/ftp_server), Web Disk settings (#/tool/webdisk_server), IMAP and POP settings (#/tool/imap_pop) and Domain forwarding (#/tool/domain_forwards: domains no site here serves,
   sent on to another address). The server admin's alone: the server refuses these calls to anyone else. What the server sends is drawn as text.
   The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var HOST_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function num(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.floor(v) : 0; }
  function count(n) { return n.toLocaleString('en'); }

  /* the frame of an admin tool page, or null (and the not-found page) for anyone but the server admin */
  function frame(id) {
    var tool = FP.tools[id];
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return null; }
    var g = FP.group(tool.group);
    return FP.frame({title: tool.label, desc: t(id + '_desc'), cls: 'fp-mail fp-srv fp-smt fp-smt-' + id,
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
  }
  function loading(body) { body.appendChild(el('p', {class: 'fp-muted', text: t('loading')})); }
  function unavailable(body, id, err) {
    body.textContent = '';
    body.appendChild(FP.empty(FP.tools[id].label, err ? err.message : t('api_failed')));
  }
  function check(id, name, label, on, hint) {
    var box = el('input', {type: 'checkbox', id: id, name: name});
    box.checked = on === true;
    if (hint) { box.setAttribute('aria-describedby', id + '-hint'); }
    return el('div', {class: 'sig-field'}, [el('label', {class: 'fp-check', for: id}, [box, el('span', {text: label})]),
      hint ? el('span', {class: 'sig-hint', id: id + '-hint', text: hint}) : null]);
  }
  function numberInput(id, name, value, min, max) {
    return el('input', {class: 'sig-input fp-smt-num', id: id, name: name, type: 'number', inputmode: 'numeric', min: String(min), max: String(max), step: '1',
      value: value ? String(value) : ''});
  }
  /* a whole number from min to max, or (blank allowed) 0; null with the field marked when it is not */
  function readNumber(form, name, min, max, blank) {
    var f = form.querySelector('[name="' + name + '"]');
    var v = f.value.trim();
    if (v === '' && blank) { return 0; }
    if (!/^[0-9]{1,7}$/.test(v) || Number(v) < min || Number(v) > max) {
      var label = form.querySelector('label[for="' + f.id + '"]');
      M.fieldError(form, f, t('smt_number_bad', {field: label ? label.textContent : name, min: count(min), max: count(max)}));
      return null;
    }
    return Number(v);
  }
  function table(labelledBy, heads, rows, cls) {
    return el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': labelledBy}, [
      el('table', {class: 'sig-table fp-mail-table ' + (cls || '')}, [el('thead', null, [el('tr', null, heads.map(function (h) {
        return el('th', {scope: 'col', class: h.num ? 'fp-num' : null}, h.hidden ? [el('span', {class: 'sig-vh', text: h.text})] : null, h.hidden ? undefined : h.text);
      }))]), el('tbody', null, rows)])]);
  }
  function th(text) { return el('th', {scope: 'row', class: 'sig-mono', text: text}); }
  function td(text, cls) { return el('td', {class: cls || null, text: text}); }

  /* ================= DNS maintenance ================= */
  var D = {page: null, zones: [], report: null};
  function cleanZones(r) {
    return (r && Array.isArray(r.zones) ? r.zones : []).filter(function (z) { return z && HOST_RE.test(str(z.zone, 253)); }).map(function (z) {
      return {zone: z.zone, account: str(z.account, 32)};
    });
  }
  function cleanReport(r) {
    if (!r || typeof r !== 'object' || !Array.isArray(r.zones)) { return null; }
    return {nameservers: (Array.isArray(r.nameservers) ? r.nameservers : []).filter(function (n) { return HOST_RE.test(str(n, 253)); }), checked: r.checked === true,
      unchecked: num(r.unchecked), zones: r.zones.filter(function (z) { return z && HOST_RE.test(str(z.zone, 253)); }).slice(0, 5000).map(function (z) {
        return {zone: z.zone, account: str(z.account, 32), delegated: (Array.isArray(z.delegated) ? z.delegated : []).filter(function (d) { return d && typeof d === 'object'; }).map(function (d) {
          return str(d.name, 253) + ' → ' + str(d.content, 253);
        }), public: (Array.isArray(z.public) ? z.public : []).map(function (n) { return str(n, 253); }), matches: z.matches === true ? true : z.matches === false ? false : null,
        error: str(z.public_error, 200)};
      })};
  }
  function bulkCard() {
    var ttl = numberInput('fp-dmt-ttl', 'ttl', 0, 60, 604800);
    var zones = el('textarea', {class: 'sig-input sig-mono fp-dmt-zones', id: 'fp-dmt-zones', name: 'zones', rows: '3', spellcheck: 'false', autocomplete: 'off',
      autocapitalize: 'none', placeholder: 'example.com'});
    var out = el('div', {class: 'fp-dmt-out'});
    var apply = el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'bulk-apply', hidden: true, text: t('dmt_apply')});
    var form = el('form', {class: 'fp-form fp-mail-form fp-dmt-bulk', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-dmt-ttl', t('dmt_ttl'), ttl, t('dmt_ttl_hint')), check('fp-dmt-dedupe', 'dedupe', t('dmt_dedupe'), false, t('dmt_dedupe_hint')),
      M.field('fp-dmt-zones', t('dmt_zones'), zones, t('dmt_zones_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary fp-submit', type: 'submit', text: t('dmt_preview')}), apply]), out]);
    var asked = null;
    function read() {
      var n = readNumber(form, 'ttl', 60, 604800, true);
      if (n === null) { return null; }
      var dedupe = form.querySelector('[name="dedupe"]').checked;
      if (!n && !dedupe) { M.fieldError(form, ttl, t('dmt_nothing')); return null; }
      var list = zones.value.toLowerCase().split(/[\s,;]+/).filter(Boolean);
      for (var i = 0; i < list.length; i++) {
        if (!HOST_RE.test(list[i].replace(/\.$/, ''))) { M.fieldError(form, zones, t('dmt_zone_bad', {zone: list[i].slice(0, 80)})); return null; }
      }
      return {ttl: n, dedupe: dedupe, zones: list.map(function (z) { return z.replace(/\.$/, ''); })};
    }
    function run(body, dry, b) {
      var mine = D.page;
      UI.setBusy(b, true);
      FP.call('post', 'dnsBulk', {ttl: body.ttl, dedupe: body.dedupe, zones: body.zones, dry_run: dry}).then(function (r) {
        if (D.page !== mine) { return; }
        UI.setBusy(b, false);
        var rows = (r && Array.isArray(r.zones) ? r.zones : []).filter(function (z) { return z && HOST_RE.test(str(z.zone, 253)); });
        var changed = rows.filter(function (z) { return z.changed === true; });
        out.textContent = '';
        var sum = el('p', {role: 'status', 'data-fp-summary': '', text: t(dry ? 'dmt_would' : 'dmt_did', {n: count(changed.length), all: count(rows.length), failed: count(num(r && r.failed))})});
        out.appendChild(M.card('fp-dmt-res-h', t(dry ? 'dmt_preview_title' : 'dmt_done_title'), [sum, changed.length ? table('fp-dmt-res-h',
          [{text: t('dmt_zone')}, {text: t('dmt_account')}, {text: t('dmt_ttls'), num: true}, {text: t('dmt_removed'), num: true}],
          changed.slice(0, 1000).map(function (z) {
            return el('tr', {'data-fp-zone': z.zone}, [th(z.zone), td(str(z.account, 32)), td(count(num(z.ttls)), 'fp-num'), td(count(num(z.removed)), 'fp-num')]);
          })) : null].concat(rows.filter(function (z) { return z.error; }).slice(0, 50).map(function (z) {
          return el('p', {class: 'fp-alert', text: z.zone + ': ' + str(z.error)});
        })), 'fp-dmt-result'));
        asked = dry && changed.length ? body : null;
        apply.hidden = !asked;
        out.querySelector('#fp-dmt-res-h').focus();
      }, function (err) {
        if (D.page !== mine) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    }
    form.addEventListener('input', function () { asked = null; apply.hidden = true; });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var body = read();
      if (body) { run(body, true, b); }
    });
    apply.addEventListener('click', function () { if (asked) { run(asked, false, apply); } });
    return M.card('fp-dmt-bulk-h', t('dmt_bulk_title'), [el('p', {class: 'fp-muted', text: t('dmt_bulk_what')}), form], 'fp-dmt-bulk-card');
  }
  function resetCard() {
    var pick = el('select', {class: 'sig-select', id: 'fp-dmt-reset-zone', name: 'zone'}, D.zones.map(function (z) {
      return el('option', {value: z.account + ' ' + z.zone, text: t('dmt_zone_of', {zone: z.zone, account: z.account})});
    }));
    var ask = el('div', {class: 'fp-dmt-ask'});
    var form = el('form', {class: 'fp-form fp-mail-form fp-dmt-reset', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-dmt-reset-zone', t('dmt_zone'), pick, t('dmt_reset_hint')), ask,
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--danger fp-submit', type: 'submit', text: t('dmt_reset')})])]);
    pick.addEventListener('change', function () { ask.textContent = ''; });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      M.confirmIn(ask, t('dmt_reset_ask', {zone: pick.value.split(' ')[1]}), 'reset-yes', t('dmt_reset_yes'));
    });
    form.addEventListener('click', function (e) {
      var a = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
      if (!a) { return; }
      if (a.getAttribute('data-fp-act') === 'confirm-no') { ask.textContent = ''; pick.focus(); return; }
      if (a.getAttribute('data-fp-act') !== 'reset-yes') { return; }
      var v = pick.value.split(' ');
      var mine = D.page;
      UI.setBusy(a, true);
      FP.call('post', 'dnsZoneReset', {}, {name: v[0], zone: v[1]}).then(function () {
        if (D.page !== mine) { return; }
        ask.textContent = '';
        M.say(form, t('dmt_reset_done', {zone: v[1]}));
        pick.focus();
      }, function (err) {
        if (D.page !== mine) { return; }
        ask.textContent = '';
        M.failed(form, err);
      });
    });
    return M.card('fp-dmt-reset-h', t('dmt_reset_title'), [el('p', {class: 'fp-muted', text: t('dmt_reset_what')}),
      D.zones.length ? form : el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('dmt_no_zones')})], 'fp-dmt-reset-card');
  }
  function reportCard() {
    var r = D.report;
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t('dmt_ns_what')}),
      el('p', {'data-fp-ns': ''}, [el('strong', {text: t('dmt_ns_ours') + ' '}), el('span', {class: 'sig-mono', text: r.nameservers.join(', ') || '—'})])];
    if (!r.zones.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('dmt_no_zones')}));
    } else {
      var heads = [{text: t('dmt_zone')}, {text: t('dmt_account')}, {text: t('dmt_delegated')}];
      if (r.checked) { heads.push({text: t('dmt_public')}); }
      parts.push(table('fp-dmt-ns-h', heads, r.zones.map(function (z) {
        var cells = [th(z.zone), td(z.account), td(z.delegated.join(', ') || '—')];
        if (r.checked) {
          cells.push(el('td', null, z.error ? [el('span', {class: 'sig-pill sig-pill--warn', text: t('dmt_public_none')}), el('span', {class: 'fp-muted fp-row-note', text: ' ' + z.error})] :
            [el('span', {class: 'sig-pill' + (z.matches ? ' sig-pill--ok' : ' sig-pill--danger'), text: t(z.matches ? 'dmt_public_ok' : 'dmt_public_other')}),
              z.matches ? null : el('span', {class: 'fp-muted fp-row-note sig-mono', text: ' ' + (z.public.join(', ') || '—')})]));
        }
        return el('tr', {'data-fp-ns-zone': z.zone}, cells);
      }), 'fp-dmt-ns-table'));
      if (r.unchecked) { parts.push(el('p', {class: 'fp-muted', text: t('dmt_public_more', {n: count(r.unchecked)})})); }
    }
    parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'ns-public', text: t('dmt_public_check')})]));
    return M.card('fp-dmt-ns-h', t('dmt_ns_title'), parts, 'fp-dmt-ns-card');
  }
  function dDraw() {
    D.page.textContent = '';
    D.page.appendChild(bulkCard());
    D.page.appendChild(resetCard());
    D.page.appendChild(reportCard());
  }
  document.addEventListener('click', function (e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act="ns-public"]') : null;
    if (!b || !D.page || !D.page.contains(b) || b.disabled) { return; }
    var mine = D.page;
    UI.setBusy(b, true);
    M.say(D.page.querySelector('.fp-dmt-ns-card'), t('dmt_public_asking'));
    FP.call('get', 'dnsNameserversPublic').then(function (r) {
      if (D.page !== mine) { return; }
      var rep = cleanReport(r);
      if (rep) { D.report = rep; }
      var old = D.page.querySelector('.fp-dmt-ns-card');
      var card = reportCard();
      old.parentNode.replaceChild(card, old);
      M.say(card, rep ? t('dmt_public_done') : '');
      if (!rep) { UI.showError(card, t('api_failed')); }
      card.querySelector('[data-fp-act="ns-public"]').focus();
    }, function (err) {
      if (D.page !== mine) { return; }
      UI.setBusy(b, false);
      var card = D.page.querySelector('.fp-dmt-ns-card');
      M.say(card, '');
      UI.showError(card, err.message);
    });
  });
  FP.view('tool:dns_maintenance', function () {
    var body = frame('dns_maintenance');
    if (!body) { return; }
    D = {page: body, zones: [], report: null};
    loading(body);
    Promise.all([FP.call('get', 'dnsZones'), FP.call('get', 'dnsNameservers')]).then(function (r) {
      if (D.page !== body) { return; }
      D.zones = cleanZones(r[0]);
      D.report = cleanReport(r[1]);
      if (!D.report) { unavailable(body, 'dns_maintenance'); return; }
      dDraw();
    }, function (err) {
      if (D.page === body) { unavailable(body, 'dns_maintenance', err); }
    });
  });

  /* ================= a settings page: one form, read with GET and saved whole with PUT ================= */
  /* spec: {id, key (the PATHS name), prefix, title, fields: [{name, label, hint, kind: 'number'|'check'|'choice', min, max, blank, choices}], note(v)} */
  function settingsPage(spec) {
    var S = {page: null, v: null};
    function draw(focus) {
      S.page.textContent = '';
      var controls = spec.fields.map(function (f) {
        var id = 'fp-' + spec.prefix + '-' + f.name.replace(/_/g, '-');
        if (f.kind === 'check') { return check(id, f.name, f.label, S.v[f.name], f.hint); }
        if (f.kind === 'choice') {
          var sel = el('select', {class: 'sig-select', id: id, name: f.name}, f.choices.map(function (c) { return el('option', {value: c.value, text: c.label}); }));
          sel.value = String(S.v[f.name]);
          return M.field(id, f.label, sel, f.hint);
        }
        return M.field(id, f.label, numberInput(id, f.name, S.v[f.name], f.min, f.max), f.hint);
      });
      var note = spec.note ? spec.note(S.v) : null;
      var form = el('form', {class: 'fp-form fp-mail-form fp-' + spec.prefix + '-form', novalidate: ''}, [M.errorLine(), M.statusLine()].concat(note ? [note] : [], controls,
        [el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('smt_save')})])]));
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var b = M.start(form);
        if (!b) { return; }
        var out = {};
        for (var i = 0; i < spec.fields.length; i++) {
          var f = spec.fields[i];
          var c = form.querySelector('[name="' + f.name + '"]');
          if (f.kind === 'check') { out[f.name] = c.checked; continue; }
          if (f.kind === 'choice') { out[f.name] = c.value; continue; }
          var n = readNumber(form, f.name, f.min, f.max, f.blank);
          if (n === null) { return; }
          out[f.name] = n;
        }
        var mine = S.page;
        UI.setBusy(b, true);
        FP.call('put', spec.key, out).then(function (r) {
          if (S.page !== mine) { return; }
          S.v = spec.clean(r) || S.v;
          draw('#fp-' + spec.prefix + '-h');
          M.say(S.page.querySelector('form'), t('smt_saved'));
        }, function (err) {
          if (S.page !== mine) { return; }
          UI.setBusy(b, false);
          M.failed(form, err);
        });
      });
      S.page.appendChild(M.card('fp-' + spec.prefix + '-h', spec.title, [el('p', {class: 'fp-muted', text: t(spec.id + '_what')}), form], 'fp-' + spec.prefix + '-card'));
      var target = focus && S.page.querySelector(focus);
      if (target) { target.focus(); }
    }
    FP.view('tool:' + spec.id, function () {
      var body = frame(spec.id);
      if (!body) { return; }
      S = {page: body, v: null};
      loading(body);
      FP.call('get', spec.key).then(function (r) {
        if (S.page !== body) { return; }
        S.v = spec.clean(r);
        if (!S.v) { unavailable(body, spec.id); return; }
        draw();
      }, function (err) {
        if (S.page === body) { unavailable(body, spec.id, err); }
      });
    });
  }

  settingsPage({id: 'ftp_server', key: 'ftpServerSettings', prefix: 'fts', title: t('fts_title'),
    clean: function (r) {
      if (!r || typeof r !== 'object' || (r.tls !== 'required' && r.tls !== 'optional')) { return null; }
      return {tls: r.tls, max_clients: num(r.max_clients) || 50, max_clients_per_ip: num(r.max_clients_per_ip) || 8, max_idle_minutes: num(r.max_idle_minutes) || 15,
        broken_clients: r.broken_clients === true};
    },
    note: function (v) { return v.tls === 'optional' ? el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-plain': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('fts_plain_on')})]) : null; },
    fields: [
      {name: 'tls', kind: 'choice', label: t('fts_tls'), hint: t('fts_tls_hint'), choices: [{value: 'required', label: t('fts_tls_required')}, {value: 'optional', label: t('fts_tls_optional')}]},
      {name: 'max_clients', label: t('fts_max_clients'), hint: t('fts_max_clients_hint'), min: 1, max: 2000},
      {name: 'max_clients_per_ip', label: t('fts_per_ip'), hint: t('fts_per_ip_hint'), min: 1, max: 200},
      {name: 'max_idle_minutes', label: t('fts_idle'), hint: t('fts_idle_hint'), min: 1, max: 240},
      {name: 'broken_clients', kind: 'check', label: t('fts_broken'), hint: t('fts_broken_hint')}]});

  settingsPage({id: 'imap_pop', key: 'imapPopSettings', prefix: 'imp', title: t('imp_title'),
    clean: function (r) {
      if (!r || typeof r !== 'object' || typeof r.pop3_off !== 'boolean') { return null; }
      return {imap_max_per_ip: num(r.imap_max_per_ip), pop3_max_per_ip: num(r.pop3_max_per_ip), imap_idle_minutes: num(r.imap_idle_minutes), pop3_off: r.pop3_off,
        installed: r.pop3_installed === true};
    },
    note: function (v) { return v.installed ? null : el('p', {class: 'fp-muted', 'data-fp-no-pop3': '', text: t('imp_no_pop3')}); },
    fields: [
      {name: 'imap_max_per_ip', label: t('imp_imap_per_ip'), hint: t('imp_per_ip_hint'), min: 1, max: 1000, blank: true},
      {name: 'pop3_max_per_ip', label: t('imp_pop3_per_ip'), hint: t('imp_per_ip_hint'), min: 1, max: 1000, blank: true},
      {name: 'imap_idle_minutes', label: t('imp_idle'), hint: t('imp_idle_hint'), min: 1, max: 30, blank: true},
      {name: 'pop3_off', kind: 'check', label: t('imp_pop3_off'), hint: t('imp_pop3_off_hint')}]});

  settingsPage({id: 'webdisk_server', key: 'webdiskServer', prefix: 'wds', title: t('wds_title'),
    clean: function (r) {
      if (!r || typeof r !== 'object' || typeof r.enabled !== 'boolean') { return null; }
      return {enabled: r.enabled, read_only: r.read_only === true, max_lock_minutes: num(r.max_lock_minutes) || 60};
    },
    note: function (v) {
      if (!v.enabled) { return el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-wds-off': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('wds_off_note')})]); }
      return v.read_only ? el('div', {class: 'sig-banner', role: 'note', 'data-fp-wds-ro': ''}, [UI.icon(FP.ui, 'ui_info'), el('span', {text: t('wds_ro_note')})]) : null;
    },
    fields: [
      {name: 'enabled', kind: 'check', label: t('wds_enabled'), hint: t('wds_enabled_hint')},
      {name: 'read_only', kind: 'check', label: t('wds_read_only'), hint: t('wds_read_only_hint')},
      {name: 'max_lock_minutes', label: t('wds_lock'), hint: t('wds_lock_hint'), min: 1, max: 60}]});

  /* ================= Domain forwarding ================= */
  var F = {page: null, list: [], max: 500};
  var STATUSES = [301, 302, 307, 308];
  function cleanForwards(r) {
    if (!r || typeof r !== 'object' || !Array.isArray(r.forwards)) { return null; }
    return r.forwards.filter(function (f) { return f && HOST_RE.test(str(f.domain, 253)) && /^https?:\/\//.test(str(f.target, 2000)); }).map(function (f) {
      return {domain: f.domain, target: str(f.target, 2000), status: STATUSES.indexOf(f.status) >= 0 ? f.status : 301, keep_path: f.keep_path === true, www: f.www === true, shadowed: f.shadowed === true};
    });
  }
  function wire(f) { return {domain: f.domain, target: f.target, status: f.status, keep_path: f.keep_path, www: f.www}; }
  function fSave(next, form, b, done) {
    var mine = F.page;
    UI.setBusy(b, true);
    FP.call('put', 'domainForwards', {forwards: next.map(wire)}).then(function (r) {
      if (F.page !== mine) { return; }
      var list = cleanForwards(r);
      if (list) { F.list = list; }
      fDraw();
      done();
    }, function (err) {
      if (F.page !== mine) { return; }
      UI.setBusy(b, false);
      M.failed(form, err);
    });
  }
  function fDraw(focus) {
    var page = F.page;
    page.textContent = '';
    var listCard;
    if (!F.list.length) {
      listCard = el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('dfw_none')});
    } else {
      listCard = table('fp-dfw-list-h', [{text: t('dfw_domain')}, {text: t('dfw_target')}, {text: t('dfw_kind')}, {text: t('mail_actions'), hidden: true}], F.list.map(function (f, i) {
        return el('tr', {'data-fp-forward': f.domain}, [th(f.domain + (f.www ? ' (+www)' : '')), td(f.target, 'sig-mono fp-dfw-target'),
          el('td', null, [el('span', {class: 'sig-pill', text: t(f.status === 301 || f.status === 308 ? 'dfw_permanent' : 'dfw_temporary', {code: f.status})}),
            f.keep_path ? el('span', {class: 'fp-muted fp-row-note', text: ' ' + t('dfw_keeps_path')}) : null,
            f.shadowed ? el('span', {class: 'sig-pill sig-pill--warn', text: t('dfw_shadowed')}) : null]),
          el('td', {class: 'fp-dfw-act'}, [el('button', {class: 'sig-btn sig-btn--danger sig-btn--sm', type: 'button', 'data-fp-act': 'dfw-remove', 'data-fp-i': String(i),
            'aria-label': t('dfw_remove_label', {domain: f.domain}), text: t('dfw_remove')})])]);
      }), 'fp-dfw-table');
    }
    var listForm = el('div', {class: 'fp-mail-form fp-dfw-listbox'}, [M.errorLine(), M.statusLine(), listCard]);
    page.appendChild(M.card('fp-dfw-list-h', t('dfw_list_title'), [el('p', {class: 'fp-muted', text: t('dfw_what')}), listForm], 'fp-dfw-list'));

    var dom = el('input', {class: 'sig-input', id: 'fp-dfw-domain', name: 'domain', type: 'text', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', maxlength: '253', placeholder: 'old-name.com'});
    var target = el('input', {class: 'sig-input', id: 'fp-dfw-target', name: 'target', type: 'url', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', maxlength: '2000', placeholder: 'https://new-name.com/'});
    var status = el('select', {class: 'sig-select', id: 'fp-dfw-status', name: 'status'}, STATUSES.map(function (s) {
      return el('option', {value: String(s), text: t(s === 301 || s === 308 ? 'dfw_permanent' : 'dfw_temporary', {code: s})});
    }));
    var form = el('form', {class: 'fp-form fp-mail-form fp-dfw-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-dfw-domain', t('dfw_domain'), dom, t('dfw_domain_hint')), M.field('fp-dfw-target', t('dfw_target'), target, t('dfw_target_hint')),
      M.field('fp-dfw-status', t('dfw_kind'), status), check('fp-dfw-keep', 'keep_path', t('dfw_keep'), true, t('dfw_keep_hint')),
      check('fp-dfw-www', 'www', t('dfw_www'), true),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('dfw_add')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var d = dom.value.trim().toLowerCase().replace(/\.$/, '');
      if (!HOST_RE.test(d)) { M.fieldError(form, dom, t('dfw_domain_bad')); return; }
      var tv = target.value.trim();
      if (!/^https?:\/\/[^\s"$\\<>`]+$/i.test(tv)) { M.fieldError(form, target, t('dfw_target_bad')); return; }
      if (F.list.length >= F.max) { M.fieldError(form, dom, t('dfw_full', {max: count(F.max)})); return; }
      var next = F.list.filter(function (f) { return f.domain !== d; }).concat([{domain: d, target: tv, status: Number(status.value),
        keep_path: form.querySelector('[name="keep_path"]').checked, www: form.querySelector('[name="www"]').checked}]);
      fSave(next, form, b, function () {
        M.say(F.page.querySelector('.fp-dfw-listbox'), t('dfw_added', {domain: d}));
        F.page.querySelector('#fp-dfw-list-h').focus();
      });
    });
    page.appendChild(M.card('fp-dfw-add-h', t('dfw_add_title'), [form], 'fp-dfw-add'));
    var f = focus && page.querySelector(focus);
    if (f) { f.focus(); }
  }
  document.addEventListener('click', function (e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !F.page || !F.page.contains(b) || b.disabled) { return; }
    var act = b.getAttribute('data-fp-act');
    var box = F.page.querySelector('.fp-dfw-listbox');
    if (act === 'dfw-remove') {
      F.removing = Number(b.getAttribute('data-fp-i'));
      M.confirmIn(b.parentNode, t('dfw_remove_ask'), 'dfw-remove-yes', t('dfw_remove_yes'));
    } else if (act === 'confirm-no' && F.removing !== undefined) {
      var i = F.removing;
      F.removing = undefined;
      fDraw('[data-fp-i="' + i + '"]');
    } else if (act === 'dfw-remove-yes' && F.removing !== undefined) {
      var gone = F.list[F.removing];
      F.removing = undefined;
      fSave(F.list.filter(function (x) { return x !== gone; }), box, b, function () {
        M.say(F.page.querySelector('.fp-dfw-listbox'), t('dfw_removed', {domain: gone.domain}));
        F.page.querySelector('#fp-dfw-list-h').focus();
      });
    }
  });
  FP.view('tool:domain_forwards', function () {
    var body = frame('domain_forwards');
    if (!body) { return; }
    F = {page: body, list: [], max: 500};
    loading(body);
    FP.call('get', 'domainForwards').then(function (r) {
      if (F.page !== body) { return; }
      var list = cleanForwards(r);
      if (!list) { unavailable(body, 'domain_forwards'); return; }
      F.list = list;
      F.max = num(r.max) || 500;
      fDraw();
    }, function (err) {
      if (F.page === body) { unavailable(body, 'domain_forwards', err); }
    });
  });
})();

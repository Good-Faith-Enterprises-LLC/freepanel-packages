/* freePanel billing transactions (#/tool/billing_transactions; docs/api.md, "Billing: payments"; docs/billing/navigation-map.md, "Transactions"):
   every payment and refund, by hand or through a gateway, filtered by kind, state, gateway and client. An invoice or a client named on a row
   opens on its own page. Amounts are whole cents. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;

  var X = null;
  FP.view('tool:billing_transactions', function () {
    var page = B.frame('billing_transactions', 'fp-btx');
    if (!page) { return; }
    X = {page: page, names: {}, gateways: ['manual']};
    var mine = X;
    var alive = function () { return X === mine && page.isConnected; };
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    var L = B.lister({page: page, pre: 'fp-btx', title: t('btx_list_title'), findLabel: t('btx_find'), tableCls: 'fp-btx-table', alive: alive,
      before: function () { return [el('p', {class: 'fp-muted fp-row-note', text: t('btx_what')})]; },
      blank: {kind: '', status: '', gateway: '', customer: ''},
      filters: [
        {name: 'kind', label: t('btx_f_kind'), control: function (v) { return B.select('fp-btx-f-kind', 'kind', [['', t('bil_any')], ['payment', t('binv_tx_payment')], ['refund', t('binv_tx_refund')]], v); }},
        {name: 'status', label: t('btx_f_status'), control: function (v) { return B.select('fp-btx-f-status', 'status', [['', t('bil_any')]].concat(['succeeded', 'pending', 'failed'].map(function (s) { return [s, B.word('tx', s)]; })), v); }},
        {name: 'gateway', label: t('btx_f_gateway'), control: function (v) { return B.select('fp-btx-f-gateway', 'gateway', [['', t('bil_any')]].concat(X.gateways.map(function (g) { return [g, B.gatewayText(g)]; })), v); }},
        {name: 'customer', control: function (v) { return B.clientPicker('fp-btx-f-client', {name: 'customer', label: t('btx_f_client'), placeholder: t('bil_any'), value: v, valueName: v ? X.names[v] : ''}); }}],
      load: function (f, offset, limit) {
        return B.listOf('billingTransactions', {limit: String(limit), offset: String(offset), kind: f.kind, status: f.status, gateway: f.gateway, customer: f.customer}, 'transactions', B.cleanTx).then(function (r) {
          return B.namesFor(X.names, r.items.map(function (x) { return x.customer_id; })).then(function () { return r; });
        });
      },
      heads: [B.th(t('btx_col_date')), B.th(t('btx_col_client')), B.th(t('btx_col_invoice')), B.th(t('btx_col_kind')), B.th(t('btx_col_gateway')), B.th(t('btx_col_method')),
        B.th(t('btx_col_amount'), 'fp-bil-num'), B.th(t('btx_col_status')), B.th(t('btx_col_reference'))],
      row: function (x) {
        var inv = x.invoice_id ? t('binv_invoice_ref', {id: String(x.invoice_id)}) : '—';
        return el('tr', {'data-fp-tx': String(x.id)}, [el('td', {class: 'fp-bil-nowrap', text: B.when(x.created) || '—'}), el('td', {class: 'fp-bil-wrap'}, [B.clientLink(X.names, x.customer_id)]),
          el('td', null, [x.invoice_id && FP.tools.billing_invoices ? B.button('open-invoice', inv, 'sig-btn--link fp-bil-link', {'data-fp-id': String(x.invoice_id), 'aria-label': t('bcl_open_invoice_id', {id: String(x.invoice_id)})}) : inv]),
          el('td', {text: t('binv_tx_' + x.kind)}), el('td', {text: B.gatewayText(x.gateway)}), el('td', {text: B.methodText(x.method)}),
          el('td', {class: 'fp-bil-num', text: (x.kind === 'refund' ? '−' : '') + B.money(x.amount_cents, x.currency)}), el('td', null, [B.statePill('tx', x.status)]),
          el('td', {class: 'fp-bil-wrap', text: [x.reference, x.error].filter(Boolean).join(' · ') || '—'})]);
      },
      none: t('btx_none'), noneMatch: t('btx_none_match'),
      found: function (n) { return n === 1 ? t('btx_found_1') : t('btx_found', {n: B.num(n)}); }});
    page.addEventListener('click', function (e) {
      var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
      if (!b || b.disabled || !alive()) { return; }
      var a = b.getAttribute('data-fp-act');
      var xid = Number(b.getAttribute('data-fp-id')) || 0;
      if (a === 'open-invoice' && xid) { B.go('billing_invoices', {invoice: xid}); } else if (a === 'open-client' && xid) { B.go('billing_clients', {client: xid}); }
    });
    FP.call('get', 'billingGateways').then(function (r) {
      return ['manual'].concat(B.pickAll(r && r.gateways, {id: [40]}, 'id').map(function (g) { return g.id; }).filter(function (g) { return g !== 'manual'; }));
    }, function () { return ['manual']; }).then(function (g) {
      if (!alive()) { return; }
      X.gateways = g;
      L.show();
    });
  });
})();

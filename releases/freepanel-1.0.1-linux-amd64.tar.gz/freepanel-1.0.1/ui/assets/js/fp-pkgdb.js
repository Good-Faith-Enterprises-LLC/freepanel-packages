/* freePanel package database rebuild (#/tool/package_db_rebuild), the admin panel's page for repairing the package manager's
   own database (docs/api.md, "System packages", POST .../rebuild): on AlmaLinux and the like rpm rebuilds its database from the
   installed packages and reads it back; on Ubuntu and Debian, which keep no such database, dpkg finishes what an interrupted
   install left half done, then dpkg's audit and apt's dependency check run. It runs as root, so the admin's own password is asked
   again. It is one of the system packages jobs: it never runs beside an install, a removal or a server update, and the page
   follows it to the end with the end of its output. What the package manager says is shown as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var POLL_MS = 3000;
  var MAX_LOG = 200;
  var STATES = ['idle', 'running', 'succeeded', 'failed'];

  var S = null;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 400) : ''; }
  function obj(v) { return v && typeof v === 'object' ? v : {}; }
  function list(v) { return Array.isArray(v) ? v : []; }
  function when(iso) {
    var d = typeof iso === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(iso) ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }
  function exitOf(v) { return typeof v === 'number' && isFinite(v) ? Math.floor(v) : null; }

  /* ---------- what the server says, kept to the shapes the page draws ---------- */
  function cleanJob(j) {
    j = obj(j);
    return {state: STATES.indexOf(j.state) >= 0 ? j.state : 'idle', action: str(j.action, 20), by: str(j.by, 64), started: str(j.started), ended: str(j.ended),
      exit: exitOf(j.exit_code), timedOut: j.timed_out === true,
      log: list(j.log).filter(function (l) { return typeof l === 'string'; }).slice(-MAX_LOG).map(function (l) { return l.slice(0, 400); }), truncated: j.log_truncated === true};
  }
  function cleanStatus(r) {
    r = obj(r);
    return {supported: r.supported === true, family: r.family === 'apt' || r.family === 'dnf' ? r.family : '', reason: str(r.reason), busy: r.busy === true, job: cleanJob(r.job)};
  }
  /* the newest rebuild in the log of package jobs, or null */
  function lastRebuild(entries) {
    var e = list(entries).map(obj).filter(function (x) { return x.action === 'rebuild'; })[0];
    return e ? {by: str(e.by, 64), started: str(e.started), state: STATES.indexOf(e.state) >= 0 ? e.state : 'running', exit: exitOf(e.exit_code)} : null;
  }
  function running() { return S.status.busy || S.status.job.state === 'running'; }
  function mine(j) { return j.action === 'rebuild'; }

  /* ---------- the cards ---------- */
  function runCard() {
    var d = S.status;
    var parts = [];
    if (!d.supported) {
      parts.push(el('p', {'data-fp-unsupported': '', text: d.reason ? t('pkdb_unsupported_why', {why: d.reason}) : t('pkdb_unsupported')}));
      return M.card('fp-pkdb-run-h', t('pkdb_title'), parts, 'fp-pkdb-run');
    }
    parts.push(el('p', {'data-fp-family': d.family, text: t(d.family === 'apt' ? 'pkdb_what_apt' : 'pkdb_what_dnf')}));
    parts.push(el('p', {class: 'fp-muted', text: t('pkdb_when')}));
    if (running()) {
      parts.push(el('p', {class: 'fp-warn-line', 'data-fp-busy': mine(d.job) ? 'rebuild' : 'other', text: t(mine(d.job) ? 'pkdb_busy_self' : 'pkdb_busy_other')}));
    }
    var pw = el('input', {class: 'sig-input', id: 'fp-pkdb-pw', name: 'current_password', type: 'password', autocomplete: 'current-password', maxlength: '1024'});
    parts.push(el('form', {class: 'fp-form fp-pkdb-form', 'data-fp-form': 'rebuild', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-pkdb-pw', t('pkdb_password'), pw, t('pkdb_password_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('pkdb_run'), disabled: running()})])]));
    return M.card('fp-pkdb-run-h', t('pkdb_title'), parts, 'fp-pkdb-run');
  }
  function jobCard() {
    if (!S.status.supported) { return null; }
    var j = S.status.job;
    var parts = [M.errorLine(), M.statusLine()];
    if (!mine(j) || j.state === 'idle') {
      var last = S.last;
      if (!last) {
        parts.push(el('p', {class: 'fp-muted', 'data-fp-last': 'none', text: t('pkdb_never')}));
      } else {
        var key = last.state === 'succeeded' ? 'pkdb_last_ok' : (last.state === 'failed' ? 'pkdb_last_failed' : 'pkdb_last_running');
        parts.push(el('p', {'data-fp-last': last.state, text: t(key, {when: when(last.started) || '—', by: last.by || '—'})}));
      }
      return M.card('fp-pkdb-job-h', t('pkdb_job_title'), parts, 'fp-pkdb-job');
    }
    var at = when(j.state === 'running' ? j.started : j.ended) || '—';
    var line = j.state === 'running' ? 'pkdb_job_running' : (j.state === 'succeeded' ? 'pkdb_job_ok' : 'pkdb_job_failed');
    parts.push(el('p', {'data-fp-job': j.state, class: j.state === 'failed' ? 'fp-bk-bad' : '', text: t(line, {when: at})}));
    if (j.by) { parts.push(el('p', {class: 'fp-muted', text: t('spk_job_by', {by: j.by})})); }
    if (j.state === 'failed') {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-job-why': '', text: j.timedOut ? t('spk_job_timeout') : (j.exit !== null ? t('spk_job_exit', {code: String(j.exit)}) : t('spk_job_noexit'))}));
    }
    if (j.log.length) {
      if (j.truncated) { parts.push(el('p', {class: 'fp-muted sig-hint', text: t('spk_log_cut')})); }
      parts.push(el('pre', {class: 'fp-upd-log sig-mono', tabindex: '0', role: 'region', 'aria-label': t('pkdb_log_label'), 'data-fp-log': '', text: j.log.join('\n')}));
    } else if (j.state === 'running') {
      parts.push(el('p', {class: 'fp-muted', text: t('spk_log_none')}));
    }
    return M.card('fp-pkdb-job-h', t('pkdb_job_title'), parts, 'fp-pkdb-job');
  }
  var CARDS = ['fp-pkdb-run', 'fp-pkdb-job'];
  var MAKERS = {'fp-pkdb-run': runCard, 'fp-pkdb-job': jobCard};

  /* puts a card in its place; a field being typed in keeps what it has and the focus */
  function draw(cls) {
    var old = S.page.querySelector('.' + cls);
    var fresh = MAKERS[cls]();
    var focused = document.activeElement;
    var typed = old && old.querySelector('#fp-pkdb-pw');
    var keep = typed && focused === typed;
    if (!fresh) { if (old) { old.remove(); } return null; }
    var pw = fresh.querySelector('#fp-pkdb-pw');
    if (typed && pw) { pw.value = typed.value; }
    if (old) {
      old.replaceWith(fresh);
    } else {
      var later = null;
      for (var i = CARDS.indexOf(cls) + 1; i < CARDS.length && !later; i++) { later = S.page.querySelector('.' + CARDS[i]); }
      S.page.insertBefore(fresh, later);
    }
    var log = fresh.querySelector('[data-fp-log]');
    if (log) { log.scrollTop = log.scrollHeight; }
    if (keep && pw) { pw.focus(); }
    return fresh;
  }
  function drawAll() { CARDS.forEach(draw); }
  function say(cls, text) { var c = S.page.querySelector('.' + cls); if (c) { M.say(c, text); } }

  /* ---------- asking the server ---------- */
  function loadLast() {
    var me = S;
    return FP.call('get', 'sysPkgsHistory').then(function (r) {
      if (S !== me) { return; }
      me.last = lastRebuild(obj(r).entries);
      /* the card shows the last rebuild only when the latest job is not one; then what it says stays */
      if (!mine(me.status.job) || me.status.job.state === 'idle') { draw('fp-pkdb-job'); }
    }, function () {});
  }
  function poll() {
    window.clearTimeout(S.timer);
    var me = S;
    me.timer = window.setTimeout(function () {
      if (S !== me || !document.body.contains(me.page)) { return; }
      FP.call('get', 'sysPkgs').then(function (r) {
        if (S !== me) { return; }
        me.status = cleanStatus(r);
        if (running()) { drawAll(); poll(); return; }
        drawAll();
        if (me.watching && mine(me.status.job)) { say('fp-pkdb-job', t(me.status.job.state === 'succeeded' ? 'pkdb_ended_ok' : 'pkdb_ended_bad')); }
        me.watching = false;
        loadLast();
      }, function () { if (S === me) { poll(); } });
    }, POLL_MS);
  }
  /* reads the status again after a refusal because another job runs; the refusal stays shown */
  function catchUp(err) {
    var me = S;
    FP.call('get', 'sysPkgs').then(function (r) {
      if (S !== me) { return; }
      me.status = cleanStatus(r);
      drawAll();
      var form = me.page.querySelector('.fp-pkdb-form');
      if (form) { M.failed(form, err); }
      if (running()) { poll(); }
    }, function () {});
  }
  function rebuild(form) {
    var me = S;
    var b = M.start(form);
    if (!b) { return; }
    var pw = form.querySelector('#fp-pkdb-pw');
    if (!pw.value) { M.fieldError(form, pw, t('pkdb_password_needed')); return; }
    UI.setBusy(b, true);
    FP.call('post', 'sysPkgsRebuild', {current_password: pw.value}).then(function (r) {
      if (S !== me) { return; }
      pw.value = '';
      me.status.job = cleanJob(obj(r).job);
      me.status.busy = me.status.job.state === 'running';
      me.watching = true;
      drawAll();
      var h = me.page.querySelector('.fp-pkdb-job .fp-h2');
      if (h) { h.focus(); }
      say('fp-pkdb-job', t('pkdb_started'));
      poll();
    }, function (err) {
      if (S !== me) { return; }
      UI.setBusy(b, false);
      pw.value = '';
      M.failed(form, err);
      if (err && err.status === 409) { catchUp(err); }
    });
  }

  function onSubmit(e) {
    var form = e.target;
    if (!S || !S.page || !S.page.contains(form) || form.getAttribute('data-fp-form') !== 'rebuild') { return; }
    e.preventDefault();
    if (running()) { return; }
    rebuild(form);
  }
  document.addEventListener('submit', onSubmit);

  FP.view('tool:package_db_rebuild', function () {
    var tool = FP.tools.package_db_rebuild;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('pkdb_desc'), cls: 'fp-mail fp-upd fp-pkdb',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    if (S) { window.clearTimeout(S.timer); }
    S = {page: body, status: null, last: null, timer: 0, watching: false};
    var me = S;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'sysPkgs').then(function (r) {
      if (S !== me) { return; }
      me.status = cleanStatus(r);
      body.textContent = '';
      drawAll();
      if (me.status.supported) { loadLast(); }
      if (running()) { me.watching = mine(me.status.job); poll(); }
    }, function (err) {
      if (S !== me) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

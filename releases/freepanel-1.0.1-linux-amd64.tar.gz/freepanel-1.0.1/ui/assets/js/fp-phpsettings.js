/* freePanel PHP settings (#/tool/php_settings), the customer panel's page for the PHP values of one site (docs/api.md,
   "PHP settings"): pick a site, change its limits and options, or give one back to the default. The server lists the
   settings it allows with their kind, default and range, and says which the site's own file sets; the page checks what
   is typed against that before it asks, and the server checks again. A saved change reaches PHP within a minute. The
   page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var DOMAIN_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var NAME_RE = /^[a-z][a-z0-9_.]{0,63}$/;
  var KINDS = ['size', 'int', 'bool'];
  var ORDER = {main: 0, addon: 1, sub: 2};

  var page = null;     /* the frame's body */
  var account = '';
  var sites = [];      /* the account's sites, main first */
  var suspended = false;
  var domain = '';     /* the site shown */
  var state = null;    /* the last PHPSettings the server sent for it */
  var problem = '';    /* the server's word when the site's settings could not be read */
  var loads = 0;       /* counts loads, so a slow answer for a site picked before is dropped */

  function str(v) { return typeof v === 'string' ? v : ''; }
  function num(v) { return typeof v === 'number' && isFinite(v) ? v : 0; }
  /* the server says "sub" in lists and takes "subdomain" in a POST; either reads as a subdomain */
  function kindOf(k) { return k === 'main' || k === 'addon' ? k : (k === 'sub' || k === 'subdomain' ? 'sub' : ''); }
  function cleanSites(v) {
    v = v && typeof v === 'object' ? v : {};
    var list = (Array.isArray(v.sites) ? v.sites : []).filter(function (s) {
      return s && DOMAIN_RE.test(str(s.domain)) && kindOf(s.kind);
    }).map(function (s) { return {domain: s.domain, kind: kindOf(s.kind)}; });
    list.sort(function (a, b) { return ORDER[a.kind] - ORDER[b.kind] || (a.domain < b.domain ? -1 : 1); });
    return {suspended: v.suspended === true, sites: list};
  }
  FP.cleanSites = cleanSites;   /* the site rules pages (fp-siterules.js) list the account's sites the same way */
  function clean(v) {
    v = v && typeof v === 'object' ? v : {};
    var list = (Array.isArray(v.settings) ? v.settings : []).filter(function (s) {
      return s && NAME_RE.test(str(s.name)) && KINDS.indexOf(s.kind) >= 0;
    }).map(function (s) {
      return {name: s.name, kind: s.kind, def: str(s.default), min: num(s.min), max: num(s.max), minusOne: s.minus_one === true,
        value: str(s.value), set: s.set === true, valid: s.valid !== false};
    });
    return {domain: str(v.domain), version: str(v.php_version), file: str(v.file), exists: v.exists === true, settings: list};
  }

  /* bytes as PHP writes them: the largest unit that divides them */
  function showSize(n) {
    if (n >= 1073741824 && n % 1073741824 === 0) { return n / 1073741824 + 'G'; }
    if (n >= 1048576 && n % 1048576 === 0) { return n / 1048576 + 'M'; }
    if (n >= 1024 && n % 1024 === 0) { return n / 1024 + 'K'; }
    return String(n);
  }
  function showLimit(s, n) { return s.kind === 'size' ? showSize(n) : String(n); }
  /* the bytes of a size such as 128M, or -1 when it isn't one */
  function sizeBytes(v) {
    var m = /^([1-9][0-9]{0,8})([KkMmGg]?)$/.exec(v);
    if (!m) { return -1; }
    return Number(m[1]) * ({'': 1, k: 1024, m: 1048576, g: 1073741824}[m[2].toLowerCase()]);
  }
  function label(s) {
    var k = 'phps_n_' + s.name.replace(/\./g, '_');
    return t(k) === k ? s.name : t(k);
  }
  function describe(s) {
    var k = 'phps_d_' + s.name.replace(/\./g, '_');
    return t(k) === k ? '' : t(k);
  }
  function range(s) {
    var p = {min: showLimit(s, s.min), max: showLimit(s, s.max)};
    return s.minusOne ? t('phps_range_minus', p) : t('phps_range', p);
  }
  function idOf(s) { return 'fp-phps-' + s.name.replace(/\./g, '_'); }

  /* what is typed for a setting, as the server takes it: the text, or null with a message on the form when it can't do */
  function read(form, s) {
    var f = UI.fieldNamed(form, s.name);
    var v = f.value.trim();
    var p = {label: label(s), min: showLimit(s, s.min), max: showLimit(s, s.max)};
    if (s.kind === 'bool') { return v; }
    if (s.kind === 'size') {
      var bytes = sizeBytes(v);
      if (bytes < 0) { M.fieldError(form, f, t('phps_bad_size', p)); return null; }
      if (bytes < s.min || bytes > s.max) { M.fieldError(form, f, t('phps_out_of_range', p)); return null; }
      return v;
    }
    if (!/^-?(0|[1-9][0-9]{0,11})$/.test(v)) { M.fieldError(form, f, t('phps_bad_int', p)); return null; }
    if (!(s.minusOne && v === '-1') && (Number(v) < s.min || Number(v) > s.max)) { M.fieldError(form, f, t(s.minusOne ? 'phps_out_of_range_minus' : 'phps_out_of_range', p)); return null; }
    return v;
  }
  /* an error from the server: the message, and the setting it names marked */
  function failed(form, err) {
    var name = err && typeof err.field === 'string' ? err.field.replace(/^settings\./, '') : '';
    var f = name ? UI.fieldNamed(form, name) : null;
    var l = f ? form.querySelector('label[for="' + f.id + '"]') : null;
    M.fieldError(form, f, (l ? l.firstChild.textContent.trim() + ': ' : '') + (err ? err.message : t('api_failed')));
  }

  /* ---- the site ---- */
  function siteCard() {
    var pick = el('select', {class: 'sig-select', id: 'fp-phps-site', 'aria-describedby': 'fp-phps-site-hint'}, sites.map(function (s) {
      return el('option', {value: s.domain, text: s.domain});
    }));
    pick.value = domain;
    pick.addEventListener('change', function () {
      domain = pick.value;
      load();
    });
    var info = el('p', {class: 'fp-muted', 'data-fp-site-info': '', text: ''});
    var body = [el('div', {class: 'sig-field fp-phps-site'}, [el('label', {class: 'sig-label', for: 'fp-phps-site', text: t('phps_site')}), pick,
      el('span', {class: 'sig-hint', id: 'fp-phps-site-hint', text: t('phps_site_hint')})]), info];
    return M.card('fp-phps-site-h', t('phps_site_title'), body);
  }
  function siteInfo() {
    var info = page.querySelector('[data-fp-site-info]');
    if (!info) { return; }
    info.textContent = !state ? '' : (state.version ? t('phps_php', {version: state.version}) + ' ' : '') +
      t(state.exists ? 'phps_in_file' : 'phps_in_new', {file: state.file});
  }

  /* ---- the settings ---- */
  function row(s) {
    var id = idOf(s);
    var control;
    if (s.kind === 'bool') {
      control = el('select', {class: 'sig-select fp-phps-val', id: id, name: s.name, 'aria-describedby': id + '-hint'}, ['On', 'Off'].map(function (v) {
        return el('option', {value: v, text: v});
      }));
      control.value = s.value === 'On' || s.value === 'Off' ? s.value : s.def;
      if (!s.valid) { control.insertBefore(el('option', {value: s.value, text: s.value}), control.firstChild); control.value = s.value; }
    } else {
      control = el('input', {class: 'sig-input sig-mono fp-phps-val', id: id, name: s.name, type: 'text', value: s.value, maxlength: '12',
        autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', 'aria-describedby': id + '-hint'});
      if (s.kind === 'int') { control.setAttribute('inputmode', 'numeric'); }
    }
    control.setAttribute('data-fp-was', s.value);
    if (suspended) { control.disabled = true; }
    var hint = [describe(s), t('phps_default', {value: s.def}) + (s.kind === 'bool' ? '' : ' ' + range(s))].filter(Boolean).join(' ');
    var pill = !s.valid ? el('span', {class: 'sig-pill sig-pill--warn', text: t('phps_invalid_pill')}) :
      s.set ? el('span', {class: 'sig-pill sig-pill--ok', text: t('phps_set_pill')}) : el('span', {class: 'sig-pill', text: t('phps_default_pill')});
    var reset = s.set && !suspended ? el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'reset',
      'data-fp-setting': s.name, 'aria-label': t('phps_reset_for', {setting: label(s)}), text: t('phps_reset')}) : null;
    return el('div', {class: 'sig-field fp-phps-row', 'data-fp-setting': s.name}, [
      el('label', {class: 'sig-label', for: id}, [document.createTextNode(label(s)), el('span', {class: 'fp-phps-name sig-mono', text: s.name})]),
      control,
      el('span', {class: 'sig-hint', id: id + '-hint', text: hint}),
      el('div', {class: 'fp-phps-state'}, [pill, reset,
        !s.valid ? el('span', {class: 'fp-muted fp-row-note', text: t('phps_invalid_hint', {value: s.value})}) : null])]);
  }
  function settingsCard() {
    var body = [el('h2', {class: 'fp-h2', id: 'fp-phps-form-h', tabindex: '-1', text: t('phps_settings_title', {domain: domain})})];
    if (!state) {
      /* loading, or the server's word on why the settings can't be shown */
      body.push(problem ? M.errorLine() : el('p', {class: 'fp-muted', text: t('loading')}));
    } else {
      var form = el('form', {class: 'fp-form fp-phps-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
        el('div', {class: 'fp-phps-grid'}, state.settings.map(row)),
        suspended ? null : el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('phps_save')})])]);
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        save(form);
      });
      body.push(el('p', {class: 'fp-muted', text: t('phps_delay')}), form);
    }
    var node = el('section', {class: 'sig-card fp-phps-card', 'aria-labelledby': 'fp-phps-form-h'}, [el('div', {class: 'sig-card-body'}, body)]);
    if (problem) { UI.showError(node, problem); }
    return node;
  }
  /* the settings card as it is now, with the answer to the last save or reset in its status line */
  function showSettings(note, focus) {
    var old = page.querySelector('.fp-phps-card');
    var node = settingsCard();
    if (old) { page.replaceChild(node, old); } else { page.appendChild(node); }
    siteInfo();
    if (note) { M.say(node, note); }
    if (focus) {
      var f = typeof focus === 'string' ? UI.fieldNamed(node, focus) : node.querySelector('#fp-phps-form-h');
      if (f) { f.focus(); }
    }
    return node;
  }

  function save(form) {
    var b = M.start(form);
    if (!b) { return; }
    var body = {};
    var changed = 0;
    for (var i = 0; i < state.settings.length; i++) {
      var s = state.settings[i];
      var f = UI.fieldNamed(form, s.name);
      if (!f || f.value.trim() === f.getAttribute('data-fp-was')) { continue; }
      var v = read(form, s);
      if (v === null) { return; }
      body[s.name] = v;
      changed++;
    }
    if (!changed) {
      M.say(form, t('phps_nothing'));
      return;
    }
    UI.setBusy(b, true);
    var mine = loads;
    FP.call('put', 'phpSettings', {settings: body}, {name: account, domain: domain}).then(function (r) {
      if (mine !== loads) { return; }
      state = clean(r);
      showSettings(t('phps_saved'), true);
    }, function (err) {
      UI.setBusy(b, false);
      failed(form, err);
    });
  }
  /* what is typed in rows whose value is not the one the server sent, by setting name */
  function typed(form) {
    var out = {};
    state.settings.forEach(function (s) {
      var f = UI.fieldNamed(form, s.name);
      if (f && f.value !== f.getAttribute('data-fp-was')) { out[s.name] = f.value; }
    });
    return out;
  }
  function reset(name, b) {
    var form = page.querySelector('.fp-phps-form');
    var s = state.settings.filter(function (x) { return x.name === name; })[0];
    if (!form || !s) { return; }
    var keep = typed(form);
    delete keep[name];
    var put = {};
    put[name] = null;
    UI.showError(form, '');
    M.say(form, '');
    UI.setBusy(b, true);
    var mine = loads;
    FP.call('put', 'phpSettings', {settings: put}, {name: account, domain: domain}).then(function (r) {
      if (mine !== loads) { return; }
      state = clean(r);
      var node = showSettings(t('phps_reset_done', {setting: label(s)}), name);
      Object.keys(keep).forEach(function (k) {
        var f = UI.fieldNamed(node, k);
        if (f) { f.value = keep[k]; }
      });
    }, function (err) {
      UI.setBusy(b, false);
      failed(form, err);
    });
  }
  document.addEventListener('click', function (e) {
    var target = e.target.closest ? e.target : null;
    if (!target || !page || !page.contains(target)) { return; }
    var act = target.closest('[data-fp-act="reset"]');
    if (act) { reset(act.getAttribute('data-fp-setting'), act); }
  });

  function load() {
    var mine = ++loads;
    state = null;
    problem = '';
    showSettings('', false);
    FP.call('get', 'phpSettings', undefined, {name: account, domain: domain}).then(function (r) {
      if (mine !== loads) { return; }
      state = clean(r);
      showSettings('', false);
    }, function (err) {
      if (mine !== loads) { return; }
      problem = err.message;
      showSettings('', false);
    });
  }

  FP.view('tool:php_settings', function () {
    var tool = FP.tools.php_settings;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    account = FP.account();
    loads++;
    page = FP.frame({title: tool.label, desc: t('php_settings_desc'), cls: 'fp-mail fp-phps',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'domains', undefined, account).then(function (r) {
      var d = cleanSites(r);
      sites = d.sites;
      suspended = d.suspended;
      page.textContent = '';
      if (!sites.length) {
        page.appendChild(FP.empty(t('phps_no_sites_title'), t('phps_no_sites')));
        return;
      }
      if (suspended) { page.appendChild(M.suspendedBanner(t('phps_suspended'))); }
      domain = sites[0].domain;
      page.appendChild(siteCard());
      load();
    }, function (err) {
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

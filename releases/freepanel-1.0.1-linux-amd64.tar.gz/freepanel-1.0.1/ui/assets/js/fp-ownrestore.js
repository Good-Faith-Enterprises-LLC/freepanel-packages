/* freePanel partial restore for the account itself (the customer panel's Backups page, fp-download.js; docs/api.md, "Restoring some items as the account"):
   puts back only the files and folders, databases and mail forwarders and filters the customer picks from one of the account's own kept backups, and
   leaves the rest of the account as it is. The card lists the account's own backups (GET /accounts/{u}/backups), reads one a folder at a time (its
   contents) and keeps what is picked in its own list. It asks before it sends: what the question lists is a copy taken when the button was pressed,
   the picker is switched off while the question is open, and a Yes sends that copy, never what the boxes show by then. The server says whether a
   restore of the account is running and how the last one ended, and the card follows it every few seconds until it ends. Everything the server
   says is drawn as text. Declares only FP.ownRestore.card. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var MAX_ITEMS = 100;
  var MAX_PATH_BYTES = 1024;
  var MAX_ENTRIES = 1000;
  var PAGE = 50;
  var ENGINES = ['mysql', 'postgres'];
  var MAIL = ['forwarders', 'filters'];
  var KINDS = ['file', 'dir', 'link', 'other'];
  var ARCHIVE_RE = /^[a-z][a-z0-9]{0,15}-[A-Za-z0-9][A-Za-z0-9._-]{0,99}\.tar\.gz$/;
  var BIG = 1024 * 1024 * 1024;
  var POLL_MS = 3000;
  var UNITS = ['KB', 'MB', 'GB', 'TB', 'PB'];

  function size(n) {
    if (n < 1024) { return t('size_bytes', {n: String(Math.round(n))}); }
    var u = -1;
    do { n /= 1024; u++; } while (n >= 1024 && u < UNITS.length - 1);
    return (n < 10 ? n.toFixed(1) : Math.round(n).toLocaleString('en')) + ' ' + UNITS[u];
  }
  function when(iso) {
    var d = iso ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString(undefined, {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }
  function plain(s, max) {
    if (typeof s !== 'string' || !s || s.length > max) { return false; }
    for (var i = 0; i < s.length; i++) {
      var c = s.charCodeAt(i);
      if (c < 32 || c === 127) { return false; }
    }
    return true;
  }
  function bytesOf(s) { return window.TextEncoder ? new window.TextEncoder().encode(s).length : s.length; }
  function join(dir, name) { return dir ? dir + '/' + name : name; }
  /* a path as the API takes it: below the home folder, no leading slash, backslash or percent sign, no empty, . or .. element */
  function pathProblem(p) {
    if (!plain(p, 4 * MAX_PATH_BYTES)) { return 'bad'; }
    if (bytesOf(p) > MAX_PATH_BYTES) { return 'long'; }
    if (p.indexOf('\\') >= 0 || p.indexOf('%') >= 0) { return 'bad'; }
    var parts = p.split('/');
    for (var i = 0; i < parts.length; i++) {
      if (!parts[i] || parts[i] === '.' || parts[i] === '..') { return 'bad'; }
    }
    return '';
  }
  function entryName(n) { return plain(n, 255) && n.indexOf('/') < 0 && n !== '.' && n !== '..'; }
  function unique(list) { return list.filter(function (v, i) { return list.indexOf(v) === i; }); }

  /* what the server says of the account's backups and of a restore of the account, in the shapes this card draws */
  function cleanBackups(r) {
    r = r && typeof r === 'object' ? r : {};
    var list = (Array.isArray(r.backups) ? r.backups : []).filter(function (b) { return b && ARCHIVE_RE.test(typeof b.name === 'string' ? b.name : '') && b.removed !== true; })
      .slice(0, 200).map(function (b) {
        return {name: b.name, bytes: typeof b.bytes === 'number' && isFinite(b.bytes) && b.bytes >= 0 ? b.bytes : null, created: typeof b.created === 'string' ? b.created : ''};
      });
    var s = r.restore && typeof r.restore === 'object' ? r.restore : {};
    var l = s.last && typeof s.last === 'object' ? s.last : null;
    return {backups: list, running: s.running === true, busy: s.busy === true, last: l ? {
      ended: typeof l.ended === 'string' ? l.ended : '',
      restored: (Array.isArray(l.restored) ? l.restored : []).filter(function (p) { return typeof p === 'string' && /^[a-z0-9_-]{1,32}$/.test(p); }),
      failed: (Array.isArray(l.failed) ? l.failed : []).filter(function (p) { return typeof p === 'string' && /^[a-z0-9_-]{1,32}$/.test(p); }),
      notes: (Array.isArray(l.notes) ? l.notes : []).filter(function (n) { return typeof n === 'string' && n; }).slice(0, 20).map(function (n) { return n.slice(0, 300); }),
      error: typeof l.error === 'string' ? l.error.slice(0, 300) : ''} : null};
  }
  function cleanContents(r) {
    r = r && typeof r === 'object' ? r : {};
    var entries = (Array.isArray(r.entries) ? r.entries : []).filter(function (e) {
      return e && typeof e === 'object' && entryName(e.name) && KINDS.indexOf(e.kind) >= 0;
    }).slice(0, MAX_ENTRIES).map(function (e) {
      return {name: e.name, kind: e.kind, size: typeof e.size === 'number' && isFinite(e.size) && e.size >= 0 ? e.size : null};
    });
    var dbs = {};
    ENGINES.forEach(function (en) {
      var list = r.databases && typeof r.databases === 'object' && Array.isArray(r.databases[en]) ? r.databases[en] : [];
      list = unique(list.filter(function (n) { return plain(n, 128); })).slice(0, MAX_ITEMS);
      if (list.length) { dbs[en] = list; }
    });
    var mail = MAIL.filter(function (m) { return Array.isArray(r.mail) && r.mail.indexOf(m) >= 0; });
    return {entries: entries, databases: dbs, mail: mail, truncated: r.truncated === true};
  }

  /* the card for the account: opts {account}; returns {node, stop()} */
  function card(opts) {
    var S = {backups: [], loaded: false, failed: '', busy: false, archive: null, dir: '', shown: PAGE, listing: null, reading: false, readFailed: '', token: 0,
      files: [], dbs: {mysql: [], postgres: []}, mail: [], holds: {databases: {}, mail: []}, seen: false, asking: false, dead: false,
      running: false, last: null, said: '', timer: 0};
    var node = el('section', {class: 'sig-card fp-mail-card fp-prst', 'aria-labelledby': 'fp-prst-h'});

    function say(box, msg) { box.textContent = msg || ''; box.classList.toggle('is-shown', Boolean(msg)); }
    function sizeOf(name) { var b = S.backups.filter(function (x) { return x.name === name; })[0]; return b || null; }

    /* ---------- the backups and the restore of the account ---------- */
    function load(focus) {
      return FP.call('get', 'ownBackups', undefined, opts.account).then(function (r) {
        if (S.dead) { return; }
        var c = cleanBackups(r);
        S.backups = c.backups;
        S.loaded = true;
        S.failed = '';
        S.busy = c.busy;
        var was = S.running;
        S.running = c.running;
        S.last = c.last;
        if (was && !S.running) { S.said = ''; }
        draw();
        if (S.running) { poll(); }
        if (focus) { var h = node.querySelector('#fp-prst-h'); if (h) { h.focus(); } }
      }, function (err) {
        if (S.dead) { return; }
        S.loaded = true;
        S.failed = err.message;
        draw();
      });
    }
    /* while a restore of the account runs, asks how it is every few seconds, and shows how it ended */
    function poll() {
      window.clearTimeout(S.timer);
      S.timer = window.setTimeout(function () {
        if (S.dead || !document.body.contains(node)) { return; }
        FP.call('get', 'ownBackups', undefined, opts.account).then(function (r) {
          if (S.dead) { return; }
          var c = cleanBackups(r);
          S.backups = c.backups;
          S.busy = c.busy;
          S.last = c.last;
          if (c.running) { poll(); return; }
          S.running = false;
          draw();
          M.say(node, S.last ? endText(S.last) : t('prst_ended'));
        }, function () { if (!S.dead) { poll(); } });
      }, POLL_MS);
    }
    function endText(l) {
      if (l.error) { return t('prst_ended_error', {when: when(l.ended) || '—', error: l.error}); }
      var out = t('prst_ended_ok', {when: when(l.ended) || '—', parts: l.restored.length ? l.restored.map(function (p) { return t('prst_part_' + p); }).join(', ') : t('prst_part_none')});
      if (l.failed.length) { out += ' ' + t('prst_ended_failed', {parts: l.failed.map(function (p) { return t('prst_part_' + p); }).join(', ')}); }
      /* each note ends as a sentence, so that they read apart */
      if (l.notes.length) { out += ' ' + l.notes.map(function (n) { return /[.!?]$/.test(n) ? n : n + '.'; }).join(' '); }
      return out;
    }

    /* ---------- drawing the card ---------- */
    function draw() {
      var said = node.querySelector('[data-fp-status]');
      var saidText = said ? said.textContent : '';
      node.textContent = '';
      var body = [el('h2', {class: 'fp-h2', id: 'fp-prst-h', tabindex: '-1', text: t('prst_title')}), el('p', {class: 'fp-muted', text: t('prst_what')}), M.statusLine()];
      if (S.failed) {
        body.push(el('div', {class: 'fp-alert is-shown', role: 'alert', 'data-fp-prst-load': '', text: t('prst_load_failed', {why: S.failed})}));
        body.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', id: 'fp-prst-retry', 'data-fp-act': 'prst-reload', text: t('prst_retry')})]));
      } else if (!S.loaded) {
        body.push(el('p', {class: 'fp-muted', role: 'status', text: t('loading')}));
      } else if (S.running) {
        body.push(el('p', {class: 'fp-prst-running', role: 'status', 'data-fp-prst-running': '', text: t('prst_running')}));
      } else {
        if (S.last && !S.said) {
          body.push(el('p', {class: S.last.error || S.last.failed.length ? 'fp-prst-bad' : 'fp-muted', 'data-fp-prst-last': '', text: t('prst_last', {result: endText(S.last)})}));
        }
        if (S.busy) { body.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-prst-busy': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('prst_busy')})])); }
        if (!S.backups.length) {
          body.push(el('p', {class: 'fp-muted', 'data-fp-prst-none': '', text: t('prst_none')}));
        } else {
          body.push(chooser());
          if (S.archive) { body.push(pickerWrap()); }
        }
      }
      node.appendChild(el('div', {class: 'sig-card-body'}, body));
      M.say(node, saidText);
    }
    /* the chooser is made once for a list of backups and drawn again as it is, so that the choice made and the focus on it
       survive the card being drawn again (opening a backup, a restore ending) */
    var chooserNode = null;
    var chooserFor = null;
    function chooser() {
      if (chooserNode && chooserFor === S.backups) { return chooserNode; }
      var pick = el('select', {class: 'sig-select', id: 'fp-prst-archive', name: 'archive'}, [el('option', {value: '', text: t('prst_choose_backup')})].concat(S.backups.map(function (b) {
        return el('option', {value: b.name, selected: S.archive && S.archive.name === b.name ? true : null,
          text: t('prst_backup_of', {when: when(b.created) || b.name, size: b.bytes === null ? '—' : size(b.bytes)})});
      })));
      var form = el('form', {class: 'fp-form fp-prst-chooser', novalidate: ''}, [M.errorLine(), M.field('fp-prst-archive', t('prst_backup'), pick, t('prst_backup_hint')),
        el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary fp-submit', type: 'submit', id: 'fp-prst-open', text: t('prst_open')})])]);
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var b = M.start(form);
        if (!b) { return; }
        var chosen = sizeOf(pick.value);
        if (!chosen) { M.fieldError(form, pick, t('prst_pick_backup')); return; }
        openArchive(chosen);
      });
      chooserNode = form;
      chooserFor = S.backups;
      return form;
    }
    function openArchive(b) {
      S.archive = b;
      S.dir = '';
      S.files = [];
      S.dbs = {mysql: [], postgres: []};
      S.mail = [];
      S.seen = false;
      S.holds = {databases: {}, mail: []};
      S.listing = null;
      S.asking = false;
      draw();
      read('', true);
    }

    /* ---------- the picker for the chosen backup ---------- */
    function pickerWrap() {
      var wrap = el('div', {class: 'fp-prst-picker-wrap', 'data-fp-prst-archive': S.archive.name});
      var cost = S.archive.bytes !== null && S.archive.bytes >= BIG ? el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-prst-cost': 'big'},
        [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('prst_cost_big', {size: size(S.archive.bytes)})})]) :
        el('p', {class: 'sig-hint', 'data-fp-prst-cost': '', text: t('prst_cost')});
      var form = el('form', {class: 'fp-form fp-prst-form', novalidate: ''}, [M.errorLine()]);
      var picker = el('div', {class: 'fp-prst-picker'});
      var acts = el('div', {class: 'fp-actions', 'data-fp-prst-acts': ''});
      form.appendChild(picker);
      form.appendChild(acts);
      wrap.appendChild(el('h3', {class: 'fp-h3', id: 'fp-prst-picker-h', tabindex: '-1', text: t('prst_picker_title', {when: when(S.archive.created) || S.archive.name})}));
      wrap.appendChild(cost);
      wrap.appendChild(form);
      wrap.fill = function () { fillPicker(picker); resetActs(acts, picker); };
      wrap.fill();
      form.addEventListener('change', function (e) { onChange(e, form); });
      form.addEventListener('click', function (e) { onClick(e, form, picker); });
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var go = M.start(form);
        if (!go) { return; }
        var snap = snapshot();
        if (!snap.lines.length) { M.fieldError(form, form.querySelector('#fp-prst-path'), t('prst_pick_some')); return; }
        ask(snap, form, picker, acts);
      });
      var pathInput = form.querySelector('#fp-prst-path');
      if (pathInput) {
        pathInput.addEventListener('keydown', function (e) {
          if (e.key === 'Enter') { e.preventDefault(); addPath(form); }
          if (e.key === 'Escape' && pathInput.value) { e.stopPropagation(); pathInput.value = ''; clearPathError(form); }
        });
        pathInput.addEventListener('input', function () { clearPathError(form); });
      }
      return wrap;
    }
    function fillPicker(picker) {
      picker.textContent = '';
      var trail = el('nav', {class: 'fp-prst-trail', 'aria-label': t('prst_trail'), id: 'fp-prst-trail'});
      var listBox = el('div', {class: 'fp-prst-listbox', id: 'fp-prst-listbox'});
      var loadError = el('div', {class: 'fp-alert', role: 'alert', 'data-fp-prst-read': ''});
      var add = el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: 'fp-prst-path', text: t('prst_add_label')}),
        el('div', {class: 'fp-prst-addrow'}, [el('input', {class: 'sig-input', id: 'fp-prst-path', name: 'path', type: 'text', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none',
          maxlength: '1100', 'aria-describedby': 'fp-prst-path-hint'}), el('button', {class: 'sig-btn sig-btn--secondary', id: 'fp-prst-add', type: 'button', 'data-fp-act': 'prst-add', text: t('prst_add')})]),
        el('p', {class: 'fp-prst-pathmsg', id: 'fp-prst-path-err', role: 'alert', hidden: true}),
        el('span', {class: 'sig-hint', id: 'fp-prst-path-hint', text: t('prst_add_hint')})]);
      picker.appendChild(el('fieldset', {class: 'fp-prst-group', 'data-fp-prst-group': 'home'}, [el('legend', {class: 'sig-label', text: t('prst_files')}),
        el('p', {class: 'sig-hint', text: t('prst_files_hint')}), trail, loadError, listBox, el('div', {class: 'fp-prst-add'}, [add]), el('div', {class: 'fp-prst-chosen-box', id: 'fp-prst-chosen-box'})]));
      picker.appendChild(el('fieldset', {class: 'fp-prst-group', id: 'fp-prst-dbbox', 'data-fp-prst-group': 'databases'}));
      picker.appendChild(el('fieldset', {class: 'fp-prst-group', id: 'fp-prst-mailbox', 'data-fp-prst-group': 'mail'}));
      picker.appendChild(el('p', {class: 'fp-muted fp-prst-count', 'data-fp-prst-count': ''}));
      drawTrail();
      drawList();
      drawChosen();
      drawDatabases();
      drawMail();
      drawCount();
    }
    function q(id) { return node.querySelector('#' + id); }
    function drawCount() {
      var c = node.querySelector('[data-fp-prst-count]');
      if (c) { c.textContent = t('prst_count', {files: S.files.length, dbs: S.dbs.mysql.length + S.dbs.postgres.length, mail: S.mail.length}); }
    }
    function drawTrail() {
      var trail = q('fp-prst-trail');
      if (!trail) { return; }
      trail.textContent = '';
      var list = el('ol', {class: 'fp-prst-crumbs'});
      var parts = S.dir ? S.dir.split('/') : [];
      var steps = [{label: t('prst_home'), path: ''}];
      parts.forEach(function (p, i) { steps.push({label: p, path: parts.slice(0, i + 1).join('/')}); });
      steps.forEach(function (s, i) {
        var last = i === steps.length - 1;
        list.appendChild(el('li', null, [last ? el('span', {class: 'fp-prst-here', id: 'fp-prst-here', tabindex: '-1', 'aria-current': 'location', text: s.label}) :
          el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'prst-go', 'data-fp-path': s.path, id: 'fp-prst-go-' + i,
            'aria-label': t('prst_go_to', {folder: s.label}), text: s.label})]));
      });
      trail.appendChild(list);
    }
    function entryIcon(e) {
      return UI.icon(FP.ui, e.kind === 'dir' ? 'ui_folder' : e.kind === 'link' ? 'ui_link' : e.kind === 'file' ? 'ui_file' : 'ui_other', 'fp-fm-ico');
    }
    function drawList() {
      var box = q('fp-prst-listbox');
      if (!box) { return; }
      box.textContent = '';
      if (S.reading) { box.appendChild(el('p', {class: 'fp-muted', role: 'status', 'data-fp-prst-reading': '', text: t('prst_reading')})); return; }
      if (S.readFailed && !S.listing) {
        box.appendChild(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', id: 'fp-prst-reread', 'data-fp-act': 'prst-reread', text: t('prst_retry')})]));
        return;
      }
      var entries = S.listing ? S.listing.entries : [];
      if (!entries.length) { box.appendChild(el('p', {class: 'fp-muted', 'data-fp-prst-empty': '', text: t('prst_empty_folder')})); return; }
      var ul = el('ul', {class: 'fp-prst-list', id: 'fp-prst-list', 'aria-label': t('prst_list_label', {folder: S.dir || t('prst_home')})});
      entries.slice(0, S.shown).forEach(function (e, i) {
        var full = join(S.dir, e.name);
        var meta = e.kind === 'file' ? (e.size === null ? '' : size(e.size)) : e.kind === 'link' ? t('prst_kind_link') : e.kind === 'other' ? t('prst_kind_other') : '';
        ul.appendChild(el('li', {class: 'fp-prst-entry', 'data-fp-entry': e.name}, [
          el('label', {class: 'fp-check fp-prst-pick', for: 'fp-prst-pick-' + i}, [el('input', {type: 'checkbox', id: 'fp-prst-pick-' + i, 'data-fp-path': full,
            checked: S.files.indexOf(full) >= 0 ? true : null}), entryIcon(e), el('span', {class: 'fp-prst-name', text: e.name}), meta ? el('span', {class: 'fp-prst-meta', text: meta}) : null]),
          e.kind === 'dir' ? el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', id: 'fp-prst-dir-' + i, 'data-fp-act': 'prst-dir', 'data-fp-path': full,
            'aria-label': t('prst_open_dir_of', {name: e.name}), text: t('prst_open_dir')}) : null]));
      });
      box.appendChild(ul);
      if (entries.length > S.shown) {
        box.appendChild(el('div', {class: 'fp-prst-more'}, [el('span', {class: 'sig-hint', 'data-fp-prst-showing': '', text: t('prst_showing', {shown: S.shown, total: entries.length})}),
          el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', id: 'fp-prst-more', 'data-fp-act': 'prst-more', text: t('prst_more')})]));
      }
      if (S.listing && S.listing.truncated) { box.appendChild(el('p', {class: 'sig-hint', 'data-fp-prst-truncated': '', text: t('prst_truncated')})); }
    }
    function drawChosen() {
      var box = q('fp-prst-chosen-box');
      if (!box) { return; }
      box.textContent = '';
      box.appendChild(el('h4', {class: 'fp-prst-sub', id: 'fp-prst-chosen-h', text: t('prst_chosen_files')}));
      if (!S.files.length) { box.appendChild(el('p', {class: 'fp-muted', 'data-fp-prst-nonechosen': '', text: t('prst_none_chosen')})); return; }
      box.appendChild(el('ul', {class: 'fp-prst-chosen', 'aria-labelledby': 'fp-prst-chosen-h'}, S.files.map(function (p, i) {
        return el('li', {class: 'fp-prst-chip', 'data-fp-chosen': p}, [el('span', {class: 'sig-mono fp-prst-chip-path', text: p}),
          el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', id: 'fp-prst-rm-' + i, 'data-fp-act': 'prst-unpick', 'data-fp-path': p,
            'aria-label': t('prst_remove_of', {path: p}), text: t('prst_remove')})]);
      })));
    }
    function drawDatabases() {
      var box = q('fp-prst-dbbox');
      if (!box) { return; }
      box.textContent = '';
      box.appendChild(el('legend', {class: 'sig-label', text: t('prst_databases')}));
      var any = false;
      ENGINES.forEach(function (en) {
        var names = S.holds.databases[en] || [];
        if (!names.length) { return; }
        any = true;
        box.appendChild(el('p', {class: 'fp-prst-sub', text: t('prst_db_' + en)}));
        names.forEach(function (n, i) {
          var id = 'fp-prst-db-' + en + '-' + i;
          box.appendChild(el('label', {class: 'fp-check', for: id}, [el('input', {type: 'checkbox', id: id, name: 'db-' + en, value: n, 'data-fp-engine': en,
            checked: S.dbs[en].indexOf(n) >= 0 ? true : null}), el('span', {class: 'fp-prst-name', text: n})]));
        });
      });
      box.appendChild(any ? el('span', {class: 'sig-hint', text: t('prst_db_hint')}) : el('p', {class: 'fp-muted', 'data-fp-prst-nodb': '', text: t('prst_db_none')}));
    }
    function drawMail() {
      var box = q('fp-prst-mailbox');
      if (!box) { return; }
      box.textContent = '';
      box.appendChild(el('legend', {class: 'sig-label', text: t('prst_mail')}));
      if (!S.holds.mail.length) { box.appendChild(el('p', {class: 'fp-muted', 'data-fp-prst-nomail': '', text: t('prst_mail_none')})); return; }
      S.holds.mail.forEach(function (m) {
        var id = 'fp-prst-mail-' + m;
        box.appendChild(el('label', {class: 'fp-check', for: id}, [el('input', {type: 'checkbox', id: id, name: 'mail', value: m, checked: S.mail.indexOf(m) >= 0 ? true : null,
          'aria-describedby': id + '-hint'}), el('span', {class: 'fp-prst-name', text: t('prst_mail_' + m)})]));
        box.appendChild(el('span', {class: 'sig-hint fp-prst-hint', id: id + '-hint', text: t('prst_mail_' + m + '_hint')}));
      });
    }

    /* ---------- reading the backup ---------- */
    function read(dir, focus) {
      var token = ++S.token;
      var archive = S.archive;
      S.reading = true;
      S.readFailed = '';
      var err0 = node.querySelector('[data-fp-prst-read]');
      if (err0) { say(err0, ''); }
      drawList();
      var call = dir ? FP.call('get', 'backupContentsAt', undefined, {name: opts.account, archive: archive.name, path: dir}) :
        FP.call('get', 'backupContents', undefined, {name: opts.account, archive: archive.name});
      call.then(function (r) {
        if (S.dead || token !== S.token) { return; }
        var c = cleanContents(r);
        S.dir = dir;
        S.shown = PAGE;
        S.listing = c;
        S.reading = false;
        if (!S.seen) {
          S.seen = true;
          S.holds = {databases: c.databases, mail: c.mail};
          drawDatabases();
          drawMail();
        }
        drawTrail();
        drawList();
        if (focus) { var here = q('fp-prst-here'); if (here) { here.focus(); } }
      }, function (err) {
        if (S.dead || token !== S.token) { return; }
        S.reading = false;
        S.readFailed = err.message;
        var box = node.querySelector('[data-fp-prst-read]');
        if (box) { say(box, t('prst_read_failed', {why: err.message})); }
        drawList();
      });
    }

    /* ---------- the choice, as it is now ---------- */
    function snapshot() {
      var select = {};
      var lines = [];
      if (S.files.length) {
        select.home = S.files.slice();
        S.files.forEach(function (p) { lines.push({kind: t('prst_ask_files'), what: p, mono: true}); });
      }
      ENGINES.forEach(function (en) {
        if (!S.dbs[en].length) { return; }
        select[en] = S.dbs[en].slice();
        S.dbs[en].forEach(function (n) { lines.push({kind: t('prst_ask_' + en), what: n, mono: true}); });
      });
      if (S.mail.length) {
        select.mail = S.mail.slice();
        S.mail.forEach(function (m) { lines.push({kind: t('prst_ask_mail'), what: t('prst_mail_' + m), mono: false}); });
      }
      return {select: select, lines: lines, archive: S.archive.name, when: when(S.archive.created) || S.archive.name};
    }

    /* ---------- the question and the send ---------- */
    function resetActs(acts, picker) {
      acts.textContent = '';
      S.asking = false;
      picker.removeAttribute('inert');
      acts.appendChild(el('button', {class: 'sig-btn sig-btn--primary fp-submit', id: 'fp-prst-submit', type: 'submit', text: t('prst_restore')}));
      acts.appendChild(el('button', {class: 'sig-btn sig-btn--secondary', id: 'fp-prst-close', type: 'button', 'data-fp-act': 'prst-close', text: t('cancel')}));
    }
    function ask(snap, form, picker, acts) {
      acts.textContent = '';
      S.asking = true;
      picker.setAttribute('inert', '');
      var list = el('ul', {class: 'fp-prst-asklist'}, snap.lines.map(function (l) {
        return el('li', null, [el('span', {class: 'fp-prst-askkind', text: l.kind + ': '}), el('span', {class: l.mono ? 'sig-mono' : '', text: l.what})]);
      }));
      var yes = el('button', {class: 'sig-btn sig-btn--danger', id: 'fp-prst-yes', type: 'button', 'aria-describedby': 'fp-prst-ask', text: t('prst_restore_yes')});
      var no = el('button', {class: 'sig-btn sig-btn--secondary', id: 'fp-prst-no', type: 'button', 'aria-describedby': 'fp-prst-ask', text: t('cancel')});
      acts.appendChild(el('div', {class: 'fp-prst-ask', id: 'fp-prst-ask'}, [el('p', {class: 'fp-mail-confirm fp-prst-asklead', 'data-fp-prst-ask': '', text: t('prst_ask', {when: snap.when})}), list]));
      acts.appendChild(yes);
      acts.appendChild(no);
      no.addEventListener('click', function () {
        resetActs(acts, picker);
        form.querySelector('#fp-prst-submit').focus();
      });
      yes.addEventListener('click', function () { send(yes, snap, form, picker, acts); });
      no.focus();
    }
    function send(yes, snap, form, picker, acts) {
      UI.setBusy(yes, true);
      FP.call('post', 'backupRestore', {select: snap.select}, {name: opts.account, archive: snap.archive}).then(function () {
        if (S.dead) { return; }
        S.running = true;
        S.archive = null;
        chooserNode = null;
        S.said = t('prst_started', {when: snap.when});
        draw();
        M.say(node, S.said);
        node.querySelector('#fp-prst-h').focus();
        poll();
      }, function (err) {
        if (S.dead) { return; }
        resetActs(acts, picker);
        M.failed(form, err.status === 400 || err.status === 422 ? {message: t('prst_refused', {why: err.message})} : err);
        if (!form.contains(document.activeElement)) { form.querySelector('#fp-prst-submit').focus(); }
      });
    }

    /* ---------- the path field and the boxes ---------- */
    function clearPathError(form) {
      var msg = form.querySelector('#fp-prst-path-err');
      var input = form.querySelector('#fp-prst-path');
      if (msg) { msg.hidden = true; msg.textContent = ''; }
      if (input) { input.removeAttribute('aria-invalid'); input.setAttribute('aria-describedby', 'fp-prst-path-hint'); }
    }
    function addPath(form) {
      var input = form.querySelector('#fp-prst-path');
      var msg = form.querySelector('#fp-prst-path-err');
      var p = input.value.trim();
      if (p.length > 1 && p.charAt(p.length - 1) === '/') { p = p.slice(0, -1); }
      var why = p ? pathProblem(p) : 'bad';
      if (!why && S.files.indexOf(p) >= 0) { why = 'dupe'; }
      if (!why && S.files.length >= MAX_ITEMS) { why = 'many'; }
      if (why) {
        msg.textContent = why === 'dupe' ? t('prst_path_dupe', {path: p}) : why === 'many' ? t('prst_too_many') : why === 'long' ? t('prst_path_long') : t('prst_path_bad');
        msg.hidden = false;
        input.setAttribute('aria-invalid', 'true');
        input.setAttribute('aria-describedby', 'fp-prst-path-hint fp-prst-path-err');
        input.focus();
        return;
      }
      clearPathError(form);
      input.value = '';
      S.files.push(p);
      drawChosen();
      drawCount();
      var boxes = form.querySelectorAll('input[type="checkbox"][data-fp-path]');
      for (var i = 0; i < boxes.length; i++) { if (boxes[i].getAttribute('data-fp-path') === p) { boxes[i].checked = true; } }
      input.focus();
    }
    function onChange(e, form) {
      var box = e.target;
      if (!box || box.type !== 'checkbox' || S.asking) { return; }
      if (box.hasAttribute('data-fp-path')) {
        var p = box.getAttribute('data-fp-path');
        var at = S.files.indexOf(p);
        if (box.checked && at < 0) {
          if (S.files.length >= MAX_ITEMS) {
            box.checked = false;
            var err = form.querySelector('[data-fp-prst-read]');
            if (err) { say(err, t('prst_too_many')); }
            return;
          }
          S.files.push(p);
        }
        if (!box.checked && at >= 0) { S.files.splice(at, 1); }
        var rd = form.querySelector('[data-fp-prst-read]');
        if (rd) { say(rd, ''); }
        drawChosen();
      } else if (box.getAttribute('data-fp-engine')) {
        var list = S.dbs[box.getAttribute('data-fp-engine')];
        var i = list.indexOf(box.value);
        if (box.checked && i < 0) { list.push(box.value); }
        if (!box.checked && i >= 0) { list.splice(i, 1); }
      } else if (box.name === 'mail') {
        var m = S.mail.indexOf(box.value);
        if (box.checked && m < 0) { S.mail.push(box.value); }
        if (!box.checked && m >= 0) { S.mail.splice(m, 1); }
        S.mail = MAIL.filter(function (x) { return S.mail.indexOf(x) >= 0; });
      }
      drawCount();
    }
    function onClick(e, form) {
      var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
      if (!b || !form.contains(b) || S.asking) { return; }
      var act = b.getAttribute('data-fp-act');
      var p = b.getAttribute('data-fp-path') || '';
      if (act === 'prst-dir' || act === 'prst-go') {
        read(p, true);
      } else if (act === 'prst-reread') {
        read(S.dir, true);
      } else if (act === 'prst-more') {
        var was = S.shown;
        S.shown += PAGE;
        drawList();
        var next = q('fp-prst-pick-' + was);
        (next || q('fp-prst-list')).focus();
      } else if (act === 'prst-add') {
        addPath(form);
      } else if (act === 'prst-unpick') {
        var rows = form.querySelectorAll('[data-fp-act="prst-unpick"]');
        var idx = Array.prototype.indexOf.call(rows, b);
        var at = S.files.indexOf(p);
        if (at >= 0) { S.files.splice(at, 1); }
        drawChosen();
        drawCount();
        var boxes = form.querySelectorAll('input[type="checkbox"][data-fp-path]');
        for (var i = 0; i < boxes.length; i++) { if (boxes[i].getAttribute('data-fp-path') === p) { boxes[i].checked = false; } }
        var left = form.querySelectorAll('[data-fp-act="prst-unpick"]');
        (left[Math.min(idx, left.length - 1)] || form.querySelector('#fp-prst-path')).focus();
      } else if (act === 'prst-close') {
        S.archive = null;
        chooserNode = null;
        draw();
        var open = q('fp-prst-open');
        (open || q('fp-prst-h')).focus();
      }
    }
    node.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('[data-fp-act="prst-reload"]') : null;
      if (b) { S.loaded = false; S.failed = ''; draw(); load(true); }
    });

    draw();
    load(false);
    return {node: node, stop: function () { S.dead = true; window.clearTimeout(S.timer); }};
  }

  FP.ownRestore = {card: card};
})();

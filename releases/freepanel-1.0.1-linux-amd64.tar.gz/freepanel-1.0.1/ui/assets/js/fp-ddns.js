/* freePanel dynamic DNS (docs/api.md, "Dynamic DNS"): the customer panel's page (#/tool/dynamic_dns) for names in the account's own zones that a
   device (a router, a script) keeps pointed at its changing address. A name gets a token, shown once, that the device presents to this panel;
   the page never shows it again and never keeps it: a new token replaces it at once. Removing a name ends its token and leaves its records.
   The page shows how a device uses it (the endpoint and the plain-text form that routers and ddclient speak) with the token filled in only
   while it is on screen. Everything the server sends is shown as text. The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var NAME_RE = /^(?=.{1,253}$)([a-z0-9_]([a-z0-9_-]{0,61}[a-z0-9_])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var ZONE_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var IP4_RE = /^((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$/;
  var IP6_RE = /^[0-9A-Fa-f:]{2,39}$/;
  var TOKEN_RE = /^[A-Za-z0-9_.-]{8,200}$/;
  var MAX_NAMES = 20;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  function when(v) {
    if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}T/.test(v)) { return ''; }
    var d = new Date(v);
    return isNaN(d.getTime()) ? '' : d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'});
  }
  function address(v, family) {
    v = str(v, 45);
    if (!v) { return ''; }
    return family === 4 ? (IP4_RE.test(v) ? v : '') : (v.indexOf(':') > 0 && IP6_RE.test(v) ? v : '');
  }
  function entry(n) {
    if (!n || typeof n !== 'object' || !NAME_RE.test(str(n.name, 253))) { return null; }
    return {name: n.name, zone: ZONE_RE.test(str(n.zone, 253)) ? n.zone : '', created: when(n.created), updated: when(n.updated), seen: when(n.seen),
      ipv4: address(n.ipv4, 4), ipv6: address(n.ipv6, 6), ttl: typeof n.ttl === 'number' && n.ttl > 0 && isFinite(n.ttl) ? Math.floor(n.ttl) : 0};
  }
  function clean(v) {
    v = v && typeof v === 'object' ? v : {};
    var seen = {};
    return {names: (Array.isArray(v.names) ? v.names : []).map(entry).filter(function (n) {
      if (!n || seen[n.name]) { return false; }
      seen[n.name] = true;
      return true;
    }).slice(0, MAX_NAMES + 5), endpoint: str(v.endpoint, 400), path: str(v.dyndns_path, 100)};
  }
  /* the token of an answer, only if it looks like one */
  function tokenOf(r) { return r && typeof r.token === 'string' && TOKEN_RE.test(r.token) ? r.token : ''; }
  /* the API names where a device calls as a path on the customer panel's own address ("/api/v1/ddns/update", docs/api.md), and this page is
     served from that address: the address a device uses is the path on this page's origin */
  function urlOf(endpoint) {
    try { return new window.URL(endpoint, window.location.origin); } catch (e) { return null; }
  }

  var D = {page: null, S: null, zones: null, account: '', busy: false, fresh: null};

  function nameRow(n) {
    var addrs = [n.ipv4, n.ipv6].filter(Boolean);
    var bits = [addrs.length ? addrs.join(', ') : t('ddn_no_address')];
    return el('li', {class: 'fp-ddn-item', 'data-fp-name': n.name}, [
      el('div', {class: 'fp-ddn-who'}, [el('span', {class: 'sig-mono fp-ddn-name', text: n.name}),
        el('span', {class: 'fp-ddn-addr', 'data-fp-addr': '', text: bits.join(' · ')}),
        el('span', {class: 'fp-muted fp-ddn-when', text: [n.updated ? t('ddn_updated', {when: n.updated}) : t('ddn_not_updated'), n.seen ? t('ddn_seen', {when: n.seen}) : ''].filter(Boolean).join(' · ')})]),
      el('div', {class: 'fp-ddn-acts'}, [
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'ddn-token', 'aria-label': t('ddn_token_of', {name: n.name}), text: t('ddn_token')}),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'ddn-remove', 'aria-label': t('ddn_remove_of', {name: n.name}),
          text: t('ddn_remove')})])]);
  }
  function listCard() {
    var S = D.S;
    var parts = [M.errorLine(), M.statusLine()];
    if (!S.names.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('ddn_none')}));
    } else {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-count': '', text: t(S.names.length === 1 ? 'ddn_count_1' : 'ddn_count', {n: S.names.length, max: MAX_NAMES})}));
      parts.push(el('ul', {class: 'fp-ddn-list', 'aria-labelledby': 'fp-ddn-list-h'}, S.names.map(nameRow)));
    }
    return M.card('fp-ddn-list-h', t('ddn_title'), parts, 'fp-ddn-list-card');
  }
  function addCard() {
    var S = D.S;
    if (S.names.length >= MAX_NAMES) {
      return M.card('fp-ddn-add-h', t('ddn_add_title'), [el('p', {class: 'fp-muted', 'data-fp-ddn-full': '', text: t('ddn_full', {max: MAX_NAMES})})], 'fp-ddn-add');
    }
    var input = el('input', {class: 'sig-input sig-mono', id: 'fp-ddn-new', name: 'name', type: 'text', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', maxlength: '253',
      'aria-describedby': 'fp-ddn-new-hint'});
    var hint = D.zones && D.zones.length ? t('ddn_name_hint_zones', {zones: D.zones.slice(0, 5).join(', ') + (D.zones.length > 5 ? ', …' : '')}) : t('ddn_name_hint');
    var form = el('form', {class: 'fp-form fp-ddn-form', novalidate: ''}, [M.errorLine(), M.statusLine(), M.field('fp-ddn-new', t('ddn_name'), input, hint),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('ddn_add')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || D.busy) { return; }
      var v = input.value.trim().toLowerCase().replace(/\.$/, '');
      if (!NAME_RE.test(v)) { M.fieldError(form, input, t('ddn_name_bad')); return; }
      if (D.zones && D.zones.length && !D.zones.some(function (z) { return v.length > z.length + 1 && v.slice(-z.length - 1) === '.' + z; })) {
        M.fieldError(form, input, t('ddn_name_zone', {zones: D.zones.slice(0, 5).join(', ')})); return;
      }
      D.busy = true;
      UI.setBusy(b, true);
      var mine = D.page;
      FP.call('post', 'ddnsNames', {name: v}, D.account).then(function (r) {
        D.busy = false;
        if (D.page !== mine) { return; }
        var made = entry(r);
        D.fresh = {name: made ? made.name : v, token: tokenOf(r), endpoint: str(r && r.endpoint, 400) || D.S.endpoint, path: str(r && r.dyndns_path, 100) || D.S.path, renewed: false};
        reload(function () { focusFresh(); });
      }, function (err) {
        D.busy = false;
        if (D.page !== mine) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return M.card('fp-ddn-add-h', t('ddn_add_title'), [form], 'fp-ddn-add');
  }

  /* ---- the token, shown once, with how a device uses it ---- */
  function snippet(label, text, id) {
    return el('div', {class: 'fp-ddn-snip'}, [el('p', {class: 'fp-ddn-snip-h', id: id + '-h', text: label}), el('pre', {class: 'sig-mono fp-ddn-code', id: id, tabindex: '0', 'aria-labelledby': id + '-h', text: text})]);
  }
  function freshCard() {
    var f = D.fresh;
    var u = f.endpoint ? urlOf(f.endpoint) : null;
    var host = u ? u.host : '';
    var path = f.path || '/nic/update';
    var tok = f.token || '<token>';
    var snips = [];
    if (u) { snips.push(snippet(t('ddn_curl'), 'curl -H "Authorization: Bearer ' + tok + '" "' + u.href + '"', 'fp-ddn-curl')); }
    if (host) { snips.push(snippet(t('ddn_ddclient'), ['protocol=dyndns2', 'server=' + host, 'ssl=yes', 'login=ddns', "password='" + tok + "'", f.name].join('\n'), 'fp-ddn-ddclient')); }
    var parts = [el('p', {class: 'fp-muted', text: t(f.renewed ? 'ddn_fresh_what_renewed' : 'ddn_fresh_what', {name: f.name})})];
    if (f.token) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note'}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('ddn_once')})]));
      parts.push(el('div', {class: 'fp-ddn-token-row'}, [el('code', {class: 'sig-mono fp-ddn-token', id: 'fp-ddn-token', tabindex: '0', 'data-fp-token': '', 'aria-label': t('ddn_token_label'), text: f.token}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'ddn-copy', text: t('ddn_copy')})]));
    } else {
      parts.push(el('p', {class: 'fp-alert is-shown', role: 'alert', text: t('ddn_no_token')}));
    }
    parts.push(el('p', {class: 'fp-muted', text: t('ddn_device_what', {path: path})}));
    parts = parts.concat(snips);
    parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'ddn-done', text: t('ddn_done')})]));
    return M.card('fp-ddn-fresh-h', t('ddn_fresh_title', {name: f.name}), [M.statusLine()].concat(parts), 'fp-ddn-fresh');
  }
  function focusFresh() {
    var h = D.page && D.page.querySelector('#fp-ddn-fresh-h');
    if (h) { h.focus(); }
  }

  function render() {
    D.page.textContent = '';
    if (D.fresh) { D.page.appendChild(freshCard()); }
    D.page.appendChild(listCard());
    D.page.appendChild(addCard());
    D.page.appendChild(M.card('fp-ddn-how-h', t('ddn_how_title'), [el('p', {class: 'fp-muted', text: t('ddn_how_1')}), el('p', {class: 'fp-muted', text: t('ddn_how_2')}),
      el('p', {class: 'fp-muted', text: t('ddn_how_3')})], 'fp-ddn-how'));
  }
  function reload(done) {
    var mine = D.page;
    FP.call('get', 'ddnsNames', undefined, D.account).then(function (r) {
      if (D.page !== mine) { return; }
      D.S = clean(r);
      render();
      if (done) { done(); }
    }, function (err) {
      if (D.page !== mine) { return; }
      render();
      UI.showError(D.page.querySelector('.fp-ddn-list-card'), err.message);
    });
  }

  function copy(b) {
    var f = D.fresh;
    var scope = D.page.querySelector('.fp-ddn-fresh');
    var tokenEl = D.page.querySelector('#fp-ddn-token');
    function selected() {
      var range = document.createRange();
      range.selectNodeContents(tokenEl);
      var sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
      M.say(scope, t('ddn_selected'));
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(f.token).then(function () { M.say(scope, t('ddn_copied')); }, selected);
    } else {
      selected();
    }
    b.focus();
  }

  document.addEventListener('click', function (e) {
    var node = e.target.closest ? e.target : null;
    var b = node && node.closest('[data-fp-act]');
    if (!b || !D.page || !D.page.contains(b) || !D.S) { return; }
    var a = b.getAttribute('data-fp-act');
    var li = b.closest('li[data-fp-name]');
    var name = li ? li.getAttribute('data-fp-name') : '';
    var mine = D.page;
    if (a === 'ddn-copy' && D.fresh && D.fresh.token) {
      copy(b);
    } else if (a === 'ddn-done') {
      D.fresh = null;
      render();
      D.page.querySelector('#fp-ddn-list-h').focus();
    } else if (a === 'ddn-token' && name) {
      M.confirmIn(li.querySelector('.fp-ddn-acts'), t('ddn_token_ask', {name: name}), 'ddn-token-yes', t('ddn_token_yes'));
    } else if (a === 'ddn-remove' && name) {
      M.confirmIn(li.querySelector('.fp-ddn-acts'), t('ddn_remove_ask', {name: name}), 'ddn-remove-yes', t('ddn_remove'));
    } else if (a === 'confirm-no' && name) {
      var opener = li.querySelector('[data-fp-act="ddn-token-yes"]') ? 'ddn-token' : 'ddn-remove';
      render();
      var again = D.page.querySelector('li[data-fp-name="' + window.CSS.escape(name) + '"] [data-fp-act="' + opener + '"]');
      if (again) { again.focus(); }
    } else if (a === 'ddn-token-yes' && name && !D.busy) {
      D.busy = true;
      UI.setBusy(b, true);
      FP.call('post', 'ddnsToken', {}, {name: D.account, host: name}).then(function (r) {
        D.busy = false;
        if (D.page !== mine) { return; }
        D.fresh = {name: name, token: tokenOf(r), endpoint: str(r && r.endpoint, 400) || D.S.endpoint, path: str(r && r.dyndns_path, 100) || D.S.path, renewed: true};
        reload(function () { focusFresh(); });
      }, function (err) {
        D.busy = false;
        if (D.page !== mine) { return; }
        render();
        UI.showError(D.page.querySelector('.fp-ddn-list-card'), err.message);
        D.page.querySelector('#fp-ddn-list-h').focus();
      });
    } else if (a === 'ddn-remove-yes' && name && !D.busy) {
      D.busy = true;
      UI.setBusy(b, true);
      FP.call('del', 'ddnsName', undefined, {name: D.account, host: name}).then(function () {
        D.busy = false;
        if (D.page !== mine) { return; }
        if (D.fresh && D.fresh.name === name) { D.fresh = null; }
        reload(function () {
          M.say(D.page.querySelector('.fp-ddn-list-card'), t('ddn_removed', {name: name}));
          D.page.querySelector('#fp-ddn-list-h').focus();
        });
      }, function (err) {
        D.busy = false;
        if (D.page !== mine) { return; }
        if (err && err.status === 404) {
          reload(function () { UI.showError(D.page.querySelector('.fp-ddn-list-card'), err.message); D.page.querySelector('#fp-ddn-list-h').focus(); });
          return;
        }
        render();
        UI.showError(D.page.querySelector('.fp-ddn-list-card'), err.message);
        D.page.querySelector('#fp-ddn-list-h').focus();
      });
    }
  });

  FP.view('tool:dynamic_dns', function () {
    var tool = FP.tools.dynamic_dns;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    D.S = null;
    D.zones = null;
    D.busy = false;
    D.fresh = null;
    D.account = FP.account();
    var body = FP.frame({title: tool.label, desc: t('ddn_desc'), cls: 'fp-mail fp-ddn-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    D.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all([FP.call('get', 'ddnsNames', undefined, D.account),
      FP.call('get', 'accountZones', undefined, D.account).then(function (r) {
        return (r && Array.isArray(r.zones) ? r.zones : []).map(function (z) { return z && z.zone; }).filter(function (z) { return typeof z === 'string' && ZONE_RE.test(z); });
      }, function () { return null; })]).then(function (r) {
      if (D.page !== body) { return; }
      D.S = clean(r[0]);
      D.zones = r[1];
      render();
    }, function (err) {
      if (D.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

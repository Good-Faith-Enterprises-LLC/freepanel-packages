/* freePanel billing credit notes (#/tool/billing_credit_notes; docs/api.md, "Billing: invoices"; docs/billing/navigation-map.md, "Credit
   notes"): every credit note made on a paid invoice, newest first, with its number, invoice, client, amount and how the money went back (to
   the client's credit, or paid back by hand). They are made on the invoice's own page and never change, so this list only reads. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;

  var NOTE = {id: 'id', number: [40], invoice_id: 'id', customer_id: 'id', amount_cents: 'c', currency: [3], method: ['=', ['credit', 'refund']], reason: [200], by: [64], created: 'w'};
  function clean(x) { var n = B.pick(x, NOTE); return n && n.id ? n : null; }
  var X = null;
  FP.view('tool:billing_credit_notes', function () {
    var page = B.frame('billing_credit_notes', 'fp-bcr');
    if (!page) { return; }
    X = {page: page, names: {}};
    var mine = X;
    var alive = function () { return X === mine && page.isConnected; };
    var L = B.lister({page: page, pre: 'fp-bcr', title: t('bcr_list_title'), findLabel: t('bcr_find'), tableCls: 'fp-bcr-table', alive: alive,
      before: function () { return [el('p', {class: 'fp-muted fp-row-note', text: t('bcr_what')})]; },
      blank: {customer: ''},
      filters: [{name: 'customer', control: function (v) { return B.clientPicker('fp-bcr-f-client', {name: 'customer', label: t('bcr_f_client'), placeholder: t('bil_any'), value: v, valueName: v ? X.names[v] : ''}); }}],
      load: function (f, offset, limit) {
        return B.listOf('billingCreditNotes', {limit: String(limit), offset: String(offset), customer: f.customer}, 'credit_notes', clean).then(function (r) {
          return B.namesFor(X.names, r.items.map(function (x) { return x.customer_id; })).then(function () { return r; });
        });
      },
      heads: [B.th(t('bcr_col_number')), B.th(t('bcr_col_date')), B.th(t('bcr_col_invoice')), B.th(t('bcr_col_client')), B.th(t('bcr_col_amount'), 'fp-bil-num'), B.th(t('bcr_col_method')),
        B.th(t('bcr_col_reason')), B.th(t('bcr_col_by'))],
      row: function (n) {
        var inv = n.invoice_id ? t('binv_invoice_ref', {id: String(n.invoice_id)}) : '—';
        return el('tr', {'data-fp-cn': String(n.id)}, [el('th', {scope: 'row', class: 'fp-bil-nowrap', text: n.number || '—'}), el('td', {class: 'fp-bil-nowrap', text: B.when(n.created) || '—'}),
          el('td', null, [n.invoice_id && FP.tools.billing_invoices ? B.button('open-invoice', inv, 'sig-btn--link fp-bil-link', {'data-fp-id': String(n.invoice_id), 'aria-label': t('bcl_open_invoice_id', {id: String(n.invoice_id)})}) : inv]),
          el('td', {class: 'fp-bil-wrap'}, [B.clientLink(X.names, n.customer_id)]), el('td', {class: 'fp-bil-num', text: B.money(n.amount_cents, n.currency)}),
          el('td', {text: t(n.method === 'refund' ? 'binv_cn_refund' : 'binv_cn_credit')}), el('td', {class: 'fp-bil-wrap', text: n.reason || '—'}), el('td', {text: n.by || '—'})]);
      },
      none: t('bcr_none'), noneMatch: t('bcr_none_match'),
      found: function (n) { return n === 1 ? t('bcr_found_1') : t('bcr_found', {n: B.num(n)}); }});
    page.addEventListener('click', function (e) {
      var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
      if (!b || b.disabled || !alive()) { return; }
      var a = b.getAttribute('data-fp-act');
      var xid = Number(b.getAttribute('data-fp-id')) || 0;
      if (a === 'open-invoice' && xid) { B.go('billing_invoices', {invoice: xid}); } else if (a === 'open-client' && xid) { B.go('billing_clients', {client: xid}); }
    });
    L.show();
  });
})();

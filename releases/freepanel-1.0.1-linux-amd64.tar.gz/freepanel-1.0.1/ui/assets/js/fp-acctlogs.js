/* freePanel customer pages for FTP traffic and importing forwarders (docs/api.md): FTP traffic (#/tool/ftp_traffic: what the account's FTP logins
   sent and received each day, and the raw FTP log to download) and Import forwarders (#/tool/forwarder_import: forwarders from a file, checked
   first and then added in one go). What the server sends is drawn as text. The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function num(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.floor(v) : 0; }
  function count(n) { return Math.round(n).toLocaleString('en'); }
  var UNITS = ['KB', 'MB', 'GB', 'TB', 'PB'];
  function size(n) {
    if (n < 1024) { return t('size_bytes', {n: count(n)}); }
    var u = -1;
    do { n /= 1024; u++; } while (n >= 1024 && u < UNITS.length - 1);
    return (n < 10 ? n.toFixed(1) : count(n)) + ' ' + UNITS[u];
  }
  function sentence(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) + (/[.!?]$/.test(s) ? '' : '.') : ''; }
  function unavailable(body, id, err) {
    body.textContent = '';
    body.appendChild(FP.empty(FP.tools[id].label, err ? err.message : t('api_failed')));
  }
  function pill(kind, text) { return el('span', {class: 'sig-pill sig-pill--' + kind, text: text}); }

  /* ================= FTP traffic ================= */
  var DAYS = [1, 7, 30, 90];
  var LOG_DAYS = [1, 7, 30];
  var T = {page: null, account: '', days: 30, data: null};
  function cleanTraffic(r) {
    if (!r || typeof r !== 'object' || !Array.isArray(r.rows)) { return null; }
    return {days: num(r.days), down: num(r.download_bytes), up: num(r.upload_bytes), rows: r.rows.filter(function (x) {
      return x && typeof x === 'object' && /^\d{4}-\d{2}-\d{2}$/.test(str(x.day, 10));
    }).slice(0, 5000).map(function (x) {
      return {day: x.day, login: str(x.login, 260), downloads: num(x.downloads), down: num(x.download_bytes), uploads: num(x.uploads), up: num(x.upload_bytes)};
    })};
  }
  function dayText(iso) {
    var d = new Date(iso + 'T00:00:00Z');
    return isNaN(d.getTime()) ? iso : d.toLocaleDateString(undefined, {year: 'numeric', month: 'short', day: 'numeric', timeZone: 'UTC'});
  }
  function trafficCard() {
    var d = T.data;
    var pick = el('select', {class: 'sig-select', id: 'fp-ftt-days', name: 'days'}, DAYS.map(function (n) {
      return el('option', {value: String(n), text: t(n === 1 ? 'ftt_day_one' : 'ftt_days_n', {n: n})});
    }));
    pick.value = String(T.days);
    var parts = [el('p', {class: 'fp-muted', text: t('ftt_what')}), M.errorLine(), M.statusLine(), M.field('fp-ftt-days', t('ftt_period'), pick),
      el('p', {class: 'fp-ftt-total', 'data-fp-total': '', text: t('ftt_total') + ' ' + t('ftt_total_line', {down: size(d.down), up: size(d.up)})})];
    if (!d.rows.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('ftt_none')}));
    } else {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-ftt-h'}, [el('table', {class: 'sig-table fp-mail-table fp-ftt-table'}, [
        el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('ftt_day')}), el('th', {scope: 'col', text: t('ftt_login')}),
          el('th', {scope: 'col', class: 'fp-num', text: t('ftt_downloaded')}), el('th', {scope: 'col', class: 'fp-num', text: t('ftt_uploaded')})])]),
        el('tbody', null, d.rows.map(function (x) {
          return el('tr', {'data-fp-day': x.day}, [el('th', {scope: 'row', text: dayText(x.day)}), el('td', {class: 'sig-mono', text: x.login || '—'}),
            el('td', {class: 'fp-num', text: t('ftt_cell', {size: size(x.down), n: count(x.downloads)})}),
            el('td', {class: 'fp-num', text: t('ftt_cell', {size: size(x.up), n: count(x.uploads)})})]);
        }))])]));
    }
    pick.addEventListener('change', function () {
      var mine = T.page;
      var want = Number(pick.value);
      pick.disabled = true;
      M.say(T.page.querySelector('.fp-ftt-card'), t('loading'));
      FP.call('get', 'ftpTraffic', undefined, {name: T.account, days: String(want)}).then(function (r) {
        if (T.page !== mine) { return; }
        var v = cleanTraffic(r);
        if (!v) { pick.disabled = false; M.say(T.page.querySelector('.fp-ftt-card'), ''); UI.showError(T.page.querySelector('.fp-ftt-card'), t('api_failed')); return; }
        T.days = want;
        T.data = v;
        tDraw();
        T.page.querySelector('#fp-ftt-days').focus();
        M.say(T.page.querySelector('.fp-ftt-card'), t('ftt_shown', {n: count(v.rows.length)}));
      }, function (err) {
        if (T.page !== mine) { return; }
        pick.disabled = false;
        pick.value = String(T.days);
        var card = T.page.querySelector('.fp-ftt-card');
        M.say(card, '');
        UI.showError(card, err.message);
      });
    });
    return M.card('fp-ftt-h', t('ftt_title'), parts, 'fp-ftt-card');
  }
  function logCard() {
    var pick = el('select', {class: 'sig-select', id: 'fp-ftl-days', name: 'days'}, LOG_DAYS.map(function (n) {
      return el('option', {value: String(n), text: t(n === 1 ? 'ftt_day_one' : 'ftt_days_n', {n: n})});
    }));
    pick.value = '7';
    var b = el('button', {class: 'sig-btn sig-btn--secondary fp-submit', type: 'submit'}, [UI.icon(FP.ui, 'ui_download'), el('span', {text: t('ftl_download')})]);
    var form = el('form', {class: 'fp-form fp-mail-form fp-ftl-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-ftl-days', t('ftl_period'), pick, t('ftl_hint')), el('div', {class: 'fp-actions'}, [b])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!M.start(form)) { return; }
      download(form, b, Number(pick.value));
    });
    return M.card('fp-ftl-h', t('ftl_title'), [el('p', {class: 'fp-muted', text: t('ftl_what')}), form], 'fp-ftl-card');
  }
  /* the log is fetched and saved by the page: a refusal arrives as JSON, which a plain link would have saved as the file */
  function download(form, b, days) {
    var mine = T.page;
    var file = T.account + '-ftp.log';
    UI.setBusy(b, true);
    M.say(form, t('ftl_making'));
    var url = '/api/v1/accounts/' + encodeURIComponent(T.account) + '/ftp/log?days=' + days;
    window.fetch(url, {credentials: 'same-origin', cache: 'no-store'}).then(function (r) {
      if (r.ok) {
        var cut = r.headers.get('X-Log-Truncated') === 'true';
        return r.blob().then(function (blob) {
          if (T.page !== mine) { return; }
          UI.setBusy(b, false);
          /* not made with el(): its address check passes only addresses on the panel's own site, and this one is a blob of the page's own */
          var href = window.URL.createObjectURL(new window.Blob([blob], {type: 'text/plain'}));
          var a = document.createElement('a');
          a.href = href;
          a.download = file;
          document.body.appendChild(a);
          a.click();
          a.remove();
          window.setTimeout(function () { window.URL.revokeObjectURL(href); }, 10000);
          M.say(form, t(blob.size ? (cut ? 'ftl_done_cut' : 'ftl_done') : 'ftl_empty', {file: file}));
          b.focus();
        });
      }
      if (r.status === 401) { FP.signedOut(true); return undefined; }
      return r.text().then(function (text) {
        var j;
        try { j = JSON.parse(text); } catch (e2) { j = null; }
        var err = j && j.error && typeof j.error === 'object' ? j.error : {};
        if (T.page !== mine) { return; }
        UI.setBusy(b, false);
        M.say(form, '');
        M.failed(form, {message: typeof err.message === 'string' && err.message.trim() ? err.message.trim().slice(0, 300) : t('api_failed')});
      });
    }, function () {
      if (T.page !== mine) { return; }
      UI.setBusy(b, false);
      M.say(form, '');
      M.failed(form, {message: t('api_failed')});
    });
  }
  function tDraw() {
    T.page.textContent = '';
    T.page.appendChild(trafficCard());
    T.page.appendChild(logCard());
  }
  FP.view('tool:ftp_traffic', function () {
    var body = M.frame('ftp_traffic', 'fp-ftt');
    if (!body) { return; }
    T = {page: body, account: FP.account(), days: 30, data: null};
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'ftpTraffic', undefined, {name: T.account, days: '30'}).then(function (r) {
      if (T.page !== body) { return; }
      T.data = cleanTraffic(r);
      if (!T.data) { unavailable(body, 'ftp_traffic'); return; }
      tDraw();
    }, function (err) {
      if (T.page === body) { unavailable(body, 'ftp_traffic', err); }
    });
  });

  /* ================= Import forwarders ================= */
  var I = {page: null, account: '', checked: ''};
  var MAX_CSV = 512 * 1024;
  var MAX_ROWS = 1000;
  var ROW_STATUS = {added: 'ok', merged: 'ok', unchanged: 'warn', failed: 'danger'};
  function cleanImport(r) {
    if (!r || typeof r !== 'object' || !Array.isArray(r.rows)) { return null; }
    return {dry: r.dry_run === true, added: num(r.added), merged: num(r.merged), failed: num(r.failed), rows: r.rows.map(function (x) {
      return x && typeof x === 'object' && ROW_STATUS[x.status] ? {row: num(x.row), source: str(x.source, 260), status: x.status, error: str(x.error, 300)} : null;
    }).filter(Boolean).slice(0, MAX_ROWS)};
  }
  function result(d) {
    var parts = [el('p', {class: 'fp-fwi-sum', role: 'status', 'data-fp-summary': '', text: t(d.dry ? 'fwi_sum_dry' : 'fwi_sum',
      {added: count(d.added), merged: count(d.merged), failed: count(d.failed)})})];
    if (d.rows.length) {
      parts.push(el('ul', {class: 'fp-mbi-rows fp-fwi-rows', 'aria-label': t('fwi_rows_label')}, d.rows.map(function (x) {
        return el('li', {class: 'fp-mbi-row', 'data-fp-row': String(x.row)}, [el('span', {class: 'fp-muted fp-mbi-n', text: t('fwi_row', {n: x.row})}),
          el('span', {class: 'fp-mbi-addr sig-mono', text: x.source || '—'}), pill(ROW_STATUS[x.status], t((d.dry ? 'fwi_would_' : 'fwi_') + x.status)),
          x.error ? el('span', {class: 'fp-muted fp-mbi-why', text: sentence(x.error)}) : null]);
      })));
    }
    return parts;
  }
  FP.view('tool:forwarder_import', function () {
    I = {page: null, account: FP.account(), checked: ''};
    var body = M.frame('forwarder_import', 'fp-fwi');
    if (!body) { return; }
    I.page = body;
    var csv = el('textarea', {class: 'sig-input sig-mono fp-mbi-csv', id: 'fp-fwi-csv', name: 'csv', rows: '10', spellcheck: 'false', autocomplete: 'off', autocapitalize: 'none', wrap: 'off',
      placeholder: 'sales@example.com,anna@example.org'});
    var file = el('input', {class: 'sig-input fp-mbi-file', id: 'fp-fwi-file', name: 'file', type: 'file', accept: '.csv,.txt,text/csv,text/plain'});
    var out = el('div', {class: 'fp-fwi-out'});
    var go = el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'fwi-go', hidden: true});
    var form = el('form', {class: 'fp-form fp-mail-form fp-fwi-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-fwi-csv', t('fwi_csv'), csv, t('fwi_csv_hint')), M.field('fp-fwi-file', t('fwi_file'), file, t('fwi_file_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary fp-submit', type: 'submit', text: t('fwi_check')}), go]), out]);
    function read() {
      var v = csv.value.replace(/^\uFEFF/, '');
      var rows = v.split(/\r?\n/).filter(function (l) { return l.trim() !== ''; });
      if (!rows.length) { M.fieldError(form, csv, t('fwi_empty')); return null; }
      if (new window.TextEncoder().encode(v).length > MAX_CSV) { M.fieldError(form, csv, t('fwi_big')); return null; }
      var data = rows.length - (rows[0].split(/[,;\t]/)[0].indexOf('@') < 0 ? 1 : 0);
      if (data > MAX_ROWS) { M.fieldError(form, csv, t('fwi_many', {n: count(data), max: count(MAX_ROWS)})); return null; }
      return v;
    }
    function call(dry, b) {
      var v = read();
      if (v === null) { return; }
      var page = I.page;
      UI.setBusy(b, true);
      FP.call('post', 'forwarderImport', {csv: v, dry_run: dry}, I.account).then(function (r) {
        if (I.page !== page) { return; }
        UI.setBusy(b, false);
        var d = cleanImport(r);
        if (!d) { M.fieldError(form, null, t('api_failed')); return; }
        out.textContent = '';
        out.appendChild(M.card('fp-fwi-res-h', t(dry ? 'fwi_check_title' : 'fwi_done_title'), result(d), 'fp-fwi-result'));
        var n = d.added + d.merged;
        if (dry) {
          I.checked = v;
          go.hidden = n === 0;
          go.textContent = t(n === 1 ? 'fwi_go_one' : 'fwi_go_n', {n: count(n)});
        } else {
          I.checked = '';
          go.hidden = true;
        }
        out.querySelector('#fp-fwi-res-h').focus();
      }, function (err) {
        if (I.page !== page) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    }
    csv.addEventListener('input', function () { if (I.checked && csv.value !== I.checked) { I.checked = ''; go.hidden = true; } });
    file.addEventListener('change', function () {
      var f = file.files && file.files[0];
      if (!f) { return; }
      M.start(form);
      if (f.size > MAX_CSV) { M.fieldError(form, file, t('fwi_big')); file.value = ''; return; }
      var reader = new window.FileReader();
      reader.onload = function () { csv.value = String(reader.result); csv.dispatchEvent(new window.Event('input')); };
      reader.onerror = function () { M.fieldError(form, file, t('fwi_read_failed')); };
      reader.readAsText(f);
    });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (b) { out.textContent = ''; go.hidden = true; call(true, b); }
    });
    go.addEventListener('click', function () {
      if (go.disabled || !I.checked || csv.value !== I.checked) { return; }
      M.start(form);
      call(false, go);
    });
    body.appendChild(M.card('fp-fwi-h', t('fwi_title'), [el('p', {class: 'fp-muted', text: t('fwi_intro')}), el('pre', {class: 'fp-mbi-example sig-mono', text: t('fwi_example')}), form], 'fp-fwi-card'));
  });
})();

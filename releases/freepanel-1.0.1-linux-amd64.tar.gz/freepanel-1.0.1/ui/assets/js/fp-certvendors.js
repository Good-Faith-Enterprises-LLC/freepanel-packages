/* freePanel certificate vendors (docs/api.md, "Certificates from a vendor"): the admin's page (#/tool/ssl_vendors). It holds the
   host's own reseller login at each vendor (a secret is written, never shown: the page only says whether it is set), the vendor's
   test host or another address, and a connection test that buys nothing; then which vendor accounts order from, the products they
   may order and the contact the vendor writes to; and every account's orders. What the server sends is cleaned and shown as text.
   Page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var VENDOR_ID = /^[a-z0-9]{2,30}$/;
  var SETTINGS = ['username', 'partner_code'];
  var SECRETS = ['password', 'auth_token'];
  var CONTACT = [['first_name', 'cvd_c_first', 64], ['last_name', 'cvd_c_last', 64], ['email', 'cvd_c_email', 254], ['phone', 'cvd_c_phone', 32],
    ['organization', 'cvd_c_org', 128], ['country', 'cvd_c_country', 2]];

  function str(v, max) { return typeof v === 'string' ? v.slice(0, max || 300) : ''; }
  function cleanVendor(v) {
    if (!v || typeof v !== 'object' || !VENDOR_ID.test(str(v.id))) { return null; }
    var settings = {};
    var secrets = {};
    SETTINGS.forEach(function (k) { if (v.settings && typeof v.settings[k] === 'string') { settings[k] = str(v.settings[k], 200); } });
    SECRETS.forEach(function (k) { if (v.secrets && typeof v.secrets[k] === 'boolean') { secrets[k] = v.secrets[k]; } });
    return {id: v.id, name: str(v.name, 60) || v.id, sandbox: v.sandbox === true, apiBase: str(v.api_base, 200), base: str(v.base, 200),
      settings: settings, secrets: secrets, ready: v.ready === true, missing: (Array.isArray(v.missing) ? v.missing : []).map(function (m) { return str(m, 40); })};
  }
  function clean(r) {
    var c = r && r.contact && typeof r.contact === 'object' ? r.contact : {};
    var contact = {};
    CONTACT.forEach(function (f) { contact[f[0]] = str(c[f[0]], f[2]); });
    return {active: str(r && r.active, 30), products: (r && Array.isArray(r.products) ? r.products : []).map(function (p) { return str(p, 80); }).filter(Boolean),
      contact: contact, vendors: (r && Array.isArray(r.vendors) ? r.vendors : []).map(cleanVendor).filter(Boolean), storable: !(r && r.secrets_storable === false)};
  }

  var S = null;
  function vendorOf(id) { return S.data.vendors.filter(function (v) { return v.id === id; })[0]; }
  function pill(kind, text) { return el('span', {class: 'sig-pill' + (kind ? ' sig-pill--' + kind : ''), text: text}); }

  /* ================= a vendor's login ================= */
  function vendorCard(v) {
    var id = 'fp-cv-' + v.id;
    var sandbox = el('input', {type: 'checkbox', id: id + '-sandbox', name: 'sandbox'});
    sandbox.checked = v.sandbox;
    var base = el('input', {class: 'sig-input sig-mono', id: id + '-base', name: 'api_base', type: 'url', maxlength: '200', autocomplete: 'off', spellcheck: 'false', value: v.apiBase});
    var fields = [];
    Object.keys(v.settings).forEach(function (k) {
      fields.push(M.field(id + '-' + k, t('cvd_set_' + k), el('input', {class: 'sig-input', id: id + '-' + k, name: k, type: 'text', maxlength: '200',
        autocomplete: 'off', spellcheck: 'false', value: v.settings[k]})));
    });
    Object.keys(v.secrets).forEach(function (k) {
      var input = el('input', {class: 'sig-input', id: id + '-' + k, name: k, type: 'password', maxlength: '500', autocomplete: 'new-password', spellcheck: 'false'});
      var clear = el('input', {type: 'checkbox', id: id + '-' + k + '-clear', name: k + '.clear'});
      fields.push(el('div', {class: 'fp-cv-secret'}, [M.field(id + '-' + k, t('cvd_set_' + k), input, v.secrets[k] ? t('cvd_secret_set') : t('cvd_secret_unset')),
        v.secrets[k] ? el('label', {class: 'fp-check', for: clear.id}, [clear, el('span', {text: t('cvd_secret_clear')})]) : null]));
    });
    var form = el('form', {class: 'fp-form fp-mail-form fp-cv-form', novalidate: '', 'data-fp-vendor': v.id}, [M.errorLine(), M.statusLine(),
      el('p', {class: 'fp-cv-state'}, [pill(v.ready ? 'ok' : 'warn', v.ready ? t('cvd_ready') : t('cvd_not_ready')), ' ',
        el('span', {class: 'fp-muted', text: v.ready ? t('cvd_calls_go', {base: v.base}) : t('cvd_missing', {list: v.missing.map(function (m) { return t('cvd_set_' + m); }).join(', ')})})]),
      el('div', {class: 'fp-cv-fields'}, fields),
      el('label', {class: 'fp-check', for: sandbox.id}, [sandbox, el('span', {text: t('cvd_sandbox')})]),
      M.field(base.id, t('cvd_base'), base, t('cvd_base_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('cvd_save')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'cv-test', disabled: v.ready ? null : true, text: t('cvd_test')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var body = {sandbox: sandbox.checked, api_base: base.value.trim()};
      Object.keys(v.settings).forEach(function (k) { body[k] = form.querySelector('[name="' + k + '"]').value.trim(); });
      Object.keys(v.secrets).forEach(function (k) {
        var val = form.querySelector('[name="' + k + '"]').value;
        var clr = form.querySelector('[name="' + k + '.clear"]');
        if (val) { body[k] = val; } else if (clr && clr.checked) { body[k] = ''; }
      });
      var mine = S;
      UI.setBusy(b, true);
      FP.call('put', 'certVendor', body, {vendor: v.id}).then(function (r) {
        if (S !== mine) { return; }
        var fresh = cleanVendor(r);
        if (fresh) { mine.data.vendors = mine.data.vendors.map(function (x) { return x.id === fresh.id ? fresh : x; }); }
        drawVendor(v.id, t('cvd_saved'));
        drawChoice();
      }, function (err) {
        UI.setBusy(b, false);
        if (S === mine) { M.failed(form, err); }
      });
    });
    return M.card(id + '-h', t('cvd_vendor_title', {vendor: v.name}), [el('p', {class: 'fp-muted', text: t('cvd_vendor_lead_' + v.id)}), form], 'fp-cv-vendor');
  }
  function drawVendor(id, said) {
    var old = S.page.querySelector('form[data-fp-vendor="' + id + '"]');
    var fresh = vendorCard(vendorOf(id));
    if (old) { old.closest('section').replaceWith(fresh); }
    if (said) {
      M.say(fresh, said);
      fresh.querySelector('h2').focus();
    }
  }

  /* ================= what accounts may order ================= */
  function choiceCard() {
    var d = S.data;
    var active = el('select', {class: 'sig-select', id: 'fp-cv-active', name: 'active'}, [el('option', {value: '', text: t('cvd_active_none')})].concat(
      d.vendors.map(function (v) {
        var o = el('option', {value: v.id, text: v.name + (v.ready ? '' : ' (' + t('cvd_not_ready') + ')')});
        if (!v.ready) { o.disabled = true; }
        return o;
      })));
    active.value = d.active;
    var list = el('div', {class: 'fp-cv-products', id: 'fp-cv-products', role: 'group', 'aria-labelledby': 'fp-cv-products-l', 'aria-live': 'polite'});
    var contact = CONTACT.map(function (f) {
      return M.field('fp-cv-c-' + f[0], t(f[1]), el('input', {class: 'sig-input', id: 'fp-cv-c-' + f[0], name: 'contact.' + f[0], type: f[0] === 'email' ? 'email' : 'text',
        maxlength: String(f[2]), autocomplete: 'off', spellcheck: 'false', value: d.contact[f[0]]}));
    });
    var form = el('form', {class: 'fp-form fp-mail-form fp-cv-choice', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-cv-active', t('cvd_active'), active, t('cvd_active_hint')),
      el('div', {class: 'sig-field'}, [el('span', {class: 'sig-label', id: 'fp-cv-products-l', text: t('cvd_products')}), list]),
      el('h3', {class: 'fp-h3', text: t('cvd_contact_title')}), el('p', {class: 'fp-muted', text: t('cvd_contact_admin_hint')}),
      el('div', {class: 'fp-co-contact-grid'}, contact),
      el('p', {class: 'fp-muted', text: t('cvd_billing_later')}),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('cvd_save')})])]);
    function loadProducts() {
      list.textContent = '';
      var id = active.value;
      if (!id) { list.appendChild(el('p', {class: 'fp-muted', text: t('cvd_products_none_active')})); return; }
      list.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
      var mine = S;
      FP.call('get', 'certVendorProducts', undefined, {vendor: id, fresh: '0'}).then(function (r) {
        if (S !== mine || active.value !== id) { return; }
        list.textContent = '';
        var ps = (r && Array.isArray(r.products) ? r.products : []).map(FP.co.cleanProduct).filter(Boolean);
        if (!ps.length) { list.appendChild(el('p', {class: 'fp-muted', text: t('cvd_products_empty')})); return; }
        ps.forEach(function (p, i) {
          var box = el('input', {type: 'checkbox', id: 'fp-cv-p-' + i, name: 'product', value: p.id});
          box.checked = id === S.data.active && S.data.products.indexOf(p.id) >= 0;
          list.appendChild(el('label', {class: 'fp-check fp-cv-product', for: box.id}, [box, el('span', {text: t('cvd_product_line', {name: p.name,
            level: t('cvd_level_' + p.level), kind: t('cvd_kind_' + p.kind)})})]));
        });
      }, function (err) {
        if (S !== mine) { return; }
        list.textContent = '';
        list.appendChild(el('p', {class: 'fp-alert', role: 'alert', text: err.message}));
      });
    }
    active.addEventListener('change', loadProducts);
    loadProducts();
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var picked = Array.prototype.map.call(list.querySelectorAll('input[name="product"]:checked'), function (x) { return x.value; });
      var c = {};
      contact.forEach(function (f) { var i = f.querySelector('input'); c[i.name.slice(8)] = i.value.trim(); });
      var mine = S;
      UI.setBusy(b, true);
      FP.call('put', 'certVendors', {active: active.value, products: picked, contact: c}).then(function (r) {
        if (S !== mine) { return; }
        mine.data = clean(r);
        drawChoice(t('cvd_choice_saved'));
      }, function (err) {
        UI.setBusy(b, false);
        if (S === mine) { M.failed(form, err); }
      });
    });
    return M.card('fp-cv-choice-h', t('cvd_choice_title'), [form], 'fp-cv-choice-card');
  }
  function drawChoice(said) {
    var old = S.page.querySelector('.fp-cv-choice-card');
    var fresh = choiceCard();
    if (old) { old.replaceWith(fresh); }
    if (said) {
      M.say(fresh, said);
      fresh.querySelector('h2').focus();
    }
  }

  /* ================= every order ================= */
  function ordersCard() {
    var parts = [];
    if (S.ordersError) { parts.push(el('p', {class: 'fp-alert', role: 'alert', text: S.ordersError})); }
    else if (!S.orders.length) { parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': 'orders', text: t('cvd_all_none')})); }
    else {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-cv-orders-h'}, [el('table', {class: 'sig-table fp-mail-table'}, [
        el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('cvd_col_site')}), el('th', {scope: 'col', text: t('cvd_col_account')}),
          el('th', {scope: 'col', text: t('cvd_f_product')}), el('th', {scope: 'col', text: t('cvd_col_status')}), el('th', {scope: 'col', text: t('cvd_f_ends')})])]),
        el('tbody', null, S.orders.map(function (o) {
          return el('tr', {'data-fp-order': o.id}, [el('th', {scope: 'row', class: 'sig-mono', text: o.domain}), el('td', {text: o.username}),
            el('td', {text: o.product}), el('td', null, [el('span', {text: t('cvd_s_' + o.status)}), o.renewDue ? el('span', {class: 'fp-muted fp-row-note', text: t('cvd_renew_short')}) : null]),
            el('td', {text: o.notAfter || '—'})]);
        }))])]));
    }
    return M.card('fp-cv-orders-h', t('cvd_all_title'), parts, 'fp-cv-orders');
  }

  function onClick(e) {
    if (!S || !S.page) { return; }
    var b = e.target.closest ? e.target.closest('[data-fp-act="cv-test"]') : null;
    if (!b || !S.page.contains(b) || b.disabled) { return; }
    var form = b.closest('form');
    var id = form.getAttribute('data-fp-vendor');
    var mine = S;
    UI.showError(form, '');
    M.say(form, t('cvd_testing'));
    UI.setBusy(b, true);
    FP.call('post', 'certVendorTest', {}, {vendor: id}).then(function () {
      if (S !== mine) { return; }
      UI.setBusy(b, false);
      M.say(form, t('cvd_test_ok', {vendor: vendorOf(id).name}));
    }, function (err) {
      if (S !== mine) { return; }
      UI.setBusy(b, false);
      M.say(form, '');
      UI.showError(form, err.message);
    });
  }
  document.addEventListener('click', onClick);

  FP.view('tool:ssl_vendors', function () {
    var tool = FP.tools.ssl_vendors;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('ssl_vendors_desc'), cls: 'fp-mail fp-cv',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    S = {page: body, data: clean(null), orders: [], ordersError: ''};
    var mine = S;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    var orders = FP.call('get', 'certOrdersAll').then(function (r) { return {r: r}; }, function (err) { return {err: err}; });
    Promise.all([FP.call('get', 'certVendors'), orders]).then(function (all) {
      if (S !== mine) { return; }
      mine.data = clean(all[0]);
      mine.orders = all[1].err ? [] : (all[1].r && Array.isArray(all[1].r.orders) ? all[1].r.orders : []).map(function (o) {
        var c = FP.co.cleanOrder(o);
        if (c) { c.username = str(o.username, 32); }
        return c;
      }).filter(Boolean);
      mine.ordersError = all[1].err ? all[1].err.message : '';
      body.textContent = '';
      if (!mine.data.storable) { body.appendChild(el('div', {class: 'sig-banner sig-banner--warn', role: 'note'}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('cvd_no_secret_key')})])); }
      mine.data.vendors.forEach(function (v) { body.appendChild(vendorCard(v)); });
      body.appendChild(choiceCard());
      body.appendChild(ordersCard());
    }, function (err) {
      if (S !== mine) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

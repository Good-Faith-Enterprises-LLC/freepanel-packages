/* freePanel server contacts (docs/api.md, "Server contacts"): the admin panel's page (#/tool/server_contacts) for the addresses the
   server writes to when it needs attention (the notices of the notification rules and the failed-service alerts). Up to ten, each with
   a note. Like the record editors, every add, change or removal sends the whole list. A test message goes to one address or to all;
   it says the server's mail took the message, never that it arrived. Admin only: the server refuses these calls to anyone else.
   Everything the server sends is shown as text. The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  /* what this page can tell is not a plain address: no space, no quote, bracket or comma, one @ with something each side. The server is the judge of the rest
     (it accepts root@localhost and a@b), so an address that only looks odd is neither refused here nor hidden when the server lists it. */
  var PLAIN_RE = /^[^\s@<>,;:"()[\]\\]+@[^\s@<>,;:"()[\]\\]+$/;
  var MAX_NOTE = 100;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  /* every address the server lists is kept as it sent it (a whole-list save would otherwise delete one the page could not read), only an empty or
     repeated one is dropped */
  function clean(v) {
    v = v && typeof v === 'object' ? v : {};
    var seen = {};
    var list = (Array.isArray(v.contacts) ? v.contacts : []).filter(function (c) {
      var e = c && typeof c === 'object' ? str(c.email, 254) : '';
      if (!e || seen[e.toLowerCase()]) { return false; }
      seen[e.toLowerCase()] = true;
      return true;
    }).map(function (c) { return {email: str(c.email, 254), note: str(c.note, MAX_NOTE), held: c.held === true}; });
    return {contacts: list, limit: typeof v.limit === 'number' && v.limit > 0 && isFinite(v.limit) ? Math.floor(v.limit) : 10};
  }

  var S = {page: null, C: null, open: -1, busy: false, results: null};

  function wire(c) { return c.note ? {email: c.email, note: c.note} : {email: c.email}; }
  function save(list, b, form, done, focus) {
    S.busy = true;
    UI.setBusy(b, true);
    var mine = S.page;
    FP.call('put', 'serverContacts', {contacts: list.map(wire)}).then(function (r) {
      S.busy = false;
      if (S.page !== mine) { return; }
      S.C = clean(r);
      S.open = -1;
      S.results = null;
      render();
      M.say(S.page.querySelector('.fp-sct-list-card'), done);
      var f = focus && S.page.querySelector(focus);
      if (f) { f.focus(); }
    }, function (err) {
      S.busy = false;
      if (S.page !== mine) { return; }
      UI.setBusy(b, false);
      if (form) { M.failed(form, err); return; }
      render();
      UI.showError(S.page.querySelector('.fp-sct-list-card'), err.message);
      S.page.querySelector('#fp-sct-list-h').focus();
    });
  }

  /* reads the address and note of a form; null (with a message on the form) when they can't be a contact */
  function readContact(form, others) {
    var email = form.querySelector('[name="email"]');
    var note = form.querySelector('[name="note"]');
    var e = email.value.trim();
    if (!PLAIN_RE.test(e) || e.length > 254) { M.fieldError(form, email, t('sct_bad_address')); return null; }
    if (others.indexOf(e.toLowerCase()) >= 0) { M.fieldError(form, email, t('sct_twice')); return null; }
    var n = note.value.trim();
    if (n.length > MAX_NOTE || n.split('').some(function (ch) { var c = ch.charCodeAt(0); return c < 32 || c === 127; })) { M.fieldError(form, note, t('sct_bad_note', {n: MAX_NOTE})); return null; }
    return {email: e, note: n};
  }
  function contactForm(prefix, c, inline) {
    var email = el('input', {class: 'sig-input', id: prefix + '-email', name: 'email', type: 'text', inputmode: 'email', autocomplete: 'off', spellcheck: 'false',
      autocapitalize: 'none', maxlength: '254', value: c ? c.email : ''});
    var note = el('input', {class: 'sig-input', id: prefix + '-note', name: 'note', type: 'text', autocomplete: 'off', maxlength: String(MAX_NOTE),
      value: c ? c.note : '', 'aria-describedby': prefix + '-note-hint'});
    var form = el('form', {class: 'fp-form ' + (inline ? 'fp-mail-inline' : 'fp-mail-form'), novalidate: ''}, [
      inline ? el('h3', {class: 'fp-h3', id: prefix + '-h', text: t('sct_change_title', {email: c.email})}) : null,
      M.errorLine(), inline ? null : M.statusLine(),
      M.field(prefix + '-email', t('sct_email'), email, null),
      M.field(prefix + '-note', t('sct_note'), note, t('sct_note_hint', {n: MAX_NOTE})),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: inline ? t('sct_save') : t('sct_add')}),
        inline ? el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'sct-close', text: t('cancel')}) : null])]);
    if (inline) { form.setAttribute('aria-labelledby', prefix + '-h'); }
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || S.busy) { return; }
      var others = S.C.contacts.map(function (x) { return x.email.toLowerCase(); });
      if (inline) { others.splice(S.open, 1); }
      var r = readContact(form, others);
      if (!r) { return; }
      var list = S.C.contacts.slice();
      if (inline) { list[S.open] = r; } else { list.push(r); }
      save(list, b, form, inline ? t('sct_changed', {email: r.email}) : t('sct_added', {email: r.email}), inline ? '#fp-sct-list-h' : '#fp-sct-new-email');
    });
    return form;
  }

  function row(c, i) {
    return el('li', {class: 'fp-sct-item', 'data-fp-i': String(i)}, [
      el('div', {class: 'fp-sct-who'}, [el('span', {class: 'sig-mono fp-sct-email', text: c.email}), c.note ? el('span', {class: 'fp-muted fp-sct-note', text: c.note}) : null,
        c.held ? el('span', {class: 'fp-sct-held'}, [el('span', {class: 'sig-pill sig-pill--warn', 'data-fp-held': '', text: t('sct_held')})]) : null,
        el('span', {class: 'fp-sct-result', role: 'status', 'data-fp-result': ''})]),
      el('div', {class: 'fp-sct-acts'}, [
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'sct-test', 'aria-label': t('sct_test_of', {email: c.email}), text: t('sct_test')}),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'sct-open', 'aria-label': t('sct_change_of', {email: c.email}), text: t('sct_change')}),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'sct-remove', 'aria-label': t('sct_remove_of', {email: c.email}),
          text: t('sct_remove')})])]);
  }
  function resultsView() {
    if (!S.results) { return null; }
    return el('ul', {class: 'fp-sct-results', 'data-fp-results': '', 'aria-label': t('sct_results')}, S.results.map(function (r) {
      return el('li', {class: 'fp-sct-res'}, [el('span', {class: 'sig-mono', text: r.email}), ' ',
        el('span', {class: 'sig-pill ' + (r.sent ? 'sig-pill--ok' : 'sig-pill--danger'), text: r.sent ? t('sct_sent') : t('sct_not_sent')}),
        r.error ? el('span', {class: 'fp-muted', text: ' ' + r.error}) : null]);
    }));
  }
  function listCard() {
    var C = S.C;
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t('sct_what')}), el('p', {class: 'fp-muted', text: t('sct_only')})];
    if (!C.contacts.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('sct_none')}));
    } else {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-count': '', text: t(C.contacts.length === 1 ? 'sct_count_1' : 'sct_count', {n: C.contacts.length, max: C.limit})}));
      if (C.contacts.some(function (c) { return c.held; })) {
        parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-held-note': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('sct_held_note')})]));
      }
      parts.push(el('ul', {class: 'fp-sct-list', 'aria-labelledby': 'fp-sct-list-h'}, C.contacts.map(row)));
      parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'sct-test-all', text: t('sct_test_all')})]));
      parts.push(el('p', {class: 'fp-muted sig-hint', text: t('sct_test_hint')}));
    }
    var res = resultsView();
    if (res) { parts.push(res); }
    return M.card('fp-sct-list-h', t('sct_title'), parts, 'fp-sct-list-card');
  }
  function addCard() {
    var full = S.C.contacts.length >= S.C.limit;
    return M.card('fp-sct-add-h', t('sct_add_title'), [full ? el('p', {class: 'fp-muted', 'data-fp-sct-full': '', text: t('sct_full', {max: S.C.limit})}) : contactForm('fp-sct-new', null, false)], 'fp-sct-add');
  }
  function render() {
    S.page.textContent = '';
    var list = listCard();
    S.page.appendChild(list);
    if (S.open >= 0 && S.C.contacts[S.open]) {
      var li = list.querySelector('li[data-fp-i="' + S.open + '"]');
      li.textContent = '';
      li.classList.add('fp-sct-editing');
      li.appendChild(contactForm('fp-sct-chg', S.C.contacts[S.open], true));
    }
    S.page.appendChild(addCard());
    S.page.appendChild(rootMailCard());
  }

  /* where the mail the system sends root goes (cron's output, a failing disk's warning): one address, or kept on the server */
  function rootMailCard() {
    var R = S.root || {};
    var input = el('input', {class: 'sig-input', id: 'fp-sct-root', name: 'address', type: 'email', maxlength: '254', autocomplete: 'off', value: R.address || ''});
    var parts = [M.statusLine(), el('p', {class: 'fp-muted', text: t('sct_root_intro')})];
    if (R.other) { parts.push(el('p', {class: 'fp-muted', 'data-fp-root-other': '', text: t('sct_root_other', {line: R.other})})); }
    var form = el('form', {class: 'fp-form fp-sct-rootform', novalidate: ''}, [M.errorLine(), M.field('fp-sct-root', t('sct_root_label'), input, t('sct_root_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('sct_root_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var v = input.value.trim();
      if (v && !PLAIN_RE.test(v)) { M.fieldError(form, input, t('sct_root_bad')); return; }
      var page = S.page;
      UI.setBusy(b, true);
      FP.call('put', 'rootMail', {address: v}).then(function (r) {
        if (S.page !== page) { return; }
        S.root = {address: str(r && r.address, 254), other: str(r && r.other, 200)};
        render();
        var c = S.page.querySelector('.fp-sct-root');
        M.say(c, t(v ? 'sct_root_saved' : 'sct_root_kept'));
        S.page.querySelector('#fp-sct-root-h').focus();
      }, function (err) {
        UI.setBusy(b, false);
        if (S.page === page) { M.failed(form, err); }
      });
    });
    parts.push(form);
    return M.card('fp-sct-root-h', t('sct_root_title'), parts, 'fp-sct-root');
  }

  /* the answer of a test round, in the order of the list */
  function results(r) {
    return (r && Array.isArray(r.results) ? r.results : []).filter(function (x) { return x && typeof x === 'object' && typeof x.email === 'string'; }).map(function (x) {
      return {email: x.email.slice(0, 254), sent: x.sent === true, error: str(x.error, 300)};
    });
  }
  function test(b, email, scope) {
    if (S.busy) { return; }
    S.busy = true;
    UI.setBusy(b, true);
    var mine = S.page;
    FP.call('post', 'serverContactsTest', email ? {email: email} : {}).then(function (r) {
      S.busy = false;
      if (S.page !== mine) { return; }
      var list = results(r);
      UI.setBusy(b, false);
      if (email) {
        var one = list[0] || {sent: false, error: ''};
        scope.querySelector('[data-fp-result]').textContent = one.sent ? t('sct_one_sent') : t('sct_one_not_sent', {error: one.error || t('sct_no_reason')});
      } else {
        S.results = list;
        render();
        M.say(S.page.querySelector('.fp-sct-list-card'), t('sct_tested', {n: list.filter(function (x) { return x.sent; }).length, m: list.length}));
        S.page.querySelector('[data-fp-act="sct-test-all"]').focus();
      }
    }, function (err) {
      S.busy = false;
      if (S.page !== mine) { return; }
      UI.setBusy(b, false);
      UI.showError(S.page.querySelector('.fp-sct-list-card'), err.message);
    });
  }

  document.addEventListener('click', function (e) {
    var node = e.target.closest ? e.target : null;
    var b = node && node.closest('[data-fp-act]');
    if (!b || !S.page || !S.page.contains(b) || !S.C) { return; }
    var a = b.getAttribute('data-fp-act');
    var li = b.closest('li[data-fp-i]');
    var i = li ? Number(li.getAttribute('data-fp-i')) : -1;
    var c = S.C.contacts[i];
    if (a === 'sct-open' && c) {
      S.open = i;
      render();
      S.page.querySelector('#fp-sct-chg-email').focus();
    } else if (a === 'sct-close') {
      var was = S.open;
      S.open = -1;
      render();
      var back = S.page.querySelector('li[data-fp-i="' + was + '"] [data-fp-act="sct-open"]');
      if (back) { back.focus(); }
    } else if (a === 'sct-remove' && c) {
      M.confirmIn(li.querySelector('.fp-sct-acts'), t('sct_remove_ask', {email: c.email}), 'sct-remove-yes', t('sct_remove'));
    } else if (a === 'confirm-no') {
      S.open = -1;
      render();
      var again = S.page.querySelector('li[data-fp-i="' + i + '"] [data-fp-act="sct-remove"]');
      if (again) { again.focus(); }
    } else if (a === 'sct-remove-yes' && c && !S.busy) {
      var list = S.C.contacts.slice();
      list.splice(i, 1);
      save(list, b, null, t('sct_removed', {email: c.email}), '#fp-sct-list-h');
    } else if (a === 'sct-test' && c) {
      test(b, c.email, li);
    } else if (a === 'sct-test-all') {
      test(b, '', null);
    }
  });

  FP.view('tool:server_contacts', function () {
    var tool = FP.tools.server_contacts;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    S.C = null;
    S.open = -1;
    S.busy = false;
    S.results = null;
    var body = FP.frame({title: tool.label, desc: t('sct_desc'), cls: 'fp-mail fp-srv fp-sct-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    S.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    S.root = null;
    Promise.all([FP.call('get', 'serverContacts'), FP.call('get', 'rootMail').then(null, function () { return null; })]).then(function (rs) {
      if (S.page !== body) { return; }
      S.C = clean(rs[0]);
      S.root = rs[1] ? {address: str(rs[1].address, 254), other: str(rs[1].other, 200)} : null;
      render();
    }, function (err) {
      if (S.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

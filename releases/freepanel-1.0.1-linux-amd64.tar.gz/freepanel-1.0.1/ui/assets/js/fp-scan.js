/* freePanel virus scanner (docs/api.md, "Virus scanner": ClamAV). The admin's page (#/tool/virus_scan_admin) installs the scanner from the
   system's packages (a job it follows to its end), turns it on, and shows whether it answers, its engine and signature database and the
   memory it needs. The customer's page (#/tool/virus_scan) scans the account's sites, mail or whole home as the account, follows the scan
   until it ends, lists what was found and deletes the files the customer picks. What the server sends is cleaned to the shapes drawn here
   and shown as text: a path and a signature's name come from a customer's files. "No known malware found" is the most a result says.
   Page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var JOB_STATES = ['idle', 'running', 'succeeded', 'failed'];
  var SCAN_STATES = ['none', 'running', 'done', 'failed', 'interrupted'];
  var STOPPED = ['files', 'findings', 'time', 'scanner'];
  var OUTCOMES = ['removed', 'changed', 'gone', 'failed'];
  var SCOPES = ['web', 'mail', 'home'];
  var POLL_MS = 3000;
  var STATUS_MS = 6000;
  var MAX_STATUS_POLLS = 500;
  var MAX_SCAN_POLLS = 2500;
  var MAX_FINDINGS = 1000;

  function obj(v) { return v && typeof v === 'object' ? v : {}; }
  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 400) : ''; }
  function whole(v) { return typeof v === 'number' && isFinite(v) && v >= 0 && v === Math.floor(v) ? v : 0; }
  function seconds(v) { return typeof v === 'number' && isFinite(v) && v > 0 && v < 4102444800 ? Math.floor(v) : 0; }
  function date(ms) {
    var d = ms ? new Date(ms) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString(undefined, {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }
  function whenS(sec) { return sec ? date(sec * 1000) : ''; }
  function whenIso(iso) { return iso ? date(Date.parse(iso)) : ''; }
  function num(n) { return n.toLocaleString(); }
  function size(n) {
    if (n < 1024) { return t('vs_size_b', {n: n}); }
    return n < 1048576 ? t('vs_size_kb', {n: (n / 1024).toFixed(1)}) : t('vs_size_mb', {n: (n / 1048576).toFixed(1)});
  }
  function pill(text, kind) { return el('span', {class: 'sig-pill' + (kind ? ' sig-pill--' + kind : ''), text: text}); }
  function warn(text, attrs) {
    return el('div', Object.assign({class: 'sig-banner sig-banner--warn', role: 'note'}, attrs || {}), [UI.icon(FP.ui, 'ui_warning'), el('span', {text: text})]);
  }
  function choice(id, name, value, current, label, hint) {
    return el('div', {class: 'fp-acct-choice'}, [el('label', {class: 'fp-check', for: id}, [
      el('input', {type: 'radio', id: id, name: name, value: value, checked: value === current ? true : null, 'aria-describedby': id + '-hint'}), el('span', {text: label})]),
    el('span', {class: 'sig-hint', id: id + '-hint', text: hint})]);
  }

  /* ---- what the server sends, cleaned ---- */
  function cleanStatus(r) {
    r = obj(r);
    return {installed: r.installed === true, installable: r.installable === true, enabled: r.enabled === true, answering: r.answering === true, loading: r.loading === true,
      engine: str(r.engine, 40), ready: r.database_ready === true, version: whole(r.database_version), built: seconds(r.database_built), signatures: whole(r.signatures),
      memory: whole(r.memory_mb), needs: whole(r.needs_memory_mb) || 2048, reason: str(r.reason), warning: str(r.warning)};
  }
  function cleanJob(r) {
    r = obj(r);
    return {state: JOB_STATES.indexOf(r.state) >= 0 ? r.state : 'idle', ended: str(r.ended, 40),
      code: typeof r.exit_code === 'number' && isFinite(r.exit_code) ? Math.round(r.exit_code) : null, timedOut: r.timed_out === true,
      log: (Array.isArray(r.log) ? r.log : []).filter(function (l) { return typeof l === 'string'; }).slice(-200).map(function (l) { return l.slice(0, 400); }),
      truncated: r.log_truncated === true};
  }
  function cleanScan(r) {
    r = obj(r);
    var list = (Array.isArray(r.findings) ? r.findings : []).map(function (f) {
      f = obj(f);
      if (!whole(f.id) || !str(f.path)) { return null; }
      var ns = typeof f.modified_ns === 'number' && isFinite(f.modified_ns) && f.modified_ns > 0 ? Math.floor(f.modified_ns / 1e6) : 0;
      return {id: f.id, path: str(f.path, 500), signature: str(f.signature, 120), size: whole(f.size), modified: ns, removed: f.removed === true};
    }).filter(Boolean).slice(0, MAX_FINDINGS);
    return {available: r.available === true, state: SCAN_STATES.indexOf(r.state) >= 0 ? r.state : 'none',
      roots: (Array.isArray(r.roots) ? r.roots : []).filter(function (x) { return typeof x === 'string' && x; }).slice(0, 12).map(function (x) { return x.slice(0, 200); }),
      started: seconds(r.started), finished: seconds(r.finished), scanned: whole(r.scanned), tooLarge: whole(r.too_large), unreadable: whole(r.unreadable), refused: whole(r.refused),
      stopped: STOPPED.indexOf(r.stopped) >= 0 ? r.stopped : '', error: str(r.error, 300), findings: list};
  }

  /* ================= the admin's page ================= */
  var A = null;

  function pending(s) { return s.installed && s.enabled && (!s.ready || s.loading || !s.answering); }
  function scannerState(s) {
    if (!s.enabled) { return t('vs_s_off'); }
    if (!s.ready) { return t('vs_s_waiting'); }
    if (s.loading) { return t('vs_s_loading'); }
    return s.answering ? t('vs_s_ready') : t('vs_s_silent');
  }
  function facts(s) {
    var rows = [[t('vs_f_scanner'), scannerState(s)]];
    if (s.engine) { rows.push([t('vs_f_engine'), s.engine]); }
    rows.push([t('vs_f_signatures'), s.ready ? t('vs_sigs', {n: num(s.signatures), version: String(s.version), built: s.built ? whenS(s.built) : '—'}) : t(s.enabled ? 'vs_sigs_coming' : 'vs_sigs_none')]);
    if (s.memory) { rows.push([t('vs_f_memory'), t('vs_memory', {have: num(s.memory), need: num(s.needs)})]); }
    return el('dl', {class: 'fp-mail-facts fp-vs-facts', 'data-fp-vs-facts': ''}, rows.reduce(function (out, r) {
      return out.concat([el('dt', {text: r[0]}), el('dd', {text: r[1]})]);
    }, []));
  }
  function drawFacts() {
    var old = A.page.querySelector('[data-fp-vs-facts]');
    if (old && A.status.installed) { old.replaceWith(facts(A.status)); }
  }
  function tooSmall(s) { return s.memory > 0 && s.memory < s.needs; }
  function settingsForm() {
    var s = A.status;
    var blocked = !s.enabled && tooSmall(s);
    var on = el('input', {type: 'checkbox', id: 'fp-vs-on', name: 'enabled', checked: s.enabled ? true : null, disabled: blocked ? true : null, 'aria-describedby': 'fp-vs-on-hint'});
    var form = el('form', {class: 'fp-form fp-mail-form fp-vs-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('div', null, [el('label', {class: 'fp-check', for: 'fp-vs-on'}, [on, el('span', {text: t('vs_on')})]),
        el('span', {class: 'sig-hint', id: 'fp-vs-on-hint', text: blocked ? t('vs_on_memory', {have: num(s.memory), need: num(s.needs)}) : t('vs_on_hint')})]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', disabled: blocked ? true : null, text: t('vs_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      if (on.checked === s.enabled) { M.say(form, t('vs_nothing')); return; }
      var mine = A;
      UI.setBusy(b, true);
      FP.call('put', 'webScan', {enabled: on.checked}).then(function (r) {
        if (A !== mine) { return; }
        A.status = cleanStatus(r);
        A.polls = 0;
        redrawSettings();
        M.say(A.page.querySelector('.fp-vs-set'), t(!A.status.enabled ? 'vs_saved_off' : (pending(A.status) ? 'vs_saved_on_wait' : 'vs_saved_on')));
        watch();
      }, function (err) {
        if (A !== mine) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return form;
  }
  function settingsCard() {
    var s = A.status;
    var parts = [el('p', {class: 'fp-muted', text: t('vs_what')}), s.installed ? null : M.errorLine(), s.installed ? null : M.statusLine()].filter(Boolean);
    if (s.warning) { parts.push(warn(s.warning, {'data-fp-vs-warning': ''})); }
    if (s.installed) {
      parts.push(facts(s), settingsForm());
    } else if (s.installable) {
      parts.push(el('p', {'data-fp-vs-facts': '', text: t('vs_not_installed')}), el('p', {class: 'fp-muted', text: t('vs_install_what')}),
        el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'install', disabled: running() ? true : null, text: t('vs_install')})]));
    } else {
      parts.push(el('p', {'data-fp-vs-facts': '', text: t('vs_not_installed')}), el('p', {class: 'fp-warn-line', 'data-fp-vs-reason': '', text: s.reason || t('vs_cannot_install')}));
    }
    return M.card('fp-vs-set-h', t('vs_title'), parts, 'fp-vs-set');
  }
  function redrawSettings() {
    var old = A.page.querySelector('.fp-vs-set');
    var fresh = settingsCard();
    if (old) { old.replaceWith(fresh); } else { A.page.insertBefore(fresh, A.page.firstChild); }
  }
  /* an enabled scanner that is still starting is read again until it answers */
  function watch() {
    window.clearTimeout(A.watcher);
    if (!pending(A.status) || A.polls >= MAX_STATUS_POLLS) { return; }
    var mine = A;
    A.watcher = window.setTimeout(function () {
      if (A !== mine || !document.body.contains(mine.page)) { return; }
      mine.polls++;
      FP.call('get', 'webScan').then(function (r) {
        if (A !== mine) { return; }
        A.status = cleanStatus(r);
        drawFacts();
        if (pending(A.status)) { watch(); } else if (A.status.enabled) { UI.announce(t('vs_s_ready')); }
      }, function () { if (A === mine) { watch(); } });
    }, STATUS_MS);
  }

  /* ---- the install, followed until it ends ---- */
  function running() { return Boolean(A.job && A.job.state === 'running'); }
  function jobCard() {
    var j = A.job;
    if (!j || j.state === 'idle') { return null; }
    var parts = [];
    if (j.state === 'running') {
      parts.push(el('p', {class: 'fp-vs-now', 'data-fp-job-state': 'running', text: t('vs_job_running')}), el('p', {class: 'fp-muted', text: t('vs_job_running_hint')}));
    } else if (j.state === 'succeeded') {
      parts.push(el('p', {class: 'fp-vs-now', 'data-fp-job-state': 'succeeded', text: t('vs_job_done')}),
        el('p', {class: 'fp-muted', text: t('vs_job_done_hint') + (j.ended ? ' ' + t('vs_job_ended', {when: whenIso(j.ended)}) : '')}));
    } else {
      var why = j.timedOut ? t('vs_job_timed_out') : (j.code === null ? t('vs_job_cut_off') : t('vs_job_code', {code: String(j.code)}));
      parts.push(warn(t('vs_job_failed') + ' ' + why, {'data-fp-job-state': 'failed'}));
      if (j.ended) { parts.push(el('p', {class: 'fp-muted', text: t('vs_job_ended', {when: whenIso(j.ended)})})); }
    }
    if (j.log.length) {
      parts.push(el('pre', {class: 'fp-vs-log sig-mono', tabindex: '0', 'data-fp-job-log': '', 'aria-label': t('vs_job_log'), text: j.log.join('\n')}));
      if (j.truncated) { parts.push(el('p', {class: 'fp-muted', text: t('vs_job_truncated')})); }
    }
    return M.card('fp-vs-job-h', t('vs_job_title'), parts, 'fp-vs-job');
  }
  function drawJob() {
    var old = A.page.querySelector('.fp-vs-job');
    var fresh = jobCard();
    var active = document.activeElement;
    var inLog = Boolean(old && active && active.hasAttribute && active.hasAttribute('data-fp-job-log') && old.contains(active));
    if (!fresh) { if (old) { old.remove(); } return; }
    if (old) { old.replaceWith(fresh); } else { A.page.querySelector('.fp-vs-set').after(fresh); }
    var log = fresh.querySelector('[data-fp-job-log]');
    if (log && running()) { log.scrollTop = log.scrollHeight; }
    if (inLog && log) { log.focus(); }
  }
  function follow() {
    window.clearTimeout(A.timer);
    var mine = A;
    A.timer = window.setTimeout(function () {
      if (A !== mine || !document.body.contains(mine.page)) { return; }
      FP.call('get', 'webScanInstall').then(function (r) {
        if (A !== mine) { return; }
        A.job = cleanJob(r);
        if (running()) { drawJob(); follow(); return; }
        ended(mine);
      }, function () { if (A === mine) { follow(); } });
    }, POLL_MS);
  }
  /* the install has ended: the scanner is read again (it is installed now), and the page says how it ended */
  function ended(mine) {
    var j = A.job;
    var done = function () {
      if (A !== mine) { return; }
      redrawSettings();
      drawJob();
      UI.announce(t(j.state === 'succeeded' ? 'vs_job_done' : 'vs_job_failed'));
    };
    FP.call('get', 'webScan').then(function (r) { if (A === mine) { A.status = cleanStatus(r); } done(); }, done);
  }
  function install(b) {
    var mine = A;
    var card = A.page.querySelector('.fp-vs-set');
    UI.showError(card, '');
    M.say(card, '');
    UI.setBusy(b, true);
    FP.call('post', 'webScanInstall').then(function (r) {
      if (A !== mine) { return; }
      A.job = cleanJob(r);
      redrawSettings();
      drawJob();
      M.say(A.page.querySelector('.fp-vs-set'), t('vs_install_started'));
      var h = A.page.querySelector('#fp-vs-job-h');
      if (h) { h.focus(); }
      if (running()) { follow(); }
    }, function (err) {
      if (A !== mine) { return; }
      UI.setBusy(b, false);
      UI.showError(card, err.message);
      b.focus();
    });
  }
  function onAdminClick(e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act="install"]') : null;
    if (b && A && A.page.contains(b) && !b.disabled) { install(b); }
  }
  document.addEventListener('click', onAdminClick);

  FP.view('tool:virus_scan_admin', function () {
    if (A) { window.clearTimeout(A.timer); window.clearTimeout(A.watcher); }
    A = null;
    var tool = FP.tools.virus_scan_admin;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('vs_desc'), cls: 'fp-mail fp-vs',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    A = {page: page, status: cleanStatus(null), job: null, timer: 0, watcher: 0, polls: 0};
    var mine = A;
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all([FP.call('get', 'webScan'), FP.call('get', 'webScanInstall').then(function (j) { return cleanJob(j); }, function () { return null; })]).then(function (r) {
      if (A !== mine) { return; }
      A.status = cleanStatus(r[0]);
      A.job = r[1];
      page.textContent = '';
      page.appendChild(settingsCard());
      var j = jobCard();
      if (j) { page.appendChild(j); }
      if (running()) { follow(); }
      watch();
    }, function (err) {
      if (A !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err.message));
    });
  });

  /* ================= the customer's page ================= */
  var S = null;

  function picked() { return Object.keys(S.pick).filter(function (k) { return S.pick[k]; }).map(Number); }
  function startCard() {
    var d = S.data;
    var busy = d.state === 'running' || S.starting;
    var parts = [el('p', {class: 'fp-muted', text: t('vsc_what')})];
    if (!d.available) { parts.push(warn(t('vsc_unavailable'), {'data-fp-vsc-note': 'off'})); }
    var form = el('form', {class: 'fp-form fp-mail-form fp-vsc-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('fieldset', {class: 'fp-acct-kinds'}, [el('legend', {class: 'sig-label', text: t('vsc_scope')}),
        choice('fp-vsc-scope-web', 'scope', 'web', S.scope, t('vsc_scope_web'), t('vsc_scope_web_hint')),
        choice('fp-vsc-scope-mail', 'scope', 'mail', S.scope, t('vsc_scope_mail'), t('vsc_scope_mail_hint')),
        choice('fp-vsc-scope-home', 'scope', 'home', S.scope, t('vsc_scope_home'), t('vsc_scope_home_hint'))]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', disabled: !d.available || busy ? true : null,
        text: t(busy ? 'vsc_scanning_btn' : 'vsc_scan')})])]);
    form.addEventListener('change', function (e) {
      if (e.target && e.target.name === 'scope' && SCOPES.indexOf(e.target.value) >= 0) { S.scope = e.target.value; }
    });
    form.addEventListener('submit', function (e) { e.preventDefault(); scan(form); });
    parts.push(form);
    return M.card('fp-vsc-start-h', t('vsc_title'), parts, 'fp-vsc-start');
  }
  function counts(d) {
    var parts = [t(d.scanned === 1 ? 'vsc_scanned_1' : 'vsc_scanned', {n: num(d.scanned)})];
    if (d.tooLarge) { parts.push(t('vsc_too_large', {n: num(d.tooLarge)})); }
    if (d.unreadable) { parts.push(t('vsc_unreadable', {n: num(d.unreadable)})); }
    if (d.refused) { parts.push(t('vsc_refused', {n: num(d.refused)})); }
    return parts.join(' ');
  }
  function stateBadge(f) {
    var o = S.outcomes[f.id];
    if (f.removed) { return pill(t('vsc_is_deleted'), 'ok'); }
    if (o === 'changed') { return pill(t('vsc_o_changed'), 'accent'); }
    if (o === 'gone') { return pill(t('vsc_o_gone'), ''); }
    if (o === 'failed') { return pill(t('vsc_o_failed'), 'danger'); }
    return null;
  }
  function findingRow(f) {
    var box = el('input', {type: 'checkbox', 'data-fp-pick': String(f.id), 'aria-label': t('vsc_pick', {path: f.path}), checked: S.pick[f.id] && !f.removed ? true : null, disabled: f.removed ? true : null});
    return el('tr', {'data-fp-finding': String(f.id)}, [el('td', {class: 'fp-vsc-pick'}, [box]), el('th', {scope: 'row', class: 'fp-vsc-path sig-mono', text: f.path}),
      el('td', {text: f.signature || '—'}), el('td', {text: size(f.size)}), el('td', {text: f.modified ? date(f.modified) : '—'}), el('td', null, [stateBadge(f)])]);
  }
  function deleteLabel() {
    var n = picked().length;
    return n ? t(n === 1 ? 'vsc_delete_1' : 'vsc_delete_n', {n: n}) : t('vsc_delete');
  }
  function findings(d) {
    var open = d.findings.filter(function (f) { return !f.removed; });
    var all = el('input', {type: 'checkbox', id: 'fp-vsc-all', 'aria-label': t('vsc_pick_all'), checked: open.length && picked().length === open.length ? true : null, disabled: open.length ? null : true});
    var table = el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-vsc-result-h'}, [el('table', {class: 'sig-table fp-mail-table fp-vsc-table'}, [
      el('thead', null, [el('tr', null, [el('th', {scope: 'col', class: 'fp-vsc-pick'}, [all]), el('th', {scope: 'col', text: t('vsc_col_file')}), el('th', {scope: 'col', text: t('vsc_col_signature')}),
        el('th', {scope: 'col', text: t('vsc_col_size')}), el('th', {scope: 'col', text: t('vsc_col_changed')}), el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('vsc_col_state')})])])]),
      el('tbody', null, d.findings.map(findingRow))])]);
    return [el('p', {class: 'fp-muted', text: t(open.length === 1 ? 'vsc_found_1' : 'vsc_found', {n: num(open.length)})}), table, open.length ? actions() : null].filter(Boolean);
  }
  function actions() {
    return el('div', {class: 'fp-actions fp-vsc-acts'}, [el('button', {class: 'sig-btn sig-btn--danger', type: 'button', 'data-fp-act': 'delete', 'data-fp-delete': '',
      disabled: picked().length ? null : true, text: deleteLabel()})]);
  }
  /* the question names a number of files: when the picks change it is withdrawn, so the files deleted are the files asked about */
  function withdraw() {
    var acts = S.page.querySelector('.fp-vsc-acts');
    if (acts && acts.querySelector('.fp-mail-confirm')) { acts.replaceWith(actions()); }
  }
  function resultCard() {
    var d = S.data;
    var parts = [M.errorLine(), M.statusLine()];
    if (d.state === 'none') {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-vsc-state': 'none', text: t('vsc_none')}));
    } else if (d.state === 'running') {
      parts.push(el('p', {class: 'fp-vs-now', 'data-fp-vsc-state': 'running', text: t('vsc_running', {when: whenS(d.started) || '—'})}), el('p', {class: 'fp-muted', text: t('vsc_running_hint')}));
    } else if (d.state === 'interrupted') {
      parts.push(warn(t('vsc_interrupted'), {'data-fp-vsc-state': 'interrupted'}));
    } else {
      if (d.state === 'failed') { parts.push(warn(t('vsc_failed') + (d.error ? ' ' + d.error : ''), {'data-fp-vsc-state': 'failed'})); }
      var line = (d.finished ? t('vsc_finished', {when: whenS(d.finished)}) + ' ' : '') + (d.roots.length ? t('vsc_looked', {roots: d.roots.join(', ')}) + ' ' : '') + counts(d);
      parts.push(el('p', {'data-fp-vsc-state': d.state === 'done' ? 'done' : null, 'data-fp-vsc-summary': '', text: line}));
      if (d.stopped) { parts.push(warn(t('vsc_stopped_' + d.stopped) + (d.stopped === 'scanner' && d.error ? ' ' + d.error : ''), {'data-fp-vsc-stopped': d.stopped})); }
      if (d.findings.length) { parts = parts.concat(findings(d)); }
      else if (d.state === 'done' && !d.stopped) { parts.push(el('p', {class: 'fp-ok-line', 'data-fp-vsc-clear': '', text: t('vsc_clear')})); }
      else if (d.state === 'done') { parts.push(el('p', {class: 'fp-muted', 'data-fp-vsc-clear': '', text: t('vsc_clear_so_far')})); }
    }
    return M.card('fp-vsc-result-h', t('vsc_result_title'), parts, 'fp-vsc-result');
  }
  function redraw(focus) {
    var oldStart = S.page.querySelector('.fp-vsc-start');
    var oldResult = S.page.querySelector('.fp-vsc-result');
    var a = startCard();
    var b = resultCard();
    oldStart.replaceWith(a);
    oldResult.replaceWith(b);
    var target = focus ? S.page.querySelector(focus) : null;
    if (target) { target.focus(); }
  }
  function redrawResult() {
    var old = S.page.querySelector('.fp-vsc-result');
    var fresh = resultCard();
    old.replaceWith(fresh);
    return fresh;
  }

  function scan(form) {
    var b = M.start(form);
    if (!b || !S) { return; }
    var mine = S;
    S.starting = true;
    UI.setBusy(b, true);
    FP.call('post', 'acctScan', {scope: S.scope}, S.account).then(function (r) {
      if (S !== mine) { return; }
      S.starting = false;
      S.data = cleanScan(Object.assign({}, obj(r), {available: true}));
      S.pick = {};
      S.outcomes = {};
      redraw('#fp-vsc-result-h');
      M.say(S.page.querySelector('.fp-vsc-start'), t('vsc_started'));
      followScan();
    }, function (err) {
      if (S !== mine) { return; }
      S.starting = false;
      UI.setBusy(b, false);
      M.failed(form, err);
    });
  }
  /* a running scan is read again until it ends */
  function followScan() {
    window.clearTimeout(S.timer);
    if (S.data.state !== 'running' || S.polls >= MAX_SCAN_POLLS) { return; }
    var mine = S;
    S.timer = window.setTimeout(function () {
      if (S !== mine || !document.body.contains(mine.page)) { return; }
      mine.polls++;
      FP.call('get', 'acctScan', undefined, S.account).then(function (r) {
        if (S !== mine) { return; }
        var fresh = cleanScan(r);
        if (fresh.state === 'running') { S.data = fresh; followScan(); return; }
        S.data = fresh;
        S.polls = 0;
        S.pick = {};
        redraw();
        UI.announce(t('vsc_ended'));
      }, function () { if (S === mine) { followScan(); } });
    }, POLL_MS);
  }
  /* a removal names findings by their place in the last scan's result, and a newer scan counts from 1 again: the result is read first,
     and nothing is sent unless each picked number is still the file the page showed */
  function unchanged(fresh, ids) {
    var at = function (d, id) { return d.findings.filter(function (f) { return f.id === id; })[0]; };
    return fresh.state === 'done' && ids.every(function (id) {
      var was = at(S.data, id);
      var now = at(fresh, id);
      return Boolean(was && now && was.path === now.path && was.signature === now.signature && was.size === now.size && was.modified === now.modified);
    });
  }
  function remove(b) {
    var ids = picked();
    var mine = S;
    var box = S.page.querySelector('.fp-vsc-result');
    UI.showError(box, '');
    M.say(box, '');
    UI.setBusy(b, true);
    FP.call('get', 'acctScan', undefined, S.account).then(function (now) {
      if (S !== mine) { return null; }
      var fresh = cleanScan(now);
      if (unchanged(fresh, ids)) { return FP.call('post', 'acctScanRemove', {ids: ids}, S.account); }
      S.data = fresh;
      S.pick = {};
      S.outcomes = {};
      redraw('#fp-vsc-result-h');
      M.say(S.page.querySelector('.fp-vsc-result'), t('vsc_changed'));
      followScan();
      return null;
    }).then(function (r) {
      if (!r || S !== mine) { return; }
      var counted = {removed: 0, changed: 0, gone: 0, failed: 0};
      (Array.isArray(obj(r).outcomes) ? r.outcomes : []).forEach(function (o) {
        o = obj(o);
        if (whole(o.id) && OUTCOMES.indexOf(o.outcome) >= 0) { S.outcomes[o.id] = o.outcome; counted[o.outcome]++; }
      });
      S.pick = {};
      FP.call('get', 'acctScan', undefined, S.account).then(function (fresh) { if (S === mine) { S.data = cleanScan(fresh); } }, function () { /* the rows keep what they showed */ })
        .then(function () {
          if (S !== mine) { return; }
          var next = redrawResult();
          M.say(next, removedLine(counted));
          next.querySelector('#fp-vsc-result-h').focus();
        });
    }, function (err) {
      if (S !== mine) { return; }
      S.page.querySelector('.fp-vsc-acts').replaceWith(actions());
      UI.showError(S.page.querySelector('.fp-vsc-result'), err.message);
    });
  }
  function removedLine(c) {
    var gone = c.removed + c.gone;
    var parts = [t(gone === 1 ? 'vsc_deleted_1' : 'vsc_deleted', {n: gone})];
    if (c.changed) { parts.push(t(c.changed === 1 ? 'vsc_deleted_changed_1' : 'vsc_deleted_changed', {n: c.changed})); }
    if (c.failed) { parts.push(t('vsc_deleted_failed', {n: c.failed})); }
    return parts.join(' ');
  }
  function sync() {
    var all = S.page.querySelector('#fp-vsc-all');
    var open = S.data.findings.filter(function (f) { return !f.removed; });
    if (all) { all.checked = open.length > 0 && picked().length === open.length; }
    var del = S.page.querySelector('[data-fp-delete]');
    if (del) { del.disabled = !picked().length; del.textContent = deleteLabel(); }
  }
  function onChange(e) {
    if (!S || !e.target || !S.page.contains(e.target)) { return; }
    var id = e.target.getAttribute && e.target.getAttribute('data-fp-pick');
    if (id) {
      S.pick[id] = e.target.checked;
      withdraw();
      sync();
    } else if (e.target.id === 'fp-vsc-all') {
      S.data.findings.forEach(function (f) { if (!f.removed) { S.pick[f.id] = e.target.checked; } });
      S.page.querySelectorAll('[data-fp-pick]').forEach(function (c) { if (!c.disabled) { c.checked = e.target.checked; } });
      withdraw();
      sync();
    }
  }
  function onCustomerClick(e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !S || !S.page.contains(b) || b.disabled) { return; }
    var act = b.getAttribute('data-fp-act');
    if (act === 'delete') {
      var n = picked().length;
      M.confirmIn(b.parentNode, t(n === 1 ? 'vsc_delete_ask_1' : 'vsc_delete_ask', {n: n}), 'delete-yes', t(n === 1 ? 'vsc_delete_1' : 'vsc_delete_n', {n: n}));
    } else if (act === 'confirm-no') {
      redrawResult();
      var again = S.page.querySelector('[data-fp-delete]');
      if (again) { again.focus(); }
    } else if (act === 'delete-yes') {
      remove(b);
    }
  }
  document.addEventListener('change', onChange);
  document.addEventListener('click', onCustomerClick);

  FP.view('tool:virus_scan', function () {
    if (S) { window.clearTimeout(S.timer); }
    S = null;
    var page = M.frame('virus_scan', 'fp-vsc-page');
    if (!page) { return; }
    S = {page: page, account: FP.account(), data: cleanScan(null), scope: 'web', pick: {}, outcomes: {}, starting: false, timer: 0, polls: 0};
    var mine = S;
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'acctScan', undefined, S.account).then(function (r) {
      if (S !== mine) { return; }
      S.data = cleanScan(r);
      page.textContent = '';
      page.appendChild(startCard());
      page.appendChild(resultCard());
      followScan();
    }, function (err) {
      if (S !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(FP.tools.virus_scan.label, err.message));
    });
  });
})();

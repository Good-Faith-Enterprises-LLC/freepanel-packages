/* freePanel billing settings (#/tool/billing_settings; docs/api.md, "Billing: settings" and the sections each part names;
   docs/billing/navigation-map.md, "Settings"): the sections in order: Company (on invoices), Invoices (numbering and due days), Quotes,
   Orders (terms required, default group, the cap on orders waiting), Terms of service, Provisioning, Automation and Sending. Each section is
   read from GET /billing/settings and saved through its own route, only what changed. Terms, Automation and Sending have pages of their own. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;
  var M = FP.mail;

  var COMPANY = [['name', 100], ['address1', 100], ['address2', 100], ['city', 60], ['region', 60], ['postcode', 20], ['country', 2], ['email', 254], ['phone', 30], ['website', 100], ['tax_number', 40]];
  FP.view('tool:billing_settings', function () {
    var page = B.frame('billing_settings', 'fp-bst');
    if (!page) { return; }
    var alive = function () { return page.isConnected; };
    /* one section: its specs, its values, the route and method that save it, and a note */
    function section(id, specs, values, route, method, what, fix) {
      var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bil_save_changes')});
      var form = el('form', {class: 'fp-form fp-bil-crud-form', novalidate: '', 'aria-labelledby': 'fp-bst-' + id + '-h', 'data-fp-section': id}, [M.errorLine(), M.statusLine(),
        el('div', {class: 'fp-bil-grid'}, B.fieldsOf('fp-bst-' + id, specs, values)), el('div', {class: 'fp-actions'}, [save])]);
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!B.begin(form, save)) { return; }
        var body = B.readFields(form, specs, values);
        if (!body) { return; }
        if (fix) { fix(body); }
        if (!Object.keys(body).length) { M.say(form, t('bil_nothing_changed')); return; }
        UI.setBusy(save, true);
        FP.call(method, route, method === 'put' ? Object.assign({}, body) : body).then(function (r) {
          if (!alive()) { return; }
          UI.setBusy(save, false);
          Object.keys(body).forEach(function (k) { values[k] = r && Object.prototype.hasOwnProperty.call(r, k) ? r[k] : body[k]; });
          M.say(form, t('bst_saved'));
        }, function (err) {
          if (!alive()) { return; }
          UI.setBusy(save, false);
          B.failed(form, err);
        });
      });
      return B.card('fp-bst-' + id + '-h', t('bst_' + id), [el('p', {class: 'fp-muted', text: what}), form], 'fp-bst-sec', id);
    }
    function linkCard(id, tool) {
      var go = FP.tools[tool] ? el('a', {class: 'sig-btn sig-btn--secondary', href: '#/tool/' + tool, text: t('bst_open', {name: FP.tools[tool].label})}) : null;
      return B.card('fp-bst-' + id + '-h', t('bst_' + id), [el('p', {class: 'fp-muted', text: t('bst_' + id + '_what')}), go ? el('div', {class: 'fp-actions'}, [go]) : null].filter(Boolean), 'fp-bst-sec', id);
    }
    function draw(s, groups) {
      var company = B.pick(s.company, Object.fromEntries ? Object.fromEntries(COMPANY.map(function (c) { return [c[0], [c[1]]]; }).concat([['invoice_footer', [300]]])) : {}) || {};
      var inv = B.pick(s.invoices, {prefix: [12], digits: 'n', due_days: 'n', credit_prefix: [12], next_number: 'n', next_credit_number: 'n'}) || {};
      var quotes = B.pick(s.quotes || {}, {prefix: [12], digits: 'n', valid_days: 'n', next_number: 'n'}) || {};
      var orders = B.pick(s.orders, {require_terms: 'b', default_group_id: 'id', max_pending_orders: 'n'}) || {};
      var prov = B.pick(s.provisioning, {on_accept: 'b'}) || {};
      var nodes = [
        section('company', COMPANY.map(function (c) { return {name: c[0], label: t('bst_c_' + c[0]), max: c[1], code: c[0] === 'email' || c[0] === 'website' || c[0] === 'country', send_empty: true}; })
          .concat([{name: 'invoice_footer', label: t('bst_c_invoice_footer'), kind: 'textarea', max: 300, rows: 4, hint: t('bst_c_footer_hint'), wide: true}]), company, 'billingCompany', 'patch', t('bst_company_what'),
          function (b) { if (b.country !== undefined) { b.country = b.country.toUpperCase(); if (b.country === company.country) { delete b.country; } } }),
        section('invoices', [{name: 'prefix', label: t('bst_i_prefix'), max: 12, code: true, send_empty: true, hint: t('bst_i_prefix_hint')}, {name: 'next_number', label: t('bst_i_next'), kind: 'number', max: 9, hint: t('bst_i_next_hint')},
          {name: 'digits', label: t('bst_i_digits'), kind: 'number', max: 2, hint: t('bst_i_digits_hint')}, {name: 'due_days', label: t('bst_i_due'), kind: 'number', max: 3, hint: t('bst_i_due_hint')},
          {name: 'credit_prefix', label: t('bst_i_cprefix'), max: 12, code: true, send_empty: true, hint: t('bst_i_cprefix_hint')}], inv, 'billingInvoiceSettings', 'patch', t('bst_invoices_what')),
        section('quotes', [{name: 'prefix', label: t('bst_i_prefix'), max: 12, code: true, send_empty: true}, {name: 'next_number', label: t('bst_i_next'), kind: 'number', max: 9, hint: t('bst_i_next_hint')},
          {name: 'digits', label: t('bst_i_digits'), kind: 'number', max: 2}, {name: 'valid_days', label: t('bst_q_valid'), kind: 'number', max: 3, hint: t('bst_q_valid_hint')}], quotes, 'billingQuoteSettings', 'patch', t('bst_quotes_what')),
        section('orders', [{name: 'require_terms', label: t('bst_o_terms'), kind: 'check', hint: t('bst_o_terms_hint')},
          {name: 'default_group_id', label: t('bst_o_group'), kind: 'select', num: true, options: [['', t('bcl_no_group')]].concat(groups.map(function (g) { return [String(g.id), g.name]; })), hint: t('bst_o_group_hint')},
          {name: 'max_pending_orders', label: t('bst_o_cap'), kind: 'number', max: 3, hint: t('bst_o_cap_hint')}], orders, 'billingOrderSettings', 'patch', t('bst_orders_what')),
        linkCard('terms', 'billing_terms'),
        section('provisioning', [{name: 'on_accept', label: t('bst_p_on'), kind: 'check', hint: t('bst_p_on_hint')}], prov, 'billingProvisioning', 'put', t('bst_provisioning_what')),
        linkCard('automation', 'billing_automation'), linkCard('sending', 'billing_templates')];
      B.screen(page, nodes);
    }
    function load() {
      Promise.all([FP.call('get', 'billingSettings'), FP.call('get', 'billingGroups').then(function (r) { return B.pickAll(r && r.groups, {id: 'id', name: [60]}, 'id'); }, function () { return []; })]).then(function (r) {
        if (alive()) { draw(r[0] || {}, r[1]); }
      }, function (err) {
        if (!alive()) { return; }
        B.screen(page, [FP.empty(t('bst_company'), err.message, B.button('reload', t('bil_try_again')))]);
        page.querySelector('[data-fp-act="reload"]').addEventListener('click', load);
      });
    }
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    load();
  });
})();

/* freePanel reseller and account overview pages of the admin panel (docs/api.md, "Resellers", "Accounts", "Session policy"):
   Reseller usage (#/tool/reseller_usage: each reseller's share of its limits), Reseller templates (#/tool/reseller_templates: saved
   sets of limits and privileges, applied to a reseller or used to reset one), All domains (#/tool/all_domains: every hosted name, cut
   by kind), Account activity (#/tool/account_activity: accounts that signed in lately and those that did not) and Session policy
   (#/tool/session_policy: maximum password age and sessions tied to their address). The reseller pages and the session policy are
   the server admin's; the domain list and activity show a reseller its own accounts. What the server sends is drawn as text. The page
   pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var USER_RE = /^[a-z][a-z0-9]{0,15}$/;
  var DOMAIN_RE = /^(?=.{1,253}$)([a-z0-9_]([a-z0-9_-]{0,61}[a-z0-9])?\.)+[a-z0-9-]{2,63}$/;
  var TPL_RE = /^[A-Za-z0-9][A-Za-z0-9 ._-]{0,63}$/;
  var LIMITS = [['max_accounts', 'rac_lim_accounts'], ['max_disk_mb', 'rac_lim_disk'], ['max_bandwidth_mb', 'rac_lim_bandwidth']];
  var PRIVS = [['lift_bandwidth', 'rac_priv_lift'], ['branding', 'rac_priv_branding']];
  var KINDS = ['', 'primary', 'addon', 'alias', 'subdomain'];

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function whole(v) { return typeof v === 'number' && isFinite(v) && v >= 0 && Math.floor(v) === v ? v : null; }
  function count(n) { return Number(n).toLocaleString('en'); }
  function isAdmin() { return FP.session.user.role === 'admin'; }
  function stamp(iso) {
    var d = typeof iso === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(iso) ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }
  function pill(kind, text) { return el('span', {class: 'sig-pill sig-pill--' + kind, text: text}); }
  function frame(id, adminOnly) {
    var tool = FP.tools[id];
    if (!tool || FP.realm !== 'admin' || (adminOnly && !isAdmin())) { FP.views['not-found']({view: 'not-found'}); return null; }
    var g = FP.group(tool.group);
    return FP.frame({title: tool.label, desc: t(id + '_desc'), cls: 'fp-mail fp-rac fp-rac-' + id,
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
  }
  function failPage(body, label, err) {
    body.textContent = '';
    body.appendChild(FP.empty(label, err && err.message ? err.message : t('api_failed')));
  }
  function table(label, heads, rows) {
    return el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-label': label}, [
      el('table', {class: 'sig-table fp-rac-table'}, [el('thead', null, [el('tr', null, heads.map(function (h) { return el('th', {scope: 'col', text: h}); }))]),
        el('tbody', null, rows)])]);
  }
  function limitText(v, mb) {
    if (v === null) { return t('rac_no_limit'); }
    return mb ? t('rac_mb', {n: count(v)}) : count(v);
  }

  /* ================= Reseller usage ================= */
  function cleanOverview(o) {
    if (!o || !USER_RE.test(str(o.username, 20))) { return null; }
    var l = o.limits && typeof o.limits === 'object' ? o.limits : {};
    var u = o.usage && typeof o.usage === 'object' ? o.usage : {};
    var pct = function (v) { return whole(v); };
    return {username: o.username, disabled: o.disabled === true, near: o.near_limit === true,
      active: whole(o.active_accounts) || 0, suspended: whole(o.suspended_accounts) || 0, domains: whole(o.domains) || 0,
      traffic: whole(o.bandwidth_bytes) || 0,
      rows: [
        {label: 'rac_lim_accounts', used: whole(u.accounts) || 0, limit: whole(l.max_accounts), pct: pct(o.percent_accounts), mb: false},
        {label: 'rac_lim_disk', used: whole(u.disk_mb) || 0, limit: whole(l.max_disk_mb), pct: pct(o.percent_disk), mb: true},
        {label: 'rac_lim_bandwidth', used: whole(u.bandwidth_mb) || 0, limit: whole(l.max_bandwidth_mb), pct: pct(o.percent_bandwidth), mb: true}]};
  }
  function gib(bytes) { return bytes >= 1073741824 ? t('rac_gb', {n: (Math.round(bytes / 1073741824 * 10) / 10).toLocaleString('en')}) : t('rac_mb', {n: count(Math.round(bytes / 1048576))}); }
  function useCell(r) {
    var text = r.limit === null ? t('rac_used_no_limit', {used: limitText(r.used, r.mb)}) :
      t('rac_used_of', {used: limitText(r.used, r.mb), limit: limitText(r.limit, r.mb), pct: count(r.pct === null ? 0 : r.pct)});
    var ratio = r.limit === null ? 0 : Math.min(1, (r.pct || 0) / 100);
    var bar = el('i');
    bar.style.width = (ratio * 100).toFixed(1) + '%';
    return el('td', null, [el('span', {text: text}), r.limit === null ? null :
      el('div', {class: 'sig-meter' + (ratio >= 1 ? ' is-danger' : ratio >= 0.9 ? ' is-warn' : ''), 'aria-hidden': 'true'}, [bar])]);
  }
  FP.view('tool:reseller_usage', function () {
    var body = frame('reseller_usage', true);
    if (!body) { return; }
    var mine = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'resellerUsage').then(function (r) {
      if (!mine.isConnected) { return; }
      var list = (r && Array.isArray(r.resellers) ? r.resellers : []).map(cleanOverview).filter(Boolean);
      body.textContent = '';
      if (!list.length) { body.appendChild(FP.empty(t('rac_usage_none_title'), t('rac_usage_none'))); return; }
      var near = list.filter(function (x) { return x.near; }).length;
      var parts = [el('p', {class: 'fp-muted', role: 'status', 'data-fp-summary': '', text: near ? t(near === 1 ? 'rac_near_one' : 'rac_near_n', {n: count(near)}) : t('rac_near_none')})];
      parts.push(table(t('rac_usage_table'), [t('rac_reseller'), t('rac_lim_accounts'), t('rac_lim_disk'), t('rac_lim_bandwidth'), t('rac_customers'), t('rac_domains'), t('rac_traffic')],
        list.map(function (x) {
          return el('tr', {'data-fp-reseller': x.username}, [el('th', {scope: 'row'}, [el('span', {class: 'sig-mono', text: x.username}),
            x.disabled ? pill('warn', t('rac_off')) : null, x.near ? pill('danger', t('rac_near')) : null])]
            .concat(x.rows.map(useCell), [el('td', {text: t('rac_customers_text', {active: count(x.active), suspended: count(x.suspended)})}),
              el('td', {text: count(x.domains)}), el('td', {text: gib(x.traffic)})]));
        })));
      body.appendChild(M.card('fp-rac-usage-h', t('rac_usage_title'), parts, 'fp-rac-usage'));
    }, function (err) { failPage(body, FP.tools.reseller_usage.label, err); });
  });

  /* ================= Reseller templates ================= */
  var T = {page: null, list: [], resellers: []};
  function cleanTemplate(x) {
    if (!x || !TPL_RE.test(str(x.name, 70))) { return null; }
    var l = x.limits && typeof x.limits === 'object' ? x.limits : {};
    var p = x.privileges && typeof x.privileges === 'object' ? x.privileges : {};
    var out = {name: x.name, limits: {}, privileges: {}};
    LIMITS.forEach(function (f) { out.limits[f[0]] = whole(l[f[0]]); });
    PRIVS.forEach(function (f) { out.privileges[f[0]] = p[f[0]] === true; });
    return out;
  }
  function tplSummary(x) {
    var parts = LIMITS.map(function (f) { return t(f[1]) + ': ' + limitText(x.limits[f[0]], f[0] !== 'max_accounts'); });
    var on = PRIVS.filter(function (f) { return x.privileges[f[0]]; }).map(function (f) { return t(f[1]); });
    parts.push(on.length ? on.join(', ') : t('rac_priv_none'));
    return parts.join(' · ');
  }
  function tplSaveCard() {
    var name = el('input', {class: 'sig-input', id: 'fp-rac-tname', name: 'name', type: 'text', maxlength: '64', autocomplete: 'off', spellcheck: 'false'});
    var fields = LIMITS.map(function (f) {
      var id = 'fp-rac-' + f[0];
      return M.field(id, t(f[1]), el('input', {class: 'sig-input', id: id, name: f[0], type: 'number', inputmode: 'numeric', min: '0', step: '1'}), t('rac_limit_hint'));
    });
    var boxes = PRIVS.map(function (f) {
      var id = 'fp-rac-' + f[0];
      return el('label', {class: 'fp-check', for: id}, [el('input', {type: 'checkbox', id: id, name: f[0]}), el('span', {text: t(f[1])})]);
    });
    var form = el('form', {class: 'fp-form fp-mail-form fp-rac-tform', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-rac-tname', t('rac_tpl_name'), name, t('rac_tpl_name_hint'))].concat(fields,
      [el('fieldset', {class: 'fp-fieldset'}, [el('legend', {text: t('rac_privileges')})].concat(boxes)),
        el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('rac_tpl_save')})])]));
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var n = name.value.trim();
      if (!TPL_RE.test(n)) { M.fieldError(form, name, t('rac_tpl_name_hint')); return; }
      var body = {name: n, limits: {}, privileges: {}};
      for (var i = 0; i < LIMITS.length; i++) {
        var f = form.querySelector('[name="' + LIMITS[i][0] + '"]');
        var v = f.value.trim();
        if (v === '') { body.limits[LIMITS[i][0]] = null; continue; }
        if (!/^[0-9]{1,12}$/.test(v)) { M.fieldError(form, f, t('rac_limit_hint')); return; }
        body.limits[LIMITS[i][0]] = Number(v);
      }
      PRIVS.forEach(function (p) { body.privileges[p[0]] = form.querySelector('[name="' + p[0] + '"]').checked; });
      var page = T.page;
      UI.setBusy(b, true);
      FP.call('put', 'resellerTemplates', body).then(function () {
        if (T.page !== page) { return; }
        tplLoad(t('rac_tpl_saved', {name: n}));
      }, function (err) {
        if (T.page !== page) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return M.card('fp-rac-tsave-h', t('rac_tpl_save_title'), [el('p', {class: 'fp-muted', text: t('rac_tpl_save_what')}), form], 'fp-rac-tsave');
  }
  function tplListCard(say) {
    var parts = [M.errorLine(), M.statusLine()];
    if (!T.list.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('rac_tpl_none')}));
    } else {
      parts.push(el('ul', {class: 'fp-rac-tlist', 'aria-label': t('rac_tpl_list_title')}, T.list.map(function (x) {
        return el('li', {class: 'fp-rac-trow', 'data-fp-template': x.name}, [el('div', {class: 'fp-rac-tname', text: x.name}),
          el('div', {class: 'fp-muted fp-row-note', text: tplSummary(x)}),
          el('div', {class: 'fp-actions fp-rac-tact'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'tpl-del',
            'data-fp-name': x.name, 'aria-label': t('rac_tpl_del_named', {name: x.name}), text: t('rac_tpl_del')})])]);
      })));
    }
    var card = M.card('fp-rac-tlist-h', t('rac_tpl_list_title'), parts, 'fp-rac-tlistcard');
    if (say) { M.say(card, say); }
    card.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('button[data-fp-act]') : null;
      if (!b) { return; }
      var act = b.getAttribute('data-fp-act');
      var row = b.closest('li');
      if (act === 'tpl-del') {
        M.confirmIn(row.querySelector('.fp-rac-tact'), t('rac_tpl_del_ask', {name: b.getAttribute('data-fp-name')}), 'tpl-del-yes', t('rac_tpl_del_yes'));
        row.querySelector('[data-fp-act="tpl-del-yes"]').setAttribute('data-fp-name', b.getAttribute('data-fp-name'));
      } else if (act === 'confirm-no') {
        tplLoad('');
      } else if (act === 'tpl-del-yes') {
        var page = T.page;
        UI.setBusy(b, true);
        FP.call('del', 'resellerTemplateDelete', undefined, {tname: b.getAttribute('data-fp-name')}).then(function () {
          if (T.page === page) { tplLoad(t('rac_tpl_deleted')); }
        }, function (err) {
          if (T.page !== page) { return; }
          UI.setBusy(b, false);
          UI.showError(card, err.message);
        });
      }
    });
    return card;
  }
  function tplApplyCard() {
    var who = el('select', {class: 'sig-select', id: 'fp-rac-who', name: 'reseller'}, [el('option', {value: '', text: t('rac_pick_reseller')})]
      .concat(T.resellers.map(function (n) { return el('option', {value: n, text: n}); })));
    var tpl = el('select', {class: 'sig-select', id: 'fp-rac-tpl', name: 'template'}, [el('option', {value: '', text: t('rac_tpl_reset_plain')})]
      .concat(T.list.map(function (x) { return el('option', {value: x.name, text: x.name}); })));
    var apply = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('rac_apply')});
    var reset = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'reset', text: t('rac_reset')});
    var ask = el('div', {class: 'fp-rac-ask'});
    var form = el('form', {class: 'fp-form fp-mail-form fp-rac-aform', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-rac-who', t('rac_reseller'), who), M.field('fp-rac-tpl', t('rac_tpl_pick'), tpl, t('rac_tpl_pick_hint')),
      el('div', {class: 'fp-actions'}, [apply, reset]), ask]);
    function send(b, path, body) {
      var page = T.page;
      UI.setBusy(b, true);
      FP.call('post', path, body, who.value).then(function () {
        if (T.page !== page) { return; }
        UI.setBusy(b, false);
        M.say(form, t(path === 'resellerReset' ? 'rac_reset_done' : 'rac_applied', {name: who.value}));
        who.focus();
      }, function (err) {
        if (T.page !== page) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    }
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      ask.textContent = '';
      var b = M.start(form);
      if (!b) { return; }
      if (!who.value) { M.fieldError(form, who, t('rac_need_reseller')); return; }
      if (!tpl.value) { M.fieldError(form, tpl, t('rac_need_template')); return; }
      send(b, 'resellerTemplateApply', {name: tpl.value});
    });
    form.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('button[data-fp-act]') : null;
      if (!b) { return; }
      var act = b.getAttribute('data-fp-act');
      if (act === 'reset') {
        M.start(form);
        if (!who.value) { M.fieldError(form, who, t('rac_need_reseller')); return; }
        M.confirmIn(ask, t(tpl.value ? 'rac_reset_ask_tpl' : 'rac_reset_ask', {name: who.value, tpl: tpl.value}), 'reset-yes', t('rac_reset_yes'));
      } else if (act === 'reset-yes') {
        ask.textContent = '';
        send(reset, 'resellerReset', tpl.value ? {template: tpl.value} : {});
      } else if (act === 'confirm-no') {
        ask.textContent = '';
        reset.focus();
      }
    });
    return M.card('fp-rac-apply-h', t('rac_apply_title'), [el('p', {class: 'fp-muted', text: t('rac_apply_what')}), form], 'fp-rac-apply');
  }
  function tplDraw(say) {
    var page = T.page;
    page.textContent = '';
    page.appendChild(tplListCard(say));
    page.appendChild(tplSaveCard());
    page.appendChild(tplApplyCard());
  }
  function tplLoad(say) {
    var page = T.page;
    return Promise.all([FP.call('get', 'resellerTemplates'), FP.call('get', 'resellers').catch(function () { return null; })]).then(function (r) {
      if (T.page !== page) { return; }
      T.list = (r[0] && Array.isArray(r[0].templates) ? r[0].templates : []).map(cleanTemplate).filter(Boolean);
      T.resellers = (r[1] && Array.isArray(r[1].resellers) ? r[1].resellers : []).map(function (x) { return str(x && x.username, 20); })
        .filter(function (n) { return USER_RE.test(n); }).sort();
      tplDraw(say);
      if (say) { page.querySelector('#fp-rac-tlist-h').focus(); }
    }, function (err) { if (T.page === page) { failPage(page, FP.tools.reseller_templates.label, err); } });
  }
  FP.view('tool:reseller_templates', function () {
    T = {page: null, list: [], resellers: []};
    var body = frame('reseller_templates', true);
    if (!body) { return; }
    T.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    tplLoad('');
  });

  /* ================= All domains ================= */
  var D = {page: null};
  function cleanDomain(d) {
    if (!d || !DOMAIN_RE.test(str(d.name, 260)) || !USER_RE.test(str(d.account, 20))) { return null; }
    return {name: d.name, kind: /^[a-z]{1,20}$/.test(str(d.kind, 30)) ? d.kind : '', account: d.account, owner: USER_RE.test(str(d.owner, 20)) ? d.owner : '',
      created: stamp(d.created_at), verified: d.verified === true};
  }
  function kindText(k) { return KINDS.indexOf(k) > 0 ? t('rac_kind_' + k) : k; }
  function domLoad(kind, form) {
    var page = D.page;
    var out = page.querySelector('.fp-rac-dout');
    var b = form.querySelector('.fp-submit');
    UI.setBusy(b, true);
    (kind ? FP.call('get', 'serverDomainsKind', undefined, {kind: kind}) : FP.call('get', 'serverDomains')).then(function (r) {
      if (D.page !== page) { return; }
      UI.setBusy(b, false);
      var list = (r && Array.isArray(r.domains) ? r.domains : []).map(cleanDomain).filter(Boolean);
      out.textContent = '';
      var parts = [el('p', {class: 'fp-muted', role: 'status', 'data-fp-summary': '', text: t(list.length === 1 ? 'rac_dom_one' : 'rac_dom_n', {n: count(list.length)})})];
      if (list.length) {
        var heads = [t('rac_domain'), t('rac_kind'), t('rac_account')].concat(isAdmin() ? [t('rac_owner')] : [], [t('rac_proven'), t('rac_added')]);
        parts.push(table(t('rac_dom_table'), heads, list.map(function (d) {
          return el('tr', {'data-fp-domain': d.name}, [el('th', {scope: 'row', class: 'sig-mono fp-rac-name', text: d.name}), el('td', {text: kindText(d.kind)}),
            el('td', {class: 'sig-mono', text: d.account})].concat(isAdmin() ? [el('td', {class: 'sig-mono', text: d.owner})] : [],
            [el('td', null, [d.verified ? pill('ok', t('rac_yes')) : pill('warn', t('rac_pending'))]), el('td', {text: d.created})]));
        })));
      }
      out.appendChild(M.card('fp-rac-dres-h', t('rac_dom_title'), parts, 'fp-rac-dres'));
    }, function (err) {
      if (D.page !== page) { return; }
      UI.setBusy(b, false);
      M.failed(form, err);
    });
  }
  FP.view('tool:all_domains', function () {
    D = {page: null};
    var body = frame('all_domains', false);
    if (!body) { return; }
    D.page = body;
    var kind = el('select', {class: 'sig-select', id: 'fp-rac-kind', name: 'kind'}, KINDS.map(function (k) { return el('option', {value: k, text: k ? t('rac_kind_' + k) : t('rac_kind_all')}); }));
    var form = el('form', {class: 'fp-form fp-mail-form', novalidate: ''}, [M.errorLine(), M.statusLine(), M.field('fp-rac-kind', t('rac_kind'), kind),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('rac_show')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!M.start(form)) { return; }
      domLoad(kind.value, form);
    });
    body.appendChild(M.card('fp-rac-dform-h', t('rac_dom_filter'), [form], 'fp-rac-dform'));
    body.appendChild(el('div', {class: 'fp-rac-dout'}, [el('p', {class: 'fp-muted', text: t('loading')})]));
    domLoad('', form);
  });

  /* ================= Account activity ================= */
  var A = {page: null};
  function cleanActivity(a) {
    if (!a || !USER_RE.test(str(a.username, 20))) { return null; }
    return {username: a.username, domain: DOMAIN_RE.test(str(a.domain, 260)) ? a.domain : '', owner: USER_RE.test(str(a.owner, 20)) ? a.owner : '',
      suspended: a.status === 'suspended', last: stamp(a.last_signin)};
  }
  function actTable(label, list) {
    if (!list.length) { return el('p', {class: 'fp-muted', text: t('rac_act_empty')}); }
    var heads = [t('rac_account'), t('rac_domain')].concat(isAdmin() ? [t('rac_owner')] : [], [t('rac_last_signin')]);
    return table(label, heads, list.map(function (a) {
      return el('tr', {'data-fp-account': a.username}, [el('th', {scope: 'row'}, [el('span', {class: 'sig-mono', text: a.username}), a.suspended ? pill('warn', t('rac_suspended')) : null]),
        el('td', {class: 'sig-mono fp-rac-name', text: a.domain})].concat(isAdmin() ? [el('td', {class: 'sig-mono', text: a.owner})] : [],
        [el('td', {text: a.last || t('rac_never')})]));
    }));
  }
  function actLoad(days, form, focus) {
    var page = A.page;
    var out = page.querySelector('.fp-rac-aout');
    var b = form.querySelector('.fp-submit');
    UI.setBusy(b, true);
    FP.call('get', 'accountsActivity', undefined, {days: String(days)}).then(function (r) {
      if (A.page !== page) { return; }
      UI.setBusy(b, false);
      var on = (r && Array.isArray(r.active) ? r.active : []).map(cleanActivity).filter(Boolean);
      var off = (r && Array.isArray(r.inactive) ? r.inactive : []).map(cleanActivity).filter(Boolean);
      out.textContent = '';
      out.appendChild(M.card('fp-rac-on-h', t('rac_act_on', {n: count(on.length), days: count(days)}), [actTable(t('rac_act_on_label'), on)], 'fp-rac-on'));
      out.appendChild(M.card('fp-rac-off-h', t('rac_act_off', {n: count(off.length), days: count(days)}), [actTable(t('rac_act_off_label'), off)], 'fp-rac-off'));
      if (focus) { out.querySelector('#fp-rac-on-h').focus(); }
    }, function (err) {
      if (A.page !== page) { return; }
      UI.setBusy(b, false);
      M.failed(form, err);
    });
  }
  FP.view('tool:account_activity', function () {
    A = {page: null};
    var body = frame('account_activity', false);
    if (!body) { return; }
    A.page = body;
    var days = el('input', {class: 'sig-input fp-rac-days', id: 'fp-rac-days', name: 'days', type: 'number', inputmode: 'numeric', min: '1', max: '3650', step: '1', value: '30'});
    var form = el('form', {class: 'fp-form fp-mail-form', novalidate: ''}, [M.errorLine(), M.statusLine(), M.field('fp-rac-days', t('rac_days'), days, t('rac_days_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('rac_show')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!M.start(form)) { return; }
      var v = days.value.trim();
      if (!/^[0-9]{1,4}$/.test(v) || Number(v) < 1 || Number(v) > 3650) { M.fieldError(form, days, t('rac_days_hint')); return; }
      actLoad(Number(v), form, true);
    });
    body.appendChild(M.card('fp-rac-aform-h', t('rac_act_form'), [form], 'fp-rac-aform'));
    body.appendChild(el('div', {class: 'fp-rac-aout'}, [el('p', {class: 'fp-muted', text: t('loading')})]));
    actLoad(30, form, false);
  });

  /* ================= Session policy ================= */
  var S = {page: null};
  function cleanPolicy(r) {
    r = r && typeof r === 'object' ? r : {};
    return {age: whole(r.password_max_age_days) || 0, bind: r.bind_sessions_to_ip === true};
  }
  function policyCard(p, say) {
    var age = el('input', {class: 'sig-input fp-rac-days', id: 'fp-rac-age', name: 'password_max_age_days', type: 'number', inputmode: 'numeric', min: '0', max: '3650', step: '1', value: String(p.age)});
    var bind = el('input', {type: 'checkbox', id: 'fp-rac-bind', name: 'bind_sessions_to_ip', 'aria-describedby': 'fp-rac-bind-hint'});
    bind.checked = p.bind;
    var form = el('form', {class: 'fp-form fp-mail-form fp-rac-pform', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-rac-age', t('rac_age'), age, t('rac_age_hint')),
      el('div', {class: 'sig-field'}, [el('label', {class: 'fp-check', for: 'fp-rac-bind'}, [bind, el('span', {text: t('rac_bind')})]),
        el('span', {class: 'sig-hint', id: 'fp-rac-bind-hint', text: t('rac_bind_hint')})]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('rac_policy_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var v = age.value.trim();
      if (!/^[0-9]{1,4}$/.test(v) || Number(v) > 3650) { M.fieldError(form, age, t('rac_age_hint')); return; }
      var page = S.page;
      UI.setBusy(b, true);
      FP.call('put', 'sessionPolicy', {password_max_age_days: Number(v), bind_sessions_to_ip: bind.checked}).then(function (r) {
        if (S.page !== page) { return; }
        var card = policyCard(cleanPolicy(r), t('rac_policy_saved'));
        page.querySelector('.fp-rac-policy').replaceWith(card);
        card.querySelector('#fp-rac-age').focus();
      }, function (err) {
        if (S.page !== page) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    var card = M.card('fp-rac-policy-h', t('rac_policy_title'), [el('p', {class: 'fp-muted', text: t('rac_policy_what')}), form], 'fp-rac-policy');
    if (say) { M.say(form, say); }
    return card;
  }
  FP.view('tool:session_policy', function () {
    S = {page: null};
    var body = frame('session_policy', true);
    if (!body) { return; }
    S.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'sessionPolicy').then(function (r) {
      if (S.page !== body) { return; }
      body.textContent = '';
      body.appendChild(policyCard(cleanPolicy(r), ''));
    }, function (err) { if (S.page === body) { failPage(body, FP.tools.session_policy.label, err); } });
  });
})();

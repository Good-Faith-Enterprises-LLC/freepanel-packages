/* freePanel temporary support access (#/tool/support_access), the admin panel's page for letting an outside support
   person into the server panel for a few hours (docs/api.md, "Temporary support access"). It is off until turned on;
   turning it on asks how long (1 to 72 hours), who it is for, optionally the addresses it may be used from, and the
   admin's own password, and shows the access key once. The grants are listed with when each ends and when it was last
   used; "End support access" ends them at once. What the server sends is drawn as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var S = null;
  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    return {enabled: r.enabled === true, max: typeof r.max_hours === 'number' && r.max_hours > 0 ? Math.floor(r.max_hours) : 72,
      token: typeof r.token === 'string' && /^fpt_[A-Za-z0-9_-]{20,80}$/.test(r.token) ? r.token : '',
      grants: (Array.isArray(r.grants) ? r.grants : []).filter(function (g) { return g && typeof g === 'object'; }).slice(0, 50).map(function (g) {
        return {note: str(g.note, 200), full: g.scope === 'full', live: g.live === true, ends: str(g.expires_at, 40), last: str(g.last_used_at, 40), lastIP: str(g.last_used_ip, 45),
          addresses: (Array.isArray(g.addresses) ? g.addresses : []).filter(function (a) { return typeof a === 'string'; }).map(function (a) { return a.slice(0, 50); })};
      })};
  }
  function when(s) {
    var d = new Date(s);
    return s && !isNaN(d.getTime()) ? d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }

  function grantsCard() {
    var d = S.data;
    var parts = [M.errorLine(), M.statusLine(),
      el('p', {class: 'sig-banner fp-sa-state', role: 'note', 'data-fp-state': d.enabled ? 'on' : 'off', text: t(d.enabled ? 'sa_on' : 'sa_off')})];
    if (d.grants.length) {
      parts.push(el('ul', {class: 'fp-sa-list'}, d.grants.map(function (g) {
        var bits = [t(g.full ? 'sa_scope_full' : 'sa_scope_read'), t(g.live ? 'sa_ends' : 'sa_ended', {when: when(g.ends)}), g.last ? t('sa_last', {when: when(g.last), ip: g.lastIP || '—'}) : t('sa_never')];
        if (g.addresses.length) { bits.push(t('sa_from', {list: g.addresses.join(', ')})); }
        return el('li', {'data-fp-grant': g.live ? 'live' : 'ended'}, [el('strong', {text: g.note || '—'}), el('span', {class: 'fp-muted fp-row-note', text: bits.join(' · ')})]);
      })));
    }
    if (d.grants.length) {
      parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary fp-btn-danger-text', type: 'button', 'data-fp-act': 'sa-end', text: t(d.enabled ? 'sa_end' : 'sa_clear')})]));
    }
    return M.card('fp-sa-h', t('sa_title'), parts, 'fp-sa-grants');
  }
  function grantCard() {
    var hours = el('input', {class: 'sig-input', id: 'fp-sa-hours', name: 'hours', type: 'text', inputmode: 'numeric', maxlength: '2', value: '4', autocomplete: 'off'});
    var note = el('input', {class: 'sig-input', id: 'fp-sa-note', name: 'note', type: 'text', maxlength: '200', autocomplete: 'off'});
    var addrs = el('textarea', {class: 'sig-input sig-mono', id: 'fp-sa-addrs', name: 'addresses', rows: '3', spellcheck: 'false', autocapitalize: 'none'});
    var full = el('input', {type: 'checkbox', id: 'fp-sa-full', name: 'scope', 'aria-describedby': 'fp-sa-full-hint'});
    var pass = el('input', {class: 'sig-input', id: 'fp-sa-pass', name: 'current_password', type: 'password', autocomplete: 'current-password'});
    var form = el('form', {class: 'fp-form fp-mail-form fp-sa-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-sa-hours', t('sa_hours'), hours, t('sa_hours_hint', {max: S.data.max})),
      M.field('fp-sa-note', t('sa_note'), note, t('sa_note_hint')),
      M.field('fp-sa-addrs', t('sa_addrs'), addrs, t('sa_addrs_hint')),
      el('div', {class: 'sig-field'}, [el('label', {class: 'fp-check', for: 'fp-sa-full'}, [full, el('span', {text: t('sa_full')})]),
        el('span', {class: 'sig-hint', id: 'fp-sa-full-hint', text: t('sa_full_hint')})]),
      M.field('fp-sa-pass', t('sa_pass'), pass, t('sa_pass_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('sa_grant')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var h = hours.value.trim();
      if (!/^[0-9]{1,2}$/.test(h) || Number(h) < 1 || Number(h) > S.data.max) { M.fieldError(form, hours, t('sa_hours_bad', {max: S.data.max})); return; }
      if (!note.value.trim()) { M.fieldError(form, note, t('sa_note_empty')); return; }
      if (!pass.value) { M.fieldError(form, pass, t('sa_pass_empty')); return; }
      var list = addrs.value.split(/[\s,]+/).filter(function (x) { return x; });
      var mine = S;
      UI.setBusy(b, true);
      FP.call('post', 'supportAccess', {hours: Number(h), note: note.value.trim(), scope: full.checked ? 'full' : 'read', addresses: list, current_password: pass.value}).then(function (r) {
        if (S !== mine) { return; }
        pass.value = '';
        mine.data = clean(r);
        draw('#fp-sa-key');
      }, function (err) {
        if (S !== mine) { return; }
        UI.setBusy(b, false);
        pass.value = '';
        M.failed(form, err);
      });
    });
    return M.card('fp-sa-new-h', t('sa_new_title'), [el('p', {class: 'fp-muted', text: t('sa_new_what')}), form], 'fp-sa-new');
  }
  function keyCard(token) {
    var key = el('input', {class: 'sig-input sig-mono', id: 'fp-sa-key', type: 'text', readonly: '', value: token, spellcheck: 'false'});
    return M.card('fp-sa-key-h', t('sa_key_title'), [el('p', {class: 'fp-warn-line', text: t('sa_key_once')}),
      el('div', {class: 'fp-form'}, [M.field('fp-sa-key', t('sa_key'), key, t('sa_key_hint'))])], 'fp-sa-key');
  }
  function draw(focus) {
    var page = S.page;
    page.textContent = '';
    if (S.data.token) { page.appendChild(keyCard(S.data.token)); S.data.token = ''; }
    page.appendChild(grantsCard());
    if (!S.data.enabled) { page.appendChild(grantCard()); }
    var target = focus ? page.querySelector(focus) : null;
    if (target) { target.focus(); }
  }
  function onClick(e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !S || !S.page.contains(b) || b.disabled) { return; }
    var act = b.getAttribute('data-fp-act');
    var card = b.closest('.fp-sa-grants');
    if (act === 'sa-end') {
      M.confirmIn(b.parentNode, t('sa_end_ask'), 'sa-end-yes', t('sa_end_yes'));
    } else if (act === 'confirm-no' && card) {
      draw('[data-fp-act="sa-end"]');
    } else if (act === 'sa-end-yes') {
      var mine = S;
      UI.setBusy(b, true);
      FP.call('del', 'supportAccess').then(function (r) {
        if (S !== mine) { return; }
        mine.data = clean(r);
        draw('#fp-sa-h');
        M.say(S.page.querySelector('.fp-sa-grants'), t('sa_ended_now'));
      }, function (err) {
        if (S !== mine) { return; }
        UI.setBusy(b, false);
        UI.showError(card, err.message);
      });
    }
  }
  document.addEventListener('click', onClick);

  FP.view('tool:support_access', function () {
    S = null;
    var tool = FP.tools.support_access;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('sa_desc'), cls: 'fp-mail fp-sa-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    var mine = S = {page: page, data: null};
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'supportAccess').then(function (r) {
      if (S !== mine) { return; }
      mine.data = clean(r);
      draw();
    }, function (err) {
      if (S !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

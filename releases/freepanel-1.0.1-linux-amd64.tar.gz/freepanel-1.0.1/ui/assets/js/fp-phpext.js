/* freePanel PHP extension pages (docs/api.md, "PHP extensions"): in the admin panel, PHP extensions (#/tool/php_extensions) shows
   what one installed PHP version loads and which extensions the panel can add to it, and installs one (a job it follows to its
   end); in the customer panel the same tool shows, read only, what each PHP version on the server has and what the host could
   add. An extension belongs to a version, and every site on the version has it. What the server sends is cleaned to the shapes
   drawn here and shown as text. Page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var VERSION_RE = /^[0-9]{1,2}\.[0-9]{1,2}$/;
  var NAME_RE = /^[a-z][a-z0-9_]{0,39}$/;
  var LABEL_RE = /^([0-9]{1,2}\.[0-9]{1,2}) ([a-z][a-z0-9_]{0,39})$/;
  var JOB_STATES = ['idle', 'running', 'succeeded', 'failed'];
  var POLL_MS = 3000;
  /* the version the PHP settings page was last on, kept in the browser */
  var STORE_KEY = 'fp.php.version';

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function arr(v) { return Array.isArray(v) ? v : []; }
  function php(v) { return t('wc_php', {version: v}); }
  function names(list) {
    return arr(list).filter(function (n) { return typeof n === 'string' && NAME_RE.test(n); }).slice(0, 300);
  }
  function frame(id, desc, cls) {
    var tool = FP.tools[id];
    if (!tool) { FP.views['not-found']({view: 'not-found'}); return null; }
    var g = FP.group(tool.group);
    return FP.frame({title: tool.label, desc: desc, cls: 'fp-mail fp-pxe ' + cls,
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
  }
  function problem(page, err) {
    page.textContent = '';
    page.appendChild(FP.empty(FP.tools.php_extensions.label, err.message));
  }
  /* a list of extension names, as chips in a list */
  function chips(list, label) {
    return el('ul', {class: 'fp-pxe-chips sig-mono', 'aria-label': label}, list.map(function (n) { return el('li', {class: 'sig-chip', text: n}); }));
  }

  /* ================= The admin's page ================= */
  var X = null;

  function cleanExt(r) {
    r = r && typeof r === 'object' ? r : {};
    return {version: VERSION_RE.test(str(r.version)) ? r.version : '', installed: r.installed === true, loaded: names(r.loaded),
      extensions: arr(r.extensions).filter(function (e) { return e && NAME_RE.test(str(e.name)); }).map(function (e) {
        return {name: e.name, title: str(e.title, 80) || e.name, installed: e.installed === true, loaded: e.loaded === true, installable: e.installable === true,
          reason: str(e.reason, 400)};
      })};
  }
  function cleanJob(r) {
    r = r && typeof r === 'object' ? r : {};
    var m = LABEL_RE.exec(str(r.label, 64));
    return {state: JOB_STATES.indexOf(r.state) >= 0 ? r.state : 'idle', version: m ? m[1] : '', name: m ? m[2] : '', ended: str(r.ended, 40),
      code: typeof r.exit_code === 'number' && isFinite(r.exit_code) ? Math.round(r.exit_code) : null, timedOut: r.timed_out === true,
      log: arr(r.log).filter(function (l) { return typeof l === 'string'; }).slice(-200).map(function (l) { return l.slice(0, 400); }), truncated: r.log_truncated === true};
  }
  function running() { return Boolean(X.job && X.job.state === 'running'); }
  function when(iso) { return (FP.bk && FP.bk.when(iso)) || iso; }
  function titleOf(name) {
    var hit = X.data && X.data.extensions.filter(function (e) { return e.name === name; })[0];
    return hit ? hit.title : name;
  }

  function pickCard() {
    var parts = [M.errorLine(), M.statusLine()];
    if (!X.versions.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('pxe_none_installed')}));
      return M.card('fp-pxe-pick-h', t('pxe_pick_title'), parts, 'fp-pxe-pick');
    }
    var pick = el('select', {class: 'sig-select fp-wc-pick', id: 'fp-pxe-version', name: 'version'}, X.versions.map(function (v) {
      return el('option', {value: v, text: php(v)});
    }));
    pick.value = X.version;
    var form = el('form', {class: 'fp-form fp-pxe-form', novalidate: ''}, [M.field('fp-pxe-version', t('pxe_pick'), pick, t('pxe_pick_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('pxe_show')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      UI.setBusy(b, true);
      var mine = X;
      FP.call('get', 'webPhpExt', undefined, {version: pick.value}).then(function (r) {
        if (X !== mine) { return; }
        X.version = pick.value;
        X.data = cleanExt(r);
        UI.store.set(STORE_KEY, X.version);
        render();
        X.page.querySelector('#fp-pxe-list-h').focus();
      }, function (err) {
        UI.setBusy(b, false);
        if (X === mine) { M.failed(form, err); }
      });
    });
    parts.push(form);
    return M.card('fp-pxe-pick-h', t('pxe_pick_title'), parts, 'fp-pxe-pick');
  }
  function statusPill(e) {
    var key = e.installed ? (e.loaded ? 'loaded' : 'installed') : 'missing';
    return el('span', {class: 'sig-pill' + (e.installed && e.loaded ? ' sig-pill--ok' : ''), text: t('pxe_s_' + key)});
  }
  function extRow(e) {
    var v = php(X.data.version);
    var action = null;
    if (!e.installed && e.installable) {
      action = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'install', 'data-fp-ext': e.name, disabled: running() ? true : null,
        'aria-label': t('pxe_install_of', {title: e.title, version: v}), text: t('pxe_install')});
    }
    return el('tr', {'data-fp-ext': e.name}, [
      el('th', {scope: 'row'}, [el('span', {text: e.title}), el('span', {class: 'fp-muted fp-wc-unit sig-mono', text: e.name})]),
      el('td', null, [el('span', {class: 'fp-wc-pills'}, [statusPill(e)]),
        !e.installed && !e.installable && e.reason ? el('span', {class: 'fp-muted fp-row-note fp-wc-reason', 'data-fp-reason': '', text: e.reason}) : null]),
      el('td', {class: 'fp-wc-acts'}, [action])]);
  }
  function listCard() {
    var d = X.data;
    var parts = [M.errorLine(), M.statusLine()];
    if (!d.installed) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('pxe_not_installed', {version: php(d.version)})}));
    } else {
      parts.push(el('p', {class: 'fp-muted', text: t('pxe_list_desc')}));
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-pxe-list-h'}, [
        el('table', {class: 'sig-table fp-wc-table'}, [el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('pxe_col_ext')}),
          el('th', {scope: 'col', text: t('pxe_col_status')}), el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]),
        el('tbody', null, d.extensions.map(extRow))])]));
    }
    return M.card('fp-pxe-list-h', t('pxe_list_title', {version: php(d.version)}), parts, 'fp-pxe-list');
  }
  function loadedCard() {
    var d = X.data;
    var parts = d.loaded.length ? [el('p', {class: 'fp-muted', text: t('pxe_loaded_desc')}), chips(d.loaded, t('pxe_loaded_title', {version: php(d.version)}))] :
      [el('p', {class: 'fp-muted', 'data-fp-none': 'loaded', text: t('pxe_loaded_none')})];
    return M.card('fp-pxe-loaded-h', t('pxe_loaded_title', {version: php(d.version)}), parts, 'fp-pxe-loaded');
  }
  function render() {
    X.page.textContent = '';
    X.page.appendChild(pickCard());
    var job = jobCard();
    if (job) { X.page.appendChild(job); }
    if (X.data) {
      X.page.appendChild(listCard());
      X.page.appendChild(loadedCard());
    }
  }

  /* ---- an install, followed until it ends ---- */
  function jobCard() {
    var j = X.job;
    if (!j || j.state === 'idle') { return null; }
    var what = j.name ? t('pxe_job_what', {title: j.name, version: php(j.version)}) : t('pxe_job_an_ext');
    var parts = [];
    if (j.state === 'running') {
      parts.push(el('p', {class: 'fp-wc-now', 'data-fp-job-state': 'running', text: t('pxe_job_running', {what: what})}));
      parts.push(el('p', {class: 'fp-muted', text: t('pxe_job_running_hint')}));
    } else if (j.state === 'succeeded') {
      parts.push(el('p', {class: 'fp-wc-now', 'data-fp-job-state': 'succeeded', text: t('pxe_job_done', {what: what})}));
      parts.push(el('p', {class: 'fp-muted', text: t('pxe_job_done_hint') + (j.ended ? ' ' + t('wc_job_ended', {when: when(j.ended)}) : '')}));
    } else {
      var why = j.timedOut ? t('wc_job_timed_out') : (j.code === null ? t('wc_job_cut_off') : t('wc_job_code', {code: String(j.code)}));
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-job-state': 'failed'}, [UI.icon(FP.ui, 'ui_warning'),
        el('span', {text: t('pxe_job_failed', {what: what}) + ' ' + why})]));
      if (j.ended) { parts.push(el('p', {class: 'fp-muted', text: t('wc_job_ended', {when: when(j.ended)})})); }
    }
    if (j.log.length) {
      parts.push(el('pre', {class: 'fp-wc-log sig-mono', tabindex: '0', 'data-fp-job-log': '', 'aria-label': t('wc_job_log'), text: j.log.join('\n')}));
      if (j.truncated) { parts.push(el('p', {class: 'fp-muted', text: t('wc_job_truncated')})); }
    }
    return M.card('fp-pxe-job-h', t('pxe_job_title'), parts, 'fp-pxe-job');
  }
  function drawJob() {
    var old = X.page.querySelector('.fp-pxe-job');
    var fresh = jobCard();
    var active = document.activeElement;
    var inLog = Boolean(old && active && active.hasAttribute && active.hasAttribute('data-fp-job-log') && old.contains(active));
    if (!fresh) { if (old) { old.remove(); } return; }
    if (old) { old.replaceWith(fresh); } else { X.page.insertBefore(fresh, X.page.querySelector('.fp-pxe-list')); }
    var log = fresh.querySelector('[data-fp-job-log]');
    if (log && running()) { log.scrollTop = log.scrollHeight; }
    if (inLog && log) { log.focus(); }
  }
  function follow() {
    window.clearTimeout(X.timer);
    var mine = X;
    X.timer = window.setTimeout(function () {
      if (X !== mine || !document.body.contains(mine.page)) { return; }
      FP.call('get', 'webPhpExtJob').then(function (r) {
        if (X !== mine) { return; }
        X.job = cleanJob(r);
        if (running()) { drawJob(); follow(); return; }
        ended(mine);
      }, function () { if (X === mine) { follow(); } });
    }, POLL_MS);
  }
  /* the install has ended: the version's extensions are read again, since the new one is there now, and the page says how it ended */
  function ended(mine) {
    var j = X.job;
    var what = j.name ? t('pxe_job_what', {title: titleOf(j.name), version: php(j.version)}) : t('pxe_job_an_ext');
    var done = function () {
      if (X !== mine) { return; }
      render();
      UI.announce(t(j.state === 'succeeded' ? 'pxe_job_done' : 'pxe_job_failed', {what: what}));
    };
    if (!X.version) { done(); return; }
    FP.call('get', 'webPhpExt', undefined, {version: X.version}).then(function (r) {
      if (X !== mine) { return; }
      X.data = cleanExt(r);
      done();
    }, done);
  }
  function install(b) {
    var name = b.getAttribute('data-fp-ext');
    var card = X.page.querySelector('.fp-pxe-list');
    UI.showError(card, '');
    M.say(card, '');
    var mine = X;
    var title = titleOf(name);
    UI.setBusy(b, true);
    FP.call('post', 'webPhpExtInstall', undefined, {version: X.version, name: name}).then(function (r) {
      if (X !== mine) { return; }
      X.job = cleanJob(r);
      render();
      M.say(X.page.querySelector('.fp-pxe-list'), t('pxe_started', {title: title, version: php(X.version)}));
      var h = X.page.querySelector('#fp-pxe-job-h');
      if (h) { h.focus(); }
      if (running()) { follow(); }
    }, function (err) {
      if (X !== mine) { return; }
      UI.setBusy(b, false);
      UI.showError(card, err.message);
      b.focus();
    });
  }
  function onClick(e) {
    var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !X || !X.page.contains(b)) { return; }
    if (b.getAttribute('data-fp-act') === 'install') { install(b); }
  }
  function adminView() {
    if (X) { window.clearTimeout(X.timer); }
    X = null;
    if (FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var page = frame('php_extensions', t('pxe_desc'), 'fp-pxe-admin');
    if (!page) { return; }
    var mine = X = {page: page, versions: [], version: '', data: null, job: null, timer: 0};
    page.addEventListener('click', onClick);
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'webPhp').then(function (r) {
      if (X !== mine) { return; }
      var all = arr(r && r.versions).filter(function (v) { return v && VERSION_RE.test(str(v.version)) && v.installed === true; }).map(function (v) { return v.version; });
      mine.versions = all;
      var stored = UI.store.get(STORE_KEY);
      var def = r && VERSION_RE.test(str(r.default)) ? r.default : '';
      mine.version = all.indexOf(stored) >= 0 ? stored : (all.indexOf(def) >= 0 ? def : (all[0] || ''));
      if (!mine.version) { return null; }
      return FP.call('get', 'webPhpExt', undefined, {version: mine.version}).then(cleanExt);
    }).then(function (data) {
      if (X !== mine) { return; }
      mine.data = data || null;
      /* the latest install, if there is one: a server that cannot say leaves the page without it */
      return FP.call('get', 'webPhpExtJob').then(cleanJob, function () { return null; });
    }).then(function (job) {
      if (X !== mine || job === undefined) { return; }
      mine.job = job;
      render();
      if (running()) { follow(); }
    }, function (err) {
      if (X === mine) { problem(page, err); }
    });
  }

  /* ================= The customer's page ================= */
  function cleanCustomer(r) {
    return arr(r && r.versions).filter(function (v) { return v && VERSION_RE.test(str(v.version)); }).map(function (v) {
      return {version: v.version, def: v.default === true, used: v.used === true, loaded: names(v.loaded),
        missing: arr(v.missing).filter(function (m) { return m && NAME_RE.test(str(m.name)); }).slice(0, 50).map(function (m) { return {name: m.name, title: str(m.title, 80) || m.name}; })};
    });
  }
  function versionCard(v) {
    var pills = [];
    if (v.def) { pills.push(el('span', {class: 'sig-pill', text: t('pxc_new_sites')})); }
    if (v.used) { pills.push(el('span', {class: 'sig-pill sig-pill--ok', text: t('pxc_used')})); }
    var id = 'fp-pxc-' + v.version.replace('.', '-');
    var parts = [pills.length ? el('span', {class: 'fp-wc-pills', 'data-fp-pills': ''}, pills) : null,
      el('h3', {class: 'fp-h3', text: t('pxc_has_title')}),
      v.loaded.length ? chips(v.loaded, t('pxc_has_title') + ' ' + php(v.version)) : el('p', {class: 'fp-muted', text: t('pxc_has_none')}),
      el('h3', {class: 'fp-h3', text: t('pxc_can_title')}),
      v.missing.length ? el('ul', {class: 'fp-pxc-missing'}, v.missing.map(function (m) {
        return el('li', {'data-fp-missing': m.name}, [el('span', {text: m.title}), ' ', el('span', {class: 'fp-muted sig-mono', text: m.name})]);
      })) : el('p', {class: 'fp-muted', text: t('pxc_can_none')})];
    var card = M.card(id + '-h', php(v.version), parts, 'fp-pxc-card');
    card.setAttribute('data-fp-version', v.version);
    return card;
  }
  function customerView() {
    var page = frame('php_extensions', t('pxc_desc'), 'fp-pxc');
    if (!page) { return; }
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'phpExt', undefined, FP.account()).then(function (r) {
      if (!page.isConnected) { return; }
      var list = cleanCustomer(r);
      page.textContent = '';
      var how = [t('pxc_how')];
      if (FP.tools.php_version) { how.push(' ', el('a', {href: '#/tool/php_version', text: t('pxc_open_versions')})); }
      page.appendChild(el('p', {class: 'fp-muted fp-pxc-how'}, how));
      list.forEach(function (v) { page.appendChild(versionCard(v)); });
      if (!list.length) { page.appendChild(FP.empty(FP.tools.php_extensions.label, t('pxc_none'))); }
    }, function (err) { if (page.isConnected) { problem(page, err); } });
  }

  FP.view('tool:php_extensions', function () {
    if (FP.realm === 'admin') { adminView(); } else { customerView(); }
  });
})();

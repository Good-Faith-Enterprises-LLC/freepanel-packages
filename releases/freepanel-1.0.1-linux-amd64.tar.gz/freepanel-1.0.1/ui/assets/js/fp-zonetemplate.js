/* freePanel zone templates (docs/api.md, "DNS zones", the zone template): the admin panel's page (#/tool/dns_templates) for the records
   every new zone starts with. Until an admin saves one the template is the built-in set; a saved one replaces it whole and applies to
   zones made afterwards, never to a zone that exists. Content may hold {zone}, {ipv4}, {ipv6} and {spf}. Like the customer's record
   editor, every add, change or removal sends the whole list, and going back to the built-in set is one question. Admin only: the server
   refuses these calls to anyone else. Everything the server sends is shown as text. The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var TYPES = ['A', 'AAAA', 'CNAME', 'MX', 'TXT', 'SRV', 'CAA', 'NS'];
  var PRIORITY = {MX: true, SRV: true};
  var PLACEHOLDERS = ['{zone}', '{ipv4}', '{ipv6}', '{spf}'];
  var MIN_TTL = 60;
  var MAX_TTL = 604800;
  var DEFAULT_TTL = 14400;
  var DKIM_NAME = 'default._domainkey';
  var HOST_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var LABEL_RE = /^(\*|_?[a-z0-9]([a-z0-9_-]{0,61}[a-z0-9])?)$/;
  var IP4_RE = /^((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$/;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 4100) : ''; }
  function int(v) { return typeof v === 'number' && isFinite(v) && Math.floor(v) === v ? v : null; }
  /* a record as the server sent it, or null when this page can't show it and send it back unchanged */
  function cleanRecord(r) {
    if (!r || typeof r !== 'object' || TYPES.indexOf(r.type) < 0 || typeof r.name !== 'string' || typeof r.content !== 'string') { return null; }
    var ttl = int(r.ttl);
    var p = r.priority === undefined || r.priority === null ? null : int(r.priority);
    if (ttl === null || (PRIORITY[r.type] ? p === null : (r.priority !== undefined && r.priority !== null))) { return null; }
    return {name: r.name.slice(0, 253), type: r.type, ttl: ttl, priority: p, content: r.content.slice(0, 4000)};
  }
  function clean(v) {
    v = v && typeof v === 'object' ? v : {};
    var raw = Array.isArray(v.records) ? v.records : [];
    var records = raw.map(cleanRecord);
    var d = typeof v.updated === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(v.updated) ? new Date(v.updated) : null;
    return {records: records.filter(Boolean), readable: records.every(Boolean), custom: v.custom === true, updated: d && !isNaN(d.getTime()) ? d : null,
      max: typeof v.max === 'number' && v.max > 0 && isFinite(v.max) ? Math.floor(v.max) : 100,
      placeholders: (Array.isArray(v.placeholders) ? v.placeholders : []).filter(function (p) { return PLACEHOLDERS.indexOf(p) >= 0; }),
      problem: str(v.problem, 400)};
  }
  function wire(r) {
    var o = {name: r.name, type: r.type, ttl: r.ttl, content: r.content};
    if (r.priority !== null) { o.priority = r.priority; }
    return o;
  }
  function ttlText(s) {
    if (s % 86400 === 0) { return t(s === 86400 ? 'dns_ttl_day' : 'dns_ttl_days', {n: s / 86400}); }
    if (s % 3600 === 0) { return t(s === 3600 ? 'dns_ttl_hour' : 'dns_ttl_hours', {n: s / 3600}); }
    if (s % 60 === 0) { return t(s === 60 ? 'dns_ttl_minute' : 'dns_ttl_minutes', {n: s / 60}); }
    return t('dns_ttl_seconds', {n: s});
  }
  function when(d) { return d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'}); }

  var Z = {page: null, T: null, open: -1, busy: false};

  /* ---- reading a record form ---- */
  function bare(c) { return c.replace(/\{(zone|ipv4|ipv6|spf)\}/g, ''); }
  function readRecord(form) {
    var get = function (n) { return form.querySelector('[name="' + n + '"]'); };
    var name = get('name').value.trim().toLowerCase();
    if (name === '') { name = '@'; }
    if (name.slice(-1) === '.') { M.fieldError(form, get('name'), t('zt_name_dot')); return null; }
    if (name === DKIM_NAME) { M.fieldError(form, get('name'), t('zt_name_dkim')); return null; }
    if (name !== '@' && (name.length > 253 || name.split('.').some(function (l, i) { return !LABEL_RE.test(l) || (l === '*' && i > 0); }))) {
      M.fieldError(form, get('name'), t('dns_name_bad')); return null;
    }
    var type = get('type').value;
    var ttlV = get('ttl').value.trim();
    if (!/^[0-9]{1,6}$/.test(ttlV) || Number(ttlV) < MIN_TTL || Number(ttlV) > MAX_TTL) { M.fieldError(form, get('ttl'), t('dns_ttl_bad')); return null; }
    var r = {name: name, type: type, ttl: Number(ttlV), priority: null, content: ''};
    if (PRIORITY[type]) {
      var p = get('priority').value.trim();
      if (!/^[0-9]{1,5}$/.test(p) || Number(p) > 65535) { M.fieldError(form, get('priority'), t('dns_priority_bad')); return null; }
      r.priority = Number(p);
    }
    var c = get('content').value;
    c = type === 'TXT' ? c.replace(/^"(.*)"$/, '$1') : c.trim();
    if (!c) { M.fieldError(form, get('content'), t('dns_content_none')); return null; }
    if (/[{}]/.test(bare(c))) { M.fieldError(form, get('content'), t('zt_braces')); return null; }
    var plain = c.toLowerCase().replace(/\.$/, '');
    if (type === 'A' && c !== '{ipv4}' && !IP4_RE.test(c)) { M.fieldError(form, get('content'), t('zt_bad_a')); return null; }
    if (type === 'AAAA' && c !== '{ipv6}' && (c.indexOf(':') < 0 || !/^[0-9a-fA-F:.]+$/.test(c))) { M.fieldError(form, get('content'), t('zt_bad_aaaa')); return null; }
    if ((type === 'CNAME' || type === 'MX' || type === 'NS') && plain !== '@' && !HOST_RE.test(plain.replace(/\{zone\}/g, 'zone.test'))) {
      M.fieldError(form, get('content'), t('dns_bad_host')); return null;
    }
    if (type === 'TXT' && (c.length > 4000 || /[^\x20-\x7e]/.test(c))) { M.fieldError(form, get('content'), t('dns_bad_txt')); return null; }
    if ((type === 'CNAME' || type === 'NS') && name === '@') { M.fieldError(form, get('name'), t(type === 'CNAME' ? 'dns_cname_apex' : 'dns_ns_apex')); return null; }
    r.content = c;
    return r;
  }

  /* ---- the record form, for adding and for changing one ---- */
  function recordForm(prefix, rec, inline) {
    var name = el('input', {class: 'sig-input', id: prefix + '-name', name: 'name', type: 'text', autocomplete: 'off', spellcheck: 'false',
      autocapitalize: 'none', maxlength: '253', value: rec ? rec.name : '', placeholder: '@', 'aria-describedby': prefix + '-name-hint'});
    var type = el('select', {class: 'sig-select', id: prefix + '-type', name: 'type'}, TYPES.map(function (x) { return el('option', {value: x, text: x}); }));
    type.value = rec ? rec.type : 'A';
    var ttl = el('input', {class: 'sig-input fp-dns-num', id: prefix + '-ttl', name: 'ttl', type: 'number', inputmode: 'numeric', min: String(MIN_TTL),
      max: String(MAX_TTL), step: '1', value: String(rec ? rec.ttl : DEFAULT_TTL)});
    var prio = el('input', {class: 'sig-input fp-dns-num', id: prefix + '-priority', name: 'priority', type: 'number', inputmode: 'numeric', min: '0',
      max: '65535', step: '1', value: rec && rec.priority !== null ? String(rec.priority) : '10'});
    var content = el('input', {class: 'sig-input sig-mono', id: prefix + '-content', name: 'content', type: 'text', autocomplete: 'off', spellcheck: 'false',
      autocapitalize: 'none', maxlength: '4000', value: rec ? rec.content : '', 'aria-describedby': prefix + '-content-hint'});
    var prioField = M.field(prefix + '-priority', t('dns_priority'), prio, t('dns_priority_hint'));
    var contentHint = el('span', {class: 'sig-hint', id: prefix + '-content-hint'});
    var form = el('form', {class: 'fp-form fp-dns-form ' + (inline ? 'fp-mail-inline' : 'fp-mail-form'), novalidate: ''}, [
      inline ? el('h3', {class: 'fp-h3', id: prefix + '-h', text: t('zt_change_title', {name: rec.name, type: rec.type})}) : null,
      M.errorLine(), inline ? null : M.statusLine(),
      M.field(prefix + '-name', t('dns_name'), name, t('zt_name_hint')),
      el('div', {class: 'fp-mail-pair'}, [M.field(prefix + '-type', t('dns_type'), type), M.field(prefix + '-ttl', t('dns_ttl'), ttl, t('dns_ttl_hint'))]),
      prioField,
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: prefix + '-content', text: t('dns_content')}), content, contentHint]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: inline ? t('dns_save') : t('dns_add')}),
        inline ? el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'zt-close', text: t('cancel')}) : null])]);
    if (inline) { form.setAttribute('aria-labelledby', prefix + '-h'); }
    function sync() {
      prioField.hidden = !PRIORITY[type.value];
      contentHint.textContent = t('zt_hint_' + type.value.toLowerCase());
    }
    type.addEventListener('change', sync);
    sync();
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || Z.busy) { return; }
      var r = readRecord(form);
      if (!r) { return; }
      var list = Z.T.records.slice();
      if (inline) { list[Z.open] = r; } else { list.push(r); }
      if (list.length > Z.T.max) { M.fieldError(form, null, t('zt_too_many', {n: Z.T.max})); return; }
      save(list, b, form, inline ? t('zt_changed', {name: r.name, type: r.type}) : t('zt_added', {name: r.name, type: r.type}), inline);
    });
    return form;
  }

  /* the server's "record N: …" in the words of the record it is about */
  function errorText(err, list) {
    var m = /^record (\d+): (.*)$/.exec(err.message || '');
    var r = m ? list[Number(m[1]) - 1] : null;
    return r ? t('zt_record_error', {name: r.name, type: r.type, message: m[2]}) : err.message;
  }
  /* saves the whole list; focus goes back to where the change started */
  function save(list, b, form, done, inline) {
    Z.busy = true;
    UI.setBusy(b, true);
    FP.call('put', 'dnsTemplate', {records: list.map(wire)}).then(function (r) {
      Z.busy = false;
      Z.T = clean(r);
      Z.open = -1;
      render();
      if (inline) {
        M.say(Z.page.querySelector('.fp-zt-list-card'), done);
        Z.page.querySelector('#fp-zt-list-h').focus();
      } else {
        M.say(Z.page.querySelector('.fp-zt-add'), done);
        Z.page.querySelector('#fp-zt-new-name').focus();
      }
    }, function (err) {
      Z.busy = false;
      UI.setBusy(b, false);
      if (form) { M.fieldError(form, null, errorText(err, list)); return; }
      render();
      UI.showError(Z.page.querySelector('.fp-zt-list-card'), errorText(err, list));
      Z.page.querySelector('#fp-zt-list-h').focus();
    });
  }

  /* ---- the cards ---- */
  function recordRow(r, i) {
    var label = r.name + ' ' + r.type;
    var meta = [ttlText(r.ttl)];
    if (r.priority !== null) { meta.unshift(t('zt_priority_n', {n: r.priority})); }
    return el('li', {class: 'fp-zt-item', 'data-fp-i': String(i)}, [
      el('div', {class: 'fp-zt-head'}, [el('span', {class: 'sig-mono fp-zt-name', text: r.name}), el('span', {class: 'sig-pill fp-zt-type', text: r.type}),
        el('span', {class: 'fp-muted fp-zt-meta', text: meta.join(' · ')})]),
      el('code', {class: 'sig-mono fp-zt-content', text: r.content}),
      el('div', {class: 'fp-zt-acts'}, [
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'zt-open', 'aria-label': t('zt_change_of', {label: label}), text: t('zt_change')}),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'zt-remove', 'aria-label': t('zt_remove_of', {label: label}),
          text: t('zt_remove')})])]);
  }
  function listCard() {
    var T = Z.T;
    var parts = [M.errorLine(), M.statusLine()];
    var source = T.custom ? t('zt_saved') + (T.updated ? ' ' + t('zt_saved_on', {when: when(T.updated)}) : '') : t('zt_builtin');
    parts.push(el('p', {class: 'fp-zt-source', 'data-fp-source': T.custom ? 'saved' : 'builtin'}, [el('span', {class: 'sig-pill' + (T.custom ? ' sig-pill--accent' : ''), text: T.custom ? t('zt_pill_saved') : t('zt_pill_builtin')}),
      ' ', el('span', {text: source})]));
    if (T.problem) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-zt-problem': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('zt_problem', {problem: T.problem})})]));
    }
    if (!T.readable) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-zt-unreadable': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('zt_unreadable')})]));
    }
    if (!T.records.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('zt_empty')}));
    } else {
      parts.push(el('p', {class: 'fp-muted fp-zt-count', 'data-fp-count': '', text: t(T.records.length === 1 ? 'zt_count_1' : 'zt_count', {n: T.records.length, max: T.max})}));
      parts.push(el('ul', {class: 'fp-zt-list', 'aria-labelledby': 'fp-zt-list-h'}, T.records.map(recordRow)));
    }
    if (T.custom) {
      parts.push(el('div', {class: 'fp-actions fp-zt-reset', 'data-fp-zt-reset': ''}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'zt-reset',
        text: t('zt_reset')})]));
    }
    return M.card('fp-zt-list-h', t('zt_title'), parts, 'fp-zt-list-card');
  }
  function infoCard() {
    var known = Z.T.placeholders.length ? Z.T.placeholders : PLACEHOLDERS;
    var facts = known.map(function (p) {
      return el('div', {}, [el('dt', {}, [el('code', {class: 'sig-mono', text: p})]), el('dd', {text: t('zt_ph_' + p.slice(1, -1))})]);
    });
    return M.card('fp-zt-info-h', t('zt_how_title'), [el('p', {class: 'fp-muted', text: t('zt_what')}), el('p', {class: 'fp-muted', text: t('zt_when')}),
      el('p', {class: 'fp-muted', text: t('zt_ph_intro')}), el('dl', {class: 'fp-zt-ph'}, facts), el('p', {class: 'fp-muted', text: t('zt_left_out')})], 'fp-zt-info');
  }
  function addCard() {
    var full = Z.T.records.length >= Z.T.max;
    var body = !Z.T.readable ? el('p', {class: 'fp-muted', text: t('zt_unreadable_add')}) : full ? el('p', {class: 'fp-muted', 'data-fp-zt-full': '', text: t('zt_full', {max: Z.T.max})}) : recordForm('fp-zt-new', null, false);
    return M.card('fp-zt-add-h', t('zt_add_title'), [body], 'fp-zt-add');
  }
  function render() {
    Z.page.textContent = '';
    Z.page.appendChild(infoCard());
    var list = listCard();
    Z.page.appendChild(list);
    if (Z.open >= 0 && Z.T.records[Z.open]) {
      var li = list.querySelector('li[data-fp-i="' + Z.open + '"]');
      var form = recordForm('fp-zt-chg', Z.T.records[Z.open], true);
      li.textContent = '';
      li.classList.add('fp-zt-editing');
      li.appendChild(form);
    }
    Z.page.appendChild(addCard());
  }

  document.addEventListener('click', function (e) {
    var node = e.target.closest ? e.target : null;
    var b = node && node.closest('[data-fp-act]');
    if (!b || !Z.page || !Z.page.contains(b) || !Z.T) { return; }
    var a = b.getAttribute('data-fp-act');
    var li = b.closest('li[data-fp-i]');
    var i = li ? Number(li.getAttribute('data-fp-i')) : -1;
    var mine = Z.page;
    if (a === 'zt-open' && Z.T.readable && Z.T.records[i]) {
      Z.open = i;
      render();
      var f = Z.page.querySelector('#fp-zt-chg-name');
      if (f) { f.focus(); }
    } else if (a === 'zt-close') {
      var was = Z.open;
      Z.open = -1;
      render();
      var back = Z.page.querySelector('li[data-fp-i="' + was + '"] [data-fp-act="zt-open"]');
      if (back) { back.focus(); }
    } else if (a === 'zt-remove' && Z.T.readable && Z.T.records[i]) {
      var r = Z.T.records[i];
      M.confirmIn(li.querySelector('.fp-zt-acts'), t('zt_remove_ask', {name: r.name, type: r.type}), 'zt-remove-yes', t('zt_remove'));
    } else if (a === 'zt-reset') {
      M.confirmIn(b.parentNode, t('zt_reset_ask'), 'zt-reset-yes', t('zt_reset_yes'));
    } else if (a === 'confirm-no') {
      var wasReset = Boolean(b.closest('[data-fp-zt-reset]'));
      Z.open = -1;
      render();
      var target = wasReset ? Z.page.querySelector('[data-fp-act="zt-reset"]') : Z.page.querySelector('li[data-fp-i="' + i + '"] [data-fp-act="zt-remove"]');
      if (target) { target.focus(); }
    } else if (a === 'zt-remove-yes' && Z.T.records[i] && !Z.busy) {
      var list = Z.T.records.slice();
      var gone = list.splice(i, 1)[0];
      save(list, b, null, t('zt_removed', {name: gone.name, type: gone.type}), true);
    } else if (a === 'zt-reset-yes' && !Z.busy) {
      Z.busy = true;
      UI.setBusy(b, true);
      FP.call('del', 'dnsTemplate').then(function (res) {
        Z.busy = false;
        if (Z.page !== mine) { return; }
        Z.T = clean(res);
        Z.open = -1;
        render();
        M.say(Z.page.querySelector('.fp-zt-list-card'), t('zt_reset_done'));
        Z.page.querySelector('#fp-zt-list-h').focus();
      }, function (err) {
        Z.busy = false;
        if (Z.page !== mine) { return; }
        render();
        UI.showError(Z.page.querySelector('.fp-zt-list-card'), err.message);
        Z.page.querySelector('#fp-zt-list-h').focus();
      });
    }
  });

  FP.view('tool:dns_templates', function () {
    var tool = FP.tools.dns_templates;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    Z.T = null;
    Z.open = -1;
    Z.busy = false;
    var body = FP.frame({title: tool.label, desc: t('zt_desc'), cls: 'fp-mail fp-srv fp-zt-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    Z.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'dnsTemplate').then(function (r) {
      if (Z.page !== body) { return; }
      Z.T = clean(r);
      render();
    }, function (err) {
      if (Z.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

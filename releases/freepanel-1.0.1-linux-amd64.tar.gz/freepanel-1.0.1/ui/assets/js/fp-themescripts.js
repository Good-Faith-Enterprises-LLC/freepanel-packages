/* freePanel's Theme scripts page for the admin panel (#/tool/theme_scripts, docs/api.md, "Themes"): the script URLs the site's themes may
   load. A theme loads a script only when its theme.json lists the URL and the admin has enabled it here. The page lists every URL an installed
   theme asks for, with the themes that ask, and any other URL enabled; the admin ticks the ones to enable and may add one. Saving checks the
   active theme again: one that loads a URL taken off stops serving, and the page says so with the file and line. What the server answers is
   cleaned to the shapes drawn and shown as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var el = UI.el;
  var M = FP.mail;
  var t = UI.t;

  var ID_RE = /^[a-z][a-z0-9-]{1,39}$/;
  var S = null;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  function url(v) { return typeof v === 'string' && /^https:\/\/[^\s"'<>]+$/.test(v) && v.length <= 300 ? v : ''; }
  function tid(v) { return typeof v === 'string' && (v === 'default' || ID_RE.test(v)) ? v : ''; }
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var enabled = (Array.isArray(r.scripts) ? r.scripts : []).map(url).filter(Boolean).slice(0, 50);
    var seen = {};
    var rows = [];
    (Array.isArray(r.requested) ? r.requested : []).slice(0, 200).forEach(function (x) {
      var u = x && typeof x === 'object' ? url(x.url) : '';
      if (!u || seen[u]) { return; }
      seen[u] = true;
      rows.push({url: u, themes: (Array.isArray(x.themes) ? x.themes : []).map(tid).filter(Boolean).slice(0, 50), on: enabled.indexOf(u) >= 0});
    });
    enabled.forEach(function (u) {
      if (!seen[u]) { seen[u] = true; rows.push({url: u, themes: [], on: true}); }
    });
    var problem = (Array.isArray(r.problem) ? r.problem : []).slice(0, 100).filter(function (p) { return p && typeof p.message === 'string'; }).map(function (p) {
      return {file: str(p.file, 200), line: typeof p.line === 'number' && p.line > 0 ? Math.floor(p.line) : 0, message: str(p.message, 500)};
    });
    return {rows: rows, active: tid(r.active) || 'default', serving: tid(r.serving) || 'default', problem: problem};
  }

  function fallbackNote() {
    if (S.data.active === S.data.serving) { return null; }
    return el('div', {class: 'sig-banner sig-banner--warn fp-thm-fallback', role: 'note', 'data-fp-tsc-fallback': ''}, [UI.icon(FP.ui, 'ui_warning'),
      el('div', {}, [el('p', {text: t('tsc_fallback', {theme: S.data.active})}),
        el('ul', {class: 'fp-thm-problems'}, S.data.problem.map(function (p) {
          var where = p.file ? p.file + (p.line ? ':' + p.line : '') : '';
          return el('li', {}, [where ? el('span', {class: 'sig-mono fp-thm-where', text: where}) : null, where ? ' ' : null, el('span', {text: p.message})]);
        }))])]);
  }

  function card() {
    var opts = S.data.rows.map(function (row, i) {
      var cid = 'fp-tsc-u-' + i;
      var who = row.themes.length ? t('tsc_asked_by', {themes: row.themes.join(', ')}) : t('tsc_asked_by_none');
      return el('label', {class: 'fp-check fp-tsc-opt', for: cid}, [
        el('input', {type: 'checkbox', id: cid, name: 'url', value: row.url, checked: row.on ? true : null}),
        el('span', {class: 'fp-tsc-text'}, [el('span', {class: 'sig-mono fp-tsc-url', text: row.url}), el('span', {class: 'fp-muted fp-tsc-who', text: who})])]);
    });
    var group = el('fieldset', {class: 'fp-tsc-choice'}, [el('legend', {class: 'sig-label', text: t('tsc_list')})].concat(
      opts.length ? opts : [el('p', {class: 'fp-muted', 'data-fp-tsc-none': '', text: t('tsc_none')})]));
    var add = el('input', {class: 'sig-input sig-mono', id: 'fp-tsc-add', name: 'add', type: 'url', inputmode: 'url', autocomplete: 'off', spellcheck: 'false',
      placeholder: 'https://cdn.example.com/widget.js', maxlength: '300'});
    var form = el('form', {class: 'fp-form fp-tsc-form', novalidate: ''}, [group, M.field('fp-tsc-add', t('tsc_add'), add, t('tsc_add_hint')),
      M.errorLine(), M.statusLine(), el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('tsc_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var go = M.start(form);
      if (!go) { return; }
      var boxes = form.querySelectorAll('input[name="url"], input[name^="scripts."]');
      var scripts = [];
      /* each control sent is named after its place in the list, so the server's field (scripts.N) finds it */
      Array.prototype.forEach.call(boxes, function (c) {
        if (c.checked) { c.name = 'scripts.' + scripts.length; scripts.push(c.value); } else { c.name = 'url'; }
      });
      var extra = add.value.trim();
      add.name = 'add';
      if (extra) {
        if (scripts.indexOf(extra) >= 0) { M.fieldError(form, add, t('tsc_add_twice')); return; }
        add.name = 'scripts.' + scripts.length;
        scripts.push(extra);
      }
      var mine = S;
      UI.setBusy(go, true);
      FP.call('put', 'themeScripts', {scripts: scripts}).then(function (r) {
        if (S !== mine) { return; }
        S.data = clean(r);
        draw('#fp-tsc-h', S.data.active !== S.data.serving ? t('tsc_saved_fallback') : t('tsc_saved'));
      }, function (err) {
        if (S !== mine) { return; }
        UI.setBusy(go, false);
        var f = err && err.field ? UI.fieldNamed(form, err.field) : null;
        M.fieldError(form, f, (err && err.message) || t('api_failed'));
      });
    });
    return M.card('fp-tsc-h', t('tsc_title'), [el('p', {class: 'fp-muted', text: t('tsc_intro')}), fallbackNote(), form], 'fp-tsc');
  }

  function draw(focus, said) {
    var page = S.page;
    page.textContent = '';
    page.appendChild(card());
    if (said) { M.say(page, said); }
    var target = focus ? page.querySelector(focus) : null;
    if (target) { target.focus(); }
  }

  FP.view('tool:theme_scripts', function () {
    S = null;
    var tool = FP.tools.theme_scripts;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('tsc_desc'), cls: 'fp-mail fp-tsc-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    if (!page) { return; }
    S = {page: page, data: clean({})};
    var mine = S;
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'themeScripts').then(function (r) {
      if (S !== mine) { return; }
      S.data = clean(r);
      draw('', '');
    }, function (err) {
      if (S !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err && err.message ? err.message : t('tsc_unavailable')));
    });
  });
})();

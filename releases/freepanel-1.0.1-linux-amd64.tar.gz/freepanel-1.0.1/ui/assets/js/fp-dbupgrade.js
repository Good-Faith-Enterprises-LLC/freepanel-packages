/* freePanel database server upgrade (#/tool/db_upgrade), the admin's way to move the local MariaDB server to a newer
   series that the operating system's own package source offers (docs/api.md, "Database servers"). It shows the running
   version and the newer series (GET .../version), and the latest upgrade job with the end of its log (GET .../upgrade).
   Starting one (POST .../upgrade) needs a series picked and a box ticked that says the server stops while it runs; the
   job dumps and checks every database first, and puts the old version and data back if a step fails. The page reads the
   job again every few seconds while it runs. Page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;
  var ID = {id: 'local-mysql'};
  var POLL = 5000;
  var U = null;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 200) : ''; }
  function series(v) { return Array.isArray(v) ? v.filter(function (s) { return typeof s === 'string' && /^\d{1,2}\.\d{1,2}$/.test(s); }).slice(0, 20) : []; }
  function cleanVersion(r) {
    r = r && typeof r === 'object' ? r : {};
    return {running: r.running === true, version: str(r.version, 80), series: str(r.series, 10), source: str(r.source, 40), newer: series(r.newer), error: str(r.error, 300)};
  }
  function cleanJob(j) {
    j = j && typeof j === 'object' ? j : {};
    var states = ['idle', 'running', 'succeeded', 'failed'];
    return {state: states.indexOf(j.state) >= 0 ? j.state : 'idle', label: str(j.label, 64), timedOut: j.timed_out === true,
      log: Array.isArray(j.log) ? j.log.filter(function (x) { return typeof x === 'string'; }).slice(-200) : []};
  }

  function versionCard() {
    var v = U.version;
    var parts = [];
    if (!v.running) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-down': '', text: v.error || t('dbu_down')}));
    } else {
      parts.push(el('dl', {class: 'fp-facts'}, [
        el('div', {'data-fp-fact': 'version'}, [el('dt', {text: t('dbu_running')}), el('dd', {class: 'sig-mono', text: v.version})]),
        el('div', {'data-fp-fact': 'source'}, [el('dt', {text: t('dbu_source')}), el('dd', {text: v.source || t('dbu_source_none')})])]));
      if (v.error) { parts.push(el('p', {class: 'fp-muted', text: v.error})); }
    }
    return M.card('fp-dbu-v-h', t('dbu_version_title'), parts, 'fp-dbu-version');
  }

  function startCard() {
    var v = U.version;
    var parts = [M.errorLine(), M.statusLine()];
    if (!v.running || !v.newer.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': '', text: t(v.running ? 'dbu_none_newer' : 'dbu_down')}));
      return M.card('fp-dbu-s-h', t('dbu_start_title'), parts, 'fp-dbu-start');
    }
    var pick = el('select', {class: 'sig-select', id: 'fp-dbu-series', name: 'series'}, v.newer.map(function (s) {
      return el('option', {value: s, text: 'MariaDB ' + s});
    }));
    pick.value = v.newer[v.newer.length - 1];
    var sure = el('input', {type: 'checkbox', id: 'fp-dbu-sure', name: 'sure'});
    var running = U.job.state === 'running';
    var form = el('form', {class: 'fp-form fp-mail-form fp-dbu-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('ol', {class: 'fp-dbu-steps'}, ['dbu_step_dump', 'dbu_step_copy', 'dbu_step_swap', 'dbu_step_check', 'dbu_step_back'].map(function (k) { return el('li', {text: t(k)}); })),
      M.field('fp-dbu-series', t('dbu_to'), pick, t('dbu_to_hint', {from: v.series})),
      el('label', {class: 'fp-check', for: 'fp-dbu-sure'}, [sure, el('span', {text: t('dbu_sure')})]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--danger fp-submit', type: 'submit', disabled: running ? true : null, text: t('dbu_go')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      if (!sure.checked) { M.fieldError(form, sure, t('dbu_sure_needed')); return; }
      var mine = U;
      UI.setBusy(b, true);
      FP.call('post', 'dbUpgrade', {series: pick.value}, ID).then(function (j) {
        if (U !== mine) { return; }
        mine.job = cleanJob(j);
        draw('#fp-dbu-j-h');
        poll(mine);
      }, function (err) {
        if (U !== mine) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    parts.push(form);
    return M.card('fp-dbu-s-h', t('dbu_start_title'), parts, 'fp-dbu-start');
  }

  function jobCard() {
    var j = U.job;
    if (j.state === 'idle') { return null; }
    var parts = [el('p', {role: 'status', 'data-fp-job': j.state, text: t('dbu_job_' + j.state, {label: j.label}) + (j.timedOut ? ' ' + t('dbu_timed_out') : '')})];
    if (j.log.length) {
      parts.push(el('pre', {class: 'fp-wc-log sig-mono', tabindex: '0', 'data-fp-job-log': '', 'aria-label': t('dbu_log'), text: j.log.join('\n')}));
    }
    return M.card('fp-dbu-j-h', t('dbu_job_title'), parts, 'fp-dbu-job');
  }

  function draw(focus) {
    var page = U.page;
    page.textContent = '';
    page.appendChild(el('p', {class: 'fp-muted', text: t('dbu_lead')}));
    page.appendChild(versionCard());
    var job = jobCard();
    if (job) { page.appendChild(job); }
    page.appendChild(startCard());
    var f = focus ? page.querySelector(focus) : null;
    if (f) { f.focus(); }
  }

  function poll(mine) {
    if (U !== mine || mine.job.state !== 'running' || mine.timer) { return; }
    mine.timer = window.setTimeout(function () {
      mine.timer = 0;
      if (U !== mine || !document.body.contains(mine.page)) { return; }
      FP.call('get', 'dbUpgrade', undefined, ID).then(function (j) {
        if (U !== mine) { return; }
        mine.job = cleanJob(j);
        if (mine.job.state === 'running') { draw(); poll(mine); return; }
        return FP.call('get', 'dbVersion', undefined, ID).then(function (v) {
          if (U !== mine) { return; }
          mine.version = cleanVersion(v);
          draw('#fp-dbu-j-h');
        });
      }, function () { if (U === mine) { poll(mine); } });
    }, POLL);
  }

  FP.view('tool:db_upgrade', function () {
    if (U && U.timer) { window.clearTimeout(U.timer); }
    U = null;
    var tool = FP.tools.db_upgrade;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('dbu_desc'), cls: 'fp-mail fp-dbu-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    var mine = U = {page: page, version: null, job: cleanJob(null), timer: 0};
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all([FP.call('get', 'dbVersion', undefined, ID), FP.call('get', 'dbUpgrade', undefined, ID)]).then(function (r) {
      if (U !== mine) { return; }
      mine.version = cleanVersion(r[0]);
      mine.job = cleanJob(r[1]);
      draw();
      poll(mine);
    }, function (err) {
      if (U !== mine) { return; }
      page.textContent = '';
      UI.showError(page, err.message);
    });
  });
})();

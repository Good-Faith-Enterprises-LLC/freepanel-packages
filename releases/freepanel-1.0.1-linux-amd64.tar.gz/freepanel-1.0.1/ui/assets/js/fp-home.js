/* freePanel home views: the customer's tools home (groups of tiles beside the account card), the admin
   home (every function group beside the server card), one group's page, a tool that has no page yet and not found. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var admin = FP.realm === 'admin';

  function count(n) { return typeof n === 'number' && isFinite(n) ? n.toLocaleString('en') : '\u2014'; }

  function row(label, value, mono) {
    return el('li', {class: 'sig-row'}, [el('span', {class: 'sig-row-label', text: label}),
      el('span', {class: 'sig-row-value' + (mono ? ' sig-mono' : ''), text: value})]);
  }
  function infoCard(title, id) {
    var list = el('ul', {class: 'sig-rows', 'data-fp-rows': id}, [el('li', {class: 'sig-row fp-muted', text: t('loading')})]);
    return el('section', {class: 'sig-card', 'aria-labelledby': 'fp-card-' + id}, [
      el('div', {class: 'sig-card-head'}, [el('h2', {class: 'sig-card-title', id: 'fp-card-' + id, text: title})]), list]);
  }
  function fill(list, rows) {
    list.textContent = '';
    rows.forEach(function (r) { list.appendChild(r); });
  }
  function unavailable(list) { fill(list, [el('li', {class: 'sig-row fp-muted', text: t('summary_unavailable')})]); }

  function str(v) { return typeof v === 'string' && v ? v : '—'; }
  function num(v) { return typeof v === 'number' && isFinite(v) && v >= 0; }

  /* sizes the way hosting panels show them: binary steps named KB, MB, GB, TB */
  var UNITS = ['KB', 'MB', 'GB', 'TB', 'PB'];
  function size(n) {
    if (!num(n)) { return '\u2014'; }
    if (n < 1024) { return t('size_bytes', {n: count(Math.round(n))}); }
    var u = -1;
    do { n /= 1024; u++; } while (n >= 1024 && u < UNITS.length - 1);
    return (n < 10 ? n.toFixed(1) : Math.round(n).toLocaleString('en')) + ' ' + UNITS[u];
  }
  /* one measure against its limit: "used of limit" with a bar, "used (no limit)", or not measured yet (never shown as 0) */
  function meterRow(label, used, limit, fmt) {
    var value;
    var level = '';
    var pct = -1;
    if (!num(used)) {
      value = t('usage_not_measured');
    } else if (!num(limit)) {
      value = t('used_no_limit', {used: fmt(used)});
    } else {
      value = t('of_limit', {used: fmt(used), limit: fmt(limit)});
      pct = limit > 0 ? Math.min(100, used / limit * 100) : 100;
      level = pct >= 95 ? ' is-danger' : pct >= 80 ? ' is-warn' : '';
    }
    var li = el('li', {class: 'sig-row'}, [el('div', {class: 'sig-row-head'}, [el('span', {class: 'sig-row-label', text: label}),
      el('span', {class: 'sig-stat-v' + level + (num(used) ? '' : ' fp-muted'), text: value})])]);
    if (pct >= 0) {
      var bar = el('i');
      bar.style.width = pct.toFixed(1) + '%';
      li.appendChild(el('div', {class: 'sig-meter' + level, 'aria-hidden': 'true'}, [bar]));
    }
    return li;
  }
  function note(text) { return el('li', {class: 'sig-row fp-muted fp-row-note', text: text}); }
  function when(iso) {
    var d = typeof iso === 'string' ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }
  function uptime(sec) {
    if (!num(sec)) { return '\u2014'; }
    var d = Math.floor(sec / 86400);
    var h = Math.floor(sec % 86400 / 3600);
    return d ? t(d === 1 ? 'uptime_day' : 'uptime_days', {d: count(d), h: h}) : t('uptime_hours', {h: h, m: Math.floor(sec % 3600 / 60)});
  }

  /* ---- customer home ---- */
  function groupCard(g, i, closed) {
    var listId = 'fp-grp-' + g.id;
    var open = !closed[g.id];
    var toggle = el('button', {class: 'sig-ghost sig-grp-toggle', type: 'button', 'aria-expanded': String(open), 'aria-controls': listId,
      'aria-label': t('group_toggle', {group: g.label})}, [UI.icon(FP.ui, 'ui_caret_down')]);
    var tiles = el('ul', {class: 'sig-tiles', id: listId});
    tiles.hidden = !open;
    g.tools.forEach(function (tool) { tiles.appendChild(el('li', null, [FP.toolLink(tool, 'sig-tile', true, 'sig-ico--36')])); });
    var card = el('section', {class: 'sig-card sig-grp' + (open ? '' : ' is-closed'), 'aria-labelledby': 'fp-grp-h-' + g.id, 'data-fp-grp': g.id}, [
      el('div', {class: 'sig-card-head'}, [UI.icon(FP.sprite, 'grp_' + g.id, 'sig-ico--24'),
        el('h2', {class: 'sig-grp-title', id: 'fp-grp-h-' + g.id, text: g.label}),
        el('div', {class: 'sig-card-actions'}, [toggle])]),
      tiles]);
    card.style.setProperty('--sig-i', String(i));
    return card;
  }

  /* the account's sites stopped for the monthly bandwidth limit (docs/api.md, Usage), or back for a while */
  function bandwidthNotice(u) {
    var text = '';
    if (u.bandwidth_limited === true) {
      var m = /^(\d{4})-(\d{2})$/.exec(typeof u.month === 'string' ? u.month : '');
      var next = m ? new Date(Date.UTC(Number(m[1]), Number(m[2]), 1)) : null;
      text = t('bw_home_stopped', {date: next ? next.toLocaleDateString('en', {month: 'long', day: 'numeric', timeZone: 'UTC'}) : t('bw_next_month')});
    } else if (typeof u.bandwidth_lifted_until === 'string' && when(u.bandwidth_lifted_until)) {
      text = t('bw_home_lifted', {when: when(u.bandwidth_lifted_until)});
    }
    return text ? el('div', {class: 'sig-banner sig-banner--warn fp-home-notice', role: 'note', 'data-fp-bandwidth': ''},
      [UI.icon(FP.ui, 'ui_warning'), el('span', {text: text})]) : null;
  }

  function userHome() {
    var body = FP.frame({title: t('home_user'), desc: t('home_user_desc_plain')});
    var layout = el('div', {class: 'fp-home'});
    var groups = el('div', {class: 'sig-groups'});
    var closed = {};
    (UI.store.json('fp.home.closed', []) || []).forEach(function (id) { if (typeof id === 'string') { closed[id] = true; } });
    FP.groups.forEach(function (g, i) { groups.appendChild(groupCard(g, i, closed)); });
    if (!FP.groups.length) { groups.appendChild(FP.empty(t('no_tools'), '')); }
    groups.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('.sig-grp-toggle') : null;
      if (!b) { return; }
      var open = b.getAttribute('aria-expanded') !== 'true';
      var card = b.closest('.sig-grp');
      b.setAttribute('aria-expanded', String(open));
      document.getElementById(b.getAttribute('aria-controls')).hidden = !open;
      card.classList.toggle('is-closed', !open);
      if (open) { delete closed[card.getAttribute('data-fp-grp')]; } else { closed[card.getAttribute('data-fp-grp')] = true; }
      UI.store.set('fp.home.closed', JSON.stringify(Object.keys(closed)));
    });
    var account = infoCard(t('account_card'), 'account');
    var usage = infoCard(t('usage_card'), 'usage');
    var info = el('aside', {class: 'sig-info', 'aria-label': t('account_info')}, [account, usage]);
    layout.appendChild(groups);
    layout.appendChild(info);
    body.appendChild(layout);
    if (FP.tour) { FP.tour(body); }

    FP.summary().then(function (acc) {
      if (!document.body.contains(account)) { return; }
      if (typeof acc.domain === 'string' && acc.domain) {
        var desc = document.querySelector('.fp-page .sig-desc');
        if (desc) { desc.textContent = t('home_user_desc', {domain: acc.domain}); }
      }
      fill(account.querySelector('ul'), [row(t('row_username'), str(acc.username), true), row(t('row_domain'), str(acc.domain), true),
        row(t('row_plan'), str(acc.package)), row(t('row_contact'), str(acc.contact_email), true),
        row(t('row_status'), acc.status === 'suspended' ? t('status_suspended') : acc.status === 'creating' ? t('status_creating') : t('status_active'))]);
    }, function () { unavailable(account.querySelector('ul')); });

    FP.call('get', 'usage', undefined, FP.account()).then(function (u) {
      if (!document.body.contains(usage)) { return; }
      var notice = bandwidthNotice(u);
      if (notice) { layout.parentNode.insertBefore(notice, layout); }
      var part = function (k) { return u[k] && typeof u[k] === 'object' ? u[k] : {}; };
      var rows = [meterRow(t('usage_disk'), part('disk_bytes').used, part('disk_bytes').limit, size),
        meterRow(t('usage_bandwidth'), part('bandwidth_bytes').used, part('bandwidth_bytes').limit, size),
        meterRow(t('usage_mailboxes'), part('email_accounts').used, part('email_accounts').limit, count),
        meterRow(t('usage_databases'), part('databases').used, part('databases').limit, count)];
      var at = when(u.disk_measured_at);
      if (at && num(part('disk_bytes').used)) { rows.push(note(t('usage_disk_when', {when: at}))); }
      if (u.disk_partial === true) { rows.push(note(t('usage_disk_partial'))); }
      fill(usage.querySelector('ul'), rows);
    }, function () { unavailable(usage.querySelector('ul')); });
  }

  /* ---- admin home ---- */
  function adminHome() {
    var body = FP.frame({title: t('home_admin'), desc: window.location.hostname ? t('home_admin_desc', {host: window.location.hostname}) : t('home_admin_desc_plain')});
    var layout = el('div', {class: 'fp-home'});
    var grid = el('div', {class: 'fp-admin-grid'});
    FP.groups.forEach(function (g) {
      var list = el('ul', {class: 'fp-fn-list'});
      g.tools.forEach(function (tool) { list.appendChild(el('li', null, [FP.toolLink(tool, 'fp-fn', true, 'sig-ico--16')])); });
      grid.appendChild(el('section', {class: 'sig-card fp-fn-card', 'aria-labelledby': 'fp-grp-h-' + g.id}, [
        el('div', {class: 'sig-card-head'}, [UI.icon(FP.sprite, 'grp_' + g.id, 'sig-ico--24'),
          el('h2', {class: 'sig-card-title', id: 'fp-grp-h-' + g.id}, [el('a', {class: 'fp-card-link', href: '#/group/' + g.id, text: g.label})])]),
        list]));
    });
    if (!FP.groups.length) { grid.appendChild(FP.empty(t('no_tools_admin'), '')); }
    var server = infoCard(t('server_card'), 'server');
    layout.appendChild(grid);
    layout.appendChild(el('aside', {class: 'sig-info', 'aria-label': t('server_card')}, [server]));
    body.appendChild(layout);
    if (FP.tour) { FP.tour(body); }
    FP.summary().then(function (sum) {
      if (!document.body.contains(server)) { return; }
      fill(server.querySelector('ul'), sum.status && typeof sum.status === 'object' ? statusRows(sum.version, sum.status) : basicRows(sum));
    }, function () { unavailable(server.querySelector('ul')); });
  }
  /* an admin sees the server itself (GET /server/status) */
  function statusRows(version, st) {
    var mem = st.memory && typeof st.memory === 'object' ? st.memory : {};
    var disk = st.home_disk && typeof st.home_disk === 'object' ? st.home_disk : null;
    var accounts = st.accounts && typeof st.accounts === 'object' ? st.accounts : {};
    var load = Array.isArray(st.load) && st.load.length === 3 && st.load.every(num) ? st.load.map(function (n) { return n.toFixed(2); }).join(', ') : '\u2014';
    var rows = [row(t('row_hostname'), str(st.hostname), true), row(t('row_os'), str(st.os)), row(t('row_kernel'), str(st.kernel), true),
      row(t('row_version'), str(version), true), row(t('row_uptime'), uptime(st.uptime_seconds)), row(t('row_load'), load, true),
      row(t('row_cpus'), count(st.cpus)),
      meterRow(t('row_memory'), num(mem.total_bytes) && num(mem.available_bytes) ? Math.max(0, mem.total_bytes - mem.available_bytes) : null,
        mem.total_bytes, size)];
    if (disk && num(disk.total_bytes) && num(disk.free_bytes)) {
      var path = typeof disk.path === 'string' && disk.path ? disk.path.slice(0, 64) : '/home';
      rows.push(meterRow(t('row_home_disk', {path: path}), Math.max(0, disk.total_bytes - disk.free_bytes), disk.total_bytes, size));
    } else {
      rows.push(row(t('row_home_disk_plain'), t('summary_unavailable')));
    }
    rows.push(row(t('row_accounts'), count(accounts.total)), row(t('row_suspended'), count(accounts.suspended)));
    return rows;
  }
  /* a reseller may not see the server: the panel version and its own accounts */
  function basicRows(sum) {
    var rows = [row(t('row_hostname'), str(window.location.hostname), true), row(t('row_version'), str(sum.version), true)];
    if (sum.accounts) {
      var suspended = sum.accounts.filter(function (a) { return a && a.status === 'suspended'; }).length;
      rows.push(row(t('row_accounts'), count(sum.accounts.length)));
      rows.push(row(t('row_suspended'), count(suspended)));
    }
    return rows;
  }

  /* ---- one group ---- */
  function toolRow(tool) {
    var a = FP.toolLink(tool, 'fp-tool-row', true, 'sig-ico--36');
    a.appendChild(el('span', {class: 'fp-tool-desc', text: tool.desc}));
    return el('li', null, [a]);
  }
  FP.view('group', function (r) {
    var g = FP.group(r.id);
    if (!g) { FP.views['not-found'](r); return; }
    var body = FP.frame({title: g.label, crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label}]});
    var list = el('ul', {class: 'fp-tool-list'});
    g.tools.forEach(function (tool) { list.appendChild(toolRow(tool)); });
    body.appendChild(el('div', {class: 'sig-card'}, [list]));
  });

  /* ---- a tool with no page yet ---- */
  FP.view('tool', function (r) {
    var tool = FP.tools[r.id];
    if (!tool) { FP.views['not-found'](r); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: tool.desc,
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    body.appendChild(FP.empty(t('tool_pending'), t('tool_pending_desc'),
      el('a', {class: 'sig-btn sig-btn--secondary', href: '#/group/' + g.id, text: t('open_group', {group: g.label})})));
  });

  FP.view('not-found', function () {
    var body = FP.frame({title: t('not_found'), desc: t('not_found_desc')});
    body.appendChild(el('p', null, [el('a', {class: 'sig-btn sig-btn--secondary', href: '#/', text: t('back_home')})]));
  });

  FP.view('home', admin ? adminHome : userHome);

  /* for the Service status page (fp-server.js) */
  FP.home = {statusRows: statusRows, meterRow: meterRow, row: row, infoCard: infoCard, fill: fill, count: count};
})();

/* freePanel main domain rename in the admin panel (docs/api.md, POST /accounts/{username}/main-domain): #/tool/main_domain picks an
   account the signed-in admin or reseller manages and gives it a new main domain. The main site answers on the new name and the
   old one stays on as its alias, so mail and links on it keep working until it is removed on the Domains page. What the server
   sends is drawn as text. The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var USER_RE = /^[a-z][a-z0-9]{0,15}$/;
  var DOMAIN_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var R = {page: null, accounts: []};

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function norm(v) { return v.trim().toLowerCase().replace(/\.$/, ''); }
  function current(user) {
    for (var i = 0; i < R.accounts.length; i++) { if (R.accounts[i].username === user) { return R.accounts[i]; } }
    return null;
  }
  function card(say) {
    var who = el('select', {class: 'sig-select', id: 'fp-md-who', name: 'username'}, [el('option', {value: '', text: t('mdr_pick')})]
      .concat(R.accounts.map(function (a) { return el('option', {value: a.username, text: a.username + ' (' + a.domain + ')'}); })));
    var now = el('p', {class: 'fp-muted fp-md-now', 'aria-live': 'polite'});
    var name = el('input', {class: 'sig-input', id: 'fp-md-domain', name: 'domain', type: 'text', autocomplete: 'off', spellcheck: 'false',
      autocapitalize: 'none', maxlength: '253'});
    var ask = el('div', {class: 'fp-actions fp-md-ask'});
    var go = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('mdr_rename')});
    var form = el('form', {class: 'fp-form fp-mail-form fp-md-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-md-who', t('mdr_account'), who), now,
      M.field('fp-md-domain', t('mdr_new'), name, t('mdr_new_hint')),
      el('div', {class: 'fp-actions'}, [go]), ask]);
    function showNow() {
      var a = current(who.value);
      now.textContent = a ? t('mdr_now', {domain: a.domain}) : '';
    }
    who.addEventListener('change', showNow);
    function check() {
      ask.textContent = '';
      var b = M.start(form);
      if (!b) { return null; }
      var a = current(who.value);
      if (!a) { M.fieldError(form, who, t('mdr_need_account')); return null; }
      var d = norm(name.value);
      if (!DOMAIN_RE.test(d)) { M.fieldError(form, name, t('mdr_need_domain')); return null; }
      if (d === a.domain) { M.fieldError(form, name, t('mdr_same')); return null; }
      return {a: a, d: d, b: b};
    }
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var c = check();
      if (!c) { return; }
      M.confirmIn(ask, t('mdr_ask', {name: c.a.username, old: c.a.domain, domain: c.d}), 'rename-yes', t('mdr_yes'));
    });
    form.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('button[data-fp-act]') : null;
      if (!b) { return; }
      var act = b.getAttribute('data-fp-act');
      if (act === 'confirm-no') { ask.textContent = ''; go.focus(); return; }
      if (act !== 'rename-yes') { return; }
      var c = check();
      if (!c) { return; }
      var page = R.page;
      UI.setBusy(go, true);
      FP.call('post', 'accountMainDomain', {domain: c.d}, c.a.username).then(function (r) {
        if (R.page !== page) { return; }
        var d = DOMAIN_RE.test(str(r && r.domain, 260)) ? r.domain : c.d;
        c.a.domain = d;
        draw(t(r && r.pending ? 'mdr_done_pending' : 'mdr_done', {name: c.a.username, domain: d, old: str(r && r.previous, 260) || ''}), c.a.username);
      }, function (err) {
        if (R.page !== page) { return; }
        UI.setBusy(go, false);
        M.failed(form, err);
      });
    });
    if (say) { M.say(form, say); }
    return {card: M.card('fp-md-h', t('mdr_title'), [el('p', {class: 'fp-muted', text: t('mdr_what')}), form], 'fp-md'), who: who, show: showNow};
  }
  function draw(say, pick) {
    var page = R.page;
    page.textContent = '';
    var c = card(say);
    page.appendChild(c.card);
    if (pick) { c.who.value = pick; c.show(); }
    if (say) { page.querySelector('#fp-md-h').focus(); }
  }
  FP.view('tool:main_domain', function () {
    var tool = FP.tools.main_domain;
    if (!tool || FP.realm !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    R = {page: null, accounts: []};
    var body = FP.frame({title: tool.label, desc: t('mdr_desc'), cls: 'fp-mail fp-md-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    R.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'accounts').then(function (r) {
      if (R.page !== body) { return; }
      R.accounts = (r && Array.isArray(r.accounts) ? r.accounts : []).map(function (a) {
        var u = str(a && a.username, 20);
        var d = str(a && a.domain, 260);
        return USER_RE.test(u) && DOMAIN_RE.test(d) && a.status !== 'creating' ? {username: u, domain: d} : null;
      }).filter(Boolean).sort(function (x, y) { return x.username < y.username ? -1 : 1; });
      if (!R.accounts.length) { body.textContent = ''; body.appendChild(FP.empty(t('mdr_none_title'), t('mdr_none'))); return; }
      draw('', '');
    }, function (err) {
      if (R.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

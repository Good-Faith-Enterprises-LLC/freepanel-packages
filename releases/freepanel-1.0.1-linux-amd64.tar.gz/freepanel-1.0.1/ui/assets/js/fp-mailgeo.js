/* freePanel Mail by country (#/tool/mail_countries, docs/api.md "Email delivery tools"): the administrator's countries whose servers port 25
   refuses or puts off, the exceptions, whether the country database is there and how recent it is, and the last seven days' refusals by
   country. Nothing changes until the admin saves. What the server sends is cleaned to the shapes drawn and shown as text (a path and an
   error come from the server's own file system); country names are the browser's own (Intl.DisplayNames), never markup. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var MAX_COUNTRIES = 250;
  var MAX_EXCEPTIONS = 500;
  var CODE_RE = /^[A-Z]{2}$/;
  var G = null;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function whole(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.round(v) : 0; }
  function arr(v) { return Array.isArray(v) ? v : []; }
  function count(n) { return n.toLocaleString('en'); }
  function codes(v, max) { return arr(v).filter(function (c) { return typeof c === 'string' && CODE_RE.test(c); }).slice(0, max); }
  function texts(v) { return arr(v).filter(function (x) { return typeof x === 'string' && x; }).slice(0, MAX_EXCEPTIONS).map(function (x) { return x.slice(0, 253); }); }
  function when(iso) {
    var d = new Date(str(iso, 40));
    return isNaN(d.getTime()) ? '' : d.toLocaleString(undefined, {year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'});
  }
  var region = null;
  function countryName(code) {
    try {
      region = region || new window.Intl.DisplayNames(['en'], {type: 'region'});
      var n = region.of(code);
      return n && n !== code ? n : code;
    } catch (e) { return code; }
  }
  function label(code) { return t('mgeo_country', {name: countryName(code), code: code}); }
  function byName(a, b) { return countryName(a).localeCompare(countryName(b), 'en'); }
  function lines(box) { return box.value.split('\n').map(function (l) { return l.trim(); }).filter(Boolean); }
  function warn(text, attr) {
    return el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-banner': attr}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: text})]);
  }

  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var db = r.database && typeof r.database === 'object' ? r.database : {};
    var ref = r.refusals && typeof r.refusals === 'object' ? r.refusals : {};
    return {
      countries: codes(r.countries, MAX_COUNTRIES), mode: r.mode === 'defer' ? 'defer' : 'refuse',
      networks: texts(r.allow_networks), senders: texts(r.allow_senders),
      tableNetworks: whole(r.networks), active: r.active === true, inactive: str(r.inactive, 400), pending: r.pending === true, warning: str(r.warning, 400),
      db: {present: db.present === true, path: str(db.path), error: str(db.error, 400), modified: when(db.modified),
        v4: whole(db.ipv4_ranges), v6: whole(db.ipv6_ranges), codes: codes(db.codes, 400)},
      refusals: {days: whole(ref.days) || 7, total: whole(ref.total),
        rows: arr(ref.countries).filter(function (x) { return x && CODE_RE.test(str(x.code, 2)); }).slice(0, 300).map(function (x) { return {code: x.code, count: whole(x.count)}; })}
    };
  }

  /* ---- the country database ---- */
  function dbCard(d) {
    var db = d.db;
    var state = db.present ? ['sig-pill--ok', t('mgeo_db_present')] : db.error ? ['sig-pill--warn', t('mgeo_db_unusable')] : ['sig-pill--warn', t('mgeo_db_missing')];
    var facts = [[t('mgeo_db_modified'), db.modified || '—']];
    if (db.present) { facts.push([t('mgeo_db_ranges'), t('mgeo_db_ranges_v', {four: count(db.v4), six: count(db.v6), n: count(db.codes.length)})]); }
    facts.push([t('mgeo_db_path'), db.path || '—', true]);
    var parts = [el('p', {class: 'fp-mgeo-state'}, [el('span', {class: 'sig-pill ' + state[0], 'data-fp-db': db.present ? 'present' : db.error ? 'unusable' : 'missing', text: state[1]})])];
    if (db.error) { parts.push(el('p', {class: 'fp-mgeo-bad', 'data-fp-db-error': '', text: t('mgeo_db_why', {why: db.error})})); }
    parts.push(el('dl', {class: 'fp-mgeo-facts'}, facts.reduce(function (out, f) {
      out.push(el('dt', {text: f[0]}), el('dd', {class: f[2] ? 'sig-mono' : ''}, [document.createTextNode(f[1])]));
      return out;
    }, [])));
    parts.push(el('p', {class: 'fp-muted', text: db.present ? t('mgeo_db_note') : t('mgeo_db_open')}));
    if (FP.tools.geoip_db) { parts.push(el('p', null, [el('a', {class: 'sig-link', href: '#/tool/geoip_db', text: t('mgeo_db_link')})])); }
    return M.card('fp-mgeo-db-h', t('mgeo_db_title'), parts, 'fp-mgeo-db');
  }

  /* ---- the choice ---- */
  function chosenList() {
    var list = G.draft;
    var ul = el('ul', {class: 'fp-mgeo-chosen', 'aria-labelledby': 'fp-mgeo-chosen-h'});
    if (!list.length) {
      ul.appendChild(el('li', {class: 'fp-muted', 'data-fp-none': 'countries', text: t('mgeo_none_chosen')}));
    }
    list.slice().sort(byName).forEach(function (code) {
      ul.appendChild(el('li', {class: 'fp-mgeo-chip', 'data-fp-country': code}, [
        el('span', {class: 'fp-mgeo-chip-name', text: label(code)}),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-remove': code, 'aria-label': t('mgeo_remove_of', {name: label(code)}), text: t('mgeo_remove')})]));
    });
    return ul;
  }
  function redrawChosen(form, focusCode) {
    var old = form.querySelector('.fp-mgeo-chosen');
    var ul = chosenList();
    old.parentNode.replaceChild(ul, old);
    form.querySelector('[data-fp-chosen-count]').textContent = t('mgeo_chosen_count', {n: count(G.draft.length), max: MAX_COUNTRIES});
    var pick = form.querySelector('#fp-mgeo-add');
    if (pick && pick.tagName === 'SELECT') {
      for (var i = 0; i < pick.options.length; i++) { pick.options[i].disabled = G.draft.indexOf(pick.options[i].value) >= 0 ? true : false; }
    }
    if (focusCode === '') { (pick || form.querySelector('.fp-submit')).focus(); }
  }
  function addPicker(d) {
    var avail = d.db.codes.slice().sort(byName);
    if (avail.length) {
      return el('select', {class: 'sig-select', id: 'fp-mgeo-add', name: 'country'}, [el('option', {value: '', text: t('mgeo_pick')})].concat(avail.map(function (c) {
        return el('option', {value: c, disabled: G.draft.indexOf(c) >= 0 ? true : null, text: label(c)});
      })));
    }
    /* no database to list the codes from: the code is typed */
    return el('input', {class: 'sig-input sig-mono fp-mgeo-code', id: 'fp-mgeo-add', name: 'country', type: 'text', maxlength: '2', autocomplete: 'off',
      spellcheck: 'false', autocapitalize: 'characters', placeholder: 'CN'});
  }
  /* the picker and its Add button on one line, the hint under both */
  function addField(pick, add, hint) {
    pick.setAttribute('aria-describedby', 'fp-mgeo-add-hint');
    return el('div', {class: 'sig-field fp-mgeo-add'}, [el('label', {class: 'sig-label', for: 'fp-mgeo-add', text: t('mgeo_add_label')}),
      el('div', {class: 'fp-mgeo-add-row'}, [pick, add]), el('span', {class: 'sig-hint', id: 'fp-mgeo-add-hint', text: hint})]);
  }
  function radio(id, value, text, hint, on) {
    return el('div', {class: 'fp-mgeo-choice'}, [el('label', {class: 'fp-check', for: id}, [
      el('input', {type: 'radio', id: id, name: 'mode', value: value, checked: on ? true : null, 'aria-describedby': id + '-hint'}), el('span', {text: text})]),
    el('span', {class: 'sig-hint', id: id + '-hint', text: hint})]);
  }
  function summary(d) {
    if (!d.countries.length) { return t('mgeo_now_none'); }
    var names = d.countries.slice().sort(byName).map(countryName);
    var list = names.length > 6 ? t('mgeo_list_more', {names: names.slice(0, 6).join(', '), n: count(names.length - 6)}) : names.join(', ');
    if (!d.active) { return t('mgeo_now_inactive', {list: list}); }
    return t(d.mode === 'defer' ? 'mgeo_now_defer' : 'mgeo_now_refuse', {list: list, networks: count(d.tableNetworks)});
  }
  function formCard(d) {
    var pick = addPicker(d);
    var add = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'add', text: t('mgeo_add')});
    var nets = el('textarea', {class: 'sig-input sig-mono fp-mgeo-list', id: 'fp-mgeo-networks', name: 'allow_networks', rows: '5', spellcheck: 'false', autocapitalize: 'none', autocomplete: 'off'});
    nets.value = d.networks.join('\n');
    var senders = el('textarea', {class: 'sig-input sig-mono fp-mgeo-list', id: 'fp-mgeo-senders', name: 'allow_senders', rows: '5', spellcheck: 'false', autocapitalize: 'none', autocomplete: 'off'});
    senders.value = d.senders.join('\n');
    var form = el('form', {class: 'fp-form fp-mail-form fp-mgeo-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('h3', {class: 'fp-h3', id: 'fp-mgeo-chosen-h', text: t('mgeo_chosen')}),
      el('p', {class: 'fp-muted', 'data-fp-chosen-count': '', text: t('mgeo_chosen_count', {n: count(G.draft.length), max: MAX_COUNTRIES})}),
      chosenList(),
      addField(pick, add, d.db.codes.length ? t('mgeo_add_hint') : t('mgeo_add_hint_code')),
      el('fieldset', {class: 'fp-mgeo-fieldset'}, [el('legend', {class: 'sig-label', text: t('mgeo_mode')}),
        radio('fp-mgeo-refuse', 'refuse', t('mgeo_mode_refuse'), t('mgeo_mode_refuse_hint'), d.mode !== 'defer'),
        radio('fp-mgeo-defer', 'defer', t('mgeo_mode_defer'), t('mgeo_mode_defer_hint'), d.mode === 'defer')]),
      el('h3', {class: 'fp-h3', text: t('mgeo_exceptions')}),
      el('p', {class: 'fp-muted', text: t('mgeo_exceptions_intro')}),
      M.field('fp-mgeo-networks', t('mgeo_networks'), nets, t('mgeo_networks_hint', {max: MAX_EXCEPTIONS})),
      M.field('fp-mgeo-senders', t('mgeo_senders'), senders, t('mgeo_senders_hint', {max: MAX_EXCEPTIONS})),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('mgeo_save')})])]);
    function addOne() {
      UI.showError(form, '');
      pick.removeAttribute('aria-invalid');
      var code = pick.value.trim().toUpperCase();
      if (!code) { M.fieldError(form, pick, t('mgeo_add_empty')); return; }
      if (!CODE_RE.test(code)) { M.fieldError(form, pick, t('mgeo_code_bad', {code: code.slice(0, 10)})); return; }
      if (G.draft.indexOf(code) >= 0) { M.fieldError(form, pick, t('mgeo_already', {name: label(code)})); return; }
      if (G.draft.length >= MAX_COUNTRIES) { M.fieldError(form, pick, t('mgeo_many', {max: MAX_COUNTRIES})); return; }
      G.draft.push(code);
      pick.value = '';
      redrawChosen(form, null);
      M.say(form, t('mgeo_added', {name: label(code)}));
      pick.focus();
    }
    add.addEventListener('click', addOne);
    pick.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); addOne(); } });
    form.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('[data-fp-remove]') : null;
      if (!b) { return; }
      var code = b.getAttribute('data-fp-remove');
      G.draft = G.draft.filter(function (c) { return c !== code; });
      redrawChosen(form, '');
      M.say(form, t('mgeo_removed', {name: label(code)}));
    });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var ns = lines(nets);
      var ss = lines(senders);
      var bad = null;
      [[ns, nets], [ss, senders]].forEach(function (p) {
        if (bad) { return; }
        if (p[0].length > MAX_EXCEPTIONS) { bad = [p[1], t('mgeo_lines_many', {max: MAX_EXCEPTIONS})]; return; }
        p[0].forEach(function (x) { if (!bad && (/\s/.test(x) || x.length > 253)) { bad = [p[1], t('mgeo_line_bad', {line: x.slice(0, 60)})]; } });
      });
      if (bad) { M.fieldError(form, bad[0], bad[1]); return; }
      var mode = form.querySelector('input[name="mode"]:checked');
      var mine = G;
      UI.setBusy(b, true);
      FP.call('put', 'mailCountries', {countries: G.draft.slice().sort(), mode: mode ? mode.value : 'refuse', allow_networks: ns, allow_senders: ss}).then(function (r) {
        if (G !== mine) { return; }
        mine.data = clean(r);
        mine.draft = mine.data.countries.slice();
        draw();
        M.say(G.page.querySelector('.fp-mgeo-form'), G.data.countries.length && !G.data.active ? t('mgeo_saved_inactive') : t('mgeo_saved'));
        G.page.querySelector('#fp-mgeo-h').focus();
      }, function (err) {
        UI.setBusy(b, false);
        if (G === mine) { M.failed(form, err); }
      });
    });
    return M.card('fp-mgeo-h', t('mgeo_title'), [el('p', {class: 'fp-muted', text: t('mgeo_intro')}),
      el('p', {class: 'fp-mgeo-now', 'data-fp-now': '', text: summary(d)}), form], 'fp-mgeo-choice-card');
  }

  /* ---- refusals ---- */
  function refusalsCard(d) {
    var r = d.refusals;
    var parts = [el('p', {class: 'fp-muted', text: t('mgeo_ref_intro', {days: count(r.days)})})];
    if (!r.rows.length) {
      parts.push(el('p', {class: 'fp-mgeo-now', 'data-fp-ref-none': '', text: t('mgeo_ref_none', {days: count(r.days)})}));
    } else {
      parts.push(el('p', {class: 'fp-mgeo-now', 'data-fp-ref-total': '', text: t('mgeo_ref_total', {n: count(r.total), days: count(r.days)})}));
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-mgeo-ref-h'}, [el('table', {class: 'sig-table fp-mgeo-table'}, [
        el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('mgeo_col_country')}), el('th', {scope: 'col', class: 'fp-num', text: t('mgeo_col_refused')})])]),
        el('tbody', null, r.rows.map(function (x) {
          return el('tr', {'data-fp-ref': x.code}, [el('th', {scope: 'row', text: label(x.code)}), el('td', {class: 'fp-num', text: count(x.count)})]);
        }))])]));
    }
    return M.card('fp-mgeo-ref-h', t('mgeo_ref_title'), parts, 'fp-mgeo-ref');
  }

  function neverCard() {
    return M.card('fp-mgeo-never-h', t('mgeo_never_title'), [el('ul', {class: 'fp-mgeo-never'}, ['mgeo_never_1', 'mgeo_never_2', 'mgeo_never_3', 'mgeo_never_4'].map(function (k) {
      return el('li', {text: t(k)});
    }))], 'fp-mgeo-never-card');
  }

  function draw() {
    var d = G.data;
    var page = G.page;
    page.textContent = '';
    if (d.warning) { page.appendChild(warn(t('mgeo_warning', {why: d.warning}), 'warning')); }
    if (d.countries.length && !d.active) { page.appendChild(warn(t('mgeo_inactive', {why: d.inactive || t('mgeo_inactive_unknown')}), 'inactive')); }
    if (d.countries.length && d.pending) { page.appendChild(warn(t('mgeo_pending'), 'pending')); }
    page.appendChild(formCard(d));
    page.appendChild(dbCard(d));
    page.appendChild(refusalsCard(d));
    page.appendChild(neverCard());
  }

  FP.view('tool:mail_countries', function () {
    G = null;
    var tool = FP.tools.mail_countries;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('mgeo_desc'), cls: 'fp-mail fp-mgeo',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    var mine = G = {page: page, data: null, draft: []};
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'mailCountries').then(function (r) {
      if (G !== mine) { return; }
      mine.data = clean(r);
      mine.draft = mine.data.countries.slice();
      draw();
    }, function (err) {
      if (G !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

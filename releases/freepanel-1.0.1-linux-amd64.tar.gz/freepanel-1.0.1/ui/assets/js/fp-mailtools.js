/* freePanel mail tools of the customer panel (docs/api.md, "Email tools"): Mailbox disk usage (#/tool/mailbox_disk: what each mailbox holds
   against its quota, and which folders hold it), Spam folder (#/tool/spam_folder: how long spam is kept, and emptying the folders now),
   DMARC and MTA-STS (#/tool/mail_auth_helper: build the records and the policy a domain publishes, written nowhere), Bulk mailbox import
   (#/tool/mailbox_import: check a list of mailboxes, then add them in one go) and Greylisting (#/tool/greylisting: which of the account's
   domains ask new senders to try again). What the server sends is drawn as text. The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var DOMAIN_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var UNITS = ['KB', 'MB', 'GB', 'TB'];

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function num(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.floor(v) : 0; }
  function count(n) { return Number(n).toLocaleString('en'); }
  function sentence(m) { return typeof m === 'string' && m ? m.charAt(0).toUpperCase() + m.slice(1) : m; }
  function size(n) {
    if (n < 1024) { return count(n) + ' B'; }
    var u = -1;
    do { n /= 1024; u++; } while (n >= 1024 && u < UNITS.length - 1);
    return (n < 10 ? n.toFixed(1) : Math.round(n).toLocaleString('en')) + ' ' + UNITS[u];
  }
  function stamp(iso) {
    var d = typeof iso === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(iso) ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }
  function pill(kind, text) { return el('span', {class: 'sig-pill sig-pill--' + kind, text: text}); }
  /* a bar for the eye; neutral when the ratio is a share of the biggest and not of a limit */
  function meter(ratio, neutral) {
    var bar = el('i');
    bar.style.width = Math.min(100, Math.max(ratio > 0 ? 1 : 0, ratio * 100)).toFixed(1) + '%';
    return el('div', {class: 'sig-meter' + (neutral ? '' : ratio >= 0.95 ? ' is-danger' : ratio >= 0.8 ? ' is-warn' : ''), 'aria-hidden': 'true'}, [bar]);
  }
  function frame(id) {
    var body = M.frame(id, 'fp-mtl fp-mtl-' + id);
    return body;
  }
  function unavailable(body, label, err) {
    body.textContent = '';
    body.appendChild(FP.empty(label, sentence(err.message)));
  }

  /* ================= Mailbox disk usage ================= */
  var LIMIT = 25;
  var D = {page: null, account: '', offset: 0, data: null, folders: {}};

  function cleanUsage(r) {
    if (!r || typeof r !== 'object' || !Array.isArray(r.mailboxes)) { return null; }
    return {total: num(r.total), offset: num(r.offset), used: num(r.used_bytes), boxes: r.mailboxes.map(function (m) {
      if (!m || typeof m !== 'object' || !M.isAddress(m.address)) { return null; }
      var folders = Array.isArray(m.folders) ? m.folders.map(function (f) {
        return f && typeof f === 'object' && typeof f.name === 'string' ? {name: f.name.replace(/[\u0000-\u001f\u007f]/g, ' ').slice(0, 200), messages: num(f.messages), used: num(f.used_bytes)} : null;   // eslint-disable-line no-control-regex -- shown as text
      }).filter(Boolean) : null;
      return {address: m.address, quota: typeof m.quota_mb === 'number' && m.quota_mb >= 0 ? Math.floor(m.quota_mb) : null, used: num(m.used_bytes), messages: num(m.messages),
        percent: typeof m.percent === 'number' && m.percent >= 0 ? m.percent : null, error: typeof m.error === 'string' && m.error !== '', folders: folders, more: num(m.folders_more)};
    }).filter(Boolean)};
  }
  function dUse(m) {
    if (m.error) { return t('md_error'); }
    if (m.quota === null || m.quota === 0 || m.percent === null) { return t('md_use_free', {used: size(m.used)}); }
    return t('md_use', {used: size(m.used), quota: size(m.quota * 1048576), pct: (Math.round(m.percent * 10) / 10).toLocaleString('en')});
  }
  function dFolders(m) {
    var f = D.folders[m.address];
    if (f === undefined) { return null; }
    if (f === 'loading') { return el('p', {class: 'fp-muted', role: 'status', text: t('loading')}); }
    if (f === 'failed') { return el('p', {class: 'fp-warn-line', text: t('md_folders_failed')}); }
    var top = f.reduce(function (n, x) { return Math.max(n, x.used); }, 0);
    var rows = f.map(function (x) {
      return el('li', {class: 'fp-md-folder'}, [el('span', {class: 'fp-md-fname', text: x.name}), el('span', {class: 'fp-muted fp-md-fuse', text: t('md_folder_use', {size: size(x.used), n: count(x.messages)})}),
        meter(top ? x.used / top : 0, true)]);
    });
    return el('div', {class: 'fp-md-folders'}, [rows.length ? el('ul', {class: 'fp-md-flist', 'aria-label': t('md_folders_label', {address: m.address})}, rows) :
      el('p', {class: 'fp-muted', text: t('md_folders_none')}), m.more ? el('p', {class: 'fp-muted fp-row-note', text: t('md_folders_more', {n: count(m.more)})}) : null]);
  }
  function dRow(m) {
    var open = D.folders[m.address] !== undefined;
    var parts = [el('div', {class: 'fp-md-head'}, [el('span', {class: 'fp-md-addr sig-mono', text: m.address}),
      m.error ? pill('warn', t('md_unreadable')) : null]),
    el('div', {class: 'fp-md-use', text: dUse(m)})];
    if (!m.error && m.percent !== null && m.quota) { parts.push(meter(m.percent / 100)); }
    if (m.error) {
      parts.push(el('p', {class: 'fp-muted fp-row-note', text: t('md_error_hint')}));
    } else {
      parts.push(el('div', {class: 'fp-muted fp-row-note', text: t(m.messages === 1 ? 'md_messages_one' : 'md_messages_n', {n: count(m.messages)})}));
      parts.push(el('div', {class: 'fp-mail-acts fp-md-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': open ? 'md-hide' : 'md-show',
        'data-fp-address': m.address, 'aria-expanded': open ? 'true' : 'false', 'aria-label': t(open ? 'md_hide_of' : 'md_show_of', {address: m.address}), text: t(open ? 'md_hide' : 'md_show')})]));
      var folders = dFolders(m);
      if (folders) { parts.push(folders); }
    }
    return el('li', {class: 'fp-md-row', 'data-fp-mailbox': m.address}, parts);
  }
  function dDraw(focus) {
    var d = D.data;
    D.page.textContent = '';
    if (!d.boxes.length && d.total === 0) {
      D.page.appendChild(FP.empty(t('md_none_title'), t('md_none_text'), FP.tools.mailboxes ? el('a', {class: 'sig-btn sig-btn--secondary', href: '#/tool/mailboxes', text: FP.tools.mailboxes.label}) : null));
      return;
    }
    var from = d.offset + 1;
    var to = d.offset + d.boxes.length;
    var parts = [el('p', {class: 'fp-md-sum', role: 'status', 'data-fp-summary': '', text: d.total <= LIMIT ?
      t(d.total === 1 ? 'md_sum_one' : 'md_sum_n', {n: count(d.total), size: size(d.used)}) : t('md_sum_page', {from: count(from), to: count(to), total: count(d.total), size: size(d.used)})}),
    el('p', {class: 'fp-muted fp-row-note', text: t('md_lag')}),
    el('ul', {class: 'fp-md-list', 'aria-label': t('md_list_label')}, d.boxes.map(dRow))];
    if (d.total > LIMIT) {
      parts.push(el('div', {class: 'fp-actions fp-md-pager'}, [
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'md-prev', disabled: d.offset > 0 ? null : true, text: t('md_prev')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'md-next', disabled: to < d.total ? null : true, text: t('md_next')})]));
    }
    D.page.appendChild(M.card('fp-md-h', t('md_title'), parts, 'fp-md-card'));
    if (focus) { D.page.querySelector('#fp-md-h').focus(); }
  }
  function dLoad(offset, focus) {
    var page = D.page;
    return FP.call('get', 'mailUsage', undefined, {name: D.account, limit: String(LIMIT), offset: String(offset)}).then(function (r) {
      if (D.page !== page) { return; }
      var d = cleanUsage(r);
      if (!d) { unavailable(page, FP.tools.mailbox_disk.label, {message: t('api_failed')}); return; }
      D.data = d;
      D.offset = offset;
      D.folders = {};
      dDraw(focus);
    }, function (err) {
      if (D.page === page) { unavailable(page, FP.tools.mailbox_disk.label, err); }
    });
  }
  FP.view('tool:mailbox_disk', function () {
    D = {page: null, account: FP.account(), offset: 0, data: null, folders: {}};
    var body = frame('mailbox_disk');
    if (!body) { return; }
    D.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    dLoad(0, false);
    body.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
      if (!b || D.page !== body || !D.data) { return; }
      var act = b.getAttribute('data-fp-act');
      var address = b.getAttribute('data-fp-address');
      if (act === 'md-prev') { dLoad(Math.max(0, D.offset - LIMIT), true); } else if (act === 'md-next') { dLoad(D.offset + LIMIT, true); } else if (act === 'md-hide') {
        delete D.folders[address];
        dDraw(false);
        D.page.querySelector('[data-fp-mailbox="' + address + '"] [data-fp-act]').focus();
      } else if (act === 'md-show') {
        D.folders[address] = 'loading';
        dDraw(false);
        D.page.querySelector('[data-fp-mailbox="' + address + '"] [data-fp-act]').focus();
        FP.call('get', 'mailboxUsage', undefined, {name: D.account, address: address}).then(function (r) {
          if (D.page !== body) { return; }
          var one = cleanUsage(r);
          var m = one && one.boxes[0];
          D.folders[address] = m && m.folders ? m.folders : 'failed';
          dDraw(false);
          var again = D.page.querySelector('[data-fp-mailbox="' + address + '"] [data-fp-act]');
          if (again) { again.focus(); }
        }, function () {
          if (D.page !== body) { return; }
          D.folders[address] = 'failed';
          dDraw(false);
          var again = D.page.querySelector('[data-fp-mailbox="' + address + '"] [data-fp-act]');
          if (again) { again.focus(); }
        });
      }
    });
  });

  /* ================= Spam folder ================= */
  var S = {page: null, account: '', data: null, boxes: []};
  function cleanSpam(r) {
    if (!r || typeof r !== 'object' || typeof r.keep_days !== 'number') { return null; }
    return {keep: num(r.keep_days), lastRun: stamp(r.last_run), folders: (Array.isArray(r.folders) ? r.folders : []).map(function (f) { return str(f, 40); }).filter(function (f) { return /^[A-Za-z0-9 ._-]+$/.test(f); })};
  }
  function sKeepCard() {
    var d = S.data;
    var days = el('input', {class: 'sig-input fp-sp-days', id: 'fp-sp-days', name: 'keep_days', type: 'number', inputmode: 'numeric', min: '1', max: '365', step: '1', value: d.keep ? String(d.keep) : '30',
      'aria-label': t('sp_days_label'), disabled: d.keep ? null : true});
    var forever = el('input', {type: 'radio', name: 'mode', value: 'forever', id: 'fp-sp-forever', checked: d.keep ? null : true});
    var after = el('input', {type: 'radio', name: 'mode', value: 'after', id: 'fp-sp-after', checked: d.keep ? true : null});
    function sync() { days.disabled = !after.checked; }
    forever.addEventListener('change', sync);
    after.addEventListener('change', function () { sync(); days.focus(); });
    var form = el('form', {class: 'fp-form fp-mail-form fp-sp-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('fieldset', {class: 'fp-sp-set'}, [el('legend', {class: 'sig-label', text: t('sp_keep')}),
        el('label', {class: 'fp-check', for: 'fp-sp-forever'}, [forever, el('span', {text: t('sp_forever')})]),
        el('div', {class: 'fp-sp-after'}, [el('label', {class: 'fp-check', for: 'fp-sp-after'}, [after, el('span', {text: t('sp_after')})]), days, el('span', {text: t('sp_days')})]),
        el('span', {class: 'sig-hint', text: t('sp_keep_hint')})]),
      el('p', {class: 'fp-muted fp-sp-last', 'data-fp-last': '', text: d.lastRun ? t('sp_last', {when: d.lastRun}) : t('sp_last_never')}),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('sp_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var keep = 0;
      if (after.checked) {
        var v = days.value.trim();
        if (!/^[0-9]{1,3}$/.test(v) || Number(v) < 1 || Number(v) > 365) { M.fieldError(form, days, t('sp_days_bad')); return; }
        keep = Number(v);
      }
      var page = S.page;
      UI.setBusy(b, true);
      FP.call('put', 'spamFolder', {keep_days: keep}, S.account).then(function (r) {
        if (S.page !== page) { return; }
        UI.setBusy(b, false);
        var fresh = cleanSpam(r);
        if (fresh) { S.data = fresh; }
        M.say(form, keep ? t('sp_saved_days', {n: count(keep)}) : t('sp_saved_forever'));
      }, function (err) {
        if (S.page !== page) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return M.card('fp-sp-keep-h', t('sp_keep_title'), [el('p', {class: 'fp-muted', text: t('sp_intro', {folders: d.folders.join(' and ') || 'Junk and spam'})}), form], 'fp-sp-keepcard');
  }
  function sEmptyCard() {
    var which = el('select', {class: 'sig-select', id: 'fp-sp-which', name: 'address'}, [el('option', {value: '', text: t('sp_all')})].concat(S.boxes.map(function (a) { return el('option', {value: a, text: a}); })));
    var older = el('input', {class: 'sig-input fp-sp-days', id: 'fp-sp-older', name: 'older_than_days', type: 'number', inputmode: 'numeric', min: '0', max: '365', step: '1', value: '0'});
    var ask = el('div', {class: 'fp-sp-ask'});
    var result = el('div', {class: 'fp-sp-result', role: 'status', 'data-fp-result': ''});
    var form = el('form', {class: 'fp-form fp-mail-form fp-sp-empty', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-sp-which', t('sp_which'), which, ''), M.field('fp-sp-older', t('sp_older'), older, t('sp_older_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary fp-submit fp-btn-danger-text', type: 'submit', text: t('sp_empty')})]), ask, result]);
    var pending = null;
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      result.textContent = '';
      var v = older.value.trim();
      if (!/^[0-9]{1,3}$/.test(v) || Number(v) > 365) { M.fieldError(form, older, t('sp_older_bad')); return; }
      pending = {older: Number(v), address: which.value};
      M.confirmIn(ask, t(pending.older ? 'sp_ask_older' : 'sp_ask', {who: pending.address || t('sp_all_lower'), n: count(pending.older)}), 'sp-confirm', t('sp_ask_yes'));
    });
    form.addEventListener('click', function (e) {
      var yes = e.target.closest ? e.target.closest('[data-fp-act="sp-confirm"]') : null;
      var no = e.target.closest ? e.target.closest('[data-fp-act="confirm-no"]') : null;
      if (no) { ask.textContent = ''; form.querySelector('.fp-submit').focus(); return; }
      if (!yes || !pending) { return; }
      var b = form.querySelector('.fp-submit');
      var body = {older_than_days: pending.older};
      if (pending.address) { body.address = pending.address; }
      var page = S.page;
      ask.textContent = '';
      UI.setBusy(b, true);
      M.say(form, t('sp_working'));
      FP.call('post', 'spamFolderEmpty', body, S.account).then(function (r) {
        if (S.page !== page) { return; }
        UI.setBusy(b, false);
        M.say(form, '');
        var n = num(r && r.mailboxes);
        var failed = num(r && r.failed);
        var parts = [el('p', {text: t(n === 1 ? 'sp_done_one' : 'sp_done_n', {n: count(n)})})];
        if (failed) { parts.push(el('p', {class: 'fp-warn-line', text: t(failed === 1 ? 'sp_failed_one' : 'sp_failed_n', {n: count(failed)})})); }
        if (r && r.incomplete === true) { parts.push(el('p', {class: 'fp-warn-line', 'data-fp-incomplete': '', text: t('sp_incomplete')})); }
        result.textContent = '';
        parts.forEach(function (p) { result.appendChild(p); });
        b.focus();
      }, function (err) {
        if (S.page !== page) { return; }
        UI.setBusy(b, false);
        M.say(form, '');
        M.failed(form, err);
      });
    });
    return M.card('fp-sp-empty-h', t('sp_empty_title'), [el('p', {class: 'fp-muted', text: t('sp_empty_intro')}), form], 'fp-sp-emptycard');
  }
  FP.view('tool:spam_folder', function () {
    S = {page: null, account: FP.account(), data: null, boxes: []};
    var body = frame('spam_folder');
    if (!body) { return; }
    S.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all([FP.call('get', 'spamFolder', undefined, S.account), FP.call('get', 'mail', undefined, S.account).then(function (r) { return M.clean(r).mailboxes.map(function (m) { return m.address; }); }, function () { return []; })]).then(function (r) {
      if (S.page !== body) { return; }
      S.data = cleanSpam(r[0]);
      S.boxes = r[1];
      if (!S.data) { unavailable(body, FP.tools.spam_folder.label, {message: t('api_failed')}); return; }
      body.textContent = '';
      body.appendChild(sKeepCard());
      body.appendChild(sEmptyCard());
    }, function (err) {
      if (S.page === body) { unavailable(body, FP.tools.spam_folder.label, err); }
    });
  });

  /* ================= DMARC and MTA-STS ================= */
  var H = {page: null, account: '', domains: [], domain: '', state: null};
  var POLICIES = ['none', 'quarantine', 'reject'];
  function cleanAuthState(r) {
    if (!r || typeof r !== 'object') { return null; }
    var d = r.dmarc && typeof r.dmarc === 'object' ? r.dmarc : {};
    var o = d.options && typeof d.options === 'object' ? d.options : null;
    var s = r.mta_sts && typeof r.mta_sts === 'object' ? r.mta_sts : {};
    var level = function (v) { return v === 'ok' || v === 'missing' || v === 'wrong' ? v : ''; };
    return {checked: r.checked === true, mailHost: str(r.mail_host, 260), spf: level(r.spf), dkim: level(r.dkim),
      dmarc: {present: d.present === true, record: str(d.record, 600), error: str(d.error, 300), options: o ? {policy: POLICIES.indexOf(o.policy) >= 0 ? o.policy : '',
        sub: POLICIES.indexOf(o.subdomain_policy) >= 0 ? o.subdomain_policy : '', percent: num(o.percent), rua: (Array.isArray(o.report_addresses) ? o.report_addresses : []).map(function (x) { return str(x, 254); }),
        dkimAlign: o.dkim_alignment === 's' ? 's' : o.dkim_alignment === 'r' ? 'r' : '', spfAlign: o.spf_alignment === 's' ? 's' : o.spf_alignment === 'r' ? 'r' : '', interval: num(o.report_interval)} : null},
      sts: {present: s.present === true, record: str(s.record, 300), reporting: str(s.tls_reporting, 300)}};
  }
  function hLevel(v) {
    var kind = v === 'ok' ? 'ok' : v === 'wrong' ? 'warn' : 'danger';
    return pill(kind, t('ma_state_' + v));
  }
  function hNow() {
    var s = H.state;
    var rows = [];
    function add(label, pillEl, text) {
      rows.push(el('dt', {class: 'fp-mtl-k', text: label}), el('dd', {class: 'fp-mtl-v'}, [pillEl, text ? el('span', {class: 'fp-muted fp-row-note fp-mtl-rec sig-mono', text: text}) : null]));
    }
    var parts = [];
    if (!s.checked) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-unchecked': '', text: t('ma_unchecked')}));
    } else {
      add('SPF', hLevel(s.spf), '');
      add('DKIM', hLevel(s.dkim), '');
      add('DMARC', s.dmarc.error ? pill('warn', t('ma_state_unreadable')) : s.dmarc.present ? pill('ok', t('ma_state_found')) : pill('danger', t('ma_state_none')), s.dmarc.error || s.dmarc.record);
      add('MTA-STS', s.sts.present ? pill('ok', t('ma_state_found')) : pill('', t('ma_state_none')), s.sts.record);
      add(t('ma_tls_reporting'), s.sts.reporting ? pill('ok', t('ma_state_found')) : pill('', t('ma_state_none')), s.sts.reporting);
      parts.push(el('dl', {class: 'fp-mtl-vals', 'data-fp-now': ''}, rows));
    }
    return M.card('fp-ma-now-h', t('ma_now_title', {domain: H.domain}), parts, 'fp-ma-now');
  }
  function hCopy(label, value, multi) {
    var box = multi ? el('textarea', {class: 'sig-input sig-mono fp-ma-out', rows: String(Math.min(12, value.split('\n').length + 1)), readonly: '', spellcheck: 'false', wrap: 'off', 'aria-label': label}) :
      el('input', {class: 'sig-input sig-mono fp-ma-out', type: 'text', readonly: '', spellcheck: 'false', 'aria-label': label});
    box.value = value;
    var copy = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'ma-copy', 'aria-label': t('ma_copy_of', {what: label}), text: t('ma_copy')});
    copy.addEventListener('click', function () {
      box.focus();
      box.select();
      var done = function (ok) { UI.announce(ok ? t('ma_copied', {what: label}) : t('ma_copy_select')); };
      if (window.navigator.clipboard && window.navigator.clipboard.writeText) { window.navigator.clipboard.writeText(value).then(function () { done(true); }, function () { done(false); }); } else { done(false); }
    });
    return el('div', {class: 'fp-ma-copy'}, [box, copy]);
  }
  function hRecords(records) {
    return el('ul', {class: 'fp-ma-records', 'data-fp-records': ''}, records.map(function (r, i) {
      return el('li', {class: 'fp-ma-record'}, [el('dl', {class: 'fp-mtl-vals'}, [el('dt', {class: 'fp-mtl-k', text: t('ma_rec_name')}), el('dd', {class: 'fp-mtl-v sig-mono', text: r.fqdn || r.name}),
        el('dt', {class: 'fp-mtl-k', text: t('ma_rec_type')}), el('dd', {class: 'fp-mtl-v', text: r.type}), el('dt', {class: 'fp-mtl-k', text: t('ma_rec_value')}),
        el('dd', {class: 'fp-mtl-v'}, [hCopy(t('ma_rec_of', {name: r.fqdn || r.name, n: i + 1}), r.content, false)])])]);
    }));
  }
  function cleanRecords(list) {
    return (Array.isArray(list) ? list : []).map(function (r) {
      return r && typeof r === 'object' ? {name: str(r.name, 260), fqdn: str(r.fqdn, 300), type: str(r.type, 10), content: str(r.content, 1000)} : null;
    }).filter(function (r) { return r && r.type && r.content; });
  }
  function warnings(list) {
    var w = (Array.isArray(list) ? list : []).map(function (x) { return str(x, 400); }).filter(Boolean);
    return w.length ? el('div', {class: 'fp-ma-warn', 'data-fp-warnings': ''}, [el('p', {class: 'fp-muted fp-ma-warn-h', text: t('ma_warnings')}),
      el('ul', {class: 'fp-at-points'}, w.map(function (x) { return el('li', {text: x}); }))]) : null;
  }
  function hWhere() {
    return el('p', {class: 'fp-muted fp-ma-where'}, [document.createTextNode(t('ma_where') + ' '), FP.tools.dns ? el('a', {href: '#/tool/dns', text: FP.tools.dns.label}) : null]);
  }
  function hDmarcCard() {
    var o = H.state.dmarc.options || {};
    function sel(id, name, values, current, labelKey) {
      return el('select', {class: 'sig-select', id: id, name: name}, values.map(function (v) { return el('option', {value: v, selected: v === current ? true : null, text: t(labelKey + v) }); }));
    }
    var policy = sel('fp-ma-policy', 'policy', POLICIES, o.policy || 'none', 'ma_pol_');
    var sub = el('select', {class: 'sig-select', id: 'fp-ma-sub', name: 'subdomain_policy'}, [el('option', {value: '', text: t('ma_sub_same')})].concat(POLICIES.map(function (v) {
      return el('option', {value: v, selected: v === o.sub ? true : null, text: t('ma_pol_' + v)});
    })));
    var percent = el('input', {class: 'sig-input fp-ma-narrow', id: 'fp-ma-percent', name: 'percent', type: 'number', inputmode: 'numeric', min: '1', max: '100', step: '1', value: String(o.percent || 100)});
    var rua = el('textarea', {class: 'sig-input', id: 'fp-ma-rua', name: 'report_addresses', rows: '3', spellcheck: 'false', autocapitalize: 'none'});
    rua.value = (o.rua || []).join('\n');
    var dk = sel('fp-ma-dkim', 'dkim_alignment', ['r', 's'], o.dkimAlign || 'r', 'ma_align_');
    var sp = sel('fp-ma-spf', 'spf_alignment', ['r', 's'], o.spfAlign || 'r', 'ma_align_');
    var intervals = [3600, 21600, 43200, 86400, 172800, 604800];
    var interval = el('select', {class: 'sig-select', id: 'fp-ma-interval', name: 'report_interval'}, intervals.map(function (v) {
      return el('option', {value: String(v), selected: v === (o.interval || 86400) ? true : null, text: t('ma_int_' + v)});
    }));
    var out = el('div', {class: 'fp-ma-answer', 'data-fp-answer': 'dmarc'});
    var form = el('form', {class: 'fp-form fp-mail-form fp-ma-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-ma-policy', t('ma_policy'), policy, t('ma_policy_hint')), M.field('fp-ma-sub', t('ma_sub'), sub, t('ma_sub_hint')),
      M.field('fp-ma-percent', t('ma_percent'), percent, t('ma_percent_hint')), M.field('fp-ma-rua', t('ma_rua'), rua, t('ma_rua_hint')),
      M.field('fp-ma-dkim', t('ma_dkim_align'), dk, t('ma_align_hint')), M.field('fp-ma-spf', t('ma_spf_align'), sp, ''),
      M.field('fp-ma-interval', t('ma_interval'), interval, t('ma_interval_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('ma_build')})]), out]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var pct = percent.value.trim();
      if (!/^[0-9]{1,3}$/.test(pct) || Number(pct) < 1 || Number(pct) > 100) { M.fieldError(form, percent, t('ma_percent_bad')); return; }
      var addrs = rua.value.split(/[\s,;]+/).map(function (x) { return x.trim().replace(/^mailto:/i, ''); }).filter(Boolean);
      if (addrs.length > 3) { M.fieldError(form, rua, t('ma_rua_many')); return; }
      var bad = addrs.filter(function (x) { return !M.isAddress(x.toLowerCase()); });
      if (bad.length) { M.fieldError(form, rua, t('ma_rua_bad', {address: bad[0].slice(0, 60)})); return; }
      var body = {policy: policy.value, percent: Number(pct), dkim_alignment: dk.value, spf_alignment: sp.value, report_interval: Number(interval.value)};
      if (sub.value) { body.subdomain_policy = sub.value; }
      if (addrs.length) { body.report_addresses = addrs.map(function (x) { return x.toLowerCase(); }); }
      var page = H.page;
      var domain = H.domain;
      UI.setBusy(b, true);
      FP.call('post', 'emailAuthDmarc', body, {name: H.account, domain: domain}).then(function (r) {
        if (H.page !== page || H.domain !== domain) { return; }
        UI.setBusy(b, false);
        var recs = cleanRecords(r && r.record ? [r.record] : []);
        if (!recs.length) { M.fieldError(form, null, t('api_failed')); return; }
        out.textContent = '';
        out.appendChild(el('h3', {class: 'fp-h3', id: 'fp-ma-dmarc-out', tabindex: '-1', text: t('ma_dmarc_out')}));
        out.appendChild(el('p', {class: 'fp-muted', text: t('ma_dmarc_out_intro')}));
        out.appendChild(hRecords(recs));
        var w = warnings(r.warnings);
        if (w) { out.appendChild(w); }
        var cur = str(r.current, 600);
        out.appendChild(el('p', {class: 'fp-muted', 'data-fp-current': '', text: cur ? t('ma_current', {record: cur}) : t('ma_current_none')}));
        out.appendChild(hWhere());
        out.querySelector('#fp-ma-dmarc-out').focus();
      }, function (err) {
        if (H.page !== page) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return M.card('fp-ma-dmarc-h', t('ma_dmarc_title'), [el('p', {class: 'fp-muted', text: t('ma_dmarc_intro')}), form], 'fp-ma-dmarc');
  }
  function hStsCard() {
    var mode = el('select', {class: 'sig-select', id: 'fp-ma-mode', name: 'mode'}, ['testing', 'enforce', 'none'].map(function (v) { return el('option', {value: v, text: t('ma_mode_' + v)}); }));
    var age = el('select', {class: 'sig-select', id: 'fp-ma-age', name: 'max_age'}, [el('option', {value: '', text: t('ma_age_default')})].concat([86400, 604800, 2592000, 31557600].map(function (v) {
      return el('option', {value: String(v), text: t('ma_age_' + v)});
    })));
    var mx = el('textarea', {class: 'sig-input sig-mono', id: 'fp-ma-mx', name: 'mx', rows: '3', spellcheck: 'false', autocapitalize: 'none'});
    var report = el('input', {class: 'sig-input', id: 'fp-ma-report', name: 'report_address', type: 'email', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', maxlength: '254'});
    var here = el('input', {type: 'checkbox', id: 'fp-ma-here', name: 'serve_here'});
    var out = el('div', {class: 'fp-ma-answer', 'data-fp-answer': 'sts'});
    var form = el('form', {class: 'fp-form fp-mail-form fp-ma-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-ma-mode', t('ma_mode'), mode, t('ma_mode_hint')), M.field('fp-ma-age', t('ma_age'), age, t('ma_age_hint')),
      M.field('fp-ma-mx', t('ma_mx'), mx, t('ma_mx_hint')), M.field('fp-ma-report', t('ma_report'), report, t('ma_report_hint')),
      el('label', {class: 'fp-check', for: 'fp-ma-here'}, [here, el('span', {text: t('ma_here')})]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('ma_build_sts')})]), out]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var hosts = mx.value.split(/[\s,;]+/).map(function (x) { return x.trim().toLowerCase(); }).filter(Boolean);
      if (hosts.length > 5) { M.fieldError(form, mx, t('ma_mx_many')); return; }
      var badHost = hosts.filter(function (x) { return !DOMAIN_RE.test(x.replace(/^\*\./, '')); });
      if (badHost.length) { M.fieldError(form, mx, t('ma_mx_bad', {host: badHost[0].slice(0, 60)})); return; }
      var rep = report.value.trim().toLowerCase();
      if (rep && !M.isAddress(rep)) { M.fieldError(form, report, t('ma_report_bad')); return; }
      var body = {mode: mode.value};
      if (age.value) { body.max_age = Number(age.value); }
      if (hosts.length) { body.mx = hosts; }
      if (rep) { body.report_address = rep; }
      if (here.checked) { body.serve_here = true; }
      var page = H.page;
      var domain = H.domain;
      UI.setBusy(b, true);
      FP.call('post', 'emailAuthSts', body, {name: H.account, domain: domain}).then(function (r) {
        if (H.page !== page || H.domain !== domain) { return; }
        UI.setBusy(b, false);
        var policy = str(r && r.policy, 4000);
        if (!policy) { M.fieldError(form, null, t('api_failed')); return; }
        out.textContent = '';
        out.appendChild(el('h3', {class: 'fp-h3', id: 'fp-ma-sts-out', tabindex: '-1', text: t('ma_sts_out')}));
        out.appendChild(el('p', {class: 'fp-muted', text: t('ma_sts_policy_intro', {id: str(r.id, 40)})}));
        out.appendChild(hCopy(t('ma_sts_policy_label'), policy.replace(/\r\n/g, '\n'), true));
        var url = str(r.policy_url, 400);
        if (url) { out.appendChild(el('p', {class: 'fp-muted', 'data-fp-policy-url': ''}, [document.createTextNode(t('ma_sts_serve') + ' '), el('code', {class: 'sig-mono', text: url})])); }
        out.appendChild(el('p', {class: 'fp-muted', text: t('ma_sts_records')}));
        out.appendChild(hRecords(cleanRecords(r.records)));
        var w = warnings(r.warnings);
        if (w) { out.appendChild(w); }
        out.appendChild(hWhere());
        out.querySelector('#fp-ma-sts-out').focus();
      }, function (err) {
        if (H.page !== page) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return M.card('fp-ma-sts-h', t('ma_sts_title'), [el('p', {class: 'fp-muted', text: t('ma_sts_intro')}), form], 'fp-ma-sts');
  }
  function hDraw() {
    var box = H.page.querySelector('.fp-ma-body');
    box.textContent = '';
    box.appendChild(hNow());
    box.appendChild(hDmarcCard());
    box.appendChild(hStsCard());
  }
  function hLoad(domain) {
    var page = H.page;
    H.domain = domain;
    var box = page.querySelector('.fp-ma-body');
    box.textContent = '';
    box.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'emailAuth', undefined, {name: H.account, domain: domain}).then(function (r) {
      if (H.page !== page || H.domain !== domain) { return; }
      H.state = cleanAuthState(r);
      if (!H.state) { box.textContent = ''; box.appendChild(FP.empty(FP.tools.mail_auth_helper.label, t('api_failed'))); return; }
      hDraw();
    }, function (err) {
      if (H.page !== page || H.domain !== domain) { return; }
      box.textContent = '';
      box.appendChild(FP.empty(FP.tools.mail_auth_helper.label, sentence(err.message)));
    });
  }
  function siteNames(r) {
    var out = [];
    (r && Array.isArray(r.sites) ? r.sites : []).forEach(function (s) {
      [s && s.domain].concat(s && Array.isArray(s.aliases) ? s.aliases : []).forEach(function (d) { if (typeof d === 'string' && DOMAIN_RE.test(d) && out.indexOf(d) < 0) { out.push(d); } });
    });
    return out;
  }
  FP.view('tool:mail_auth_helper', function () {
    H = {page: null, account: FP.account(), domains: [], domain: '', state: null};
    var body = frame('mail_auth_helper');
    if (!body) { return; }
    H.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'domains', undefined, H.account).then(function (r) {
      if (H.page !== body) { return; }
      H.domains = siteNames(r);
      body.textContent = '';
      if (!H.domains.length) { body.appendChild(FP.empty(t('ma_none_title'), t('ma_none_text'))); return; }
      var pick = el('select', {class: 'sig-select', id: 'fp-ma-domain', name: 'domain'}, H.domains.map(function (d) { return el('option', {value: d, text: d}); }));
      pick.addEventListener('change', function () { hLoad(pick.value); });
      body.appendChild(M.card('fp-ma-pick-h', t('ma_pick_title'), [M.field('fp-ma-domain', t('ma_domain'), pick, t('ma_domain_hint'))], 'fp-ma-pick'));
      body.appendChild(el('div', {class: 'fp-ma-body'}));
      hLoad(H.domains[0]);
    }, function (err) {
      if (H.page === body) { unavailable(body, FP.tools.mail_auth_helper.label, err); }
    });
  });

  /* ================= Bulk mailbox import ================= */
  var I = {page: null, account: '', checked: ''};
  var MAX_CSV = 64 * 1024;
  var MAX_ROWS = 50;
  var ROW_STATUS = {created: 'ok', exists: 'warn', invalid: 'danger', limited: 'danger'};
  function cleanImport(r) {
    if (!r || typeof r !== 'object' || !Array.isArray(r.rows)) { return null; }
    return {dry: r.dry_run === true, created: num(r.created), exists: num(r.exists), invalid: num(r.invalid), limited: num(r.limited), rows: r.rows.map(function (x) {
      return x && typeof x === 'object' && ROW_STATUS[x.status] ? {row: num(x.row), address: str(x.address, 260), status: x.status, error: str(x.error, 300)} : null;
    }).filter(Boolean)};
  }
  function iResult(d) {
    var parts = [el('p', {class: 'fp-mbi-sum', role: 'status', 'data-fp-summary': '', text: d.dry ? t('mbi_sum_dry', {created: count(d.created), exists: count(d.exists), invalid: count(d.invalid), limited: count(d.limited)}) :
      t(d.created === 1 ? 'mbi_sum_one' : 'mbi_sum_n', {n: count(d.created), exists: count(d.exists), invalid: count(d.invalid), limited: count(d.limited)})})];
    if (d.rows.length) {
      parts.push(el('ul', {class: 'fp-mbi-rows', 'aria-label': t('mbi_rows_label')}, d.rows.map(function (x) {
        return el('li', {class: 'fp-mbi-row', 'data-fp-row': String(x.row)}, [el('span', {class: 'fp-muted fp-mbi-n', text: t('mbi_row', {n: x.row})}), el('span', {class: 'fp-mbi-addr sig-mono', text: x.address || '—'}),
          pill(ROW_STATUS[x.status], t((d.dry && x.status === 'created' ? 'mbi_would_' : 'mbi_') + x.status)), x.error ? el('span', {class: 'fp-muted fp-mbi-why', text: sentence(x.error)}) : null]);
      })));
    }
    return parts;
  }
  FP.view('tool:mailbox_import', function () {
    I = {page: null, account: FP.account(), checked: ''};
    var body = frame('mailbox_import');
    if (!body) { return; }
    I.page = body;
    var csv = el('textarea', {class: 'sig-input sig-mono fp-mbi-csv', id: 'fp-mbi-csv', name: 'csv', rows: '10', spellcheck: 'false', autocomplete: 'off', autocapitalize: 'none', wrap: 'off', placeholder: 'info@example.com,a-long-password-12,1024'});
    var file = el('input', {class: 'sig-input fp-mbi-file', id: 'fp-mbi-file', name: 'file', type: 'file', accept: '.csv,.txt,text/csv,text/plain'});
    var out = el('div', {class: 'fp-mbi-out'});
    var go = el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'im-go', hidden: true});
    var check = el('button', {class: 'sig-btn sig-btn--secondary fp-submit', type: 'submit', text: t('mbi_check')});
    var form = el('form', {class: 'fp-form fp-mail-form fp-mbi-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-mbi-csv', t('mbi_csv'), csv, t('mbi_csv_hint')), M.field('fp-mbi-file', t('mbi_file'), file, t('mbi_file_hint')),
      el('div', {class: 'fp-actions'}, [check, go]), out]);
    function read() {
      var v = csv.value.replace(/^\uFEFF/, '');
      var rows = v.split(/\r?\n/).filter(function (l) { return l.trim() !== ''; });
      if (!rows.length) { M.fieldError(form, csv, t('mbi_empty')); return null; }
      if (new window.TextEncoder().encode(v).length > MAX_CSV) { M.fieldError(form, csv, t('mbi_big')); return null; }
      var data = rows.length - (/^\s*(address|email)\s*[,;\t]/i.test(rows[0]) ? 1 : 0);
      if (data > MAX_ROWS) { M.fieldError(form, csv, t('mbi_many', {n: count(data), max: MAX_ROWS})); return null; }
      return v;
    }
    function call(dry, b) {
      var v = read();
      if (v === null) { return; }
      var page = I.page;
      UI.setBusy(b, true);
      FP.call('post', 'mailImport', {csv: v, dry_run: dry}, I.account).then(function (r) {
        if (I.page !== page) { return; }
        UI.setBusy(b, false);
        var d = cleanImport(r);
        if (!d) { M.fieldError(form, null, t('api_failed')); return; }
        out.textContent = '';
        out.appendChild(M.card('fp-mbi-res-h', t(dry ? 'mbi_check_title' : 'mbi_done_title'), iResult(d), 'fp-mbi-result'));
        if (dry) {
          I.checked = v;
          go.hidden = d.created === 0;
          go.textContent = t(d.created === 1 ? 'mbi_go_one' : 'mbi_go_n', {n: count(d.created)});
        } else {
          /* the passwords are not kept on the page once the mailboxes are made */
          csv.value = '';
          I.checked = '';
          go.hidden = true;
        }
        out.querySelector('#fp-mbi-res-h').focus();
      }, function (err) {
        if (I.page !== page) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    }
    csv.addEventListener('input', function () { if (I.checked && csv.value !== I.checked) { I.checked = ''; go.hidden = true; } });
    file.addEventListener('change', function () {
      var f = file.files && file.files[0];
      if (!f) { return; }
      M.start(form);
      if (f.size > MAX_CSV) { M.fieldError(form, file, t('mbi_big')); file.value = ''; return; }
      var reader = new window.FileReader();
      reader.onload = function () { csv.value = String(reader.result); csv.dispatchEvent(new window.Event('input')); };
      reader.onerror = function () { M.fieldError(form, file, t('mbi_read_failed')); };
      reader.readAsText(f);
    });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (b) { out.textContent = ''; go.hidden = true; call(true, b); }
    });
    go.addEventListener('click', function () {
      if (go.disabled || !I.checked || csv.value !== I.checked) { return; }
      M.start(form);
      call(false, go);
    });
    body.appendChild(M.card('fp-mbi-h', t('mbi_title'), [el('p', {class: 'fp-muted', text: t('mbi_intro')}), el('pre', {class: 'fp-mbi-example sig-mono', text: t('mbi_example')}), form], 'fp-mbi-card'));
  });

  /* ================= Greylisting ================= */
  var G = {page: null, account: '', data: null};
  function cleanGrey(r) {
    if (!r || typeof r !== 'object' || !Array.isArray(r.domains)) { return null; }
    return {available: r.available === true, enabled: r.enabled === true, delay: num(r.delay_seconds), warning: str(r.warning, 300), domains: r.domains.map(function (d) {
      return d && typeof d === 'object' && DOMAIN_RE.test(str(d.domain, 260)) ? {domain: d.domain, served: d.served === true, optedOut: d.opted_out === true, enabled: d.enabled === true} : null;
    }).filter(Boolean).sort(function (a, b) { return a.domain < b.domain ? -1 : 1; })};
  }
  function delayText(s) { return s % 60 === 0 ? t(s === 60 ? 'gl_min_one' : 'gl_min_n', {n: count(s / 60)}) : t('gl_sec', {n: count(s)}); }
  function gState() {
    var d = G.data;
    var key = !d.available ? 'gl_state_unavailable' : !d.enabled ? 'gl_state_off' : 'gl_state_on';
    return el('div', {class: 'sig-banner' + (d.available ? '' : ' sig-banner--warn'), role: 'note', 'data-fp-state': !d.available ? 'unavailable' : d.enabled ? 'on' : 'off'},
      [UI.icon(FP.ui, d.available ? 'ui_info' : 'ui_warning'), el('span', {text: t(key, {delay: delayText(d.delay || 300)})})]);
  }
  function gRow(d) {
    var box = el('input', {type: 'checkbox', id: 'fp-gl-' + d.domain.replace(/[^a-z0-9]/g, '-'), 'data-fp-domain': d.domain, checked: !d.optedOut ? true : null, disabled: d.served ? null : true});
    return el('li', {class: 'fp-gl-row', 'data-fp-row': d.domain}, [el('label', {class: 'fp-check fp-gl-label', for: box.id}, [box,
      el('span', {class: 'fp-gl-who'}, [el('span', {class: 'fp-gl-name sig-mono', text: d.domain}), el('span', {class: 'fp-muted fp-row-note', text: d.served ? t(d.optedOut ? 'gl_row_out' : 'gl_row_in') : t('gl_row_elsewhere')})])])]);
  }
  function gDraw() {
    var d = G.data;
    G.page.textContent = '';
    G.page.appendChild(gState());
    if (d.warning) { G.page.appendChild(el('p', {class: 'fp-warn-line', text: sentence(d.warning)})); }
    var parts = [el('p', {class: 'fp-muted', text: t('gl_intro')}), M.errorLine(), M.statusLine()];
    if (!d.domains.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('gl_none')}));
    } else {
      parts.push(el('p', {class: 'fp-muted', text: t('gl_choose')}), el('ul', {class: 'fp-gl-list', 'aria-label': t('gl_list_label')}, d.domains.map(gRow)));
    }
    G.page.appendChild(M.card('fp-gl-h', t('gl_title'), parts, 'fp-gl-card'));
  }
  FP.view('tool:greylisting', function () {
    G = {page: null, account: FP.account(), data: null};
    var body = frame('greylisting');
    if (!body) { return; }
    G.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'mailGreylist', undefined, G.account).then(function (r) {
      if (G.page !== body) { return; }
      G.data = cleanGrey(r);
      if (!G.data) { unavailable(body, FP.tools.greylisting.label, {message: t('api_failed')}); return; }
      gDraw();
    }, function (err) {
      if (G.page === body) { unavailable(body, FP.tools.greylisting.label, err); }
    });
    body.addEventListener('change', function (e) {
      var box = e.target;
      var domain = box && box.getAttribute ? box.getAttribute('data-fp-domain') : null;
      if (!domain || G.page !== body) { return; }
      var card = body.querySelector('.fp-gl-card');
      var want = box.checked;
      box.disabled = true;
      UI.showError(card, '');
      M.say(card, '');
      FP.call('put', 'mailGreylistDomain', {enabled: want}, {name: G.account, domain: domain}).then(function (r) {
        if (G.page !== body) { return; }
        var fresh = cleanGrey(r);
        if (fresh) { G.data = fresh; }
        gDraw();
        M.say(G.page.querySelector('.fp-gl-card'), t(want ? 'gl_saved_in' : 'gl_saved_out', {domain: domain}));
        var again = G.page.querySelector('[data-fp-domain="' + domain + '"]');
        if (again) { again.focus(); }
      }, function (err) {
        if (G.page !== body) { return; }
        box.checked = !want;
        box.disabled = false;
        UI.showError(card, domain + ': ' + err.message);
        box.focus();
      });
    });
  });
})();

/* freePanel Web Disk (#/tool/web_disk), the customer panel's page for the account's Web Disk logins (docs/api.md, "Web Disk"): a
   login opens one folder of the home as a drive over WebDAV, read and write or read only. The page lists the logins, adds one,
   changes one's password, folder or access, removes one, and says how to connect from Windows, macOS and Linux. Passwords go to the
   server once and are never shown again. What the server sends is drawn as text. It shares the mail pages' look and helpers (FP.mail),
   and the 'Make a strong password' button is theirs. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var NAME_RE = /^[a-z0-9][a-z0-9_-]{0,31}$/;
  var PART_RE = /^[A-Za-z0-9._-]+$/;
  var PATH_RE = /^\/webdisk\/[a-z0-9][a-z0-9_-]{0,31}\/$/;
  var W = {page: null, account: '', state: null, open: ''};

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function clean(r) {
    if (!r || typeof r !== 'object' || !PATH_RE.test(str(r.path, 60)) || !Array.isArray(r.logins)) { return null; }
    var logins = r.logins.slice(0, 200).filter(function (l) { return l && typeof l === 'object' && NAME_RE.test(str(l.name, 40)); }).map(function (l) {
      return {name: l.name, dir: str(l.dir, 255), readOnly: l.read_only === true};
    }).sort(function (a, b) { return a.name < b.name ? -1 : 1; });
    return {path: r.path, logins: logins};
  }
  /* a folder as typed: '' for the home ('.' or nothing), the clean path otherwise; null when it is not one */
  function cleanDir(v) {
    v = v.trim().replace(/^\/+|\/+$/g, '');
    if (v === '' || v === '.') { return ''; }
    if (v.length > 255) { return null; }
    var parts = v.split('/');
    for (var i = 0; i < parts.length; i++) {
      if (!PART_RE.test(parts[i]) || parts[i] === '.' || parts[i] === '..') { return null; }
    }
    return v;
  }
  function dirText(d) { return d === '' ? t('wd_home') : d; }

  /* the password fields of the mailboxes page, with the bound of the server's (1024 bytes: the hash is argon2id, which has no 72-byte end); its button makes the password and shows it */
  function passwordFields(id, optional) {
    return [el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: id, text: optional ? t('mail_new_password') : t('label_password')}),
      el('div', {class: 'fp-reveal-wrap'}, [
        el('input', {class: 'sig-input', id: id, name: 'password', type: 'password', autocomplete: 'new-password', maxlength: '1024',
          'aria-describedby': id + '-hint'}),
        el('button', {class: 'sig-ghost fp-reveal', type: 'button', 'data-overlap-ok': '', 'data-fp-reveal': id + ',' + id + '-again',
          'aria-pressed': 'false', 'aria-label': 'Show password'}, [UI.icon(FP.ui, 'ui_eye')])]),
      el('span', {class: 'sig-hint', id: id + '-hint', text: optional ? t('mail_password_keep_hint') : t('wd_password_hint')})]),
    el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: id + '-again', text: t('mail_password_again')}),
      el('input', {class: 'sig-input', id: id + '-again', name: 'again', type: 'password', autocomplete: 'new-password', maxlength: '1024'})]),
    el('div', {class: 'fp-mail-gen'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'generate',
      'data-fp-for': id, text: t('mail_generate')})])];
  }
  /* the password and its repeat; '' and a message on the form when they don't do */
  function readPassword(form, optional) {
    var pw = form.querySelector('[name="password"]');
    var again = form.querySelector('[name="again"]');
    if (optional && !pw.value && !again.value) { return {value: ''}; }
    if (pw.value.length < 12) { M.fieldError(form, pw, t('mail_password_short')); return null; }
    if (new window.TextEncoder().encode(pw.value).length > 1024) { M.fieldError(form, pw, t('wd_password_long')); return null; }
    if (pw.value !== again.value) { M.fieldError(form, again, t('mail_password_mismatch')); return null; }
    return {value: pw.value};
  }
  function readOnlyBox(id, on) {
    return el('div', {class: 'sig-field'}, [el('label', {class: 'fp-check', for: id}, [
      el('input', {type: 'checkbox', id: id, name: 'read_only', checked: on ? true : null, 'aria-describedby': id + '-hint'}),
      el('span', {text: t('wd_readonly')})]), el('span', {class: 'sig-hint', id: id + '-hint', text: t('wd_readonly_hint')})]);
  }

  function createCard() {
    var form = el('form', {class: 'fp-form fp-mail-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-wd-name', t('wd_name'), el('input', {class: 'sig-input', id: 'fp-wd-name', name: 'name', type: 'text', autocomplete: 'off', spellcheck: 'false',
        autocapitalize: 'none', maxlength: '32'}), t('wd_name_hint'))].concat(passwordFields('fp-wd-pw', false), [
      M.field('fp-wd-dir', t('wd_dir'), el('input', {class: 'sig-input sig-mono', id: 'fp-wd-dir', name: 'dir', type: 'text', autocomplete: 'off', spellcheck: 'false',
        autocapitalize: 'none', maxlength: '255', placeholder: 'webdisk/…'}), t('wd_dir_hint')),
      readOnlyBox('fp-wd-ro', false),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('wd_add')})])]));
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var name = form.querySelector('[name="name"]');
      if (!NAME_RE.test(name.value.trim())) { M.fieldError(form, name, t('wd_name_bad')); return; }
      var pw = readPassword(form, false);
      if (!pw) { return; }
      var dirField = form.querySelector('[name="dir"]');
      var body = {name: name.value.trim(), password: pw.value, read_only: form.querySelector('[name="read_only"]').checked};
      if (dirField.value.trim() !== '') {
        var d = cleanDir(dirField.value);
        if (d === null) { M.fieldError(form, dirField, t('wd_dir_bad')); return; }
        body.dir = d;
      }
      UI.setBusy(b, true);
      FP.call('post', 'webdiskAdd', body, W.account).then(function (r) {
        var s = clean(r);
        if (!s) { UI.setBusy(b, false); M.fieldError(form, null, t('api_failed')); return; }
        W.state = s;
        render();
        M.say(W.page.querySelector('.fp-wd-create'), t('wd_added', {name: body.name}));
        W.page.querySelector('#fp-wd-name').focus();
      }, function (err) {
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return M.card('fp-wd-create-h', t('wd_create_title'), [el('p', {class: 'fp-muted', text: t('wd_create_desc')}), form], 'fp-wd-create');
  }

  function changeRow(l) {
    var form = el('form', {class: 'fp-form fp-mail-inline', novalidate: '', 'aria-labelledby': 'fp-wd-change-h'}, [
      el('h3', {class: 'fp-h3', id: 'fp-wd-change-h', tabindex: '-1', text: t('wd_change_title', {name: l.name})}), M.errorLine()].concat(
      passwordFields('fp-wd-cpw', true), [
      M.field('fp-wd-cdir', t('wd_dir'), el('input', {class: 'sig-input sig-mono', id: 'fp-wd-cdir', name: 'dir', type: 'text', autocomplete: 'off', spellcheck: 'false',
        autocapitalize: 'none', maxlength: '255', value: l.dir === '' ? '.' : l.dir}), t('wd_dir_hint_change')),
      readOnlyBox('fp-wd-cro', l.readOnly),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('wd_save')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'close', text: t('cancel')})])]));
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var pw = readPassword(form, true);
      if (!pw) { return; }
      var dirField = form.querySelector('[name="dir"]');
      var d = cleanDir(dirField.value);
      if (d === null) { M.fieldError(form, dirField, t('wd_dir_bad')); return; }
      var ro = form.querySelector('[name="read_only"]').checked;
      var body = {};
      if (pw.value) { body.password = pw.value; }
      if (d !== l.dir) { body.dir = d; }
      if (ro !== l.readOnly) { body.read_only = ro; }
      if (!Object.keys(body).length) { M.fieldError(form, form.querySelector('[name="password"]'), t('wd_nothing')); return; }
      UI.setBusy(b, true);
      FP.call('patch', 'webdiskLogin', body, {name: W.account, login: l.name}).then(function (r) {
        var s = clean(r);
        if (!s) { UI.setBusy(b, false); M.fieldError(form, null, t('api_failed')); return; }
        W.state = s;
        W.open = '';
        render();
        M.say(W.page.querySelector('.fp-wd-list'), t('wd_saved', {name: l.name}));
        focusRow(l.name, 'change');
      }, function (err) {
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return el('tr', {class: 'fp-mail-formrow'}, [el('td', {colspan: '4'}, [form])]);
  }
  function row(l) {
    return el('tr', {'data-fp-login': l.name}, [
      el('th', {scope: 'row', class: 'fp-mail-name'}, [el('span', {class: 'sig-mono', text: l.name})]),
      el('td', {class: 'fp-wd-dir'}, [el('span', {class: l.dir === '' ? '' : 'sig-mono', text: dirText(l.dir)})]),
      el('td', null, [el('span', {class: 'sig-pill' + (l.readOnly ? '' : ' sig-pill--ok'), text: l.readOnly ? t('wd_mode_ro') : t('wd_mode_rw')})]),
      el('td', {class: 'fp-mail-acts'}, [
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'change', 'aria-expanded': String(W.open === l.name),
          'aria-label': t('wd_change_of', {name: l.name}), text: t('mail_change')}),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'remove',
          'aria-label': t('wd_remove_of', {name: l.name}), text: t('mail_remove')})])]);
  }
  function listCard() {
    var parts = [M.errorLine(), M.statusLine()];
    if (!W.state.logins.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('wd_none')}));
    } else {
      var rows = [];
      W.state.logins.forEach(function (l) {
        rows.push(row(l));
        if (W.open === l.name) { rows.push(changeRow(l)); }
      });
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-wd-list-h'}, [
        el('table', {class: 'sig-table fp-mail-table fp-wd-table'}, [el('thead', null, [el('tr', null, [
          el('th', {scope: 'col', text: t('wd_col_name')}), el('th', {scope: 'col', text: t('wd_col_dir')}),
          el('th', {scope: 'col', text: t('wd_col_mode')}), el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]),
        el('tbody', null, rows)])]));
    }
    return M.card('fp-wd-list-h', t('wd_list_title'), parts, 'fp-wd-list');
  }
  /* how to open the drive; the address is the panel's own, with the path the server gave */
  function connectCard() {
    var address = window.location.origin + W.state.path;
    var input = el('input', {class: 'sig-input sig-mono', id: 'fp-wd-address', type: 'text', readonly: '', value: address, spellcheck: 'false', 'aria-label': t('wd_conn_addr')});
    return M.card('fp-wd-conn-h', t('wd_conn_title'), [el('p', {class: 'fp-muted', text: t('wd_conn_desc')}), M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-wd-addr'}, [input, el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'copy', text: t('wd_copy')})]),
      el('ul', {class: 'fp-wd-os'}, [el('li', {text: t('wd_conn_win')}), el('li', {text: t('wd_conn_mac')}), el('li', {text: t('wd_conn_linux')})]),
      el('p', {class: 'fp-muted', text: t('wd_conn_note')})], 'fp-wd-conn');
  }
  function render() {
    W.page.textContent = '';
    W.page.appendChild(createCard());
    W.page.appendChild(listCard());
    W.page.appendChild(connectCard());
  }
  function focusRow(name, act) {
    var b = W.page.querySelector('tr[data-fp-login="' + window.CSS.escape(name) + '"] [data-fp-act="' + act + '"]');
    if (b) { b.focus(); }
  }

  document.addEventListener('click', function (e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !W.page || !W.page.contains(b)) { return; }
    var a = b.getAttribute('data-fp-act');
    var tr = b.closest('tr');
    var name = tr ? tr.getAttribute('data-fp-login') : '';
    var list = W.page.querySelector('.fp-wd-list');
    if (a === 'copy') {
      var input = W.page.querySelector('#fp-wd-address');
      var conn = W.page.querySelector('.fp-wd-conn');
      var done = function () { UI.showError(conn, ''); M.say(conn, t('wd_copied')); };
      var manual = function () { input.focus(); input.select(); M.say(conn, t('wd_copy_manual')); };
      if (window.navigator.clipboard && window.navigator.clipboard.writeText) { window.navigator.clipboard.writeText(input.value).then(done, manual); } else { manual(); }
    } else if (a === 'change') {
      W.open = W.open === name ? '' : name;
      render();
      if (W.open) { W.page.querySelector('#fp-wd-cpw').focus(); } else { focusRow(name, 'change'); }
    } else if (a === 'close') {
      var was = W.open;
      W.open = '';
      render();
      focusRow(was, 'change');
    } else if (a === 'remove') {
      M.confirmIn(tr.querySelector('.fp-mail-acts'), t('wd_remove_ask', {name: name}), 'remove-yes', t('mail_remove'));
    } else if (a === 'confirm-no') {
      render();
      focusRow(name, 'remove');
    } else if (a === 'remove-yes') {
      UI.showError(list, '');
      UI.setBusy(b, true);
      FP.call('del', 'webdiskLogin', undefined, {name: W.account, login: name}).then(function (r) {
        var s = clean(r);
        if (!s) { render(); UI.showError(W.page.querySelector('.fp-wd-list'), t('api_failed')); return; }
        W.state = s;
        if (W.open === name) { W.open = ''; }
        render();
        M.say(W.page.querySelector('.fp-wd-list'), t('wd_removed', {name: name}));
        W.page.querySelector('#fp-wd-list-h').focus();
      }, function (err) {
        render();
        UI.showError(W.page.querySelector('.fp-wd-list'), err.message);
        focusRow(name, 'remove');
      });
    }
  });

  FP.view('tool:web_disk', function () {
    W.page = null;
    var body = M.frame('web_disk', 'fp-wd');
    if (!body) { return; }
    W.page = body;
    W.account = FP.account();
    W.open = '';
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'webdisk', undefined, W.account).then(function (r) {
      if (W.page !== body) { return; }
      var s = clean(r);
      body.textContent = '';
      if (!s) { body.appendChild(FP.empty(FP.tools.web_disk.label, t('api_failed'))); return; }
      W.state = s;
      render();
    }, function (err) {
      if (W.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(FP.tools.web_disk.label, err.message));
    });
  });
})();

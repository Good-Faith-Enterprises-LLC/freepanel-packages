/* freePanel single sign-on pages (docs/api.md, "Single sign-on"): in both panels the page where a login links itself to the sign-in provider and
   unlinks again (#/tool/sso), and in the admin panel the provider's settings (#/tool/sso_settings): its address, the client the panel is registered
   as, the secret (kept, never shown), which panels offer it, a test, and removing it. What the server answers is cleaned to the shapes drawn, and
   what the provider sends is never shown: a failed sign-in comes back as one of a few fixed words. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var el = UI.el;
  var M = FP.mail;

  var t = UI.t;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  function plain(v) { return /^[\x20-\x7e]*$/.test(v) ? v : ''; }
  function when(iso) {
    var d = new Date(iso);
    return isNaN(d.getTime()) ? '' : d.toLocaleDateString('en', {year: 'numeric', month: 'long', day: 'numeric'});
  }
  function pill(text, kind) { return el('span', {class: 'sig-pill' + (kind ? ' sig-pill--' + kind : ''), 'data-fp-state': '', text: text}); }
  function row(label, value) { return el('div', {class: 'fp-sso-row'}, [el('dt', {text: label}), el('dd', null, Array.isArray(value) ? value : [value])]); }
  function ownAddress(u) { return typeof u === 'string' && /^https:\/\/[^\s"'<>]{4,300}$/.test(u) ? u : ''; }
  /* the panel's own addresses are http on a server that has no certificate yet */
  function panelAddress(u) { return typeof u === 'string' && /^https?:\/\/[^\s"'<>]{4,300}$/.test(u) ? u : ''; }

  /* ------------------------------------------------------------------ the link page */
  var L = null;
  var RESULTS = ['linked', 'denied', 'expired', 'taken', 'failed', 'busy', 'refused', 'off'];

  function cleanLink(r) {
    r = r && typeof r === 'object' ? r : {};
    return {available: r.available === true, linked: r.linked === true, name: str(r.name, 60) || 'single sign-on', at: str(r.linked_at, 40)};
  }
  function linkCard() {
    var st = L.st;
    var support = Boolean(FP.session && FP.session.support);
    var state = st.linked ? pill(t('sso_state_linked'), 'ok') : pill(t('sso_state_not'));
    var banner = L.result ? el('p', {class: L.result === 'linked' || L.result === 'unlinked' ? 'fp-ok-line' : 'fp-alert', role: L.result === 'linked' || L.result === 'unlinked' ? 'status' : 'alert',
      'data-fp-status': '', text: L.result === 'unlinked' ? t('sso_unlinked') : t('sso_r_' + L.result, {name: st.name})}) : null;
    var head = [banner, el('p', {class: 'fp-muted', text: t('sso_what', {name: st.name})}),
      el('dl', {class: 'fp-sso-list'}, [row(t('sso_status'), state)].concat(st.linked && when(st.at) ? [row(t('sso_row_since'), when(st.at))] : []))];
    /* in a support session the server refuses a link and an unlink (the link would outlive the session): say so, offer neither */
    if (support) {
      return M.card('fp-sso-h', t('sso_link_title', {name: st.name}), head.concat([el('p', {class: 'fp-note', role: 'note', 'data-fp-sso-note': '', text: t('sso_support')})]), 'fp-sso');
    }
    /* a link is one more way to sign in to the login, so it asks for the login's own password, as a change of the e-mail address does */
    var pw = el('input', {class: 'sig-input', id: 'fp-sso-pw', name: 'password', type: 'password', autocomplete: 'current-password', maxlength: '1024', spellcheck: 'false', autocapitalize: 'none'});
    var go = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', 'data-fp-act': 'link', text: t(st.linked ? 'sso_relink' : 'sso_link', {name: st.name})});
    var acts = el('div', {class: 'fp-actions fp-sso-acts'}, [go].concat(st.linked ? [el('button', {class: 'sig-btn sig-btn--secondary fp-btn-danger-text', type: 'button', 'data-fp-act': 'unlink', text: t('sso_unlink')})] : []));
    var form = el('form', {class: 'fp-form fp-sso-link-form', novalidate: ''}, [M.field('fp-sso-pw', t('sso_password'), pw, t('sso_password_hint')), M.errorLine(), acts]);
    form.addEventListener('submit', function (e) { e.preventDefault(); linkSubmit(form, pw); });
    return M.card('fp-sso-h', t('sso_link_title', {name: st.name}), head.concat([form]), 'fp-sso');
  }
  function linkSubmit(form, pw) {
    var mine = L;
    if (!form.querySelector('.fp-submit')) { return; }   /* the unlink question is open: Enter in the field asks nothing */
    var go = M.start(form);
    if (!go) { return; }
    if (!pw.value) { M.fieldError(form, pw, t('need_password')); return; }
    UI.setBusy(go, true);
    FP.call('post', 'ssoLink', {password: pw.value}).then(function (r) {
      if (L !== mine) { return; }
      pw.value = '';
      var u = ownAddress(r && r.url);
      if (!u) { UI.setBusy(go, false); UI.showError(form, t('sso_link_failed')); return; }
      M.say(form.closest('.fp-sso'), t('sso_linking', {name: L.st.name}));
      window.location.assign(u);
    }, function (err) {
      if (L !== mine) { return; }
      UI.setBusy(go, false);
      if (err && err.code === 'forbidden') { pw.value = ''; M.fieldError(form, pw, t('sso_pw_wrong')); return; }
      UI.showError(form, err && err.status === 503 ? t('sso_link_failed') : (err && err.message ? err.message : t('api_failed')));
    });
  }
  function drawLink(focus) {
    L.page.textContent = '';
    if (!L.st.available) { L.page.appendChild(FP.empty(FP.tools.sso.label, t('sso_unavailable'))); return; }
    L.page.appendChild(linkCard());
    var target = focus ? L.page.querySelector(focus) : null;
    if (target) { target.focus(); }
  }
  function linkClick(e) {
    var b = e.target && e.target.closest ? e.target.closest('.fp-sso [data-fp-act]') : null;
    if (!b || !L || !L.page.contains(b) || b.disabled) { return; }
    var a = b.getAttribute('data-fp-act');
    var mine = L;
    var scope = b.closest('.fp-sso');
    if (a === 'unlink') {
      M.confirmIn(b.closest('.fp-sso-acts'), t('sso_unlink_ask', {name: L.st.name}), 'unlink-yes', t('sso_unlink_yes'));
    } else if (a === 'confirm-no') {
      drawLink('[data-fp-act="unlink"]');
    } else if (a === 'unlink-yes') {
      UI.setBusy(b, true);
      FP.call('del', 'ssoLink').then(function () {
        if (L !== mine) { return; }
        L.st.linked = false;
        L.result = 'unlinked';
        drawLink('#fp-sso-h');
      }, function (err) { if (L === mine) { UI.setBusy(b, false); UI.showError(scope, err.message); } });
    }
  }
  document.addEventListener('click', linkClick);

  FP.view('tool:sso', function () {
    L = null;
    var tool = FP.tools.sso;
    if (!tool) { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('sso_desc'), cls: 'fp-mail fp-sso-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    if (!page) { return; }
    L = {page: page, st: null, result: ''};
    var mine = L;
    /* where the provider sent the browser back to says how the linking went: one fixed word, then forgotten */
    var m = /[?&]sso=([a-z_]+)/.exec(window.location.search);
    if (m && RESULTS.indexOf(m[1]) >= 0) { L.result = m[1]; }
    if (m && window.history && window.history.replaceState) {
      window.history.replaceState(null, '', window.location.pathname + window.location.hash);
    }
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'ssoLink').then(function (r) {
      if (L !== mine) { return; }
      L.st = cleanLink(r);
      drawLink('');
    }, function (err) {
      if (L !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err && err.message ? err.message : t('api_failed')));
    });
  });

  /* ------------------------------------------------------------------ the provider's settings (admin) */
  var S = null;

  function cleanSettings(r) {
    r = r && typeof r === 'object' ? r : {};
    return {name: str(r.name, 80), issuer: ownAddress(r.issuer), client: plain(str(r.client_id, 255)), secretSet: r.client_secret_set === true, admin: r.admin_login === true,
      user: r.user_login === true, internal: r.allow_internal === true, redirectAdmin: panelAddress(r.redirect_uri_admin), redirectUser: panelAddress(r.redirect_uri_user),
      configured: r.configured === true};
  }
  function textField(id, name, label, value, hint, type) {
    var input = el('input', {class: 'sig-input', id: id, name: name, type: type || 'text', value: value, maxlength: '300', spellcheck: 'false', autocapitalize: 'none', autocomplete: 'off'});
    return M.field(id, label, input, hint);
  }
  function checkbox(id, name, label, checked, hint) {
    var box = el('input', {type: 'checkbox', id: id, name: name, checked: checked ? true : null});
    if (hint) { box.setAttribute('aria-describedby', id + '-hint'); }
    return el('div', {class: 'sig-field'}, [el('label', {class: 'fp-check', for: id}, [box, el('span', {text: label})]), hint ? el('span', {class: 'sig-hint', id: id + '-hint', text: hint}) : null]);
  }
  function providerCard() {
    var st = S.st;
    var form = el('form', {class: 'fp-form fp-sso-form', novalidate: ''}, [
      textField('fp-sso-name', 'name', t('sso_name'), st.name, t('sso_name_hint')),
      textField('fp-sso-issuer', 'issuer', t('sso_issuer'), st.issuer, t('sso_issuer_hint', {path: '/.well-known/openid-configuration'}), 'url'),
      textField('fp-sso-client', 'client_id', t('sso_client'), st.client, t('sso_client_hint')),
      textField('fp-sso-secret', 'client_secret', t('sso_secret'), '', st.secretSet ? t('sso_secret_hint_set') : t('sso_secret_hint_new'), 'password'),
      checkbox('fp-sso-internal', 'allow_internal', t('sso_internal'), st.internal, t('sso_internal_hint')),
      el('fieldset', {class: 'fp-sso-panels'}, [el('legend', {class: 'sig-label', text: t('sso_panels')}),
        checkbox('fp-sso-admin', 'admin_login', t('sso_panel_admin'), st.admin, ''), checkbox('fp-sso-user', 'user_login', t('sso_panel_user'), st.user, ''),
        el('span', {class: 'sig-hint', text: t('sso_panels_hint')})]),
      el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': ''}), M.statusLine(),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('sso_save')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'test', text: t('sso_test')})]),
      el('p', {class: 'fp-sso-test', role: 'status', 'data-fp-test': ''})]);
    form.querySelector('#fp-sso-name').setAttribute('maxlength', '40');
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var go = M.start(form);
      if (!go) { return; }
      var mine = S;
      var f = function (n) { return form.querySelector('[name="' + n + '"]'); };
      var body = {name: f('name').value.trim(), issuer: f('issuer').value.trim(), client_id: f('client_id').value.trim(), allow_internal: f('allow_internal').checked,
        admin_login: f('admin_login').checked, user_login: f('user_login').checked};
      /* a field left empty is not sent: the server keeps what it has, and says what is missing when a panel is turned on */
      ['name', 'issuer', 'client_id'].forEach(function (k) { if (body[k] === '') { delete body[k]; } });
      if (f('client_secret').value) { body.client_secret = f('client_secret').value; }
      UI.setBusy(go, true);
      FP.call('put', 'ssoProvider', body).then(function (r) {
        if (S !== mine) { return; }
        S.st = cleanSettings(r);
        S.saved = S.st.admin || S.st.user ? 'on' : 'saved';
        drawSettings('#fp-sso-prov-h');
      }, function (err) {
        if (S !== mine) { return; }
        UI.setBusy(go, false);
        var input = err && err.field ? form.querySelector('[name="' + window.CSS.escape(err.field) + '"]') : null;
        if (input) { M.fieldError(form, input, err.message); } else { M.failed(form, err); }
      });
    });
    form.addEventListener('click', function (e) {
      var b = e.target && e.target.closest ? e.target.closest('[data-fp-act="test"]') : null;
      if (!b || b.disabled) { return; }
      var out = form.querySelector('[data-fp-test]');
      var mine = S;
      UI.showError(form, '');
      out.textContent = t('sso_testing');
      UI.setBusy(b, true);
      FP.call('post', 'ssoTest', {}).then(function (r) {
        if (S !== mine) { return; }
        UI.setBusy(b, false);
        r = r && typeof r === 'object' ? r : {};
        out.textContent = t('sso_test_ok', {n: String(typeof r.keys === 'number' ? Math.min(Math.floor(r.keys), 1000) : 0), token: ownAddress(r.token_endpoint) || '—'});
      }, function (err) {
        if (S !== mine) { return; }
        UI.setBusy(b, false);
        out.textContent = '';
        UI.showError(form, err && err.field === 'issuer' && /is not set/.test(err.message || '') ? t('sso_test_none') : (err && err.message ? err.message : t('api_failed')));
      });
    });
    return M.card('fp-sso-prov-h', t('sso_prov_title'), [el('p', {class: 'fp-muted', text: t('sso_prov_what')}),
      S.saved ? el('p', {class: 'fp-ok-line', role: 'status', 'data-fp-status': '', text: t(S.saved === 'on' ? 'sso_saved_on' : 'sso_saved')}) : null, form], 'fp-sso');
  }
  function copyRow(which, label, value) {
    var btn = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'copy', 'data-fp-copy': value, 'aria-label': t('sso_copy_for', {which: label}), text: t('sso_copy'),
      disabled: value ? null : true});
    return row(label, [el('span', {class: 'sig-mono fp-sso-addr', 'data-fp-addr': which, text: value || t('sso_not_set')}), el('span', null, [' ']), btn]);
  }
  function redirectCard() {
    var st = S.st;
    return M.card('fp-sso-redir-h', t('sso_redirect_title'), [el('p', {class: 'fp-muted', text: t('sso_redirect_what')}),
      el('dl', {class: 'fp-sso-list'}, [copyRow('admin', t('sso_redirect_admin'), st.redirectAdmin), copyRow('user', t('sso_redirect_user'), st.redirectUser)]), M.statusLine()], 'fp-sso fp-sso-redir');
  }
  function removeCard() {
    var acts = el('div', {class: 'fp-actions fp-sso-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary fp-btn-danger-text', type: 'button', 'data-fp-act': 'remove', text: t('sso_remove')})]);
    return M.card('fp-sso-rm-h', t('sso_remove_title'), [el('p', {class: 'fp-muted', text: t('sso_remove_what')}), M.errorLine(), acts], 'fp-sso fp-sso-rm');
  }
  function drawSettings(focus) {
    S.page.textContent = '';
    S.page.appendChild(providerCard());
    S.page.appendChild(redirectCard());
    if (S.st.configured || S.st.issuer || S.st.client || S.st.secretSet) { S.page.appendChild(removeCard()); }
    var target = focus ? S.page.querySelector(focus) : null;
    if (target) { target.focus(); }
  }
  function settingsClick(e) {
    var b = e.target && e.target.closest ? e.target.closest('.fp-sso-redir [data-fp-act], .fp-sso-rm [data-fp-act]') : null;
    if (!b || !S || !S.page.contains(b) || b.disabled) { return; }
    var a = b.getAttribute('data-fp-act');
    var mine = S;
    if (a === 'copy') {
      var card = b.closest('.fp-sso');
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(b.getAttribute('data-fp-copy')).then(function () { M.say(card, t('copied')); }, function () { M.say(card, t('copy_failed')); });
      } else {
        M.say(card, t('copy_failed'));
      }
    } else if (a === 'remove') {
      M.confirmIn(b.closest('.fp-sso-acts'), t('sso_remove_ask'), 'remove-yes', t('sso_remove_yes'));
    } else if (a === 'confirm-no') {
      var rm = S.page.querySelector('.fp-sso-rm');
      if (rm) { rm.parentNode.replaceChild(removeCard(), rm); S.page.querySelector('[data-fp-act="remove"]').focus(); }
    } else if (a === 'remove-yes') {
      var scope = b.closest('.fp-sso');
      UI.setBusy(b, true);
      FP.call('del', 'ssoProvider').then(function () {
        if (S !== mine) { return; }
        S.st = cleanSettings({redirect_uri_admin: S.st.redirectAdmin, redirect_uri_user: S.st.redirectUser});
        S.saved = '';
        drawSettings('#fp-sso-prov-h');
        M.say(S.page.querySelector('.fp-sso'), t('sso_removed'));
      }, function (err) { if (S === mine) { UI.setBusy(b, false); UI.showError(scope, err.message); } });
    }
  }
  document.addEventListener('click', settingsClick);

  FP.view('tool:sso_settings', function () {
    S = null;
    var tool = FP.tools.sso_settings;
    if (!tool || FP.realm !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('sso_settings_desc'), cls: 'fp-mail fp-sso-page fp-sso-settings',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    if (!page) { return; }
    S = {page: page, st: null, saved: ''};
    var mine = S;
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'ssoProvider').then(function (r) {
      if (S !== mine) { return; }
      S.st = cleanSettings(r);
      drawSettings('');
    }, function (err) {
      if (S !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err && err.message ? err.message : t('api_failed')));
    });
  });
})();

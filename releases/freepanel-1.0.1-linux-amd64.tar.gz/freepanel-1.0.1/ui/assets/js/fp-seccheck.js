/* freePanel security check in the admin panel (docs/api.md, "Security check"): #/tool/security_check shows the server's report of how
   it is set up, made fresh at each request: a summary of how many findings are failures, warnings, fine or only information, and
   each finding with what it saw, what to do, and a link to the panel page that puts it right. It only reads: nothing is changed here.
   Admin only: the server refuses it to anyone else, and allows 6 reports a minute (the page says when it has to wait). A finding
   can name a database user or a host a customer chose, so everything the server sends is shown as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var STATUS = ['fail', 'warn', 'info', 'ok'];
  var PILL = {fail: 'danger', warn: 'warn', ok: 'ok', info: ''};
  var ID_RE = /^[a-z0-9_]{1,40}$/;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function when(iso) {
    var d = new Date(str(iso, 40));
    return isNaN(d.getTime()) ? '' : d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'});
  }
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var items = (Array.isArray(r.items) ? r.items : []).filter(function (i) { return i && ID_RE.test(str(i.id, 40)) && str(i.title, 120); }).slice(0, 80).map(function (i) {
      return {id: i.id, group: ID_RE.test(str(i.group, 40)) ? i.group : 'other', title: str(i.title, 120), status: STATUS.indexOf(i.status) >= 0 ? i.status : 'info',
        detail: str(i.detail), fix: str(i.fix), page: ID_RE.test(str(i.page, 40)) ? i.page : ''};
    });
    /* the counts are the findings' own: a summary that disagreed with the list would be one more thing to doubt */
    var summary = {fail: 0, warn: 0, ok: 0, info: 0};
    items.forEach(function (i) { summary[i.status] += 1; });
    return {checkedAt: str(r.checked_at, 40), items: items, summary: summary};
  }

  var page = null;
  var R = null;          /* the server's report, cleaned */
  var onlyProblems = false;

  function groupLabel(id) { return t('sck_group_' + id) === 'sck_group_' + id ? id : t('sck_group_' + id); }
  function statusPill(status) { return el('span', {class: 'sig-pill' + (PILL[status] ? ' sig-pill--' + PILL[status] : ''), 'data-fp-status-of': status, text: t('sck_s_' + status)}); }

  function summaryLine() {
    var s = R.summary;
    var parts = [['fail', 'sck_n_fail'], ['warn', 'sck_n_warn'], ['ok', 'sck_n_ok'], ['info', 'sck_n_info']].map(function (p) {
      return el('li', {class: 'fp-sck-count', 'data-fp-count': p[0]}, [statusPill(p[0]), el('span', {text: t(p[1], {n: s[p[0]].toLocaleString('en')})})]);
    });
    return el('ul', {class: 'fp-sck-summary', 'aria-label': t('sck_summary')}, parts);
  }

  function itemNode(i) {
    var parts = [el('div', {class: 'fp-sck-head'}, [statusPill(i.status), el('strong', {class: 'fp-sck-title', text: i.title})])];
    if (i.detail) { parts.push(el('p', {class: 'fp-sck-detail', text: i.detail})); }
    if (i.fix && (i.status === 'fail' || i.status === 'warn' || i.status === 'info')) { parts.push(el('p', {class: 'fp-muted fp-sck-fix', text: t('sck_fix', {fix: i.fix})})); }
    var tool = i.page ? FP.tools[i.page] : null;
    if (tool && (i.status === 'fail' || i.status === 'warn' || i.status === 'info')) {
      parts.push(el('p', {class: 'fp-sck-page'}, [el('a', {href: tool.href, 'data-fp-page': i.page, 'aria-label': t('sck_open_of', {page: tool.label, title: i.title}), text: t('sck_open', {page: tool.label})})]));
    }
    return el('li', {class: 'fp-sck-item fp-sck-item--' + i.status, 'data-fp-item': i.id, 'data-fp-status': i.status}, parts);
  }

  function reportCard() {
    var shown = R.items.filter(function (i) { return !onlyProblems || i.status === 'fail' || i.status === 'warn'; });
    var groups = [];
    shown.forEach(function (i) { if (groups.indexOf(i.group) < 0) { groups.push(i.group); } });
    var at = when(R.checkedAt);
    var box = el('input', {type: 'checkbox', id: 'fp-sck-only', name: 'only', checked: onlyProblems ? true : null});
    box.addEventListener('change', function () {
      onlyProblems = box.checked;
      draw({focus: '#fp-sck-only'});
    });
    var parts = [el('p', {class: 'fp-muted', text: t('sck_what')}), summaryLine(),
      el('div', {class: 'fp-sck-bar'}, [
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'again', text: t('sck_again')}),
        el('label', {class: 'fp-check', for: 'fp-sck-only'}, [box, el('span', {text: t('sck_only')})]),
        at ? el('span', {class: 'fp-muted fp-sck-when', 'data-fp-checked': '', text: t('sck_checked', {when: at})}) : null]),
      M.errorLine(), M.statusLine()];
    if (!R.items.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': 'none', text: t('sck_none')}));
    } else if (!shown.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': 'fine', text: t('sck_all_fine')}));
    }
    groups.forEach(function (g) {
      var id = 'fp-sck-g-' + g;
      parts.push(el('section', {class: 'fp-sck-group', 'data-fp-group-of': g, 'aria-labelledby': id}, [
        el('h3', {class: 'fp-h3', id: id, text: groupLabel(g)}),
        el('ul', {class: 'fp-sck-list'}, shown.filter(function (i) { return i.group === g; }).map(itemNode))]));
    });
    return M.card('fp-sck-h', t('sck_title'), parts, 'fp-sck-card');
  }

  /* redraws the report; opts.say is the text for its status line, opts.focus a selector for the control that takes focus */
  function draw(opts) {
    opts = opts || {};
    var old = page.querySelector('.fp-sck-card');
    var card = reportCard();
    if (old) { old.replaceWith(card); } else { page.appendChild(card); }
    if (opts.say) { M.say(card, opts.say); }
    var target = opts.focus ? card.querySelector(opts.focus) : null;
    if (target) { target.focus(); }
  }

  function onClick(e) {
    var node = e.target.closest ? e.target : null;
    var b = node && node.closest('[data-fp-act="again"]');
    if (!b || !page || !page.contains(b) || b.disabled) { return; }
    var mine = page;
    var card = page.querySelector('.fp-sck-card');
    UI.showError(card, '');
    M.say(card, '');
    UI.setBusy(b, true);
    FP.call('get', 'securityCheck').then(function (r) {
      if (page !== mine) { return; }
      R = clean(r);
      draw({say: t('sck_checked_now'), focus: '[data-fp-act="again"]'});
    }, function (err) {
      if (page !== mine) { return; }
      UI.setBusy(b, false);
      /* a report refused for the limit says how long to wait: the API client's own words for a 429 */
      UI.showError(card, err.message);
      b.focus();
    });
  }
  document.addEventListener('click', onClick);

  FP.view('tool:security_check', function () {
    var tool = FP.tools.security_check;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    R = null;
    onlyProblems = false;
    var mine = FP.frame({title: tool.label, desc: t('sck_desc'), cls: 'fp-mail fp-srv fp-sck-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    page = mine;
    mine.appendChild(el('p', {class: 'fp-muted', text: t('sck_loading')}));
    FP.call('get', 'securityCheck').then(function (r) {
      if (page !== mine) { return; }
      R = clean(r);
      mine.textContent = '';
      draw();
    }, function (err) {
      if (page !== mine) { return; }
      mine.textContent = '';
      var again = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-retry': '', text: t('sec_try_again')});
      again.addEventListener('click', function () { FP.route(true); });
      mine.appendChild(FP.empty(tool.label, err.message, again));
    });
  });
})();

/* freePanel mail queue (#/tool/mail_queue), the admin panel's page for the mail waiting to go out (docs/api.md, "Mail
   queue"): the messages in each of the mail server's queues, a way to look for one, to read its headers and text, to
   try it again now, to park it, to release a parked one, to have the mail server read it again, and to delete a parked
   one for good. Nothing leaves the queue without being parked and then deleted on purpose. Addresses, reasons and the
   messages themselves come from mail and from other servers: they are shown as text, never as markup. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var ID_RE = /^[0-9A-Za-z]{6,32}$/;
  /* the tabs, in the order they are drawn; each is one of the mail server's queues */
  var ORDER = ['deferred', 'active', 'incoming', 'maildrop', 'hold'];
  var STATE = {deferred: ['warn', 'ui_warning'], active: ['', 'ui_info'], incoming: ['', 'ui_info'], maildrop: ['', 'ui_info'], hold: ['', 'ui_pause']};
  var PAGE = 100;
  var UNITS = ['KB', 'MB', 'GB', 'TB'];
  var Q = null;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 500) : ''; }
  function whole(v) { return typeof v === 'number' && isFinite(v) && v >= 0 && Math.floor(v) === v ? v : null; }
  function num(n) { return n.toLocaleString('en'); }
  function size(n) {
    if (n < 1024) { return t('size_bytes', {n: String(Math.round(n))}); }
    var u = -1;
    do { n /= 1024; u++; } while (n >= 1024 && u < UNITS.length - 1);
    return (n < 10 ? n.toFixed(1) : Math.round(n).toLocaleString('en')) + ' ' + UNITS[u];
  }
  function when(iso) {
    var d = new Date(str(iso, 40));
    return isNaN(d.getTime()) ? '' : d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'});
  }

  function cleanMessage(m) {
    if (!m || !ID_RE.test(str(m.id, 32)) || ORDER.indexOf(m.queue) < 0) { return null; }
    var recipients = (Array.isArray(m.recipients) ? m.recipients : []).slice(0, 20).map(function (r) {
      return r && typeof r === 'object' && str(r.address, 320) ? {address: r.address.slice(0, 320), reason: str(r.reason)} : null;
    }).filter(Boolean);
    return {id: m.id, queue: m.queue, arrived: str(m.arrived, 40), size: whole(m.size), sender: str(m.sender, 320), recipients: recipients,
      count: Math.max(whole(m.recipient_count) || 0, recipients.length)};
  }
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var counts = {};
    ORDER.forEach(function (k) { counts[k] = whole(r.counts && r.counts[k]) || 0; });
    var p = r.postfix && typeof r.postfix === 'object' ? r.postfix : {};
    var messages = (Array.isArray(r.messages) ? r.messages : []).map(cleanMessage).filter(Boolean);
    return {installed: p.installed !== false, active: p.active !== false, counts: counts, total: whole(r.total) || 0, messages: messages, truncated: r.truncated === true};
  }
  /* the answer to a batch: the ids done, the ids gone from the queue, and how many were turned away for each reason */
  function cleanResult(r) {
    r = r && typeof r === 'object' ? r : {};
    var ids = function (v) { return (Array.isArray(v) ? v : []).filter(function (x) { return typeof x === 'string' && ID_RE.test(x); }); };
    var refused = {parked: 0, not_parked: 0, not_queued: 0};
    (Array.isArray(r.refused) ? r.refused : []).forEach(function (x) {
      if (x && refused[x.reason] !== undefined) { refused[x.reason]++; }
    });
    return {done: ids(r.done), missing: ids(r.missing), refused: refused};
  }

  function allCount() { return ORDER.reduce(function (n, k) { return n + Q.data.counts[k]; }, 0); }
  function find(id) {
    for (var i = 0; i < Q.data.messages.length; i++) { if (Q.data.messages[i].id === id) { return Q.data.messages[i]; } }
    return null;
  }
  function rowSelector(id) { return 'tr[data-fp-id="' + window.CSS.escape(id) + '"]'; }
  function viewOf(id) { return rowSelector(id) + ' [data-fp-act="view"]'; }
  function card(name) { return Q.page.querySelector('[data-fp-card="' + name + '"]'); }

  /* ---- pieces ---- */
  function stateOf(queue) {
    var s = STATE[queue];
    return el('span', {class: 'sig-pill fp-mq-pill' + (s[0] ? ' sig-pill--' + s[0] : ''), 'data-fp-queue-of': queue}, [UI.icon(FP.ui, s[1], 'fp-pill-ico'), el('span', {text: t('mq_q_' + queue)})]);
  }
  function th(text, cls) { return el('th', {scope: 'col', class: cls || null, text: text}); }
  function button(act, text, cls, extra) {
    return el('button', Object.assign({class: 'sig-btn ' + (cls || 'sig-btn--secondary'), type: 'button', 'data-fp-act': act, text: text}, extra || {}));
  }
  function rowButton(act, labelKey, text, id, cls) {
    return button(act, text, 'sig-btn--sm ' + (cls || 'sig-btn--secondary'), {'data-fp-id': id, 'aria-label': t(labelKey, {id: id})});
  }

  /* the tabs say which queue is shown and how many messages each holds; they are changed in place, so a search being typed stays */
  function tabs() {
    var group = el('div', {class: 'fp-mq-tabs', role: 'group', 'aria-label': t('mq_show')});
    [''].concat(ORDER).forEach(function (name) {
      group.appendChild(el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-mq-tab', type: 'button', 'data-fp-act': 'queue', 'data-fp-queue': name, 'aria-pressed': 'false'}));
    });
    return group;
  }
  function updateTabs() {
    var bs = Q.page.querySelectorAll('.fp-mq-tab');
    for (var i = 0; i < bs.length; i++) {
      var name = bs[i].getAttribute('data-fp-queue');
      bs[i].textContent = t('mq_tab', {name: t(name ? 'mq_q_' + name : 'mq_q_all'), n: num(name ? Q.data.counts[name] : allCount())});
      bs[i].setAttribute('aria-pressed', name === Q.queue ? 'true' : 'false');
      bs[i].classList.toggle('is-on', name === Q.queue);
    }
    Q.page.querySelector('[data-fp-act="clear"]').hidden = !Q.q;
    Q.page.querySelector('[data-fp-act="retry-all"]').disabled = Q.data.counts.deferred === 0;
  }
  function notices() {
    var box = Q.page.querySelector('.fp-mq-notices');
    box.textContent = '';
    if (!Q.data.installed) { box.appendChild(M.suspendedBanner(t('mq_postfix_missing'))); } else if (!Q.data.active) { box.appendChild(M.suspendedBanner(t('mq_postfix_stopped'))); }
  }

  function overviewCard() {
    var input = el('input', {class: 'sig-input', id: 'fp-mq-q', name: 'q', type: 'search', maxlength: '100', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', value: Q.q});
    var form = el('form', {class: 'fp-form fp-mq-form', novalidate: '', role: 'search', 'aria-label': t('mq_find_label')}, [M.errorLine(), M.statusLine(),
      M.field('fp-mq-q', t('mq_find_label'), input, t('mq_find_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('mq_find')}),
        button('clear', t('mq_clear'), 'sig-btn--secondary', {hidden: ''}), button('retry-all', t('mq_retry_all')), button('refresh', t('mq_refresh'))])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var v = input.value.trim();
      if (Array.from(v).length > 100) { M.fieldError(form, input, t('mq_find_long')); return; }
      Q.q = v;
      Q.offset = 0;
      refreshList({busy: b, focus: '#fp-mq-q'}).then(function (ok) {
        if (ok && Q) { M.say(form, Q.data.total === 1 ? t('mq_found_1') : t('mq_found', {n: num(Q.data.total)})); }
      });
    });
    return M.card('fp-mq-top-h', t('mq_title'), [el('p', {class: 'fp-muted', text: t('mq_what')}), tabs(), form], 'fp-mq-top');
  }

  function range() {
    var d = Q.data;
    if (d.total === 1) { return t('mq_range_1'); }
    return t('mq_range', {from: num(Q.offset + 1), to: num(Math.min(d.total, Q.offset + d.messages.length)), total: num(d.total)});
  }
  /* who it is from and to, one under the other, each with its label */
  function people(m) {
    var to = [el('span', {class: 'fp-mq-addr', text: m.recipients.length ? m.recipients[0].address : '–'})];
    if (m.count > 1) { to.push(el('span', {class: 'fp-muted fp-mq-more', text: ' ' + t('mq_more', {n: num(m.count - 1)})})); }
    return [el('span', {class: 'fp-mq-line'}, [el('span', {class: 'fp-muted fp-mq-lbl', text: t('mq_col_from')}), el('span', {class: 'fp-mq-addr', text: m.sender || t('mq_no_sender')})]),
      el('span', {class: 'fp-mq-line'}, [el('span', {class: 'fp-muted fp-mq-lbl', text: t('mq_col_to')}), el('span', {class: 'fp-mq-to'}, to)])];
  }
  function reasonOf(m) {
    for (var i = 0; i < m.recipients.length; i++) { if (m.recipients[i].reason) { return m.recipients[i].reason; } }
    return '';
  }
  /* a message still in the pickup folder has no queue file yet: it can be looked at, nothing more */
  function actionable(m) { return m.queue !== 'maildrop'; }
  function rowActions(m) {
    var acts = [rowButton('view', 'mq_view_of', t('mq_view'), m.id)];
    if (!actionable(m)) {
      /* only the view */
    } else if (m.queue === 'hold') {
      acts.push(rowButton('release', 'mq_release_of', t('mq_release'), m.id), rowButton('row-delete', 'mq_delete_of', t('mq_delete'), m.id, 'sig-btn--secondary fp-btn-danger-text'));
    } else {
      acts.push(rowButton('retry', 'mq_retry_of', t('mq_retry'), m.id), rowButton('hold', 'mq_hold_of', t('mq_hold'), m.id));
    }
    return [el('div', {class: 'fp-mq-btns'}, acts)];
  }
  function row(m) {
    var why = reasonOf(m);
    return el('tr', {'data-fp-id': m.id, class: Q.sel[m.id] ? 'is-picked' : null}, [
      el('td', {class: 'fp-mq-pick'}, actionable(m) ? [el('input', {type: 'checkbox', 'data-fp-pick': m.id, 'aria-label': t('mq_select_of', {id: m.id}), checked: Q.sel[m.id] ? true : null})] : []),
      el('th', {scope: 'row', class: 'fp-mq-id'}, [el('span', {class: 'sig-mono', text: m.id}), stateOf(m.queue)]),
      el('td', {class: 'fp-mq-when'}, [el('span', {text: when(m.arrived) || '–'}), el('span', {class: 'fp-muted', text: m.size === null ? '–' : size(m.size)})]),
      el('td', {class: 'fp-mq-people'}, people(m)),
      el('td', {class: 'fp-mq-why', text: why || '–'}),
      el('td', {class: 'fp-mq-acts'}, rowActions(m))]);
  }

  function bulkBar() {
    var bar = el('div', {class: 'fp-mq-bulk', role: 'group', 'aria-label': t('mq_bulk')}, [el('span', {class: 'fp-mq-picked', role: 'status', 'data-fp-picked': ''})]);
    [['bulk-retry', 'mq_retry_sel'], ['bulk-hold', 'mq_hold_sel'], ['bulk-requeue', 'mq_requeue_sel'], ['bulk-release', 'mq_release_sel'], ['bulk-delete', 'mq_delete_sel']].forEach(function (x) {
      bar.appendChild(button(x[0], t(x[1]), 'sig-btn--sm sig-btn--secondary' + (x[0] === 'bulk-delete' ? ' fp-btn-danger-text' : '')));
    });
    return bar;
  }
  /* what the selection holds, and so which buttons mean something: parked messages can be released or deleted, the rest tried, parked or requeued */
  function picked() {
    var parked = [];
    var live = [];
    Q.data.messages.forEach(function (m) {
      if (Q.sel[m.id]) { (m.queue === 'hold' ? parked : live).push(m.id); }
    });
    return {parked: parked, live: live, n: parked.length + live.length};
  }
  function updateBulk() {
    var bar = Q.page.querySelector('.fp-mq-bulk');
    if (!bar) { return; }
    var p = picked();
    bar.querySelector('[data-fp-picked]').textContent = p.n === 0 ? t('mq_none_picked') : p.n === 1 ? t('mq_picked_1') : t('mq_picked', {n: num(p.n)});
    var flags = {'bulk-retry': p.live.length, 'bulk-hold': p.live.length, 'bulk-requeue': p.live.length, 'bulk-release': p.parked.length, 'bulk-delete': p.parked.length};
    Object.keys(flags).forEach(function (a) {
      var b = bar.querySelector('[data-fp-act="' + a + '"]');
      if (b && !b.hasAttribute('aria-busy')) { b.disabled = !flags[a]; }
    });
    var all = Q.page.querySelector('#fp-mq-all');
    var pickable = Q.data.messages.filter(actionable).length;
    all.disabled = pickable === 0;
    all.checked = p.n > 0 && p.n === pickable;
    all.indeterminate = p.n > 0 && p.n < pickable;
    var rows = Q.page.querySelectorAll('tr[data-fp-id]');
    for (var i = 0; i < rows.length; i++) { rows[i].classList.toggle('is-picked', Boolean(Q.sel[rows[i].getAttribute('data-fp-id')])); }
  }

  function pager() {
    if (Q.data.total <= PAGE) { return null; }
    var newer = button('newer', t('mq_newer'));
    var older = button('older', t('mq_older'));
    newer.disabled = Q.offset === 0;
    older.disabled = Q.offset + PAGE >= Q.data.total;
    return el('div', {class: 'fp-actions fp-mq-pager'}, [newer, older]);
  }

  function listCard() {
    var d = Q.data;
    var parts = [M.errorLine(), M.statusLine()];
    if (!d.messages.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t(Q.q || Q.queue ? 'mq_none_match' : 'mq_none')}));
    } else {
      parts.push(el('p', {class: 'fp-muted fp-mq-count', 'data-fp-count': '', text: range()}), el('p', {class: 'fp-muted', text: t('mq_park_what')}), bulkBar());
      var all = el('input', {type: 'checkbox', id: 'fp-mq-all', 'aria-label': t('mq_select_all')});
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-mq-list-h'}, [
        el('table', {class: 'sig-table fp-mq-table'}, [el('thead', null, [el('tr', null, [el('th', {scope: 'col', class: 'fp-mq-pick'}, [all]), th(t('mq_col_id')),
          th(t('mq_col_arrived')), th(t('mq_col_people')), th(t('mq_col_why')),
          el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('acct_actions')})])])]),
        el('tbody', null, d.messages.map(row))])]));
      var pg = pager();
      if (pg) { parts.push(pg); }
    }
    if (d.truncated) { parts.push(el('p', {class: 'fp-muted', 'data-fp-truncated': '', text: t('mq_truncated')})); }
    return M.card('fp-mq-list-h', t('mq_list_title'), parts, 'fp-mq-list');
  }

  function detailCard() {
    var o = Q.open;
    var m = find(o.id);
    var parts = [M.errorLine(), M.statusLine()];
    var meta = [['mq_col_state', [stateOf(m ? m.queue : o.queue)]]];
    if (m) {
      meta.push(['mq_col_arrived', [when(m.arrived) || '–']], ['mq_col_size', [m.size === null ? '–' : size(m.size)]], ['mq_col_from', [m.sender || t('mq_no_sender')]]);
    }
    var items = [];
    meta.forEach(function (x) { items.push(el('dt', {text: t(x[0])}), el('dd', null, x[1])); });
    parts.push(el('dl', {class: 'fp-mq-meta'}, items));
    if (m && m.recipients.length) {
      parts.push(el('h3', {class: 'fp-h3', id: 'fp-mq-to-h', text: t('mq_col_to')}),
        el('ul', {class: 'fp-mq-rcpts', 'aria-labelledby': 'fp-mq-to-h'}, m.recipients.map(function (r) {
          return el('li', null, [el('span', {class: 'fp-mq-addr', text: r.address}), r.reason ? el('span', {class: 'fp-muted fp-mq-reason', text: ' ' + r.reason}) : null]);
        })));
      if (m.count > m.recipients.length) { parts.push(el('p', {class: 'fp-muted', text: t('mq_more_rcpts', {n: num(m.count - m.recipients.length)})})); }
    }
    parts.push(el('h3', {class: 'fp-h3', id: 'fp-mq-headers-h', text: t('mq_headers')}),
      el('pre', {class: 'fp-mq-pre', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-mq-headers-h', 'data-fp-headers': '', text: o.headers || t('mq_nothing')}));
    if (o.body !== null) {
      parts.push(el('h3', {class: 'fp-h3', id: 'fp-mq-body-h', text: t('mq_text')}),
        el('pre', {class: 'fp-mq-pre', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-mq-body-h', 'data-fp-body': '', text: o.body || t('mq_nothing')}));
      if (o.truncated) { parts.push(el('p', {class: 'fp-muted', 'data-fp-cut': '', text: t('mq_text_cut')})); }
    }
    var acts = [];
    if (o.body === null) { acts.push(button('show-text', t('mq_show_text'))); }
    acts.push(button('close', t('mq_close')));
    parts.push(el('div', {class: 'fp-actions'}, acts));
    return M.card('fp-mq-detail-h', t('mq_detail_title', {id: o.id}), parts, 'fp-mq-detail');
  }

  /* ---- drawing ---- */
  /* redraws the cards named ('list', 'detail'); opts.focus is the selector of what takes focus afterwards */
  function draw(names, opts) {
    opts = opts || {};
    names.forEach(function (name) {
      var old = card(name);
      var made = name === 'list' ? listCard() : name === 'detail' && Q.open ? detailCard() : null;
      if (made) {
        made.setAttribute('data-fp-card', name);
        if (old) { old.replaceWith(made); } else { Q.page.appendChild(made); }
      } else if (old) {
        old.remove();
      }
    });
    updateTabs();
    notices();
    updateBulk();
    var target = opts.focus ? Q.page.querySelector(opts.focus) : null;
    if (target) { target.focus(); }
  }
  function cards() { return ['list'].concat(Q.open ? ['detail'] : []); }

  function load() {
    var mine = Q;
    return FP.call('get', 'mailQueue', undefined, {limit: String(PAGE), offset: String(Q.offset), queue: Q.queue, q: Q.q}).then(function (r) {
      if (Q !== mine) { return null; }
      var d = clean(r);
      /* messages left the queue meanwhile and the page asked for is past the end: the last page is shown instead */
      if (!d.messages.length && Q.offset > 0 && d.total > 0) {
        Q.offset = Math.floor((d.total - 1) / PAGE) * PAGE;
        return load();
      }
      Q.data = d;
      var keep = {};
      d.messages.forEach(function (m) { if (Q.sel[m.id]) { keep[m.id] = true; } });
      Q.sel = keep;
      return d;
    });
  }
  /* reads the list again and draws it; opts.busy is the button held while it runs. Answers whether it worked */
  function refreshList(opts) {
    var mine = Q;
    if (opts.busy) { UI.setBusy(opts.busy, true); }
    return load().then(function (d) {
      if (Q !== mine || !d) { return false; }
      if (opts.busy) { UI.setBusy(opts.busy, false); }
      draw(cards(), {focus: opts.focus});
      return true;
    }, function (err) {
      if (Q !== mine) { return false; }
      if (opts.busy) { UI.setBusy(opts.busy, false); }
      M.failed(Q.page.querySelector('.fp-mq-form'), err);
      return false;
    });
  }

  /* ---- doing things ---- */
  var DONE = {retry: 'mq_done_retry', hold: 'mq_done_hold', release: 'mq_done_release', requeue: 'mq_done_requeue', delete: 'mq_done_delete'};
  function resultText(action, r) {
    var out = [];
    if (r.done.length) { out.push(t(DONE[action] + (r.done.length === 1 ? '_1' : ''), {n: num(r.done.length)})); }
    if (r.refused.parked) { out.push(t(r.refused.parked === 1 ? 'mq_refused_parked_1' : 'mq_refused_parked', {n: num(r.refused.parked)})); }
    if (r.refused.not_parked) { out.push(t(r.refused.not_parked === 1 ? 'mq_refused_loose_1' : 'mq_refused_loose', {n: num(r.refused.not_parked)})); }
    if (r.refused.not_queued) { out.push(t(r.refused.not_queued === 1 ? 'mq_refused_early_1' : 'mq_refused_early', {n: num(r.refused.not_queued)})); }
    if (r.missing.length) { out.push(t(r.missing.length === 1 ? 'mq_gone_1' : 'mq_gone', {n: num(r.missing.length)})); }
    return out.join(' ');
  }
  /* the ids focus goes to when the one acted on may have left the view: itself, then the one after it, then the one before */
  function neighbours(id) {
    var rows = Q.data.messages;
    for (var i = 0; i < rows.length; i++) {
      if (rows[i].id === id) { return [id].concat(rows[i + 1] ? [rows[i + 1].id] : [], rows[i - 1] ? [rows[i - 1].id] : []); }
    }
    return [];
  }
  /* sends one action for the ids; near is the row focus stays by when it can */
  function act(action, ids, b, near) {
    var mine = Q;
    var order = near ? neighbours(near) : [];
    var list = card('list');
    UI.setBusy(b, true);
    UI.showError(list, '');
    M.say(list, '');
    return FP.call('post', 'mailQueueActions', {action: action, ids: ids}).then(function (raw) {
      if (Q !== mine) { return; }
      var r = cleanResult(raw);
      var text = resultText(action, r);
      r.done.concat(r.missing).forEach(function (id) { delete Q.sel[id]; });
      if (Q.open && (r.missing.indexOf(Q.open.id) >= 0 || ((action === 'delete' || action === 'requeue') && r.done.indexOf(Q.open.id) >= 0))) { Q.open = null; }
      return load().then(function (d) {
        if (Q !== mine || !d) { return; }
        var stay = order.filter(function (id) { return find(id); })[0];
        draw(cards(), {focus: stay ? viewOf(stay) : '#fp-mq-list-h'});
        if (r.done.length) { M.say(card('list'), text); } else { UI.showError(card('list'), text || t('api_failed')); }
      });
    }, function (err) {
      if (Q !== mine) { return; }
      UI.setBusy(b, false);
      /* the page is read again, so what it shows is what the queue holds; the server's words stay on it */
      load().then(function () {
        if (Q !== mine) { return; }
        draw(cards(), {focus: '#fp-mq-list-h'});
        UI.showError(card('list'), err.message);
      }, function () {
        UI.showError(list, err.message);
        b.focus();
      });
    });
  }

  function open(id, b) {
    var mine = Q;
    UI.setBusy(b, true);
    UI.showError(card('list'), '');
    FP.call('get', 'mailQueueMessage', undefined, {id: id}).then(function (r) {
      if (Q !== mine) { return; }
      UI.setBusy(b, false);
      var m = find(id);
      Q.open = {id: id, queue: ORDER.indexOf(r && r.queue) >= 0 ? r.queue : (m ? m.queue : 'deferred'), headers: str(r && r.headers, 40000), body: null, truncated: false};
      draw(['detail'], {focus: '#fp-mq-detail-h'});
    }, function (err) {
      if (Q !== mine) { return; }
      UI.setBusy(b, false);
      if (err && err.status === 404) {
        /* it left the queue (delivered, or taken out): the list is read again and says so */
        load().then(function () {
          if (Q !== mine) { return; }
          draw(cards(), {focus: '#fp-mq-list-h'});
          UI.showError(card('list'), err.message);
        }, function () { UI.showError(card('list'), err.message); b.focus(); });
        return;
      }
      UI.showError(card('list'), err.message);
      b.focus();
    });
  }
  function showText(b) {
    var mine = Q;
    var o = Q.open;
    UI.setBusy(b, true);
    UI.showError(card('detail'), '');
    FP.call('get', 'mailQueueBody', undefined, {id: o.id}).then(function (r) {
      if (Q !== mine || Q.open !== o) { return; }
      o.body = str(r && r.body, 70000);
      o.truncated = r && r.body_truncated === true;
      draw(['detail'], {focus: '[data-fp-body]'});
    }, function (err) {
      if (Q !== mine || Q.open !== o) { return; }
      UI.setBusy(b, false);
      UI.showError(card('detail'), err.message);
      b.focus();
    });
  }

  function retryAll(b) {
    var mine = Q;
    var form = Q.page.querySelector('.fp-mq-form');
    UI.showError(form, '');
    M.say(form, '');
    UI.setBusy(b, true);
    FP.call('post', 'mailQueueRetryAll', {}).then(load).then(function (d) {
      if (Q !== mine || !d) { return; }
      UI.setBusy(b, false);
      draw(cards());
      (b.disabled ? Q.page.querySelector('#fp-mq-q') : b).focus();
      M.say(form, t('mq_retry_all_done'));
    }).catch(function (err) {
      if (Q !== mine) { return; }
      UI.setBusy(b, false);
      M.failed(form, err);
      b.focus();
    });
  }

  /* a question in the bar for deleting the parked messages picked; Cancel takes focus, so a second Enter can't confirm it */
  function bulkAsk(b, ids) {
    var bar = b.closest('.fp-mq-bulk');
    if (bar.querySelector('.fp-mq-ask')) { return; }
    var qid = 'fp-mq-bulk-ask';
    var yes = button('bulk-delete-yes', t('mq_delete_yes'), 'sig-btn--sm sig-btn--danger', {'aria-describedby': qid});
    var no = button('bulk-delete-no', t('cancel'), 'sig-btn--sm sig-btn--secondary', {'aria-describedby': qid});
    bar.appendChild(el('span', {class: 'fp-mq-ask'}, [el('span', {class: 'fp-mq-ask-q', id: qid, text: t(ids.length === 1 ? 'mq_ask_delete_sel_1' : 'mq_ask_delete_sel', {n: num(ids.length)})}), yes, no]));
    b.hidden = true;
    no.focus();
  }
  function dropAsk() {
    var ask = Q.page.querySelector('.fp-mq-ask');
    if (!ask) { return false; }
    ask.remove();
    Q.page.querySelector('[data-fp-act="bulk-delete"]').hidden = false;
    return true;
  }

  function onClick(e) {
    var target = e.target.closest ? e.target : null;
    if (!target || !Q || !Q.page.contains(target)) { return; }
    var b = target.closest('[data-fp-act]');
    if (!b || b.disabled) { return; }
    var a = b.getAttribute('data-fp-act');
    var tr = b.closest('tr');
    var id = b.getAttribute('data-fp-id') || (tr ? tr.getAttribute('data-fp-id') : '') || '';
    if (a === 'queue') {
      var name = b.getAttribute('data-fp-queue');
      if (name === Q.queue) { return; }
      Q.queue = name;
      Q.offset = 0;
      refreshList({focus: '.fp-mq-tab[data-fp-queue="' + name + '"]'});
    } else if (a === 'clear') {
      Q.q = '';
      Q.offset = 0;
      Q.page.querySelector('#fp-mq-q').value = '';
      refreshList({focus: '#fp-mq-q'});
    } else if (a === 'refresh') {
      refreshList({busy: b, focus: '[data-fp-act="refresh"]'}).then(function (ok) {
        if (ok && Q) { M.say(Q.page.querySelector('.fp-mq-form'), t('mq_up_to_date')); }
      });
    } else if (a === 'retry-all') {
      retryAll(b);
    } else if (a === 'view') {
      open(id, b);
    } else if (a === 'close') {
      var from = Q.open.id;
      Q.open = null;
      draw(['detail'], {focus: find(from) ? viewOf(from) : '#fp-mq-list-h'});
    } else if (a === 'show-text') {
      showText(b);
    } else if (a === 'retry' || a === 'hold' || a === 'release') {
      act(a, [id], b, id);
    } else if (a === 'row-delete') {
      M.confirmIn(b.closest('.fp-mq-btns'), t('mq_ask_delete', {id: id}), 'row-delete-yes', t('mq_delete_yes'));
    } else if (a === 'row-delete-yes') {
      act('delete', [id], b, id);
    } else if (a === 'confirm-no') {
      var m = find(id);
      if (m) {
        var again = row(m);
        tr.replaceWith(again);
        again.querySelector('[data-fp-act="row-delete"]').focus();
      }
    } else if (a === 'newer' || a === 'older') {
      Q.offset = Math.max(0, Q.offset + (a === 'older' ? PAGE : -PAGE));
      refreshList({focus: '#fp-mq-list-h'});
    } else if (a === 'bulk-delete-yes') {
      act('delete', picked().parked, b, '');
    } else if (a === 'bulk-delete-no') {
      dropAsk();
      Q.page.querySelector('[data-fp-act="bulk-delete"]').focus();
    } else if (a === 'bulk-delete') {
      var parked = picked().parked;
      if (parked.length) { bulkAsk(b, parked); }
    } else if (a.indexOf('bulk-') === 0) {
      var p = picked();
      var what = a.slice(5);
      var ids = what === 'release' ? p.parked : p.live;
      if (ids.length) { act(what, ids, b, ''); }
    }
  }
  document.addEventListener('click', onClick);

  function onChange(e) {
    var box = e.target && e.target.closest ? e.target.closest('input[type="checkbox"]') : null;
    if (!box || !Q || !Q.page.contains(box)) { return; }
    var id = box.getAttribute('data-fp-pick');
    if (id) {
      if (box.checked) { Q.sel[id] = true; } else { delete Q.sel[id]; }
    } else if (box.id === 'fp-mq-all') {
      Q.sel = {};
      var boxes = Q.page.querySelectorAll('input[data-fp-pick]');
      for (var i = 0; i < boxes.length; i++) { boxes[i].checked = box.checked; }
      if (box.checked) { Q.data.messages.filter(actionable).forEach(function (m) { Q.sel[m.id] = true; }); }
    } else {
      return;
    }
    /* a question open in the bar is for the messages picked when it was asked: it goes when the picking changes */
    dropAsk();
    updateBulk();
  }
  document.addEventListener('change', onChange);

  FP.view('tool:mail_queue', function () {
    var tool = FP.tools.mail_queue;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('mq_desc'), cls: 'fp-mail fp-mq',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    Q = {page: page, data: null, queue: '', q: '', offset: 0, sel: {}, open: null};
    var mine = Q;
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    load().then(function (d) {
      if (Q !== mine || !d) { return; }
      page.textContent = '';
      page.appendChild(el('div', {class: 'fp-mq-notices'}));
      var top = overviewCard();
      top.setAttribute('data-fp-card', 'top');
      page.appendChild(top);
      draw(['list']);
    }, function (err) {
      if (Q !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

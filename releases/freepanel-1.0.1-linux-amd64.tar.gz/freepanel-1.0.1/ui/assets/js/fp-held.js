/* freePanel held outgoing mail (#/tool/mail_held), the admin panel's page for the mail local users sent with the
   sendmail command that was refused and set aside (docs/api.md, "Mail": GET /email/refused). It counts what is held
   for each user and says where it is; nothing is sent or removed from here. User names and the folder come from the
   server and are shown as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var OWNER_RE = /^(?:[a-z_][a-z0-9_.-]{0,31}|uid-[0-9]{1,10})$/;

  var H = null;

  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var owners = (Array.isArray(r.owners) ? r.owners : []).filter(function (o) {
      return o && OWNER_RE.test(typeof o.owner === 'string' ? o.owner : '') && typeof o.count === 'number' && isFinite(o.count) && o.count >= 0;
    }).map(function (o) { return {owner: o.owner, count: Math.floor(o.count)}; });
    owners.sort(function (a, b) { return b.count - a.count || (a.owner < b.owner ? -1 : 1); });
    return {dir: typeof r.dir === 'string' ? r.dir.slice(0, 4096) : '', owners: owners};
  }

  function heldCard() {
    var d = H.data;
    var total = d.owners.reduce(function (n, o) { return n + o.count; }, 0);
    var parts = [M.errorLine(), M.statusLine(),
      el('p', {class: 'fp-muted', text: t('hm_what')})];
    if (!d.owners.length) {
      parts.push(el('p', {'data-fp-hm-total': '', text: t('hm_none')}));
    } else {
      parts.push(el('p', {'data-fp-hm-total': '', text: t(total === 1 ? 'hm_total_1' : 'hm_total', {n: total.toLocaleString('en'), users: d.owners.length.toLocaleString('en')})}));
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-hm-h'}, [
        el('table', {class: 'sig-table fp-mail-table fp-hm-table'}, [el('thead', null, [el('tr', null, [
          el('th', {scope: 'col', text: t('hm_user')}), el('th', {scope: 'col', class: 'fp-num', text: t('hm_count')})])]),
        el('tbody', null, d.owners.map(function (o) {
          var uid = /^uid-([0-9]+)$/.exec(o.owner);
          return el('tr', {'data-fp-owner': o.owner}, [
            el('th', {scope: 'row', class: 'fp-hm-owner'}, uid ? [el('span', {text: t('hm_uid', {id: uid[1]})})] : [el('span', {class: 'sig-mono', text: o.owner})]),
            el('td', {class: 'fp-num', text: o.count.toLocaleString('en')})]);
        }))])]));
    }
    if (d.dir) {
      parts.push(el('p', {class: 'fp-hm-where'}, [t('hm_where_1') + ' ', el('code', {class: 'sig-mono', 'data-fp-hm-dir': '', text: d.dir}),
        ' ' + t('hm_where_2')]));
      parts.push(el('p', {class: 'fp-muted', text: t('hm_retry')}));
    }
    parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'refresh', text: t('hm_refresh')})]));
    return M.card('fp-hm-h', t('hm_title'), parts, 'fp-hm');
  }

  function render() {
    H.page.textContent = '';
    H.page.appendChild(heldCard());
  }

  function onClick(e) {
    var target = e.target.closest ? e.target : null;
    var b = target && H && H.page && H.page.contains(target) ? target.closest('[data-fp-act="refresh"]') : null;
    if (!b) { return; }
    var cardNode = H.page.querySelector('.fp-hm');
    UI.setBusy(b, true);
    UI.showError(cardNode, '');
    FP.call('get', 'mailRefused').then(function (r) {
      H.data = clean(r);
      render();
      var again = H.page.querySelector('[data-fp-act="refresh"]');
      again.focus();
      M.say(H.page.querySelector('.fp-hm'), t('hm_refreshed'));
    }, function (err) {
      UI.setBusy(b, false);
      UI.showError(cardNode, err.message);
      b.focus();
    });
  }
  document.addEventListener('click', onClick);

  FP.view('tool:mail_held', function () {
    var tool = FP.tools.mail_held;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('hm_desc'), cls: 'fp-mail fp-hm-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    H = {page: body, data: {dir: '', owners: []}};
    var mine = H;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'mailRefused').then(function (r) {
      if (H !== mine) { return; }
      H.data = clean(r);
      render();
    }, function (err) {
      if (H !== mine) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

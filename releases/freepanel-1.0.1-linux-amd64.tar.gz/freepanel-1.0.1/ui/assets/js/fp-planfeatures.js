/* freePanel feature sets in the admin panel (docs/api.md, "Packages"): #/tool/feature_sets chooses, for each package, which parts of
   the customer panel its accounts may use. A part turned off is hidden from those accounts, their team members and their tokens, and
   the server refuses its calls. The admin sets any package's set, a reseller its own packages'. What the server sends is drawn as text.
   The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var NAME_RE = /^[A-Za-z0-9][A-Za-z0-9_. -]{0,63}$/;
  var ID_RE = /^[a-z][a-z0-9_]{0,30}$/;
  var F = {page: null, packages: [], pick: '', data: null};

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var parts = (Array.isArray(r.parts) ? r.parts : []).map(function (p) {
      return p && ID_RE.test(str(p.id, 40)) ? {id: p.id, label: str(p.label, 80) || p.id, what: str(p.description, 300)} : null;
    }).filter(Boolean);
    var off = {};
    (Array.isArray(r.off) ? r.off : []).forEach(function (id) { if (typeof id === 'string' && ID_RE.test(id)) { off[id] = true; } });
    return {pkg: NAME_RE.test(str(r.package, 70)) ? r.package : F.pick, parts: parts, off: off};
  }
  function pickCard() {
    var sel = el('select', {class: 'sig-select', id: 'fp-fs-pkg', name: 'package'}, [el('option', {value: '', text: t('fs_pick')})]
      .concat(F.packages.map(function (n) { return el('option', {value: n, selected: n === F.pick ? true : null, text: n}); })));
    var form = el('form', {class: 'fp-form fp-mail-form fp-fs-pick', novalidate: ''}, [M.errorLine(), M.statusLine(), M.field('fp-fs-pkg', t('fs_package'), sel),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('fs_open')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      if (!sel.value) { M.fieldError(form, sel, t('fs_need_package')); return; }
      load(sel.value, form, b);
    });
    return M.card('fp-fs-pick-h', t('fs_pick_title'), [form], 'fp-fs-pickcard');
  }
  function setCard(say) {
    var d = F.data;
    var boxes = d.parts.map(function (p) {
      var id = 'fp-fs-' + p.id;
      var box = el('input', {type: 'checkbox', id: id, name: 'part', value: p.id, 'aria-describedby': id + '-hint'});
      box.checked = !d.off[p.id];
      return el('div', {class: 'sig-field fp-fs-part'}, [el('label', {class: 'fp-check', for: id}, [box, el('span', {text: p.label})]),
        el('span', {class: 'sig-hint', id: id + '-hint', text: p.what})]);
    });
    var form = el('form', {class: 'fp-form fp-mail-form fp-fs-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('fieldset', {class: 'fp-fieldset'}, [el('legend', {text: t('fs_parts', {pkg: d.pkg})})].concat(boxes)),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('fs_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var off = [].slice.call(form.querySelectorAll('input[name="part"]')).filter(function (x) { return !x.checked; }).map(function (x) { return x.value; });
      var page = F.page;
      UI.setBusy(b, true);
      FP.call('put', 'packageFeatures', {off: off}, d.pkg).then(function (r) {
        if (F.page !== page) { return; }
        F.data = clean(r);
        draw(t('fs_saved', {pkg: F.data.pkg}), '#fp-fs-set-h');
      }, function (err) {
        if (F.page !== page) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    var card = M.card('fp-fs-set-h', t('fs_set_title', {pkg: d.pkg}), [el('p', {class: 'fp-muted', text: t('fs_set_what')}), form], 'fp-fs-set');
    if (say) { M.say(form, say); }
    return card;
  }
  function draw(say, focus) {
    var page = F.page;
    page.textContent = '';
    page.appendChild(pickCard());
    if (F.data) { page.appendChild(setCard(say)); }
    var target = focus ? page.querySelector(focus) : null;
    if (target) { target.focus(); }
  }
  function load(name, form, b) {
    var page = F.page;
    UI.setBusy(b, true);
    FP.call('get', 'packageFeatures', undefined, name).then(function (r) {
      if (F.page !== page) { return; }
      F.pick = name;
      F.data = clean(r);
      draw('', '#fp-fs-set-h');
    }, function (err) {
      if (F.page !== page) { return; }
      UI.setBusy(b, false);
      M.failed(form, err);
    });
  }
  FP.view('tool:feature_sets', function () {
    var tool = FP.tools.feature_sets;
    if (!tool || FP.realm !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    F = {page: null, packages: [], pick: '', data: null};
    var body = FP.frame({title: tool.label, desc: t('fs_desc'), cls: 'fp-mail fp-fs',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    F.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'packages').then(function (r) {
      if (F.page !== body) { return; }
      F.packages = (r && Array.isArray(r.packages) ? r.packages : []).map(function (p) { return str(p && p.name, 70); })
        .filter(function (n) { return NAME_RE.test(n); }).sort();
      if (!F.packages.length) { body.textContent = ''; body.appendChild(FP.empty(t('fs_none_title'), t('fs_none'))); return; }
      draw('', '');
    }, function (err) {
      if (F.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

/* freePanel stats (docs/api.md, "Metrics"): the customer panel's Bandwidth (#/tool/bandwidth), Visitors (#/tool/visitors)
   and Error log (#/tool/error_log) pages under Stats and logs. Bandwidth shows what the account's sites sent, by UTC hour
   for the past day and by UTC day and month further back, from the figures the web module keeps; Visitors and Error log
   are the latest lines of the sites' logs, read when the page asks. Access logs (#/tool/access_logs) downloads each site's
   raw log and sets whether older days are kept in ~/logs. Everything from the server is shown as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;

  var DOMAIN_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var HOUR_RE = /^\d{4}-\d{2}-\d{2}T\d{2}$/;
  var DAY_RE = /^\d{4}-\d{2}-\d{2}$/;
  var PROTO_RE = /^[a-z0-9]{1,16}$/;
  var STEP = 100;   /* rows shown at a time on Visitors and Error log */

  function str(v) { return typeof v === 'string' ? v : ''; }
  function num(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? v : 0; }
  function count(n) { return Math.round(n).toLocaleString('en'); }
  var UNITS = ['KB', 'MB', 'GB', 'TB', 'PB'];
  function size(n) {
    if (n < 1024) { return t('size_bytes', {n: count(n)}); }
    var u = -1;
    do { n /= 1024; u++; } while (n >= 1024 && u < UNITS.length - 1);
    return (n < 10 ? n.toFixed(1) : count(n)) + ' ' + UNITS[u];
  }
  function when(iso) {
    var d = iso ? new Date(iso) : null;
    if (!d || isNaN(d.getTime())) { return ''; }
    return d.toLocaleString(undefined, {year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit'});
  }
  function frame(id, cls) {
    var tool = FP.tools[id];
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return null; }
    var g = FP.group(tool.group);
    return FP.frame({title: tool.label, desc: t('st_' + id + '_desc'), cls: 'fp-st ' + cls,
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
  }
  function card(id, title, children, cls) {
    return el('section', {class: 'sig-card fp-st-card' + (cls ? ' ' + cls : ''), 'aria-labelledby': id}, [el('div', {class: 'sig-card-body'},
      [el('h2', {class: 'fp-h2', id: id, tabindex: '-1', text: title})].concat(children))]);
  }
  function selectField(id, label, options, value) {
    var s = el('select', {class: 'sig-select', id: id}, options.map(function (o) {
      var opt = el('option', {value: o[0], text: o[1]});
      if (o[0] === value) { opt.selected = true; }
      return opt;
    }));
    return {select: s, field: el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: id, text: label}), s])};
  }
  function failedCard(page, title, err) {
    page.textContent = '';
    page.appendChild(FP.empty(title, err.message));
  }
  function remembered(key, names) {
    var v = UI.store.get(key);
    return v && names.indexOf(v) >= 0 ? v : names[0];
  }

  /* ================= Bandwidth ================= */
  var B = {page: null};
  function protoName(p) {
    var known = {http: t('st_proto_http'), smtp: t('st_proto_smtp'), imap: 'IMAP', pop3: 'POP3', ftp: 'FTP'};
    return known[p] || p.toUpperCase();
  }
  function series(m, re) {
    var out = {};
    if (m && typeof m === 'object') {
      Object.keys(m).forEach(function (k) { if (re.test(k)) { out[k] = num(m[k]); } });
    }
    return out;
  }
  function cleanBandwidth(r) {
    r = r && typeof r === 'object' ? r : {};
    var sites = (Array.isArray(r.sites) ? r.sites : []).filter(function (s) { return s && DOMAIN_RE.test(str(s.domain)); }).map(function (s) {
      var protos = {};
      var p = s.protocols && typeof s.protocols === 'object' ? s.protocols : {};
      Object.keys(p).forEach(function (k) {
        if (PROTO_RE.test(k) && p[k] && typeof p[k] === 'object') { protos[k] = {hours: series(p[k].hours, HOUR_RE), days: series(p[k].days, DAY_RE)}; }
      });
      return {domain: s.domain, protocols: protos};
    });
    var now = HOUR_RE.test(str(r.now)) ? new Date(r.now + ':00:00Z') : new Date();
    if (isNaN(now.getTime())) { now = new Date(); }
    return {sites: sites, now: now, truncated: r.truncated === true};
  }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function hourKey(d) { return d.getUTCFullYear() + '-' + pad(d.getUTCMonth() + 1) + '-' + pad(d.getUTCDate()) + 'T' + pad(d.getUTCHours()); }
  function dayKey(d) { return hourKey(d).slice(0, 10); }
  var MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  /* the time slots of a range, oldest first: {label, short, keys: [[kind, key]]}; months sum their days */
  function slots(range, now) {
    var out = [];
    var i;
    var d;
    if (range === 'day') {
      for (i = 23; i >= 0; i--) {
        d = new Date(now.getTime() - i * 3600000);
        out.push({label: t('st_hour_label', {day: MONTHS[d.getUTCMonth()] + ' ' + d.getUTCDate(), hour: pad(d.getUTCHours())}),
          short: pad(d.getUTCHours()), keys: [['hours', hourKey(d)]]});
      }
    } else if (range === 'week' || range === 'month') {
      var n = range === 'week' ? 7 : 30;
      for (i = n - 1; i >= 0; i--) {
        d = new Date(now.getTime() - i * 86400000);
        out.push({label: MONTHS[d.getUTCMonth()] + ' ' + d.getUTCDate(), short: String(d.getUTCDate()), keys: [['days', dayKey(d)]]});
      }
    } else {
      for (i = 11; i >= 0; i--) {
        var y = now.getUTCFullYear();
        var m = now.getUTCMonth() - i;
        while (m < 0) { m += 12; y--; }
        var keys = [];
        var days = new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
        for (var day = 1; day <= days; day++) { keys.push(['days', y + '-' + pad(m + 1) + '-' + pad(day)]); }
        out.push({label: MONTHS[m] + ' ' + y, short: MONTHS[m], keys: keys});
      }
    }
    return out;
  }
  function slotBytes(site, proto, slot) {
    var p = site.protocols[proto];
    if (!p) { return 0; }
    return slot.keys.reduce(function (sum, k) { return sum + (p[k[0]][k[1]] || 0); }, 0);
  }
  function protocolsOf(sites) {
    var all = {};
    sites.forEach(function (s) { Object.keys(s.protocols).forEach(function (p) { all[p] = true; }); });
    var order = ['http', 'smtp', 'imap', 'pop3', 'ftp'];
    return Object.keys(all).sort(function (a, b) {
      var x = order.indexOf(a);
      var y = order.indexOf(b);
      return (x < 0 ? 99 : x) - (y < 0 ? 99 : y) || (a < b ? -1 : 1);
    });
  }
  var RANGES = [['day', 'st_range_day'], ['week', 'st_range_week'], ['month', 'st_range_month'], ['year', 'st_range_year']];
  function bwChart(list, protos) {
    var totals = list.slots.map(function (slot) {
      return list.sites.reduce(function (sum, s) {
        return sum + protos.reduce(function (x, p) { return x + slotBytes(s, p, slot); }, 0);
      }, 0);
    });
    var top = Math.max.apply(null, totals.concat([0]));
    var total = totals.reduce(function (a, b) { return a + b; }, 0);
    var peak = totals.indexOf(top);
    var cols = list.slots.map(function (slot, i) {
      var pct = top ? Math.max(totals[i] ? 2 : 0, Math.round(totals[i] / top * 100)) : 0;
      var bar = el('div', {class: 'fp-st-bar' + (totals[i] ? '' : ' fp-st-bar--none')});
      bar.style.height = pct + '%';
      return el('div', {class: 'fp-st-col', title: slot.label + ': ' + size(totals[i])}, [bar]);
    });
    /* the first, middle and last slots' names under the bars */
    var n = list.slots.length;
    var marks = [0, Math.floor((n - 1) / 2), n - 1].map(function (i) { return el('span', {class: 'fp-st-mark', text: list.slots[i].label}); });
    var said = total ? t('st_chart_label', {total: size(total), peak: list.slots[peak].label, top: size(top)}) : t('st_chart_none');
    return {total: total, totals: totals, node: el('div', {class: 'fp-st-chart-wrap'}, [
      el('div', {class: 'fp-st-chart', role: 'img', 'aria-label': said, 'data-fp-chart': ''}, cols),
      el('div', {class: 'fp-st-marks', 'aria-hidden': 'true'}, marks)])};
  }
  function bwRender() {
    var page = B.page;
    var range = B.range;
    var shown = B.site ? B.data.sites.filter(function (s) { return s.domain === B.site; }) : B.data.sites;
    var protos = protocolsOf(B.data.sites);
    var list = {sites: shown, slots: slots(range, B.data.now)};
    page.textContent = '';
    var rangeSel = selectField('fp-st-range', t('st_range'), RANGES.map(function (r) { return [r[0], t(r[1])]; }), range);
    var siteSel = selectField('fp-st-site', t('st_site'), [['', t('st_all_sites')]].concat(B.names.map(function (n) { return [n, n]; })), B.site);
    var chart = bwChart(list, protos.length ? protos : ['http']);
    var table = el('table', {class: 'sig-table fp-st-table'}, [
      el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('st_when')}), el('th', {scope: 'col', class: 'fp-num', text: t('st_sent')})])]),
      el('tbody', null, list.slots.map(function (slot, i) {
        return el('tr', null, [el('th', {scope: 'row', text: slot.label}), el('td', {class: 'fp-num', text: size(chart.totals[i])})]);
      }).reverse())]);
    page.appendChild(card('fp-st-bw-h', t('st_bw_title'), [
      el('div', {class: 'fp-st-controls'}, [rangeSel.field, siteSel.field]),
      el('p', {class: 'fp-st-total', 'data-fp-total': ''}, [el('span', {text: t('st_total')}), el('strong', {text: size(chart.total)})]),
      chart.node,
      el('p', {class: 'fp-muted fp-st-utc', text: t('st_utc')}),
      el('details', {class: 'fp-st-numbers'}, [el('summary', {text: t('st_numbers')}),
        el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-label': t('st_numbers')}, [table])])], 'fp-st-bw'));
    rangeSel.select.addEventListener('change', function () {
      B.range = rangeSel.select.value;
      UI.store.set('fp.stats.range', B.range);
      bwRender();
      B.page.querySelector('#fp-st-range').focus();
    });
    siteSel.select.addEventListener('change', function () { bwSite(siteSel.select.value); });

    var rows = B.data.sites.map(function (s) {
      var by = protos.map(function (p) { return list.slots.reduce(function (sum, slot) { return sum + slotBytes(s, p, slot); }, 0); });
      return {domain: s.domain, by: by, total: by.reduce(function (a, b) { return a + b; }, 0)};
    }).sort(function (a, b) { return b.total - a.total || (a.domain < b.domain ? -1 : 1); });
    var parts = [];
    if (B.data.truncated) { parts.push(el('p', {class: 'sig-banner sig-banner--warn', role: 'note', text: t('st_bw_truncated')})); }
    parts.push(rows.length ? el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-st-sites-h'}, [
      el('table', {class: 'sig-table fp-st-table fp-st-sites'}, [el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('st_site')})]
        .concat(protos.length > 1 ? protos.map(function (p) { return el('th', {scope: 'col', class: 'fp-num', text: protoName(p)}); }) : [])
        .concat([el('th', {scope: 'col', class: 'fp-num', text: t('st_sent')})]))]),
      el('tbody', null, rows.map(function (r) {
        return el('tr', {'data-fp-site': r.domain}, [el('th', {scope: 'row', class: 'fp-st-name', text: r.domain})]
          .concat(protos.length > 1 ? r.by.map(function (b) { return el('td', {class: 'fp-num', text: size(b)}); }) : [])
          .concat([el('td', {class: 'fp-num', text: size(r.total)})]));
      }))])]) : el('p', {class: 'fp-muted', text: t('st_bw_no_sites')}));
    page.appendChild(card('fp-st-sites-h', t('st_by_site', {range: t(RANGES.filter(function (r) { return r[0] === range; })[0][1]).toLowerCase()}),
      parts, 'fp-st-bysite'));
  }
  /* one site: read from what is here, or asked for on its own when the full answer left sites out */
  function bwSite(name) {
    B.site = name;
    var have = !name || B.data.sites.some(function (s) { return s.domain === name; });
    if (have || !B.data.truncated) {
      bwRender();
      B.page.querySelector('#fp-st-site').focus();
      return;
    }
    var mine = B.page;
    FP.call('get', 'statsBandwidthSite', undefined, {name: B.account, domain: name}).then(function (r) {
      if (B.page !== mine) { return; }
      var one = cleanBandwidth(r).sites[0];
      if (one) { B.data.sites.push(one); }
      bwRender();
      B.page.querySelector('#fp-st-site').focus();
    }, function (err) {
      if (B.page !== mine) { return; }
      UI.announce(err.message);
      bwRender();
      B.page.querySelector('#fp-st-bw-h').after(el('div', {class: 'fp-alert', role: 'alert', text: err.message}));
    });
  }
  FP.view('tool:bandwidth', function () {
    B.page = null;
    var body = frame('bandwidth', 'fp-st-bw-page');
    if (!body) { return; }
    B.page = body;
    B.account = FP.account();
    B.site = '';
    B.range = remembered('fp.stats.range', ['month', 'day', 'week', 'year']);
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    /* the site list comes from Domains too, so a site the answer left out can still be chosen */
    Promise.all([FP.call('get', 'statsBandwidth', undefined, B.account),
      FP.call('get', 'domains', undefined, B.account).catch(function () { return null; })]).then(function (r) {
      if (B.page !== body) { return; }
      B.data = cleanBandwidth(r[0]);
      B.names = B.data.sites.map(function (s) { return s.domain; });
      (r[1] && Array.isArray(r[1].sites) ? r[1].sites : []).forEach(function (s) {
        var d = str(s && s.domain);
        if (DOMAIN_RE.test(d) && B.names.indexOf(d) < 0) { B.names.push(d); }
      });
      B.names.sort();
      bwRender();
    }, function (err) {
      if (B.page !== body) { return; }
      failedCard(body, FP.tools.bandwidth.label, err);
    });
  });

  /* ================= Visitors and Error log: a list of log lines ================= */
  /* the rows of a list, a filter over them and "show more"; render(row) makes one <tr> */
  function logTable(L, opts) {
    var q = L.filter.toLowerCase();
    var hits = q ? L.rows.filter(function (r) { return r.text.indexOf(q) >= 0; }) : L.rows;
    var shown = hits.slice(0, L.limit);
    var parts = [];
    parts.push(el('p', {class: 'fp-muted fp-st-count', role: 'status', 'data-fp-count': ''},
      [document.createTextNode(hits.length ? t(opts.countKey, {shown: count(shown.length), all: count(hits.length)}) : '')]));
    if (!L.rows.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': '', text: opts.none}));
    } else if (!hits.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('st_no_match')}));
    } else {
      parts.push(opts.wrap(shown.map(opts.render)));
    }
    if (hits.length > shown.length) {
      parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'more',
        text: t('st_more', {n: count(Math.min(STEP, hits.length - shown.length))})})]));
    }
    return parts;
  }
  function filterField(L, id, redraw) {
    var input = el('input', {class: 'sig-input', id: id, type: 'search', autocomplete: 'off', spellcheck: 'false', maxlength: '200',
      'aria-describedby': id + '-hint'});
    input.value = L.filter;
    input.addEventListener('input', function () {
      L.filter = input.value.trim();
      L.limit = STEP;
      redraw();
    });
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && input.value) { e.preventDefault(); input.value = ''; L.filter = ''; L.limit = STEP; redraw(); }
    });
    return el('div', {class: 'sig-field fp-st-filter'}, [el('label', {class: 'sig-label', for: id, text: t('st_filter')}), input,
      el('span', {class: 'sig-hint', id: id + '-hint', text: t('st_filter_hint')})]);
  }
  function listBody(L, opts) {
    var box = L.page.querySelector('[data-fp-list]');
    box.textContent = '';
    logTable(L, opts).forEach(function (n) { box.appendChild(n); });
  }
  function moreClick(L, opts) {
    L.page.addEventListener('click', function (e) {
      var b = e.target.closest && e.target.closest('[data-fp-act="more"]');
      if (!b || !L.page.contains(b)) { return; }
      var before = L.limit;
      L.limit += STEP;
      listBody(L, opts);
      var rows = L.page.querySelectorAll('[data-fp-list] [data-fp-row]');
      var first = rows[before];
      if (first) { first.setAttribute('tabindex', '-1'); first.focus(); }
    });
  }

  /* ---- Visitors ---- */
  var V = {page: null};
  function cleanHits(r) {
    r = r && typeof r === 'object' ? r : {};
    return {truncated: r.truncated === true, rows: (Array.isArray(r.hits) ? r.hits : []).filter(function (h) { return h && typeof h === 'object'; }).map(function (h) {
      var x = {time: str(h.time), ip: str(h.ip).slice(0, 64), method: str(h.method).slice(0, 16), path: str(h.path).slice(0, 2048),
        protocol: str(h.protocol).slice(0, 16), status: typeof h.status === 'number' && h.status >= 0 && h.status < 1000 ? h.status : 0,
        bytes: num(h.bytes), referrer: str(h.referrer).slice(0, 2048), agent: str(h.agent).slice(0, 512), https: h.https === true};
      x.text = [x.ip, x.method, x.path, String(x.status), x.referrer, x.agent].join(' ').toLowerCase();
      return x;
    })};
  }
  function statusClass(s) { return s >= 500 ? 'sig-pill sig-pill--danger' : (s >= 400 ? 'sig-pill sig-pill--warn' : 'sig-pill'); }
  var VISITS = {countKey: 'st_vis_count',
    wrap: function (rows) {
      var cols = [[t('st_time')], [t('st_ip')], [t('st_request')], [t('st_status')], [t('st_size'), 'fp-num'], [t('st_referrer')], [t('st_agent')]];
      return el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-st-vis-h'}, [
        el('table', {class: 'sig-table fp-st-table fp-st-visits'}, [el('thead', null, [el('tr', null, cols.map(function (c) {
          return el('th', {scope: 'col', class: c[1] || null, text: c[0]});
        }))]), el('tbody', null, rows)])]);
    },
    render: function (h) {
      return el('tr', {'data-fp-row': ''}, [el('td', {class: 'fp-st-time', text: when(h.time) || h.time || '—'}),
        el('td', {class: 'sig-mono', text: h.ip || '—'}),
        el('td', {class: 'fp-st-req'}, [el('span', {class: 'sig-mono', text: (h.method ? h.method + ' ' : '') + (h.path || '—')}),
          h.https ? el('span', {class: 'fp-st-https', text: 'HTTPS'}) : null]),
        el('td', null, [h.status ? el('span', {class: statusClass(h.status), text: String(h.status)}) : document.createTextNode('—')]),
        el('td', {class: 'fp-num', text: size(h.bytes)}),
        el('td', {class: 'fp-st-ref', text: h.referrer && h.referrer !== '-' ? h.referrer : '—'}),
        el('td', {class: 'fp-st-agent', text: h.agent && h.agent !== '-' ? h.agent : '—'})]);
    }};
  function vRender() {
    var page = V.page;
    page.textContent = '';
    if (!V.names.length) {
      page.appendChild(FP.empty(FP.tools.visitors.label, t('st_vis_no_sites')));
      return;
    }
    var siteSel = selectField('fp-st-vsite', t('st_site'), V.names.map(function (n) { return [n, n]; }), V.site);
    var reload = el('button', {class: 'sig-btn sig-btn--secondary fp-submit', type: 'button', 'data-fp-act': 'reload', text: t('st_reload')});
    var parts = [el('div', {class: 'fp-st-controls'}, [siteSel.field, filterField(V, 'fp-st-vfilter', function () { listBody(V, VISITS); }),
      el('div', {class: 'fp-st-reload'}, [reload])]), el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': ''})];
    if (V.truncated) { parts.push(el('p', {class: 'fp-muted', text: t('st_vis_truncated')})); }
    parts.push(el('div', {'data-fp-list': ''}));
    page.appendChild(card('fp-st-vis-h', t('st_vis_title', {site: V.site}), parts, 'fp-st-vis'));
    VISITS.none = t('st_vis_none', {site: V.site});
    listBody(V, VISITS);
    siteSel.select.addEventListener('change', function () {
      V.site = siteSel.select.value;
      UI.store.set('fp.stats.site', V.site);
      vLoad('#fp-st-vsite');
    });
    reload.addEventListener('click', function () { vLoad('[data-fp-act="reload"]'); });
  }
  function vLoad(focus) {
    var mine = V.page;
    var b = mine.querySelector('[data-fp-act="reload"]');
    UI.setBusy(b, true);
    if (mine.querySelector('[data-fp-error]')) { UI.showError(mine.querySelector('.fp-st-vis'), ''); }
    FP.call('get', 'statsVisitors', undefined, {name: V.account, domain: V.site}).then(function (r) {
      if (V.page !== mine) { return; }
      var c = cleanHits(r);
      V.rows = c.rows;
      V.truncated = c.truncated;
      V.limit = STEP;
      vRender();
      UI.announce(t('st_vis_loaded', {n: count(V.rows.length), site: V.site}));
      if (focus) { mine.querySelector(focus).focus(); }
    }, function (err) {
      if (V.page !== mine) { return; }
      UI.setBusy(b, false);
      V.rows = [];
      V.limit = STEP;
      listBody(V, VISITS);
      UI.showError(mine.querySelector('.fp-st-vis'), err.message);
    });
  }
  FP.view('tool:visitors', function () {
    V.page = null;
    var body = frame('visitors', 'fp-st-vis-page');
    if (!body) { return; }
    V.page = body;
    V.account = FP.account();
    V.rows = [];
    V.filter = '';
    V.limit = STEP;
    V.truncated = false;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    moreClick(V, VISITS);
    FP.call('get', 'domains', undefined, V.account).then(function (r) {
      if (V.page !== body) { return; }
      var sites = r && Array.isArray(r.sites) ? r.sites : [];
      V.names = sites.map(function (s) { return str(s && s.domain); }).filter(function (d) { return DOMAIN_RE.test(d); });
      V.site = remembered('fp.stats.site', V.names);
      vRender();
      if (V.names.length) { vLoad(''); }
    }, function (err) {
      if (V.page !== body) { return; }
      failedCard(body, FP.tools.visitors.label, err);
    });
  });

  /* ---- Error log ---- */
  var E = {page: null};
  function cleanErrors(r) {
    r = r && typeof r === 'object' ? r : {};
    return {truncated: r.truncated === true, rows: (Array.isArray(r.lines) ? r.lines : []).filter(function (l) { return l && typeof l === 'object'; }).map(function (l) {
      var x = {domain: DOMAIN_RE.test(str(l.domain)) ? l.domain : '', time: str(l.time), line: str(l.line).slice(0, 8192)};
      x.text = (x.domain + ' ' + x.line).toLowerCase();
      return x;
    })};
  }
  /* a list rather than a table: the lines are long, and read best full width at any size */
  var ERRORS = {countKey: 'st_err_count', none: '',
    wrap: function (rows) { return el('ol', {class: 'fp-st-errors', 'aria-labelledby': 'fp-st-err-h'}, rows); },
    render: function (l) {
      return el('li', {class: 'fp-st-error', 'data-fp-row': ''}, [el('p', {class: 'fp-st-error-head'}, [
        el('span', {class: 'fp-st-time', text: when(l.time) || t('st_no_time')}), el('span', {class: 'fp-st-name', text: l.domain || '—'})]),
        el('code', {class: 'fp-st-line', text: l.line})]);
    }};
  function eRender() {
    var page = E.page;
    page.textContent = '';
    var names = [];
    E.all.forEach(function (l) { if (l.domain && names.indexOf(l.domain) < 0) { names.push(l.domain); } });
    names.sort();
    var siteSel = selectField('fp-st-esite', t('st_site'), [['', t('st_all_sites')]].concat(names.map(function (n) { return [n, n]; })), E.site);
    var reload = el('button', {class: 'sig-btn sig-btn--secondary fp-submit', type: 'button', 'data-fp-act': 'reload', text: t('st_reload')});
    E.rows = E.site ? E.all.filter(function (l) { return l.domain === E.site; }) : E.all;
    var parts = [el('div', {class: 'fp-st-controls'}, [siteSel.field, filterField(E, 'fp-st-efilter', function () { listBody(E, ERRORS); }),
      el('div', {class: 'fp-st-reload'}, [reload])]), el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': ''})];
    if (E.truncated) { parts.push(el('p', {class: 'fp-muted', text: t('st_err_truncated')})); }
    parts.push(el('div', {'data-fp-list': ''}));
    page.appendChild(card('fp-st-err-h', t('st_err_title'), parts, 'fp-st-err'));
    ERRORS.none = E.site ? t('st_err_none_site', {site: E.site}) : t('st_err_none');
    listBody(E, ERRORS);
    siteSel.select.addEventListener('change', function () {
      E.site = siteSel.select.value;
      E.limit = STEP;
      eRender();
      E.page.querySelector('#fp-st-esite').focus();
    });
    reload.addEventListener('click', function () { eLoad(true); });
  }
  function eLoad(again) {
    var mine = E.page;
    var b = mine.querySelector('[data-fp-act="reload"]');
    UI.setBusy(b, true);
    FP.call('get', 'statsErrors', undefined, E.account).then(function (r) {
      if (E.page !== mine) { return; }
      var c = cleanErrors(r);
      E.all = c.rows;
      E.truncated = c.truncated;
      E.limit = STEP;
      eRender();
      if (again) {
        UI.announce(t('st_err_loaded', {n: count(E.all.length)}));
        mine.querySelector('[data-fp-act="reload"]').focus();
      }
    }, function (err) {
      if (E.page !== mine) { return; }
      if (!again) { failedCard(mine, FP.tools.error_log.label, err); return; }
      UI.setBusy(b, false);
      UI.showError(mine.querySelector('.fp-st-err'), err.message);
    });
  }
  FP.view('tool:error_log', function () {
    E.page = null;
    var body = frame('error_log', 'fp-st-err-page');
    if (!body) { return; }
    E.page = body;
    E.account = FP.account();
    E.all = [];
    E.rows = [];
    E.site = '';
    E.filter = '';
    E.limit = STEP;
    E.truncated = false;
    moreClick(E, ERRORS);
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    eLoad(false);
  });

  /* ================= Access logs ================= */
  /* each site's raw log for download (the previous day and today so far, gzip), and whether older days are kept in ~/logs */
  var A = {page: null};
  function rawHref(site, ssl) {
    return '/api/v1/accounts/' + encodeURIComponent(A.account) + '/stats/raw?domain=' + encodeURIComponent(site) + (ssl ? '&ssl=1' : '');
  }
  function cleanLogSettings(r) {
    r = r && typeof r === 'object' ? r : {};
    return {archive: r.archive_logs === true, remove: r.remove_previous_archive === true, archiveDefault: r.archive_logs_default !== false,
      removeDefault: r.remove_previous_archive_default !== false, available: r.available !== false};
  }
  function aDownloadCard() {
    var parts = [el('p', {class: 'fp-muted', text: t('st_raw_what')})];
    if (!A.names.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('st_raw_no_sites')}));
    } else {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-st-raw-h'}, [
        el('table', {class: 'sig-table fp-st-table fp-st-raw'}, [el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('st_site')}),
          el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('st_raw_downloads')})])])]),
        el('tbody', null, A.names.map(function (n) {
          return el('tr', {'data-fp-site': n}, [el('th', {scope: 'row', class: 'fp-st-name', text: n}), el('td', {class: 'fp-st-raw-acts'}, [
            el('a', {class: 'sig-btn sig-btn--secondary sig-btn--sm', href: rawHref(n, false), download: n + '.gz',
              'aria-label': t('st_raw_http_of', {site: n}), text: t('st_raw_http')}),
            el('a', {class: 'sig-btn sig-btn--secondary sig-btn--sm', href: rawHref(n, true), download: n + '-ssl_log.gz',
              'aria-label': t('st_raw_https_of', {site: n}), text: t('st_raw_https')})])]);
        }))])]));
    }
    parts.push(el('p', {class: 'fp-muted', text: t('st_raw_busy')}));
    return card('fp-st-raw-h', t('st_raw_title'), parts, 'fp-st-rawcard');
  }
  function aCheck(name, label, checked, follows) {
    return el('div', {class: 'fp-st-opt'}, [el('label', {class: 'fp-check'}, [
      el('input', {type: 'checkbox', name: name, checked: checked ? true : null, 'aria-describedby': 'fp-st-' + name + '-hint'}), el('span', {text: label})]),
      el('span', {class: 'sig-hint', id: 'fp-st-' + name + '-hint', text: follows ? t('st_arch_follows') : t('st_arch_own')})]);
  }
  function aSettingsCard() {
    var c = A.settings;
    var form = el('form', {class: 'fp-form fp-st-arch', novalidate: ''}, [el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': ''}),
      el('p', {class: 'fp-ok-line', role: 'status', 'data-fp-status': ''}),
      c.available ? null : el('p', {class: 'sig-banner sig-banner--warn', role: 'note', text: t('st_arch_unavailable')}),
      el('fieldset', {class: 'fp-st-fieldset'}, [el('legend', {class: 'sig-vh', text: t('st_arch_title')}),
        aCheck('archive_logs', t('st_arch_keep'), c.archive, c.archiveDefault),
        aCheck('remove_previous_archive', t('st_arch_remove'), c.remove, c.removeDefault)]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('st_arch_save')}),
        c.archiveDefault && c.removeDefault ? null : el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'arch-default',
          text: t('st_arch_default')})])]);
    function put(body, b, said) {
      UI.showError(form, '');
      form.querySelector('[data-fp-status]').textContent = '';
      UI.setBusy(b, true);
      var mine = A.page;
      FP.call('put', 'statsLogs', body, A.account).then(function (r) {
        if (A.page !== mine) { return; }
        A.settings = cleanLogSettings(r);
        var fresh = aSettingsCard();
        form.closest('.fp-st-archcard').replaceWith(fresh);
        fresh.querySelector('[data-fp-status]').textContent = said;
        fresh.querySelector('#fp-st-arch-h').focus();
      }, function (err) {
        if (A.page !== mine) { return; }
        UI.setBusy(b, false);
        UI.showError(form, err.message);
      });
    }
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = form.querySelector('.fp-submit');
      if (b.disabled) { return; }
      var body = {};
      var keep = form.querySelector('[name="archive_logs"]').checked;
      var remove = form.querySelector('[name="remove_previous_archive"]').checked;
      if (keep !== c.archive) { body.archive_logs = keep; }
      if (remove !== c.remove) { body.remove_previous_archive = remove; }
      if (!Object.keys(body).length) {
        UI.showError(form, '');
        form.querySelector('[data-fp-status]').textContent = t('st_arch_unchanged');
        return;
      }
      put(body, b, t('st_arch_saved'));
    });
    var back = form.querySelector('[data-fp-act="arch-default"]');
    if (back) { back.addEventListener('click', function () { put({default: true}, back, t('st_arch_defaulted')); }); }
    return card('fp-st-arch-h', t('st_arch_title'), [el('p', {class: 'fp-muted', text: t('st_arch_what')}), form], 'fp-st-archcard');
  }
  FP.view('tool:access_logs', function () {
    A.page = null;
    var body = frame('access_logs', 'fp-st-raw-page');
    if (!body) { return; }
    A.page = body;
    A.account = FP.account();
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all([FP.call('get', 'domains', undefined, A.account), FP.call('get', 'statsLogs', undefined, A.account)]).then(function (r) {
      if (A.page !== body) { return; }
      var sites = r[0] && Array.isArray(r[0].sites) ? r[0].sites : [];
      A.names = sites.map(function (s) { return str(s && s.domain); }).filter(function (d) { return DOMAIN_RE.test(d); });
      A.settings = cleanLogSettings(r[1]);
      body.textContent = '';
      body.appendChild(aDownloadCard());
      body.appendChild(aSettingsCard());
    }, function (err) {
      if (A.page !== body) { return; }
      failedCard(body, FP.tools.access_logs.label, err);
    });
  });
})();

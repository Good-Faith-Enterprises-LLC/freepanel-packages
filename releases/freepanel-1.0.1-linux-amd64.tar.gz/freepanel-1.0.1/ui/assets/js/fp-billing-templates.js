/* freePanel billing message templates (#/tool/billing_templates; docs/api.md, "Billing: messages"; docs/billing/navigation-map.md, "Message
   templates"): the sending settings above the kinds of message with their subject; a kind opens its editor with the placeholders it takes
   listed and a preview filled in for a client; a changed one goes back to the panel's own wording after a question. Plain text only. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;
  var M = FP.mail;

  var TPL = {kind: [40], subject: [200], body: [10000], changed: 'b', updated: 'w'};
  function cleanTpl(x) { var v = B.pick(x, TPL); if (!v || !/^[a-z_]{1,40}$/.test(v.kind)) { return null; } v.placeholders = B.words(x.placeholders, /^[a-z_]{1,40}$/, 30); return v; }
  FP.view('tool:billing_templates', function () {
    var page = B.frame('billing_templates', 'fp-btp');
    if (!page) { return; }
    var alive = function () { return page.isConnected; };
    var mailBox = el('div');
    var listBox = el('div', {class: 'fp-btp-kinds'});
    var editBox = el('div');
    function mailCard(v, said) {
      var specs = [{name: 'enabled', label: t('btp_enabled'), kind: 'check', hint: t('btp_enabled_hint')}, {name: 'from', label: t('btp_from'), max: 254, code: true, hint: t('btp_from_hint'), send_empty: true},
        {name: 'copy_billing_contacts', label: t('btp_copy'), kind: 'check', hint: t('btp_copy_hint')}];
      var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bil_save_changes')});
      var form = el('form', {class: 'fp-form fp-bil-crud-form fp-btp-mail', novalidate: '', 'aria-labelledby': 'fp-btp-mail-h'}, [M.errorLine(), M.statusLine(),
        v.enabled_since ? el('p', {class: 'fp-muted fp-row-note', text: t('btp_since', {when: B.when(v.enabled_since)})}) : null,
        el('div', {class: 'fp-bil-grid'}, B.fieldsOf('fp-btp-m', specs, v)), el('div', {class: 'fp-actions'}, [save])]);
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!B.begin(form, save)) { return; }
        var body = B.readFields(form, specs, v);
        if (!body) { return; }
        if (!Object.keys(body).length) { M.say(form, t('bil_nothing_changed')); return; }
        UI.setBusy(save, true);
        FP.call('patch', 'billingMail', body).then(function (r) {
          if (!alive()) { return; }
          mailBox.textContent = '';
          mailBox.appendChild(mailCard(cleanMail(r), t('btp_mail_saved')));
          mailBox.querySelector('#fp-btp-mail-h').focus();
        }, function (err) {
          if (!alive()) { return; }
          UI.setBusy(save, false);
          B.failed(form, err);
        });
      });
      var c = B.card('fp-btp-mail-h', t('btp_sending'), [el('p', {class: 'fp-muted', text: t('btp_sending_what')}), form], 'fp-btp-mail-card', 'mail');
      if (said) { M.say(form, said); }
      return c;
    }
    function cleanMail(r) { return B.pick(r, {enabled: 'b', from: [254], copy_billing_contacts: 'b', enabled_since: 'w'}) || {}; }
    function listCard(list, said) {
      var c = B.card('fp-btp-h', t('btp_kinds'), [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t('btp_kinds_what')}),
        B.table('fp-btp-h', 'fp-btp-table', [B.th(t('btp_col_kind')), B.th(t('btp_col_subject')), B.th(t('btp_col_wording')), el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('acct_actions')})])],
          list.map(function (x) {
            return el('tr', {'data-fp-kind': x.kind}, [el('th', {scope: 'row', text: B.word('mkind', x.kind)}), el('td', {class: 'fp-bil-wrap', text: x.subject}),
              el('td', null, [B.pill(t(x.changed ? 'btp_yours' : 'btp_default'), x.changed ? 'accent' : '')]),
              el('td', {class: 'fp-bil-acts'}, [B.button('edit', t('bil_change'), 'sig-btn--secondary sig-btn--sm', {'data-fp-kind': x.kind, 'aria-label': t('bil_change_of', {name: B.word('mkind', x.kind)})})])]);
          }))], 'fp-btp-list', 'list');
      if (said) { M.say(c, said); }
      return c;
    }
    function editor(v) {
      var subject = B.input('fp-btp-e-subject', 'subject', v.subject, {maxlength: '200', 'aria-required': 'true'});
      var body = el('textarea', {class: 'sig-input fp-bil-text', id: 'fp-btp-e-body', name: 'body', rows: '12', maxlength: '10000', 'aria-required': 'true'});
      body.value = v.body;
      var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('btp_save')});
      var acts = el('div', {class: 'fp-actions', 'data-fp-acts': ''}, [save, v.changed ? B.button('reset', t('btp_reset'), 'sig-btn--secondary fp-btn-danger-text') : null, B.button('close', t('btp_close'))]);
      var form = el('form', {class: 'fp-form fp-bil-crud-form fp-btp-edit', novalidate: '', 'aria-labelledby': 'fp-btp-e-h'}, [M.errorLine(), M.statusLine(),
        M.field('fp-btp-e-subject', t('btp_col_subject'), subject), M.field('fp-btp-e-body', t('btp_body'), body, t('btp_body_hint')),
        el('div', {class: 'fp-btp-place'}, [el('p', {class: 'sig-label', text: t('btp_places')}), el('ul', {class: 'fp-btp-place-list'}, v.placeholders.map(function (p) { return el('li', null, [el('code', {text: '{' + p + '}'})]); }))]),
        acts]);
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!B.begin(form, save)) { return; }
        if (!subject.value.trim()) { M.fieldError(form, subject, t('bil_needed', {name: t('btp_col_subject')})); return; }
        if (!body.value.trim()) { M.fieldError(form, body, t('bil_needed', {name: t('btp_body')})); return; }
        UI.setBusy(save, true);
        FP.call('put', 'billingTemplate', {subject: subject.value.trim(), body: body.value}, {kind: v.kind}).then(function (r) {
          if (alive()) { open(v.kind, t('btp_saved'), cleanTpl(r)); }
        }, function (err) {
          if (!alive()) { return; }
          UI.setBusy(save, false);
          B.failed(form, err);
        });
      });
      form.addEventListener('click', function (e) {
        var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
        if (!b || b.disabled) { return; }
        var a = b.getAttribute('data-fp-act');
        if (a === 'reset') {
          M.confirmIn(acts, t('btp_reset_ask'), 'reset-yes', t('btp_reset'));
        } else if (a === 'reset-yes') {
          UI.setBusy(b, true);
          FP.call('del', 'billingTemplate', undefined, {kind: v.kind}).then(function (r) { if (alive()) { open(v.kind, t('btp_reset_done'), cleanTpl(r)); } }, function (err) {
            if (!alive()) { return; }
            open(v.kind).then(function () { UI.showError(page.querySelector('.fp-btp-edit'), err.message); });
          });
        } else if (a === 'confirm-no') {
          open(v.kind, '', v).then(function () { var r = page.querySelector('[data-fp-act="reset"]'); if (r) { r.focus(); } });
        }
      });
      var picker = B.clientPicker('fp-btp-p-client', {label: t('btp_p_client'), placeholder: t('binv_pick_client'), required: true});
      var inv = B.input('fp-btp-p-invoice', 'invoice_id', '', {inputmode: 'numeric', maxlength: '10', class: 'sig-input fp-bil-amount'});
      var see = el('button', {class: 'sig-btn sig-btn--secondary fp-submit', type: 'submit', text: t('btp_preview')});
      var out = el('div', {'data-fp-preview': ''});
      var pform = el('form', {class: 'fp-form fp-bil-crud-form fp-btp-preview', novalidate: '', 'aria-labelledby': 'fp-btp-p-h'}, [M.errorLine(),
        el('div', {class: 'fp-bil-grid'}, [picker.node, M.field('fp-btp-p-invoice', t('btp_p_invoice'), inv, t('btp_p_invoice_hint'))]), el('div', {class: 'fp-actions'}, [see]), out]);
      pform.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!B.begin(pform, see)) { return; }
        if (!picker.select.value) { M.fieldError(pform, picker.select, t('binv_client_needed')); return; }
        var q = {customer_id: Number(picker.select.value)};
        if (inv.value.trim()) {
          if (!/^[1-9][0-9]{0,9}$/.test(inv.value.trim())) { M.fieldError(pform, inv, t('bil_number_bad')); return; }
          q.invoice_id = Number(inv.value.trim());
        }
        UI.setBusy(see, true);
        FP.call('post', 'billingTemplatePreview', q, {kind: v.kind}).then(function (r) {
          if (!alive()) { return; }
          UI.setBusy(see, false);
          out.textContent = '';
          out.appendChild(el('div', {class: 'fp-btp-shown'}, [B.facts([[t('btp_to'), B.str(r && r.to, 254)], [t('btp_col_subject'), B.str(r && r.subject, 400)]]),
            el('pre', {class: 'fp-bob-body', 'data-fp-preview-body': '', text: B.str(r && r.body, 20000)})]));
        }, function (err) {
          if (!alive()) { return; }
          UI.setBusy(see, false);
          B.failed(pform, err);
        });
      });
      return [B.card('fp-btp-e-h', t('btp_edit_title', {name: B.word('mkind', v.kind)}), [el('p', {class: 'fp-muted', text: t(v.changed ? 'btp_edit_yours' : 'btp_edit_default')}), form], 'fp-btp-edit-card', 'edit'),
        B.card('fp-btp-p-h', t('btp_preview_title'), [el('p', {class: 'fp-muted', text: t('btp_preview_what')}), pform], 'fp-btp-p-card', 'preview')];
    }
    function open(kind, said, have) {
      return (have ? Promise.resolve(have) : FP.call('get', 'billingTemplate', undefined, {kind: kind}).then(cleanTpl)).then(function (v) {
        if (!alive() || !v) { return; }
        editBox.textContent = '';
        editor(v).forEach(function (n) { editBox.appendChild(n); });
        if (said) { M.say(editBox.querySelector('.fp-btp-edit'), said); }
        editBox.querySelector('#fp-btp-e-h').focus();
        return FP.call('get', 'billingTemplates').then(function (r) {
          if (!alive()) { return; }
          listBox.textContent = '';
          listBox.appendChild(listCard((r && Array.isArray(r.templates) ? r.templates : []).map(cleanTpl).filter(Boolean)));
        }, function () { /* the list stays as it was */ });
      }, function (err) {
        if (!alive()) { return; }
        UI.showError(page.querySelector('.fp-btp-list'), err.message);
      });
    }
    page.addEventListener('click', function (e) {
      var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
      if (!b || b.disabled || !alive()) { return; }
      var a = b.getAttribute('data-fp-act');
      if (a === 'edit') {
        open(b.getAttribute('data-fp-kind'));
      } else if (a === 'close') {
        var k = page.querySelector('.fp-btp-edit-card') ? editBox.querySelector('#fp-btp-e-subject') : null;
        editBox.textContent = '';
        var back = k ? page.querySelector('[data-fp-act="edit"]') : null;
        if (back) { back.focus(); }
      } else if (a === 'reload') {
        FP.route(true);
      }
    });
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all([FP.call('get', 'billingMail'), FP.call('get', 'billingTemplates')]).then(function (r) {
      if (!alive()) { return; }
      mailBox.appendChild(mailCard(cleanMail(r[0])));
      listBox.appendChild(listCard((r[1] && Array.isArray(r[1].templates) ? r[1].templates : []).map(cleanTpl).filter(Boolean)));
      B.screen(page, [mailBox, listBox, editBox]);
    }, function (err) {
      if (!alive()) { return; }
      B.screen(page, [FP.empty(t('btp_kinds'), err.message, B.button('reload', t('bil_try_again')))]);
    });
  });
})();

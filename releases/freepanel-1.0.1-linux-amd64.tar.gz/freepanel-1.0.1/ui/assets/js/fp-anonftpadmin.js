/* freePanel anonymous FTP for the server (#/tool/anonymous_ftp_server), the admin panel's page for the server's switch and
   limits (docs/api.md, "Anonymous FTP"): on or off, uploads (only with the risk accepted), the most anonymous sessions at
   once and each session's speed, and the accounts that turned it on, with why one isn't served. Only the server's admin
   sees it. What the server sends is drawn as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var USER_RE = /^[a-z_][a-z0-9_-]{0,31}$/;
  var X = null;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function num(v, lo, hi, d) { return typeof v === 'number' && isFinite(v) && v >= lo && v <= hi ? Math.floor(v) : d; }
  function clean(r) {
    if (!r || typeof r !== 'object' || !r.server || typeof r.server !== 'object') { return null; }
    var s = r.server;
    return {enabled: s.enabled === true, uploads: s.uploads === true, sessions: num(s.max_sessions, 1, 500, 20), kbps: num(s.kbps, 0, 1048576, 0),
      blocked: str(r.blocked),
      accounts: (Array.isArray(r.accounts) ? r.accounts : []).slice(0, 2000).filter(function (a) { return a && USER_RE.test(str(a.username, 40)); }).map(function (a) {
        return {username: a.username, ip: /^[0-9a-f.:]{2,45}$/i.test(str(a.ip, 45)) ? a.ip : '', uploads: a.uploads === true,
          serving: a.serving === true, uploadsOpen: a.uploads_open === true, problem: str(a.problem)};
      })};
  }

  function settingsCard() {
    var s = X.s;
    var parts = [];
    if (s.blocked) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-aftp-blocked': ''}, [UI.icon(FP.ui, 'ui_warning'),
        el('span', {text: t('aftp_s_blocked', {why: s.blocked})})]));
    }
    var on = el('input', {type: 'checkbox', id: 'fp-aftps-on', name: 'enabled', checked: s.enabled ? true : null, 'aria-describedby': 'fp-aftps-on-hint'});
    var up = el('input', {type: 'checkbox', id: 'fp-aftps-up', name: 'uploads', checked: s.uploads ? true : null, disabled: s.enabled ? null : true,
      'aria-describedby': 'fp-aftps-up-hint'});
    var risk = el('input', {type: 'checkbox', id: 'fp-aftps-risk', name: 'accept_upload_risk', checked: s.uploads ? true : null,
      'aria-describedby': 'fp-aftps-risk-text'});
    var riskBox = el('div', {class: 'fp-aftp-risk', 'data-fp-aftp-risk': '', hidden: up.checked && !up.disabled ? null : true}, [
      el('div', {class: 'sig-banner sig-banner--warn', role: 'note'}, [UI.icon(FP.ui, 'ui_warning'), el('span', {id: 'fp-aftps-risk-text', text: t('aftp_s_risk')})]),
      el('label', {class: 'fp-check', for: 'fp-aftps-risk'}, [risk, el('span', {text: t('aftp_s_risk_accept')})])]);
    var sessions = el('input', {class: 'sig-input fp-aftp-num', id: 'fp-aftps-sessions', name: 'max_sessions', type: 'number', inputmode: 'numeric',
      min: '1', max: '500', step: '1', value: String(s.sessions)});
    var kbps = el('input', {class: 'sig-input fp-aftp-num', id: 'fp-aftps-kbps', name: 'kbps', type: 'number', inputmode: 'numeric',
      min: '0', max: '1048576', step: '1', value: String(s.kbps)});
    var form = el('form', {class: 'fp-form fp-aftp-form', novalidate: ''}, [
      M.errorLine(), M.statusLine(),
      el('label', {class: 'fp-check', for: 'fp-aftps-on'}, [on, el('span', {text: t('aftp_s_on')})]),
      el('span', {class: 'sig-hint', id: 'fp-aftps-on-hint', text: t('aftp_s_on_hint')}),
      el('label', {class: 'fp-check', for: 'fp-aftps-up'}, [up, el('span', {text: t('aftp_s_uploads')})]),
      el('span', {class: 'sig-hint', id: 'fp-aftps-up-hint', text: t('aftp_s_uploads_hint')}),
      riskBox,
      el('div', {class: 'fp-aftp-limits'}, [
        M.field('fp-aftps-sessions', t('aftp_s_sessions'), sessions, t('aftp_s_sessions_hint')),
        M.field('fp-aftps-kbps', t('aftp_s_kbps'), kbps, t('aftp_s_kbps_hint'))]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('aftp_s_save')})])]);
    on.addEventListener('change', function () {
      up.disabled = !on.checked;
      if (!on.checked) { up.checked = false; }
      riskBox.hidden = !(up.checked && !up.disabled);
    });
    up.addEventListener('change', function () {
      riskBox.hidden = !up.checked;
      if (up.checked) { risk.checked = false; }
    });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var n = sessions.value.trim();
      if (!/^[0-9]{1,3}$/.test(n) || Number(n) < 1 || Number(n) > 500) { M.fieldError(form, UI.fieldNamed(form, 'max_sessions'), t('aftp_s_sessions_bad')); return; }
      var k = kbps.value.trim();
      if (!/^[0-9]{1,7}$/.test(k) || Number(k) > 1048576) { M.fieldError(form, UI.fieldNamed(form, 'kbps'), t('aftp_s_kbps_bad')); return; }
      if (up.checked && !risk.checked) { M.fieldError(form, UI.fieldNamed(form, 'accept_upload_risk'), t('aftp_s_risk_needed')); return; }
      var body = {enabled: on.checked, uploads: on.checked && up.checked, max_sessions: Number(n), kbps: Number(k)};
      if (body.uploads) { body.accept_upload_risk = true; }
      var mine = X;
      UI.setBusy(b, true);
      M.say(form, t('aftp_s_saving'));
      FP.call('put', 'anonFtpServer', body).then(function (r) {
        if (X !== mine) { return; }
        var next = clean(r);
        if (next) { X.s = next; }
        render();
        var card = X.page.querySelector('.fp-aftp-server');
        card.querySelector('.fp-submit').focus();
        M.say(card, t(X.s.enabled ? (X.s.uploads ? 'aftp_s_saved_uploads' : 'aftp_s_saved_on') : 'aftp_s_saved_off'));
      }, function (err) {
        if (X !== mine) { return; }
        UI.setBusy(b, false);
        M.say(form, '');
        M.failed(form, err);
      });
    });
    parts.push(form);
    parts.push(el('p', {class: 'fp-muted', text: t('aftp_s_note')}));
    return M.card('fp-aftps-h', t('aftp_s_title'), parts, 'fp-aftp-server');
  }

  function accountRow(a) {
    var status = a.serving ? el('span', {class: 'sig-pill sig-pill--ok', text: t(a.uploadsOpen ? 'aftp_pill_on_uploads' : 'aftp_pill_on')}) :
      el('span', {class: 'fp-aftp-why'}, [el('span', {class: 'sig-pill sig-pill--warn', text: t('aftp_pill_held')}),
        a.problem ? el('span', {class: 'fp-muted fp-row-note', text: a.problem}) : null]);
    return el('tr', {'data-fp-account': a.username}, [
      el('th', {scope: 'row'}, [el('span', {class: 'sig-mono', text: a.username})]),
      a.ip ? el('td', {class: 'sig-mono', text: a.ip}) : el('td', {class: 'fp-muted', text: t('aftp_s_no_ip')}),
      el('td', null, [status])]);
  }
  function accountsCard() {
    var parts = [el('p', {class: 'fp-muted', text: t('aftp_s_accounts_what')})];
    if (!X.s.accounts.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('aftp_s_accounts_none')}));
    } else {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-aftps-acc-h'}, [
        el('table', {class: 'sig-table fp-mail-table fp-aftp-table'}, [el('thead', null, [el('tr', null, [
          el('th', {scope: 'col', text: t('aftp_s_account')}), el('th', {scope: 'col', text: t('aftp_s_ip')}), el('th', {scope: 'col', text: t('aftp_s_status')})])]),
        el('tbody', null, X.s.accounts.map(accountRow))])]));
    }
    return M.card('fp-aftps-acc-h', t('aftp_s_accounts_title'), parts, 'fp-aftp-accounts');
  }

  function render() {
    X.page.textContent = '';
    X.page.appendChild(settingsCard());
    X.page.appendChild(accountsCard());
  }

  FP.view('tool:anonymous_ftp_server', function () {
    var tool = FP.tools.anonymous_ftp_server;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('aftp_s_desc'), cls: 'fp-mail fp-aftp',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    X = {page: body, s: null};
    var mine = X;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'anonFtpServer').then(function (r) {
      if (X !== mine) { return; }
      var s = clean(r);
      body.textContent = '';
      if (!s) { body.appendChild(FP.empty(tool.label, t('api_failed'))); return; }
      X.s = s;
      render();
    }, function (err) {
      if (X !== mine) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

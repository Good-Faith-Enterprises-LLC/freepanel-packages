/* freePanel mail tools of the administrators' panel (docs/api.md, "Email tools"): Repair mail folders (#/tool/mail_repair: put right the owner
   and permissions of an account's mail folder, looked at first), Deliverability overview (#/tool/mail_deliverability: the SPF, DKIM and DMARC
   state of every zone, and a repair for the ones that need it), Mail troubleshooter (#/tool/mail_trace: what the server does with mail sent to
   one address) and Greylisting (#/tool/mail_greylisting: the server's switch, delay and trusted senders). All four are the administrator's
   alone. What the server sends is drawn as text. The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var USER_RE = /^[a-z][a-z0-9]{0,15}$/;
  var ZONE_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function num(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.floor(v) : 0; }
  function count(n) { return Number(n).toLocaleString('en'); }
  function sentence(m) { return typeof m === 'string' && m ? m.charAt(0).toUpperCase() + m.slice(1) : m; }
  function pill(kind, text) { return el('span', {class: 'sig-pill' + (kind ? ' sig-pill--' + kind : ''), text: text}); }
  function frame(id) {
    var tool = FP.tools[id];
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return null; }
    var g = FP.group(tool.group);
    return FP.frame({title: tool.label, desc: t(id + '_desc'), cls: 'fp-mail fp-ml fp-ml-' + id,
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
  }
  function unavailable(body, label, err) {
    body.textContent = '';
    body.appendChild(FP.empty(label, sentence(err.message)));
  }

  /* ================= Repair mail folders ================= */
  var R = {page: null, accounts: []};
  var COUNTS = ['folders', 'files', 'owner_fixed', 'mode_fixed', 'links', 'shared', 'foreign', 'special', 'other_device', 'failed'];
  function cleanRepair(r) {
    if (!r || typeof r !== 'object' || typeof r.dry_run !== 'boolean') { return null; }
    var out = {username: str(r.username, 20), dry: r.dry_run, exists: r.exists !== false, incomplete: r.incomplete === true};
    COUNTS.forEach(function (k) { out[k] = num(r[k]); });
    return out;
  }
  function rResult(d) {
    if (!d.exists) { return [el('p', {'data-fp-summary': '', role: 'status', text: t('mr_no_folder', {name: d.username})})]; }
    var rows = [];
    function add(label, value, note) {
      rows.push(el('dt', {class: 'fp-ml-k', text: label}), el('dd', {class: 'fp-ml-v'}, [el('b', {text: count(value)}), note ? el('span', {class: 'fp-muted fp-row-note', text: ' ' + note}) : null]));
    }
    add(t('mr_looked'), d.folders + d.files, t('mr_looked_of', {folders: count(d.folders), files: count(d.files)}));
    add(t(d.dry ? 'mr_owner_dry' : 'mr_owner'), d.owner_fixed, '');
    add(t(d.dry ? 'mr_mode_dry' : 'mr_mode'), d.mode_fixed, '');
    add(t('mr_links'), d.links, t('mr_links_why'));
    add(t('mr_shared'), d.shared, t('mr_shared_why'));
    add(t('mr_foreign'), d.foreign, t('mr_foreign_why'));
    add(t('mr_special'), d.special, t('mr_special_why'));
    add(t('mr_other_device'), d.other_device, t('mr_other_device_why'));
    add(t('mr_failed'), d.failed, d.failed ? t('mr_failed_why') : '');
    var parts = [el('p', {class: 'fp-ml-sum', role: 'status', 'data-fp-summary': '', text: d.dry ? t(d.owner_fixed + d.mode_fixed ? 'mr_sum_dry' : 'mr_sum_dry_none', {name: d.username, n: count(d.owner_fixed + d.mode_fixed)}) :
      t(d.failed ? 'mr_sum_failed' : 'mr_sum_done', {name: d.username, n: count(d.owner_fixed + d.mode_fixed), failed: count(d.failed)})}),
    el('dl', {class: 'fp-ml-vals'}, rows)];
    if (d.incomplete) { parts.push(el('p', {class: 'fp-warn-line', 'data-fp-incomplete': '', text: t('mr_incomplete')})); }
    return parts;
  }
  function rCard() {
    var pick = el('select', {class: 'sig-select', id: 'fp-mr-account', name: 'account'}, R.accounts.map(function (a) { return el('option', {value: a, text: a}); }));
    var out = el('div', {class: 'fp-ml-out'});
    var ask = el('div', {class: 'fp-ml-ask'});
    var fix = el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'mr-fix', hidden: true});
    var check = el('button', {class: 'sig-btn sig-btn--secondary fp-submit', type: 'submit', text: t('mr_check')});
    var form = el('form', {class: 'fp-form fp-mail-form', novalidate: ''}, [M.errorLine(), M.statusLine(), M.field('fp-mr-account', t('mr_account'), pick, t('mr_account_hint')),
      el('div', {class: 'fp-actions'}, [check, fix]), ask, out]);
    var looked = '';
    function call(dry, b) {
      var name = pick.value;
      var page = R.page;
      UI.setBusy(b, true);
      M.say(form, t('mr_working'));
      FP.call('post', 'mailRepair', {dry_run: dry}, name).then(function (r) {
        if (R.page !== page) { return; }
        UI.setBusy(b, false);
        M.say(form, '');
        var d = cleanRepair(r);
        if (!d) { M.fieldError(form, null, t('api_failed')); return; }
        d.username = name;
        out.textContent = '';
        out.appendChild(M.card('fp-mr-res-h', t(dry ? 'mr_res_dry' : 'mr_res_done', {name: name}), rResult(d), 'fp-mr-result'));
        looked = dry && d.exists && d.owner_fixed + d.mode_fixed > 0 ? name : '';
        fix.hidden = !looked;
        fix.textContent = t('mr_fix', {name: looked});
        out.querySelector('#fp-mr-res-h').focus();
      }, function (err) {
        if (R.page !== page) { return; }
        UI.setBusy(b, false);
        M.say(form, '');
        M.failed(form, err);
      });
    }
    pick.addEventListener('change', function () { looked = ''; fix.hidden = true; out.textContent = ''; ask.textContent = ''; });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      ask.textContent = '';
      if (!USER_RE.test(pick.value)) { M.fieldError(form, pick, t('mr_pick_bad')); return; }
      fix.hidden = true;
      out.textContent = '';
      call(true, b);
    });
    form.addEventListener('click', function (e) {
      var go = e.target.closest ? e.target.closest('[data-fp-act="mr-fix"]') : null;
      var yes = e.target.closest ? e.target.closest('[data-fp-act="mr-yes"]') : null;
      var no = e.target.closest ? e.target.closest('[data-fp-act="confirm-no"]') : null;
      if (go && looked === pick.value) {
        M.start(form);
        M.confirmIn(ask, t('mr_ask', {name: looked}), 'mr-yes', t('mr_ask_yes'));
      } else if (yes) {
        ask.textContent = '';
        call(false, fix);
      } else if (no) {
        ask.textContent = '';
        fix.focus();
      }
    });
    return M.card('fp-mr-h', t('mr_title'), [el('p', {class: 'fp-muted', text: t('mr_intro')}), form], 'fp-mr-card');
  }
  FP.view('tool:mail_repair', function () {
    R = {page: null, accounts: []};
    var body = frame('mail_repair');
    if (!body) { return; }
    R.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'accounts').then(function (r) {
      if (R.page !== body) { return; }
      R.accounts = (r && Array.isArray(r.accounts) ? r.accounts : []).map(function (a) { return str(a && a.username, 20); }).filter(function (n) { return USER_RE.test(n); }).sort();
      body.textContent = '';
      if (!R.accounts.length) { body.appendChild(FP.empty(t('mr_none_title'), t('mr_none_text'))); return; }
      body.appendChild(rCard());
    }, function (err) {
      if (R.page === body) { unavailable(body, FP.tools.mail_repair.label, err); }
    });
  });

  /* ================= Deliverability overview ================= */
  var PAGE = 50;
  var Z = {page: null, offset: 0, account: '', problems: false, data: null, sel: {}};
  var CHECKS = ['spf', 'dkim', 'dmarc'];
  var LEVEL = {ok: 'ok', missing: 'danger', wrong: 'warn'};
  function cleanOverview(r) {
    if (!r || typeof r !== 'object' || !Array.isArray(r.domains)) { return null; }
    var s = r.summary && typeof r.summary === 'object' ? r.summary : {};
    return {total: num(r.total), offset: num(r.offset), summary: {checked: num(s.checked), ok: num(s.ok), problems: num(s.problems), errors: num(s.errors)}, zones: r.domains.map(function (z) {
      if (!z || typeof z !== 'object' || !ZONE_RE.test(str(z.zone, 260))) { return null; }
      var out = {zone: z.zone, account: USER_RE.test(str(z.account, 20)) ? z.account : '', primary: z.primary === true, signing: z.dkim_signing === true, error: str(z.error, 300),
        problems: (Array.isArray(z.problems) ? z.problems : []).map(function (x) { return str(x, 20); })};
      CHECKS.forEach(function (k) { out[k] = LEVEL[z[k]] ? z[k] : ''; });
      return out;
    }).filter(Boolean)};
  }
  function zRow(z) {
    var state = z.error ? [pill('warn', t('mdv_unreadable'))] : CHECKS.map(function (k) { return pill(z[k] ? LEVEL[z[k]] : '', t('mdv_' + k) + ': ' + t('mdv_state_' + (z[k] || 'unknown'))); });
    var box = el('input', {type: 'checkbox', 'data-fp-zone': z.zone, id: 'fp-mdv-' + z.zone.replace(/[^a-z0-9]/g, '-'), checked: Z.sel[z.zone] ? true : null});
    return el('li', {class: 'fp-mdv-row', 'data-fp-row': z.zone}, [el('label', {class: 'fp-check fp-mdv-label', for: box.id}, [box,
      el('span', {class: 'fp-mdv-who'}, [el('span', {class: 'fp-mdv-zone sig-mono', text: z.zone}),
        el('span', {class: 'fp-muted fp-row-note', text: [z.account, z.primary ? t('mdv_primary') : ''].filter(Boolean).join(' · ')})])]),
    el('div', {class: 'fp-mdv-pills'}, state.concat(z.signing ? [pill('ok', t('mdv_signing'))] : [])),
    z.error ? el('p', {class: 'fp-muted fp-row-note fp-mdv-err', text: sentence(z.error)}) : null]);
  }
  function zSelected() { return Object.keys(Z.sel).filter(function (k) { return Z.sel[k]; }); }
  function zCount() {
    var n = zSelected().length;
    var line = Z.page && Z.page.querySelector('.fp-mdv-count');
    if (line) { line.textContent = n ? t(n === 1 ? 'mdv_chosen_one' : 'mdv_chosen_n', {n: count(n)}) : t('mdv_chosen_none'); }
  }
  function zDraw(note) {
    var d = Z.data;
    var from = d.offset + 1;
    var to = d.offset + d.zones.length;
    var sum = d.summary;
    var parts = [M.errorLine(), M.statusLine(),
      el('p', {class: 'fp-mdv-sum', role: 'status', 'data-fp-summary': '', text: d.total ? t('mdv_sum', {total: count(d.total), from: count(from), to: count(to), ok: count(sum.ok), problems: count(sum.problems), errors: count(sum.errors)}) : t('mdv_none')})];
    if (d.zones.length) {
      parts.push(el('div', {class: 'fp-actions fp-mdv-tools'}, [
        el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'mdv-fix-chosen', text: t('mdv_fix_chosen')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'mdv-fix-all', text: t('mdv_fix_all', {max: PAGE})}),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'mdv-pick-problems', text: t('mdv_pick_problems')})]),
      el('div', {class: 'fp-mdv-ask'}), el('p', {class: 'fp-mdv-count', role: 'status', 'aria-live': 'polite'}),
      el('ul', {class: 'fp-mdv-list', 'aria-label': t('mdv_list_label')}, d.zones.map(zRow)));
      if (d.total > PAGE) {
        parts.push(el('div', {class: 'fp-actions fp-mdv-pager'}, [
          el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'mdv-prev', disabled: d.offset > 0 ? null : true, text: t('mdv_prev')}),
          el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'mdv-next', disabled: to < d.total ? null : true, text: t('mdv_next')})]));
      }
    }
    var box = Z.page.querySelector('.fp-mdv-out');
    box.textContent = '';
    box.appendChild(M.card('fp-mdv-res-h', t('mdv_list_title'), parts, 'fp-mdv-card'));
    zCount();
    if (note) { M.say(box.querySelector('.fp-mdv-card'), note); }
  }
  function zLoad(focus) {
    var page = Z.page;
    return FP.call('get', 'mailDeliverability', undefined, {limit: String(PAGE), offset: String(Z.offset), account: Z.account, problems: Z.problems ? '1' : ''}).then(function (r) {
      if (Z.page !== page) { return; }
      var d = cleanOverview(r);
      if (!d) { unavailable(page.querySelector('.fp-mdv-out'), FP.tools.mail_deliverability.label, {message: t('api_failed')}); return; }
      Z.data = d;
      zDraw('');
      if (focus) { page.querySelector('#fp-mdv-res-h').focus(); }
    }, function (err) {
      if (Z.page === page) { unavailable(page.querySelector('.fp-mdv-out'), FP.tools.mail_deliverability.label, err); }
    });
  }
  function zRepair(body, b) {
    var page = Z.page;
    var card = page.querySelector('.fp-mdv-card');
    var ask = card.querySelector('.fp-mdv-ask');
    ask.textContent = '';
    UI.setBusy(b, true);
    M.say(card, t('mdv_working'));
    FP.call('post', 'mailDeliverabilityRepair', body).then(function (r) {
      if (Z.page !== page) { return; }
      var fixed = num(r && r.fixed);
      var unchanged = num(r && r.unchanged);
      var failed = (r && Array.isArray(r.failed) ? r.failed : []).map(function (x) { return x && typeof x === 'object' ? {zone: str(x.zone, 260), error: str(x.error, 300)} : null; }).filter(Boolean);
      var more = r && r.more === true;
      Z.sel = {};
      Z.pending = {fixed: fixed, unchanged: unchanged, failed: failed, more: more};
      zLoad(false).then(function () {
        if (Z.page !== page) { return; }
        var box = page.querySelector('.fp-mdv-card');
        var res = el('div', {class: 'fp-mdv-result', role: 'status', 'data-fp-result': ''}, [
          el('p', {class: 'fp-ml-sum', text: t('mdv_result', {fixed: count(fixed), unchanged: count(unchanged), failed: count(failed.length)})}),
          failed.length ? el('ul', {class: 'fp-at-points', 'data-fp-failed': ''}, failed.map(function (x) { return el('li', {text: x.zone + ': ' + sentence(x.error)}); })) : null,
          more ? el('p', {class: 'fp-warn-line', 'data-fp-more': '', text: t('mdv_more')}) : null]);
        var sum = box.querySelector('.fp-mdv-sum');
        sum.parentNode.insertBefore(res, sum.nextSibling);
      });
    }, function (err) {
      if (Z.page !== page) { return; }
      UI.setBusy(b, false);
      M.say(card, '');
      M.fieldError(card, null, err.message);
    });
  }
  FP.view('tool:mail_deliverability', function () {
    Z = {page: null, offset: 0, account: '', problems: false, data: null, sel: {}};
    var body = frame('mail_deliverability');
    if (!body) { return; }
    Z.page = body;
    var account = el('input', {class: 'sig-input sig-mono', id: 'fp-mdv-account', name: 'account', type: 'text', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', maxlength: '16'});
    var problems = el('input', {type: 'checkbox', id: 'fp-mdv-problems', name: 'problems'});
    var form = el('form', {class: 'fp-form fp-mail-form fp-mdv-filter', novalidate: ''}, [M.errorLine(),
      M.field('fp-mdv-account', t('mdv_account'), account, t('mdv_account_hint')),
      el('label', {class: 'fp-check', for: 'fp-mdv-problems'}, [problems, el('span', {text: t('mdv_only_problems')})]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('mdv_show')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var a = account.value.trim().toLowerCase();
      if (a && !USER_RE.test(a)) { M.fieldError(form, account, t('mdv_account_bad')); return; }
      Z.account = a;
      Z.problems = problems.checked;
      Z.offset = 0;
      Z.sel = {};
      UI.setBusy(b, true);
      zLoad(true).then(function () { UI.setBusy(b, false); });
    });
    body.appendChild(M.card('fp-mdv-filter-h', t('mdv_filter_title'), [form], 'fp-mdv-filtercard'));
    body.appendChild(el('div', {class: 'fp-mdv-out'}, [el('p', {class: 'fp-muted', text: t('loading')})]));
    zLoad(false);
    body.addEventListener('change', function (e) {
      var zone = e.target && e.target.getAttribute ? e.target.getAttribute('data-fp-zone') : null;
      if (!zone) { return; }
      if (e.target.checked) { Z.sel[zone] = true; } else { delete Z.sel[zone]; }
      zCount();
    });
    body.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
      if (!b || Z.page !== body || !Z.data) { return; }
      var act = b.getAttribute('data-fp-act');
      var card = body.querySelector('.fp-mdv-card');
      var ask = card ? card.querySelector('.fp-mdv-ask') : null;
      if (act === 'mdv-prev') { Z.offset = Math.max(0, Z.offset - PAGE); Z.sel = {}; zLoad(true); } else if (act === 'mdv-next') { Z.offset += PAGE; Z.sel = {}; zLoad(true); } else if (act === 'mdv-pick-problems') {
        Z.sel = {};
        Z.data.zones.forEach(function (z) { if (z.problems.length || z.error) { Z.sel[z.zone] = true; } });
        Array.prototype.forEach.call(card.querySelectorAll('[data-fp-zone]'), function (c) { c.checked = Boolean(Z.sel[c.getAttribute('data-fp-zone')]); });
        zCount();
      } else if (act === 'mdv-fix-chosen') {
        UI.showError(card, '');
        var n = zSelected().length;
        if (!n) { M.fieldError(card, null, t('mdv_need_some')); return; }
        if (n > PAGE) { M.fieldError(card, null, t('mdv_too_many', {max: PAGE})); return; }
        Z.asked = zSelected();   /* the answer applies to the zones the question was put about */
        M.confirmIn(ask, t(n === 1 ? 'mdv_ask_one' : 'mdv_ask_n', {n: count(n)}), 'mdv-yes-chosen', t('mdv_ask_yes'));
      } else if (act === 'mdv-fix-all') {
        UI.showError(card, '');
        M.confirmIn(ask, t('mdv_ask_all', {max: PAGE}), 'mdv-yes-all', t('mdv_ask_yes'));
      } else if (act === 'mdv-yes-chosen') {
        if (Z.asked && Z.asked.length) { zRepair({zones: Z.asked}, b); }
      } else if (act === 'mdv-yes-all') {
        zRepair({all: true}, b);
      } else if (act === 'confirm-no') {
        ask.textContent = '';
        Z.asked = null;
        card.querySelector('[data-fp-act="mdv-fix-chosen"]').focus();
      }
    });
  });

  /* ================= Mail troubleshooter ================= */
  var OUTCOME = {mailbox: 'ok', external: 'accent', refused: 'danger', discarded: 'warn', not_accepted: 'danger', elsewhere: 'warn', loop: 'danger'};
  function cleanTrace(r) {
    if (!r || typeof r !== 'object' || !Array.isArray(r.steps) || !Array.isArray(r.ends)) { return null; }
    return {address: str(r.address, 300), domain: str(r.domain, 260), account: str(r.account, 20), hosted: r.hosted === true, held: r.held === true, here: r.here === true, accepted: r.accepted === true,
      truncated: r.truncated === true, steps: r.steps.map(function (s) { return s && typeof s === 'object' && typeof s.text === 'string' ? {kind: str(s.kind, 30), text: str(s.text, 600)} : null; }).filter(Boolean),
      ends: r.ends.map(function (e) { return e && typeof e === 'object' && OUTCOME[e.outcome] ? {address: str(e.address, 300), outcome: e.outcome, detail: str(e.detail, 500)} : null; }).filter(Boolean)};
  }
  function trResult(d) {
    var facts = [];
    function fact(label, yes) { facts.push(pill(yes ? 'ok' : 'warn', label)); }
    fact(t(d.hosted ? 'mt_hosted' : 'mt_not_hosted'), d.hosted);
    fact(t(d.here ? 'mt_here' : 'mt_not_here'), d.here);
    fact(t(d.accepted ? 'mt_accepted' : 'mt_not_accepted'), d.accepted);
    if (d.held) { facts.push(pill('warn', t('mt_held'))); }
    var parts = [el('p', {class: 'fp-mt-addr sig-mono', role: 'status', 'data-fp-summary': '', text: d.address}),
      el('p', {class: 'fp-muted fp-row-note', text: d.domain ? t('mt_domain', {domain: d.domain, account: d.account || '—'}) : ''}),
      el('div', {class: 'fp-mt-facts'}, facts),
      el('h3', {class: 'fp-h3', text: t('mt_steps')}),
      el('ol', {class: 'fp-mt-steps', 'data-fp-steps': ''}, d.steps.map(function (s) { return el('li', {text: s.text}); })),
      el('h3', {class: 'fp-h3', text: t('mt_ends')}),
      d.ends.length ? el('ul', {class: 'fp-mt-ends', 'data-fp-ends': ''}, d.ends.map(function (e) {
        return el('li', {class: 'fp-mt-end'}, [pill(OUTCOME[e.outcome], t('mt_out_' + e.outcome)), e.address ? el('span', {class: 'sig-mono fp-mt-endaddr', text: e.address}) : null,
          e.detail ? el('span', {class: 'fp-muted fp-row-note', text: e.detail}) : null]);
      })) : el('p', {class: 'fp-muted', text: t('mt_no_ends')})];
    if (d.truncated) { parts.push(el('p', {class: 'fp-warn-line', 'data-fp-truncated': '', text: t('mt_truncated')})); }
    return parts;
  }
  FP.view('tool:mail_trace', function () {
    var body = frame('mail_trace');
    if (!body) { return; }
    var input = el('input', {class: 'sig-input', id: 'fp-mt-address', name: 'address', type: 'text', inputmode: 'email', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', maxlength: '254'});
    var out = el('div', {class: 'fp-mt-out'});
    var form = el('form', {class: 'fp-form fp-mail-form', novalidate: ''}, [M.errorLine(), M.field('fp-mt-address', t('mt_address'), input, t('mt_address_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('mt_follow')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var a = input.value.trim().toLowerCase();
      if (!M.isAddress(a)) { M.fieldError(form, input, t('mt_address_bad')); return; }
      UI.setBusy(b, true);
      FP.call('get', 'mailTrace', undefined, {address: a}).then(function (r) {
        if (!body.isConnected) { return; }
        UI.setBusy(b, false);
        var d = cleanTrace(r);
        if (!d) { M.fieldError(form, null, t('api_failed')); return; }
        out.textContent = '';
        out.appendChild(M.card('fp-mt-res-h', t('mt_res_title'), trResult(d), 'fp-mt-result'));
        out.querySelector('#fp-mt-res-h').focus();
      }, function (err) {
        if (!body.isConnected) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    body.appendChild(M.card('fp-mt-form-h', t('mt_form_title'), [el('p', {class: 'fp-muted', text: t('mt_intro')}), form], 'fp-mt-card'));
    body.appendChild(out);
  });

  /* ================= Greylisting ================= */
  var L = {page: null, data: null};
  function cleanGreyAdmin(r) {
    if (!r || typeof r !== 'object' || typeof r.available !== 'boolean') { return null; }
    return {available: r.available, enabled: r.enabled === true, delay: num(r.delay_seconds), warning: str(r.warning, 300),
      trusted: (Array.isArray(r.trusted) ? r.trusted : []).map(function (x) { return str(x, 60); }).filter(Boolean)};
  }
  function lDraw(note) {
    var d = L.data;
    var on = el('input', {type: 'checkbox', id: 'fp-gl-on', name: 'enabled', checked: d.enabled ? true : null, disabled: d.available || d.enabled ? null : true});
    var delay = el('input', {class: 'sig-input fp-ml-narrow', id: 'fp-gl-delay', name: 'delay_seconds', type: 'number', inputmode: 'numeric', min: '60', max: '3600', step: '1', value: String(d.delay || 300)});
    var trusted = el('textarea', {class: 'sig-input sig-mono', id: 'fp-gl-trusted', name: 'trusted', rows: '5', spellcheck: 'false', autocapitalize: 'none', placeholder: '192.0.2.10\n198.51.100.0/24'});
    trusted.value = d.trusted.join('\n');
    var form = el('form', {class: 'fp-form fp-mail-form fp-ml-gl', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('label', {class: 'fp-check', for: 'fp-gl-on'}, [on, el('span', {text: t('mgl_on')})]),
      el('p', {class: 'sig-hint fp-ml-onhint', text: t(d.available ? 'mgl_on_hint' : 'mgl_on_unavailable')}),
      M.field('fp-gl-delay', t('mgl_delay'), delay, t('mgl_delay_hint')), M.field('fp-gl-trusted', t('mgl_trusted'), trusted, t('mgl_trusted_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('mgl_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var v = delay.value.trim();
      if (!/^[0-9]{1,4}$/.test(v) || Number(v) < 60 || Number(v) > 3600) { M.fieldError(form, delay, t('mgl_delay_bad')); return; }
      var list = trusted.value.split(/[\s,;]+/).map(function (x) { return x.trim(); }).filter(Boolean);
      if (list.length > 100) { M.fieldError(form, trusted, t('mgl_trusted_many')); return; }
      var bad = list.filter(function (x) { return !/^[0-9a-fA-F:.]+(\/[0-9]{1,3})?$/.test(x); });
      if (bad.length) { M.fieldError(form, trusted, t('mgl_trusted_bad', {value: bad[0].slice(0, 60)})); return; }
      var page = L.page;
      UI.setBusy(b, true);
      FP.call('put', 'mailGreylistServer', {enabled: on.checked, delay_seconds: Number(v), trusted: list}).then(function (r) {
        if (L.page !== page) { return; }
        var fresh = cleanGreyAdmin(r);
        if (!fresh) { UI.setBusy(b, false); M.fieldError(form, null, t('api_failed')); return; }
        L.data = fresh;
        lDraw(t(fresh.enabled ? 'mgl_saved_on' : 'mgl_saved_off'));
      }, function (err) {
        if (L.page !== page) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    L.page.textContent = '';
    if (!d.available) { L.page.appendChild(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-unavailable': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('mgl_unavailable')})])); }
    if (d.warning) { L.page.appendChild(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-warning': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: sentence(d.warning)})])); }
    L.page.appendChild(M.card('fp-mgl-h', t('mgl_title'), [el('p', {class: 'fp-muted', text: t('mgl_intro')}), form], 'fp-mgl-card'));
    if (note) { M.say(L.page.querySelector('.fp-mgl-card'), note); }
  }
  FP.view('tool:mail_greylisting', function () {
    L = {page: null, data: null};
    var body = frame('mail_greylisting');
    if (!body) { return; }
    L.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'mailGreylistServer').then(function (r) {
      if (L.page !== body) { return; }
      L.data = cleanGreyAdmin(r);
      if (!L.data) { unavailable(body, FP.tools.mail_greylisting.label, {message: t('api_failed')}); return; }
      lDraw('');
    }, function (err) {
      if (L.page === body) { unavailable(body, FP.tools.mail_greylisting.label, err); }
    });
  });
})();

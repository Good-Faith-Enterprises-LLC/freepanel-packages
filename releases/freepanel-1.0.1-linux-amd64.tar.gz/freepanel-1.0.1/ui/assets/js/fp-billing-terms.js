/* freePanel billing terms of service (#/tool/billing_terms; docs/api.md, "Billing: settings", Terms of service; docs/billing/navigation-map.md,
   "Settings"): the published versions, newest first, each with how many clients accepted it and its text to read; and a new version, which is
   in force from the moment it is published, so publishing is asked first. A version never changes. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;
  var M = FP.mail;

  var TERMS = {id: 'id', title: [100], body: [50000], published_by: [64], published: 'w', accepted: 'n'};
  FP.view('tool:billing_terms', function () {
    var page = B.frame('billing_terms', 'fp-bts');
    if (!page) { return; }
    var alive = function () { return page.isConnected; };
    var R = B.crud({page: page, pre: 'fp-bts', title: t('bts_title'), alive: alive,
      what: function () { return [el('p', {class: 'fp-muted', text: t('bts_what')})]; },
      load: function () { return FP.call('get', 'billingTerms').then(function (r) { return B.pickAll(r && r.versions, TERMS, 'id'); }); },
      heads: [B.th(t('bts_col_title')), B.th(t('bts_col_published')), B.th(t('bts_col_by')), B.th(t('bts_col_accepted'), 'fp-bil-num')],
      cells: function (v) {
        var first = R.items.length && R.items[0].id === v.id;
        return [el('th', {scope: 'row', class: 'fp-bil-wrap'}, [el('span', {text: v.title}), first ? B.pill(t('bts_in_force'), 'ok') : null]), el('td', {class: 'fp-bil-nowrap', text: B.when(v.published) || '—'}),
          el('td', {text: v.published_by || '—'}), el('td', {class: 'fp-bil-num', text: v.accepted === null ? '—' : B.num(v.accepted)})];
      },
      rowActs: function (v) { return [B.button('read', t('bts_read'), 'sig-btn--secondary sig-btn--sm', {'data-fp-key': String(v.id), 'aria-label': t('bts_read_of', {name: v.title})})]; },
      onAct: function (a, key, b, v) {
        if (a !== 'read' || !v) { return; }
        UI.setBusy(b, true);
        FP.call('get', 'billingTermsOne', undefined, {id: String(v.id)}).then(function (r) {
          if (!alive()) { return; }
          UI.setBusy(b, false);
          var full = B.pick(r, TERMS) || v;
          var old = page.querySelector('[data-fp-card="text"]');
          var made = B.card('fp-bts-text-h', t('bts_text_of', {name: full.title}), [el('p', {class: 'fp-muted', text: t('bts_text_when', {when: B.when(full.published) || '—'})}),
            el('div', {class: 'fp-bts-text fp-bil-note-body', 'data-fp-text': '', text: full.body})], 'fp-bts-text-card', 'text');
          if (old) { old.replaceWith(made); } else { page.querySelector('[data-fp-card="list"]').after(made); }
          made.querySelector('#fp-bts-text-h').focus();
        }, function (err) {
          if (!alive()) { return; }
          UI.setBusy(b, false);
          UI.showError(page.querySelector('[data-fp-card="list"]'), err.message);
        });
      },
      item: null, add: null, nameOf: function (v) { return v.title; },
      strings: {none: t('bts_none')},
      below: function () { return [publishCard()]; }});
    function publishCard() {
      var specs = [{name: 'title', label: t('bts_col_title'), required: true, max: 100, hint: t('bts_f_title_hint'), wide: true},
        {name: 'body', label: t('bts_f_body'), kind: 'textarea', required: true, max: 50000, rows: 12, hint: t('bts_f_body_hint'), wide: true}];
      var go = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bts_publish')});
      var asked = null;
      var form = el('form', {class: 'fp-form fp-bil-crud-form fp-bts-form', novalidate: '', 'aria-labelledby': 'fp-bts-new-h'}, [M.errorLine(), M.statusLine(),
        el('div', {class: 'fp-bil-grid'}, B.fieldsOf('fp-bts-f', specs, null)), el('div', {class: 'fp-actions', 'data-fp-acts': ''}, [go])]);
      function restore(focus) { var box = form.querySelector('[data-fp-acts]'); box.textContent = ''; box.appendChild(go); UI.setBusy(go, false); if (focus) { go.focus(); } }
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!B.begin(form, go)) { return; }
        var body = B.readFields(form, specs, null);
        if (!body) { return; }
        asked = body;
        var box = form.querySelector('[data-fp-acts]');
        box.textContent = '';
        var yes = el('button', {class: 'sig-btn sig-btn--danger', type: 'button', text: t('bts_publish_yes'), 'aria-describedby': 'fp-bts-q'});
        var no = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', text: t('bts_publish_keep'), 'aria-describedby': 'fp-bts-q'});
        box.appendChild(el('p', {class: 'fp-mail-confirm', id: 'fp-bts-q', text: t('bts_publish_ask')}));
        box.appendChild(yes);
        box.appendChild(no);
        no.addEventListener('click', function () { restore(true); });
        yes.addEventListener('click', function () {
          UI.setBusy(yes, true);
          FP.call('post', 'billingTerms', asked).then(function (r) {
            if (!alive()) { return; }
            R.show(t('bts_published', {name: (r && B.str(r.title, 100)) || asked.title}), '#fp-bts-h');
          }, function (err) {
            if (!alive()) { return; }
            restore(false);
            B.failed(form, err);
          });
        });
        no.focus();
      });
      return B.card('fp-bts-new-h', t('bts_new'), [el('p', {class: 'fp-muted', text: t('bts_new_what')}), form], 'fp-bts-new', 'publish');
    }
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    R.show();
  });
})();

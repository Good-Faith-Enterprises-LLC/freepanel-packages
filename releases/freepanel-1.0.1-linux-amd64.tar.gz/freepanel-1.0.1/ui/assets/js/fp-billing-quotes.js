/* freePanel billing quotes (#/tool/billing_quotes; docs/api.md, "Billing: quotes"; docs/billing/navigation-map.md, "Quotes"): offers to clients.
   The list is filtered by status and client; a quote is made as a draft with its lines, and opens on this same page with its lines and totals
   (changed while a draft) and, in order, Send, Download PDF, Record answer (accepted or declined, saying how) and Make invoice, and Remove
   for a draft. Sending and removing are asked first. Amounts are whole cents. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;
  var M = FP.mail;

  var STATUSES = ['draft', 'sent', 'accepted', 'declined', 'expired', 'invoiced'];
  var QUOTE = {id: 'id', customer_id: 'id', number: [40], status: ['=', STATUSES], subject: [100], note: [500], valid_until: 'd', currency: [3], subtotal_cents: 'c', tax_cents: 'c',
    tax_name: [60], total_cents: 'c', invoice_id: 'id', sent: 'w', decided: 'w', decided_by: [64], decided_how: [220], created: 'w'};
  function cleanQuote(x) {
    var q = B.pick(x, QUOTE);
    if (!q || !q.id || !q.status) { return null; }
    q.lines = B.pickAll(x.lines, {description: [200], quantity: 'n', unit_cents: 'c', amount_cents: 'c', no_tax: 'b'}).map(function (l) { l.quantity = l.quantity || 1; return l; });
    return q;
  }
  function quoteName(q) { return q.number || t('bcl_quote_draft_n', {id: String(q.id)}); }
  var Q = null;
  function card(name) { return Q.page.querySelector('[data-fp-card="' + name + '"]'); }

  function lister() {
    var mine = Q;
    return B.lister({page: Q.page, pre: 'fp-bqt', title: t('bqt_list_title'), findLabel: t('bqt_find'), tableCls: 'fp-bqt-table', alive: function () { return Q === mine && Q.page.isConnected; },
      before: function () { return [el('div', {class: 'fp-bil-toolbar'}, [B.button('create', t('bqt_create'), 'sig-btn--primary')])]; },
      blank: {status: '', customer: ''},
      filters: [
        {name: 'status', label: t('bqt_f_status'), control: function (v) { return B.select('fp-bqt-f-status', 'status', [['', t('bil_any')]].concat(STATUSES.map(function (s) { return [s, B.word('quote', s)]; })), v); }},
        {name: 'customer', control: function (v) { return B.clientPicker('fp-bqt-f-client', {name: 'customer', label: t('bqt_f_client'), placeholder: t('bil_any'), value: v, valueName: v ? Q.names[v] : ''}); }}],
      load: function (f, offset, limit) {
        return B.listOf('billingQuotes', {limit: String(limit), offset: String(offset), status: f.status, customer: f.customer}, 'quotes', cleanQuote).then(function (r) {
          return B.namesFor(Q.names, r.items.map(function (x) { return x.customer_id; })).then(function () { return r; });
        });
      },
      heads: [B.th(t('bqt_col_number')), B.th(t('bqt_col_client')), B.th(t('bqt_col_subject')), B.th(t('bqt_col_total'), 'fp-bil-num'), B.th(t('bqt_col_valid')), B.th(t('bqt_col_status'))],
      row: function (q) {
        var name = quoteName(q);
        return el('tr', {'data-fp-quote': String(q.id)}, [el('th', {scope: 'row', class: 'fp-bil-name'}, [B.button('open', name, 'sig-btn--link fp-bil-link', {'data-fp-id': String(q.id), 'aria-label': t('bcl_open_quote_of', {name: name})})]),
          el('td', {class: 'fp-bil-wrap', text: B.nameIn(Q.names, q.customer_id)}), el('td', {class: 'fp-bil-wrap', text: q.subject || '—'}),
          el('td', {class: 'fp-bil-num', text: B.money(q.total_cents, q.currency)}), el('td', {class: 'fp-bil-nowrap', text: B.day(q.valid_until) || '—'}), el('td', null, [B.statePill('quote', q.status)])]);
      },
      none: t('bqt_none'), noneMatch: t('bqt_none_match'),
      found: function (n) { return n === 1 ? t('bqt_found_1') : t('bqt_found', {n: B.num(n)}); }});
  }
  function showList(focus, said) { Q.view = 'list'; Q.q = null; return Q.L.show(focus, said); }

  /* ---- a new quote ---- */
  function showCreate(cid) {
    Q.view = 'create';
    Q.q = null;
    var picker = B.clientPicker('fp-bqt-n-client', {label: t('bqt_client'), placeholder: t('binv_pick_client'), active: true, required: true, value: cid || '', valueName: cid ? Q.names[cid] : ''});
    var subject = B.input('fp-bqt-n-subject', 'subject', '', {maxlength: '100', 'aria-required': 'true'});
    var box = B.lines.box('fp-bqt-n', [], t('bqt_lines_table'));
    var note = el('textarea', {class: 'sig-input fp-bil-text', id: 'fp-bqt-n-note', name: 'note', rows: '3', maxlength: '500'});
    var valid = el('input', {class: 'sig-input fp-binv-date', type: 'date', id: 'fp-bqt-n-valid', name: 'valid_until'});
    var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bqt_save_draft')});
    var form = el('form', {class: 'fp-form fp-bqt-new', novalidate: '', 'aria-labelledby': 'fp-bqt-new-h'}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-binv-client-pick'}, [picker.node]), el('div', {class: 'fp-bqt-subject'}, [M.field('fp-bqt-n-subject', t('bqt_subject'), subject, t('bqt_subject_hint'))]),
      el('fieldset', {class: 'fp-bil-set'}, [el('legend', {class: 'fp-bil-legend', text: t('binv_lines')}), el('p', {class: 'fp-muted fp-row-note', text: t('binv_lines_hint')}), box]),
      M.field('fp-bqt-n-note', t('bqt_note'), note, t('bqt_note_hint')), el('div', {class: 'fp-binv-due'}, [M.field('fp-bqt-n-valid', t('bqt_valid'), valid, t('bqt_valid_hint'))]),
      el('div', {class: 'fp-actions'}, [save, B.button('create-cancel', t('cancel'))])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!B.begin(form, save)) { return; }
      if (!picker.select.value) { M.fieldError(form, picker.select, t('binv_client_needed')); return; }
      if (!subject.value.trim()) { M.fieldError(form, subject, t('bqt_subject_needed')); return; }
      var lines = B.lines.read(form, box);
      if (!lines) { return; }
      var body = {customer_id: Number(picker.select.value), subject: subject.value.trim(), lines: lines};
      if (note.value.trim()) { body.note = note.value; }
      if (valid.value) { body.valid_until = valid.value; }
      var mine = Q;
      UI.setBusy(save, true);
      FP.call('post', 'billingQuoteNew', body).then(function (r) {
        if (Q !== mine) { return; }
        var q = cleanQuote(r);
        if (!q) { throw {message: t('api_failed')}; }
        openQuote(q.id, {say: t('bqt_draft_saved')});
      }).catch(function (err) {
        if (Q !== mine) { return; }
        UI.setBusy(save, false);
        B.lines.failed(form, box, err);
      });
    });
    B.screen(Q.page, [B.back('to-list', t('bqt_back')), B.card('fp-bqt-new-h', t('bqt_create_title'), [el('p', {class: 'fp-muted', text: t('bqt_create_what')}), form], 'fp-bqt-create', 'create')],
      cid ? '#fp-bqt-n-subject' : '#fp-bqt-n-client');
  }

  /* ---- a quote ---- */
  function openQuote(qid, opts) {
    opts = opts || {};
    var mine = Q;
    var b = Q.page.querySelector('[data-fp-act="open"][data-fp-id="' + qid + '"]');
    if (b) { UI.setBusy(b, true); }
    return FP.call('get', 'billingQuote', undefined, {id: String(qid)}).then(function (r) {
      var q = cleanQuote(r);
      if (!q) { throw {message: t('api_failed')}; }
      return B.namesFor(Q.names, [q.customer_id]).then(function () { return q; });
    }).then(function (q) {
      if (Q !== mine) { return; }
      Q.view = 'quote';
      Q.q = q;
      B.screen(Q.page, [B.back('to-list', t('bqt_back')), headCard(q), linesCard(q), q.status === 'sent' ? answerCard(q) : null, q.status === 'accepted' ? invoiceCard(q) : null]);
      if (opts.say) { M.say(card('head'), opts.say); }
      if (opts.sayIn) { M.say(card(opts.sayIn[0]), opts.sayIn[1]); }
      (Q.page.querySelector(opts.focus || '#fp-bqt-h') || Q.page.querySelector('#fp-bqt-h')).focus();
    }).catch(function (err) {
      if (Q !== mine) { return; }
      if (b && b.isConnected) { UI.setBusy(b, false); Q.L.error(err); b.focus(); return; }
      if (Q.view === 'quote' && card('head')) { UI.showError(card('head'), err.message); return; }
      showList().then(function () { Q.L.error(err); });
    });
  }
  function reopen(opts) { return openQuote(Q.q.id, opts); }
  function headCard(q) {
    var pairs = [[t('bqt_client'), [B.clientLink(Q.names, q.customer_id)]], [t('bqt_subject'), q.subject], [t('bqt_made'), B.day(q.created)], [t('bqt_sent'), B.day(q.sent)],
      [t('bqt_col_valid'), B.day(q.valid_until)]];
    if (q.decided) { pairs.push([t(q.status === 'declined' ? 'bqt_declined_on' : 'bqt_accepted_on'), B.day(q.decided)], [t('bqt_how'), q.decided_how.replace(/^staff: /, '')]); }
    if (q.invoice_id) {
      var inv = t('binv_invoice_ref', {id: String(q.invoice_id)});
      pairs.push([t('bqt_invoice'), [FP.tools.billing_invoices ? B.button('open-invoice', inv, 'sig-btn--link fp-bil-link', {'data-fp-id': String(q.invoice_id), 'aria-label': t('bcl_open_invoice_id', {id: String(q.invoice_id)})}) : inv]]);
    }
    var acts = [];
    if (q.status === 'draft') { acts.push(B.button('send', t('bqt_send'), 'sig-btn--primary')); }
    acts.push(el('a', {class: 'sig-btn sig-btn--secondary', href: '/api/v1/billing/quotes/' + q.id + '/pdf', download: '', 'data-fp-pdf': ''}, [UI.icon(FP.ui, 'ui_download'), el('span', {text: t('binv_pdf')})]));
    if (q.status === 'draft') { acts.push(B.button('remove', t('bqt_remove'), 'sig-btn--secondary fp-btn-danger-text')); }
    return el('section', {class: 'sig-card fp-bil-head fp-bqt-head', 'aria-labelledby': 'fp-bqt-h', 'data-fp-card': 'head'}, [el('div', {class: 'sig-card-body'}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-bil-head-row'}, [el('div', {class: 'fp-bil-head-name'}, [el('h2', {class: 'fp-h2', id: 'fp-bqt-h', tabindex: '-1', text: q.number ? t('bqt_quote_n', {number: q.number}) : t('bqt_draft_title', {id: String(q.id)})})]),
        B.statePill('quote', q.status)]), B.facts(pairs), el('div', {class: 'fp-actions', 'data-fp-acts': ''}, acts)])]);
  }
  function totals(q) {
    var pairs = [[t('binv_subtotal'), B.money(q.subtotal_cents, q.currency)]];
    if (q.tax_cents || q.tax_name) { pairs.push([q.tax_name ? t('binv_tax_named', {name: q.tax_name}) : t('binv_tax'), B.money(q.tax_cents, q.currency)]); }
    pairs.push([t('binv_total'), B.money(q.total_cents, q.currency)]);
    return B.totalsBlock(pairs);
  }
  function linesCard(q) {
    var parts = [M.statusLine()];
    if (q.status === 'draft') {
      var subject = B.input('fp-bqt-e-subject', 'subject', q.subject, {maxlength: '100', 'aria-required': 'true'});
      var box = B.lines.box('fp-bqt-e', q.lines.map(B.lines.typedOf), t('bqt_lines_table'));
      var note = el('textarea', {class: 'sig-input fp-bil-text', id: 'fp-bqt-e-note', name: 'note', rows: '3', maxlength: '500'});
      note.value = q.note;
      var valid = el('input', {class: 'sig-input fp-binv-date', type: 'date', id: 'fp-bqt-e-valid', name: 'valid_until', value: q.valid_until});
      var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bqt_save')});
      var form = el('form', {class: 'fp-form fp-bqt-edit', novalidate: '', 'aria-label': t('bqt_edit_label')}, [M.errorLine(),
        el('div', {class: 'fp-bqt-subject'}, [M.field('fp-bqt-e-subject', t('bqt_subject'), subject)]), el('p', {class: 'fp-muted fp-row-note', text: t('binv_lines_hint')}), box,
        M.field('fp-bqt-e-note', t('bqt_note'), note, t('bqt_note_hint')), el('div', {class: 'fp-binv-due'}, [M.field('fp-bqt-e-valid', t('bqt_valid'), valid, t('bqt_valid_hint'))]),
        el('div', {class: 'fp-actions'}, [save])]);
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!B.begin(form, save)) { return; }
        if (!subject.value.trim()) { M.fieldError(form, subject, t('bqt_subject_needed')); return; }
        var lines = B.lines.read(form, box);
        if (!lines) { return; }
        var mine = Q;
        UI.setBusy(save, true);
        FP.call('patch', 'billingQuote', {subject: subject.value.trim(), lines: lines, note: note.value, valid_until: valid.value}, {id: String(q.id)}).then(function () {
          if (Q !== mine) { return; }
          reopen({sayIn: ['lines', t('bqt_saved')], focus: '#fp-bqt-lines-h'});
        }, function (err) {
          if (Q !== mine) { return; }
          UI.setBusy(save, false);
          B.lines.failed(form, box, err);
        });
      });
      parts.push(form);
    } else {
      parts.push(q.lines.length ? B.lines.table('fp-bqt-lines-h', q.lines, q.currency) : el('p', {class: 'fp-muted', text: t('bqt_no_lines')}));
      if (q.note) { parts.push(el('p', {class: 'fp-bil-note-body', 'data-fp-note': '', text: q.note})); }
    }
    parts.push(totals(q));
    return B.card('fp-bqt-lines-h', t('binv_lines'), parts, 'fp-bqt-lines', 'lines');
  }
  /* Record answer: what the client said, and how they said it */
  function answerCard(q) {
    var yes = el('input', {type: 'radio', id: 'fp-bqt-d-yes', name: 'accept', value: 'yes'});
    var no = el('input', {type: 'radio', id: 'fp-bqt-d-no', name: 'accept', value: 'no'});
    var note = B.input('fp-bqt-d-note', 'note', '', {maxlength: '200', 'aria-required': 'true'});
    var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bqt_answer_save')});
    var form = el('form', {class: 'fp-form fp-bqt-answer', novalidate: '', 'aria-labelledby': 'fp-bqt-answer-h'}, [M.errorLine(), M.statusLine(),
      el('fieldset', {class: 'fp-bil-set'}, [el('legend', {class: 'sig-label', text: t('bqt_answer_what')}), el('div', {class: 'fp-bil-checks'}, [
        el('label', {class: 'fp-bil-check', for: 'fp-bqt-d-yes'}, [yes, el('span', {text: t('bqt_answer_yes')})]), el('label', {class: 'fp-bil-check', for: 'fp-bqt-d-no'}, [no, el('span', {text: t('bqt_answer_no')})])])]),
      el('div', {class: 'fp-bil-grid'}, [M.field('fp-bqt-d-note', t('bqt_answer_how'), note, t('bqt_answer_how_hint'))]), el('div', {class: 'fp-actions'}, [save])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!B.begin(form, save)) { return; }
      if (!yes.checked && !no.checked) { M.fieldError(form, yes, t('bqt_answer_pick')); return; }
      if (!note.value.trim()) { M.fieldError(form, note, t('bqt_answer_how_needed')); return; }
      var mine = Q;
      UI.setBusy(save, true);
      FP.call('post', 'billingQuoteDecide', {accept: yes.checked, note: note.value.trim()}, {id: String(q.id)}).then(function () {
        if (Q !== mine) { return; }
        reopen({say: t(yes.checked ? 'bqt_accepted' : 'bqt_declined'), focus: '#fp-bqt-h'});
      }, function (err) {
        if (Q !== mine) { return; }
        UI.setBusy(save, false);
        B.failed(form, err.field === 'accept' ? Object.assign({}, err, {field: ''}) : err);
      });
    });
    return B.card('fp-bqt-answer-h', t('bqt_answer_title'), [el('p', {class: 'fp-muted', text: t('bqt_answer_intro')}), form], 'fp-bqt-answer-card', 'answer');
  }
  function invoiceCard(q) {
    var issue = el('input', {type: 'checkbox', id: 'fp-bqt-i-issue', name: 'issue'});
    var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bqt_make_invoice')});
    var form = el('form', {class: 'fp-form fp-bqt-invoice', novalidate: '', 'aria-labelledby': 'fp-bqt-inv-h'}, [M.errorLine(),
      el('label', {class: 'fp-bil-check', for: 'fp-bqt-i-issue'}, [issue, el('span', {text: t('bqt_issue_now')})]), el('div', {class: 'fp-actions'}, [save])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!B.begin(form, save)) { return; }
      var mine = Q;
      UI.setBusy(save, true);
      FP.call('post', 'billingQuoteInvoice', issue.checked ? {issue: true} : {}, {id: String(q.id)}).then(function (r) {
        if (Q !== mine) { return; }
        var v = B.cleanInvoice(r && r.invoice);
        reopen({say: v ? t('bqt_invoiced', {name: B.invoiceName(v)}) : t('bqt_invoiced_plain'), focus: '#fp-bqt-h'});
      }, function (err) {
        if (Q !== mine) { return; }
        UI.setBusy(save, false);
        B.failed(form, err);
      });
    });
    return B.card('fp-bqt-inv-h', t('bqt_invoice_title'), [el('p', {class: 'fp-muted', text: t('bqt_invoice_what')}), form], 'fp-bqt-inv-card', 'invoice');
  }
  function restoreHead(focus) {
    var old = card('head');
    var made = headCard(Q.q);
    old.replaceWith(made);
    var f = made.querySelector(focus);
    if (f) { f.focus(); }
  }
  function headCall(b, call, then, back) {
    var mine = Q;
    UI.setBusy(b, true);
    UI.showError(card('head'), '');
    call.then(function (r) {
      if (Q !== mine) { return; }
      then(r);
    }, function (err) {
      if (Q !== mine) { return; }
      restoreHead('[data-fp-act="' + back + '"]');
      UI.showError(card('head'), err.message);
    });
  }

  function onClick(e) {
    var target = e.target && e.target.closest ? e.target : null;
    if (!target || !Q || !Q.page.isConnected || !Q.page.contains(target)) { return; }
    var b = target.closest('[data-fp-act]');
    if (!b || b.disabled) { return; }
    var a = b.getAttribute('data-fp-act');
    var xid = Number(b.getAttribute('data-fp-id')) || 0;
    if (a === 'create') {
      showCreate(Q.L.filters.customer ? Number(Q.L.filters.customer) : 0);
    } else if (a === 'create-cancel' || a === 'to-list') {
      var from = Q.q ? Q.q.id : 0;
      showList(from ? '[data-fp-act="open"][data-fp-id="' + from + '"]' : '#fp-bqt-list-h');
    } else if (a === 'open' && xid) {
      openQuote(xid);
    } else if (a === 'open-client' && xid) {
      B.go('billing_clients', {client: xid});
    } else if (a === 'open-invoice' && xid) {
      B.go('billing_invoices', {invoice: xid});
    } else if (a === 'send') {
      M.confirmIn(b.closest('[data-fp-acts]'), t('bqt_send_ask'), 'send-yes', t('bqt_send_yes'));
    } else if (a === 'send-yes') {
      headCall(b, FP.call('post', 'billingQuoteSend', {}, {id: String(Q.q.id)}), function (r) {
        var q = cleanQuote(r);
        reopen({say: t('bqt_sent_said', {name: q ? quoteName(q) : ''}), focus: '#fp-bqt-h'});
      }, 'send');
    } else if (a === 'remove') {
      M.confirmIn(b.closest('[data-fp-acts]'), t('bqt_remove_ask'), 'remove-yes', t('bqt_remove_yes'));
    } else if (a === 'remove-yes') {
      var q = Q.q;
      headCall(b, FP.call('del', 'billingQuote', undefined, {id: String(q.id)}), function () { showList('#fp-bqt-list-h', t('bqt_removed', {name: quoteName(q)})); }, 'remove');
    } else if (a === 'confirm-no') {
      var yes = b.parentNode.querySelector('[data-fp-act$="-yes"]');
      restoreHead('[data-fp-act="' + (yes ? yes.getAttribute('data-fp-act').replace(/-yes$/, '') : 'send') + '"]');
    }
  }
  document.addEventListener('click', onClick);

  FP.view('tool:billing_quotes', function () {
    var page = B.frame('billing_quotes', 'fp-bqt');
    if (!page) { return; }
    Q = {page: page, view: 'list', names: {}, q: null};
    Q.L = lister();
    var handed = B.take('billing_quotes');
    if (handed && B.id(handed.quote)) {
      page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
      openQuote(handed.quote);
    } else if (handed && B.id(handed.create)) {
      var mine = Q;
      B.namesFor(Q.names, [handed.create]).then(function () { if (Q === mine) { showCreate(handed.create); } });
    } else {
      showList();
    }
  });
})();

/* freePanel email archiving (#/tool/email_archiving, docs/api.md, "Archive a mailbox's mail"): for each mailbox, whether every message
   delivered to it is also copied into its Archive folder, and how many days a copy stays. Mailbox names come from the account's own
   list and are shown as text. Without the server's filter plugin the page says archiving is not there. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var KEEP = [0, 30, 90, 180, 365, 730, 1825, 3650];
  var A = null;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 255) : ''; }
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var boxes = (Array.isArray(r.mailboxes) ? r.mailboxes : []).filter(function (b) { return b && typeof b.address === 'string' && /^[^@\s]{1,64}@[^@\s]{1,253}$/.test(b.address); }).map(function (b) {
      var d = typeof b.archive_keep_days === 'number' && isFinite(b.archive_keep_days) && b.archive_keep_days >= 0 ? Math.min(Math.floor(b.archive_keep_days), 3650) : 0;
      return {address: str(b.address), on: b.archive === true, days: d};
    });
    return {on: r.filters_on !== false, boxes: boxes};
  }
  function keepLabel(d) {
    if (d === 0) { return t('ar_forever'); }
    if (d % 365 === 0) { return t(d === 365 ? 'ar_year' : 'ar_years', {n: String(d / 365)}); }
    return t('ar_days', {n: String(d)});
  }
  function options(d) {
    var list = KEEP.indexOf(d) >= 0 ? KEEP : KEEP.concat([d]).sort(function (a, b) { return a - b; });
    return list.map(function (n) { return el('option', {value: String(n), selected: n === d ? true : null, text: keepLabel(n)}); });
  }
  function boxForm(b, i) {
    var id = 'fp-ar-' + i;
    var check = el('input', {type: 'checkbox', id: id + '-on', name: 'enabled', checked: b.on ? true : null});
    var sel = el('select', {class: 'sig-select', id: id + '-days', name: 'keep_days'}, options(b.days));
    var form = el('form', {class: 'fp-ar-box', 'data-fp-box': b.address, novalidate: ''}, [
      el('h3', {class: 'fp-h3 sig-mono fp-ar-addr', id: id + '-h', text: b.address}),
      el('label', {class: 'fp-check', for: id + '-on'}, [check, el('span', {text: t('arch_on')})]),
      M.field(id + '-days', t('ar_keep'), sel, t('ar_keep_hint')),
      el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': ''}),
      M.statusLine(),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', 'aria-describedby': id + '-h', text: t('arch_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var go = M.start(form);
      if (!go) { return; }
      var mine = A;
      var body = {enabled: check.checked, keep_days: Number(sel.value)};
      UI.setBusy(go, true);
      FP.call('put', 'mailArchive', body, {name: A.account, address: b.address}).then(function (r) {
        if (A !== mine) { return; }
        UI.setBusy(go, false);
        var got = clean(r).boxes.filter(function (x) { return x.address === b.address; })[0];
        if (got) { b.on = got.on; b.days = got.days; }
        M.say(form, t(b.on ? (b.days ? 'ar_saved_on_days' : 'ar_saved_on') : (b.days ? 'ar_saved_off_days' : 'ar_saved_off'), {days: keepLabel(b.days).toLowerCase()}));
      }, function (err) {
        if (A !== mine) { return; }
        UI.setBusy(go, false);
        M.failed(form, err);
      });
    });
    return form;
  }
  function draw() {
    var page = A.page;
    page.textContent = '';
    if (!A.on) { page.appendChild(FP.empty(FP.tools.email_archiving.label, t('arch_unavailable'))); return; }
    if (!A.boxes.length) { page.appendChild(FP.empty(FP.tools.email_archiving.label, t('ar_no_boxes'))); return; }
    page.appendChild(M.card('fp-ar-h', t('ar_title'), [el('p', {class: 'fp-muted', text: t('ar_what')}),
      el('div', {class: 'fp-ar-list'}, A.boxes.map(boxForm)), el('p', {class: 'fp-muted', text: t('ar_note')})], 'fp-ar'));
  }
  FP.view('tool:email_archiving', function () {
    A = null;
    var tool = FP.tools.email_archiving;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('email_archiving_desc'), cls: 'fp-mail fp-ar-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    A = {page: page, account: FP.account(), on: true, boxes: []};
    var mine = A;
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'mail', undefined, A.account).then(function (r) {
      if (A !== mine) { return; }
      var c = clean(r);
      A.on = c.on; A.boxes = c.boxes;
      draw();
    }, function (err) {
      if (A !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

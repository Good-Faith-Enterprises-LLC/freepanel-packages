/* freePanel app hosting (docs/api.md, "App hosting"): the customer's page for programs of their own (Node.js, Python, Ruby) that run as
   the account behind one of its sites (#/tool/app_hosting), and the admin's page that says which runtimes the server has, whether Apache
   can reach an app, and whether an app may listen on a port of the loopback instead of its own socket (#/tool/app_runtimes). An app is
   added, changed, started, stopped, restarted and removed by its owner alone; its log is read, never kept. What the page can see is wrong
   is said before anything is sent; every other refusal is the server's words. What the server sends is cleaned to the shapes drawn and
   shown as text. Page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var RUNTIMES = ['node', 'python', 'ruby'];
  var STATES = ['active', 'inactive', 'failed', 'activating', 'deactivating', 'unknown'];
  var NAME_RE = /^([a-z]|[a-z][a-z0-9-]{0,30}[a-z0-9])$/;
  var PART_RE = /^[A-Za-z0-9_][A-Za-z0-9._-]{0,99}$/;
  var ENV_NAME_RE = /^[A-Z][A-Z0-9_]{0,39}$/;
  var ENV_VALUE_RE = /^[A-Za-z0-9._:/@+=,-]{0,200}$/;
  var DOMAIN_RE = /^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$/;
  /* the settings the panel sets itself, or that change how a program loads code (the server refuses them too) */
  var RESERVED = ['PORT', 'HOST', 'SOCKET', 'HOME', 'USER', 'LOGNAME', 'PATH', 'SHELL', 'LANG', 'LD_PRELOAD', 'LD_LIBRARY_PATH', 'LD_AUDIT', 'NODE_ENV'];
  var MAX_ENV = 20;
  var LOG_LINES = 100;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function whole(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.round(v) : 0; }
  function arr(v) { return Array.isArray(v) ? v : []; }
  function runtimeTitle(id) { return t('ah_rt_' + id); }

  /* a path inside the home folder as the server takes it: plain names joined by slashes; '' when it is not one */
  function plainPath(p) {
    if (!p || p.length > 200 || p.charAt(0) === '/' || p.charAt(p.length - 1) === '/') { return ''; }
    var parts = p.split('/');
    for (var i = 0; i < parts.length; i++) { if (parts[i] === '.' || parts[i] === '..' || !PART_RE.test(parts[i])) { return ''; } }
    return p;
  }

  /* ================= the customer's apps ================= */
  var A = null;

  function cleanApp(x) {
    if (!x || typeof x !== 'object' || !NAME_RE.test(str(x.name, 40)) || RUNTIMES.indexOf(x.runtime) < 0) { return null; }
    var env = {};
    var raw = x.env && typeof x.env === 'object' && !Array.isArray(x.env) ? x.env : {};
    Object.keys(raw).slice(0, MAX_ENV).forEach(function (k) { if (ENV_NAME_RE.test(k) && typeof raw[k] === 'string' && ENV_VALUE_RE.test(raw[k])) { env[k] = raw[k]; } });
    return {name: x.name, runtime: x.runtime, dir: str(x.dir, 200), start: str(x.start, 200), domain: DOMAIN_RE.test(str(x.domain, 253)) ? x.domain : '',
      listen: x.listen === 'port' ? 'port' : 'socket', port: whole(x.port), env: env, stopped: x.stopped === true, state: STATES.indexOf(x.state) >= 0 ? x.state : 'unknown'};
  }
  function cleanApps(r) {
    r = r && typeof r === 'object' ? r : {};
    return {apps: arr(r.apps).map(cleanApp).filter(Boolean).slice(0, 20), max: whole(r.max) || 5, enabled: r.enabled === true, ports: r.ports_allowed === true,
      runtimes: arr(r.runtimes).filter(function (x) { return RUNTIMES.indexOf(x) >= 0; })};
  }
  function take(mine, got) {
    mine.apps = got.apps;
    mine.max = got.max;
    mine.enabled = got.enabled;
    mine.ports = got.ports;
    mine.runtimes = got.runtimes;
  }
  function stateOf(app) {
    if (app.stopped) { return {key: 'stopped', cls: ''}; }
    return {key: app.state, cls: app.state === 'active' ? ' sig-pill--ok' : app.state === 'failed' ? ' sig-pill--danger' : app.state === 'inactive' || app.state === 'unknown' ? ' sig-pill--warn' : ''};
  }
  function say(name, text) {
    var li = A.page.querySelector('[data-fp-app="' + name + '"]');
    if (li) { M.say(li, text); }
  }
  function call(method, key, arg, body) {
    return FP.call(method, key, body, Object.assign({name: A.account}, arg || {}));
  }

  /* NAME=value lines, one setting a line; null, with the box marked, when a line is plainly wrong */
  function readEnv(form, box) {
    var env = {};
    var rows = box.value.split('\n').map(function (l) { return l.trim(); }).filter(Boolean);
    if (rows.length > MAX_ENV) { M.fieldError(form, box, t('ah_env_many', {max: MAX_ENV})); return null; }
    for (var i = 0; i < rows.length; i++) {
      var at = rows[i].indexOf('=');
      var key = at < 0 ? rows[i] : rows[i].slice(0, at).trim();
      var value = at < 0 ? '' : rows[i].slice(at + 1).trim();
      if (at < 0 || !ENV_NAME_RE.test(key)) { M.fieldError(form, box, t('ah_env_line', {line: rows[i].slice(0, 60)})); return null; }
      if (RESERVED.indexOf(key) >= 0) { M.fieldError(form, box, t('ah_env_reserved', {name: key})); return null; }
      if (!ENV_VALUE_RE.test(value)) { M.fieldError(form, box, t('ah_env_value', {name: key})); return null; }
      if (env[key] !== undefined) { M.fieldError(form, box, t('ah_env_twice', {name: key})); return null; }
      env[key] = value;
    }
    return env;
  }

  /* the form that adds an app (app null) or changes one */
  function appForm(app) {
    var p = app ? 'fp-ah-e-' : 'fp-ah-n-';
    var name = el('input', {class: 'sig-input sig-mono', id: p + 'name', name: 'name', type: 'text', maxlength: '32', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', value: app ? app.name : ''});
    if (app) { name.readOnly = true; }
    var runtime = el('select', {class: 'sig-select', id: p + 'runtime', name: 'runtime'}, A.runtimes.map(function (id) { return el('option', {value: id, text: runtimeTitle(id)}); }));
    runtime.value = app ? app.runtime : (A.runtimes[0] || '');
    var domain = el('select', {class: 'sig-select', id: p + 'domain', name: 'domain'}, A.sites.map(function (s) { return el('option', {value: s.domain, text: s.domain}); }));
    if (app && A.sites.every(function (s) { return s.domain !== app.domain; })) { domain.appendChild(el('option', {value: app.domain, text: app.domain})); }
    domain.value = app ? app.domain : (A.sites[0] ? A.sites[0].domain : '');
    var dir = el('input', {class: 'sig-input sig-mono', id: p + 'dir', name: 'dir', type: 'text', maxlength: '200', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', value: app ? app.dir : ''});
    var start = el('input', {class: 'sig-input sig-mono', id: p + 'start', name: 'start', type: 'text', maxlength: '200', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', value: app ? app.start : ''});
    /* the way the app listens is offered only where the admin allows a port (or the app already has one): a socket is the way */
    var listen = null;
    if (A.ports || (app && app.listen === 'port')) {
      listen = el('select', {class: 'sig-select', id: p + 'listen', name: 'listen'}, [el('option', {value: 'socket', text: t('ah_listen_socket')}), el('option', {value: 'port', text: t('ah_listen_port')})]);
      listen.value = app ? app.listen : 'socket';
    }
    var env = el('textarea', {class: 'sig-input sig-mono fp-ah-env', id: p + 'env', name: 'env', rows: '4', spellcheck: 'false', autocapitalize: 'none', autocomplete: 'off'});
    env.value = app ? Object.keys(app.env).map(function (k) { return k + '=' + app.env[k]; }).join('\n') : '';
    var grid = [M.field(p + 'name', t('ah_f_name'), name, t(app ? 'ah_f_name_fixed' : 'ah_f_name_hint')), M.field(p + 'runtime', t('ah_f_runtime'), runtime, t('ah_f_runtime_hint')),
      M.field(p + 'domain', t('ah_f_domain'), domain, t('ah_f_domain_hint')), M.field(p + 'dir', t('ah_f_dir'), dir, t('ah_f_dir_hint')),
      M.field(p + 'start', t('ah_f_start'), start, t('ah_f_start_hint'))];
    if (listen) { grid.push(M.field(p + 'listen', t('ah_f_listen'), listen, t('ah_f_listen_hint'))); }
    var form = el('form', {class: 'fp-form fp-mail-form fp-ah-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-rules-grid'}, grid),
      M.field(p + 'env', t('ah_f_env'), env, t('ah_f_env_hint', {max: MAX_ENV})),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t(app ? 'ah_save' : 'ah_add')}),
        app ? el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'edit-cancel', text: t('cancel')}) : null])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var n = name.value.trim();
      if (!NAME_RE.test(n)) { M.fieldError(form, name, t('ah_name_bad')); return; }
      if (!app && A.apps.some(function (x) { return x.name === n; })) { M.fieldError(form, name, t('ah_name_taken', {name: n})); return; }
      if (!runtime.value) { M.fieldError(form, runtime, t('ah_runtime_none')); return; }
      if (!domain.value) { M.fieldError(form, domain, t('ah_domain_none')); return; }
      var d = plainPath(dir.value.trim());
      if (!d) { M.fieldError(form, dir, t('ah_path_bad', {what: t('ah_f_dir')})); return; }
      var s = plainPath(start.value.trim());
      if (!s) { M.fieldError(form, start, t('ah_path_bad', {what: t('ah_f_start')})); return; }
      var settings = readEnv(form, env);
      if (!settings) { return; }
      var body = {runtime: runtime.value, dir: d, start: s, domain: domain.value, env: settings};
      if (listen) { body.listen = listen.value; }
      var mine = A;
      UI.setBusy(b, true);
      call('put', 'appHostingApp', {app: n}, body).then(function (r) {
        if (A !== mine) { return; }
        take(mine, cleanApps(r));
        mine.editing = '';
        draw();
        say(n, t(app ? 'ah_saved' : 'ah_added', {name: n, domain: domain.value}));
        var h = A.page.querySelector('[data-fp-app="' + n + '"] .fp-ah-name');
        if (h) { h.focus(); }
      }, function (err) {
        UI.setBusy(b, false);
        if (A === mine) { M.failed(form, err); }
      });
    });
    return form;
  }

  function appItem(app) {
    var st = stateOf(app);
    var facts = [['runtime', t('ah_k_runtime'), runtimeTitle(app.runtime)], ['site', t('ah_k_site'), app.domain || '—'], ['dir', t('ah_k_dir'), app.dir || '—'],
      ['start', t('ah_k_start'), app.start || '—'], ['reach', t('ah_k_reach'), app.listen === 'port' ? t('ah_reach_port', {port: app.port}) : t('ah_reach_socket')],
      ['env', t('ah_k_env'), Object.keys(app.env).length ? Object.keys(app.env).join(', ') : t('ah_none')]];
    var acts = [];
    function button(act, key, cls) {
      return el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm' + (cls || ''), type: 'button', 'data-fp-act': act, 'aria-label': t(key + '_of', {name: app.name}), text: t(key)});
    }
    if (!A.suspended && A.enabled) {
      if (app.stopped) { acts.push(button('start', 'ah_start')); } else { acts.push(button('restart', 'ah_restart')); }
    }
    if (!A.suspended && !app.stopped) { acts.push(button('stop', 'ah_stop')); }
    acts.push(button(A.logs[app.name] ? 'logs-hide' : 'logs', A.logs[app.name] ? 'ah_log_hide' : 'ah_log'));
    if (!A.suspended && A.enabled) { acts.push(button('edit', 'ah_edit')); }
    acts.push(button('remove', 'ah_remove', ' fp-btn-danger-text'));
    var parts = [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-ah-head'}, [el('h3', {class: 'fp-h3 fp-ah-name sig-mono', tabindex: '-1', text: app.name}),
        el('span', {class: 'sig-pill' + st.cls, 'data-fp-state': st.key, text: t('ah_state_' + st.key)})]),
      el('dl', {class: 'fp-ah-facts'}, facts.map(function (f) { return el('div', {'data-fp-fact': f[0]}, [el('dt', {text: f[1]}), el('dd', {class: f[0] === 'runtime' ? '' : 'sig-mono', text: f[2]})]); }))];
    if (app.listen === 'port') { parts.push(el('p', {class: 'fp-muted fp-ah-portwarn', 'data-fp-portwarn': '', text: t('ah_port_warn', {port: app.port})})); }
    if (A.editing === app.name) {
      parts.push(appForm(app));
    } else {
      parts.push(el('div', {class: 'fp-actions fp-ah-acts'}, acts));
    }
    if (A.logs[app.name]) { parts.push(logBox(app, A.logs[app.name])); }
    return el('li', {class: 'fp-ah-app', 'data-fp-app': app.name}, parts);
  }
  function logBox(app, log) {
    var id = 'fp-ah-log-' + app.name;
    var body = log.lines.length ? el('pre', {class: 'fp-ah-log sig-mono', tabindex: '0', role: 'region', 'aria-label': t('ah_logbox_of', {name: app.name}), text: log.lines.join('\n')})
      : el('p', {class: 'fp-muted', 'data-fp-nolog': '', text: t('ah_log_empty')});
    return el('div', {class: 'fp-ah-logbox', id: id}, [el('p', {class: 'fp-muted', text: t('ah_log_note', {n: LOG_LINES})}), body,
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'logs', text: t('ah_log_again')})])]);
  }
  /* how a start file listens on the socket the panel gives it, for each language */
  function howCard() {
    var rows = RUNTIMES.map(function (id) {
      return el('tr', {'data-fp-how': id}, [el('th', {scope: 'row', text: runtimeTitle(id)}), el('td', {class: 'sig-mono', text: t('ah_how_' + id)})]);
    });
    return M.card('fp-ah-how-h', t('ah_how_title'), [el('p', {class: 'fp-muted', text: t('ah_how_intro')}),
      el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-ah-how-h'}, [el('table', {class: 'sig-table fp-ah-how'}, [
        el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('ah_how_col_lang')}), el('th', {scope: 'col', text: t('ah_how_col_code')})])]), el('tbody', null, rows)])])], 'fp-ah fp-ah-howcard');
  }

  function draw() {
    A.page.textContent = '';
    if (A.suspended) { A.page.appendChild(M.suspendedBanner(t('ah_suspended'))); }
    if (!A.enabled) { A.page.appendChild(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-off': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('ah_off')})])); }
    A.page.appendChild(el('p', {class: 'fp-muted fp-ah-lead', text: t('ah_lead')}));
    var list = [];
    if (!A.apps.length) {
      list.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('ah_empty')}));
    } else {
      list.push(el('p', {class: 'fp-muted', text: t('ah_count', {n: A.apps.length, max: A.max})}));
      list.push(el('ul', {class: 'fp-ah-list'}, A.apps.map(appItem)));
    }
    A.page.appendChild(M.card('fp-ah-list-h', t('ah_list_title'), list, 'fp-ah fp-ah-card'));
    if (A.suspended || !A.enabled) { return; }
    var add = [];
    if (A.apps.length >= A.max) {
      add.push(el('p', {class: 'fp-muted', 'data-fp-full': '', text: t('ah_full', {max: A.max})}));
    } else if (!A.runtimes.length) {
      add.push(el('p', {class: 'fp-muted', 'data-fp-no-runtime': '', text: t('ah_no_runtime')}));
    } else if (!A.sites.length) {
      add.push(el('p', {class: 'fp-muted', 'data-fp-no-site': '', text: t('ah_no_site')}));
    } else {
      add.push(el('p', {class: 'fp-muted', text: t('ah_add_intro')}));
      add.push(appForm(null));
    }
    A.page.appendChild(M.card('fp-ah-add-h', t('ah_add_title'), add, 'fp-ah fp-ah-add'));
    A.page.appendChild(howCard());
  }

  function control(button, name, action) {
    var mine = A;
    UI.setBusy(button, true);
    call('post', 'appHostingControl', {app: name}, {action: action}).then(function (r) {
      if (A !== mine) { return; }
      take(mine, cleanApps(r));
      draw();
      say(name, t('ah_done_' + action, {name: name}));
      var again = A.page.querySelector('[data-fp-app="' + name + '"] [data-fp-act]');
      if (again) { again.focus(); }
    }, function (err) {
      UI.setBusy(button, false);
      if (A === mine) { UI.showError(A.page.querySelector('[data-fp-app="' + name + '"]'), err.message); }
    });
  }
  function readLog(button, name) {
    var mine = A;
    UI.setBusy(button, true);
    call('get', 'appHostingLogs', {app: name, lines: String(LOG_LINES)}).then(function (r) {
      if (A !== mine) { return; }
      mine.logs[name] = {lines: arr(r && r.lines).filter(function (l) { return typeof l === 'string'; }).slice(0, 200).map(function (l) { return l.slice(0, 600); })};
      draw();
      var box = A.page.querySelector('[data-fp-app="' + name + '"] .fp-ah-log, [data-fp-app="' + name + '"] [data-fp-nolog]');
      if (box && box.focus) { box.focus(); }
    }, function (err) {
      UI.setBusy(button, false);
      if (A === mine) { UI.showError(A.page.querySelector('[data-fp-app="' + name + '"]'), err.message); }
    });
  }
  function onClick(e) {
    var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !A || !A.page.contains(b)) { return; }
    var act = b.getAttribute('data-fp-act');
    var li = b.closest('[data-fp-app]');
    var name = li ? li.getAttribute('data-fp-app') : '';
    var mine = A;
    if (act === 'start' || act === 'stop' || act === 'restart') {
      control(b, name, act);
    } else if (act === 'logs') {
      readLog(b, name);
    } else if (act === 'logs-hide') {
      delete A.logs[name];
      draw();
      var again = A.page.querySelector('[data-fp-app="' + name + '"] [data-fp-act="logs"]');
      if (again) { again.focus(); }
    } else if (act === 'edit') {
      A.editing = name;
      draw();
      A.page.querySelector('#fp-ah-e-runtime').focus();
    } else if (act === 'edit-cancel') {
      A.editing = '';
      draw();
      var opener = A.page.querySelector('[data-fp-app="' + name + '"] [data-fp-act="edit"]');
      if (opener) { opener.focus(); }
    } else if (act === 'remove') {
      M.confirmIn(b.closest('.fp-ah-acts'), t('ah_remove_ask', {name: name}), 'remove-yes', t('ah_remove'));
    } else if (act === 'confirm-no') {
      draw();
      var back = A.page.querySelector('[data-fp-app="' + name + '"] [data-fp-act="remove"]');
      if (back) { back.focus(); }
    } else if (act === 'remove-yes') {
      UI.setBusy(b, true);
      call('del', 'appHostingApp', {app: name}).then(function (r) {
        if (A !== mine) { return; }
        take(mine, cleanApps(r));
        delete mine.logs[name];
        draw();
        M.say(A.page.querySelector('.fp-ah-card'), t('ah_removed', {name: name}));
        A.page.querySelector('#fp-ah-list-h').focus();
      }, function (err) {
        UI.setBusy(b, false);
        if (A === mine) { UI.showError(A.page.querySelector('[data-fp-app="' + name + '"]'), err.message); }
      });
    }
  }

  FP.view('tool:app_hosting', function () {
    A = null;
    var tool = FP.tools.app_hosting;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('ah_desc'), cls: 'fp-mail fp-ahp',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    var mine = A = {page: page, account: FP.account(), sites: [], suspended: false, apps: [], max: 5, enabled: false, ports: false, runtimes: [], editing: '', logs: {}};
    page.addEventListener('click', onClick);
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all([call('get', 'appHosting'), FP.call('get', 'domains', undefined, mine.account).then(FP.cleanSites, function () { return {sites: [], suspended: false}; })]).then(function (r) {
      if (A !== mine) { return; }
      take(mine, cleanApps(r[0]));
      mine.sites = r[1].sites;
      mine.suspended = r[1].suspended;
      draw();
    }, function (err) {
      if (A !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err.message));
    });
  });

  /* ================= the admin's runtimes ================= */
  var R = null;

  function cleanRuntimes(r) {
    r = r && typeof r === 'object' ? r : {};
    return {runtimes: arr(r.runtimes).filter(function (x) { return x && typeof x === 'object' && RUNTIMES.indexOf(x.id) >= 0; })
      .map(function (x) { return {id: x.id, installed: x.installed === true, version: /^[0-9][0-9.]{0,15}$/.test(str(x.version, 16)) ? x.version : ''}; }),
    enabled: r.enabled === true, ports: r.ports === true, portApps: whole(r.port_apps), policy: r.socket_policy === true, domain: r.app_domain === true,
    dir: /^\/[A-Za-z0-9._/-]{1,100}$/.test(str(r.socket_dir, 101)) ? r.socket_dir : '',
    proxy: r.proxy_module === true, known: r.proxy_known === true, selinux: r.selinux === 'enforcing' || r.selinux === 'permissive' ? r.selinux : '', connect: r.network_connect === true};
  }
  function runtimeView(d) {
    var rows = d.runtimes.map(function (x) {
      return el('tr', {'data-fp-runtime': x.id}, [el('th', {scope: 'row', text: runtimeTitle(x.id)}),
        el('td', null, [el('span', {class: 'sig-pill' + (x.installed ? ' sig-pill--ok' : ''), 'data-fp-installed': x.installed ? 'yes' : 'no', text: t(x.installed ? 'ar_installed' : 'ar_not_installed')})]),
        el('td', {class: 'sig-mono', text: x.installed ? (x.version || '—') : '—'})]);
    });
    var parts = [el('p', {class: 'fp-muted', text: t('ar_intro')})];
    parts.push(d.enabled
      ? el('p', {class: 'fp-ar-switch', 'data-fp-switch': 'on'}, [el('span', {class: 'sig-pill sig-pill--ok', text: t('ar_sw_pill')}), el('span', {text: t('ar_sw_on')})])
      : el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-switch': 'off'}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('ar_sw_off')})]));
    parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-ar-h'}, [el('table', {class: 'sig-table fp-ar-table'}, [
      el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('ar_col_runtime')}), el('th', {scope: 'col', text: t('ar_col_state')}), el('th', {scope: 'col', text: t('ar_col_version')})])]),
      el('tbody', null, rows)])]));
    var checks = [['proxy', d.known ? (d.proxy ? 'ok' : 'bad') : 'unknown', d.known ? (d.proxy ? 'ar_proxy_ok' : 'ar_proxy_bad') : 'ar_proxy_unknown']];
    checks.push(['selinux', !d.selinux ? 'off' : (d.policy && d.domain ? 'ok' : 'bad'), !d.selinux ? 'ar_selinux_off' : (!d.policy ? 'ar_selinux_bad' : d.domain ? 'ar_selinux_ok' : 'ar_selinux_stale')]);
    var reach = [el('p', {class: 'fp-muted', text: t('ar_reach_intro')}), el('ul', {class: 'fp-ar-checks'}, checks.map(function (c) {
      return el('li', {'data-fp-check': c[0], 'data-fp-result': c[1]}, [el('span', {class: 'sig-pill' + (c[1] === 'ok' ? ' sig-pill--ok' : c[1] === 'bad' ? ' sig-pill--danger' : ''), text: t('ar_r_' + c[1])}),
        el('span', {text: t(c[2], {mode: d.selinux})})]);
    }))];
    if (d.dir) { reach.push(el('p', {class: 'fp-muted', 'data-fp-socket-dir': '', text: t('ar_socket_dir', {dir: d.dir})})); }
    return [M.card('fp-ar-h', t('ar_apps_title'), parts, 'fp-ar'), M.card('fp-ar-reach-h', t('ar_reach'), reach, 'fp-ar-reach'), portsCard(d)];
  }
  /* the one choice the admin has: may an app listen on a port of the loopback, which every account on the server shares */
  function portsCard(d) {
    var pill = el('span', {class: 'sig-pill' + (d.ports ? ' sig-pill--warn' : ' sig-pill--ok'), 'data-fp-ports': d.ports ? 'on' : 'off', text: t(d.ports ? 'ar_ports_on' : 'ar_ports_off')});
    var parts = [el('p', {class: 'fp-ar-ports-state'}, [pill, el('span', {text: t(d.ports ? 'ar_ports_on_note' : 'ar_ports_off_note')})]),
      el('p', {class: 'fp-muted', text: t('ar_ports_risk')})];
    if ((d.ports || d.portApps) && d.selinux && !d.connect) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-ports-selinux': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('ar_ports_selinux', {mode: d.selinux})})]));
    }
    if (d.portApps) { parts.push(el('p', {class: 'fp-muted', 'data-fp-port-apps': '', text: t('ar_ports_used', {n: d.portApps})})); }
    var form = el('form', {class: 'fp-form fp-mail-form fp-ar-ports-form', novalidate: ''}, [M.errorLine(), M.statusLine(), el('div', {class: 'fp-actions fp-ar-ports-acts'}, [
      el('button', {class: 'sig-btn ' + (d.ports ? 'sig-btn--secondary' : 'sig-btn--primary') + ' fp-submit', type: 'submit', 'aria-describedby': d.ports && d.portApps ? 'fp-ar-ports-used' : null,
        text: t(d.ports ? 'ar_ports_stop' : 'ar_ports_allow')})])]);
    if (d.ports && d.portApps) {
      form.querySelector('.fp-submit').disabled = true;
      form.querySelector('.fp-submit').setAttribute('aria-disabled', 'true');
      parts[parts.length - 1].id = 'fp-ar-ports-used';
    }
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      if (!d.ports) {
        /* turning ports on is asked first, with the risk said again beside the answer */
        M.confirmIn(form.querySelector('.fp-ar-ports-acts'), t('ar_ports_ask'), 'ports-yes', t('ar_ports_allow'));
        return;
      }
      save(form, b, false);
    });
    form.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
      if (!b) { return; }
      var act = b.getAttribute('data-fp-act');
      if (act === 'confirm-no') {
        R.page.replaceChild(portsCard(R.data), R.page.querySelector('.fp-ar-ports'));
        var again = R.page.querySelector('.fp-ar-ports .fp-submit');
        if (again) { again.focus(); }
      } else if (act === 'ports-yes') {
        save(form, b, true);
      }
    });
    parts.push(form);
    return M.card('fp-ar-ports-h', t('ar_ports_title'), parts, 'fp-ar-ports');
  }
  function save(form, button, allowed) {
    var mine = R;
    UI.setBusy(button, true);
    FP.call('put', 'appPorts', {allowed: allowed}).then(function (r) {
      if (R !== mine) { return; }
      r = r && typeof r === 'object' ? r : {};
      mine.data.ports = r.ports === true;
      mine.data.portApps = whole(r.port_apps);
      var card = portsCard(mine.data);
      mine.page.replaceChild(card, mine.page.querySelector('.fp-ar-ports'));
      M.say(card, t(mine.data.ports ? 'ar_ports_saved_on' : 'ar_ports_saved_off'));
      card.querySelector('#fp-ar-ports-h').focus();
    }, function (err) {
      UI.setBusy(button, false);
      if (R !== mine) { return; }
      /* a refusal after the question: the card is drawn again, with the server's words in it */
      var card = portsCard(mine.data);
      mine.page.replaceChild(card, mine.page.querySelector('.fp-ar-ports'));
      M.failed(card.querySelector('form'), err);
    });
  }
  FP.view('tool:app_runtimes', function () {
    R = null;
    var tool = FP.tools.app_runtimes;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('ar_desc'), cls: 'fp-mail fp-arp',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    var mine = R = {page: page, data: null};
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'appRuntimes').then(function (r) {
      if (R !== mine) { return; }
      page.textContent = '';
      mine.data = cleanRuntimes(r);
      runtimeView(mine.data).forEach(function (c) { page.appendChild(c); });
    }, function (err) {
      if (R !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

/* freePanel panel analytics (docs/api.md, "Panel analytics"; docs/panel-analytics.md). Two parts:
   - in every panel, while the server offers panel_usage (the admin has analytics on, and the login is the owner's own: no team member, staff login
     or support session is offered it), each page opened posts its key (home, group:<id>, tool:<id> or a page of the panel's own) to this server's
     own /api/v1/panel-usage. Nothing else is sent, and nothing goes anywhere but the panel's own server;
   - the administrator's page (#/tool/panel_analytics): the switch, per-login counts, the days kept, what is recorded, and the counts drawn as inline
     SVG made here (no outside script, no inline style: it holds under the panel's CSP), each chart with its numbers as a table too.
   Everything the server sends is shown as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;
  var M = FP.mail;

  var TOOL = 'panel_analytics';
  var PAGE_RE = /^([a-z][a-z0-9-]{0,39}|group:[a-z0-9_]{1,40}|tool:[a-z0-9_]{1,40})$/;
  var SVGNS = 'http://www.w3.org/2000/svg';

  /* ---- counting what is opened ---- */
  function keyOf(r) {
    r = r || {};
    var k = r.view === 'tool' ? 'tool:' + r.id : r.view === 'group' ? 'group:' + r.id : r.view || 'home';
    return PAGE_RE.test(k) ? k : '';
  }
  var counted = null;
  function count() {
    var r = FP.current;
    if (!r || r === counted || !FP.session || !B.has('panel_usage')) { return; }
    counted = r;
    var k = keyOf(r);
    if (k) { FP.call('post', 'panelUsage', {page: k}).then(null, function () { /* a count that failed is not shown */ }); }
  }
  document.addEventListener('fp:ready', function () {
    window.setTimeout(count, 0);
    window.addEventListener('hashchange', function () { window.setTimeout(count, 0); });
  });

  /* ---- the administrator's page ---- */
  var S = {page: null, busy: false, days: 30, panel: '', table: false, data: null, labels: {}};

  /* the labels of both panels' pages, from their lists; a key with none is shown as it is */
  var labelsRead = null;
  function readLabels() {
    if (!labelsRead) {
      labelsRead = Promise.all(['admin', 'user'].map(function (realm) {
        return window.fetch('/assets/registry/' + realm + '.json', {credentials: 'same-origin'}).then(function (r) { return r.ok ? r.json() : null; })
          .then(function (reg) {
            var out = {};
            ((reg && reg.groups) || []).forEach(function (g) {
              if (g && typeof g.id === 'string') { out['group:' + g.id] = B.str(g.label, 80); }
              ((g && g.tools) || []).forEach(function (x) { if (x && typeof x.id === 'string') { out['tool:' + x.id] = B.str(x.label, 80); } });
            });
            return out;
          }, function () { return {}; });
      })).then(function (r) { S.labels = {admin: r[0], user: r[1]}; });
    }
    return labelsRead;
  }
  function pageLabel(panel, key) {
    var own = {home: t('menu_home'), 'not-found': t('not_found'), 'two-factor': t('pan_page_two_factor')};
    var l = (S.labels[panel] || {})[key] || own[key];
    return l ? l : key;
  }
  function panelName(p) { return p === 'admin' ? t('pan_panel_admin') : t('pan_panel_user'); }

  function cleanSettings(v) {
    v = v && typeof v === 'object' ? v : {};
    var days = Number.isInteger(v.retention_days) ? v.retention_days : 90;
    return {enabled: v.enabled === true, per_login: v.per_login === true, retention_days: days};
  }
  function n(v) { return Number.isInteger(v) && v >= 0 ? v : 0; }
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var day = /^\d{4}-\d{2}-\d{2}$/;
    return {settings: cleanSettings(r.settings), total: n(r.total),
      days: (Array.isArray(r.days) ? r.days.slice(0, 730) : []).filter(function (d) { return d && day.test(d.day); }).map(function (d) { return {day: d.day, uses: n(d.uses)}; }),
      pages: (Array.isArray(r.pages) ? r.pages.slice(0, 50) : []).filter(function (p) { return p && PAGE_RE.test(p.page) && (p.panel === 'admin' || p.panel === 'user'); })
        .map(function (p) { return {panel: p.panel, page: p.page, uses: n(p.uses)}; }),
      logins: (Array.isArray(r.logins) ? r.logins.slice(0, 50) : []).filter(function (l) { return l && typeof l.login === 'string'; })
        .map(function (l) { return {panel: l.panel === 'admin' ? 'admin' : 'user', login: B.str(l.login, 64), uses: n(l.uses), pages: n(l.pages)}; })};
  }

  /* ---- drawing: inline SVG made with the DOM, its colours from panel.css ---- */
  function svg(name, attrs, kids) {
    var node = document.createElementNS(SVGNS, name);
    Object.keys(attrs || {}).forEach(function (k) { node.setAttribute(k, String(attrs[k])); });
    (kids || []).forEach(function (c) { if (c) { node.appendChild(c); } });
    return node;
  }
  function stext(attrs, s) { var n2 = svg('text', attrs); n2.textContent = s; return n2; }
  /* a top a little above max that reads well: 1, 2 or 5 times a power of ten */
  function niceTop(max) {
    if (max <= 4) { return 4; }
    var p = Math.pow(10, Math.floor(Math.log10(max)));
    var steps = [1, 2, 5, 10];
    for (var i = 0; i < steps.length; i++) { if (steps[i] * p >= max) { return steps[i] * p; } }
    return 10 * p;
  }
  /* a bar with its top corners rounded, standing on the baseline */
  function barPath(x, y, w, h) {
    var r = Math.min(4, w / 2, h);
    return 'M' + x + ',' + (y + h) + 'V' + (y + r) + 'Q' + x + ',' + y + ' ' + (x + r) + ',' + y + 'H' + (x + w - r) + 'Q' + (x + w) + ',' + y + ' ' + (x + w) + ',' + (y + r) +
      'V' + (y + h) + 'Z';
  }
  function dayShort(d) {
    var x = new Date(d + 'T00:00:00Z');
    return x.toLocaleDateString('en', {month: 'short', day: 'numeric', timeZone: 'UTC'});
  }
  function dailyChart(days, width) {
    var W = Math.max(260, Math.round(width));
    var H = 200;
    var left = 40;
    var right = 8;
    var top = 10;
    var bottom = 26;
    var pw = W - left - right;
    var ph = H - top - bottom;
    var max = days.reduce(function (m, d) { return Math.max(m, d.uses); }, 0);
    var topV = niceTop(max);
    var slot = pw / Math.max(1, days.length);
    var gap = slot > 6 ? 2 : 1;
    var kids = [svg('title', {id: 'fp-pan-chart-t'}), svg('desc', {id: 'fp-pan-chart-d'})];
    kids[0].textContent = t('pan_chart_title');
    kids[1].textContent = t('pan_chart_desc', {days: String(days.length), total: B.num(days.reduce(function (s, d) { return s + d.uses; }, 0)), max: B.num(max)});
    [0, 0.5, 1].forEach(function (f) {
      var y = top + ph - f * ph;
      kids.push(svg('line', {class: f === 0 ? 'fp-pan-base' : 'fp-pan-grid', x1: left, x2: W - right, y1: y, y2: y}));
      kids.push(stext({class: 'fp-pan-tick', x: left - 6, y: y + 4, 'text-anchor': 'end'}, B.num(Math.round(topV * f))));
    });
    days.forEach(function (d, i) {
      var h = topV ? (d.uses / topV) * ph : 0;
      var x = left + i * slot + gap / 2;
      var w = Math.max(1, slot - gap);
      var tip = svg('title');
      tip.textContent = t('pan_bar_tip', {day: B.day(d.day), uses: B.num(d.uses)});
      kids.push(svg('g', {class: 'fp-pan-day', 'data-fp-day': d.day}, [tip,
        svg('rect', {class: 'fp-pan-hit', x: left + i * slot, y: top, width: slot, height: ph}),
        h > 0 ? svg('path', {class: 'fp-pan-bar', d: barPath(x, top + ph - h, w, h)}) : null]));
    });
    var marks = days.length > 1 ? [0, Math.floor((days.length - 1) / 2), days.length - 1] : [0];
    marks.forEach(function (i, k) {
      if (!days[i]) { return; }
      var anchor = k === 0 ? 'start' : k === marks.length - 1 ? 'end' : 'middle';
      var x = k === 0 ? left : k === marks.length - 1 ? W - right : left + (i + 0.5) * slot;
      kids.push(stext({class: 'fp-pan-tick', x: x, y: H - 8, 'text-anchor': anchor}, dayShort(days[i].day)));
    });
    return svg('svg', {class: 'fp-pan-chart', viewBox: '0 0 ' + W + ' ' + H, width: W, height: H, role: 'img', 'aria-labelledby': 'fp-pan-chart-t fp-pan-chart-d'}, kids);
  }
  /* a bar for a row of a table: its length is the row's share of the most used */
  function rowBar(uses, max) {
    var w = max ? Math.max(1, Math.round((uses / max) * 100)) : 0;
    return svg('svg', {class: 'fp-pan-rowbar', viewBox: '0 0 100 8', preserveAspectRatio: 'none', 'aria-hidden': 'true', focusable: 'false'},
      [svg('rect', {class: 'fp-pan-track', x: 0, y: 0, width: 100, height: 8, rx: 2}), w ? svg('rect', {class: 'fp-pan-bar', x: 0, y: 0, width: w, height: 8, rx: 2}) : null]);
  }

  /* ---- the cards ---- */
  function settingsCard(s) {
    var form = el('form', {class: 'fp-form fp-pan-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'sig-field'}, [el('label', {class: 'fp-bil-check'}, [el('input', {type: 'checkbox', name: 'enabled', id: 'fp-pan-on', checked: s.enabled ? true : null,
        'aria-describedby': 'fp-pan-on-hint'}), el('span', {text: t('pan_on')})]), el('span', {class: 'sig-hint', id: 'fp-pan-on-hint', text: t('pan_on_hint')})]),
      el('div', {class: 'sig-field'}, [el('label', {class: 'fp-bil-check'}, [el('input', {type: 'checkbox', name: 'per_login', id: 'fp-pan-login', checked: s.per_login ? true : null,
        'aria-describedby': 'fp-pan-login-hint'}), el('span', {text: t('pan_login')})]), el('span', {class: 'sig-hint', id: 'fp-pan-login-hint', text: t('pan_login_hint')})]),
      M.field('fp-pan-keep', t('pan_keep'), el('input', {class: 'sig-input fp-pan-keep', id: 'fp-pan-keep', name: 'retention_days', type: 'number', inputmode: 'numeric',
        min: '7', max: '730', step: '1', value: String(s.retention_days)}), t('pan_keep_hint')),
      el('div', {class: 'fp-actions'}, [B.button('pan-save', t('pan_save'), 'sig-btn--primary fp-submit', {type: 'submit'})]),
      el('div', {class: 'fp-actions fp-pan-clear'}, [B.button('pan-clear', t('pan_clear'), 'sig-btn--secondary')])]);
    return M.card('fp-pan-set-h', t('pan_set_title'), [s.enabled ? null : el('p', {class: 'fp-muted', 'data-fp-pan-off': '', text: t('pan_off_note')}), form], 'fp-pan-set');
  }
  function recordedCard() {
    return M.card('fp-pan-what-h', t('pan_what_title'), [el('ul', {class: 'fp-pan-what'}, ['pan_what_1', 'pan_what_2', 'pan_what_3', 'pan_what_4', 'pan_what_5', 'pan_what_6']
      .map(function (k) { return el('li', {text: t(k)}); }))], 'fp-pan-what-card');
  }
  function filters() {
    return el('div', {class: 'fp-pan-filters'}, [
      M.field('fp-pan-days', t('pan_range'), B.select('fp-pan-days', 'days', [['7', t('pan_range_7')], ['30', t('pan_range_30')], ['90', t('pan_range_90')]], String(S.days))),
      M.field('fp-pan-panel', t('pan_panel'), B.select('fp-pan-panel', 'panel', [['', t('pan_panel_all')], ['user', t('pan_panel_user')], ['admin', t('pan_panel_admin')]], S.panel))]);
  }
  function chartCard(d) {
    var parts = [filters(), el('p', {class: 'fp-pan-total', 'data-fp-pan-total': '', text: t('pan_total', {total: B.num(d.total), days: String(d.days.length)})})];
    if (!d.total) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t(d.settings.enabled ? 'pan_none_yet' : 'pan_none_off')}));
    } else {
      parts.push(el('div', {class: 'fp-pan-chart-wrap', 'data-fp-pan-chart': ''}));
      var table = B.table('fp-pan-chart-h', 'fp-pan-days-table', [B.th(t('pan_col_day')), B.th(t('pan_col_uses'), 'fp-num')],
        d.days.slice().reverse().map(function (x) { return el('tr', null, [el('td', {text: B.day(x.day)}), el('td', {class: 'fp-num', text: B.num(x.uses)})]); }));
      table.id = 'fp-pan-days-wrap';
      table.hidden = !S.table;
      parts.push(el('div', {class: 'fp-pan-table'}, [B.button('pan-table', t(S.table ? 'pan_as_table_hide' : 'pan_as_table'), 'sig-btn--secondary sig-btn--sm',
        {'aria-expanded': S.table ? 'true' : 'false', 'aria-controls': 'fp-pan-days-wrap'}), table]));
    }
    return M.card('fp-pan-chart-h', t('pan_chart_title'), parts, 'fp-pan-chart-card');
  }
  function pagesCard(d) {
    var max = d.pages.reduce(function (m, p) { return Math.max(m, p.uses); }, 0);
    var body = d.pages.length ? B.table('fp-pan-pages-h', 'fp-pan-pages', [B.th(t('pan_col_page')), B.th(t('pan_col_panel')), B.th(t('pan_col_uses'), 'fp-num'),
      B.th(t('pan_col_share'), 'fp-pan-barcol')], d.pages.map(function (p) {
      return el('tr', {'data-fp-pan-page': p.panel + ' ' + p.page}, [el('td', null, [el('span', {class: 'fp-pan-label', text: pageLabel(p.panel, p.page)}),
        el('span', {class: 'fp-muted fp-pan-key', text: p.page})]), el('td', {text: panelName(p.panel)}), el('td', {class: 'fp-num', text: B.num(p.uses)}),
        el('td', {class: 'fp-pan-barcol'}, [rowBar(p.uses, max)])]);
    })) : el('p', {class: 'fp-muted', text: t('pan_pages_none')});
    return M.card('fp-pan-pages-h', t('pan_pages_title'), [body], 'fp-pan-pages-card');
  }
  function loginsCard(d) {
    if (!d.settings.per_login) { return null; }
    var body = d.logins.length ? B.table('fp-pan-logins-h', 'fp-pan-logins', [B.th(t('pan_col_login')), B.th(t('pan_col_panel')), B.th(t('pan_col_uses'), 'fp-num'),
      B.th(t('pan_col_pages'), 'fp-num')], d.logins.map(function (l) {
      return el('tr', null, [el('td', {class: 'fp-pan-login', text: l.login}), el('td', {text: panelName(l.panel)}), el('td', {class: 'fp-num', text: B.num(l.uses)}),
        el('td', {class: 'fp-num', text: B.num(l.pages)})]);
    })) : el('p', {class: 'fp-muted', text: t('pan_logins_none')});
    return M.card('fp-pan-logins-h', t('pan_logins_title'), [el('p', {class: 'fp-muted', text: t('pan_logins_hint')}), body], 'fp-pan-logins-card');
  }
  function drawChart() {
    var wrap = S.page && S.page.querySelector('[data-fp-pan-chart]');
    if (!wrap || !S.data) { return; }
    wrap.textContent = '';
    wrap.appendChild(dailyChart(S.data.days, wrap.clientWidth || 600));
  }
  function render(focus) {
    var d = S.data;
    S.page.textContent = '';
    [settingsCard(d.settings), chartCard(d), pagesCard(d), loginsCard(d), recordedCard()].forEach(function (c) { if (c) { S.page.appendChild(c); } });
    drawChart();
    var h = focus && S.page.querySelector(focus);
    if (h) { h.focus(); }
  }
  function read() {
    var arg = {days: String(S.days)};
    var name = 'panelAnalyticsRead';
    if (S.panel) { arg.panel = S.panel; name = 'panelAnalyticsPanel'; }
    return Promise.all([FP.call('get', name, undefined, arg), readLabels()]).then(function (r) { S.data = clean(r[0]); });
  }
  function reload(focus) {
    var mine = S.page;
    return read().then(function () { if (S.page === mine) { render(focus); } }, function (err) {
      if (S.page !== mine) { return; }
      UI.showError(S.page.querySelector('.fp-pan-chart-card') || S.page, err.message);
    });
  }

  function save(form) {
    var b = form.querySelector('[data-fp-act="pan-save"]');
    if (S.busy || !B.begin(form, b)) { return; }
    var keep = form.elements.retention_days;
    var v = keep.value.trim();
    if (!/^[0-9]{1,3}$/.test(v) || Number(v) < 7 || Number(v) > 730) { M.fieldError(form, keep, t('pan_keep_bad')); return; }
    var body = {enabled: form.elements.enabled.checked, per_login: form.elements.per_login.checked, retention_days: Number(v)};
    S.busy = true;
    UI.setBusy(b, true);
    var mine = S.page;
    FP.call('patch', 'panelAnalytics', body).then(function () {
      S.busy = false;
      if (S.page !== mine) { return null; }
      return read().then(function () {
        render();
        M.say(S.page.querySelector('.fp-pan-form'), t('pan_saved'));
        var f = S.page.querySelector('#fp-pan-on');
        if (f) { f.focus(); }
      });
    }, function (err) {
      S.busy = false;
      if (S.page !== mine) { return; }
      UI.setBusy(b, false);
      B.failed(form, err);
    });
  }
  function clearAll(b) {
    var form = S.page.querySelector('.fp-pan-form');
    if (S.busy || !B.begin(form, b)) { return; }
    S.busy = true;
    UI.setBusy(b, true);
    var mine = S.page;
    FP.call('del', 'panelAnalytics').then(function () {
      S.busy = false;
      if (S.page !== mine) { return null; }
      return read().then(function () {
        render();
        M.say(S.page.querySelector('.fp-pan-form'), t('pan_cleared'));
        var h = S.page.querySelector('#fp-pan-set-h');
        if (h) { h.focus(); }
      });
    }, function (err) {
      S.busy = false;
      if (S.page !== mine) { return; }
      UI.setBusy(b, false);
      UI.showError(form, err.message);
    });
  }

  document.addEventListener('submit', function (e) {
    if (!S.page || !S.page.contains(e.target)) { return; }
    e.preventDefault();
    if (e.target.classList.contains('fp-pan-form')) { save(e.target); }
  });
  document.addEventListener('click', function (e) {
    var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !S.page || !S.page.contains(b)) { return; }
    var a = b.getAttribute('data-fp-act');
    var row = S.page.querySelector('.fp-pan-clear');
    if (a === 'pan-table') {
      S.table = !S.table;
      var wrap = S.page.querySelector('#fp-pan-days-wrap');
      if (wrap) { wrap.hidden = !S.table; }
      b.setAttribute('aria-expanded', S.table ? 'true' : 'false');
      b.textContent = t(S.table ? 'pan_as_table_hide' : 'pan_as_table');
    } else if (a === 'pan-clear') {
      M.confirmIn(row, t('pan_clear_ask'), 'pan-clear-yes', t('pan_clear_yes'));
    } else if (a === 'pan-clear-yes') {
      clearAll(b);
    } else if (a === 'confirm-no' && row && row.contains(b)) {
      row.textContent = '';
      row.appendChild(B.button('pan-clear', t('pan_clear'), 'sig-btn--secondary'));
      row.firstChild.focus();
    }
  });
  document.addEventListener('change', function (e) {
    if (!S.page || !S.page.contains(e.target)) { return; }
    if (e.target.id === 'fp-pan-days') { S.days = Number(e.target.value) || 30; reload('#fp-pan-days'); }
    if (e.target.id === 'fp-pan-panel') { S.panel = e.target.value === 'admin' || e.target.value === 'user' ? e.target.value : ''; reload('#fp-pan-panel'); }
  });
  var resized = 0;
  window.addEventListener('resize', function () {
    window.clearTimeout(resized);
    resized = window.setTimeout(drawChart, 150);
  });

  FP.view('tool:' + TOOL, function () {
    var body = B.frame(TOOL, 'fp-pan-page');
    if (!body) { return; }
    S.page = body;
    S.busy = false;
    S.days = 30;
    S.panel = '';
    S.table = false;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    read().then(function () {
      if (S.page !== body) { return; }
      render();
    }, function (err) {
      if (S.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(FP.tools[TOOL].label, err.message));
    });
  });
})();

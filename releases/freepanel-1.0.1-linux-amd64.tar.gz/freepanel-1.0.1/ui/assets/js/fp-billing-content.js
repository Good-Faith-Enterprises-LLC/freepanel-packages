/* freePanel billing content for clients (docs/api.md, "Billing: content"; docs/billing/navigation-map.md, "Support"): Announcements
   (#/tool/billing_announcements), the knowledge base (#/tool/billing_kb) and Downloads (#/tool/billing_downloads). Every text is plain text:
   the customer area shows it as text, never as markup, and so does this page. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;

  function strings(p) {
    return {none: t(p + '_none'), addTitle: t(p + '_add_title'), addSave: t(p + '_add'), editTitle: function (n) { return t('bil_change_title', {name: n}); },
      added: function (n) { return t('bil_added', {name: n}); }, saved: function (n) { return t('bil_saved', {name: n}); }, removed: function (n) { return t('bil_removed', {name: n}); },
      removeAsk: function (n) { return t(p + '_remove_ask', {name: n}); }, removeYes: t(p + '_remove_yes')};
  }
  function view(toolId, cls, make) {
    FP.view('tool:' + toolId, function () {
      var page = B.frame(toolId, cls);
      if (!page) { return; }
      page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
      make(page, function () { return page.isConnected; }).show();
    });
  }
  var PUB = [['draft', t('ban_draft')], ['published', t('ban_published')]];
  function pubPill(status) { return B.pill(status === 'published' ? t('ban_published') : t('ban_draft'), status === 'published' ? 'ok' : '', {'data-fp-status-of': status}); }

  /* ---- announcements ---- */
  view('billing_announcements', 'fp-ban', function (page, alive) {
    return B.crud({page: page, pre: 'fp-ban', title: t('ban_title'), alive: alive,
      what: function () { return [el('p', {class: 'fp-muted', text: t('ban_what')})]; },
      load: function () {
        return FP.call('get', 'billingAnnouncements', undefined, {}).then(function (r) {
          return B.pickAll(r && r.announcements, {id: 'id', title: [150], body: [20000], status: ['=', ['draft', 'published']], pinned: 'b', published: 'w', created_by: [64]}, 'id');
        });
      },
      heads: [B.th(t('ban_col_title')), B.th(t('ban_col_status')), B.th(t('ban_col_published')), B.th(t('ban_col_pinned'))],
      cells: function (a) {
        return [el('th', {scope: 'row', class: 'fp-bil-wrap', text: a.title}), el('td', null, [pubPill(a.status)]), el('td', {class: 'fp-bil-nowrap', text: B.day(a.published) || '—'}),
          el('td', {text: t(a.pinned ? 'bil_yes' : 'bil_no')})];
      },
      fields: [{name: 'title', label: t('ban_f_title'), required: true, max: 150, wide: true},
        {name: 'body', label: t('ban_f_body'), kind: 'textarea', required: true, max: 20000, rows: 8, hint: t('ban_f_body_hint'), wide: true},
        {name: 'status', label: t('ban_col_status'), kind: 'select', options: PUB, value: 'draft', hint: t('ban_f_status_hint')},
        {name: 'pinned', label: t('ban_f_pinned'), kind: 'check', hint: t('ban_f_pinned_hint')}],
      add: 'billingAnnouncements', item: 'billingAnnouncement', nameOf: function (a) { return a.title; }, strings: strings('ban')});
  });

  /* ---- the knowledge base: categories, then the articles in them ---- */
  FP.view('tool:billing_kb', function () {
    var page = B.frame('billing_kb', 'fp-bkb');
    if (!page) { return; }
    var alive = function () { return page.isConnected; };
    var cats = el('div', {'data-fp-part': 'categories'});
    var arts = el('div', {class: 'fp-bkb-articles', 'data-fp-part': 'articles'});
    page.appendChild(cats);
    page.appendChild(arts);
    var categories = [];
    var read = false;
    var CAT = {id: 'id', name: [80], description: [200], position: 'n', hidden: 'b', articles: 'n'};
    var ART = {id: 'id', category_id: 'id', title: [150], slug: [80], body: [50000], status: ['=', ['draft', 'published']], position: 'n', views: 'n'};
    function catName(cid) { for (var i = 0; i < categories.length; i++) { if (categories[i].id === cid) { return categories[i].name; } } return '—'; }
    var C2 = B.crud({page: cats, pre: 'fp-bkc', title: t('bkb_cats'), alive: alive,
      what: function () { return [el('p', {class: 'fp-muted', text: t('bkb_cats_what')})]; },
      load: function () {
        return FP.call('get', 'billingKbCategories').then(function (r) { categories = B.pickAll(r && r.categories, CAT, 'id'); read = true; return categories; });
      },
      heads: [B.th(t('bkb_col_name')), B.th(t('bkb_col_position'), 'fp-bil-num'), B.th(t('bkb_col_hidden')), B.th(t('bkb_col_articles'), 'fp-bil-num')],
      cells: function (k) {
        return [el('th', {scope: 'row', class: 'fp-bil-wrap', text: k.name}), el('td', {class: 'fp-bil-num', text: k.position === null ? '—' : B.num(k.position)}),
          el('td', {text: t(k.hidden ? 'bil_yes' : 'bil_no')}), el('td', {class: 'fp-bil-num', text: k.articles === null ? '—' : B.num(k.articles)})];
      },
      removable: function (k) { return !k.articles; },
      fields: [{name: 'name', label: t('bkb_col_name'), required: true, max: 80}, {name: 'description', label: t('bkb_f_desc'), max: 200},
        {name: 'position', label: t('bkb_col_position'), kind: 'number', hint: t('bkb_f_position_hint'), max: 5}, {name: 'hidden', label: t('bkb_f_hidden'), kind: 'check', hint: t('bkb_f_hidden_hint')}],
      add: 'billingKbCategories', item: 'billingKbCategory', nameOf: function (k) { return k.name; }, strings: strings('bkc'),
      changed: function () { if (alive()) { A2.show(); } }});
    var A2 = B.crud({page: arts, pre: 'fp-bka', title: t('bkb_arts'), alive: alive,
      what: function () { return [el('p', {class: 'fp-muted', text: t('bkb_arts_what')})]; },
      load: function () {
        return FP.call('get', 'billingKbArticles', undefined, {}).then(function (r) { return B.pickAll(r && r.articles, ART, 'id'); });
      },
      fetch: function (x) { return FP.call('get', 'billingKbArticle', undefined, {id: String(x.id)}).then(function (r) { return B.pick(r, ART) || x; }); },
      heads: [B.th(t('bkb_col_title')), B.th(t('bkb_col_category')), B.th(t('bkb_col_status')), B.th(t('bkb_col_slug')), B.th(t('bkb_col_views'), 'fp-bil-num')],
      cells: function (x) {
        return [el('th', {scope: 'row', class: 'fp-bil-wrap', text: x.title}), el('td', {class: 'fp-bil-wrap', text: catName(x.category_id)}), el('td', null, [pubPill(x.status)]),
          el('td', {class: 'fp-bil-wrap'}, [el('code', {text: x.slug})]), el('td', {class: 'fp-bil-num', text: x.views === null ? '—' : B.num(x.views)})];
      },
      canAdd: function () { return categories.length > 0; },
      below: function () { return categories.length ? [] : [el('p', {class: 'fp-muted', 'data-fp-no-category': '', text: t('bkb_no_category')})]; },
      fieldsFor: function () {
        return [{name: 'title', label: t('bkb_col_title'), required: true, max: 150, wide: true},
          {name: 'category_id', label: t('bkb_col_category'), kind: 'select', num: true, options: categories.map(function (k) { return [String(k.id), k.name]; }), value: categories.length ? categories[0].id : ''},
          {name: 'slug', label: t('bkb_col_slug'), max: 80, code: true, hint: t('bkb_f_slug_hint')},
          {name: 'status', label: t('bkb_col_status'), kind: 'select', options: PUB, value: 'draft'},
          {name: 'position', label: t('bkb_col_position'), kind: 'number', max: 5, hint: t('bkb_f_position_hint')},
          {name: 'body', label: t('bkb_f_body'), kind: 'textarea', required: true, max: 50000, rows: 10, hint: t('ban_f_body_hint'), wide: true}];
      },
      add: 'billingKbArticleNew', item: 'billingKbArticle', nameOf: function (x) { return x.title; }, strings: strings('bka'),
      changed: function () { if (alive()) { C2.show(); } }});
    /* the articles are drawn once the categories are known, and again when a category changes */
    C2.show().then(function () { if (alive() && read) { A2.show(); } });
  });

  /* ---- downloads: files for clients, added as they are; published or not, for every client or those with an active service ---- */
  var FILE_RE = /^[A-Za-z0-9][A-Za-z0-9 ._()-]{0,99}$/;
  var KINDS = /\.(pdf|png|jpe?g|gif|txt|log|csv|zip|gz|tgz|tar)$/i;
  var AUD = [['customers', t('bdl_aud_customers')], ['active', t('bdl_aud_active')]];
  function size(n) { return n === null ? '—' : n < 1024 ? t('bsp_bytes', {n: B.num(n)}) : n < 1048576 ? t('bsp_kb', {n: (n / 1024).toFixed(1)}) : t('bsp_mb', {n: (n / 1048576).toFixed(1)}); }
  FP.view('tool:billing_downloads', function () {
    var page = B.frame('billing_downloads', 'fp-bdl');
    if (!page) { return; }
    var alive = function () { return page.isConnected; };
    var R = null;
    function uploadCard() {
      var file = el('input', {type: 'file', id: 'fp-bdl-u-file', name: 'file', class: 'fp-btk-file-input', 'aria-required': 'true', 'aria-describedby': 'fp-bdl-u-file-hint'});
      var specs = [{name: 'title', label: t('bdl_col_title'), max: 150, hint: t('bdl_title_hint')}, {name: 'description', label: t('bdl_f_desc'), max: 300},
        {name: 'audience', label: t('bdl_col_audience'), kind: 'select', options: AUD, value: 'customers'}];
      var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bdl_add')});
      var form = el('form', {class: 'fp-form fp-bil-crud-form fp-bdl-upload', novalidate: '', 'aria-labelledby': 'fp-bdl-u-h'}, [FP.mail.errorLine(), FP.mail.statusLine(),
        el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: 'fp-bdl-u-file', text: t('bdl_file')}), file, el('span', {class: 'sig-hint', id: 'fp-bdl-u-file-hint', text: t('bdl_file_hint')})]),
        el('div', {class: 'fp-bil-grid'}, B.fieldsOf('fp-bdl-u', specs, null)), el('div', {class: 'fp-actions'}, [save])]);
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!B.begin(form, save)) { return; }
        var f = file.files && file.files[0];
        if (!f) { FP.mail.fieldError(form, file, t('bdl_file_needed')); return; }
        if (!FILE_RE.test(f.name) || !KINDS.test(f.name)) { FP.mail.fieldError(form, file, t('bdl_file_bad', {name: f.name.slice(0, 100)})); return; }
        if (!f.size || f.size > 10 * 1048576) { FP.mail.fieldError(form, file, t('bdl_file_big', {name: f.name.slice(0, 100)})); return; }
        var body = B.readFields(form, specs, null);
        if (!body) { return; }
        UI.setBusy(save, true);
        FP.call('post', 'billingDownloadAdd', undefined, {name: f.name, title: body.title || '', description: body.description || '', audience: body.audience || 'customers'}, {body: f, type: 'application/octet-stream'}).then(function (r) {
          if (!alive()) { return; }
          R.show(t('bdl_added', {name: (r && B.str(r.title, 150)) || f.name}), '#fp-bdl-h');
        }, function (err) {
          if (!alive()) { return; }
          UI.setBusy(save, false);
          B.failed(form, err.field === 'file' ? Object.assign({}, err, {field: ''}) : err);
          if (err.field === 'file') { file.setAttribute('aria-invalid', 'true'); file.focus(); }
        });
      });
      return B.card('fp-bdl-u-h', t('bdl_add_title'), [el('p', {class: 'fp-muted', text: t('bdl_add_what')}), form], 'fp-bdl-u-card', 'upload');
    }
    R = B.crud({page: page, pre: 'fp-bdl', title: t('bdl_title'), alive: alive,
      what: function () { return [el('p', {class: 'fp-muted', text: t('bdl_what')})]; },
      load: function () {
        return FP.call('get', 'billingDownloads').then(function (r) {
          return B.pickAll(r && r.downloads, {id: 'id', title: [150], description: [300], name: [100], size: 'n', audience: ['=', ['customers', 'active']], published: 'b', downloads: 'n'}, 'id');
        });
      },
      heads: [B.th(t('bdl_col_title')), B.th(t('bdl_col_file')), B.th(t('bdl_col_size'), 'fp-bil-num'), B.th(t('bdl_col_audience')), B.th(t('bdl_col_published')), B.th(t('bdl_col_count'), 'fp-bil-num')],
      cells: function (d) {
        return [el('th', {scope: 'row', class: 'fp-bil-wrap', text: d.title}),
          el('td', {class: 'fp-bil-wrap'}, [el('a', {href: '/api/v1/billing/downloads/' + d.id + '/file', download: '', 'aria-label': t('bdl_get_of', {name: d.name})}, [UI.icon(FP.ui, 'ui_download'), el('span', {text: d.name})])]),
          el('td', {class: 'fp-bil-num', text: size(d.size)}), el('td', {text: d.audience === 'active' ? t('bdl_aud_active') : t('bdl_aud_customers')}),
          el('td', null, [B.pill(t(d.published ? 'bdl_on' : 'bdl_off'), d.published ? 'ok' : '')]), el('td', {class: 'fp-bil-num', text: d.downloads === null ? '—' : B.num(d.downloads)})];
      },
      fields: [{name: 'title', label: t('bdl_col_title'), required: true, max: 150}, {name: 'description', label: t('bdl_f_desc'), max: 300},
        {name: 'audience', label: t('bdl_col_audience'), kind: 'select', options: AUD}, {name: 'published', label: t('bdl_f_published'), kind: 'check', hint: t('bdl_f_published_hint')}],
      add: null, item: 'billingDownload', nameOf: function (d) { return d.title; }, strings: strings('bdl'),
      below: function () { return [uploadCard()]; }});
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    R.show();
  });
})();

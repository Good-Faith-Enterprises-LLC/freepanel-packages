/* freePanel billing orders (docs/api.md, "Billing: orders" and "Billing: catalogue"; docs/billing/navigation-map.md, "Orders"): three tools of
   the Orders group. Orders (#/tool/billing_orders) lists the orders, waiting for review first in mind, filtered by status, client and review
   flag, and opens an order on the same page with its lines, totals and flags, Accept (asked first, and confirmed when flagged), Cancel with a
   reason, and its notes. Add order (#/tool/billing_order_new) takes the steps in order: client, plan, term, add-ons and options, promo code,
   panel account, a price check, then places the order. Order review rules (#/tool/billing_review) say which new orders wait for a person.
   Amounts are whole cents. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;
  var M = FP.mail;

  var STATUSES = ['pending', 'accepted', 'cancelled'];
  var FLAGS = ['first_order', 'high_value', 'many_recent', 'check_failed'];
  var LINE = {kind: [20], description: [200], quantity: 'n', unit_cents: 'c', amount_cents: 'c'};
  var ORDER = {id: 'id', customer_id: 'id', plan_id: 'id', plan_name: [60], package: [64], term: ['=', B.TERMS], status: ['=', STATUSES], currency: [3], recurring_cents: 'c',
    setup_cents: 'c', discount_cents: 'c', first_total_cents: 'c', renewal_total_cents: 'c', promo_id: 'id', free_domain: 'b', reviewed_by: [64], reviewed: 'w', reason: [200],
    username: [32], domain: [253], created: 'w'};
  function cleanOrder(x, quote) {
    var o = B.pick(x, ORDER);
    if (!o || (!quote && (!o.id || !o.status))) { return null; }
    o.lines = B.pickAll(x.lines, LINE);
    o.flags = B.words(x.flags, null, 10);
    return o;
  }
  function orderName(o) { return t('bord_order_n', {id: String(o.id)}); }
  function flagText(f, meanings) { return meanings && meanings[f] ? meanings[f] : B.word('flag', f); }
  function cleanReview(r) {
    var rules = r && r.rules && typeof r.rules === 'object' ? r.rules : {};
    var meanings = {};
    if (r && r.flags && typeof r.flags === 'object') {
      Object.keys(r.flags).forEach(function (k) { if (/^[a-z_]{1,40}$/.test(k) && typeof r.flags[k] === 'string') { meanings[k] = r.flags[k].slice(0, 300); } });
    }
    return {first_order: rules.first_order === true, high_value_cents: B.whole(rules.high_value_cents), recent_orders: B.whole(rules.recent_orders), flags: meanings};
  }
  /* the catalogue's plans that can be sold, by group and name, and the groups' names */
  function loadPlans() {
    return Promise.all([FP.call('get', 'billingPlans', undefined, {status: 'active'}), FP.call('get', 'billingProductGroups').then(null, function () { return null; })]).then(function (r) {
      var groups = {};
      B.pickAll(r[1] && r[1].groups, {id: 'id', name: [60]}, 'id').forEach(function (g) { groups[g.id] = g.name; });
      var plans = (r[0] && Array.isArray(r[0].plans) ? r[0].plans : []).map(function (x) {
        var p = B.pick(x, {id: 'id', group_id: 'id', name: [60], status: [10], visibility: [10], setup_cents: 'c', free_domain_from: [12]});
        if (!p || !p.id) { return null; }
        p.prices = {};
        B.TERMS.forEach(function (term) { var c = x.prices && B.cents(x.prices[term]); if (c !== null && c !== undefined && x.prices[term] !== null) { p.prices[term] = c; } });
        p.groupName = groups[p.group_id] || '';
        return p;
      }).filter(Boolean);
      return plans;
    });
  }

  /* ================= Orders ================= */
  var O = null;
  function ordersAlive(mine) { return function () { return O === mine && O.page.isConnected; }; }
  function listOrders() {
    var mine = O;
    O.L = B.lister({page: O.page, pre: 'fp-bord', title: t('bord_list_title'), findLabel: t('bord_find'), tableCls: 'fp-bord-table', alive: ordersAlive(mine),
      before: function () {
        return [FP.tools.billing_order_new ? el('div', {class: 'fp-bil-toolbar'}, [B.button('add-order', t('bord_add'), 'sig-btn--primary')]) : null].filter(Boolean);
      },
      blank: {status: '', customer: '', flag: ''},
      filters: [
        {name: 'status', label: t('bord_f_status'), control: function (v) { return B.select('fp-bord-f-status', 'status', [['', t('bil_any')]].concat(STATUSES.map(function (s) { return [s, B.word('order', s)]; })), v); }},
        {name: 'customer', control: function (v) {
          return B.clientPicker('fp-bord-f-client', {name: 'customer', label: t('bord_f_client'), placeholder: t('bil_any'), value: v, valueName: v ? O.names[v] : ''});
        }},
        {name: 'flag', label: t('bord_f_flag'), control: function (v) {
          var words = Object.keys(O.review.flags).length ? Object.keys(O.review.flags) : FLAGS;
          return B.select('fp-bord-f-flag', 'flag', [['', t('bord_f_flag_any')]].concat(words.map(function (f) { return [f, B.word('flag', f)]; })), v);
        }}],
      load: function (f, offset, limit) {
        return B.listOf('billingOrders', {limit: String(limit), offset: String(offset), status: f.status, customer: f.customer, flag: f.flag}, 'orders', function (x) { return cleanOrder(x, false); }).then(function (r) {
          return B.namesFor(O.names, r.items.map(function (o) { return o.customer_id; })).then(function () { return r; });
        });
      },
      heads: [B.th(t('bord_col_number')), B.th(t('bord_col_date')), B.th(t('bord_col_client')), B.th(t('bord_col_plan')), B.th(t('bord_col_term')), B.th(t('bord_col_total'), 'fp-bil-num'),
        B.th(t('bord_col_status')), B.th(t('bord_col_flags'))],
      row: function (o) {
        var name = orderName(o);
        return el('tr', {'data-fp-order': String(o.id)}, [
          el('th', {scope: 'row', class: 'fp-bil-name'}, [B.button('open', name, 'sig-btn--link fp-bil-link', {'data-fp-id': String(o.id), 'aria-label': t('bord_open_of', {name: name})})]),
          el('td', {class: 'fp-bil-nowrap', text: B.day(o.created) || '—'}), el('td', {class: 'fp-bil-wrap', text: B.nameIn(O.names, o.customer_id)}),
          el('td', {class: 'fp-bil-wrap', text: o.plan_name || '—'}), el('td', {text: B.termText(o.term)}), el('td', {class: 'fp-bil-num', text: B.money(o.first_total_cents, o.currency)}),
          el('td', null, [B.statePill('order', o.status)]),
          el('td', {class: 'fp-bil-wrap'}, o.flags.length ? [el('span', {class: 'fp-bord-flags', text: o.flags.map(function (f) { return B.word('flag', f); }).join(', ')})] : [el('span', {class: 'fp-muted', text: t('bord_no_flags')})])]);
      },
      none: t('bord_none'), noneMatch: t('bord_none_match'),
      found: function (n) { return n === 1 ? t('bord_found_1') : t('bord_found', {n: B.num(n)}); }});
    return O.L;
  }
  function showOrders(focus, said) {
    O.view = 'list';
    O.order = null;
    return O.L.show(focus, said);
  }
  function openOrder(oid, opts) {
    opts = opts || {};
    var mine = O;
    var b = O.page.querySelector('[data-fp-act="open"][data-fp-id="' + oid + '"]');
    if (b) { UI.setBusy(b, true); }
    return Promise.all([FP.call('get', 'billingOrder', undefined, {id: String(oid)}), FP.call('get', 'billingOrderNotes', undefined, {id: String(oid)}).then(function (r) {
      return B.pickAll(r && r.notes, {id: 'id', author: [64], body: [2000], created: 'w'}, 'id');
    }, function () { return null; })]).then(function (r) {
      var o = cleanOrder(r[0], false);
      if (!o) { throw {message: t('api_failed')}; }
      return B.namesFor(O.names, [o.customer_id]).then(function () { return [o, r[1]]; });
    }).then(function (r) {
      if (O !== mine) { return; }
      O.view = 'order';
      O.order = {o: r[0], notes: r[1]};
      drawOrder();
      if (opts.say) { M.say(O.page.querySelector('[data-fp-card="head"]'), opts.say); }
      if (opts.sayIn) { M.say(O.page.querySelector('[data-fp-card="' + opts.sayIn[0] + '"]'), opts.sayIn[1]); }
      (O.page.querySelector(opts.focus || '#fp-bord-h') || O.page.querySelector('#fp-bord-h')).focus();
    }, function (err) {
      if (O !== mine) { return; }
      if (b && b.isConnected) { UI.setBusy(b, false); O.L.error(err); b.focus(); return; }
      if (O.view === 'order') { UI.showError(O.page.querySelector('[data-fp-card="head"]'), err.message); return; }
      showOrders().then(function () { O.L.error(err); });
    });
  }
  function reopen(opts) { return openOrder(O.order.o.id, opts); }
  function drawOrder() {
    var o = O.order.o;
    B.screen(O.page, [B.back('to-list', t('bord_back')), headCard(o), o.flags.length ? flagsCard(o) : null, linesCard(o), notesCard()]);
  }
  function headCard(o) {
    var pairs = [[t('bord_col_client'), [B.clientLink(O.names, o.customer_id)]], [t('bord_col_date'), B.when(o.created)], [t('bord_col_plan'), o.plan_name],
      [t('bord_col_term'), B.termText(o.term)], [t('bord_account'), o.username ? o.username + (o.domain ? ' · ' + o.domain : '') : t('bord_no_account')]];
    if (o.reviewed) { pairs.push([t(o.status === 'cancelled' ? 'bord_cancelled_by' : 'bord_accepted_by'), t('bord_by_when', {who: o.reviewed_by || '—', when: B.when(o.reviewed)})]); }
    if (o.status === 'cancelled') { pairs.push([t('bord_reason'), o.reason]); }
    var acts = [];
    if (o.status === 'pending') { acts.push(B.button('accept', t('bord_accept'), 'sig-btn--primary')); }
    if (o.status !== 'cancelled') { acts.push(B.button('cancel', t('bord_cancel'), 'sig-btn--secondary fp-btn-danger-text')); }
    return el('section', {class: 'sig-card fp-bil-head fp-bord-head', 'aria-labelledby': 'fp-bord-h', 'data-fp-card': 'head'}, [el('div', {class: 'sig-card-body'}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-bil-head-row'}, [el('div', {class: 'fp-bil-head-name'}, [el('h2', {class: 'fp-h2', id: 'fp-bord-h', tabindex: '-1', text: orderName(o)})]), B.statePill('order', o.status)]),
      B.facts(pairs), acts.length ? el('div', {class: 'fp-actions', 'data-fp-acts': ''}, acts) : null])]);
  }
  function flagsCard(o) {
    return B.card('fp-bord-flags-h', t('bord_flags_title'), [el('p', {class: 'fp-muted', text: t(o.status === 'pending' ? 'bord_flags_what' : 'bord_flags_were')}),
      el('ul', {class: 'fp-bord-flag-list'}, o.flags.map(function (f) {
        return el('li', {'data-fp-flag': f}, [el('strong', {text: B.word('flag', f)}), el('span', {text: flagText(f, O.review.flags)})]);
      }))], 'fp-bord-flags-card', 'flags');
  }
  /* the lines and sums of an order or a price check */
  function linesParts(o, hid) {
    var parts = [];
    if (!o.lines.length) {
      parts.push(el('p', {class: 'fp-muted', text: t('bord_no_lines')}));
    } else {
      parts.push(B.table(hid, 'fp-bord-lines-table', [B.th(t('bord_col_line')), B.th(t('binv_col_desc')), B.th(t('binv_col_qty'), 'fp-bil-num'), B.th(t('binv_col_unit'), 'fp-bil-num'),
        B.th(t('binv_col_amount'), 'fp-bil-num')], o.lines.map(function (l) {
        return el('tr', null, [el('td', {text: B.word('line', l.kind)}), el('td', {class: 'fp-bil-wrap', text: l.description}), el('td', {class: 'fp-bil-num', text: B.num(l.quantity || 1)}),
          el('td', {class: 'fp-bil-num', text: B.money(l.unit_cents, o.currency)}), el('td', {class: 'fp-bil-num', text: B.money(l.amount_cents, o.currency)})]);
      })));
    }
    parts.push(B.totalsBlock([[t('bord_t_term'), B.money(o.recurring_cents, o.currency)], [t('bord_t_setup'), B.money(o.setup_cents, o.currency)],
      [t('bord_t_discount'), o.discount_cents ? '−' + B.money(o.discount_cents, o.currency) : B.money(0, o.currency)], [t('bord_t_renewal'), B.money(o.renewal_total_cents, o.currency)],
      [t('bord_t_first'), B.money(o.first_total_cents, o.currency)]]));
    if (o.free_domain) { parts.push(el('p', {class: 'fp-muted fp-row-note', 'data-fp-free-domain': '', text: t('bord_free_domain')})); }
    return parts;
  }
  function linesCard(o) { return B.card('fp-bord-lines-h', t('bord_lines'), linesParts(o, 'fp-bord-lines-h'), 'fp-bord-lines', 'lines'); }
  function notesCard() {
    var notes = O.order.notes;
    var body = el('textarea', {class: 'sig-input fp-bil-text', id: 'fp-bord-nt-body', name: 'body', rows: '3', maxlength: '2000'});
    var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bord_note_add')});
    var form = el('form', {class: 'fp-form fp-bord-nt-form', novalidate: '', 'aria-label': t('bord_note_add_label')}, [M.errorLine(), M.field('fp-bord-nt-body', t('bord_note_text'), body, t('bord_note_hint')),
      el('div', {class: 'fp-actions'}, [save])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!B.begin(form, save)) { return; }
      if (!body.value.trim()) { M.fieldError(form, body, t('bord_note_needed')); return; }
      var mine = O;
      UI.setBusy(save, true);
      FP.call('post', 'billingOrderNotes', {body: body.value}, {id: String(O.order.o.id)}).then(function () {
        if (O !== mine) { return; }
        reopen({sayIn: ['notes', t('bord_note_added')], focus: '#fp-bord-nt-body'});
      }, function (err) {
        if (O !== mine) { return; }
        UI.setBusy(save, false);
        B.failed(form, err);
      });
    });
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t('bord_notes_what')})];
    if (notes === null) {
      parts.push(el('p', {class: 'fp-muted', text: t('bord_notes_unread')}));
    } else if (!notes.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('bord_no_notes')}));
    } else {
      parts.push(el('ul', {class: 'fp-bil-notes'}, notes.map(function (n) {
        var when = B.when(n.created);
        return el('li', {class: 'fp-bil-note', 'data-fp-note': String(n.id)}, [el('p', {class: 'fp-muted fp-row-note', text: t('bcl_note_by', {who: n.author || '—', when: when})}),
          el('p', {class: 'fp-bil-note-body', text: n.body}), el('div', {class: 'fp-bil-row-acts'}, [B.button('note-remove', t('bil_remove'), 'sig-btn--secondary sig-btn--sm fp-btn-danger-text',
            {'data-fp-id': String(n.id), 'aria-label': t('bcl_note_remove_of', {when: when})})])]);
      })));
    }
    parts.push(form);
    return B.card('fp-bord-notes-h', t('bord_notes'), parts, 'fp-bord-notes', 'notes');
  }
  /* Accept, asked in place of the head's buttons; a flagged order also needs the box ticked that says someone looked at its flags */
  function askAccept() {
    var o = O.order.o;
    var box = O.page.querySelector('[data-fp-card="head"] [data-fp-acts]');
    box.textContent = '';
    var looked = o.flags.length ? el('input', {type: 'checkbox', id: 'fp-bord-a-looked', name: 'confirm'}) : null;
    var yes = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bord_accept_yes'), 'aria-describedby': 'fp-bord-a-q'});
    var no = B.button('accept-no', t('bord_accept_keep'), 'sig-btn--secondary', {'aria-describedby': 'fp-bord-a-q'});
    var form = el('form', {class: 'fp-form fp-bord-accept', novalidate: '', 'aria-label': t('bord_accept_label')}, [M.errorLine(),
      el('p', {class: 'fp-mail-confirm', id: 'fp-bord-a-q', text: t('bord_accept_ask')}),
      looked ? el('label', {class: 'fp-bil-check', for: 'fp-bord-a-looked'}, [looked, el('span', {text: t('bord_accept_looked', {flags: o.flags.map(function (f) { return B.word('flag', f); }).join(', ')})})]) : null,
      el('div', {class: 'fp-actions'}, [yes, no])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!B.begin(form, yes)) { return; }
      if (looked && !looked.checked) { M.fieldError(form, looked, t('bord_accept_look_first')); return; }
      var mine = O;
      UI.setBusy(yes, true);
      FP.call('post', 'billingOrderAccept', looked ? {confirm: true} : {}, {id: String(o.id)}).then(function (r) {
        if (O !== mine) { return; }
        var said = [t('bord_accepted')];
        var made = r && r.account && typeof r.account === 'object' ? B.str(r.account.username, 32) : r && typeof r.account === 'string' ? B.str(r.account, 32) : '';
        if (made) { said.push(t('bord_account_made', {name: made})); }
        if (r && typeof r.provisioning_error === 'string' && r.provisioning_error) { said.push(t('bord_account_failed', {why: B.str(r.provisioning_error, 300)})); }
        reopen({say: said.join(' '), focus: '#fp-bord-h'});
      }, function (err) {
        if (O !== mine) { return; }
        UI.setBusy(yes, false);
        B.failed(form, err.field === 'flags' ? Object.assign({}, err, {field: ''}) : err);
        if (!form.querySelector('[aria-invalid]')) { no.focus(); }
      });
    });
    box.appendChild(form);
    (looked || no).focus();
  }
  function askCancel() {
    var o = O.order.o;
    var box = O.page.querySelector('[data-fp-card="head"] [data-fp-acts]');
    box.textContent = '';
    var reason = B.input('fp-bord-x-reason', 'reason', '', {maxlength: '200'});
    var yes = el('button', {class: 'sig-btn sig-btn--danger fp-submit', type: 'submit', text: t('bord_cancel_yes'), 'aria-describedby': 'fp-bord-x-q'});
    var no = B.button('cancel-no', t('bord_cancel_keep'), 'sig-btn--secondary', {'aria-describedby': 'fp-bord-x-q'});
    var form = el('form', {class: 'fp-form fp-bord-cancel', novalidate: '', 'aria-label': t('bord_cancel_label')}, [M.errorLine(),
      el('p', {class: 'fp-mail-confirm', id: 'fp-bord-x-q', text: t(o.status === 'accepted' ? 'bord_cancel_ask_accepted' : 'bord_cancel_ask')}),
      M.field('fp-bord-x-reason', t('bord_cancel_reason'), reason, t('bord_cancel_reason_hint')), el('div', {class: 'fp-actions'}, [yes, no])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!B.begin(form, yes)) { return; }
      var mine = O;
      UI.setBusy(yes, true);
      FP.call('post', 'billingOrderCancel', reason.value.trim() ? {reason: reason.value.trim()} : {}, {id: String(o.id)}).then(function () {
        if (O !== mine) { return; }
        reopen({say: t('bord_cancelled'), focus: '#fp-bord-h'});
      }, function (err) {
        if (O !== mine) { return; }
        UI.setBusy(yes, false);
        B.failed(form, err);
      });
    });
    box.appendChild(form);
    no.focus();
  }
  function restoreHead(focus) {
    var old = O.page.querySelector('[data-fp-card="head"]');
    var made = headCard(O.order.o);
    old.replaceWith(made);
    var f = made.querySelector(focus);
    if (f) { f.focus(); }
  }
  function onOrdersClick(e) {
    var target = e.target && e.target.closest ? e.target : null;
    if (!target || !O || !O.page.isConnected || !O.page.contains(target)) { return; }
    var b = target.closest('[data-fp-act]');
    if (!b || b.disabled) { return; }
    var a = b.getAttribute('data-fp-act');
    var xid = Number(b.getAttribute('data-fp-id')) || 0;
    if (a === 'open' && xid) {
      openOrder(xid);
    } else if (a === 'to-list') {
      var from = O.order ? O.order.o.id : 0;
      showOrders(from ? '[data-fp-act="open"][data-fp-id="' + from + '"]' : '#fp-bord-list-h');
    } else if (a === 'add-order') {
      B.go('billing_order_new', {});
    } else if (a === 'open-client' && xid) {
      B.go('billing_clients', {client: xid});
    } else if (a === 'accept') {
      askAccept();
    } else if (a === 'accept-no') {
      restoreHead('[data-fp-act="accept"]');
    } else if (a === 'cancel') {
      askCancel();
    } else if (a === 'cancel-no') {
      restoreHead('[data-fp-act="cancel"]');
    } else if (a === 'note-remove') {
      var cell = b.closest('.fp-bil-row-acts');
      M.confirmIn(cell, t('bcl_note_remove_ask'), 'note-remove-yes', t('bcl_note_remove_yes'));
      cell.querySelector('[data-fp-act="note-remove-yes"]').setAttribute('data-fp-id', String(xid));
    } else if (a === 'note-remove-yes') {
      var mine = O;
      var notes = O.page.querySelector('[data-fp-card="notes"]');
      UI.setBusy(b, true);
      FP.call('del', 'billingOrderNote', undefined, {id: String(O.order.o.id), note: String(xid)}).then(function () {
        if (O !== mine) { return; }
        reopen({sayIn: ['notes', t('bcl_note_removed')], focus: '#fp-bord-notes-h'});
      }, function (err) {
        if (O !== mine) { return; }
        UI.setBusy(b, false);
        UI.showError(notes, err.message);
        b.focus();
      });
    } else if (a === 'confirm-no') {
      var li = b.closest('li[data-fp-note]');
      if (li) { reopen({focus: '[data-fp-act="note-remove"][data-fp-id="' + li.getAttribute('data-fp-note') + '"]'}); }
    }
  }
  document.addEventListener('click', onOrdersClick);

  FP.view('tool:billing_orders', function () {
    var page = B.frame('billing_orders', 'fp-bord');
    if (!page) { return; }
    O = {page: page, view: 'list', names: {}, review: {flags: {}}, order: null};
    var mine = O;
    var handed = B.take('billing_orders');
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'billingOrderReview').then(cleanReview, function () { return {flags: {}}; }).then(function (rv) {
      if (O !== mine) { return; }
      O.review = rv;
      listOrders();
      if (handed && B.id(handed.order)) { openOrder(handed.order, {say: handed.said}); } else { showOrders(); }
    });
  });

  /* ================= Add order ================= */
  var N = null;
  function planLabel(p) { return (p.groupName ? p.groupName + ': ' : '') + p.name + (p.visibility === 'hidden' ? ' ' + t('bon_hidden_mark') : ''); }
  function planById(pid) { for (var i = 0; i < N.plans.length; i++) { if (N.plans[i].id === pid) { return N.plans[i]; } } return null; }
  function drawNew(clientId) {
    var picker = B.clientPicker('fp-bon-client', {label: t('bon_client'), placeholder: t('binv_pick_client'), active: true, required: true, value: clientId || '',
      valueName: clientId && N.names[clientId] ? N.names[clientId] : ''});
    var plan = B.select('fp-bon-plan', 'plan_id', [['', t('bon_pick_plan')]].concat(N.plans.map(function (p) { return [String(p.id), planLabel(p)]; })), '', {'aria-required': 'true'});
    var term = B.select('fp-bon-term', 'term', [['', t('bon_pick_plan_first')]], '', {'aria-required': 'true', disabled: true});
    var extras = el('div', {'data-fp-extras': ''});
    var promo = B.input('fp-bon-promo', 'promo', '', {maxlength: '32', spellcheck: 'false', autocapitalize: 'characters'});
    var user = B.input('fp-bon-user', 'username', '', {maxlength: '32', spellcheck: 'false', autocapitalize: 'none'});
    var domain = B.input('fp-bon-domain', 'domain', '', {maxlength: '253', spellcheck: 'false', autocapitalize: 'none'});
    var check = el('button', {class: 'sig-btn sig-btn--secondary fp-submit', type: 'submit', value: 'check', text: t('bon_check')});
    var place = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', value: 'place', text: t('bon_place')});
    var form = el('form', {class: 'fp-form fp-bon-form', novalidate: '', 'aria-labelledby': 'fp-bon-h'}, [M.errorLine(), M.statusLine(),
      step(1, t('bon_s_client'), [picker.node]),
      step(2, t('bon_s_plan'), [el('div', {class: 'fp-bil-grid'}, [M.field('fp-bon-plan', t('bon_plan'), plan, N.plans.length ? null : t('bon_no_plans')), M.field('fp-bon-term', t('bon_term'), term)])]),
      step(3, t('bon_s_extras'), [extras]),
      step(4, t('bon_s_promo'), [el('div', {class: 'fp-bil-grid'}, [M.field('fp-bon-promo', t('bon_promo'), promo, t('bon_promo_hint'))])]),
      step(5, t('bon_s_account'), [el('p', {class: 'fp-muted fp-row-note', text: t('bon_account_what')}), el('div', {class: 'fp-bil-grid'}, [M.field('fp-bon-user', t('bon_user'), user, t('bon_user_hint')),
        M.field('fp-bon-domain', t('bon_domain'), domain, t('bon_domain_hint'))])]),
      step(6, t('bon_s_check'), [el('p', {class: 'fp-muted fp-row-note', text: t('bon_check_what')}), el('div', {'data-fp-price': ''})]),
      el('div', {class: 'fp-actions'}, [check, place])]);
    N.extras = {addons: [], options: []};
    plan.addEventListener('change', function () { planChanged(plan, term, extras); });
    term.addEventListener('change', function () { drawExtras(extras, planById(Number(plan.value)), term.value); stale(); });
    form.addEventListener('input', stale);
    function stale() { var box = form.querySelector('[data-fp-price]'); if (box.firstChild) { box.textContent = ''; box.appendChild(el('p', {class: 'fp-muted', 'data-fp-stale': '', text: t('bon_price_stale')})); } }
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = e.submitter && e.submitter.classList.contains('fp-submit') ? e.submitter : check;
      if (!B.begin(form, b)) { return; }
      var body = readOrder(form, picker.select, plan, term, promo, user, domain);
      if (!body) { return; }
      var mine = N;
      var quote = b === check;
      UI.setBusy(check, true);
      UI.setBusy(place, true);
      FP.call('post', quote ? 'billingOrderQuote' : 'billingOrderNew', body).then(function (r) {
        if (N !== mine) { return; }
        UI.setBusy(check, false);
        UI.setBusy(place, false);
        var o = cleanOrder(r, true);
        if (!o) { UI.showError(form, t('api_failed')); return; }
        if (!quote) {
          if (FP.tools.billing_orders && o.id) { B.go('billing_orders', {order: o.id, said: t('bon_placed', {name: orderName(o)})}); return; }
          M.say(form, t('bon_placed', {name: orderName(o)}));
          return;
        }
        var box = form.querySelector('[data-fp-price]');
        box.textContent = '';
        var parts = [el('h3', {class: 'fp-h3', id: 'fp-bon-price-h', tabindex: '-1', text: t('bon_price_title')})].concat(linesParts(o, 'fp-bon-price-h'));
        if (o.flags.length) { parts.push(el('p', {class: 'fp-bord-will-wait', 'data-fp-will-wait': '', text: t('bon_will_wait', {flags: o.flags.map(function (f) { return B.word('flag', f); }).join(', ')})})); }
        parts.forEach(function (n) { box.appendChild(n); });
        box.querySelector('#fp-bon-price-h').focus();
      }, function (err) {
        if (N !== mine) { return; }
        UI.setBusy(check, false);
        UI.setBusy(place, false);
        orderFailed(form, err);
      });
    });
    B.screen(N.page, [B.card('fp-bon-h', t('bon_title'), [el('p', {class: 'fp-muted', text: t('bon_what')}), form], 'fp-bon', 'new')], clientId ? '#fp-bon-plan' : '#fp-bon-client');
  }
  function step(n, title, parts) {
    return el('fieldset', {class: 'fp-bil-set fp-bon-step', 'data-fp-step': String(n)}, [el('legend', {class: 'fp-bil-legend', text: t('bon_step', {n: n, title: title})})].concat(parts));
  }
  function planChanged(plan, term, extras) {
    var p = planById(Number(plan.value));
    term.textContent = '';
    if (!p) {
      term.appendChild(el('option', {value: '', text: t('bon_pick_plan_first')}));
      term.disabled = true;
      extras.textContent = '';
      N.extras = {addons: [], options: []};
      return;
    }
    var priced = B.TERMS.filter(function (x) { return Object.prototype.hasOwnProperty.call(p.prices, x); });
    if (!priced.length) { term.appendChild(el('option', {value: '', text: t('bon_no_price')})); term.disabled = true; } else {
      priced.forEach(function (x) { term.appendChild(el('option', {value: x, text: t('bon_term_price', {term: B.termText(x), amount: B.money(p.prices[x], 'USD')})})); });
      term.disabled = false;
    }
    var mine = N;
    extras.textContent = '';
    extras.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all([FP.call('get', 'billingPlanAddons', undefined, {id: String(p.id)}).then(function (r) {
      return (r && Array.isArray(r.addons) ? r.addons : []).map(function (x) {
        var a = B.pick(x, {id: 'id', name: [60], status: [10], setup_cents: 'c'});
        if (!a || !a.id || a.status === 'retired') { return null; }
        a.prices = {};
        B.TERMS.forEach(function (k) { var c = x.prices && x.prices[k] !== null ? B.cents(x.prices[k]) : null; if (c !== null && c !== undefined) { a.prices[k] = c; } });
        return a;
      }).filter(Boolean);
    }), FP.call('get', 'billingPlanOptions', undefined, {id: String(p.id)}).then(function (r) {
      return (r && Array.isArray(r.options) ? r.options : []).map(function (x) {
        var o = B.pick(x, {id: 'id', name: [60], unit: [20], min: 'n', max: 'n'});
        if (!o || !o.id) { return null; }
        o.unit_prices = {};
        B.TERMS.forEach(function (k) { var c = x.unit_prices && x.unit_prices[k] !== null ? B.cents(x.unit_prices[k]) : null; if (c !== null && c !== undefined) { o.unit_prices[k] = c; } });
        return o;
      }).filter(Boolean);
    })]).then(function (r) {
      if (N !== mine) { return; }
      N.extras = {addons: r[0], options: r[1]};
      drawExtras(extras, p, term.value);
    }, function (err) {
      if (N !== mine) { return; }
      extras.textContent = '';
      extras.appendChild(el('p', {class: 'fp-muted', text: err.message}));
    });
  }
  /* the add-ons and options of the plan, priced for the term chosen; ticks and quantities typed so far are kept */
  function drawExtras(box, p, term) {
    var was = {};
    Array.prototype.forEach.call(box.querySelectorAll('input'), function (i) { was[i.name + ':' + i.value] = i.checked; was[i.name] = i.value; });
    box.textContent = '';
    if (!p) { return; }
    var adds = N.extras.addons;
    var opts = N.extras.options;
    if (!adds.length && !opts.length) { box.appendChild(el('p', {class: 'fp-muted', 'data-fp-no-extras': '', text: t('bon_no_extras')})); return; }
    if (adds.length) {
      box.appendChild(el('fieldset', {class: 'fp-bil-set', 'data-fp-addons': ''}, [el('legend', {class: 'sig-label', text: t('bon_addons')}), el('div', {class: 'fp-bil-checks fp-bon-addons'}, adds.map(function (a) {
        var priced = Object.prototype.hasOwnProperty.call(a.prices, term);
        var fid = 'fp-bon-a-' + a.id;
        return el('label', {class: 'fp-bil-check', for: fid}, [el('input', {type: 'checkbox', id: fid, name: 'addon_ids', value: String(a.id), disabled: priced ? null : true,
          checked: priced && was['addon_ids:' + a.id] ? true : null}), el('span', {text: priced ? t('bon_addon_price', {name: a.name, amount: B.money(a.prices[term], 'USD'), setup: a.setup_cents ? t('bon_setup_more', {amount: B.money(a.setup_cents, 'USD')}) : ''}).trim() :
          t('bon_addon_unpriced', {name: a.name})})]);
      }))]));
    }
    if (opts.length) {
      box.appendChild(el('div', {class: 'fp-bil-grid fp-bon-options'}, opts.map(function (o) {
        var fid = 'fp-bon-o-' + o.id;
        var unit = Object.prototype.hasOwnProperty.call(o.unit_prices, term) ? o.unit_prices[term] : null;
        var input = B.input(fid, 'options.' + o.id, was['options.' + o.id] || (o.min ? String(o.min) : ''), {inputmode: 'numeric', maxlength: '7', class: 'sig-input fp-bil-amount'});
        return M.field(fid, t('bon_option', {name: o.name, unit: o.unit || t('bon_units')}), input, unit === null ? t('bon_option_unpriced') :
          t('bon_option_hint', {min: B.num(o.min || 0), max: B.num(o.max || 0), amount: B.money(unit, 'USD')}));
      })));
    }
  }
  function readOrder(form, client, plan, term, promo, user, domain) {
    if (!client.value) { M.fieldError(form, client, t('binv_client_needed')); return null; }
    if (!plan.value) { M.fieldError(form, plan, t('bon_plan_needed')); return null; }
    if (!term.value) { M.fieldError(form, term, t('bon_term_needed')); return null; }
    var body = {customer_id: Number(client.value), plan_id: Number(plan.value), term: term.value};
    var ids = Array.prototype.filter.call(form.querySelectorAll('[name="addon_ids"]'), function (c) { return c.checked && !c.disabled; }).map(function (c) { return Number(c.value); });
    if (ids.length) { body.addon_ids = ids; }
    var options = {};
    var inputs = form.querySelectorAll('[name^="options."]');
    for (var i = 0; i < inputs.length; i++) {
      var v = inputs[i].value.trim();
      if (!v) { continue; }
      if (!/^[0-9]{1,7}$/.test(v)) { M.fieldError(form, inputs[i], t('bon_option_bad')); return null; }
      if (Number(v) > 0) { options[inputs[i].name.slice(8)] = Number(v); }
    }
    if (Object.keys(options).length) { body.options = options; }
    if (promo.value.trim()) { body.promo = promo.value.trim(); }
    var u = user.value.trim();
    var d = domain.value.trim().toLowerCase();
    if (u && !d) { M.fieldError(form, domain, t('bon_domain_needed')); return null; }
    if (d && !u) { M.fieldError(form, user, t('bon_user_needed')); return null; }
    if (u) { body.username = u; body.domain = d; }
    return body;
  }
  /* a refusal about an add-on is about the boxes: the first one is marked */
  function orderFailed(form, err) {
    if (err && err.field === 'addon_ids') {
      var first = form.querySelector('[name="addon_ids"]');
      B.failed(form, Object.assign({}, err, {field: ''}));
      if (first) { first.setAttribute('aria-invalid', 'true'); first.focus(); }
      return;
    }
    if (err && err.field === 'options') {
      B.failed(form, Object.assign({}, err, {field: ''}));
      return;
    }
    B.failed(form, err);
  }

  FP.view('tool:billing_order_new', function () {
    var page = B.frame('billing_order_new', 'fp-bon');
    if (!page) { return; }
    N = {page: page, names: {}, plans: [], extras: {addons: [], options: []}};
    var mine = N;
    var handed = B.take('billing_order_new');
    var cid = handed && B.id(handed.client) ? handed.client : 0;
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all([loadPlans(), cid ? B.namesFor(N.names, [cid]) : null]).then(function (r) {
      if (N !== mine) { return; }
      N.plans = r[0];
      drawNew(cid);
    }, function (err) {
      if (N !== mine) { return; }
      B.screen(page, [FP.empty(t('bon_title'), err.message, B.button('reload-new', t('bil_try_again')))]);
      page.querySelector('[data-fp-act="reload-new"]').addEventListener('click', function () { FP.route(true); });
    });
  });

  /* ================= Order review rules ================= */
  FP.view('tool:billing_review', function () {
    var page = B.frame('billing_review', 'fp-brv');
    if (!page) { return; }
    var mine = {};
    var R = mine;
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    function draw(rv, said) {
      var first = el('input', {type: 'checkbox', id: 'fp-brv-first', name: 'first_order', checked: rv.first_order ? true : null});
      var high = B.input('fp-brv-high', 'high_value_cents', rv.high_value_cents === null ? '' : B.amountText(rv.high_value_cents), {inputmode: 'decimal', maxlength: '16', class: 'sig-input fp-bil-amount'});
      var recent = B.input('fp-brv-recent', 'recent_orders', rv.recent_orders === null ? '' : String(rv.recent_orders), {inputmode: 'numeric', maxlength: '3', class: 'sig-input fp-bil-amount'});
      var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bil_save_changes')});
      var form = el('form', {class: 'fp-form fp-brv-form', novalidate: '', 'aria-labelledby': 'fp-brv-h'}, [M.errorLine(), M.statusLine(),
        el('div', {class: 'sig-field'}, [el('label', {class: 'fp-bil-check', for: 'fp-brv-first'}, [first, el('span', {text: t('brv_first')})]),
          el('span', {class: 'sig-hint', text: t('brv_first_hint')})]),
        el('div', {class: 'fp-bil-grid'}, [M.field('fp-brv-high', t('brv_high'), high, t('brv_high_hint')), M.field('fp-brv-recent', t('brv_recent'), recent, t('brv_recent_hint'))]),
        el('div', {class: 'fp-actions'}, [save])]);
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!B.begin(form, save)) { return; }
        var body = {};
        if (first.checked !== rv.first_order) { body.first_order = first.checked; }
        var h = high.value.trim() ? B.parseAmount(high.value, false) : null;
        if (high.value.trim() && !h) { M.fieldError(form, high, t('bil_amount_bad')); return; }
        if (h !== rv.high_value_cents) { body.high_value_cents = h; }
        var n = recent.value.trim();
        if (n && (!/^[0-9]{1,3}$/.test(n) || Number(n) < 1 || Number(n) > 100)) { M.fieldError(form, recent, t('brv_recent_bad')); return; }
        var nv = n ? Number(n) : null;
        if (nv !== rv.recent_orders) { body.recent_orders = nv; }
        if (!Object.keys(body).length) { M.say(form, t('bil_nothing_changed')); return; }
        UI.setBusy(save, true);
        FP.call('patch', 'billingOrderReview', body).then(function (r) {
          if (R !== mine || !page.isConnected) { return; }
          draw(cleanReview(r), t('brv_saved'));
        }, function (err) {
          if (R !== mine || !page.isConnected) { return; }
          UI.setBusy(save, false);
          B.failed(form, err);
        });
      });
      var words = Object.keys(rv.flags);
      B.screen(page, [B.card('fp-brv-h', t('brv_title'), [el('p', {class: 'fp-muted', text: t('brv_what')}), form], 'fp-brv', 'rules'),
        B.card('fp-brv-flags-h', t('brv_flags'), [el('p', {class: 'fp-muted', text: t('brv_flags_what')}),
          words.length ? B.facts(words.map(function (f) { return [B.word('flag', f), rv.flags[f]]; }), 'fp-brv-flag-facts') : el('p', {class: 'fp-muted', text: t('brv_no_flags')})], 'fp-brv-flags', 'flags')]);
      if (said) { M.say(page.querySelector('.fp-brv-form'), said); page.querySelector('#fp-brv-h').focus(); }
    }
    function load() {
      FP.call('get', 'billingOrderReview').then(function (r) {
        if (R !== mine || !page.isConnected) { return; }
        draw(cleanReview(r));
      }, function (err) {
        if (R !== mine || !page.isConnected) { return; }
        B.screen(page, [FP.empty(t('brv_title'), err.message, B.button('reload-review', t('bil_try_again')))]);
        page.querySelector('[data-fp-act="reload-review"]').addEventListener('click', load);
      });
    }
    load();
  });
})();

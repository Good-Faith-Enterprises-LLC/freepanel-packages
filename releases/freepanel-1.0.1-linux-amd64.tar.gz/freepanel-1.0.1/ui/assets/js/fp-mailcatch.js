/* freePanel default address (docs/api.md, "Email", PUT .../email/defaults/{domain}): the customer panel's Catch-all
   address page (#/tool/catch_all). For each of the account's domains it chooses what happens to mail for addresses
   the domain has neither as a mailbox nor as a forwarder: refused while the sender is still connected (with the mail
   server's own answer, or the account's notice), thrown away, or forwarded to 1 to 20 addresses. Refusing with the
   server's answer is the default and is what an empty setting means. A setting stays when its domain is dropped
   (served false) and can't be changed until the domain is back. Page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var DOMAIN_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var NOTICE_RE = /^[\x20-\x7e]*$/;
  var MAX_NOTICE = 200;
  var MAX_TO = 20;
  var ACTIONS = ['reject', 'discard', 'forward', 'domain'];

  function str(v) { return typeof v === 'string' ? v : ''; }
  function cleanDefaults(v) {
    var out = {};
    (v && Array.isArray(v.defaults) ? v.defaults : []).forEach(function (d) {
      if (!d || !DOMAIN_RE.test(str(d.domain)) || ACTIONS.indexOf(d.action) < 0) { return; }
      out[d.domain] = {action: d.action, notice: NOTICE_RE.test(str(d.notice)) ? str(d.notice).slice(0, MAX_NOTICE) : '',
        to: (Array.isArray(d.to) ? d.to : []).filter(d.action === 'domain' ? function (x) { return DOMAIN_RE.test(str(x)); } : M.isAddress).slice(0, MAX_TO),
        served: d.served !== false};
      if (d.action === 'domain' && out[d.domain].to.length !== 1) { delete out[d.domain]; }
    });
    return out;
  }
  /* the names the account's sites answer on */
  function namesOf(v) {
    var out = [];
    (v && Array.isArray(v.sites) ? v.sites : []).forEach(function (s) {
      [s && s.domain].concat(s && Array.isArray(s.aliases) ? s.aliases : []).forEach(function (d) {
        if (typeof d === 'string' && DOMAIN_RE.test(d) && out.indexOf(d) < 0) { out.push(d); }
      });
    });
    return out;
  }
  function settle(P, mailReply, sitesReply) {
    P.mail = M.clean(mailReply);
    P.defaults = cleanDefaults(mailReply);
    if (sitesReply) { P.names = namesOf(sitesReply); }
    var all = P.names.slice();
    Object.keys(P.defaults).forEach(function (d) { if (all.indexOf(d) < 0) { all.push(d); } });
    P.rows = all.sort().map(function (d) {
      var x = P.defaults[d];
      return {domain: d, set: x || {action: 'reject', notice: '', to: [], served: true}, editable: P.names.indexOf(d) >= 0};
    });
    if (!P.rows.some(function (r) { return r.domain === P.pick && r.editable; })) {
      var first = P.rows.filter(function (r) { return r.editable; })[0];
      P.pick = first ? first.domain : '';
    }
  }

  var P = {page: null, account: '', mail: null, defaults: {}, names: [], rows: [], pick: ''};
  function rowOf(domain) { return P.rows.filter(function (r) { return r.domain === domain; })[0]; }

  function whatText(s) {
    if (s.action === 'discard') { return t('ca_discards'); }
    if (s.action === 'forward') { return t('ca_forwards'); }
    if (s.action === 'domain') { return t('ca_domain_forwards'); }
    return s.notice ? t('ca_refuses_notice') : t('ca_refuses');
  }
  function whatCell(s) {
    var parts = [el('span', {class: 'sig-pill' + (s.action === 'discard' ? ' sig-pill--warn' : (s.action === 'forward' || s.action === 'domain' ? ' sig-pill--accent' : '')),
      text: whatText(s)})];
    if (s.action === 'forward') { parts.push(el('ul', {class: 'fp-mail-to-list fp-row-note'}, s.to.map(function (a) { return el('li', {text: a}); }))); }
    if (s.action === 'domain') { parts.push(el('span', {class: 'fp-row-note fp-ca-to-domain', text: t('ca_domain_to_note', {domain: s.to[0]})})); }
    if (s.notice) { parts.push(el('span', {class: 'fp-row-note fp-ca-notice', text: t('ca_notice_quoted', {notice: s.notice})})); }
    return el('td', {class: 'fp-ca-what'}, parts);
  }
  function listCard() {
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t('ca_note')})];
    if (!P.rows.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('ca_no_domains')}));
    } else {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-ca-h'}, [
        el('table', {class: 'sig-table fp-mail-table fp-ca-table'}, [el('thead', null, [el('tr', null, [
          el('th', {scope: 'col', text: t('ca_domain')}), el('th', {scope: 'col', text: t('ca_what')}),
          el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]),
        el('tbody', null, P.rows.map(function (r) {
          return el('tr', {'data-fp-domain': r.domain}, [el('th', {scope: 'row', class: 'fp-mail-name'}, [el('span', {text: r.domain}),
            r.editable ? null : el('span', {class: 'fp-muted fp-row-note', text: t('ca_dropped')})]),
          whatCell(r.set),
          el('td', {class: 'fp-mail-acts'}, [r.editable ? el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button',
            'data-fp-act': 'ca-change', 'aria-label': t('ca_change_of', {domain: r.domain}), text: t('ca_change')}) : null])]);
        }))])]));
    }
    return M.card('fp-ca-h', t('ca_title'), parts, 'fp-ca-list');
  }

  function radio(id, value, label, hint) {
    return el('div', {class: 'fp-ca-choice'}, [el('label', {class: 'fp-check', for: id}, [
      el('input', {type: 'radio', id: id, name: 'action', value: value, 'aria-describedby': hint ? id + '-hint' : null}), el('span', {text: label})]),
    hint ? el('span', {class: 'sig-hint', id: id + '-hint', text: hint}) : null]);
  }
  function formCard() {
    var editable = P.rows.filter(function (r) { return r.editable; });
    var pick = el('select', {class: 'sig-select', id: 'fp-ca-domain', name: 'domain'}, editable.map(function (r) {
      var o = el('option', {value: r.domain, text: r.domain});
      if (r.domain === P.pick) { o.selected = true; }
      return o;
    }));
    var notice = el('input', {class: 'sig-input', id: 'fp-ca-notice', name: 'notice', type: 'text', maxlength: String(MAX_NOTICE), autocomplete: 'off',
      spellcheck: 'true', placeholder: t('ca_notice_placeholder')});
    var to = el('textarea', {class: 'sig-input fp-mail-to', id: 'fp-ca-to', name: 'to', rows: '3', spellcheck: 'false', autocapitalize: 'none',
      autocomplete: 'off'});
    var toDomain = el('input', {class: 'sig-input', id: 'fp-ca-to-domain', name: 'to_domain', type: 'text', maxlength: '253', spellcheck: 'false',
      autocapitalize: 'none', autocomplete: 'off', placeholder: 'example.com'});
    var toDomainField = M.field('fp-ca-to-domain', t('ca_to_domain'), toDomain, t('ca_to_domain_hint'));
    var noticeField = M.field('fp-ca-notice', t('ca_notice'), notice, t('ca_notice_hint', {n: MAX_NOTICE}));
    var toField = M.field('fp-ca-to', t('ca_to'), to, t('ca_to_hint', {n: MAX_TO}));
    var form = el('form', {class: 'fp-form fp-mail-form fp-ca-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-ca-domain', t('ca_for_domain'), pick),
      el('fieldset', {class: 'fp-ca-actions'}, [el('legend', {class: 'sig-label', text: t('ca_action')}),
        radio('fp-ca-reject', 'reject', t('ca_reject'), t('ca_reject_hint')), noticeField,
        radio('fp-ca-discard', 'discard', t('ca_discard'), t('ca_discard_hint')),
        radio('fp-ca-forward', 'forward', t('ca_forward'), t('ca_forward_hint')), toField,
        radio('fp-ca-domain-fwd', 'domain', t('ca_domain_fwd'), t('ca_domain_fwd_hint')), toDomainField]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('ca_save')})])]);
    function action() { var c = form.querySelector('[name="action"]:checked'); return c ? c.value : 'reject'; }
    function sync() {
      var a = action();
      noticeField.hidden = a !== 'reject';
      toField.hidden = a !== 'forward';
      toDomainField.hidden = a !== 'domain';
    }
    /* the form shows the chosen domain's setting as the server has it */
    function load() {
      var r = rowOf(pick.value);
      P.pick = pick.value;
      var s = r ? r.set : {action: 'reject', notice: '', to: []};
      form.querySelector('[name="action"][value="' + s.action + '"]').checked = true;
      notice.value = s.notice;
      to.value = s.action === 'forward' ? s.to.join('\n') : '';
      toDomain.value = s.action === 'domain' ? s.to[0] : '';
      sync();
    }
    pick.addEventListener('change', function () { M.start(form); load(); });
    form.addEventListener('change', function (e) { if (e.target.name === 'action') { sync(); } });
    load();
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var domain = pick.value;
      var a = action();
      var body = {action: a};
      if (a === 'reject') {
        var n = notice.value.trim();
        if (!NOTICE_RE.test(n) || /[\r\n]/.test(notice.value)) { M.fieldError(form, notice, t('ca_notice_bad')); return; }
        if (n.length > MAX_NOTICE) { M.fieldError(form, notice, t('ca_notice_long', {n: MAX_NOTICE})); return; }
        if (n) { body.notice = n; }
      } else if (a === 'forward') {
        var list = to.value.split(/[\s,;]+/).map(function (s) { return s.trim().toLowerCase(); }).filter(Boolean);
        list = list.filter(function (s, i) { return list.indexOf(s) === i; });
        var bad = list.filter(function (s) { return !M.isAddress(s); })[0];
        if (!list.length) { M.fieldError(form, to, t('fwd_to_none')); return; }
        if (bad) { M.fieldError(form, to, t('fwd_to_bad', {address: bad})); return; }
        if (list.length > MAX_TO) { M.fieldError(form, to, t('fwd_to_many', {n: MAX_TO})); return; }
        /* an address of the same domain that is neither a mailbox nor a forwarder would send the mail straight back here */
        var known = P.mail.mailboxes.map(function (m) { return m.address; }).concat(P.mail.forwarders.map(function (f) { return f.source; }));
        var loop = list.filter(function (s) { return s.slice(s.lastIndexOf('@') + 1) === domain && known.indexOf(s) < 0; })[0];
        if (loop) { M.fieldError(form, to, t('ca_to_loop', {address: loop, domain: domain})); return; }
        body.to = list;
      } else if (a === 'domain') {
        var td = toDomain.value.trim().toLowerCase().replace(/^@/, '').replace(/\.$/, '');
        if (!DOMAIN_RE.test(td)) { M.fieldError(form, toDomain, t('ca_to_domain_bad')); return; }
        if (td === domain) { M.fieldError(form, toDomain, t('ca_to_domain_self')); return; }
        body.to = [td];
      }
      UI.setBusy(b, true);
      FP.call('put', 'mailDefault', body, {name: P.account, domain: domain}).then(function (r) {
        settle(P, r, null);
        render();
        M.say(P.page.querySelector('.fp-ca-list'), t(a === 'reject' ? (body.notice ? 'ca_saved_notice' : 'ca_saved_reject') : 'ca_saved_' + a, {domain: domain, to: body.to ? body.to[0] : ''}));
        P.page.querySelector('#fp-ca-h').focus();
      }, function (err) {
        UI.setBusy(b, false);
        var f = a === 'domain' ? toDomain : (err.field === 'to' || /forward|address/.test(err.message) ? to : (/notice/.test(err.message) ? notice : null));
        if (f && f.closest('[hidden]')) { f = null; }
        M.fieldError(form, f, err.message);
      });
    });
    return M.card('fp-ca-form-h', t('ca_form_title'), [form], 'fp-ca-change');
  }

  function render() {
    P.page.textContent = '';
    if (P.mail.suspended) { P.page.appendChild(M.suspendedBanner(t('mail_suspended'))); }
    P.page.appendChild(listCard());
    if (P.rows.some(function (r) { return r.editable; })) { P.page.appendChild(formCard()); }
  }

  document.addEventListener('click', function (e) {
    if (!P.page) { return; }
    var b = e.target.closest ? e.target.closest('[data-fp-act="ca-change"]') : null;
    if (!b || !P.page.contains(b)) { return; }
    var pick = P.page.querySelector('#fp-ca-domain');
    pick.value = b.closest('tr').getAttribute('data-fp-domain');
    pick.dispatchEvent(new Event('change'));
    P.page.querySelector('.fp-ca-form [name="action"]:checked').focus();
  });

  FP.view('tool:catch_all', function () {
    P.page = null;
    var body = M.frame('catch_all', 'fp-ca');
    if (!body) { return; }
    P.page = body;
    P.account = FP.account();
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all([FP.call('get', 'mail', undefined, P.account), FP.call('get', 'domains', undefined, P.account)]).then(function (r) {
      if (P.page !== body) { return; }
      settle(P, r[0], r[1]);
      render();
    }, function (err) {
      if (P.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(FP.tools.catch_all.label, err.message));
    });
  });
})();

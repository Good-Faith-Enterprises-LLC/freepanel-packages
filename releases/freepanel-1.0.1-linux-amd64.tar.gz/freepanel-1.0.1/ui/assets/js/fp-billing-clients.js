/* freePanel billing clients (#/tool/billing_clients), the admin panel's list of the people and companies that buy hosting (docs/api.md,
   "Billing: customers", docs/billing/navigation-map.md, "Clients"): the clients with their status, group, services and what they owe,
   found by name, company or email and filtered by status and group; a form to add one; and a client's own page, opened from the list on
   this same page, with what they owe and the credit they hold, and its tabs: Summary, Profile, Contacts, Notes, Invoices and Credit.
   Everything a client or an admin typed is shown as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;
  var M = FP.mail;

  var PAGE = 50;
  var STATUSES = ['active', 'inactive', 'closed'];
  var TABS = ['summary', 'profile', 'contacts', 'services', 'domains', 'invoices', 'quotes', 'transactions', 'credit', 'tickets', 'methods', 'notes', 'referral'];
  /* the feature a tab's API needs; the others need only the clients' own */
  var GATE = {services: 'billing_invoices', invoices: 'billing_invoices', quotes: 'billing_invoices', transactions: 'billing_invoices', credit: 'billing_invoices',
    methods: 'billing_invoices', domains: 'billing_domains', tickets: 'billing_support'};
  var ROLES = ['billing', 'support', 'technical', 'domains'];
  var C = null;

  function invoicesOn() { return B.has('billing_invoices'); }
  function groupName(gid) {
    for (var i = 0; i < C.groups.length; i++) { if (C.groups[i].id === gid) { return C.groups[i].name; } }
    return '';
  }
  function cleanGroups(r) {
    return (r && Array.isArray(r.groups) ? r.groups : []).map(function (g) {
      return g && B.id(g.id) ? {id: g.id, name: B.str(g.name, 60)} : null;
    }).filter(Boolean);
  }
  function cleanFields(r) {
    return (r && Array.isArray(r.fields) ? r.fields : []).map(function (f) {
      if (!f || !B.id(f.id) || ['text', 'choice', 'yes_no'].indexOf(f.kind) < 0) { return null; }
      return {id: f.id, name: B.str(f.name, 60), kind: f.kind, required: f.required === true,
        choices: (Array.isArray(f.choices) ? f.choices : []).filter(function (c) { return typeof c === 'string'; }).slice(0, 20)};
    }).filter(Boolean);
  }
  function screen(nodes, focus) {
    C.page.textContent = '';
    nodes.forEach(function (n) { if (n) { C.page.appendChild(n); } });
    var target = focus ? C.page.querySelector(focus) : null;
    if (target) { target.focus(); }
  }
  function idSel(act, cid) { return '[data-fp-act="' + act + '"][data-fp-id="' + cid + '"]'; }

  /* ================= the list ================= */
  function filterForm() {
    var f = C.filters;
    var q = B.input('fp-bcl-q', 'q', f.q, {type: 'search', maxlength: '100', spellcheck: 'false', autocapitalize: 'none'});
    var status = B.select('fp-bcl-status', 'status', [['', t('bil_any')]].concat(STATUSES.map(function (s) { return [s, t('bil_client_' + s)]; })), f.status);
    var group = B.select('fp-bcl-group', 'group', [['', t('bil_any')]].concat(C.groups.map(function (g) { return [String(g.id), g.name]; })), f.group,
      {disabled: C.groups.length ? null : true});
    var form = el('form', {class: 'fp-form fp-bil-filters', novalidate: '', role: 'search', 'aria-label': t('bcl_find')}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-bil-filter-row'}, [M.field('fp-bcl-q', t('bcl_f_q'), q, t('bcl_f_q_hint')), M.field('fp-bcl-status', t('bcl_f_status'), status),
        M.field('fp-bcl-group', t('bcl_f_group'), group)]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bil_show')}),
        B.button('clear', t('bil_clear'), 'sig-btn--secondary', {hidden: f.q || f.status || f.group ? null : true})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = form.querySelector('.fp-submit');
      if (!B.begin(form, b)) { return; }
      C.filters = {q: q.value.trim(), status: status.value, group: group.value};
      C.offset = 0;
      refreshList(b, '#fp-bcl-q');
    });
    return form;
  }
  function listCard() {
    var add = B.button('add', t('bcl_add'), 'sig-btn--primary');
    return M.card('fp-bcl-list-h', t('bcl_list_title'), [el('div', {class: 'fp-bil-toolbar'}, [add]), filterForm(), el('div', {'data-fp-results': ''})], 'fp-bcl-list');
  }
  function row(c) {
    var a = C.agg;
    var owed = a.owed ? B.money(a.owed[c.id] || 0, 'USD') : '—';
    var services = a.services ? B.num(a.services[c.id] || 0) : '—';
    return el('tr', {'data-fp-client': String(c.id)}, [
      el('th', {scope: 'row', class: 'fp-bil-name'}, [B.button('open', c.name || '—', 'sig-btn--link fp-bil-link', {'data-fp-id': String(c.id)})]),
      el('td', {class: 'fp-bil-wrap', text: c.company || '—'}),
      el('td', {class: 'fp-bil-wrap fp-bil-email', text: c.email}),
      el('td', null, [B.clientPill(c.status)]),
      el('td', {text: c.group_id ? groupName(c.group_id) || '—' : '—'}),
      el('td', {class: 'fp-bil-num', text: services}),
      el('td', {class: 'fp-bil-num', text: owed}),
      el('td', {class: 'fp-bil-nowrap', text: B.day(c.created) || '—'})]);
  }
  function results() {
    var d = C.data;
    var f = C.filters;
    var out = [];
    if (!d.customers.length) {
      out.push(el('p', {class: 'fp-muted fp-bil-empty', 'data-fp-empty': '', text: t(f.q || f.status || f.group ? 'bcl_none_match' : 'bcl_none')}));
      return out;
    }
    out.push(el('p', {class: 'fp-muted', 'data-fp-count': '', text: d.total === 1 ? t('bil_range_1') :
      t('bil_range', {from: B.num(C.offset + 1), to: B.num(C.offset + d.customers.length), total: B.num(d.total)})}));
    out.push(B.table('fp-bcl-list-h', 'fp-bcl-table', [B.th(t('bcl_col_name')), B.th(t('bcl_col_company')), B.th(t('bcl_col_email')), B.th(t('bcl_col_status')),
      B.th(t('bcl_col_group')), B.th(t('bcl_col_services'), 'fp-bil-num'), B.th(t('bcl_col_owed'), 'fp-bil-num'), B.th(t('bcl_col_created'))], d.customers.map(row)));
    if (!C.agg.owed || !C.agg.services) { out.push(el('p', {class: 'fp-muted fp-row-note', 'data-fp-agg-note': '', text: t('bcl_totals_missing')})); }
    if (d.total > PAGE) {
      var prev = B.button('prev', t('bil_prev'));
      var next = B.button('next', t('bil_next'));
      prev.disabled = C.offset === 0;
      next.disabled = C.offset + PAGE >= d.total;
      out.push(el('div', {class: 'fp-actions'}, [prev, next]));
    }
    return out;
  }
  function drawResults(focus) {
    var box = C.page.querySelector('[data-fp-results]');
    if (!box) { return; }
    box.textContent = '';
    results().forEach(function (n) { box.appendChild(n); });
    var clear = C.page.querySelector('[data-fp-act="clear"]');
    if (clear) { clear.hidden = !(C.filters.q || C.filters.status || C.filters.group); }
    var target = focus ? C.page.querySelector(focus) : null;
    if (target) { target.focus(); }
  }
  /* what each client owes (their unpaid invoices) and how many services are running, counted from those lists; null when they can't be
     read in full (more than a thousand), so a column never shows a part as the whole */
  function aggregates() {
    if (!invoicesOn()) { return Promise.resolve({owed: null, services: null}); }
    var count = function (r, f) {
      if (!r.complete) { return null; }
      var out = {};
      r.items.forEach(function (x) { if (x && B.id(x.customer_id)) { f(out, x); } });
      return out;
    };
    return Promise.all([
      B.allPages('billingInvoices', {status: 'unpaid'}, 'invoices').then(function (r) {
        return count(r, function (o, x) { o[x.customer_id] = (o[x.customer_id] || 0) + (B.cents(x.balance_cents) || 0); });
      }, function () { return null; }),
      B.allPages('billingServices', {status: 'active'}, 'services').then(function (r) {
        return count(r, function (o, x) { o[x.customer_id] = (o[x.customer_id] || 0) + 1; });
      }, function () { return null; })
    ]).then(function (r) { return {owed: r[0], services: r[1]}; });
  }
  function loadList() {
    var mine = C;
    var f = C.filters;
    return Promise.all([FP.call('get', 'billingCustomers', undefined, {limit: String(PAGE), offset: String(C.offset), q: f.q, status: f.status, group: f.group}),
      aggregates()]).then(function (r) {
      if (C !== mine) { return null; }
      var list = (r[0] && Array.isArray(r[0].customers) ? r[0].customers : []).map(B.cleanCustomer).filter(Boolean);
      var total = B.whole(r[0] && r[0].total);
      if (!list.length && C.offset > 0 && total) {
        C.offset = Math.floor((total - 1) / PAGE) * PAGE;
        return loadList();
      }
      C.data = {customers: list, total: total === null ? list.length : total};
      C.agg = r[1];
      return C.data;
    });
  }
  function refreshList(b, focus) {
    var mine = C;
    if (b) { UI.setBusy(b, true); }
    return loadList().then(function (d) {
      if (C !== mine || !d) { return; }
      if (b) { UI.setBusy(b, false); }
      drawResults(focus);
      var form = C.page.querySelector('.fp-bil-filters');
      if (form && b && b.classList.contains('fp-submit')) { M.say(form, d.total === 1 ? t('bcl_found_1') : t('bcl_found', {n: B.num(d.total)})); }
    }, function (err) {
      if (C !== mine) { return; }
      if (b) { UI.setBusy(b, false); }
      B.failed(C.page.querySelector('.fp-bil-filters'), err);
    });
  }
  function showList(focus) {
    C.view = 'list';
    C.client = null;
    var mine = C;
    screen([el('p', {class: 'fp-muted', text: t('loading')})]);
    return loadList().then(function (d) {
      if (C !== mine || !d) { return; }
      screen([listCard()]);
      drawResults();
      if (focus) { (C.page.querySelector(focus) || C.page.querySelector('#fp-bcl-list-h')).focus(); }
    }, function (err) {
      if (C !== mine) { return; }
      screen([FP.empty(t('bcl_list_title'), err.message, B.button('reload', t('bil_try_again')))]);
    });
  }

  /* ================= the client form: add, and the Profile tab ================= */
  function fieldControl(f, value, pre) {
    var fid = pre + '-x' + f.id;
    var name = 'fields.' + f.id;
    var label = f.name + (f.required ? ' *' : '');
    var control;
    if (f.kind === 'choice') {
      control = B.select(fid, name, [['', t('bil_none_chosen')]].concat(f.choices.map(function (c) { return [c, c]; })), value);
    } else if (f.kind === 'yes_no') {
      control = B.select(fid, name, [['', t('bil_none_chosen')], ['yes', t('bil_yes')], ['no', t('bil_no')]], value);
    } else {
      control = B.input(fid, name, value, {maxlength: '200'});
    }
    if (f.required) { control.setAttribute('aria-required', 'true'); }
    return M.field(fid, label, control);
  }
  function clientForm(c, edit) {
    var pre = edit ? 'fp-bcl-p' : 'fp-bcl-a';
    var v = c || {};
    var text = function (name, labelKey, max, extra, hint) {
      return M.field(pre + '-' + name, t(labelKey), B.input(pre + '-' + name, name, v[name] || '', Object.assign({maxlength: String(max)}, extra || {})), hint);
    };
    var groups = [['', t('bcl_no_group')]].concat(C.groups.map(function (g) { return [String(g.id), g.name]; }));
    var statusSel = B.select(pre + '-status', 'status', STATUSES.map(function (s) { return [s, t('bil_client_' + s)]; }), v.status || 'active');
    var account = [M.field(pre + '-group_id', t('bcl_group'), B.select(pre + '-group_id', 'group_id', groups, v.group_id ? String(v.group_id) : '')),
      M.field(pre + '-status', t('bcl_status'), statusSel, t('bcl_status_hint'))];
    C.fields.forEach(function (f) { account.push(fieldControl(f, v.fields ? v.fields[String(f.id)] || '' : '', pre)); });
    var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t(edit ? 'bil_save_changes' : 'bcl_add_save')});
    var form = el('form', {class: 'fp-form fp-bcl-form', novalidate: '', 'data-fp-client-form': edit ? 'edit' : 'add', 'aria-labelledby': edit ? 'fp-bcl-profile-h' : 'fp-bcl-add-h'}, [
      M.errorLine(), M.statusLine(),
      el('fieldset', {class: 'fp-bil-set'}, [el('legend', {class: 'fp-bil-legend', text: t('bcl_contact')}), el('div', {class: 'fp-bil-grid'}, [
        text('name', 'bcl_name', 100, {autocomplete: 'name', 'aria-required': 'true'}), text('company', 'bcl_company', 100, {autocomplete: 'organization'}),
        text('email', 'bcl_email', 254, {type: 'email', autocomplete: 'email', spellcheck: 'false', autocapitalize: 'none', 'aria-required': 'true'}),
        text('phone', 'bcl_phone', 30, {type: 'tel', autocomplete: 'tel'})])]),
      el('fieldset', {class: 'fp-bil-set'}, [el('legend', {class: 'fp-bil-legend', text: t('bcl_address')}), el('div', {class: 'fp-bil-grid'}, [
        text('address1', 'bcl_address1', 100, {autocomplete: 'address-line1'}), text('address2', 'bcl_address2', 100, {autocomplete: 'address-line2'}),
        text('city', 'bcl_city', 60, {autocomplete: 'address-level2'}), text('region', 'bcl_region', 60, {autocomplete: 'address-level1'}),
        text('postcode', 'bcl_postcode', 20, {autocomplete: 'postal-code'}),
        text('country', 'bcl_country', 2, {autocomplete: 'country', autocapitalize: 'characters', spellcheck: 'false'}, t('bcl_country_hint'))])]),
      el('fieldset', {class: 'fp-bil-set'}, [el('legend', {class: 'fp-bil-legend', text: t('bcl_account')}), el('div', {class: 'fp-bil-grid'}, account)]),
      el('p', {class: 'fp-muted fp-row-note', text: t('bcl_required_note')}),
      el('div', {class: 'fp-actions'}, [save, edit ? null : B.button('add-cancel', t('cancel'))])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!B.begin(form, save)) { return; }
      var body = readForm(form, edit ? C.client.c : null);
      if (!body) { return; }
      if (edit && !Object.keys(body).length) { M.say(form, t('bil_nothing_changed')); return; }
      saveClient(form, save, body, edit);
    });
    return form;
  }
  var TEXT_FIELDS = ['name', 'company', 'email', 'phone', 'address1', 'address2', 'city', 'region', 'postcode', 'country'];
  /* what the form holds: for a new client everything filled in; for a client being changed only what differs from before */
  function readForm(form, old) {
    var get = function (n) { return form.querySelector('[name="' + n + '"]'); };
    var body = {};
    TEXT_FIELDS.forEach(function (n) {
      var v = get(n).value.trim();
      if (n === 'country') { v = v.toUpperCase(); }
      if (old ? v !== old[n] : v) { body[n] = v; }
    });
    var name = get('name');
    var email = get('email');
    if (!name.value.trim()) { M.fieldError(form, name, t('bcl_name_needed')); return null; }
    if (!/^[^\s@]+@[^\s@]+$/.test(email.value.trim())) { M.fieldError(form, email, t('bcl_email_needed')); return null; }
    if (!old) { body.name = name.value.trim(); body.email = email.value.trim(); }
    var status = get('status').value;
    if (old ? status !== old.status : status !== 'active') { body.status = status; }
    var g = get('group_id').value;
    var gid = g ? Number(g) : null;
    if (old ? gid !== old.group_id : gid) { body.group_id = gid; }
    var fields = {};
    C.fields.forEach(function (f) {
      var v = get('fields.' + f.id).value.trim();
      var was = old ? old.fields[String(f.id)] || '' : '';
      if (v !== was) { fields[String(f.id)] = v === '' ? null : v; }
    });
    if (Object.keys(fields).length) { body.fields = fields; }
    return body;
  }
  function saveClient(form, save, body, edit) {
    var mine = C;
    UI.setBusy(save, true);
    var call = edit ? FP.call('patch', 'billingCustomer', body, {id: String(C.client.id)}) : FP.call('post', 'billingCustomerNew', body);
    call.then(function (r) {
      if (C !== mine) { return; }
      UI.setBusy(save, false);
      var c = B.cleanCustomer(r);
      if (!c) { UI.showError(form, t('api_failed')); return; }
      if (edit) {
        C.client.c = c;
        drawHeader();
        drawTab(null, function () {
          M.say(C.page.querySelector('[data-fp-client-form]'), t('bcl_saved'));
          var h = C.page.querySelector('#fp-bcl-profile-h');
          if (h) { h.focus(); }
        });
        UI.announce(t('bcl_saved'));
      } else {
        openClient(c.id, t('bcl_added', {name: c.name}));
      }
    }, function (err) {
      if (C !== mine) { return; }
      UI.setBusy(save, false);
      B.failed(form, err);
    });
  }
  function showAdd() {
    C.view = 'add';
    screen([B.back('to-list', t('bcl_back')), M.card('fp-bcl-add-h', t('bcl_add_title'), [el('p', {class: 'fp-muted', text: t('bcl_add_what')}), clientForm(null, false)], 'fp-bcl-add')],
      '#fp-bcl-a-name');
  }

  /* ================= a client ================= */
  function tabsOn() { return TABS.filter(function (x) { return !GATE[x] || B.has(GATE[x]); }); }
  function cleanCredit(r) {
    if (!r || typeof r !== 'object') { return null; }
    var entries = (Array.isArray(r.entries) ? r.entries : []).map(function (e) {
      return e && B.id(e.id) ? {id: e.id, amount_cents: B.cents(e.amount_cents) || 0, kind: B.str(e.kind, 20), invoice_id: B.id(e.invoice_id),
        note: B.str(e.note, 200), by: B.str(e.by, 64), created: B.str(e.created, 40)} : null;
    }).filter(Boolean);
    return {balance_cents: B.cents(r.balance_cents) || 0, currency: B.str(r.currency, 3) || 'USD', entries: entries, more: B.whole(r.more) || 0};
  }
  /* what the client owes: the balance of each unpaid invoice */
  function owedOf(cid) {
    return B.allPages('billingInvoices', {customer: String(cid), status: 'unpaid'}, 'invoices', 3).then(function (r) {
      return r.complete ? r.items.reduce(function (n, x) { return n + (x ? B.cents(x.balance_cents) || 0 : 0); }, 0) : null;
    }, function () { return null; });
  }
  function openClient(cid, said, tab) {
    var mine = C;
    var busy = C.page.querySelector(idSel('open', cid));
    if (busy) { UI.setBusy(busy, true); }
    var form = C.page.querySelector('.fp-bil-filters');
    if (form) { UI.showError(form, ''); }
    return Promise.all([FP.call('get', 'billingCustomer', undefined, {id: String(cid)}),
      invoicesOn() ? owedOf(cid) : null,
      invoicesOn() ? FP.call('get', 'billingCredit', undefined, {id: String(cid)}).then(cleanCredit, function () { return null; }) : null]).then(function (r) {
      if (C !== mine) { return; }
      var c = B.cleanCustomer(r[0]);
      if (!c) { throw {message: t('api_failed')}; }
      C.view = 'client';
      C.client = {id: c.id, c: c, owed: r[1], credit: r[2], tab: tab || 'summary', seq: 0};
      screen([B.back('to-list', t('bcl_back')), el('div', {'data-fp-head': ''}), tabStrip(), el('div', {class: 'fp-bil-panel', id: 'fp-bcl-panel', role: 'tabpanel', 'aria-labelledby': 'fp-bcl-tab-' + C.client.tab})]);
      drawHeader();
      C.page.querySelector('#fp-bcl-name-h').focus();
      if (said) { M.say(C.page.querySelector('[data-fp-head]'), said); }
      drawTab();
    }).catch(function (err) {
      if (C !== mine) { return; }
      if (busy && busy.isConnected) { UI.setBusy(busy, false); }
      var f = C.page.querySelector('.fp-bil-filters');
      if (f) { UI.showError(f, err.message); if (busy && busy.isConnected) { busy.focus(); } } else { showList().then(function () { var g = C.page.querySelector('.fp-bil-filters'); if (g) { UI.showError(g, err.message); } }); }
    });
  }
  function drawHeader() {
    var box = C.page.querySelector('[data-fp-head]');
    var cl = C.client;
    var c = cl.c;
    var acts = [];
    if (FP.tools.billing_invoices && c.status === 'active') { acts.push(B.button('create-invoice', t('bcl_create_invoice'), 'sig-btn--primary sig-btn--sm')); }
    if (FP.tools.billing_order_new && c.status === 'active') { acts.push(B.button('add-order', t('bcl_add_order'), 'sig-btn--secondary sig-btn--sm')); }
    if (invoicesOn() && c.status !== 'closed') { acts.push(B.button('add-credit', t('bcl_add_credit'), 'sig-btn--secondary sig-btn--sm')); }
    if (B.has('billing_support') && c.status !== 'closed') { acts.push(B.button('new-ticket', t('bcl_open_ticket'), 'sig-btn--secondary sig-btn--sm')); }
    var card = el('section', {class: 'sig-card fp-bil-head', 'aria-labelledby': 'fp-bcl-name-h'}, [el('div', {class: 'sig-card-body'}, [
      M.statusLine(),
      el('div', {class: 'fp-bil-head-row'}, [el('div', {class: 'fp-bil-head-name'}, [
        el('h2', {class: 'fp-h2', id: 'fp-bcl-name-h', tabindex: '-1', text: c.name || '—'}),
        c.company ? el('p', {class: 'fp-muted fp-bil-sub', text: c.company}) : null]), B.clientPill(c.status)]),
      invoicesOn() ? B.facts([[t('bcl_col_owed'), cl.owed === null ? '—' : B.money(cl.owed, 'USD')], [t('bcl_credit'), cl.credit ? B.money(cl.credit.balance_cents, cl.credit.currency) : '—']], 'fp-bil-money') : null,
      acts.length ? el('div', {class: 'fp-actions'}, acts) : null])]);
    var said = box.querySelector('[data-fp-status]');
    var keep = said ? said.textContent : '';
    box.textContent = '';
    box.appendChild(card);
    if (keep) { M.say(box, keep); }
  }
  function tabStrip() {
    var strip = el('div', {class: 'sig-tabs fp-bil-tabs', role: 'tablist', 'aria-label': t('bcl_tabs')});
    tabsOn().forEach(function (name) {
      var on = name === C.client.tab;
      strip.appendChild(el('button', {class: 'sig-tab', type: 'button', role: 'tab', id: 'fp-bcl-tab-' + name, 'aria-selected': String(on), 'aria-controls': 'fp-bcl-panel',
        tabindex: on ? '0' : '-1', 'data-fp-act': 'tab', 'data-fp-tab': name, text: t('bcl_tab_' + name)}));
    });
    strip.addEventListener('keydown', function (e) {
      var tabs = Array.prototype.slice.call(strip.querySelectorAll('[role="tab"]'));
      var i = tabs.indexOf(document.activeElement);
      if (i < 0) { return; }
      var to = e.key === 'ArrowRight' ? (i + 1) % tabs.length : e.key === 'ArrowLeft' ? (i - 1 + tabs.length) % tabs.length : e.key === 'Home' ? 0 : e.key === 'End' ? tabs.length - 1 : -1;
      if (to < 0) { return; }
      e.preventDefault();
      selectTab(tabs[to].getAttribute('data-fp-tab'), true);
    });
    return strip;
  }
  function selectTab(name, focusTab, then) {
    C.client.tab = name;
    var tabs = C.page.querySelectorAll('[role="tab"]');
    for (var i = 0; i < tabs.length; i++) {
      var on = tabs[i].getAttribute('data-fp-tab') === name;
      tabs[i].setAttribute('aria-selected', String(on));
      tabs[i].setAttribute('tabindex', on ? '0' : '-1');
      if (on && focusTab) { tabs[i].focus(); }
    }
    C.page.querySelector('#fp-bcl-panel').setAttribute('aria-labelledby', 'fp-bcl-tab-' + name);
    drawTab(null, then);
  }

  /* reads what the tab shows and draws it; then runs after it is drawn */
  function drawTab(_, then) {
    var cl = C.client;
    var mine = C;
    var seq = ++cl.seq;
    var panel = C.page.querySelector('#fp-bcl-panel');
    panel.textContent = '';
    panel.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    var tab = cl.tab;
    var cid = String(cl.id);
    var loads = {
      summary: function () {
        return Promise.all([invoicesOn() ? FP.call('get', 'billingInvoices', undefined, {limit: '5', offset: '0', customer: cid}).then(cleanInvoices, function () { return null; }) : null,
          FP.call('get', 'billingNotes', undefined, {id: cid}).then(cleanNotes, function () { return null; }),
          B.has('billing_support') ? ticketsOf(cid, '5').then(null, function () { return null; }) : null]);
      },
      profile: function () { return Promise.resolve(null); },
      contacts: function () { return FP.call('get', 'billingContacts', undefined, {id: cid}); },
      notes: function () { return FP.call('get', 'billingNotes', undefined, {id: cid}).then(cleanNotes); },
      invoices: function () { return FP.call('get', 'billingInvoices', undefined, {limit: '50', offset: '0', customer: cid}).then(cleanInvoices); },
      credit: function () { return FP.call('get', 'billingCredit', undefined, {id: cid}).then(cleanCredit); },
      services: function () {
        return Promise.all([B.listOf('billingServices', {limit: '50', offset: '0', customer: cid}, 'services', B.cleanService),
          FP.call('get', 'billingAccounts', undefined, {id: cid}).then(cleanAccounts)]);
      },
      domains: function () { return B.listOf('billingDomains', {limit: '50', offset: '0', customer: cid}, 'domains', cleanDomain); },
      quotes: function () { return B.listOf('billingQuotes', {limit: '50', offset: '0', customer: cid}, 'quotes', cleanQuote); },
      transactions: function () { return B.listOf('billingTransactions', {limit: '50', offset: '0', customer: cid}, 'transactions', B.cleanTx); },
      tickets: function () { return ticketsOf(cid, '50'); },
      methods: function () {
        return Promise.all([FP.call('get', 'billingMethods', undefined, {id: cid}).then(cleanMethods),
          FP.call('get', 'billingGateways').then(cleanGateways, function () { return null; })]);
      },
      referral: function () {
        return Promise.all([FP.call('get', 'billingReferrer', undefined, {id: cid}).then(cleanReferral),
          FP.call('get', 'billingAffiliates').then(function (r) {
            return B.pickAll(r && r.affiliates, {id: 'id', customer_id: 'id', code: [32], status: [10], rate_bp: 'n', referred: 'n'}, 'id').filter(function (a) { return a.customer_id === cl.id; })[0] || false;
          }, function () { return null; })]);
      }
    };
    return loads[tab]().then(function (data) {
      if (C !== mine || C.client !== cl || cl.seq !== seq) { return; }
      if (tab === 'credit' && data) { cl.credit = data; drawHeader(); }
      panel.textContent = '';
      PANELS[tab](data).forEach(function (n) { if (n) { panel.appendChild(n); } });
      if (then) { then(); }
    }, function (err) {
      if (C !== mine || C.client !== cl || cl.seq !== seq) { return; }
      panel.textContent = '';
      panel.appendChild(FP.empty(t('bcl_tab_' + tab), err.message, B.button('tab-again', t('bil_try_again'))));
    });
  }
  function cleanInvoices(r) {
    return {invoices: (r && Array.isArray(r.invoices) ? r.invoices : []).map(B.cleanInvoice).filter(Boolean), total: B.whole(r && r.total) || 0};
  }
  function cleanNotes(r) {
    return (r && Array.isArray(r.notes) ? r.notes : []).map(function (n) {
      return n && B.id(n.id) ? {id: n.id, author: B.str(n.author, 64), body: B.str(n.body, 2000), created: B.str(n.created, 40), updated: B.str(n.updated, 40)} : null;
    }).filter(Boolean);
  }

  function cleanAccounts(r) {
    return {accounts: B.pickAll(r && r.accounts, {username: [32], domain: [253], status: [20], package: [64], linked: 'w'}, 'username'), max: B.whole(r && r.max) || 200};
  }
  var DOMAIN = {id: 'id', name: [253], status: ['=', ['pending', 'active', 'expired', 'cancelled', 'failed', 'transferred_away']], expires_on: 'd', auto_renew: 'b', registrar: [40], locked: 'b'};
  function cleanDomain(x) { var d = B.pick(x, DOMAIN); return d && d.id ? d : null; }
  var QUOTE = {id: 'id', customer_id: 'id', number: [40], status: ['=', ['draft', 'sent', 'accepted', 'declined', 'expired', 'invoiced']], subject: [100], valid_until: 'd',
    currency: [3], total_cents: 'c', invoice_id: 'id', created: 'w'};
  function cleanQuote(x) { var q = B.pick(x, QUOTE); return q && q.id && q.status ? q : null; }
  var TICKET = {id: 'id', customer_id: 'id', department_id: 'id', subject: [150], status: ['=', ['open', 'customer_reply', 'answered', 'on_hold', 'closed']],
    priority: ['=', ['low', 'medium', 'high']], assigned_to: [64], last_reply_by: [64], last_reply: 'w', created: 'w'};
  function cleanTicket(x) { var k = B.pick(x, TICKET); return k && k.id ? k : null; }
  /* a client's tickets and the departments' names */
  function ticketsOf(cid, limit) {
    return Promise.all([B.listOf('billingTickets', {limit: limit, offset: '0', customer: cid}, 'tickets', cleanTicket),
      FP.call('get', 'billingDepartments').then(function (r) { return B.pickAll(r && r.departments, {id: 'id', name: [60], hidden: 'b'}, 'id'); }, function () { return []; })]).then(function (r) {
      return {tickets: r[0].items, total: r[0].total || r[0].items.length, departments: r[1]};
    });
  }
  function cleanMethods(r) {
    return {methods: B.pickAll(r && r.methods, {id: 'id', gateway: [40], status: ['=', ['pending', 'active', 'refused', 'removed']], label: [100], expires_on: 'd', default: 'b', created: 'w'}, 'id'),
      max: B.whole(r && r.max) || 10};
  }
  function cleanGateways(r) { return B.pickAll(r && r.gateways, {id: [40], name: [60], enabled: 'b'}, 'id'); }
  function cleanReferral(r) { return B.pick(r, {affiliate_id: 'id', code: [32], since: 'w'}) || {affiliate_id: null, code: '', since: ''}; }
  function quoteName(q) { return q.number || t('bcl_quote_draft_n', {id: String(q.id)}); }
  function actsHead() { return el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('acct_actions')})]); }

  function invoiceTable(hid, list) {
    var open = Boolean(FP.tools.billing_invoices);
    return B.table(hid, 'fp-bcl-inv-table', [B.th(t('binv_col_number')), B.th(t('binv_col_issued')), B.th(t('binv_col_due')), B.th(t('binv_col_total'), 'fp-bil-num'),
      B.th(t('binv_col_balance'), 'fp-bil-num'), B.th(t('binv_col_status'))], list.map(function (inv) {
      var name = B.invoiceName(inv);
      return el('tr', {'data-fp-invoice': String(inv.id)}, [
        el('th', {scope: 'row', class: 'fp-bil-name'}, [open ? B.button('open-invoice', name, 'sig-btn--link fp-bil-link', {'data-fp-id': String(inv.id), 'aria-label': t('bil_open_invoice', {name: name})}) : name]),
        el('td', {class: 'fp-bil-nowrap', text: B.day(inv.issued) || '—'}), el('td', {class: 'fp-bil-nowrap', text: B.day(inv.due_on) || '—'}),
        el('td', {class: 'fp-bil-num', text: B.money(inv.total_cents, inv.currency)}), el('td', {class: 'fp-bil-num', text: B.money(inv.balance_cents, inv.currency)}),
        el('td', null, [B.invoicePill(inv)])]);
    }));
  }
  function noteList(notes, editable) {
    return el('ul', {class: 'fp-bil-notes'}, notes.map(function (n) { return noteItem(n, editable); }));
  }
  function noteButtons(nid, when) {
    return [B.button('note-edit', t('bil_change'), 'sig-btn--secondary sig-btn--sm', {'data-fp-id': String(nid), 'aria-label': t('bcl_note_change_of', {when: when})}),
      B.button('note-remove', t('bil_remove'), 'sig-btn--secondary sig-btn--sm fp-btn-danger-text', {'data-fp-id': String(nid), 'aria-label': t('bcl_note_remove_of', {when: when})})];
  }
  function noteItem(n, editable) {
    var when = B.when(n.created);
    var acts = editable ? el('div', {class: 'fp-bil-row-acts'}, noteButtons(n.id, when)) : null;
    return el('li', {class: 'fp-bil-note', 'data-fp-note': String(n.id), 'data-fp-when': when}, [
      el('p', {class: 'fp-muted fp-row-note', text: t('bcl_note_by', {who: n.author || '—', when: when})}),
      el('p', {class: 'fp-bil-note-body', text: n.body}), acts]);
  }

  var PANELS = {
    summary: function (d) {
      var c = C.client.c;
      var where = [c.address1, c.address2, [c.city, c.region, c.postcode].filter(Boolean).join(', '), c.country].filter(Boolean);
      var pairs = [[t('bcl_email'), c.email], [t('bcl_phone'), c.phone], [t('bcl_address'), where.length ? where.map(function (l) { return el('span', {class: 'fp-bil-line', text: l}); }) : ''],
        [t('bcl_group'), c.group_id ? groupName(c.group_id) : ''], [t('bcl_col_created'), B.day(c.created)]];
      C.fields.forEach(function (f) {
        var v = c.fields[String(f.id)];
        if (v) { pairs.push([f.name, f.kind === 'yes_no' ? t(v === 'yes' ? 'bil_yes' : 'bil_no') : v]); }
      });
      var out = [M.card('fp-bcl-details-h', t('bcl_details'), [B.facts(pairs)], 'fp-bcl-details')];
      if (invoicesOn()) {
        var inv = d[0];
        out.push(M.card('fp-bcl-recent-h', t('bcl_recent_invoices'), [inv === null ? el('p', {class: 'fp-muted', text: t('bcl_invoices_unread')}) : inv.invoices.length ?
          invoiceTable('fp-bcl-recent-h', inv.invoices) : el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('bcl_no_invoices')})], 'fp-bcl-recent'));
      }
      if (B.has('billing_support')) {
        var tk = d[2];
        out.push(M.card('fp-bcl-recent-tk-h', t('bcl_recent_tickets'), [tk === null ? el('p', {class: 'fp-muted', text: t('bcl_tickets_unread')}) : tk.tickets.length ?
          ticketTable('fp-bcl-recent-tk-h', tk.tickets, tk.departments) : el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('bcl_no_tickets')})], 'fp-bcl-recent-tk'));
      }
      var notes = d[1];
      out.push(M.card('fp-bcl-recent-notes-h', t('bcl_recent_notes'), [notes === null ? el('p', {class: 'fp-muted', text: t('bcl_notes_unread')}) : notes.length ?
        noteList(notes.slice(0, 3), false) : el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('bcl_no_notes')})], 'fp-bcl-recent-notes'));
      return out;
    },
    profile: function () {
      return [M.card('fp-bcl-profile-h', t('bcl_tab_profile'), [clientForm(C.client.c, true)], 'fp-bcl-profile')];
    },
    contacts: function (r) {
      var roles = (r && Array.isArray(r.roles) ? r.roles : ROLES).filter(function (x) { return typeof x === 'string' && /^[a-z_]{1,20}$/.test(x); });
      var list = (r && Array.isArray(r.contacts) ? r.contacts : []).map(function (x) {
        return x && B.id(x.id) ? {id: x.id, name: B.str(x.name, 100), email: B.str(x.email, 254), phone: B.str(x.phone, 30),
          roles: (Array.isArray(x.roles) ? x.roles : []).filter(function (y) { return typeof y === 'string'; })} : null;
      }).filter(Boolean);
      C.client.contacts = list;
      C.client.roles = roles;
      var max = B.whole(r && r.max) || 20;
      var parts = [M.errorLine(), M.statusLine()];
      if (!list.length) {
        parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('bcl_no_contacts')}));
      } else {
        parts.push(B.table('fp-bcl-contacts-h', 'fp-bcl-ct-table', [B.th(t('bcl_col_name')), B.th(t('bcl_col_email')), B.th(t('bcl_col_kind')), B.th(t('bcl_col_gets_invoices')),
          el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('acct_actions')})])], list.map(contactRow)));
      }
      var closed = C.client.c.status === 'closed';
      var out = [M.card('fp-bcl-contacts-h', t('bcl_tab_contacts'), parts, 'fp-bcl-contacts')];
      if (closed) {
        out.push(el('p', {class: 'fp-muted', 'data-fp-closed': '', text: t('bcl_contacts_closed')}));
      } else if (list.length >= max) {
        out.push(el('p', {class: 'fp-muted', text: t('bcl_contacts_full', {n: B.num(max)})}));
      } else {
        out.push(contactCard(null));
      }
      return out;
    },
    notes: function (notes) {
      var parts = [M.errorLine(), M.statusLine()];
      parts.push(notes.length ? noteList(notes, true) : el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('bcl_no_notes')}));
      return [noteCard(), M.card('fp-bcl-notes-h', t('bcl_notes_title'), parts, 'fp-bcl-notes')];
    },
    invoices: function (d) {
      var parts = [M.errorLine()];
      if (!d.invoices.length) {
        parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('bcl_no_invoices')}));
      } else {
        parts.push(invoiceTable('fp-bcl-invoices-h', d.invoices));
        if (d.total > d.invoices.length) { parts.push(el('p', {class: 'fp-muted fp-row-note', text: t('bcl_invoices_newest', {n: B.num(d.invoices.length), total: B.num(d.total)})})); }
      }
      return [M.card('fp-bcl-invoices-h', t('bcl_tab_invoices'), parts, 'fp-bcl-invoices')];
    },
    credit: function (cr) {
      var closed = C.client.c.status === 'closed';
      var kind = B.select('fp-bcl-cr-kind', 'kind', [['add', t('bcl_credit_add')], ['remove', t('bcl_credit_remove')]].filter(function (o) { return !closed || o[0] === 'remove'; }), closed ? 'remove' : 'add');
      var amount = B.input('fp-bcl-cr-amount', 'amount_cents', '', {inputmode: 'decimal', maxlength: '16', class: 'sig-input fp-bil-amount'});
      var note = B.input('fp-bcl-cr-note', 'note', '', {maxlength: '200'});
      var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bcl_credit_save')});
      var form = el('form', {class: 'fp-form fp-bcl-cr-form', novalidate: '', 'aria-labelledby': 'fp-bcl-credit-h'}, [M.errorLine(), M.statusLine(),
        el('div', {class: 'fp-bil-grid'}, [M.field('fp-bcl-cr-kind', t('bcl_credit_kind'), kind), M.field('fp-bcl-cr-amount', t('bcl_credit_amount'), amount, t('bil_amount_hint')),
          M.field('fp-bcl-cr-note', t('bcl_credit_note'), note, t('bcl_credit_note_hint'))]),
        el('div', {class: 'fp-actions'}, [save])]);
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!B.begin(form, save)) { return; }
        var c = B.parseAmount(amount.value, false);
        if (!c) { M.fieldError(form, amount, t('bil_amount_bad')); return; }
        if (!note.value.trim()) { M.fieldError(form, note, t('bcl_credit_note_needed')); return; }
        var mine = C;
        var cl = C.client;
        UI.setBusy(save, true);
        FP.call('post', 'billingCredit', {amount_cents: kind.value === 'remove' ? -c : c, note: note.value.trim()}, {id: String(cl.id)}).then(function (r) {
          if (C !== mine || C.client !== cl) { return; }
          cl.credit = cleanCredit(r);
          drawHeader();
          drawTab(null, function () {
            var f = C.page.querySelector('.fp-bcl-cr-form');
            M.say(f, t(kind.value === 'remove' ? 'bcl_credit_removed' : 'bcl_credit_added', {amount: B.money(c, 'USD')}));
            C.page.querySelector('#fp-bcl-cr-amount').focus();
          });
        }, function (err) {
          if (C !== mine || C.client !== cl) { return; }
          UI.setBusy(save, false);
          B.failed(form, err);
        });
      });
      var parts = [el('p', {class: 'fp-bil-balance', 'data-fp-balance': ''}, [el('span', {class: 'fp-muted', text: t('bcl_credit_balance') + ' '}),
        el('strong', {text: B.money(cr.balance_cents, cr.currency)})]), el('p', {class: 'fp-muted', text: t(closed ? 'bcl_credit_closed' : 'bcl_credit_what')}), form];
      var hist = [];
      if (!cr.entries.length) {
        hist.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('bcl_credit_none')}));
      } else {
        hist.push(B.table('fp-bcl-credit-hist-h', 'fp-bcl-cr-table', [B.th(t('bcl_col_date')), B.th(t('bcl_col_entry')), B.th(t('bcl_col_amount'), 'fp-bil-num'),
          B.th(t('bcl_col_invoice')), B.th(t('bcl_col_note')), B.th(t('bcl_col_by'))], cr.entries.map(function (e) {
          return el('tr', null, [el('td', {class: 'fp-bil-nowrap', text: B.when(e.created) || '—'}), el('td', {text: t('bcl_entry_' + e.kind) === 'bcl_entry_' + e.kind ? e.kind : t('bcl_entry_' + e.kind)}),
            el('td', {class: 'fp-bil-num', text: B.money(e.amount_cents, cr.currency)}), el('td', {text: e.invoice_id ? t('bcl_invoice_ref', {id: String(e.invoice_id)}) : '—'}),
            el('td', {class: 'fp-bil-wrap', text: e.note || '—'}), el('td', {text: e.by || '—'})]);
        })));
        if (cr.more) { hist.push(el('p', {class: 'fp-muted fp-row-note', text: t('bcl_credit_more', {n: B.num(cr.more)})})); }
      }
      return [M.card('fp-bcl-credit-h', t('bcl_tab_credit'), parts, 'fp-bcl-credit'), M.card('fp-bcl-credit-hist-h', t('bcl_credit_history'), hist, 'fp-bcl-credit-hist')];
    }
  };

  /* ---- services and the panel accounts behind them ---- */
  function serviceRow(x) {
    var acts = [];
    if (x.status === 'active') { acts.push(B.button('svc-suspend', t('bcl_svc_suspend'), 'sig-btn--secondary sig-btn--sm', {'data-fp-id': String(x.id), 'aria-label': t('bcl_svc_suspend_of', {name: x.plan_name})})); }
    if (x.status === 'suspended') { acts.push(B.button('svc-unsuspend', t('bcl_svc_unsuspend'), 'sig-btn--secondary sig-btn--sm', {'data-fp-id': String(x.id), 'aria-label': t('bcl_svc_unsuspend_of', {name: x.plan_name})})); }
    if (x.status === 'active' || x.status === 'suspended') { acts.push(B.button('svc-end', t('bcl_svc_end'), 'sig-btn--secondary sig-btn--sm fp-btn-danger-text', {'data-fp-id': String(x.id), 'aria-label': t('bcl_svc_end_of', {name: x.plan_name})})); }
    return el('tr', {'data-fp-service': String(x.id)}, [el('th', {scope: 'row', class: 'fp-bil-wrap', text: x.plan_name || '—'}), el('td', {text: B.termText(x.term)}),
      el('td', {class: 'fp-bil-num', text: B.money(x.renewal_cents, x.currency)}), el('td', {class: 'fp-bil-nowrap', text: B.day(x.next_due) || '—'}),
      el('td', {class: 'fp-bil-wrap', text: x.username || '—'}), el('td', null, [B.statePill('svc', x.status)]),
      el('td', {class: 'fp-bil-acts'}, acts.length ? [el('div', {class: 'fp-bil-row-acts'}, acts)] : [])]);
  }
  function accountRow(a) {
    return el('tr', {'data-fp-account': a.username}, [el('th', {scope: 'row', text: a.username}), el('td', {class: 'fp-bil-wrap', text: a.domain || '—'}), el('td', {text: a.package || '—'}),
      el('td', {text: a.status ? B.word('acct', a.status) : '—'}),
      el('td', {class: 'fp-bil-acts'}, [el('div', {class: 'fp-bil-row-acts'}, [B.button('acct-unlink', t('bcl_acct_unlink'), 'sig-btn--secondary sig-btn--sm fp-btn-danger-text', {'data-fp-name': a.username, 'aria-label': t('bcl_acct_unlink_of', {name: a.username})})])])]);
  }
  function linkCard() {
    var name = B.input('fp-bcl-ln-user', 'username', '', {maxlength: '32', spellcheck: 'false', autocapitalize: 'none', 'aria-required': 'true'});
    var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bcl_acct_link')});
    var form = el('form', {class: 'fp-form fp-bcl-ln-form', novalidate: '', 'aria-labelledby': 'fp-bcl-ln-h'}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-bil-grid'}, [M.field('fp-bcl-ln-user', t('bcl_acct_user'), name, t('bcl_acct_user_hint'))]), el('div', {class: 'fp-actions'}, [save])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!B.begin(form, save)) { return; }
      var u = name.value.trim();
      if (!u) { M.fieldError(form, name, t('bcl_acct_user_needed')); return; }
      var mine = C;
      var cl = C.client;
      UI.setBusy(save, true);
      FP.call('post', 'billingAccounts', {username: u}, {id: String(cl.id)}).then(function () {
        if (C !== mine || C.client !== cl) { return; }
        drawTab(null, function () { M.say(C.page.querySelector('.fp-bcl-accounts'), t('bcl_acct_linked', {name: u})); C.page.querySelector('#fp-bcl-accounts-h').focus(); });
      }, function (err) {
        if (C !== mine || C.client !== cl) { return; }
        UI.setBusy(save, false);
        B.failed(form, err);
      });
    });
    return M.card('fp-bcl-ln-h', t('bcl_acct_link_title'), [el('p', {class: 'fp-muted', text: t('bcl_acct_link_what')}), form], 'fp-bcl-ln-card');
  }
  function methodRow(m) {
    var acts = [];
    if (m.status === 'active' && !m.default) { acts.push(B.button('pm-default', t('bcl_pm_default'), 'sig-btn--secondary sig-btn--sm', {'data-fp-id': String(m.id), 'aria-label': t('bcl_pm_default_of', {name: m.label || t('bcl_pm_no_label')})})); }
    if (m.status !== 'removed') { acts.push(B.button('pm-remove', t('bil_remove'), 'sig-btn--secondary sig-btn--sm fp-btn-danger-text', {'data-fp-id': String(m.id), 'aria-label': t('bcl_pm_remove_of', {name: m.label || t('bcl_pm_no_label')})})); }
    return el('tr', {'data-fp-method': String(m.id)}, [el('th', {scope: 'row', class: 'fp-bil-wrap', text: m.label || t('bcl_pm_no_label')}), el('td', {text: B.gatewayText(m.gateway)}),
      el('td', {class: 'fp-bil-nowrap', text: B.day(m.expires_on) || '—'}), el('td', null, [B.statePill('pm', m.status)]), el('td', {text: t(m.default ? 'bil_yes' : 'bil_no')}),
      el('td', {class: 'fp-bil-acts'}, acts.length ? [el('div', {class: 'fp-bil-row-acts'}, acts)] : [])]);
  }
  /* a page address the client is given (a gateway's own page); only one of this panel or an https one is shown as a link */
  function pageLink(url) {
    var safe = /^\/[^/\\]/.test(url) || /^https:\/\/[^\s]+$/.test(url);
    return el('div', {class: 'fp-bil-handoff', 'data-fp-handoff': ''}, [el('p', {text: t('bcl_pm_give')}),
      el('p', {class: 'fp-bil-url'}, [safe ? el('a', {href: url, target: '_blank', rel: 'noopener noreferrer', text: url}) : el('code', {text: url})])]);
  }
  function ticketTable(hid, list, departments) {
    var open = Boolean(FP.tools.billing_tickets);
    var dept = function (did) { for (var i = 0; i < departments.length; i++) { if (departments[i].id === did) { return departments[i].name; } } return '—'; };
    return B.table(hid, 'fp-bcl-tk-table', [B.th(t('bcl_col_subject')), B.th(t('bcl_col_department')), B.th(t('bcl_col_status')), B.th(t('bcl_col_priority')), B.th(t('bcl_col_last_reply'))],
      list.map(function (k) {
        return el('tr', {'data-fp-ticket': String(k.id)}, [el('th', {scope: 'row', class: 'fp-bil-name'}, [open ? B.button('open-ticket', k.subject || '—', 'sig-btn--link fp-bil-link', {'data-fp-id': String(k.id), 'aria-label': t('bcl_open_ticket_of', {name: k.subject})}) : k.subject || '—']),
          el('td', {text: dept(k.department_id)}), el('td', null, [B.statePill('ticket', k.status)]), el('td', {text: k.priority ? B.word('prio', k.priority) : '—'}),
          el('td', {class: 'fp-bil-nowrap', text: k.last_reply ? t('bcl_last_reply', {who: k.last_reply_by || '—', when: B.when(k.last_reply)}) : '—'})]);
      }));
  }
  /* the tabs after Contacts, drawn from what loads() read */
  var MORE = {
    services: function (r) {
      var svc = r[0];
      var acc = r[1];
      C.client.services = svc.items;
      C.client.accounts = acc.accounts;
      var parts = [M.errorLine(), M.statusLine()];
      if (!svc.items.length) {
        parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('bcl_no_services')}));
      } else {
        parts.push(B.table('fp-bcl-services-h', 'fp-bcl-svc-table', [B.th(t('bcl_col_plan')), B.th(t('bcl_col_term')), B.th(t('bcl_col_renewal'), 'fp-bil-num'), B.th(t('bcl_col_next_due')),
          B.th(t('bcl_col_account')), B.th(t('bcl_col_status')), actsHead()], svc.items.map(serviceRow)));
        if (svc.total > svc.items.length) { parts.push(el('p', {class: 'fp-muted fp-row-note', text: t('bcl_newest', {n: B.num(svc.items.length), total: B.num(svc.total)})})); }
      }
      parts.push(el('p', {class: 'fp-muted fp-row-note', text: t('bcl_svc_what')}));
      var accParts = [M.errorLine(), M.statusLine()];
      accParts.push(acc.accounts.length ? B.table('fp-bcl-accounts-h', 'fp-bcl-acct-table', [B.th(t('bcl_col_username')), B.th(t('bcl_col_domain')), B.th(t('bcl_col_package')),
        B.th(t('bcl_col_status')), actsHead()], acc.accounts.map(accountRow)) : el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('bcl_no_accounts')}));
      var out = [M.card('fp-bcl-services-h', t('bcl_tab_services'), parts, 'fp-bcl-services'), M.card('fp-bcl-accounts-h', t('bcl_accounts'), accParts, 'fp-bcl-accounts')];
      if (C.client.c.status === 'closed') {
        out.push(el('p', {class: 'fp-muted', text: t('bcl_acct_closed')}));
      } else if (acc.accounts.length < acc.max) {
        out.push(linkCard());
      }
      return out;
    },
    domains: function (r) {
      var parts = [];
      if (!r.items.length) {
        parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('bcl_no_domains')}));
      } else {
        parts.push(B.table('fp-bcl-domains-h', 'fp-bcl-dom-table', [B.th(t('bcl_col_domain')), B.th(t('bcl_col_status')), B.th(t('bcl_col_expires')), B.th(t('bcl_col_auto_renew')),
          B.th(t('bcl_col_registrar'))], r.items.map(function (d) {
          return el('tr', {'data-fp-domain': String(d.id)}, [el('th', {scope: 'row', class: 'fp-bil-wrap', text: d.name}), el('td', null, [B.statePill('domain', d.status)]),
            el('td', {class: 'fp-bil-nowrap', text: B.day(d.expires_on) || '—'}), el('td', {text: t(d.auto_renew ? 'bil_yes' : 'bil_no')}), el('td', {text: d.registrar ? B.word('registrar', d.registrar) : '—'})]);
        })));
        if (r.total > r.items.length) { parts.push(el('p', {class: 'fp-muted fp-row-note', text: t('bcl_newest', {n: B.num(r.items.length), total: B.num(r.total)})})); }
      }
      return [M.card('fp-bcl-domains-h', t('bcl_tab_domains'), parts, 'fp-bcl-domains')];
    },
    quotes: function (r) {
      var open = Boolean(FP.tools.billing_quotes);
      var parts = [];
      if (open && C.client.c.status === 'active') { parts.push(el('div', {class: 'fp-bil-toolbar'}, [B.button('create-quote', t('bcl_create_quote'), 'sig-btn--primary sig-btn--sm')])); }
      if (!r.items.length) {
        parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('bcl_no_quotes')}));
      } else {
        parts.push(B.table('fp-bcl-quotes-h', 'fp-bcl-q-table', [B.th(t('bcl_col_number')), B.th(t('bcl_col_subject')), B.th(t('bcl_col_total'), 'fp-bil-num'), B.th(t('bcl_col_valid')),
          B.th(t('bcl_col_status'))], r.items.map(function (q) {
          var name = quoteName(q);
          return el('tr', {'data-fp-quote': String(q.id)}, [el('th', {scope: 'row', class: 'fp-bil-name'}, [open ? B.button('open-quote', name, 'sig-btn--link fp-bil-link', {'data-fp-id': String(q.id), 'aria-label': t('bcl_open_quote_of', {name: name})}) : name]),
            el('td', {class: 'fp-bil-wrap', text: q.subject || '—'}), el('td', {class: 'fp-bil-num', text: B.money(q.total_cents, q.currency)}), el('td', {class: 'fp-bil-nowrap', text: B.day(q.valid_until) || '—'}),
            el('td', null, [B.statePill('quote', q.status)])]);
        })));
        if (r.total > r.items.length) { parts.push(el('p', {class: 'fp-muted fp-row-note', text: t('bcl_newest', {n: B.num(r.items.length), total: B.num(r.total)})})); }
      }
      return [M.card('fp-bcl-quotes-h', t('bcl_tab_quotes'), parts, 'fp-bcl-quotes')];
    },
    transactions: function (r) {
      var open = Boolean(FP.tools.billing_invoices);
      var parts = [];
      if (!r.items.length) {
        parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('bcl_no_transactions')}));
      } else {
        parts.push(B.table('fp-bcl-transactions-h', 'fp-bcl-tx-table', [B.th(t('bcl_col_date')), B.th(t('bcl_col_invoice')), B.th(t('bcl_col_kind')), B.th(t('bcl_col_gateway')),
          B.th(t('bcl_col_method')), B.th(t('bcl_col_amount'), 'fp-bil-num'), B.th(t('bcl_col_status')), B.th(t('bcl_col_reference'))], r.items.map(function (x) {
          var inv = x.invoice_id ? t('bcl_invoice_ref', {id: String(x.invoice_id)}) : '—';
          return el('tr', {'data-fp-tx': String(x.id)}, [el('td', {class: 'fp-bil-nowrap', text: B.when(x.created) || '—'}),
            el('td', null, [x.invoice_id && open ? B.button('open-invoice', inv, 'sig-btn--link fp-bil-link', {'data-fp-id': String(x.invoice_id), 'aria-label': t('bcl_open_invoice_id', {id: String(x.invoice_id)})}) : inv]),
            el('td', {text: t('binv_tx_' + x.kind)}), el('td', {text: B.gatewayText(x.gateway)}), el('td', {text: B.methodText(x.method)}),
            el('td', {class: 'fp-bil-num', text: (x.kind === 'refund' ? '−' : '') + B.money(x.amount_cents, x.currency)}), el('td', null, [B.statePill('tx', x.status)]),
            el('td', {class: 'fp-bil-wrap', text: x.reference || '—'})]);
        })));
        if (r.total > r.items.length) { parts.push(el('p', {class: 'fp-muted fp-row-note', text: t('bcl_newest', {n: B.num(r.items.length), total: B.num(r.total)})})); }
      }
      return [M.card('fp-bcl-transactions-h', t('bcl_tab_transactions'), parts, 'fp-bcl-transactions')];
    },
    tickets: function (r) {
      var parts = [M.statusLine()];
      parts.push(r.tickets.length ? ticketTable('fp-bcl-tickets-h', r.tickets, r.departments) : el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('bcl_no_tickets')}));
      if (r.total > r.tickets.length) { parts.push(el('p', {class: 'fp-muted fp-row-note', text: t('bcl_newest', {n: B.num(r.tickets.length), total: B.num(r.total)})})); }
      C.client.departments = r.departments;
      var out = [M.card('fp-bcl-tickets-h', t('bcl_tab_tickets'), parts, 'fp-bcl-tickets')];
      out.push(C.client.c.status === 'closed' ? el('p', {class: 'fp-muted', text: t('bcl_tk_closed')}) : r.departments.length ? ticketCard(r.departments) :
        el('p', {class: 'fp-muted', 'data-fp-no-department': '', text: t('bcl_tk_no_department')}));
      return out;
    },
    methods: function (r) {
      var ms = r[0];
      var gws = r[1];
      C.client.methods = ms.methods;
      var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted fp-row-note', text: t('bcl_pm_what')})];
      parts.push(ms.methods.length ? B.table('fp-bcl-methods-h', 'fp-bcl-pm-table', [B.th(t('bcl_col_method_label')), B.th(t('bcl_col_gateway')), B.th(t('bcl_col_expires')),
        B.th(t('bcl_col_status')), B.th(t('bcl_col_default')), actsHead()], ms.methods.map(methodRow)) : el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('bcl_no_methods')}));
      var out = [M.card('fp-bcl-methods-h', t('bcl_tab_methods'), parts, 'fp-bcl-methods')];
      var on = (gws || []).filter(function (g) { return g.enabled; });
      var active = ms.methods.filter(function (m) { return m.status === 'active'; }).length;
      if (C.client.c.status !== 'active') {
        out.push(el('p', {class: 'fp-muted', text: t('bcl_pm_not_active')}));
      } else if (gws === null) {
        out.push(el('p', {class: 'fp-muted', text: t('bcl_pm_gw_unread')}));
      } else if (!on.length) {
        out.push(el('p', {class: 'fp-muted', 'data-fp-no-gateway': '', text: t('bcl_pm_no_gateway')}));
      } else if (active >= ms.max) {
        out.push(el('p', {class: 'fp-muted', text: t('bcl_pm_full', {n: B.num(ms.max)})}));
      } else {
        out.push(methodCard(on));
      }
      return out;
    },
    referral: function (r) {
      var ref = r[0];
      var aff = r[1];
      C.client.referral = ref;
      var code = B.input('fp-bcl-rf-code', 'code', ref.code, {maxlength: '32', spellcheck: 'false', autocapitalize: 'none'});
      var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bcl_rf_save')});
      var form = el('form', {class: 'fp-form fp-bcl-rf-form', novalidate: '', 'aria-labelledby': 'fp-bcl-referral-h'}, [M.errorLine(), M.statusLine(),
        el('p', {'data-fp-referral': '', text: ref.code ? t('bcl_rf_now', {code: ref.code, since: B.day(ref.since) || '—'}) : t('bcl_rf_none')}),
        el('div', {class: 'fp-bil-grid'}, [M.field('fp-bcl-rf-code', t('bcl_rf_code'), code, t('bcl_rf_code_hint'))]),
        el('div', {class: 'fp-actions', 'data-fp-acts': ''}, [save, ref.code ? B.button('rf-clear', t('bcl_rf_clear'), 'sig-btn--secondary fp-btn-danger-text') : null])]);
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!B.begin(form, save)) { return; }
        var v = code.value.trim();
        if (!v) { M.fieldError(form, code, t('bcl_rf_code_needed')); return; }
        if (v.toLowerCase() === (ref.code || '').toLowerCase()) { M.say(form, t('bil_nothing_changed')); return; }
        saveReferral(form, save, v);
      });
      var out = [M.card('fp-bcl-referral-h', t('bcl_rf_title'), [el('p', {class: 'fp-muted', text: t('bcl_rf_what')}), form], 'fp-bcl-referral')];
      var affParts = [M.errorLine(), M.statusLine()];
      if (aff === null) {
        affParts.push(el('p', {class: 'fp-muted', text: t('bcl_aff_unread')}));
      } else if (aff) {
        affParts.push(B.facts([[t('bcl_aff_code'), aff.code], [t('bcl_col_status'), B.word('aff', aff.status)], [t('bcl_aff_rate'), aff.rate_bp === null ? t('bcl_aff_rate_scheme') : rate(aff.rate_bp)],
          [t('bcl_aff_referred'), aff.referred === null ? '—' : B.num(aff.referred)]]));
        if (FP.tools.billing_affiliates) { affParts.push(el('div', {class: 'fp-actions'}, [B.button('open-affiliate', t('bcl_aff_open'), 'sig-btn--secondary sig-btn--sm', {'data-fp-id': String(aff.id)})])); }
      } else {
        affParts.push(el('p', {class: 'fp-muted', 'data-fp-not-affiliate': '', text: t('bcl_aff_not')}));
        if (C.client.c.status === 'active') { affParts.push(el('div', {class: 'fp-actions'}, [B.button('make-affiliate', t('bcl_aff_make'), 'sig-btn--secondary sig-btn--sm')])); }
      }
      out.push(M.card('fp-bcl-aff-h', t('bcl_aff_title'), affParts, 'fp-bcl-aff'));
      return out;
    }
  };
  Object.keys(MORE).forEach(function (k) { PANELS[k] = MORE[k]; });
  /* hundredths of a percent as a percent: 1000 is 10%, 1250 is 12.5% */
  function rate(bp) { var whole = Math.floor(bp / 100); var frac = String(bp % 100); return whole + (bp % 100 ? '.' + (frac.length < 2 ? '0' + frac : frac).replace(/0$/, '') : '') + '%'; }
  function saveReferral(form, b, code) {
    var mine = C;
    var cl = C.client;
    UI.setBusy(b, true);
    FP.call('put', 'billingReferrer', {code: code}, {id: String(cl.id)}).then(function () {
      if (C !== mine || C.client !== cl) { return; }
      drawTab(null, function () {
        M.say(C.page.querySelector('.fp-bcl-rf-form'), code ? t('bcl_rf_saved', {code: code.toLowerCase()}) : t('bcl_rf_cleared'));
        C.page.querySelector(code ? '#fp-bcl-rf-code' : '#fp-bcl-referral-h').focus();
      });
    }, function (err) {
      if (C !== mine || C.client !== cl) { return; }
      UI.setBusy(b, false);
      B.failed(form, err);
      if (!code) { b.focus(); }
    });
  }
  function methodCard(gateways) {
    var gw = B.select('fp-bcl-pm-gw', 'gateway', gateways.map(function (g) { return [g.id, g.name || g.id]; }), gateways[0].id);
    var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bcl_pm_add')});
    var form = el('form', {class: 'fp-form fp-bcl-pm-form', novalidate: '', 'aria-labelledby': 'fp-bcl-pm-h'}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-bil-grid'}, [M.field('fp-bcl-pm-gw', t('bcl_pm_gateway'), gw)]), el('div', {class: 'fp-actions'}, [save]), el('div', {'data-fp-handoff-box': ''})]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!B.begin(form, save)) { return; }
      var mine = C;
      var cl = C.client;
      UI.setBusy(save, true);
      FP.call('post', 'billingMethods', {gateway: gw.value}, {id: String(cl.id)}).then(function (r) {
        if (C !== mine || C.client !== cl) { return; }
        var url = r && typeof r.redirect_url === 'string' ? r.redirect_url.slice(0, 500) : '';
        drawTab(null, function () {
          var f = C.page.querySelector('.fp-bcl-pm-form');
          var box = f ? f.querySelector('[data-fp-handoff-box]') : null;
          if (box && url) { box.appendChild(pageLink(url)); }
          M.say(f || C.page.querySelector('.fp-bcl-methods'), t('bcl_pm_started'));
          C.page.querySelector('#fp-bcl-methods-h').focus();
        });
      }, function (err) {
        if (C !== mine || C.client !== cl) { return; }
        UI.setBusy(save, false);
        B.failed(form, err);
      });
    });
    return M.card('fp-bcl-pm-h', t('bcl_pm_add_title'), [el('p', {class: 'fp-muted', text: t('bcl_pm_add_what')}), form], 'fp-bcl-pm-card');
  }
  /* Open ticket, on the client's behalf: the first message is the staff's, so the ticket starts answered */
  function ticketCard(departments) {
    var dept = B.select('fp-bcl-tk-dept', 'department_id', departments.map(function (d) { return [String(d.id), d.name + (d.hidden ? ' ' + t('bcl_tk_hidden_mark') : '')]; }), String(departments[0].id));
    var subject = B.input('fp-bcl-tk-subject', 'subject', '', {maxlength: '150', 'aria-required': 'true'});
    var prio = B.select('fp-bcl-tk-prio', 'priority', ['low', 'medium', 'high'].map(function (p) { return [p, B.word('prio', p)]; }), 'medium');
    var body = el('textarea', {class: 'sig-input fp-bil-text', id: 'fp-bcl-tk-body', name: 'body', rows: '5', maxlength: '20000', 'aria-required': 'true'});
    var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bcl_tk_open')});
    var form = el('form', {class: 'fp-form fp-bcl-tk-form', novalidate: '', 'aria-labelledby': 'fp-bcl-tk-h'}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-bil-grid'}, [M.field('fp-bcl-tk-dept', t('bcl_tk_dept'), dept), M.field('fp-bcl-tk-prio', t('bcl_tk_prio'), prio)]),
      M.field('fp-bcl-tk-subject', t('bcl_tk_subject'), subject), M.field('fp-bcl-tk-body', t('bcl_tk_body'), body, t('bcl_tk_body_hint')), el('div', {class: 'fp-actions'}, [save])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!B.begin(form, save)) { return; }
      if (!subject.value.trim()) { M.fieldError(form, subject, t('bcl_tk_subject_needed')); return; }
      if (!body.value.trim()) { M.fieldError(form, body, t('bcl_tk_body_needed')); return; }
      var mine = C;
      var cl = C.client;
      UI.setBusy(save, true);
      FP.call('post', 'billingTicketNew', {customer_id: cl.id, department_id: Number(dept.value), subject: subject.value.trim(), body: body.value, priority: prio.value}).then(function (r) {
        if (C !== mine || C.client !== cl) { return; }
        var k = cleanTicket(r);
        if (k && FP.tools.billing_tickets) { B.go('billing_tickets', {ticket: k.id, said: t('bcl_tk_opened', {name: k.subject})}); return; }
        drawTab(null, function () { M.say(C.page.querySelector('.fp-bcl-tickets'), t('bcl_tk_opened', {name: k ? k.subject : ''})); C.page.querySelector('#fp-bcl-tickets-h').focus(); });
      }, function (err) {
        if (C !== mine || C.client !== cl) { return; }
        UI.setBusy(save, false);
        B.failed(form, err);
      });
    });
    return M.card('fp-bcl-tk-h', t('bcl_tk_title'), [el('p', {class: 'fp-muted', text: t('bcl_tk_what')}), form], 'fp-bcl-tk-card');
  }
  function findIn(list, key, v) { for (var i = 0; i < (list || []).length; i++) { if (list[i][key] === v) { return list[i]; } } return null; }
  /* a row's action after its question: the button busy, the answer said on the card, focus on its heading */
  function rowCall(b, cardSel, headSel, call, said) {
    var mine = C;
    var cl = C.client;
    var box = C.page.querySelector(cardSel);
    UI.setBusy(b, true);
    UI.showError(box, '');
    call.then(function () {
      if (C !== mine || C.client !== cl) { return; }
      drawTab(null, function () { M.say(C.page.querySelector(cardSel), said); C.page.querySelector(headSel).focus(); });
    }, function (err) {
      if (C !== mine || C.client !== cl) { return; }
      UI.setBusy(b, false);
      UI.showError(box, err.message);
      b.focus();
    });
  }
  function ask(b, question, act, yes, attr, value) {
    var cell = b.closest('.fp-bil-row-acts') || b.closest('[data-fp-acts]');
    M.confirmIn(cell, question, act, yes);
    cell.querySelector('[data-fp-act="' + act + '"]').setAttribute(attr, value);
  }

  /* ---- contacts ---- */
  function contactRow(x) {
    var kinds = x.roles.map(function (r) { return t('bcl_role_' + r) === 'bcl_role_' + r ? r : t('bcl_role_' + r); }).join(', ');
    var closed = C.client.c.status === 'closed';
    return el('tr', {'data-fp-contact': String(x.id)}, [el('th', {scope: 'row', class: 'fp-bil-wrap', text: x.name}), el('td', {class: 'fp-bil-wrap', text: x.email}),
      el('td', {text: kinds || t('bcl_kind_none')}), el('td', {text: t(x.roles.indexOf('billing') >= 0 ? 'bil_yes' : 'bil_no')}),
      el('td', {class: 'fp-bil-acts'}, closed ? [] : [el('div', {class: 'fp-bil-row-acts'}, [
        B.button('contact-edit', t('bil_change'), 'sig-btn--secondary sig-btn--sm', {'data-fp-id': String(x.id), 'aria-label': t('bcl_contact_change_of', {name: x.name})}),
        B.button('contact-remove', t('bil_remove'), 'sig-btn--secondary sig-btn--sm fp-btn-danger-text', {'data-fp-id': String(x.id), 'aria-label': t('bcl_contact_remove_of', {name: x.name})})])])]);
  }
  function contactCard(x) {
    var v = x || {name: '', email: '', phone: '', roles: []};
    var pre = 'fp-bcl-ct';
    var boxes = C.client.roles.map(function (r) {
      return el('label', {class: 'fp-bil-check', for: pre + '-r-' + r}, [el('input', {type: 'checkbox', id: pre + '-r-' + r, name: 'roles', value: r, checked: v.roles.indexOf(r) >= 0 ? true : null}),
        el('span', {text: t('bcl_role_' + r) === 'bcl_role_' + r ? r : t('bcl_role_' + r)})]);
    });
    var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t(x ? 'bil_save_changes' : 'bcl_contact_add')});
    var form = el('form', {class: 'fp-form fp-bcl-ct-form', novalidate: '', 'aria-labelledby': 'fp-bcl-ct-h', 'data-fp-contact-form': x ? String(x.id) : ''}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-bil-grid'}, [M.field(pre + '-name', t('bcl_name'), B.input(pre + '-name', 'name', v.name, {maxlength: '100', 'aria-required': 'true'})),
        M.field(pre + '-email', t('bcl_email'), B.input(pre + '-email', 'email', v.email, {type: 'email', maxlength: '254', spellcheck: 'false', autocapitalize: 'none', 'aria-required': 'true'})),
        M.field(pre + '-phone', t('bcl_phone'), B.input(pre + '-phone', 'phone', v.phone, {type: 'tel', maxlength: '30'}))]),
      el('fieldset', {class: 'fp-bil-set', 'data-fp-roles': ''}, [el('legend', {class: 'sig-label', text: t('bcl_contact_roles')}), el('div', {class: 'fp-bil-checks'}, boxes),
        el('span', {class: 'sig-hint', text: t('bcl_contact_roles_hint')})]),
      el('div', {class: 'fp-actions'}, [save, x ? B.button('contact-cancel', t('cancel')) : null])]);
    /* a refused role list is about the boxes: the error goes to the first one */
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!B.begin(form, save)) { return; }
      var get = function (n) { return form.querySelector('[name="' + n + '"]'); };
      var name = get('name');
      var email = get('email');
      if (!name.value.trim()) { M.fieldError(form, name, t('bcl_name_needed')); return; }
      if (!/^[^\s@]+@[^\s@]+$/.test(email.value.trim())) { M.fieldError(form, email, t('bcl_email_needed')); return; }
      var roles = Array.prototype.filter.call(form.querySelectorAll('[name="roles"]'), function (b) { return b.checked; }).map(function (b) { return b.value; });
      var body = {name: name.value.trim(), email: email.value.trim(), phone: get('phone').value.trim(), roles: roles};
      if (x) {
        Object.keys(body).forEach(function (k) { if (JSON.stringify(body[k]) === JSON.stringify(x[k])) { delete body[k]; } });
        if (!Object.keys(body).length) { M.say(form, t('bil_nothing_changed')); return; }
      } else if (!body.phone) {
        delete body.phone;
      }
      var mine = C;
      var cl = C.client;
      UI.setBusy(save, true);
      var call = x ? FP.call('patch', 'billingContact', body, {id: String(cl.id), contact: String(x.id)}) : FP.call('post', 'billingContacts', body, {id: String(cl.id)});
      call.then(function (r) {
        if (C !== mine || C.client !== cl) { return; }
        var made = r && B.id(r.id) ? r.id : x ? x.id : null;
        drawTab(null, function () {
          var list = C.page.querySelector('.fp-bcl-contacts');
          M.say(list, t(x ? 'bcl_contact_saved' : 'bcl_contact_added', {name: body.name || x.name}));
          var b = made ? C.page.querySelector(idSel('contact-edit', made)) : null;
          (b || C.page.querySelector('#fp-bcl-contacts-h')).focus();
        });
      }, function (err) {
        if (C !== mine || C.client !== cl) { return; }
        UI.setBusy(save, false);
        if (err && err.field === 'roles') {
          // The roles are boxes, not one control: the message goes at the
          // form's foot and the first box is marked.
          var first = form.querySelector('[name="roles"]');
          B.failed(form, Object.assign({}, err, {field: ''}));
          if (first) { first.setAttribute('aria-invalid', 'true'); first.focus(); }
          return;
        }
        B.failed(form, err);
      });
    });
    return M.card('fp-bcl-ct-h', t(x ? 'bcl_contact_change_title' : 'bcl_contact_add_title', {name: x ? x.name : ''}), [form], 'fp-bcl-ct-card');
  }
  function contactById(xid) {
    var list = C.client.contacts || [];
    for (var i = 0; i < list.length; i++) { if (list[i].id === xid) { return list[i]; } }
    return null;
  }

  /* ---- notes ---- */
  function noteCard() {
    var body = el('textarea', {class: 'sig-input fp-bil-text', id: 'fp-bcl-nt-body', name: 'body', rows: '4', maxlength: '2000'});
    var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bcl_note_add')});
    var form = el('form', {class: 'fp-form fp-bcl-nt-form', novalidate: '', 'aria-labelledby': 'fp-bcl-nt-h'}, [M.errorLine(), M.statusLine(),
      M.field('fp-bcl-nt-body', t('bcl_note_text'), body, t('bcl_note_hint')), el('div', {class: 'fp-actions'}, [save])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!B.begin(form, save)) { return; }
      if (!body.value.trim()) { M.fieldError(form, body, t('bcl_note_needed')); return; }
      var mine = C;
      var cl = C.client;
      UI.setBusy(save, true);
      FP.call('post', 'billingNotes', {body: body.value}, {id: String(cl.id)}).then(function () {
        if (C !== mine || C.client !== cl) { return; }
        drawTab(null, function () {
          M.say(C.page.querySelector('.fp-bcl-nt-form'), t('bcl_note_added'));
          C.page.querySelector('#fp-bcl-nt-body').focus();
        });
      }, function (err) {
        if (C !== mine || C.client !== cl) { return; }
        UI.setBusy(save, false);
        B.failed(form, err);
      });
    });
    return M.card('fp-bcl-nt-h', t('bcl_note_add_title'), [el('p', {class: 'fp-muted', text: t('bcl_note_what')}), form], 'fp-bcl-nt-card');
  }
  function noteEdit(li, nid) {
    var old = li.querySelector('.fp-bil-note-body').textContent;
    var fid = 'fp-bcl-ne-' + nid;
    var body = el('textarea', {class: 'sig-input fp-bil-text', id: fid, name: 'body', rows: '4', maxlength: '2000'});
    body.value = old;
    var save = el('button', {class: 'sig-btn sig-btn--primary sig-btn--sm fp-submit', type: 'submit', text: t('bil_save_changes')});
    var form = el('form', {class: 'fp-form fp-bil-note-form', novalidate: ''}, [M.errorLine(), M.field(fid, t('bcl_note_text'), body),
      el('div', {class: 'fp-actions'}, [save, B.button('note-edit-cancel', t('cancel'), 'sig-btn--secondary sig-btn--sm', {'data-fp-id': String(nid)})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!B.begin(form, save)) { return; }
      if (!body.value.trim()) { M.fieldError(form, body, t('bcl_note_needed')); return; }
      var mine = C;
      var cl = C.client;
      UI.setBusy(save, true);
      FP.call('patch', 'billingNote', {body: body.value}, {id: String(cl.id), note: String(nid)}).then(function () {
        if (C !== mine || C.client !== cl) { return; }
        drawTab(null, function () {
          M.say(C.page.querySelector('.fp-bcl-notes'), t('bcl_note_saved'));
          var b = C.page.querySelector(idSel('note-edit', nid));
          (b || C.page.querySelector('#fp-bcl-notes-h')).focus();
        });
      }, function (err) {
        if (C !== mine || C.client !== cl) { return; }
        UI.setBusy(save, false);
        B.failed(form, err);
      });
    });
    var acts = li.querySelector('.fp-bil-row-acts');
    li.querySelector('.fp-bil-note-body').hidden = true;
    if (acts) { acts.hidden = true; }
    li.appendChild(form);
    body.focus();
  }

  /* ---- removing (a contact, a note), after a question in place of the row's buttons ---- */
  function remove(kind, xid, b) {
    var mine = C;
    var cl = C.client;
    var card = C.page.querySelector(kind === 'contact' ? '.fp-bcl-contacts' : '.fp-bcl-notes');
    UI.setBusy(b, true);
    UI.showError(card, '');
    var call = kind === 'contact' ? FP.call('del', 'billingContact', undefined, {id: String(cl.id), contact: String(xid)}) : FP.call('del', 'billingNote', undefined, {id: String(cl.id), note: String(xid)});
    call.then(function () {
      if (C !== mine || C.client !== cl) { return; }
      drawTab(null, function () {
        M.say(C.page.querySelector(kind === 'contact' ? '.fp-bcl-contacts' : '.fp-bcl-notes'), t(kind === 'contact' ? 'bcl_contact_removed' : 'bcl_note_removed'));
        C.page.querySelector(kind === 'contact' ? '#fp-bcl-contacts-h' : '#fp-bcl-notes-h').focus();
      });
    }, function (err) {
      if (C !== mine || C.client !== cl) { return; }
      UI.setBusy(b, false);
      UI.showError(card, err.message);
      b.focus();
    });
  }

  function onClick(e) {
    var target = e.target && e.target.closest ? e.target : null;
    if (!target || !C || !C.page.isConnected || !C.page.contains(target)) { return; }
    var b = target.closest('[data-fp-act]');
    if (!b || b.disabled) { return; }
    var a = b.getAttribute('data-fp-act');
    var xid = Number(b.getAttribute('data-fp-id')) || 0;
    if (a === 'add') {
      showAdd();
    } else if (a === 'add-cancel' || a === 'to-list') {
      var from = C.client ? C.client.id : 0;
      showList(from ? idSel('open', from) : '#fp-bcl-list-h');
    } else if (a === 'clear') {
      C.filters = {q: '', status: '', group: ''};
      C.offset = 0;
      var form = C.page.querySelector('.fp-bil-filters');
      form.querySelector('[name="q"]').value = '';
      form.querySelector('[name="status"]').value = '';
      form.querySelector('[name="group"]').value = '';
      refreshList(null, '#fp-bcl-q');
    } else if (a === 'prev' || a === 'next') {
      C.offset = Math.max(0, C.offset + (a === 'next' ? PAGE : -PAGE));
      refreshList(b, '#fp-bcl-list-h');
    } else if (a === 'reload') {
      showList();
    } else if (a === 'open' && xid) {
      openClient(xid);
    } else if (a === 'tab') {
      selectTab(b.getAttribute('data-fp-tab'), false);
    } else if (a === 'tab-again') {
      drawTab();
    } else if (a === 'create-invoice') {
      B.go('billing_invoices', {create: C.client.id});
    } else if (a === 'open-invoice' && xid) {
      B.go('billing_invoices', {invoice: xid});
    } else if (a === 'add-order') {
      B.go('billing_order_new', {client: C.client.id});
    } else if (a === 'new-ticket') {
      selectTab('tickets', false, function () { var f = C.page.querySelector('#fp-bcl-tk-subject'); if (f) { f.focus(); } });
    } else if (a === 'add-credit') {
      selectTab('credit', false, function () { var f = C.page.querySelector('#fp-bcl-cr-amount'); if (f) { f.focus(); } });
    } else if (a === 'contact-edit') {
      var x = contactById(xid);
      if (!x) { return; }
      var old = C.page.querySelector('.fp-bcl-ct-card');
      var made = contactCard(x);
      if (old) { old.replaceWith(made); } else { C.page.querySelector('#fp-bcl-panel').appendChild(made); }
      made.querySelector('#fp-bcl-ct-name').focus();
    } else if (a === 'contact-cancel') {
      var editing = Number(C.page.querySelector('[data-fp-contact-form]').getAttribute('data-fp-contact-form'));
      C.page.querySelector('.fp-bcl-ct-card').replaceWith(contactCard(null));
      var back = C.page.querySelector(idSel('contact-edit', editing));
      (back || C.page.querySelector('#fp-bcl-ct-name')).focus();
    } else if (a === 'contact-remove') {
      var who = contactById(xid);
      var acts = b.closest('.fp-bil-row-acts');
      M.confirmIn(acts, t('bcl_contact_remove_ask', {name: who ? who.name : ''}), 'contact-remove-yes', t('bcl_contact_remove_yes'));
      acts.querySelector('[data-fp-act="contact-remove-yes"]').setAttribute('data-fp-id', String(xid));
    } else if (a === 'contact-remove-yes') {
      remove('contact', xid, b);
    } else if (a === 'note-edit') {
      noteEdit(b.closest('li'), xid);
    } else if (a === 'note-edit-cancel') {
      var li = b.closest('li');
      li.querySelector('form').remove();
      li.querySelector('.fp-bil-note-body').hidden = false;
      li.querySelector('.fp-bil-row-acts').hidden = false;
      li.querySelector('[data-fp-act="note-edit"]').focus();
    } else if (a === 'note-remove') {
      var cell = b.closest('.fp-bil-row-acts');
      M.confirmIn(cell, t('bcl_note_remove_ask'), 'note-remove-yes', t('bcl_note_remove_yes'));
      cell.querySelector('[data-fp-act="note-remove-yes"]').setAttribute('data-fp-id', String(xid));
    } else if (a === 'note-remove-yes') {
      remove('note', xid, b);
    } else if (a === 'svc-suspend') {
      var sv = findIn(C.client.services, 'id', xid);
      ask(b, t('bcl_svc_suspend_ask', {name: sv ? sv.plan_name : ''}), 'svc-suspend-yes', t('bcl_svc_suspend'), 'data-fp-id', String(xid));
    } else if (a === 'svc-suspend-yes') {
      rowCall(b, '.fp-bcl-services', '#fp-bcl-services-h', FP.call('post', 'billingServiceSuspend', {}, {id: String(xid)}), t('bcl_svc_suspended'));
    } else if (a === 'svc-unsuspend') {
      rowCall(b, '.fp-bcl-services', '#fp-bcl-services-h', FP.call('post', 'billingServiceUnsuspend', {}, {id: String(xid)}), t('bcl_svc_unsuspended'));
    } else if (a === 'svc-end') {
      var se = findIn(C.client.services, 'id', xid);
      ask(b, t('bcl_svc_end_ask', {name: se ? se.plan_name : ''}), 'svc-end-yes', t('bcl_svc_end_yes'), 'data-fp-id', String(xid));
    } else if (a === 'svc-end-yes') {
      rowCall(b, '.fp-bcl-services', '#fp-bcl-services-h', FP.call('post', 'billingServiceTerminate', {confirm: true}, {id: String(xid)}), t('bcl_svc_ended'));
    } else if (a === 'acct-unlink') {
      var un = b.getAttribute('data-fp-name');
      ask(b, t('bcl_acct_unlink_ask', {name: un}), 'acct-unlink-yes', t('bcl_acct_unlink'), 'data-fp-name', un);
    } else if (a === 'acct-unlink-yes') {
      var uname = b.getAttribute('data-fp-name');
      rowCall(b, '.fp-bcl-accounts', '#fp-bcl-accounts-h', FP.call('del', 'billingAccount', undefined, {id: String(C.client.id), username: uname}), t('bcl_acct_unlinked', {name: uname}));
    } else if (a === 'pm-default') {
      rowCall(b, '.fp-bcl-methods', '#fp-bcl-methods-h', FP.call('post', 'billingMethodDefault', {}, {id: String(C.client.id), method: String(xid)}), t('bcl_pm_defaulted'));
    } else if (a === 'pm-remove') {
      var pm = findIn(C.client.methods, 'id', xid);
      ask(b, t('bcl_pm_remove_ask', {name: pm ? pm.label || t('bcl_pm_no_label') : ''}), 'pm-remove-yes', t('bcl_pm_remove_yes'), 'data-fp-id', String(xid));
    } else if (a === 'pm-remove-yes') {
      rowCall(b, '.fp-bcl-methods', '#fp-bcl-methods-h', FP.call('del', 'billingMethod', undefined, {id: String(C.client.id), method: String(xid)}), t('bcl_pm_removed'));
    } else if (a === 'rf-clear') {
      M.confirmIn(b.closest('[data-fp-acts]'), t('bcl_rf_clear_ask'), 'rf-clear-yes', t('bcl_rf_clear'));
    } else if (a === 'rf-clear-yes') {
      saveReferral(C.page.querySelector('.fp-bcl-rf-form'), b, '');
    } else if (a === 'make-affiliate') {
      rowCall(b, '.fp-bcl-aff', '#fp-bcl-aff-h', FP.call('post', 'billingAffiliates', {customer_id: C.client.id}), t('bcl_aff_made'));
    } else if (a === 'open-affiliate' && xid) {
      B.go('billing_affiliates', {affiliate: xid});
    } else if (a === 'open-quote' && xid) {
      B.go('billing_quotes', {quote: xid});
    } else if (a === 'create-quote') {
      B.go('billing_quotes', {create: C.client.id});
    } else if (a === 'open-ticket' && xid) {
      B.go('billing_tickets', {ticket: xid});
    } else if (a === 'confirm-no' && b.closest('tr[data-fp-service], tr[data-fp-account], tr[data-fp-method]')) {
      var row = b.closest('tr');
      var yes = b.parentNode.querySelector('[data-fp-act$="-yes"]');
      var asked = yes ? yes.getAttribute('data-fp-act').replace(/-yes$/, '') : '';
      var again2;
      if (row.hasAttribute('data-fp-service')) { again2 = serviceRow(findIn(C.client.services, 'id', Number(row.getAttribute('data-fp-service')))); }
      if (row.hasAttribute('data-fp-account')) { again2 = accountRow(findIn(C.client.accounts, 'username', row.getAttribute('data-fp-account'))); }
      if (row.hasAttribute('data-fp-method')) { again2 = methodRow(findIn(C.client.methods, 'id', Number(row.getAttribute('data-fp-method')))); }
      row.replaceWith(again2);
      var was = again2.querySelector('[data-fp-act="' + asked + '"]');
      if (was) { was.focus(); }
    } else if (a === 'confirm-no' && b.closest('.fp-bcl-rf-form')) {
      drawTab(null, function () { var c = C.page.querySelector('[data-fp-act="rf-clear"]'); if (c) { c.focus(); } });
    } else if (a === 'confirm-no') {
      /* the question goes and the row's buttons come back */
      var item = b.closest('li[data-fp-note]');
      var tr = b.closest('tr[data-fp-contact]');
      if (item) {
        var box = b.closest('.fp-bil-row-acts');
        box.textContent = '';
        noteButtons(Number(item.getAttribute('data-fp-note')), item.getAttribute('data-fp-when')).forEach(function (n) { box.appendChild(n); });
        box.querySelector('[data-fp-act="note-remove"]').focus();
      } else if (tr) {
        var c = contactById(Number(tr.getAttribute('data-fp-contact')));
        if (c) {
          var again = contactRow(c);
          tr.replaceWith(again);
          again.querySelector('[data-fp-act="contact-remove"]').focus();
        }
      }
    }
  }
  document.addEventListener('click', onClick);

  FP.view('tool:billing_clients', function () {
    var page = B.frame('billing_clients', 'fp-bcl');
    if (!page) { return; }
    C = {page: page, view: 'list', filters: {q: '', status: '', group: ''}, offset: 0, data: null, agg: {owed: null, services: null}, groups: [], fields: [], client: null};
    var mine = C;
    var handed = B.take('billing_clients');
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all([FP.call('get', 'billingGroups').then(cleanGroups, function () { return []; }), FP.call('get', 'billingFields').then(cleanFields, function () { return []; })]).then(function (r) {
      if (C !== mine) { return; }
      C.groups = r[0];
      C.fields = r[1];
      if (handed && B.id(handed.client)) {
        openClient(handed.client);
      } else {
        showList();
      }
    });
  });
})();

/* freePanel shell start, loaded last so every view has registered. The skip link moves focus to the page without
   touching the address (the router owns the hash). */
(function () {
  'use strict';
  document.addEventListener('click', function (e) {
    var skip = e.target.closest ? e.target.closest('[data-fp-skip]') : null;
    if (!skip) { return; }
    e.preventDefault();
    var h = document.getElementById('fp-h1');
    (h || document.getElementById('sig-main')).focus();
  });
  window.FP.start();
})();

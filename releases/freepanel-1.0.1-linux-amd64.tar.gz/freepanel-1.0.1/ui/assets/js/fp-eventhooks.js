/* freePanel event hooks (docs/api.md, "Event hooks"), in the admin panel: #/tool/event_hooks, the server admin's alone. A hook tells an https address when
   something is done on the server: one signed request for each action in the audit log that the hook's events match. The page lists the hooks with how the last
   delivery went, makes one, changes one, turns one off or on, sends a test, shows the recent deliveries of one, replaces its secret and removes it after asking.
   The server judges the address (https only, no login in it, nothing of this machine or its networks) and says which rule an address breaks; the page shows those
   words by the address field. The secret that signs the requests is shown once, in the answer that makes a hook or replaces its secret; the list never has it,
   so it is held in this script, shown as text in a card of its own, and gone when the admin says it is copied, when the page is left or when the browser puts the
   page away. Making or changing a hook asks for the admin's own password again. What the server sends is cleaned to the shapes drawn and shown as text. Page
   pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var MAX_HOOKS = 10;
  var MAX_EVENTS = 20;
  var MAX_URL = 512;
  var NAME_RE = /^[A-Za-z0-9][A-Za-z0-9 ._-]{0,63}$/;
  var EVENT_RE = /^(\*|[a-z][a-z0-9_]{0,31}\.\*|[a-z][a-z0-9_]{0,31}(\.[a-z0-9_]{1,40}){1,2})$/;
  var STATES = {delivered: ['ok', 'ehk_state_delivered'], pending: ['accent', 'ehk_state_pending'], failed: ['danger', 'ehk_state_failed'], skipped: ['', 'ehk_state_skipped']};
  var SECRET_RE = /^whsec_[A-Za-z0-9_-]{20,80}$/;

  var H = null;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function whole(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.round(v) : 0; }
  function arr(v) { return Array.isArray(v) ? v : []; }
  function when(v) {
    var d = typeof v === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(v) ? new Date(v) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }

  function cleanHook(x) {
    if (!x || typeof x !== 'object' || typeof x.id !== 'number' || !isFinite(x.id) || x.id < 1) { return null; }
    return {id: Math.floor(x.id), name: str(x.name, 64), url: str(x.url, MAX_URL), enabled: x.enabled === true,
      events: arr(x.events).filter(function (e) { return typeof e === 'string' && EVENT_RE.test(e); }).slice(0, MAX_EVENTS),
      lastAt: when(x.last_at), lastStatus: x.last_status === 'ok' || x.last_status === 'failed' ? x.last_status : '', lastCode: whole(x.last_code), lastError: str(x.last_error, 300)};
  }
  function cleanHooks(r) { return arr(r && r.hooks).map(cleanHook).filter(Boolean).slice(0, MAX_HOOKS * 2); }
  function cleanDelivery(d) {
    if (!d || typeof d !== 'object' || typeof d.id !== 'number') { return null; }
    return {id: Math.floor(d.id), event: str(d.event, 80), type: str(d.type, 40), state: STATES[d.state] ? d.state : '', attempts: whole(d.attempts), code: whole(d.code),
      error: str(d.error, 300), created: when(d.created_at), next: when(d.next_at), done: when(d.done_at)};
  }
  function hookOf(id) {
    for (var i = 0; i < H.hooks.length; i++) { if (H.hooks[i].id === id) { return H.hooks[i]; } }
    return null;
  }
  function eventsOf(text) { return text.split(/[\s,;]+/).filter(Boolean); }

  /* ---- the secret, shown once ---- */
  function freshCard() {
    var f = H.fresh;
    var secret = el('code', {class: 'sig-mono fp-ehk-secret', id: 'fp-ehk-secret', tabindex: '0', role: 'group', 'aria-label': t('ehk_secret_label', {name: f.name}), text: f.secret});
    return M.card('fp-ehk-fresh-h', t(f.renewed ? 'ehk_fresh_renewed' : 'ehk_fresh_title', {name: f.name}), [
      M.statusLine(),
      el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-once': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('ehk_once')})]),
      secret,
      el('p', {class: 'fp-muted', text: t('ehk_verify')}),
      el('div', {class: 'fp-actions'}, [
        el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'copy'}, [UI.icon(FP.ui, 'ui_copy'), t('ehk_copy')]),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'done', text: t('ehk_done')})])], 'fp-ehk-fresh');
  }
  function forget() {
    if (H && H.fresh) {
      H.fresh = null;
      var secret = H.page && H.page.querySelector('#fp-ehk-secret');
      if (secret) { secret.textContent = ''; }
    }
  }

  /* ---- the hooks ---- */
  function lastLine(h) {
    if (h.lastStatus === 'ok') { return el('span', {class: 'fp-muted fp-row-note', 'data-fp-last': 'ok', text: t('ehk_last_ok', {when: h.lastAt, code: h.lastCode})}); }
    if (h.lastStatus === 'failed') { return el('span', {class: 'fp-muted fp-row-note', 'data-fp-last': 'failed', text: t('ehk_last_failed', {when: h.lastAt, why: h.lastError || t('ehk_last_unknown')})}); }
    return el('span', {class: 'fp-muted fp-row-note', 'data-fp-last': 'none', text: t('ehk_last_none')});
  }
  function hookRow(h) {
    var editing = H.editing === h.id;
    var main = el('div', {class: 'fp-rpp-main'}, [
      el('span', {class: 'fp-ehk-head'}, [el('span', {class: 'fp-rpp-title', text: h.name}),
        el('span', {class: 'sig-pill' + (h.enabled ? ' sig-pill--ok' : ''), 'data-fp-state': h.enabled ? 'on' : 'off', text: t(h.enabled ? 'ehk_on' : 'ehk_off')})]),
      el('span', {class: 'sig-mono fp-ehk-url', text: h.url}),
      el('span', {class: 'fp-ehk-events'}, h.events.map(function (e) { return el('span', {class: 'sig-badge sig-mono', text: e}); })),
      lastLine(h)]);
    var ask = H.asking && H.asking.id === h.id ? H.asking : null;
    var acts = el('span', {class: 'fp-rpp-acts fp-ehk-acts'}, [
      btn('test', t('ehk_test'), t('ehk_test_of', {name: h.name})),
      btn('deliveries', t(H.open[h.id] ? 'ehk_hide_deliveries' : 'ehk_deliveries'), t(H.open[h.id] ? 'ehk_hide_deliveries_of' : 'ehk_deliveries_of', {name: h.name})),
      btn('edit', t('ehk_edit'), t('ehk_edit_of', {name: h.name})),
      btn('toggle', t(h.enabled ? 'ehk_turn_off' : 'ehk_turn_on'), t(h.enabled ? 'ehk_turn_off_of' : 'ehk_turn_on_of', {name: h.name})),
      btn('secret', t('ehk_secret'), t('ehk_secret_of', {name: h.name})),
      btn('remove', t('ehk_remove'), t('ehk_remove_of', {name: h.name}), true)]);
    var li = el('li', {class: 'fp-rpp-row fp-ehk-row', 'data-fp-hook': String(h.id)}, [main, acts]);
    if (ask) { li.appendChild(askBox(ask)); }
    var extra = el('div', {class: 'fp-ehk-extra'}, []);
    if (H.tested && H.tested.id === h.id) { extra.appendChild(testLine(H.tested)); }
    if (editing) { extra.appendChild(hookForm(h)); }
    if (H.open[h.id]) { extra.appendChild(deliveriesView(h)); }
    if (extra.childNodes.length) { li.appendChild(extra); }
    return li;
  }
  function btn(act, text, label, danger) {
    return el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm' + (danger ? ' fp-btn-danger-text' : ''), type: 'button', 'data-fp-act': act, 'aria-label': label, text: text});
  }
  function askBox(ask) {
    return el('div', {class: 'fp-ehk-ask', 'data-fp-ask': ask.kind}, []);
  }
  function testLine(r) {
    var ok = r.delivered;
    return el('p', {class: 'fp-ehk-test ' + (ok ? 'fp-ok-line' : 'fp-alert is-shown'), role: ok ? 'status' : 'alert', 'data-fp-test': ok ? 'ok' : 'failed',
      text: ok ? t('ehk_test_ok', {code: r.code, ms: r.ms}) : t('ehk_test_failed', {why: r.error || (r.code ? t('ehk_answered', {code: r.code}) : t('ehk_last_unknown'))})});
  }
  function listCard() {
    var parts = [M.errorLine(), M.statusLine()];
    if (!H.hooks.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': 'hooks', text: t('ehk_none')}));
    } else {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-count': '', text: t(H.hooks.length === 1 ? 'ehk_count_1' : 'ehk_count', {n: H.hooks.length, max: MAX_HOOKS})}));
      parts.push(el('ul', {class: 'fp-rpp-list'}, H.hooks.map(hookRow)));
    }
    return M.card('fp-ehk-list-h', t('ehk_list_title'), parts, 'fp-ehk-list');
  }

  /* ---- deliveries ---- */
  function deliveriesView(h) {
    var d = H.deliveries[h.id];
    var box = el('div', {class: 'fp-ehk-deliveries', 'data-fp-deliveries': String(h.id)}, [el('h3', {class: 'fp-h3', text: t('ehk_deliveries_title')})]);
    if (!d) { box.appendChild(el('p', {class: 'fp-muted', text: t('loading')})); return box; }
    if (d.error) { box.appendChild(el('p', {class: 'fp-alert is-shown', role: 'alert', text: d.error})); return box; }
    if (!d.list.length) { box.appendChild(el('p', {class: 'fp-muted', 'data-fp-empty': 'deliveries', text: t('ehk_deliveries_none')})); return box; }
    /* a list of small cards and not a table: the rows are narrow on a phone and a table there breaks words letter by letter */
    box.appendChild(el('ul', {class: 'fp-ehk-dlist', 'aria-label': t('ehk_deliveries_of_hook', {name: h.name})}, d.list.map(function (x) {
      var st = STATES[x.state];
      return el('li', {class: 'fp-ehk-delivery', 'data-fp-delivery': String(x.id)}, [
        el('div', {class: 'fp-ehk-dhead'}, [el('span', {class: 'sig-mono fp-ehk-event', text: x.event || x.type || '—'}),
          st ? el('span', {class: 'sig-pill' + (st[0] ? ' sig-pill--' + st[0] : ''), text: t(st[1])}) : null]),
        el('div', {class: 'fp-muted fp-row-note fp-ehk-dline'}, [x.created ? el('span', {text: t('ehk_d_made', {when: x.created})}) : null,
          el('span', {text: t(x.attempts === 1 ? 'ehk_d_try_1' : 'ehk_d_tries', {n: x.attempts})}),
          el('span', {text: x.code ? t('ehk_d_answer', {code: x.code}) : t('ehk_d_no_answer')}),
          x.state === 'pending' && x.next ? el('span', {text: t('ehk_next', {when: x.next})}) : null]),
        x.error ? el('div', {class: 'fp-muted fp-row-note fp-ehk-derror', text: x.error}) : null]);
    })));
    box.appendChild(el('p', {class: 'fp-muted fp-row-note', text: t('ehk_deliveries_note')}));
    return box;
  }

  /* ---- the form to make a hook or change one ---- */
  function hookForm(h) {
    var id = h ? 'fp-ehk-e' + h.id : 'fp-ehk-n';
    var name = el('input', {class: 'sig-input', id: id + '-name', name: 'name', type: 'text', maxlength: '64', autocomplete: 'off', spellcheck: 'false', value: h ? h.name : ''});
    var url = el('input', {class: 'sig-input sig-mono', id: id + '-url', name: 'url', type: 'url', maxlength: String(MAX_URL), autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none',
      placeholder: 'https://example.com/hook', value: h ? h.url : ''});
    var events = el('textarea', {class: 'sig-input sig-mono', id: id + '-events', name: 'events', rows: '3', spellcheck: 'false', autocapitalize: 'none', autocomplete: 'off',
      placeholder: 'account.*\nbackup.pass'});
    events.value = h ? h.events.join('\n') : '';
    var pw = el('input', {class: 'sig-input', id: id + '-password', name: 'current_password', type: 'password', autocomplete: 'current-password'});
    var enabled = h ? null : el('div', {class: 'sig-field'}, [el('label', {class: 'fp-check', for: id + '-enabled'}, [
      el('input', {type: 'checkbox', id: id + '-enabled', name: 'enabled', checked: true}), el('span', {text: t('ehk_enabled')})])]);
    var form = el('form', {class: 'fp-form fp-rpp-form fp-ehk-form', novalidate: '', 'data-fp-form': h ? 'edit' : 'new'}, [M.errorLine(),
      M.field(id + '-name', t('ehk_name'), name, t('ehk_name_hint')), M.field(id + '-url', t('ehk_url'), url, t('ehk_url_hint')),
      M.field(id + '-events', t('ehk_events'), events, t('ehk_events_hint', {max: MAX_EVENTS})), enabled,
      M.field(id + '-password', t('ehk_password'), pw, t('ehk_password_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t(h ? 'ehk_save' : 'ehk_make')}),
        h ? el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'edit-cancel', text: t('cancel')}) : null])]);
    form.addEventListener('submit', function (e) { e.preventDefault(); submit(form, h); });
    return form;
  }
  function makeCard() {
    if (H.hooks.length >= MAX_HOOKS) {
      return M.card('fp-ehk-make-h', t('ehk_make_title'), [el('p', {class: 'fp-muted', 'data-fp-full': '', text: t('ehk_full', {max: MAX_HOOKS})})], 'fp-ehk-make');
    }
    return M.card('fp-ehk-make-h', t('ehk_make_title'), [el('p', {class: 'fp-muted', text: t('ehk_make_intro')}), hookForm(null)], 'fp-ehk-make');
  }
  function submit(form, h) {
    var b = M.start(form);
    if (!b) { return; }
    var name = UI.fieldNamed(form, 'name');
    var url = UI.fieldNamed(form, 'url');
    var events = UI.fieldNamed(form, 'events');
    var pw = UI.fieldNamed(form, 'current_password');
    var list = eventsOf(events.value);
    var n = name.value.trim();
    var u = url.value.trim();
    if (!NAME_RE.test(n)) { M.fieldError(form, name, t('ehk_name_bad')); return; }
    if (!u) { M.fieldError(form, url, t('ehk_url_needed')); return; }
    if (u.length > MAX_URL) { M.fieldError(form, url, t('ehk_url_long', {max: MAX_URL})); return; }
    if (!list.length) { M.fieldError(form, events, t('ehk_events_needed')); return; }
    if (list.length > MAX_EVENTS) { M.fieldError(form, events, t('ehk_events_many', {max: MAX_EVENTS})); return; }
    if (!pw.value) { M.fieldError(form, pw, t('ehk_need_password')); return; }
    var mine = H;
    var body = {name: n, url: u, events: list, current_password: pw.value};
    var call;
    if (h) {
      /* the whole form is sent, with the password the server asks for when a name, an address or an action changes; nothing is sent when nothing is */
      var same = n === h.name && u === h.url && list.join(' ') === h.events.join(' ');
      if (same) { M.fieldError(form, null, t('ehk_nothing')); return; }
      call = FP.call('put', 'eventHook', body, {id: String(h.id)});
    } else {
      body.enabled = UI.fieldNamed(form, 'enabled').checked;
      call = FP.call('post', 'eventHooks', body);
    }
    UI.setBusy(b, true);
    call.then(function (r) {
      if (H !== mine) { return; }
      var k = cleanHook(r);
      if (!h) {
        var secret = typeof r.secret === 'string' && SECRET_RE.test(r.secret) ? r.secret : '';
        mine.fresh = secret && k ? {name: k.name, secret: secret, renewed: false} : null;
        if (!secret || !k) { reload(t('ehk_made_unseen')); return; }
        mine.hooks = mine.hooks.concat([k]);
        draw();
        mine.page.querySelector('#fp-ehk-fresh-h').focus();
      } else {
        mine.editing = 0;
        mine.hooks = mine.hooks.map(function (x) { return x.id === h.id ? (k || x) : x; });
        draw();
        M.say(mine.page.querySelector('.fp-ehk-list'), t('ehk_saved', {name: k ? k.name : h.name}));
        focusRow(h.id, 'edit');
      }
    }, function (err) {
      UI.setBusy(b, false);
      if (H !== mine) { return; }
      pw.value = '';
      if (err && err.status === 0 && !h) {
        /* the answer may have been lost after the hook was made, with its secret: nothing here can show it, so the list is read again */
        UI.showError(form, err.message + ' ' + t('ehk_cut'));
        FP.call('get', 'eventHooks').then(function (r) { if (H === mine && !mine.fresh) { mine.hooks = cleanHooks(r); redrawList(); } }, function () { /* the list is as it was */ });
        return;
      }
      if (err && err.status === 404) { reload('').then(function () { UI.showError(mine.page.querySelector('.fp-ehk-list'), err.message); }); return; }
      /* a wrong password is the password field's: it is marked and takes the focus, in the server's own words */
      if (err && err.status === 403) { M.fieldError(form, pw, err.message); return; }
      M.failed(form, err);
    });
  }

  /* ---- the guide ---- */
  function guideCard() {
    return M.card('fp-ehk-guide-h', t('ehk_guide_title'), [
      el('p', {class: 'fp-muted', text: t('ehk_guide_1')}),
      el('ul', {class: 'fp-ehk-points'}, ['ehk_point_body', 'ehk_point_headers', 'ehk_point_sign', 'ehk_point_retry', 'ehk_point_secret', 'ehk_point_address'].map(function (k) {
        return el('li', {class: 'fp-muted', text: t(k)});
      }))], 'fp-ehk-guide');
  }

  /* ---- the page ---- */
  function draw() {
    H.page.textContent = '';
    if (H.fresh) { H.page.appendChild(freshCard()); }
    H.page.appendChild(listCard());
    if (!H.fresh) { H.page.appendChild(makeCard()); }
    H.page.appendChild(guideCard());
    if (H.asking) { openAsk(); }
  }
  function redrawList() {
    var old = H.page.querySelector('.fp-ehk-list');
    if (old) { H.page.replaceChild(listCard(), old); if (H.asking) { openAsk(); } }
  }
  function focusRow(id, act) {
    var b = H.page.querySelector('li[data-fp-hook="' + id + '"] [data-fp-act="' + act + '"]');
    if (b) { b.focus(); }
  }
  function reload(note) {
    var mine = H;
    return FP.call('get', 'eventHooks').then(function (r) {
      if (H !== mine) { return; }
      mine.hooks = cleanHooks(r);
      mine.editing = 0;
      mine.asking = null;
      draw();
      if (note) { M.say(mine.page.querySelector('.fp-ehk-list'), note); }
    }, function (err) {
      if (H !== mine) { return; }
      UI.showError(mine.page.querySelector('.fp-ehk-list'), err.message);
    });
  }

  /* a question in place of a row's buttons, with the password it needs where it needs one */
  function openAsk() {
    var a = H.asking;
    var li = H.page.querySelector('li[data-fp-hook="' + a.id + '"]');
    if (!li) { H.asking = null; return; }
    var box = li.querySelector('.fp-ehk-ask');
    var hook = hookOf(a.id);
    var form = el('form', {class: 'fp-form fp-ehk-askform', novalidate: ''}, [M.errorLine(),
      el('p', {class: 'fp-mail-confirm fp-ehk-question', id: 'fp-ehk-q' + a.id, text: t(a.kind === 'remove' ? 'ehk_remove_ask' : 'ehk_secret_ask', {name: hook ? hook.name : ''})}),
      a.kind === 'secret' ? M.field('fp-ehk-q' + a.id + '-pw', t('ehk_password'), el('input', {class: 'sig-input', id: 'fp-ehk-q' + a.id + '-pw', name: 'current_password', type: 'password',
        autocomplete: 'current-password'}), t('ehk_password_hint')) : null,
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn ' + (a.kind === 'remove' ? 'sig-btn--danger' : 'sig-btn--primary') + ' fp-submit', type: 'submit', 'aria-describedby': 'fp-ehk-q' + a.id,
        text: t(a.kind === 'remove' ? 'ehk_remove' : 'ehk_secret_yes')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'ask-no', text: t('cancel')})])]);
    form.addEventListener('submit', function (e) { e.preventDefault(); answer(form, a); });
    box.textContent = '';
    box.appendChild(form);
    (form.querySelector('input') || form.querySelector('[data-fp-act="ask-no"]')).focus();
  }
  function answer(form, a) {
    var b = M.start(form);
    if (!b) { return; }
    var mine = H;
    var arg = {id: String(a.id)};
    var hook = hookOf(a.id);
    if (a.kind === 'remove') {
      UI.setBusy(b, true);
      FP.call('del', 'eventHook', undefined, arg).then(function () {
        if (H !== mine) { return; }
        mine.hooks = mine.hooks.filter(function (x) { return x.id !== a.id; });
        mine.asking = null;
        delete mine.open[a.id];
        draw();
        M.say(mine.page.querySelector('.fp-ehk-list'), t('ehk_removed', {name: hook ? hook.name : ''}));
        mine.page.querySelector('#fp-ehk-list-h').focus();
      }, function (err) {
        UI.setBusy(b, false);
        if (H !== mine) { return; }
        if (err && err.status === 404) { reload('').then(function () { UI.showError(mine.page.querySelector('.fp-ehk-list'), err.message); }); return; }
        M.failed(form, err);
      });
      return;
    }
    var pw = UI.fieldNamed(form, 'current_password');
    if (!pw.value) { M.fieldError(form, pw, t('ehk_need_password')); return; }
    UI.setBusy(b, true);
    FP.call('post', 'eventHookSecret', {current_password: pw.value}, arg).then(function (r) {
      if (H !== mine) { return; }
      var secret = typeof r.secret === 'string' && SECRET_RE.test(r.secret) ? r.secret : '';
      mine.asking = null;
      if (!secret) { reload(t('ehk_made_unseen_secret')); return; }
      mine.fresh = {name: hook ? hook.name : '', secret: secret, renewed: true};
      draw();
      mine.page.querySelector('#fp-ehk-fresh-h').focus();
    }, function (err) {
      UI.setBusy(b, false);
      if (H !== mine) { return; }
      pw.value = '';
      if (err && err.status === 0) {
        UI.showError(form, err.message + ' ' + t('ehk_cut_secret'));
        return;
      }
      if (err && err.status === 403) { M.fieldError(form, pw, err.message); return; }
      M.failed(form, err);
    });
  }

  function copy(button) {
    var scope = H.page.querySelector('.fp-ehk-fresh');
    var secret = H.page.querySelector('#fp-ehk-secret');
    function selected() {
      var range = document.createRange();
      range.selectNodeContents(secret);
      var sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
      M.say(scope, t('ehk_selected'));
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(H.fresh.secret).then(function () { M.say(scope, t('ehk_copied')); }, selected);
    } else {
      selected();
    }
    button.focus();
  }
  function loadDeliveries(id) {
    var mine = H;
    delete mine.deliveries[id];
    return FP.call('get', 'eventHookDeliveries', undefined, {id: String(id)}).then(function (r) {
      mine.deliveries[id] = {list: arr(r && r.deliveries).map(cleanDelivery).filter(Boolean).slice(0, 200), error: ''};
    }, function (err) {
      mine.deliveries[id] = {list: [], error: err && err.message ? err.message : t('api_failed')};
    }).then(function () { if (H === mine) { redrawList(); } });
  }
  function onClick(e) {
    var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !H || !H.page.contains(b)) { return; }
    var act = b.getAttribute('data-fp-act');
    var li = b.closest('li[data-fp-hook]');
    var id = li ? parseInt(li.getAttribute('data-fp-hook'), 10) : 0;
    var hook = id ? hookOf(id) : null;
    var mine = H;
    if (act === 'copy' && H.fresh) {
      copy(b);
    } else if (act === 'done') {
      forget();
      draw();
      H.page.querySelector('#fp-ehk-list-h').focus();
    } else if (act === 'again') {
      start(true);
    } else if (act === 'edit' && hook) {
      H.editing = hook.id;
      H.asking = null;
      redrawList();
      var field = H.page.querySelector('li[data-fp-hook="' + id + '"] [name="name"]');
      if (field) { field.focus(); }
    } else if (act === 'edit-cancel') {
      H.editing = 0;
      redrawList();
      focusRow(id, 'edit');
    } else if ((act === 'remove' || act === 'secret') && hook) {
      H.asking = {id: hook.id, kind: act};
      H.editing = 0;
      redrawList();
    } else if (act === 'ask-no') {
      var was = H.asking;
      H.asking = null;
      redrawList();
      if (was) { focusRow(was.id, was.kind); }
    } else if (act === 'toggle' && hook) {
      UI.setBusy(b, true);
      FP.call('put', 'eventHook', {enabled: !hook.enabled}, {id: String(hook.id)}).then(function (r) {
        if (H !== mine) { return; }
        var k = cleanHook(r);
        mine.hooks = mine.hooks.map(function (x) { return x.id === hook.id ? (k || x) : x; });
        redrawList();
        M.say(mine.page.querySelector('.fp-ehk-list'), t(k && k.enabled ? 'ehk_turned_on' : 'ehk_turned_off', {name: hook.name}));
        focusRow(hook.id, 'toggle');
      }, function (err) {
        UI.setBusy(b, false);
        if (H !== mine) { return; }
        UI.showError(mine.page.querySelector('.fp-ehk-list'), err.message);
      });
    } else if (act === 'test' && hook) {
      UI.setBusy(b, true);
      FP.call('post', 'eventHookTest', {}, {id: String(hook.id)}).then(function (r) {
        if (H !== mine) { return; }
        mine.tested = {id: hook.id, delivered: r && r.delivered === true, code: whole(r && r.code), error: str(r && r.error, 300), ms: whole(r && r.ms)};
        /* the list is read again: the test is the hook's latest delivery */
        return FP.call('get', 'eventHooks').then(function (all) { if (H === mine) { mine.hooks = cleanHooks(all); } }, function () { /* as it was */ }).then(function () {
          if (H !== mine) { return; }
          redrawList();
          focusRow(hook.id, 'test');
        });
      }, function (err) {
        UI.setBusy(b, false);
        if (H !== mine) { return; }
        UI.showError(mine.page.querySelector('.fp-ehk-list'), err.message);
      });
    } else if (act === 'deliveries' && hook) {
      if (H.open[hook.id]) {
        delete H.open[hook.id];
        redrawList();
        focusRow(hook.id, 'deliveries');
      } else {
        H.open[hook.id] = true;
        redrawList();
        focusRow(hook.id, 'deliveries');
        loadDeliveries(hook.id).then(function () { if (H === mine) { focusRow(hook.id, 'deliveries'); } });
      }
    }
  }

  function start(again) {
    forget();
    H = null;
    var tool = FP.tools.event_hooks;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('ehk_desc'), cls: 'fp-mail fp-rpp fp-ehk-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    var mine = H = {page: page, hooks: [], fresh: null, editing: 0, asking: null, open: {}, deliveries: {}, tested: null};
    page.addEventListener('click', onClick);
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    if (again) { document.getElementById('fp-h1').focus(); }
    FP.call('get', 'eventHooks').then(function (r) {
      if (H !== mine) { return; }
      mine.hooks = cleanHooks(r);
      draw();
    }, function (err) {
      if (H !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err.message, el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'again', text: t('ehk_try_again')})));
    });
  }
  window.addEventListener('pagehide', forget);
  window.addEventListener('hashchange', function () { if (H && window.location.hash !== '#/tool/event_hooks') { forget(); } });
  FP.view('tool:event_hooks', function () { start(false); });
})();

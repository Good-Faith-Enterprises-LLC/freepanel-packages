/* freePanel Code libraries (#/tool/code_libraries), the customer panel's page for the Ruby gems, Perl modules and PEAR packages the
   account keeps in its home (docs/api.md, "Code libraries"): add one by name (and a version, where the server's installer can pin one),
   see what the account has, remove one. An install or removal runs on the server in the background, so the page asks again every few
   seconds while one runs, and says how it went, with the installer's last lines when it failed. What the server sends is drawn as text.
   It shares the mail pages' look and helpers (FP.mail). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var KINDS = ['gem', 'perl', 'pear'];
  var NAME = {gem: /^[A-Za-z0-9][A-Za-z0-9._-]{0,99}$/, perl: /^[A-Za-z_][A-Za-z0-9_]*(::[A-Za-z_][A-Za-z0-9_]*)*$/, pear: /^[A-Za-z][A-Za-z0-9_]{0,99}$/};
  var VERSION = {gem: /^[0-9][0-9A-Za-z.]{0,31}$/, perl: /^v?[0-9][0-9._]{0,31}$/, pear: /^[0-9][0-9A-Za-z.]{0,31}$/};
  var PROGRAMS = {gem: true, cpanm: true, cpan: true, pear: true};
  var STATUS = {running: 'clb_st_running', done: 'clb_st_done', failed: 'clb_st_failed', stopped: 'clb_st_stopped'};
  var EVERY = 2000;
  var G = {page: null, account: '', state: null, ask: '', timer: 0, srv: false};
  /* The admin panel's Server-wide libraries (#/tool/server_libraries) is this page for the server's own gems and Perl modules: no account,
     no PEAR, and an install asks the admin's password again, because it runs as root. */
  var SRV = {add_desc: 1, hint_gem: 1, hint_perl_cpanm: 1, hint_perl_cpan: 1, list_title: 1, none: 1, none_here: 1, remove_ask: 1, kind_off: 1};
  function ct(k, v) { return t((G.srv && SRV[k] ? 'slb_' : 'clb_') + k, v); }
  function kinds() { return G.srv ? ['gem', 'perl'] : KINDS; }
  function listKey() { return G.srv ? 'serverLibraries' : 'libraries'; }
  function listArg() { return G.srv ? undefined : G.account; }

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function when(iso) {
    var d = iso ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString(undefined, {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }
  function okName(kind, n) { return NAME[kind] && n.length <= 100 && NAME[kind].test(n); }
  function okVersion(kind, v) { return v === '' || (VERSION[kind].test(v) && v.indexOf('..') < 0 && v.charAt(v.length - 1) !== '.'); }
  function cleanTool(x) {
    if (!x || typeof x !== 'object' || KINDS.indexOf(x.kind) < 0) { return null; }
    var on = x.available === true && PROGRAMS[x.program] === true;
    return {kind: x.kind, available: on, program: on ? x.program : '', versions: on && x.versions === true, reason: on ? '' : str(x.reason, 300)};
  }
  function cleanLib(x) {
    if (!x || typeof x !== 'object' || KINDS.indexOf(x.kind) < 0 || !okName(x.kind, str(x.name, 120))) { return null; }
    var v = str(x.version, 40);
    return {kind: x.kind, name: x.name, version: okVersion(x.kind, v) ? v : ''};
  }
  function cleanJob(j) {
    if (!j || typeof j !== 'object' || !STATUS[j.status] || (j.action !== 'install' && j.action !== 'remove') || KINDS.indexOf(j.kind) < 0 ||
      !okName(j.kind, str(j.name, 120))) { return null; }
    var v = str(j.version, 40);
    return {action: j.action, kind: j.kind, name: j.name, version: okVersion(j.kind, v) ? v : '', status: j.status, started: str(j.started, 40),
      ended: str(j.ended, 40), problem: str(j.problem, 600), output: Array.isArray(j.output) ? j.output.slice(-40).map(function (l) { return str(l, 320); }) : []};
  }
  function clean(v) {
    if (!v || typeof v !== 'object' || !Array.isArray(v.tools) || !Array.isArray(v.libraries)) { return null; }
    var tools = {};
    v.tools.map(cleanTool).filter(Boolean).forEach(function (x) { tools[x.kind] = x; });
    kinds().forEach(function (k) { if (!tools[k]) { tools[k] = {kind: k, available: false, program: '', versions: false, reason: ''}; } });
    return {tools: tools, libraries: v.libraries.slice(0, 1500).map(cleanLib).filter(Boolean), job: cleanJob(v.job), listProblem: str(v.list_problem, 300)};
  }
  function running() { return Boolean(G.state && G.state.job && G.state.job.status === 'running'); }
  function anyTool() { return kinds().some(function (k) { return G.state.tools[k].available; }); }

  /* ---- the form that adds a library ---- */
  function kindHint(kind) {
    var tool = G.state.tools[kind];
    if (!tool.available) { return tool.reason || ct('kind_off'); }
    return ct('hint_' + kind + (kind === 'perl' ? '_' + tool.program : ''));
  }
  function syncForm(form) {
    var kind = form.querySelector('[name="kind"]').value;
    var tool = G.state.tools[kind];
    var ver = form.querySelector('[name="version"]');
    var hint = form.querySelector('#fp-clb-kind-hint');
    hint.textContent = kindHint(kind);
    hint.classList.toggle('fp-clb-off', !tool.available);
    form.querySelector('[name="name"]').setAttribute('placeholder', t('clb_ph_' + kind));
    ver.disabled = !tool.versions;
    if (!tool.versions) { ver.value = ''; }
    form.querySelector('#fp-clb-version-hint').textContent = tool.available && !tool.versions ? t('clb_version_cpan') : t('clb_version_hint');
    form.querySelector('.fp-submit').disabled = !tool.available || running();
  }
  function addCard() {
    var first = kinds().filter(function (k) { return G.state.tools[k].available; })[0] || 'gem';
    var kind = el('select', {class: 'sig-select', id: 'fp-clb-kind', name: 'kind', 'aria-describedby': 'fp-clb-kind-hint'}, kinds().map(function (k) {
      return el('option', {value: k, selected: k === first ? true : null, text: t('clb_kind_' + k) + (G.state.tools[k].available ? '' : ' ' + t('clb_kind_not_here'))});
    }));
    var form = el('form', {class: 'fp-form fp-mail-form fp-clb-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: 'fp-clb-kind', text: t('clb_kind')}), kind,
        el('span', {class: 'sig-hint', id: 'fp-clb-kind-hint'})]),
      el('div', {class: 'fp-clb-row'}, [
        M.field('fp-clb-name', t('clb_name'), el('input', {class: 'sig-input sig-mono', id: 'fp-clb-name', name: 'name', type: 'text', autocomplete: 'off',
          spellcheck: 'false', autocapitalize: 'none', maxlength: '100'}), t('clb_name_hint')),
        el('div', {class: 'sig-field fp-clb-ver'}, [el('label', {class: 'sig-label', for: 'fp-clb-version', text: t('clb_version')}),
          el('input', {class: 'sig-input sig-mono', id: 'fp-clb-version', name: 'version', type: 'text', autocomplete: 'off', spellcheck: 'false',
            autocapitalize: 'none', maxlength: '32', placeholder: t('clb_version_ph'), 'aria-describedby': 'fp-clb-version-hint'}),
          el('span', {class: 'sig-hint', id: 'fp-clb-version-hint'})])]),
      G.srv ? M.field('fp-clb-pw', t('slb_password'), el('input', {class: 'sig-input', id: 'fp-clb-pw', name: 'current_password', type: 'password',
        autocomplete: 'current-password', maxlength: '512'}), t('slb_password_hint')) : null,
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('clb_add_btn')})])]);
    kind.addEventListener('change', function () { syncForm(form); });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var k = kind.value;
      var name = form.querySelector('[name="name"]');
      var ver = form.querySelector('[name="version"]');
      if (!G.state.tools[k].available) { M.fieldError(form, kind, kindHint(k)); return; }
      var n = name.value.trim();
      if (!okName(k, n)) { M.fieldError(form, name, t('clb_name_bad_' + k)); return; }
      var v = ver.value.trim();
      if (!okVersion(k, v)) { M.fieldError(form, ver, t('clb_version_bad')); return; }
      var body = {kind: k, name: n};
      if (v) { body.version = v; }
      var pw = form.querySelector('[name="current_password"]');
      if (pw) {
        if (!pw.value) { M.fieldError(form, pw, t('slb_password_needed')); return; }
        body.current_password = pw.value;
      }
      UI.setBusy(b, true);
      FP.call('post', listKey(), body, listArg()).then(function (r) {
        var s = clean(r);
        UI.setBusy(b, false);
        if (!s) { M.fieldError(form, null, t('api_failed')); return; }
        G.state = s;
        form.reset();
        kind.value = k;
        syncForm(form);
        drawJob();
        schedule();
        M.say(form, t('clb_started', {name: n}));
      }, function (err) {
        UI.setBusy(b, false);
        if (pw) { pw.value = ''; }
        M.failed(form, err);
        syncForm(form);
      });
    });
    var c = M.card('fp-clb-add-h', t('clb_add_title'), [el('p', {class: 'fp-muted', text: ct('add_desc')}), form], 'fp-clb-add');
    syncForm(form);
    return c;
  }

  /* ---- the latest install or removal ---- */
  function jobText(j) {
    var what = j.version ? j.name + ' ' + j.version : j.name;
    var key = 'clb_job_' + j.action + '_' + j.status;
    return t(key, {name: what, kind: t('clb_kind_' + j.kind), date: when(j.ended || j.started)});
  }
  function drawJob() {
    var box = G.page.querySelector('[data-fp-job]');
    box.textContent = '';
    var j = G.state.job;
    box.hidden = !j;
    if (!j) { return; }
    box.className = 'fp-clb-job fp-clb-job--' + j.status;
    var pill = el('span', {class: 'sig-pill ' + (j.status === 'done' ? 'sig-pill--ok' : j.status === 'running' ? 'sig-pill--accent' : 'sig-pill--danger'),
      text: t(STATUS[j.status])});
    box.appendChild(el('div', {class: 'fp-clb-job-head'}, [pill, el('p', {class: 'fp-clb-job-what', text: jobText(j)})]));
    if (j.status === 'running') { box.appendChild(el('p', {class: 'fp-muted', text: t('clb_running_hint')})); }
    if (j.problem) { box.appendChild(el('p', {class: 'fp-warn-line', 'data-fp-problem': '', text: j.problem})); }
    if (j.output.length) {
      box.appendChild(el('details', {class: 'fp-clb-out'}, [el('summary', {text: t('clb_output', {n: j.output.length})}),
        el('pre', {class: 'fp-clb-pre sig-mono', tabindex: '0', text: j.output.join('\n')})]));
    }
  }

  /* ---- what the account has ---- */
  function removeAsk(l) {
    var id = 'fp-clb-ask-' + l.kind + '-' + l.name.replace(/[^A-Za-z0-9_-]/g, '-');
    return el('div', {class: 'fp-clb-ask', role: 'group', 'aria-labelledby': id}, [
      el('span', {class: 'fp-mail-confirm', id: id, text: ct('remove_ask', {name: l.name})}),
      el('button', {class: 'sig-btn sig-btn--danger sig-btn--sm', type: 'button', 'data-fp-act': 'remove-yes', 'aria-describedby': id, text: t('clb_remove_yes')}),
      el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'remove-no', 'aria-describedby': id, text: t('clb_keep')})]);
  }
  function key(l) { return l.kind + ':' + l.name; }
  function row(l) {
    var acts = G.ask === key(l) ? removeAsk(l) :
      el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'remove', disabled: running() ? true : null,
        'aria-label': t('clb_remove_of', {name: l.name}), text: t('clb_remove')});
    return el('tr', {'data-fp-lib': key(l)}, [
      el('th', {scope: 'row', class: 'sig-mono fp-clb-name', text: l.name}),
      el('td', {class: 'sig-mono', text: l.version || '—'}),
      el('td', {class: 'fp-clb-acts'}, [acts])]);
  }
  function drawList() {
    var holder = G.page.querySelector('[data-fp-libs]');
    holder.textContent = '';
    var problem = G.page.querySelector('[data-fp-list-problem]');
    problem.textContent = G.state.listProblem ? t('clb_list_problem', {problem: G.state.listProblem}) : '';
    problem.hidden = !G.state.listProblem;
    var none = G.page.querySelector('[data-fp-empty]');
    none.hidden = G.state.libraries.length > 0;
    kinds().forEach(function (k) {
      var libs = G.state.libraries.filter(function (l) { return l.kind === k; });
      if (!libs.length) { return; }
      var hid = 'fp-clb-h-' + k;
      holder.appendChild(el('section', {class: 'fp-clb-group', 'data-fp-kind': k, 'aria-labelledby': hid}, [
        el('h3', {class: 'fp-h3', id: hid, text: t('clb_group_' + k, {n: libs.length})}),
        el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': hid}, [
          el('table', {class: 'sig-table fp-clb-table'}, [
            el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('clb_col_name')}), el('th', {scope: 'col', text: t('clb_col_version')}),
              el('th', {scope: 'col', class: 'fp-clb-acts', text: t('clb_col_actions')})])]),
            el('tbody', null, libs.map(row))])])]));
    });
  }
  function howCard() {
    if (G.srv) {
      return M.card('fp-clb-how-h', t('clb_how_title'), [el('dl', {class: 'fp-clb-how'}, [
        el('dt', {text: t('clb_kind_gem')}), el('dd', {text: t('slb_how_gem')}),
        el('dt', {text: t('clb_kind_perl')}), el('dd', {text: t('slb_how_perl')})]),
      el('p', {class: 'fp-muted', text: t('slb_how_root')})], 'fp-clb-how-card');
    }
    return M.card('fp-clb-how-h', t('clb_how_title'), [el('dl', {class: 'fp-clb-how'}, [
      el('dt', {text: t('clb_kind_gem')}), el('dd', {text: t('clb_how_gem')}),
      el('dt', {text: t('clb_kind_perl')}), el('dd', null, [document.createTextNode(t('clb_how_perl') + ' '), el('code', {text: 'PERL5LIB=$HOME/perl5/lib/perl5'})]),
      el('dt', {text: t('clb_kind_pear')}), el('dd', null, [document.createTextNode(t('clb_how_pear') + ' '), el('code', {text: '~/pear/php'})])]),
    el('p', {class: 'fp-muted', text: t('clb_how_native')})], 'fp-clb-how-card');
  }
  function render() {
    G.page.textContent = '';
    if (!anyTool()) {
      G.page.appendChild(el('div', {class: 'fp-note', role: 'note', 'data-fp-none-here': '', text: ct('none_here')}));
    }
    G.page.appendChild(addCard());
    G.page.appendChild(M.card('fp-clb-list-h', ct('list_title'), [M.errorLine(), M.statusLine(), el('div', {'data-fp-job': '', hidden: true}),
      el('p', {class: 'fp-warn-line', 'data-fp-list-problem': '', hidden: true}),
      el('p', {class: 'fp-muted', 'data-fp-empty': '', text: ct('none')}), el('div', {'data-fp-libs': ''})], 'fp-clb-list'));
    G.page.appendChild(howCard());
    drawJob();
    drawList();
  }
  function redrawAll() {
    var form = G.page.querySelector('.fp-clb-form');
    if (form) { syncForm(form); }
    drawJob();
    drawList();
  }

  /* ---- a job runs on the server: asked again until it ends ---- */
  function here() { return Boolean(G.page && G.page.isConnected); }
  function schedule() {
    window.clearTimeout(G.timer);
    G.timer = 0;
    if (here() && running()) { G.timer = window.setTimeout(refresh, EVERY); }
  }
  function refresh() {
    var page = G.page;
    G.timer = 0;
    if (!here()) { return; }
    FP.call('get', listKey(), undefined, listArg()).then(function (r) {
      if (G.page !== page || !here()) { return; }
      var s = clean(r);
      if (!s) { return; }
      var was = running();
      G.state = s;
      redrawAll();
      if (was && !running() && s.job) { M.say(G.page.querySelector('.fp-clb-list'), jobText(s.job)); }
      schedule();
    }, function () {
      if (G.page !== page || !here()) { return; }
      UI.showError(G.page.querySelector('.fp-clb-list'), t('clb_refresh_failed'));
      G.timer = window.setTimeout(refresh, EVERY * 3);
    });
  }

  /* ---- clicks ---- */
  function libOf(node) {
    var k = node ? node.getAttribute('data-fp-lib') : '';
    for (var i = 0; i < G.state.libraries.length; i++) { if (key(G.state.libraries[i]) === k) { return G.state.libraries[i]; } }
    return null;
  }
  function focusRow(k, act) {
    var n = G.page.querySelector('[data-fp-lib="' + window.CSS.escape(k) + '"]');
    var b = n && n.querySelector('[data-fp-act="' + act + '"]');
    if (b) { b.focus(); }
  }
  document.addEventListener('click', function (e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !G.page || !G.page.contains(b)) { return; }
    var a = b.getAttribute('data-fp-act');
    var l = libOf(b.closest('[data-fp-lib]'));
    if (!l) { return; }
    var list = G.page.querySelector('.fp-clb-list');
    if (a === 'remove') {
      G.ask = key(l);
      drawList();
      focusRow(key(l), 'remove-no');
    } else if (a === 'remove-no') {
      G.ask = '';
      drawList();
      focusRow(key(l), 'remove');
    } else if (a === 'remove-yes') {
      UI.showError(list, '');
      M.say(list, '');
      UI.setBusy(b, true);
      FP.call('del', G.srv ? 'serverLibrary' : 'library', undefined, G.srv ? {kind: l.kind, lib: l.name} : {name: G.account, kind: l.kind, lib: l.name}).then(function (r) {
        var s = clean(r);
        G.ask = '';
        if (!s) { drawList(); UI.showError(list, t('api_failed')); return; }
        G.state = s;
        redrawAll();
        M.say(list, t('clb_remove_started', {name: l.name}));
        G.page.querySelector('#fp-clb-list-h').focus();
        schedule();
      }, function (err) {
        G.ask = '';
        drawList();
        UI.showError(list, l.name + ': ' + err.message);
        focusRow(key(l), 'remove');
      });
    }
  });

  function open(id, body) {
    G.page = body;
    G.ask = '';
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', listKey(), undefined, listArg()).then(function (r) {
      if (G.page !== body) { return; }
      var s = clean(r);
      body.textContent = '';
      if (!s) { body.appendChild(FP.empty(FP.tools[id].label, t('api_failed'))); return; }
      G.state = s;
      render();
      schedule();
    }, function (err) {
      if (G.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(FP.tools[id].label, err.message));
    });
  }
  FP.view('tool:code_libraries', function () {
    window.clearTimeout(G.timer);
    G.page = null;
    G.srv = false;
    var body = M.frame('code_libraries', 'fp-clb');
    if (!body) { return; }
    G.account = FP.account();
    open('code_libraries', body);
  });
  FP.view('tool:server_libraries', function () {
    window.clearTimeout(G.timer);
    G.page = null;
    G.srv = true;
    G.account = '';
    var tool = FP.tools.server_libraries;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('server_libraries_desc'), cls: 'fp-mail fp-clb fp-slb',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    open('server_libraries', body);
  });
})();

/* freePanel site rules (#/tool/ip_blocker, folder_listing, error_pages, hotlink, mime_types, file_handlers and optimize_site), the
   customer panel's seven pages for the rules a site keeps in its .htaccess (docs/api.md, "Site rules"): addresses to block, folder
   listing, error pages, hotlink protection, file types, file handlers and compression with browser caching. Each page picks a site, reads the site's rules once, and sends a change that replaces
   one block of the file; the server keeps the rest of the file as it is and checks every value again. A page that adds to or
   removes from a list reads the rules afresh just before it sends, so a list changed in another tab is not overwritten from
   an old copy. Page pieces come from FP.mail (fp-mail.js) and the site list from fp-phpsettings.js. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  /* the statuses an error page can be set for, as the server lists them; used when it does not */
  var STATUSES = [400, 401, 403, 404, 405, 408, 410, 413, 414, 429, 500, 501, 502, 503, 504];
  /* the kinds of file hotlink protection can cover, in the groups they are shown in; others the server adds go last */
  var KINDS = [
    ['hot_k_pictures', ['jpg', 'jpeg', 'gif', 'png', 'webp', 'avif', 'bmp', 'svg', 'ico']],
    ['hot_k_sound', ['mp3', 'm4a', 'ogg', 'wav']],
    ['hot_k_video', ['mp4', 'webm', 'mov', 'avi', 'mkv']],
    ['hot_k_documents', ['pdf']],
    ['hot_k_archives', ['zip', 'rar', '7z', 'gz']]
  ];
  /* what is protected when the page is first turned on */
  var FIRST_KINDS = ['jpg', 'jpeg', 'gif', 'png', 'webp'];
  var PATH_RE = /^\/[A-Za-z0-9._~%/-]*$/;
  var ADDRESS_RE = /^[0-9A-Fa-f:./-]{2,100}$/;
  var EXT_RE = /^[a-z0-9]{1,16}$/;
  var TYPE_RE = /^[a-z0-9.+-]+\/[a-z0-9.+-]+$/;
  var FOLDERS_SHOWN = 200;
  /* what a file ending can do (file handlers) and the kinds of file whose keeping time can be set, with the times (optimise) */
  var HANDLERS = ['php', 'plain'];
  var CACHE_KINDS = ['images', 'styles_scripts', 'fonts'];
  var CACHE_AGES = ['hour', 'day', 'week', 'month', 'year'];

  var cur = null;   /* the page being shown: its frame, the account's sites, the site picked and what the server says about it */

  function str(v) { return typeof v === 'string' ? v : ''; }
  function num(v) { return typeof v === 'number' && isFinite(v) ? v : 0; }
  function obj(v) { return v && typeof v === 'object' && !Array.isArray(v) ? v : {}; }
  function strs(v) { return (Array.isArray(v) ? v : []).filter(function (s) { return typeof s === 'string' && s; }); }
  /* a PUT answers with the part it changed; a whole document is read the same way */
  function partOf(r, key) { return obj(r)[key] && typeof r[key] === 'object' ? r[key] : r; }

  function cleanIp(p) {
    p = obj(p);
    return {readable: p.readable !== false, entries: strs(p.entries), max: num(p.max) || 500};
  }
  function cleanPages(p, was) {
    p = obj(p);
    var pages = {};
    Object.keys(obj(p.pages)).forEach(function (k) {
      if (/^[0-9]{3}$/.test(k) && typeof p.pages[k] === 'string') { pages[k] = p.pages[k]; }
    });
    var statuses = (Array.isArray(p.statuses) ? p.statuses : []).filter(function (n) { return typeof n === 'number' && n >= 400 && n <= 599 && n % 1 === 0; });
    return {readable: p.readable !== false, pages: pages, statuses: statuses.length ? statuses : (was ? was.statuses : [])};
  }
  function cleanListing(p) {
    p = obj(p);
    return {readable: p.readable !== false, mode: p.mode === 'off' || p.mode === 'on' ? p.mode : 'default'};
  }
  function cleanHot(p, was) {
    p = obj(p);
    var available = strs(p.available_extensions);
    return {readable: p.readable !== false, enabled: p.enabled === true, hosts: strs(p.hosts), extensions: strs(p.extensions),
      allowEmpty: p.allow_empty !== false, redirect: str(p.redirect), maxHosts: num(p.max_hosts) || 50,
      available: available.length ? available : (was ? was.available : [])};
  }
  function cleanTypes(p) {
    p = obj(p);
    return {readable: p.readable !== false, max: num(p.max) || 100, types: (Array.isArray(p.types) ? p.types : []).filter(function (x) {
      return x && typeof x.extension === 'string' && x.extension && typeof x.type === 'string' && x.type;
    }).map(function (x) { return {extension: x.extension, type: x.type}; })};
  }
  function cleanHandlers(p) {
    p = obj(p);
    return {readable: p.readable !== false, max: num(p.max) || 20, stale: p.stale === true, handlers: (Array.isArray(p.handlers) ? p.handlers : []).filter(function (x) {
      return x && typeof x === 'object' && EXT_RE.test(str(x.extension)) && HANDLERS.indexOf(x.handler) >= 0;
    }).map(function (x) { return {extension: x.extension, handler: x.handler}; })};
  }
  function cleanOptimize(p) {
    p = obj(p);
    var cache = {};
    Object.keys(obj(p.cache)).forEach(function (k) {
      if (CACHE_KINDS.indexOf(k) >= 0 && CACHE_AGES.indexOf(p.cache[k]) >= 0) { cache[k] = p.cache[k]; }
    });
    return {readable: p.readable !== false, compress: p.compress === true, cache: cache};
  }
  function cleanRules(r) {
    r = obj(r);
    return {file: str(r.file), exists: r.exists === true, ip: cleanIp(r.ip_blocker), pages: cleanPages(r.error_pages),
      listing: cleanListing(r.listing), hot: cleanHot(r.hotlink), types: cleanTypes(r.file_types),
      handlers: cleanHandlers(r.handlers), optimize: cleanOptimize(r.optimize)};
  }

  function live(v, mine) { return cur === v && mine === v.loads; }
  function args(v) { return {name: v.account, domain: v.domain}; }
  /* the site's rules as the server has them now */
  function fresh(v, site) {
    return FP.call('get', 'siteRules', undefined, site || args(v)).then(cleanRules);
  }
  function put(v, rule, body, site) {
    site = site || args(v);
    return FP.call('put', 'siteRule', body, {name: site.name, domain: site.domain, rule: rule}).then(function (r) {
      if (v.rules && v.domain === site.domain) { v.rules.exists = true; }   /* the first change makes the file */
      return r;
    });
  }
  /* one change to a list: read the rules afresh, let make(now) say what to send (or throw a failure to stop), send it.
     Resolves with the fresh rules and the server's answer; a failure carries the fresh rules as .now once they were read.
     The site is the one shown when the change starts: picking another while the read is out does not move the write there. */
  function change(v, rule, make) {
    var site = args(v);
    return fresh(v, site).then(function (now) {
      var body = make(now);
      return put(v, rule, body, site).then(function (answer) { return {now: now, answer: answer}; }, function (err) { err.now = now; throw err; });
    });
  }
  /* what the page says when the server refuses: its words, and where to mend a file it can't read. The server's words for a
     value finish a sentence ("is not an address…", "must be a path…"), so they follow the value they are about. */
  function wording(err, value) {
    if (err.status === 422 && err.field) {
      return value ? t('rules_value_of', {value: value.slice(0, 80), message: err.message}) : err.message.charAt(0).toUpperCase() + err.message.slice(1);
    }
    return err.status === 409 && !err.own ? err.message + ' ' + t('rules_use_files') : err.message;
  }
  function unreadable(v) {
    return {status: 409, own: true, message: t('rules_unreadable', {file: v.rules.file})};
  }

  /* ---- the page ---- */
  function loadCard(v) {
    var node = M.card('fp-rules-load-h', t(v.spec.title, {domain: v.domain}), [M.errorLine(),
      v.problem ? null : el('p', {class: 'fp-muted', text: t('loading')})], 'fp-rules-card');
    if (v.problem) { UI.showError(node, v.problem); }
    return node;
  }
  /* what the page says of a rule it can't read: it was changed by hand, so only the file manager can mend it */
  function unreadableBanner(file) {
    var more = FP.tools.file_manager ? [' ', el('a', {href: '#/tool/file_manager', text: t('rules_open_files')})] : [];
    return el('div', {class: 'sig-banner sig-banner--warn', role: 'note'}, [UI.icon(FP.ui, 'ui_warning'),
      el('span', null, [t('rules_unreadable', {file: file})].concat(more))]);
  }
  function lockedCard(v, title) {
    return M.card('fp-rules-locked-h', t(title, {domain: v.domain}), [unreadableBanner(v.rules.file)], 'fp-rules-card');
  }
  /* the cards for the rules now held; opts: note and scope (what a status line says, and in which card), error, focus */
  function show(v, opts) {
    if (cur !== v) { return; }
    opts = opts || {};
    var holder = v.page.querySelector('.fp-rules-body');
    holder.textContent = '';
    v.s.kept = null;
    (v.rules ? v.spec.draw(v) : [loadCard(v)]).forEach(function (n) { holder.appendChild(n); });
    var scope = opts.scope ? holder.querySelector(opts.scope) : holder;
    if (opts.note) { M.say(scope, opts.note); }
    if (opts.error) { UI.showError(scope, opts.error); }
    if (opts.focus) {
      var f = holder.querySelector(opts.focus);
      if (f) { f.focus(); }
    }
    siteInfo(v);
  }
  function siteInfo(v) {
    var info = v.page.querySelector('[data-fp-site-info]');
    if (!info) { return; }
    info.textContent = !v.rules || v.spec.info === false ? '' : t(v.rules.exists ? 'rules_in_file' : 'rules_in_new', {file: v.rules.file});
  }
  function siteCard(v) {
    var pick = el('select', {class: 'sig-select', id: 'fp-rules-site', 'aria-describedby': 'fp-rules-site-hint'}, v.sites.map(function (s) {
      return el('option', {value: s.domain, text: s.domain});
    }));
    pick.value = v.domain;
    pick.addEventListener('change', function () {
      v.domain = pick.value;
      load(v);
    });
    return M.card('fp-rules-site-h', t('rules_site_title'), [el('div', {class: 'sig-field fp-rules-site'}, [
      el('label', {class: 'sig-label', for: 'fp-rules-site', text: t('rules_site')}), pick,
      el('span', {class: 'sig-hint', id: 'fp-rules-site-hint', text: t('rules_site_hint')})]),
    el('p', {class: 'fp-muted', 'data-fp-site-info': '', text: ''})]);
  }
  function load(v) {
    var mine = ++v.loads;
    v.rules = null;
    v.problem = '';
    v.s = {};
    show(v);
    FP.call('get', 'siteRules', undefined, args(v)).then(function (r) {
      if (!live(v, mine)) { return; }
      v.rules = cleanRules(r);
      if (v.spec.start) { v.spec.start(v); } else { show(v); }
    }, function (err) {
      if (!live(v, mine)) { return; }
      v.problem = err.message;
      show(v);
    });
  }

  /* a question in place of a row's buttons, and the buttons back when it is not confirmed */
  function ask(v, cell, question, act, yes) {
    unask(v, true);
    v.s.kept = {cell: cell, kids: [].slice.call(cell.childNodes)};
    M.confirmIn(cell, question, act, yes);
  }
  function unask(v, quiet) {
    var k = v.s.kept;
    if (!k) { return; }
    v.s.kept = null;
    k.cell.textContent = '';
    k.kids.forEach(function (n) { k.cell.appendChild(n); });
    var b = k.cell.querySelector('button');
    if (b && !quiet) { b.focus(); }
  }
  /* the words typed in a box, split on spaces, commas, semicolons and new lines */
  function words(text) { return text.split(/[\s,;]+/).filter(Boolean); }
  function tableOf(heading, cls, cols, rows) {
    return el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': heading}, [
      el('table', {class: 'sig-table fp-mail-table ' + cls}, [el('thead', null, [el('tr', null, cols.map(function (c) {
        return c ? el('th', {scope: 'col', text: c}) : el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})]);
      }))]), el('tbody', null, rows)])]);
  }
  function removeCell(act, label, text) {
    return el('td', {class: 'fp-mail-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button',
      'data-fp-act': act, 'aria-label': label, text: text})]);
  }

  /* ================= Block IP addresses ================= */
  function ipDraw(v) {
    if (!v.rules.ip.readable) { return [lockedCard(v, 'ipb_title')]; }
    return (v.suspended ? [] : [ipAddCard(v)]).concat([ipListCard(v)]);
  }
  function ipAddCard(v) {
    var area = el('textarea', {class: 'sig-input sig-mono', id: 'fp-ip-add', name: 'entries', rows: '3', maxlength: '30000', autocomplete: 'off',
      spellcheck: 'false', autocapitalize: 'none'});
    var form = el('form', {class: 'fp-form fp-rules-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-ip-add', t('ipb_label'), area, t('ipb_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('ipb_block')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var given = words(area.value);
      if (!given.length) { M.fieldError(form, area, t('ipb_none')); return; }
      for (var i = 0; i < given.length; i++) {
        if (!ADDRESS_RE.test(given[i])) { M.fieldError(form, area, t('ipb_bad', {entry: given[i].slice(0, 60)})); return; }
      }
      UI.setBusy(b, true);
      var mine = v.loads;
      change(v, 'ip-blocker', function (now) {
        if (!now.ip.readable) { throw unreadable(v); }
        return {entries: now.ip.entries.concat(given)};
      }).then(function (x) {
        if (!live(v, mine)) { return; }
        v.rules.ip = cleanIp(partOf(x.answer, 'ip_blocker'));
        show(v, {note: t('ipb_saved', {count: v.rules.ip.entries.length}), scope: '.fp-ip-add', focus: '#fp-ip-add'});
      }, function (err) {
        if (!live(v, mine)) { return; }
        UI.setBusy(b, false);
        var at = /^entries\.([0-9]+)$/.exec(err.field || '');
        M.fieldError(form, area, wording(err, at && err.now ? given[Number(at[1]) - err.now.ip.entries.length] : ''));
      });
    });
    return M.card('fp-ip-add-h', t('ipb_add_title'), [el('p', {class: 'fp-muted', text: t('ipb_add_desc')}), form], 'fp-rules-card fp-ip-add');
  }
  function ipListCard(v) {
    var ip = v.rules.ip;
    var parts = [M.errorLine(), M.statusLine()];
    if (!ip.entries.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('ipb_empty')}));
    } else {
      parts.push(el('p', {class: 'fp-muted', text: t('ipb_count', {count: ip.entries.length, max: ip.max})}));
      parts.push(tableOf('fp-ip-list-h', 'fp-ip-table', [t('ipb_col_entry'), ''], ip.entries.map(function (entry) {
        return el('tr', {'data-fp-entry': entry}, [el('th', {scope: 'row', class: 'fp-mail-name sig-mono', text: entry}),
          v.suspended ? el('td') : removeCell('unblock', t('ipb_unblock_of', {entry: entry}), t('ipb_unblock'))]);
      })));
    }
    parts.push(el('p', {class: 'fp-muted fp-row-note', text: t('ipb_note')}));
    return M.card('fp-ip-list-h', t('ipb_list_title'), parts, 'fp-rules-card fp-ip-list');
  }
  function ipClick(v, act, button) {
    var tr = button.closest('tr');
    var entry = tr ? tr.getAttribute('data-fp-entry') : '';
    if (act === 'unblock') {
      ask(v, tr.querySelector('.fp-mail-acts'), t('ipb_unblock_ask', {entry: entry}), 'unblock-yes', t('ipb_unblock'));
    } else if (act === 'unblock-yes') {
      var mine = v.loads;
      UI.setBusy(button, true);
      change(v, 'ip-blocker', function (now) {
        if (!now.ip.readable) { throw unreadable(v); }
        return {entries: now.ip.entries.filter(function (e) { return e !== entry; })};
      }).then(function (x) {
        if (!live(v, mine)) { return; }
        v.rules.ip = cleanIp(partOf(x.answer, 'ip_blocker'));
        show(v, {note: t('ipb_removed', {entry: entry}), scope: '.fp-ip-list', focus: '#fp-ip-list-h'});
      }, function (err) {
        if (!live(v, mine)) { return; }
        unask(v);
        UI.showError(v.page.querySelector('.fp-ip-list'), wording(err));
      });
    }
  }

  /* ================= Folder listing ================= */
  function dirname(file) {
    var i = file.lastIndexOf('/');
    return i > 0 ? file.slice(0, i) : '';
  }
  /* a folder of the site as the file manager names it: from the home folder */
  function homePath(v, rel) {
    var root = dirname(v.rules.file);
    return (rel.length ? (root ? root + '/' : '') + rel.join('/') : root) || '.';
  }
  function flsStart(v) {
    flsGo(v, [], '');
  }
  /* shows a folder of the site: its setting and the folders inside it */
  function flsGo(v, rel, focus) {
    var s = v.s;
    var mine = v.loads;
    s.nav = (s.nav || 0) + 1;
    var n = s.nav;
    s.rel = rel;
    s.view = null;
    s.folders = null;
    s.problem = '';
    s.foldersProblem = '';
    show(v, {focus: focus});
    var path = rel.join('/');
    var read = path ? FP.call('get', 'siteListing', undefined, {name: v.account, domain: v.domain, path: path}) :
      FP.call('get', 'siteRule', undefined, {name: v.account, domain: v.domain, rule: 'listing'});
    var inside = FP.call('get', 'files', undefined, {name: v.account, path: homePath(v, rel)});
    Promise.all([
      read.then(function (r) { return {view: cleanListing(r)}; }, function (err) { return {problem: err.message}; }),
      inside.then(function (r) {
        var list = (Array.isArray(obj(r).entries) ? r.entries : []).filter(function (e) {
          return e && e.type === 'folder' && typeof e.name === 'string' && e.name;
        }).map(function (e) { return e.name; }).sort();
        return {folders: list};
      }, function (err) { return {problem: err.message}; })
    ]).then(function (got) {
      if (!live(v, mine) || n !== s.nav) { return; }
      s.view = got[0].view || null;
      s.problem = got[0].problem || '';
      s.folders = got[1].folders || [];
      s.foldersProblem = got[1].problem || '';
      show(v, {focus: focus});
      if (focus) { UI.announce(t('fls_in', {folder: rel.length ? rel.join('/') : t('fls_root')})); }
    });
  }
  function flsDraw(v) {
    var s = v.s;
    return [flsFolderCard(v)].concat(s.view ? [flsModeCard(v)] : []);
  }
  function flsFolderCard(v) {
    var s = v.s;
    var rel = s.rel || [];
    /* each folder on the way in is a button that goes back to it; the one shown is not */
    var names = [t('fls_root')].concat(rel);
    var trail = [];
    names.forEach(function (name, depth) {
      if (depth) { trail.push(el('span', {class: 'fp-muted', 'aria-hidden': 'true', text: '/'})); }
      trail.push(depth === rel.length ? el('span', {class: 'sig-pill', 'aria-current': 'location', text: name}) :
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'cd', 'data-fp-depth': String(depth), text: name}));
    });
    var parts = [M.errorLine(), el('div', {class: 'fp-fls-trail', role: 'group', 'aria-label': t('fls_trail')}, trail)];
    if (s.folders === null) {
      parts.push(el('p', {class: 'fp-muted', text: t('loading')}));
    } else if (s.foldersProblem) {
      parts.push(el('p', {class: 'fp-muted', text: t('fls_folders_failed', {message: s.foldersProblem})}));
    } else if (!s.folders.length) {
      parts.push(el('p', {class: 'fp-muted', text: t('fls_none_inside')}));
    } else {
      parts.push(el('p', {class: 'fp-muted', id: 'fp-fls-inside', text: t('fls_inside')}));
      parts.push(el('ul', {class: 'fp-fls-folders', 'aria-labelledby': 'fp-fls-inside'}, s.folders.slice(0, FOLDERS_SHOWN).map(function (name) {
        return el('li', null, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'enter',
          'data-fp-name': name, text: name})]);
      })));
      if (s.folders.length > FOLDERS_SHOWN) { parts.push(el('p', {class: 'fp-muted fp-row-note', text: t('fls_more', {count: FOLDERS_SHOWN})})); }
    }
    var node = M.card('fp-fls-folder-h', t('fls_title', {domain: v.domain}), parts, 'fp-rules-card fp-fls-folder');
    if (s.problem) { UI.showError(node, s.problem); }
    return node;
  }
  function flsModeCard(v) {
    var s = v.s;
    var view = s.view;
    var where = s.rel.length ? s.rel.join('/') : t('fls_root');
    var title = t('fls_mode_title', {folder: where});
    if (!view.readable) { return M.card('fp-fls-mode-h', title, [unreadableBanner(filePath(v))], 'fp-rules-card fp-fls-mode'); }
    var group = el('fieldset', {class: 'fp-rules-kinds'}, [el('legend', {class: 'sig-label', text: t('fls_mode')})].concat(['default', 'off', 'on'].map(function (mode) {
      var input = el('input', {type: 'radio', id: 'fp-fls-' + mode, name: 'mode', value: mode, checked: view.mode === mode ? true : null,
        disabled: v.suspended ? true : null, 'aria-describedby': 'fp-fls-' + mode + '-hint'});
      return el('div', {class: 'fp-fls-choice'}, [el('label', {class: 'fp-check', for: 'fp-fls-' + mode}, [input, el('span', {text: t('fls_mode_' + mode)})]),
        el('span', {class: 'sig-hint', id: 'fp-fls-' + mode + '-hint', text: t('fls_mode_' + mode + '_hint')})]);
    })));
    var form = el('form', {class: 'fp-form fp-rules-form', novalidate: ''}, [M.errorLine(), M.statusLine(), group,
      v.suspended ? null : el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('fls_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var picked = form.querySelector('input[name="mode"]:checked');
      var body = {mode: picked ? picked.value : view.mode};
      if (s.rel.length) { body.path = s.rel.join('/'); }
      UI.setBusy(b, true);
      var mine = v.loads;
      var n = s.nav;
      put(v, 'listing', body).then(function (r) {
        if (!live(v, mine) || n !== s.nav) { return; }
        s.view = cleanListing(partOf(r, 'listing'));
        show(v, {note: t('fls_saved', {folder: where}), scope: '.fp-fls-mode', focus: '#fp-fls-mode-h'});
      }, function (err) {
        if (!live(v, mine) || n !== s.nav) { return; }
        UI.setBusy(b, false);
        M.fieldError(form, null, wording(err));
      });
    });
    return M.card('fp-fls-mode-h', title, [el('p', {class: 'fp-muted', text: t('fls_in_file', {file: filePath(v)})}),
      el('p', {class: 'fp-muted', text: t('fls_inherit')}), form], 'fp-rules-card fp-fls-mode');
  }
  /* the folder's .htaccess as the file manager names it */
  function filePath(v) {
    var p = homePath(v, v.s.rel || []);
    return (p === '.' ? '' : p + '/') + '.htaccess';
  }
  function flsClick(v, act, button) {
    var s = v.s;
    if (act === 'cd') {
      flsGo(v, s.rel.slice(0, Number(button.getAttribute('data-fp-depth'))), '#fp-fls-folder-h');
    } else if (act === 'enter') {
      flsGo(v, s.rel.concat([button.getAttribute('data-fp-name')]), '#fp-fls-folder-h');
    }
  }

  /* ================= Error pages ================= */
  function erpLabel(status) {
    var k = 'erp_s_' + status;
    return t(k) === k ? String(status) : status + ' ' + t(k);
  }
  function erpDraw(v) {
    var ep = v.rules.pages;
    if (!ep.readable) { return [lockedCard(v, 'erp_title')]; }
    var statuses = ep.statuses.length ? ep.statuses : STATUSES;
    var rows = statuses.map(function (status) {
      var id = 'fp-erp-' + status;
      var input = el('input', {class: 'sig-input sig-mono', id: id, name: String(status), type: 'text', value: ep.pages[status] || '', maxlength: '200',
        autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', placeholder: '/errors/' + status + '.html', disabled: v.suspended ? true : null,
        'data-fp-was': ep.pages[status] || ''});
      return M.field(id, erpLabel(status), input);
    });
    var form = el('form', {class: 'fp-form fp-rules-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-rules-grid'}, rows),
      v.suspended ? null : el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('erp_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var pages = {};
      var changed = false;
      for (var i = 0; i < statuses.length; i++) {
        var f = UI.fieldNamed(form, String(statuses[i]));
        var value = f.value.trim();
        if (value !== f.getAttribute('data-fp-was')) { changed = true; }
        if (!value) { continue; }
        var label = erpLabel(statuses[i]);
        if (/^[a-z][a-z0-9+.-]*:/i.test(value) || value.indexOf('//') === 0) { M.fieldError(form, f, t('erp_url', {label: label})); return; }
        if (!PATH_RE.test(value) || value.length > 200 || value.split('/').indexOf('..') >= 0 || value.indexOf('//') >= 0) {
          M.fieldError(form, f, t('erp_bad', {label: label}));
          return;
        }
        pages[statuses[i]] = value;
      }
      if (!changed) { M.say(form, t('erp_nothing')); return; }
      UI.setBusy(b, true);
      var mine = v.loads;
      put(v, 'error-pages', {pages: pages}).then(function (r) {
        if (!live(v, mine)) { return; }
        v.rules.pages = cleanPages(partOf(r, 'error_pages'), v.rules.pages);
        show(v, {note: t('erp_saved'), focus: '#fp-erp-h'});
      }, function (err) {
        if (!live(v, mine)) { return; }
        UI.setBusy(b, false);
        var at = /^pages\.([0-9]{3})$/.exec(err.field || '');
        var f = at ? UI.fieldNamed(form, at[1]) : null;
        M.fieldError(form, f, wording(err, f ? f.value.trim() : ''));
      });
    });
    return [M.card('fp-erp-h', t('erp_title', {domain: v.domain}), [el('p', {class: 'fp-muted', text: t('erp_intro')}), form,
      el('p', {class: 'fp-muted fp-row-note', text: t('erp_note')})], 'fp-rules-card')];
  }

  /* ================= Hotlink protection ================= */
  function hotGroups(available) {
    var left = available.slice();
    var out = KINDS.map(function (g) {
      var have = g[1].filter(function (x) { return left.indexOf(x) >= 0; });
      have.forEach(function (x) { left.splice(left.indexOf(x), 1); });
      return [g[0], have];
    });
    out.push(['hot_k_other', left]);
    return out.filter(function (g) { return g[1].length; });
  }
  function hotDraw(v) {
    var h = v.rules.hot;
    if (!h.readable) { return [lockedCard(v, 'hot_title')]; }
    var checked = h.enabled && h.extensions.length ? h.extensions : FIRST_KINDS;
    var on = el('input', {type: 'checkbox', id: 'fp-hot-on', name: 'enabled', checked: h.enabled ? true : null, disabled: v.suspended ? true : null,
      'aria-describedby': 'fp-hot-on-hint'});
    var kinds = hotGroups(h.available).map(function (g) {
      return el('fieldset', {class: 'fp-rules-kinds'}, [el('legend', {class: 'sig-label', text: t(g[0])}),
        el('div', {class: 'fp-rules-boxes'}, g[1].map(function (ext) {
          var id = 'fp-hot-k-' + ext;
          return el('label', {class: 'fp-check', for: id}, [el('input', {type: 'checkbox', id: id, name: 'extension', value: ext,
            checked: checked.indexOf(ext) >= 0 ? true : null, disabled: v.suspended ? true : null}), el('span', {class: 'sig-mono', text: '.' + ext})]);
        }))]);
    });
    var hosts = el('textarea', {class: 'sig-input sig-mono', id: 'fp-hot-hosts', name: 'hosts', rows: '3', maxlength: '15000', autocomplete: 'off',
      spellcheck: 'false', autocapitalize: 'none', disabled: v.suspended ? true : null});
    hosts.value = h.hosts.join('\n');
    var empty = el('input', {type: 'checkbox', id: 'fp-hot-empty', name: 'allow_empty', checked: h.allowEmpty ? true : null,
      disabled: v.suspended ? true : null, 'aria-describedby': 'fp-hot-empty-hint'});
    var redirect = el('input', {class: 'sig-input sig-mono', id: 'fp-hot-redirect', name: 'redirect', type: 'text', value: h.redirect, maxlength: '200',
      autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', placeholder: '/images/blocked.png', disabled: v.suspended ? true : null});
    var form = el('form', {class: 'fp-form fp-rules-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'sig-field'}, [el('label', {class: 'fp-check', for: 'fp-hot-on'}, [on, el('span', {text: t('hot_on')})]),
        el('span', {class: 'sig-hint', id: 'fp-hot-on-hint', text: t('hot_on_hint')})])]
      .concat(kinds, [
        M.field('fp-hot-hosts', t('hot_hosts'), hosts, t('hot_hosts_hint', {max: h.maxHosts})),
        el('div', {class: 'sig-field'}, [el('label', {class: 'fp-check', for: 'fp-hot-empty'}, [empty, el('span', {text: t('hot_empty')})]),
          el('span', {class: 'sig-hint', id: 'fp-hot-empty-hint', text: t('hot_empty_hint')})]),
        M.field('fp-hot-redirect', t('hot_redirect'), redirect, t('hot_redirect_hint')),
        v.suspended ? null : el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('hot_save')})])]));
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var body = {enabled: on.checked};
      if (on.checked) {
        body.extensions = [].slice.call(form.querySelectorAll('input[name="extension"]:checked')).map(function (x) { return x.value; });
        if (!body.extensions.length) { M.fieldError(form, form.querySelector('input[name="extension"]'), t('hot_kinds_none')); return; }
        body.hosts = words(hosts.value.toLowerCase()).filter(function (x, i, all) { return all.indexOf(x) === i; });
        var bad = body.hosts.filter(function (x) { return /[/:@?#*]/.test(x) || x.length > 253; })[0];
        if (bad) { M.fieldError(form, hosts, t('hot_host_bad', {host: bad.slice(0, 60)})); return; }
        if (body.hosts.length > h.maxHosts) { M.fieldError(form, hosts, t('hot_hosts_many', {max: h.maxHosts})); return; }
        body.allow_empty = empty.checked;
        var to = redirect.value.trim();
        if (to) {
          if (!PATH_RE.test(to) || to.length > 200 || to.indexOf('%') >= 0 || to.split('/').indexOf('..') >= 0 || to.indexOf('//') >= 0) {
            M.fieldError(form, redirect, t('hot_redirect_bad'));
            return;
          }
          body.redirect = to;
        }
      }
      UI.setBusy(b, true);
      var mine = v.loads;
      put(v, 'hotlink', body).then(function (r) {
        if (!live(v, mine)) { return; }
        v.rules.hot = cleanHot(partOf(r, 'hotlink'), v.rules.hot);
        show(v, {note: t(body.enabled ? 'hot_saved_on' : 'hot_saved_off'), focus: '#fp-hot-h'});
      }, function (err) {
        if (!live(v, mine)) { return; }
        UI.setBusy(b, false);
        var at = /^(extensions|hosts|redirect|enabled)(?:\.[0-9]+)?$/.exec(err.field || '');
        var f = !at ? null : at[1] === 'hosts' ? hosts : at[1] === 'redirect' ? redirect : at[1] === 'enabled' ? on : form.querySelector('input[name="extension"]');
        var n = /\.([0-9]+)$/.exec(err.field || '');
        M.fieldError(form, f, wording(err, at && at[1] === 'hosts' && n ? (body.hosts || [])[Number(n[1])] : at && at[1] === 'redirect' ? body.redirect : ''));
      });
    });
    return [M.card('fp-hot-h', t('hot_title', {domain: v.domain}), [el('p', {class: 'fp-muted', text: t('hot_intro')}), form,
      el('p', {class: 'fp-muted fp-row-note', text: t('hot_note')})], 'fp-rules-card')];
  }

  /* ================= File types ================= */
  function typesDraw(v) {
    if (!v.rules.types.readable) { return [lockedCard(v, 'mim_title')]; }
    return (v.suspended ? [] : [typesAddCard(v)]).concat([typesListCard(v)]);
  }
  function typesAddCard(v) {
    var ext = el('input', {class: 'sig-input sig-mono', id: 'fp-mim-ext', name: 'extension', type: 'text', maxlength: '17', autocomplete: 'off',
      spellcheck: 'false', autocapitalize: 'none', placeholder: 'webp'});
    var type = el('input', {class: 'sig-input sig-mono', id: 'fp-mim-type', name: 'type', type: 'text', maxlength: '100', autocomplete: 'off',
      spellcheck: 'false', autocapitalize: 'none', placeholder: 'image/webp'});
    var form = el('form', {class: 'fp-form fp-rules-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-rules-grid'}, [M.field('fp-mim-ext', t('mim_ext'), ext, t('mim_ext_hint')), M.field('fp-mim-type', t('mim_type'), type, t('mim_type_hint'))]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('mim_add')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var extension = ext.value.trim().toLowerCase().replace(/^\./, '');
      var kind = type.value.trim().toLowerCase();
      if (!EXT_RE.test(extension)) { M.fieldError(form, ext, t('mim_ext_bad')); return; }
      if (!TYPE_RE.test(kind) || kind.length > 100) { M.fieldError(form, type, t('mim_type_bad')); return; }
      if (/httpd|php|cgi/.test(kind)) { M.fieldError(form, type, t('mim_type_runs', {type: kind})); return; }
      UI.setBusy(b, true);
      var mine = v.loads;
      var sent = [];
      change(v, 'file-types', function (now) {
        if (!now.types.readable) { throw unreadable(v); }
        sent = now.types.types.filter(function (x) { return x.extension !== extension; }).concat([{extension: extension, type: kind}]);
        return {types: sent};
      }).then(function (x) {
        if (!live(v, mine)) { return; }
        v.rules.types = cleanTypes(partOf(x.answer, 'file_types'));
        show(v, {note: t('mim_saved', {extension: extension, type: kind}), scope: '.fp-mim-add', focus: '#fp-mim-ext'});
      }, function (err) {
        if (!live(v, mine)) { return; }
        UI.setBusy(b, false);
        var at = /^types\.([0-9]+)\.(extension|type)$/.exec(err.field || '');
        var ours = at && Number(at[1]) === sent.length - 1;
        M.fieldError(form, at ? (at[2] === 'type' ? type : ext) : null, wording(err, ours ? (at[2] === 'type' ? kind : extension) : ''));
      });
    });
    return M.card('fp-mim-add-h', t('mim_add_title'), [el('p', {class: 'fp-muted', text: t('mim_add_desc')}), form], 'fp-rules-card fp-mim-add');
  }
  function typesListCard(v) {
    var ty = v.rules.types;
    var parts = [M.errorLine(), M.statusLine()];
    if (!ty.types.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('mim_empty')}));
    } else {
      parts.push(el('p', {class: 'fp-muted', text: t('mim_count', {count: ty.types.length, max: ty.max})}));
      parts.push(tableOf('fp-mim-list-h', 'fp-mim-table', [t('mim_col_ext'), t('mim_col_type'), ''], ty.types.map(function (x) {
        return el('tr', {'data-fp-ext': x.extension, 'data-fp-kind': x.type}, [el('th', {scope: 'row', class: 'fp-mail-name sig-mono', text: '.' + x.extension}),
          el('td', {class: 'sig-mono', text: x.type}),
          v.suspended ? el('td') : removeCell('forget', t('mim_remove_of', {extension: x.extension}), t('mim_remove'))]);
      })));
    }
    return M.card('fp-mim-list-h', t('mim_list_title'), parts, 'fp-rules-card fp-mim-list');
  }
  function typesClick(v, act, button) {
    var tr = button.closest('tr');
    var extension = tr ? tr.getAttribute('data-fp-ext') : '';
    if (act === 'forget') {
      ask(v, tr.querySelector('.fp-mail-acts'), t('mim_remove_ask', {extension: extension, type: tr.getAttribute('data-fp-kind')}), 'forget-yes', t('mim_remove'));
    } else if (act === 'forget-yes') {
      var mine = v.loads;
      UI.setBusy(button, true);
      change(v, 'file-types', function (now) {
        if (!now.types.readable) { throw unreadable(v); }
        return {types: now.types.types.filter(function (x) { return x.extension !== extension; })};
      }).then(function (x) {
        if (!live(v, mine)) { return; }
        v.rules.types = cleanTypes(partOf(x.answer, 'file_types'));
        show(v, {note: t('mim_removed', {extension: extension}), scope: '.fp-mim-list', focus: '#fp-mim-list-h'});
      }, function (err) {
        if (!live(v, mine)) { return; }
        unask(v);
        UI.showError(v.page.querySelector('.fp-mim-list'), wording(err));
      });
    }
  }

  /* ================= File handlers ================= */
  function handlersDraw(v) {
    if (!v.rules.handlers.readable) { return [lockedCard(v, 'fhd_title')]; }
    return (v.suspended ? [] : [handlersAddCard(v)]).concat([handlersListCard(v)]);
  }
  function handlersAddCard(v) {
    var ext = el('input', {class: 'sig-input sig-mono', id: 'fp-fhd-ext', name: 'extension', type: 'text', maxlength: '17', autocomplete: 'off',
      spellcheck: 'false', autocapitalize: 'none', placeholder: 'html'});
    var what = el('select', {class: 'sig-select', id: 'fp-fhd-what', name: 'handler'}, HANDLERS.map(function (h) {
      return el('option', {value: h, text: t('fhd_' + h)});
    }));
    var form = el('form', {class: 'fp-form fp-rules-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-rules-grid'}, [M.field('fp-fhd-ext', t('fhd_ext'), ext, t('fhd_ext_hint')), M.field('fp-fhd-what', t('fhd_what'), what, t('fhd_what_hint'))]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('fhd_add')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var extension = ext.value.trim().toLowerCase().replace(/^\./, '');
      var handler = what.value;
      if (!EXT_RE.test(extension)) { M.fieldError(form, ext, t('fhd_ext_bad')); return; }
      UI.setBusy(b, true);
      var mine = v.loads;
      var sent = [];
      change(v, 'handlers', function (now) {
        if (!now.handlers.readable) { throw unreadable(v); }
        sent = now.handlers.handlers.filter(function (x) { return x.extension !== extension; }).concat([{extension: extension, handler: handler}]);
        return {handlers: sent};
      }).then(function (x) {
        if (!live(v, mine)) { return; }
        v.rules.handlers = cleanHandlers(x.answer);
        show(v, {note: t('fhd_saved_' + handler, {extension: extension}), scope: '.fp-fhd-add', focus: '#fp-fhd-ext'});
      }, function (err) {
        if (!live(v, mine)) { return; }
        UI.setBusy(b, false);
        var at = /^handlers\.([0-9]+)\.(extension|handler)$/.exec(err.field || '');
        M.fieldError(form, at ? (at[2] === 'handler' ? what : ext) : null, wording(err, ''));
      });
    });
    return M.card('fp-fhd-add-h', t('fhd_add_title'), [el('p', {class: 'fp-muted', text: t('fhd_add_desc')}), form], 'fp-rules-card fp-fhd-add');
  }
  function handlersListCard(v) {
    var hs = v.rules.handlers;
    var parts = [M.errorLine(), M.statusLine()];
    if (!hs.handlers.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('fhd_empty')}));
    } else {
      /* the server says these endings still name the pool of the site's old PHP version: saving them again moves them */
      if (hs.stale) {
        parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-stale': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('fhd_stale')})]));
        if (!v.suspended) {
          parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'renew', text: t('fhd_renew')})]));
        }
      }
      parts.push(el('p', {class: 'fp-muted', text: t('fhd_count', {count: hs.handlers.length, max: hs.max})}));
      parts.push(tableOf('fp-fhd-list-h', 'fp-fhd-table', [t('fhd_col_ext'), t('fhd_col_what'), ''], hs.handlers.map(function (x) {
        return el('tr', {'data-fp-ext': x.extension, 'data-fp-handler': x.handler}, [el('th', {scope: 'row', class: 'fp-mail-name sig-mono', text: '.' + x.extension}),
          el('td', {text: t('fhd_' + x.handler)}),
          v.suspended ? el('td') : removeCell('unset', t('fhd_remove_of', {extension: x.extension}), t('fhd_remove'))]);
      })));
    }
    return M.card('fp-fhd-list-h', t('fhd_list_title'), parts, 'fp-rules-card fp-fhd-list');
  }
  function handlersClick(v, act, button) {
    var tr = button.closest('tr');
    var extension = tr ? tr.getAttribute('data-fp-ext') : '';
    if (act === 'renew') {
      var again = v.loads;
      UI.setBusy(button, true);
      change(v, 'handlers', function (now) {
        if (!now.handlers.readable) { throw unreadable(v); }
        return {handlers: now.handlers.handlers};
      }).then(function (x) {
        if (!live(v, again)) { return; }
        v.rules.handlers = cleanHandlers(x.answer);
        show(v, {note: t('fhd_renewed'), scope: '.fp-fhd-list', focus: '#fp-fhd-list-h'});
      }, function (err) {
        if (!live(v, again)) { return; }
        UI.setBusy(button, false);
        UI.showError(v.page.querySelector('.fp-fhd-list'), wording(err));
      });
    } else if (act === 'unset') {
      ask(v, tr.querySelector('.fp-mail-acts'), t('fhd_remove_ask', {extension: extension}), 'unset-yes', t('fhd_remove'));
    } else if (act === 'unset-yes') {
      var mine = v.loads;
      UI.setBusy(button, true);
      change(v, 'handlers', function (now) {
        if (!now.handlers.readable) { throw unreadable(v); }
        return {handlers: now.handlers.handlers.filter(function (x) { return x.extension !== extension; })};
      }).then(function (x) {
        if (!live(v, mine)) { return; }
        v.rules.handlers = cleanHandlers(x.answer);
        show(v, {note: t('fhd_removed', {extension: extension}), scope: '.fp-fhd-list', focus: '#fp-fhd-list-h'});
      }, function (err) {
        if (!live(v, mine)) { return; }
        unask(v);
        UI.showError(v.page.querySelector('.fp-fhd-list'), wording(err));
      });
    }
  }

  /* ================= Optimize ================= */
  function optimizeDraw(v) {
    var o = v.rules.optimize;
    if (!o.readable) { return [lockedCard(v, 'oz_title')]; }
    var off = v.suspended ? true : null;
    var compress = el('input', {type: 'checkbox', id: 'fp-oz-compress', name: 'compress', checked: o.compress ? true : null, disabled: off, 'aria-describedby': 'fp-oz-compress-hint'});
    var picks = CACHE_KINDS.map(function (k) {
      var id = 'fp-oz-' + k.replace('_', '-');
      var pick = el('select', {class: 'sig-select', id: id, name: k, disabled: off}, [el('option', {value: '', text: t('oz_age_none')})].concat(CACHE_AGES.map(function (a) {
        return el('option', {value: a, text: t('oz_age_' + a)});
      })));
      pick.value = o.cache[k] || '';
      return M.field(id, t('oz_kind_' + k), pick, t('oz_kind_' + k + '_hint'));
    });
    var form = el('form', {class: 'fp-form fp-rules-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'sig-field'}, [el('label', {class: 'fp-check', for: 'fp-oz-compress'}, [compress, el('span', {text: t('oz_compress')})]),
        el('span', {class: 'sig-hint', id: 'fp-oz-compress-hint', text: t('oz_compress_hint')})]),
      el('h3', {class: 'fp-h3', text: t('oz_cache_title')}), el('p', {class: 'fp-muted', text: t('oz_cache_desc')})]
      .concat(picks, [v.suspended ? null : el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('oz_save')})])]));
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var body = {compress: compress.checked, cache: {}};
      form.querySelectorAll('select').forEach(function (sel) {
        if (sel.value) { body.cache[sel.name] = sel.value; }
      });
      UI.setBusy(b, true);
      var mine = v.loads;
      put(v, 'optimize', body).then(function (r) {
        if (!live(v, mine)) { return; }
        v.rules.optimize = cleanOptimize(r);
        show(v, {note: t(body.compress || Object.keys(body.cache).length ? 'oz_saved' : 'oz_saved_off'), focus: '#fp-oz-h'});
      }, function (err) {
        if (!live(v, mine)) { return; }
        UI.setBusy(b, false);
        var at = /^cache\.(images|styles_scripts|fonts)$/.exec(err.field || '');
        M.fieldError(form, at ? form.querySelector('select[name="' + at[1] + '"]') : null, wording(err, ''));
      });
    });
    return [M.card('fp-oz-h', t('oz_title', {domain: v.domain}), [el('p', {class: 'fp-muted', text: t('oz_intro')}), form,
      el('p', {class: 'fp-muted fp-row-note', text: t('oz_note')})], 'fp-rules-card')];
  }

  var SPECS = {
    ip_blocker: {desc: 'ipb_desc', title: 'ipb_title', draw: ipDraw, click: ipClick},
    folder_listing: {desc: 'fls_desc', title: 'fls_title', info: false, start: flsStart, draw: flsDraw, click: flsClick},
    error_pages: {desc: 'erp_desc', title: 'erp_title', draw: erpDraw},
    hotlink: {desc: 'hot_desc', title: 'hot_title', draw: hotDraw},
    mime_types: {desc: 'mim_desc', title: 'mim_title', draw: typesDraw, click: typesClick},
    file_handlers: {desc: 'fhd_desc', title: 'fhd_title', draw: handlersDraw, click: handlersClick},
    optimize_site: {desc: 'oz_desc', title: 'oz_title', draw: optimizeDraw}
  };

  Object.keys(SPECS).forEach(function (id) {
    FP.view('tool:' + id, function () {
      var tool = FP.tools[id];
      if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
      var g = FP.group(tool.group);
      var v = {spec: SPECS[id], account: FP.account(), sites: [], suspended: false, domain: '', rules: null, problem: '', loads: 0, s: {}, page: null};
      cur = v;
      v.page = FP.frame({title: tool.label, desc: t(v.spec.desc), cls: 'fp-mail fp-rules',
        crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
      v.page.addEventListener('click', function (e) {
        var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
        if (!b || cur !== v) { return; }
        var act = b.getAttribute('data-fp-act');
        if (act === 'confirm-no') { unask(v); } else if (v.spec.click && v.rules) { v.spec.click(v, act, b); }
      });
      v.page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
      FP.call('get', 'domains', undefined, v.account).then(function (r) {
        if (cur !== v) { return; }
        var d = FP.cleanSites(r);
        v.sites = d.sites;
        v.suspended = d.suspended;
        v.page.textContent = '';
        if (!v.sites.length) {
          v.page.appendChild(FP.empty(t('rules_no_sites_title'), t('rules_no_sites')));
          return;
        }
        if (v.suspended) { v.page.appendChild(M.suspendedBanner(t('rules_suspended'))); }
        v.domain = v.sites[0].domain;
        v.page.appendChild(siteCard(v));
        v.page.appendChild(el('div', {class: 'fp-rules-body'}));
        load(v);
      }, function (err) {
        if (cur !== v) { return; }
        v.page.textContent = '';
        v.page.appendChild(FP.empty(tool.label, err.message));
      });
    });
  });
})();

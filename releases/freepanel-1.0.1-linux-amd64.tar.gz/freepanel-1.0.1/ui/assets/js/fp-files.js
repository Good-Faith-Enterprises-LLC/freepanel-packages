/* freePanel file manager (#/tool/file_manager), the customer panel's page for the account's own files (docs/api.md,
   "File manager"): the folder being looked at with the way back up, a list of what is in it with what can be done to
   each, forms to make, upload, rename, move, copy, compress, extract and set permissions, a search by name, a text
   editor, and the trash. Every operation runs on the server as the account itself. Names, link targets and the server's
   messages are shown as text only. Copying, moving, deleting, compressing, extracting, searching and emptying the trash
   can take minutes on a big folder, so those calls keep waiting. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;

  var TYPES = {file: true, folder: true, link: true, other: true};
  var MAX_TEXT = 10 * 1024 * 1024;
  var HIDDEN_KEY = 'fp.files.hidden';
  /* the permission boxes, in the order the three digits read */
  var WHO = ['owner', 'group', 'others'];
  var BITS = [['read', 4], ['write', 2], ['run', 1]];
  /* the endings the server makes archives with, and the ones it unpacks (it checks what a file holds, not its name) */
  var PACK_END = /\.(zip|tar\.gz|tgz)$/i;
  var UNPACK_END = /\.(zip|tar|tar\.gz|tgz|tar\.bz2|tbz2|tbz|gz|bz2)$/i;

  var page = null;    /* the frame's body */
  var account = '';
  var cwd = '';       /* the folder looked at, relative to the home; '' is the home */
  var listing = null; /* {path, truncated, entries} as last read */
  var hidden = false;
  var suspended = false;
  var mode = 'list';  /* list, edit or trash */
  var action = null;  /* the open form: {kind, entry} */
  var opened = null;  /* the file in the editor: {path, text, crlf, readOnly} */
  var trashList = null;
  var found = null;   /* the last search: {q, path, entries, truncated, timedOut}, until cleared or the page is left */

  function str(v) { return typeof v === 'string' ? v : ''; }
  function num(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? v : null; }
  function join(a, b) { return a ? a + '/' + b : b; }
  function parent(p) { return p.indexOf('/') >= 0 ? p.slice(0, p.lastIndexOf('/')) : ''; }
  function base(p) { return p.slice(p.lastIndexOf('/') + 1); }
  /* a path for the API: the home is '.', since a path can't be empty in a call */
  function apiPath(p) { return p || '.'; }
  /* a name the server takes for something new: one path part, at most 255 bytes, no control characters but tab */
  function nameProblem(n) {
    if (!n || n === '.' || n === '..') { return t('fm_name_need'); }
    if (n.indexOf('/') >= 0) { return t('fm_name_slash'); }
    /* eslint-disable-next-line no-control-regex */
    if (/[\u0000-\u0008\u000a-\u001f\u007f]/.test(n)) { return t('fm_name_control'); }
    if (new window.TextEncoder().encode(n).length > 255) { return t('fm_name_long'); }
    return '';
  }

  function entryOf(e) {
    if (!e || typeof e !== 'object' || !TYPES[e.type]) { return null; }
    var name = str(e.name);
    if (!name || name.indexOf('/') >= 0 || name === '.' || name === '..' || name.length > 1024) { return null; }
    return {name: name, type: e.type, size: num(e.size), mode: /^0?[0-7]{3}$/.test(str(e.mode)) ? str(e.mode).slice(-3) : '',
      modified: num(e.modified), target: str(e.target), targetType: str(e.target_type),
      from: str(e.from), trashed: num(e.trashed)};
  }
  function entriesOf(list) {
    return (Array.isArray(list) ? list : []).map(entryOf).filter(Boolean);
  }
  /* sizes the way hosting panels show them: binary steps named KB, MB, GB, TB */
  var UNITS = ['KB', 'MB', 'GB', 'TB', 'PB'];
  function size(n) {
    if (n === null) { return '—'; }
    if (n < 1024) { return t('size_bytes', {n: String(Math.round(n))}); }
    var u = -1;
    do { n /= 1024; u++; } while (n >= 1024 && u < UNITS.length - 1);
    return (n < 10 ? n.toFixed(1) : Math.round(n).toLocaleString('en')) + ' ' + UNITS[u];
  }
  function when(sec) {
    if (sec === null) { return '—'; }
    var d = new Date(sec * 1000);
    return isNaN(d.getTime()) ? '—' : d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'});
  }
  function where(p) { return p ? '/' + p : t('fm_home'); }
  function itemPath(e) { return join(cwd, e.name); }
  /* a folder to open: a folder, or a link the server says leads to one */
  function isFolder(e) { return e.type === 'folder' || (e.type === 'link' && e.targetType === 'folder'); }
  function isFile(e) { return e.type === 'file' || (e.type === 'link' && e.targetType === 'file'); }

  /* the server's words, with ours for being busy and for a suspended account */
  function message(err) {
    if (err && err.code === 'rate_limited') { return t('fm_busy'); }
    if (err && err.code === 'account_suspended') { return t('fm_suspended_change'); }
    return err && err.message ? err.message : t('api_failed');
  }
  function downloadHref(p) {
    return '/api/v1/accounts/' + encodeURIComponent(account) + '/files/download?path=' + encodeURIComponent(p);
  }

  /* ---- page pieces ---- */
  function card(id, title, children, cls) {
    return el('section', {class: 'sig-card fp-fm-card' + (cls ? ' ' + cls : ''), 'aria-labelledby': id}, [el('div', {class: 'sig-card-body'},
      [el('h2', {class: 'fp-h2', id: id, tabindex: '-1', text: title})].concat(children))]);
  }
  function errorLine() { return el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': ''}); }
  function statusLine() { return el('p', {class: 'fp-ok-line', role: 'status', 'data-fp-status': ''}); }
  function say(scope, text) {
    var s = scope && scope.querySelector('[data-fp-status]');
    if (s) { s.textContent = text || ''; }
  }
  function input(id, label, attrs, hint) {
    var hintId = hint ? id + '-hint' : null;
    return el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: id, text: label}),
      el('input', Object.assign({class: 'sig-input', id: id, 'aria-describedby': hintId}, attrs)),
      hint ? el('span', {class: 'sig-hint', id: hintId, text: hint}) : null]);
  }
  function button(text, act, kind, extra) {
    return el('button', Object.assign({class: 'sig-btn sig-btn--' + (kind || 'secondary'), type: 'button', 'data-fp-act': act, text: text}, extra || {}));
  }
  function fieldError(form, f, text) {
    UI.showError(form, text);
    if (!f) { return; }
    f.setAttribute('aria-invalid', 'true');
    f.focus({preventScroll: true});
    var line = form.querySelector('[data-fp-error]');
    if (line && line.scrollIntoView) { line.scrollIntoView({block: 'nearest'}); }
  }
  function failed(form, err) {
    var f = err && err.field ? form.querySelector('[name="' + (window.CSS && window.CSS.escape ? window.CSS.escape(err.field) : err.field.replace(/[^a-z_]/g, '')) + '"]') : null;
    if (err && err.code === 'account_suspended') { suspended = true; }
    fieldError(form, f, message(err));
  }
  function clearInvalid(form) {
    var bad = form.querySelectorAll('[aria-invalid]');
    for (var i = 0; i < bad.length; i++) { bad[i].removeAttribute('aria-invalid'); }
  }
  function focusHeading(id) {
    var h = page.querySelector('#' + id);
    if (h) { h.focus(); }
  }

  /* ---- where we are ---- */
  function placeCard() {
    var parts = cwd ? cwd.split('/') : [];
    var ol = el('ol', {class: 'fp-fm-path'});
    ol.appendChild(el('li', null, [parts.length ? button(t('fm_home'), 'go', 'secondary', {'data-fp-path': '', class: 'sig-btn sig-btn--secondary sig-btn--sm'}) :
      el('span', {'aria-current': 'location', text: t('fm_home')})]));
    parts.forEach(function (p, i) {
      var to = parts.slice(0, i + 1).join('/');
      ol.appendChild(el('li', null, [i === parts.length - 1 ? el('span', {'aria-current': 'location', text: p}) :
        button(p, 'go', 'secondary', {'data-fp-path': to, class: 'sig-btn sig-btn--secondary sig-btn--sm'})]));
    });
    var show = el('input', {type: 'checkbox', id: 'fp-fm-hidden', 'data-fp-hidden': '', checked: hidden});
    var tools = el('div', {class: 'fp-fm-tools'}, [
      button(t('fm_up'), 'up', 'secondary', {disabled: !cwd, class: 'sig-btn sig-btn--secondary sig-btn--sm'}),
      button(t('fm_reload'), 'reload', 'secondary', {class: 'sig-btn sig-btn--secondary sig-btn--sm'}),
      suspended ? null : button(t('fm_new_folder'), 'new-folder', 'secondary', {class: 'sig-btn sig-btn--secondary sig-btn--sm'}),
      suspended ? null : button(t('fm_new_file'), 'new-file', 'secondary', {class: 'sig-btn sig-btn--secondary sig-btn--sm'}),
      suspended ? null : button(t('fm_upload'), 'upload', 'secondary', {class: 'sig-btn sig-btn--secondary sig-btn--sm'}),
      button(t('fm_trash'), 'trash-view', 'secondary', {class: 'sig-btn sig-btn--secondary sig-btn--sm'})]);
    return card('fp-fm-place-h', t('fm_place_title'), [
      el('nav', {'aria-label': t('fm_path_label')}, [ol]),
      tools,
      el('label', {class: 'fp-check fp-fm-hidden'}, [show, el('span', {text: t('fm_show_hidden')})])]);
  }

  /* ---- what is in the folder ---- */
  function kindIcon(e) {
    return UI.icon(FP.ui, e.type === 'folder' ? 'ui_folder' : e.type === 'link' ? 'ui_link' : e.type === 'file' ? 'ui_file' : 'ui_other', 'fp-fm-ico');
  }
  function nameCell(e) {
    var parts = [kindIcon(e)];
    if (isFolder(e)) {
      parts.push(el('button', {class: 'fp-fm-name fp-linkbtn', type: 'button', 'data-fp-act': 'open', text: e.name}));
    } else if (isFile(e)) {
      parts.push(el('button', {class: 'fp-fm-name fp-linkbtn', type: 'button', 'data-fp-act': 'edit', text: e.name}));
    } else {
      parts.push(el('span', {class: 'fp-fm-name', text: e.name}));
    }
    var what = e.type === 'link' ? t('fm_type_link') : e.type === 'folder' ? t('fm_type_folder') : e.type === 'other' ? t('fm_type_other') : '';
    if (what) { parts.push(el('span', {class: 'sig-vh', text: ' (' + what + ')'})); }
    if (e.type === 'link') {
      parts.push(el('span', {class: 'fp-muted fp-fm-target'}, [el('span', {'aria-hidden': 'true', text: '→ '}),
        el('span', {class: 'sig-vh', text: t('fm_leads_to') + ' '}), el('span', {class: 'sig-mono', text: e.target || t('fm_target_unknown')}),
        e.targetType ? null : el('span', {text: ' ' + t('fm_target_missing')})]));
    } else if (e.type === 'other') {
      parts.push(el('span', {class: 'fp-muted fp-fm-target', 'aria-hidden': 'true', text: t('fm_type_other')}));
    }
    return el('td', {class: 'fp-fm-namecell'}, parts);
  }
  /* what can be done to an entry: the menu under its Actions button */
  function actionsFor(e) {
    var a = [];
    if (isFolder(e)) { a.push(['open', t('fm_open')]); }
    if (isFile(e)) { a.push(['edit', suspended ? t('fm_view') : t('fm_edit')]); }
    if (e.type === 'file') { a.push(['download', t('fm_download')]); }
    if (!suspended) {
      a.push(['rename', t('fm_rename')], ['move', t('fm_move')]);
      if (e.type !== 'other') { a.push(['copy', t('fm_copy')]); }
      if (e.type === 'file' || e.type === 'folder') { a.push(['compress', t('fm_compress')]); }
      if (e.type === 'file' && UNPACK_END.test(e.name)) { a.push(['extract', t('fm_extract')]); }
      if (e.type === 'file' || e.type === 'folder') { a.push(['permissions', t('fm_permissions')]); }
      a.push(['trash', t('fm_to_trash')], ['delete', t('fm_delete')]);
    }
    return a;
  }
  function row(e, i) {
    var menuId = 'fp-fm-menu-' + i;
    var label = t('fm_actions_for', {name: e.name});
    var toggle = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'menu', 'aria-expanded': 'false',
      'aria-controls': menuId, 'aria-label': label, text: t('fm_actions')});
    var menu = el('div', {class: 'fp-fm-menu', id: menuId, hidden: true}, actionsFor(e).map(function (x) {
      if (x[0] === 'download') {
        return el('a', {class: 'sig-btn sig-btn--secondary sig-btn--sm', href: downloadHref(itemPath(e)), download: e.name, 'data-fp-act': 'download', text: x[1]});
      }
      return el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm' + (x[0] === 'delete' ? ' fp-btn-danger-text' : ''), type: 'button',
        'data-fp-act': x[0], text: x[1]});
    }));
    return el('tr', {'data-fp-entry': String(i)}, [
      nameCell(e),
      el('td', {class: 'fp-fm-num', 'data-label': t('fm_size'), text: e.type === 'file' ? size(e.size) : '—'}),
      el('td', {'data-label': t('fm_modified'), text: when(e.modified)}),
      el('td', {class: 'sig-mono', 'data-label': t('fm_mode'), text: e.type === 'link' ? '—' : e.mode || '—'}),
      el('td', {class: 'fp-fm-acts'}, [toggle, menu])]);
  }
  function listCard() {
    var parts = [errorLine(), statusLine()];
    if (listing.truncated) { parts.push(el('p', {class: 'fp-muted', 'data-fp-truncated': '', text: t('fm_truncated')})); }
    if (!listing.entries.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: hidden ? t('fm_empty') : t('fm_empty_hidden')}));
    } else {
      var head = el('tr', null, [el('th', {scope: 'col', text: t('fm_name')}), el('th', {scope: 'col', class: 'fp-fm-num', text: t('fm_size')}),
        el('th', {scope: 'col', text: t('fm_modified')}), el('th', {scope: 'col', text: t('fm_mode')}),
        el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('fm_actions')})])]);
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-fm-list-h'}, [
        el('table', {class: 'sig-table fp-fm-table'}, [el('thead', null, [head]), el('tbody', null, listing.entries.map(row))])]));
    }
    return card('fp-fm-list-h', t('fm_list_title', {where: where(cwd)}), parts, 'fp-fm-list');
  }

  /* ---- finding by name ---- */
  /* a match as the server gives it: an entry with its path from the home */
  function hitOf(h) {
    var e = entryOf(h);
    var p = h && typeof h.path === 'string' ? h.path : '';
    if (!e || !p || p.length > 4096 || p.split('/').some(function (x) { return x === '' || x === '.' || x === '..'; }) || base(p) !== e.name) { return null; }
    e.path = p;
    return e;
  }
  function queryProblem(q) {
    if (!q.trim()) { return t('fm_find_need'); }
    if (q.indexOf('/') >= 0) { return t('fm_find_slash'); }
    /* eslint-disable-next-line no-control-regex */
    if (/[\u0000-\u001f\u007f]/.test(q)) { return t('fm_name_control'); }
    if (new window.TextEncoder().encode(q).length > 255) { return t('fm_find_long'); }
    return '';
  }
  function findForm() { return page ? page.querySelector('.fp-fm-findform') : null; }
  function drawFound(out) {
    out.textContent = '';
    if (!found) { return; }
    var w = where(found.path);
    if (!found.entries.length) {
      out.appendChild(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('fm_found_none', {where: w, q: found.q})}));
    } else {
      out.appendChild(el('p', {class: 'fp-fm-found-sum', text: t('fm_found', {q: found.q, where: w, n: String(found.entries.length)})}));
    }
    if (found.truncated) { out.appendChild(el('p', {class: 'fp-muted', 'data-fp-truncated': '', text: t('fm_found_more')})); }
    if (found.timedOut) { out.appendChild(el('p', {class: 'fp-muted', 'data-fp-timed-out': '', text: t('fm_found_timed')})); }
    if (found.entries.length) {
      var head = el('tr', null, [el('th', {scope: 'col', text: t('fm_name')}), el('th', {scope: 'col', text: t('fm_found_in')}),
        el('th', {scope: 'col', class: 'fp-fm-num', text: t('fm_size')}), el('th', {scope: 'col', text: t('fm_modified')}),
        el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('fm_actions')})])]);
      var rows = found.entries.map(function (h, i) {
        var what = h.type === 'link' ? t('fm_type_link') : h.type === 'folder' ? t('fm_type_folder') : h.type === 'other' ? t('fm_type_other') : '';
        var acts = [];
        if (isFolder(h)) {
          acts.push(button(t('fm_open'), 'found-open', 'secondary', {class: 'sig-btn sig-btn--secondary sig-btn--sm', 'aria-label': t('fm_open') + ' ' + h.name}));
        }
        acts.push(button(t('fm_found_show'), 'found-show', 'secondary', {class: 'sig-btn sig-btn--secondary sig-btn--sm', 'aria-label': t('fm_found_show_for', {name: h.name})}));
        return el('tr', {'data-fp-hit': String(i)}, [
          el('td', {class: 'fp-fm-namecell'}, [kindIcon(h), el('span', {class: 'fp-fm-name', text: h.name}),
            what ? el('span', {class: 'sig-vh', text: ' (' + what + ')'}) : null]),
          el('td', {class: 'sig-mono fp-fm-from', 'data-label': t('fm_found_in'), text: where(parent(h.path))}),
          el('td', {class: 'fp-fm-num', 'data-label': t('fm_size'), text: h.type === 'file' ? size(h.size) : '—'}),
          el('td', {'data-label': t('fm_modified'), text: when(h.modified)}),
          el('td', {class: 'fp-fm-acts'}, acts)]);
      });
      out.appendChild(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-fm-find-h'}, [
        el('table', {class: 'sig-table fp-fm-table'}, [el('thead', null, [head]), el('tbody', null, rows)])]));
    }
    out.appendChild(el('div', {class: 'fp-actions fp-fm-found-acts'}, [button(t('fm_found_clear'), 'found-clear')]));
  }
  function findCard() {
    var hint = 'fp-fm-find-hint';
    var form = el('form', {class: 'fp-form fp-fm-findform', novalidate: ''}, [errorLine(), statusLine(),
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: 'fp-fm-find', text: t('fm_find_label')}),
        el('input', {class: 'sig-input', id: 'fp-fm-find', name: 'q', type: 'search', autocomplete: 'off', spellcheck: 'false', maxlength: '255',
          value: found ? found.q : '', 'aria-describedby': hint}),
        el('span', {class: 'sig-hint', id: hint, text: t('fm_find_hint', {where: where(cwd)})})]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('fm_find')})])]);
    form.addEventListener('submit', function (ev) {
      ev.preventDefault();
      find(form);
    });
    var out = el('div', {class: 'fp-fm-found', 'data-fp-found': ''});
    drawFound(out);
    return card('fp-fm-find-h', t('fm_find_title'), [form, out], 'fp-fm-find');
  }
  function find(form) {
    var b = form.querySelector('.fp-submit');
    if (b.disabled) { return; }
    UI.showError(form, '');
    clearInvalid(form);
    var box = form.querySelector('[name="q"]');
    var q = box.value;
    var problem = queryProblem(q);
    if (problem) { fieldError(form, box, problem); return; }
    var folder = cwd;
    var view = page;
    say(form, t('fm_finding', {where: where(folder)}));
    UI.setBusy(b, true);
    FP.call('get', hidden ? 'fileSearchHidden' : 'fileSearch', undefined, {name: account, path: apiPath(folder), q: q}).then(function (r) {
      if (page !== view) { return; }
      UI.setBusy(b, false);
      r = r && typeof r === 'object' ? r : {};
      found = {q: q, path: folder, entries: (Array.isArray(r.entries) ? r.entries : []).map(hitOf).filter(Boolean),
        truncated: r.truncated === true, timedOut: r.timed_out === true};
      /* the page may have moved on to another folder meanwhile: whatever form is showing now gets the result */
      var now = findForm();
      var out = page.querySelector('[data-fp-found]');
      if (now) { say(now, ''); }
      if (out) { drawFound(out); }
      UI.announce(found.entries.length ? t('fm_found', {q: q, where: where(folder), n: String(found.entries.length)}) : t('fm_found_none', {where: where(folder), q: q}));
    }, function (err) {
      if (page !== view) { return; }
      UI.setBusy(b, false);
      var now = findForm();
      if (!now) { return; }
      say(now, '');
      failed(now, err);
    });
  }

  /* ---- the forms ---- */
  function formActions(submitText) {
    return el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: submitText}),
      button(t('cancel'), 'cancel-action')]);
  }
  function permBoxes(mode3) {
    var digits = (mode3 || '644').split('').map(Number);
    var rows = WHO.map(function (who, w) {
      return el('tr', null, [el('th', {scope: 'row', text: t('fm_perm_' + who)})].concat(BITS.map(function (b) {
        var id = 'fp-fm-perm-' + who + '-' + b[0];
        return el('td', null, [el('input', {type: 'checkbox', id: id, 'data-fp-bit': String(b[1]), 'data-fp-who': String(w), checked: Boolean(digits[w] & b[1]),
          'aria-label': t('fm_perm_' + who) + ': ' + t('fm_perm_' + b[0])})]);
      })));
    });
    return el('div', {class: 'fp-table-wrap'}, [el('table', {class: 'sig-table fp-fm-perms'}, [
      el('thead', null, [el('tr', null, [el('td'), el('th', {scope: 'col', text: t('fm_perm_read')}), el('th', {scope: 'col', text: t('fm_perm_write')}),
        el('th', {scope: 'col', text: t('fm_perm_run')})])]), el('tbody', null, rows)])]);
  }
  function actionCard() {
    var k = action.kind;
    var e = action.entry;
    var title;
    var fields = [];
    var submit;
    if (k === 'new-folder' || k === 'new-file') {
      title = k === 'new-folder' ? t('fm_new_folder_title', {where: where(cwd)}) : t('fm_new_file_title', {where: where(cwd)});
      fields.push(input('fp-fm-name', t('fm_name'), {type: 'text', name: 'path', autocomplete: 'off', spellcheck: 'false', maxlength: '255'}));
      submit = k === 'new-folder' ? t('fm_new_folder') : t('fm_new_file');
    } else if (k === 'upload') {
      title = t('fm_upload_title', {where: where(cwd)});
      fields.push(el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: 'fp-fm-pick', text: t('fm_upload_pick')}),
        el('input', {class: 'sig-input', type: 'file', id: 'fp-fm-pick', name: 'files', multiple: true, 'aria-describedby': 'fp-fm-pick-hint'}),
        el('span', {class: 'sig-hint', id: 'fp-fm-pick-hint', text: t('fm_upload_hint')})]));
      fields.push(el('label', {class: 'fp-check'}, [el('input', {type: 'checkbox', id: 'fp-fm-over', name: 'overwrite'}),
        el('span', {text: t('fm_upload_over')})]));
      submit = t('fm_upload');
    } else if (k === 'rename') {
      title = t('fm_rename_title', {name: e.name});
      fields.push(input('fp-fm-name', t('fm_new_name'), {type: 'text', name: 'name', value: e.name, autocomplete: 'off', spellcheck: 'false', maxlength: '255'}));
      submit = t('fm_rename');
    } else if (k === 'move' || k === 'copy') {
      title = t(k === 'move' ? 'fm_move_title' : 'fm_copy_title', {name: e.name});
      fields.push(input('fp-fm-to', t('fm_to'), {type: 'text', name: 'to', value: cwd, autocomplete: 'off', spellcheck: 'false', class: 'sig-input sig-mono'},
        t('fm_to_hint')));
      if (k === 'copy') {
        fields.push(input('fp-fm-name', t('fm_copy_name'), {type: 'text', name: 'name', value: t('fm_copy_default', {name: e.name}), autocomplete: 'off',
          spellcheck: 'false', maxlength: '255'}));
      }
      fields.push(el('p', {class: 'fp-muted', text: t('fm_long_note')}));
      submit = k === 'move' ? t('fm_move') : t('fm_copy');
    } else if (k === 'compress') {
      title = t('fm_compress_title', {name: e.name});
      fields.push(input('fp-fm-name', t('fm_pack_name'), {type: 'text', name: 'name', value: e.name + '.zip', autocomplete: 'off', spellcheck: 'false', maxlength: '255'},
        t('fm_pack_name_hint')));
      fields.push(el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: 'fp-fm-format', text: t('fm_pack_format')}),
        el('select', {class: 'sig-select', id: 'fp-fm-format', name: 'format'}, [el('option', {value: 'zip', text: t('fm_pack_zip')}),
          el('option', {value: 'tgz', text: t('fm_pack_tgz')})])]));
      fields.push(input('fp-fm-to', t('fm_pack_to'), {type: 'text', name: 'to', value: cwd, autocomplete: 'off', spellcheck: 'false', class: 'sig-input sig-mono'},
        t('fm_to_hint')));
      fields.push(el('p', {class: 'fp-muted', text: t('fm_pack_note')}));
      submit = t('fm_compress');
    } else if (k === 'extract') {
      title = t('fm_extract_title', {name: e.name});
      fields.push(input('fp-fm-to', t('fm_extract_to'), {type: 'text', name: 'to', value: cwd, autocomplete: 'off', spellcheck: 'false', class: 'sig-input sig-mono'},
        t('fm_extract_to_hint')));
      fields.push(el('label', {class: 'fp-check'}, [el('input', {type: 'checkbox', id: 'fp-fm-over', name: 'overwrite'}), el('span', {text: t('fm_extract_over')})]));
      fields.push(el('p', {class: 'fp-muted', text: t('fm_extract_note')}));
      submit = t('fm_extract');
    } else {
      title = t('fm_permissions_title', {name: e.name});
      fields.push(permBoxes(e.mode));
      fields.push(input('fp-fm-mode', t('fm_mode_digits'), {type: 'text', name: 'mode', value: e.mode || '644', inputmode: 'numeric', maxlength: '3',
        autocomplete: 'off', spellcheck: 'false', class: 'sig-input sig-mono fp-fm-mode'}, t('fm_mode_hint')));
      submit = t('fm_permissions_save');
    }
    var form = el('form', {class: 'fp-form fp-fm-form', novalidate: '', 'data-fp-kind': k}, [errorLine(), statusLine()].concat(fields, [formActions(submit)]));
    form.addEventListener('submit', function (ev) {
      ev.preventDefault();
      send(form);
    });
    if (k === 'compress') {
      /* the kind picks the ending of the name; a name that ends some other way is left for the person to fix */
      form.querySelector('#fp-fm-format').addEventListener('change', function (ev) {
        var nameField = form.querySelector('#fp-fm-name');
        var ending = ev.target.value === 'tgz' ? '.tar.gz' : '.zip';
        nameField.value = PACK_END.test(nameField.value) ? nameField.value.replace(PACK_END, ending) : nameField.value + ending;
      });
    }
    if (k === 'permissions') {
      form.addEventListener('change', function (ev) {
        if (!ev.target.hasAttribute('data-fp-bit')) { return; }
        var d = [0, 0, 0];
        var boxes = form.querySelectorAll('[data-fp-bit]');
        for (var i = 0; i < boxes.length; i++) {
          if (boxes[i].checked) { d[Number(boxes[i].getAttribute('data-fp-who'))] += Number(boxes[i].getAttribute('data-fp-bit')); }
        }
        form.querySelector('[name="mode"]').value = d.join('');
      });
      form.querySelector('[name="mode"]').addEventListener('input', function (ev) {
        var v = ev.target.value;
        if (!/^[0-7]{3}$/.test(v)) { return; }
        var boxes = form.querySelectorAll('[data-fp-bit]');
        for (var i = 0; i < boxes.length; i++) {
          boxes[i].checked = Boolean(Number(v[Number(boxes[i].getAttribute('data-fp-who'))]) & Number(boxes[i].getAttribute('data-fp-bit')));
        }
      });
    }
    return card('fp-fm-action-h', title, [form], 'fp-fm-action');
  }

  /* a folder typed by hand: relative to the home, '/' or nothing for the home itself */
  function folderTyped(v) {
    v = v.trim().replace(/^\/+/, '').replace(/\/+$/, '');
    if (v.split('/').some(function (p) { return p === '..'; })) { return null; }
    return v;
  }
  /* what the server left out, by the call that did: said after the result */
  var SKIPPED = {copy: 'fm_skipped', compress: 'fm_pack_skipped', extract: 'fm_extract_skipped'};
  function extractedNote(e, to, r) {
    function n(key) { return r && typeof r[key] === 'number' && r[key] >= 0 ? String(r[key]) : '0'; }
    var text = t('fm_extracted', {name: e.name, where: where(to), files: n('files'), folders: n('folders')});
    if (n('links') !== '0') { text += ' ' + t('fm_extracted_links', {n: n('links')}); }
    if (n('replaced') !== '0') { text += ' ' + t('fm_extracted_replaced', {n: n('replaced')}); }
    return text;
  }
  function send(form) {
    var b = form.querySelector('.fp-submit');
    if (b.disabled) { return; }
    UI.showError(form, '');
    say(form, '');
    clearInvalid(form);
    var k = action.kind;
    var e = action.entry;
    if (k === 'upload') { upload(form, b); return; }
    var call;
    var done;
    var nameBox = form.querySelector('#fp-fm-name');
    if (k === 'new-folder' || k === 'new-file' || k === 'rename' || k === 'copy' || k === 'compress') {
      var problem = nameProblem(nameBox.value);
      if (problem) { fieldError(form, nameBox, problem); return; }
    }
    if (k === 'new-folder' || k === 'new-file') {
      call = FP.call('post', k === 'new-folder' ? 'fileFolder' : 'fileNew', {path: join(cwd, nameBox.value)}, account);
      done = t(k === 'new-folder' ? 'fm_made_folder' : 'fm_made_file', {name: nameBox.value});
    } else if (k === 'rename') {
      call = FP.call('post', 'fileRename', {path: itemPath(e), name: nameBox.value}, account);
      done = t('fm_renamed', {name: e.name, to: nameBox.value});
    } else if (k === 'move' || k === 'copy') {
      var toBox = form.querySelector('[name="to"]');
      var to = folderTyped(toBox.value);
      if (to === null) { fieldError(form, toBox, t('fm_to_bad')); return; }
      var body = {path: itemPath(e), to: to};
      if (k === 'copy') { body.name = nameBox.value; }
      say(form, t(k === 'move' ? 'fm_moving' : 'fm_copying'));
      call = FP.call('post', k === 'move' ? 'fileMove' : 'fileCopy', body, account);
      done = k === 'move' ? t('fm_moved', {name: e.name, where: where(to)}) : t('fm_copied', {name: e.name, where: where(to)});
    } else if (k === 'compress') {
      if (!PACK_END.test(nameBox.value)) { fieldError(form, nameBox, t('fm_pack_suffix')); return; }
      var packTo = form.querySelector('[name="to"]');
      var into = folderTyped(packTo.value);
      if (into === null) { fieldError(form, packTo, t('fm_to_bad')); return; }
      say(form, t('fm_packing'));
      call = FP.call('post', 'fileArchive', {paths: [itemPath(e)], to: into, name: nameBox.value}, account);
      done = t('fm_packed', {name: e.name, archive: nameBox.value, where: where(into)});
    } else if (k === 'extract') {
      var outTo = form.querySelector('[name="to"]');
      var outOf = folderTyped(outTo.value);
      if (outOf === null) { fieldError(form, outTo, t('fm_to_bad')); return; }
      var body2 = {path: itemPath(e), to: outOf};
      if (form.querySelector('[name="overwrite"]').checked) { body2.overwrite = true; }
      say(form, t('fm_extracting'));
      call = FP.call('post', 'fileExtract', body2, account);
      done = function (r) { return extractedNote(e, outOf, r); };
    } else {
      var modeBox = form.querySelector('[name="mode"]');
      if (!/^[0-7]{3}$/.test(modeBox.value)) { fieldError(form, modeBox, t('fm_mode_bad')); return; }
      call = FP.call('post', 'filePerms', {path: itemPath(e), mode: modeBox.value}, account);
      done = t('fm_perms_set', {name: e.name, mode: modeBox.value});
    }
    UI.setBusy(b, true);
    var at = here();
    call.then(function (r) {
      var skipped = SKIPPED[k] && r && typeof r.skipped === 'number' && r.skipped > 0 ? ' ' + t(SKIPPED[k], {n: String(r.skipped)}) : '';
      var text = (typeof done === 'function' ? done(r) : done) + skipped;
      if (stillAt(at)) { action = null; load(cwd, text); } else if (page === at.page) { elsewhere(text, false); }
    }, function (err) {
      /* a taken archive name belongs on the name */
      if (k === 'compress' && err && err.code === 'conflict' && !err.field) { err.field = 'name'; }
      if (!stillAt(at)) { if (err && err.code === 'account_suspended') { suspended = true; } elsewhere(message(err), true); return; }
      UI.setBusy(b, false);
      say(form, '');
      failed(form, err);
      if (suspended && err.code === 'account_suspended') { render(); showListError(t('fm_suspended_change')); }
    });
  }

  /* files one at a time, so one refusal (a taken name, too big) doesn't stop the rest */
  function upload(form, b) {
    var pick = form.querySelector('[name="files"]');
    var files = Array.prototype.slice.call(pick.files || []);
    if (!files.length) { fieldError(form, pick, t('fm_upload_none')); return; }
    var over = form.querySelector('[name="overwrite"]').checked;
    var sent = [];
    var refused = [];
    UI.setBusy(b, true);
    pick.disabled = true;
    var at = here();
    function next(i) {
      if (i >= files.length) {
        pick.disabled = false;
        UI.setBusy(b, false);
        var text = sent.length ? t('fm_uploaded', {n: String(sent.length)}) : '';
        if (!stillAt(at)) { elsewhere([text].concat(refused.length ? [t('fm_upload_refused') + ' ' + refused.join('; ')] : []).join(' '), refused.length > 0); return; }
        if (!refused.length) { action = null; load(cwd, text); return; }
        /* keep the form, saying what didn't go, and show the folder as it is now */
        say(form, text);
        UI.showError(form, t('fm_upload_refused') + ' ' + refused.join('; '));
        refreshList();
        return;
      }
      var f = files[i];
      say(form, t('fm_uploading', {i: String(i + 1), n: String(files.length), name: f.name}));
      var problem = nameProblem(f.name);
      if (problem) { refused.push(f.name + ': ' + problem); next(i + 1); return; }
      FP.call('post', over ? 'fileUploadOver' : 'fileUpload', undefined, {name: account, path: join(cwd, f.name)},
        {body: f, type: 'application/octet-stream'}).then(function () {
        sent.push(f.name);
        next(i + 1);
      }, function (err) {
        refused.push(f.name + ': ' + (err && err.code === 'conflict' && !over ? t('fm_upload_taken') : message(err)));
        if (err && err.code === 'account_suspended') { suspended = true; }
        next(i + 1);
      });
    }
    next(0);
  }

  /* ---- deleting and the trash ---- */
  function entryOfRow(tr) {
    var i = Number(tr.getAttribute('data-fp-entry'));
    return listing && listing.entries[i] ? listing.entries[i] : null;
  }
  /* each question has its own id, so a question left in a closed menu never names another row's buttons */
  var asked = 0;
  function confirmIn(holder, question, act, yesLabel) {
    holder.textContent = '';
    var id = 'fp-fm-confirm-' + (++asked);
    var yes = el('button', {class: 'sig-btn sig-btn--danger sig-btn--sm', type: 'button', 'data-fp-act': act, 'aria-describedby': id, text: yesLabel});
    var no = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'confirm-no', 'aria-describedby': id, text: t('cancel')});
    holder.appendChild(el('span', {class: 'fp-fm-confirm', id: id, text: question}));
    holder.appendChild(yes);
    holder.appendChild(no);
    /* Cancel takes focus, so a second Enter can't confirm it */
    no.focus();
  }
  function showListError(text) {
    var list = page.querySelector('.fp-fm-list');
    if (list) { UI.showError(list, text); }
  }
  function removeEntry(e, how, b) {
    var list = page.querySelector('.fp-fm-list');
    UI.showError(list, '');
    UI.setBusy(b, true);
    if (how === 'delete') { say(list, t('fm_deleting', {name: e.name})); }
    var at = here();
    FP.call('post', how === 'delete' ? 'fileDelete' : 'fileTrash', {path: itemPath(e)}, account).then(function () {
      finished(at, t(how === 'delete' ? 'fm_deleted' : 'fm_trashed', {name: e.name}));
    }, function (err) {
      if (err && err.code === 'account_suspended') { suspended = true; }
      if (!stillAt(at)) { elsewhere(message(err), true); return; }
      render();
      showListError(message(err));
      focusHeading('fp-fm-list-h');
    });
  }

  function trashCard() {
    var parts = [errorLine(), statusLine()];
    var entries = trashList.entries;
    if (trashList.truncated) { parts.push(el('p', {class: 'fp-muted', text: t('fm_truncated')})); }
    if (!entries.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('fm_trash_none')}));
    } else {
      parts.push(el('p', {class: 'fp-muted', text: t('fm_trash_note')}));
      var head = el('tr', null, [el('th', {scope: 'col', text: t('fm_name')}), el('th', {scope: 'col', text: t('fm_from')}),
        el('th', {scope: 'col', text: t('fm_trashed_at')}), el('th', {scope: 'col', class: 'fp-fm-num', text: t('fm_size')}),
        el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('fm_actions')})])]);
      var rows = entries.map(function (e, i) {
        return el('tr', {'data-fp-trash': String(i)}, [el('td', {class: 'fp-fm-namecell'}, [el('span', {class: 'fp-fm-name', text: e.name})]),
          el('td', {class: 'sig-mono fp-fm-from', 'data-label': t('fm_from'), text: e.from ? '/' + e.from : t('fm_from_unknown')}),
          el('td', {'data-label': t('fm_trashed_at'), text: when(e.trashed)}),
          el('td', {class: 'fp-fm-num', 'data-label': t('fm_size'), text: e.type === 'file' ? size(e.size) : '—'}),
          el('td', {class: 'fp-fm-acts'}, suspended ? [] : [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'restore',
            'aria-label': t('fm_restore') + ' ' + e.name, text: t('fm_restore')})])]);
      });
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-fm-trash-h'}, [
        el('table', {class: 'sig-table fp-fm-table'}, [el('thead', null, [head]), el('tbody', null, rows)])]));
    }
    var acts = el('div', {class: 'fp-actions fp-fm-trash-acts'}, [button(t('fm_back_to_files'), 'list-view'),
      entries.length && !suspended ? button(t('fm_empty_trash'), 'empty-trash', 'secondary', {class: 'sig-btn sig-btn--secondary fp-btn-danger-text'}) : null]);
    parts.push(acts);
    return card('fp-fm-trash-h', t('fm_trash_title'), parts, 'fp-fm-trashcard');
  }
  function loadTrash(note, focus) {
    FP.call('get', 'trash', undefined, account).then(function (r) {
      r = r && typeof r === 'object' ? r : {};
      trashList = {truncated: r.truncated === true, entries: entriesOf(r.entries)};
      mode = 'trash';
      render();
      say(page.querySelector('.fp-fm-trashcard'), note || '');
      if (focus !== false) { focusHeading('fp-fm-trash-h'); }
    }, function (err) {
      if (mode === 'trash') {
        UI.showError(page.querySelector('.fp-fm-trashcard'), message(err));
      } else {
        showListError(message(err));
      }
    });
  }
  /* a trash call has ended: the trash again if it is still what's open, else the result said where the person is now */
  function trashDone(view, note, error) {
    if (page !== view) { return; }
    if (mode === 'trash') { loadTrash(note); return; }
    elsewhere(note, error);
  }
  function restore(e, b, to) {
    var holder = page.querySelector('.fp-fm-trashcard');
    UI.showError(holder, '');
    UI.setBusy(b, true);
    var body = {name: e.name};
    var view = page;
    if (to) { body.to = to; }
    FP.call('post', 'trashRestore', body, account).then(function (r) {
      var p = r && typeof r.path === 'string' ? r.path : (to || e.from || e.name);
      trashDone(view, t('fm_restored', {name: e.name, where: '/' + p}), false);
    }, function (err) {
      if (page !== view || mode !== 'trash') { trashDone(view, message(err), true); return; }
      UI.setBusy(b, false);
      var suggested = err && err.code === 'conflict' && typeof err.suggested === 'string' ? err.suggested : '';
      var tr = b.closest('tr');
      if (suggested && tr) {
        /* the name is taken where it came from: offer the free name beside it the server found */
        var cell = tr.querySelector('.fp-fm-acts');
        confirmIn(cell, t('fm_restore_taken', {name: e.name, suggested: '/' + suggested}), 'restore-as', t('fm_restore_as'));
        cell.querySelector('[data-fp-act="restore-as"]').setAttribute('data-fp-to', suggested);
        return;
      }
      UI.showError(holder, message(err));
    });
  }

  /* ---- the editor ---- */
  function editCard() {
    var ro = opened.readOnly;
    var area = el('textarea', {class: 'sig-input sig-mono fp-fm-text', id: 'fp-fm-text', name: 'content', rows: '22', spellcheck: 'false',
      autocomplete: 'off', wrap: 'off', readonly: ro});
    area.value = opened.text;
    var form = el('form', {class: 'fp-form fp-fm-editor', novalidate: ''}, [errorLine(), statusLine(),
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: 'fp-fm-text', text: ro ? t('fm_text_ro') : t('fm_text')}), area]),
      el('div', {class: 'fp-actions', 'data-fp-edit-acts': ''}, [ro ? null : el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('fm_save')}),
        button(t('fm_close'), 'close-edit')])]);
    form.addEventListener('submit', function (ev) {
      ev.preventDefault();
      save(form);
    });
    area.addEventListener('keydown', function (ev) {
      if ((ev.ctrlKey || ev.metaKey) && (ev.key === 's' || ev.key === 'S') && !ro) {
        ev.preventDefault();
        save(form);
      }
    });
    return card('fp-fm-edit-h', t(ro ? 'fm_view_title' : 'fm_edit_title', {name: '/' + opened.path}), [form], 'fp-fm-editcard');
  }
  function textOut(v) { return opened.crlf ? v.replace(/\r?\n/g, '\r\n') : v; }
  function save(form) {
    var b = form.querySelector('.fp-submit');
    if (!b || b.disabled) { return; }
    UI.showError(form, '');
    say(form, '');
    var v = form.querySelector('textarea').value;
    UI.setBusy(b, true);
    FP.call('put', 'fileContent', undefined, {name: account, path: opened.path}, {body: textOut(v), type: 'text/plain'}).then(function () {
      UI.setBusy(b, false);
      opened.text = v;
      say(form, t('fm_saved', {name: base(opened.path)}));
    }, function (err) {
      UI.setBusy(b, false);
      if (err && err.code === 'account_suspended') { suspended = true; }
      UI.showError(form, message(err));
    });
  }
  function openFile(e, b) {
    var p = itemPath(e);
    var list = page.querySelector('.fp-fm-list');
    UI.showError(list, '');
    if (e.type === 'file' && e.size !== null && e.size > MAX_TEXT) {
      UI.showError(list, t('fm_too_big', {name: e.name}));
      return;
    }
    UI.setBusy(b, true);
    say(list, t('fm_opening', {name: e.name}));
    FP.call('get', 'fileContent', undefined, {name: account, path: p}).then(function (r) {
      UI.setBusy(b, false);
      if (!r || typeof r.content !== 'string') { say(list, ''); UI.showError(list, t('api_unreachable')); return; }
      var text = r.content;
      var crlf = /\r\n/.test(text) && !/(^|[^\r])\n/.test(text);
      opened = {path: p, text: text.replace(/\r\n/g, '\n'), crlf: crlf, readOnly: suspended};
      mode = 'edit';
      render();
      focusHeading('fp-fm-edit-h');
    }, function (err) {
      UI.setBusy(b, false);
      say(list, '');
      /* too big or not text: the server's words say to download it */
      UI.showError(list, err && err.code === 'too_large' ? t('fm_too_big', {name: e.name}) :
        err && (err.status === 413 || err.status === 422) ? e.name + ': ' + message(err) : message(err));
    });
  }
  function closeEditor(force) {
    var area = page.querySelector('#fp-fm-text');
    if (!force && area && !opened.readOnly && area.value !== opened.text) {
      confirmIn(page.querySelector('[data-fp-edit-acts]'), t('fm_unsaved'), 'close-edit-yes', t('fm_discard'));
      return;
    }
    var back = opened ? base(opened.path) : '';
    opened = null;
    mode = 'list';
    load(cwd, '', back);
  }

  /* ---- clicks ---- */
  function closeMenus(except) {
    var open = page.querySelectorAll('[data-fp-act="menu"][aria-expanded="true"]');
    for (var i = 0; i < open.length; i++) {
      if (open[i] === except) { continue; }
      open[i].setAttribute('aria-expanded', 'false');
      var m = page.querySelector('#' + open[i].getAttribute('aria-controls'));
      if (m) { m.hidden = true; }
    }
  }
  function openAction(kind, e) {
    action = {kind: kind, entry: e};
    render();
    focusHeading('fp-fm-action-h');
    var first = page.querySelector('.fp-fm-form input:not([type="checkbox"])') || page.querySelector('.fp-fm-form input');
    if (first) { first.focus(); }
  }
  function onClick(ev) {
    var target = ev.target.closest ? ev.target : null;
    if (!target || !page || !page.contains(target)) { return; }
    var act = target.closest('[data-fp-act]');
    if (!act) { closeMenus(null); return; }
    var a = act.getAttribute('data-fp-act');
    var tr = act.closest('tr');
    var e = tr && tr.hasAttribute('data-fp-entry') ? entryOfRow(tr) : null;
    var hit = tr && tr.hasAttribute('data-fp-hit') && found ? found.entries[Number(tr.getAttribute('data-fp-hit'))] : null;
    if (a === 'menu') {
      var opening = act.getAttribute('aria-expanded') !== 'true';
      closeMenus(act);
      act.setAttribute('aria-expanded', opening ? 'true' : 'false');
      var m = page.querySelector('#' + act.getAttribute('aria-controls'));
      m.hidden = !opening;
      if (opening) {
        var first = m.querySelector('button, a');
        if (first) { first.focus(); }
      }
      return;
    }
    if (a === 'download') { closeMenus(null); return; }
    if (a === 'go') { go(act.getAttribute('data-fp-path') || ''); } else if (a === 'up') { go(parent(cwd)); } else if (a === 'reload') {
      load(cwd, t('fm_reloaded'));
    } else if (a === 'open' && e) { go(itemPath(e)); } else if (a === 'edit' && e) { openFile(e, act); } else if (a === 'new-folder' || a === 'new-file' || a === 'upload') {
      openAction(a, null);
    } else if (['rename', 'move', 'copy', 'compress', 'extract', 'permissions'].indexOf(a) >= 0 && e) { openAction(a, e); } else if (a === 'found-open' && hit) {
      go(hit.path);
    } else if (a === 'found-show' && hit) {
      action = null;
      load(parent(hit.path), '', hit.name);
    } else if (a === 'found-clear') {
      found = null;
      var out = page.querySelector('[data-fp-found]');
      var box = page.querySelector('#fp-fm-find');
      if (out) { drawFound(out); }
      if (box) { box.value = ''; box.focus(); }
      UI.announce(t('fm_found_cleared'));
    } else if (a === 'cancel-action') {
      var was = action && action.entry ? action.entry.name : '';
      action = null;
      render();
      focusRow(was);
    } else if ((a === 'trash' || a === 'delete') && e) {
      var menu = act.closest('.fp-fm-menu');
      if (a === 'trash') { removeEntry(e, 'trash', act); return; }
      confirmIn(menu, t('fm_delete_ask', {name: e.name}), 'delete-yes', t('fm_delete'));
    } else if (a === 'delete-yes' && e) { removeEntry(e, 'delete', act); } else if (a === 'confirm-no') {
      if (mode === 'edit') {
        var acts = page.querySelector('[data-fp-edit-acts]');
        acts.textContent = '';
        acts.appendChild(el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('fm_save')}));
        acts.appendChild(button(t('fm_close'), 'close-edit'));
        page.querySelector('#fp-fm-text').focus();
      } else if (mode === 'trash') {
        render();
        var back = (tr && page.querySelector('tr[data-fp-trash="' + tr.getAttribute('data-fp-trash') + '"] [data-fp-act="restore"]')) ||
          page.querySelector('[data-fp-act="empty-trash"]');
        if (back) { back.focus(); }
      } else {
        render();
        focusRow(e ? e.name : '');
      }
    } else if (a === 'trash-view') {
      action = null;
      loadTrash('');
    } else if (a === 'list-view') {
      trashList = null;
      mode = 'list';
      load(cwd, '');
    } else if (a === 'restore' && tr) {
      restore(trashList.entries[Number(tr.getAttribute('data-fp-trash'))], act);
    } else if (a === 'restore-as' && tr) {
      restore(trashList.entries[Number(tr.getAttribute('data-fp-trash'))], act, act.getAttribute('data-fp-to'));
    } else if (a === 'empty-trash') {
      confirmIn(act.parentNode, t('fm_empty_ask', {n: String(trashList.entries.length)}), 'empty-yes', t('fm_empty_trash'));
    } else if (a === 'empty-yes') {
      var holder = page.querySelector('.fp-fm-trashcard');
      UI.setBusy(act, true);
      say(holder, t('fm_emptying'));
      var view = page;
      FP.call('del', 'trash', undefined, account).then(function (r) {
        var n = r && typeof r.removed === 'number' ? r.removed : 0;
        trashDone(view, t('fm_emptied', {n: String(n)}), false);
      }, function (err) {
        if (page !== view || mode !== 'trash') { trashDone(view, message(err), true); return; }
        render();
        UI.showError(page.querySelector('.fp-fm-trashcard'), message(err));
        focusHeading('fp-fm-trash-h');
      });
    } else if (a === 'close-edit') { closeEditor(false); } else if (a === 'close-edit-yes') { closeEditor(true); }
  }
  function onKey(ev) {
    if (ev.key !== 'Escape' || !page || !page.contains(ev.target)) { return; }
    var menu = ev.target.closest('.fp-fm-menu');
    if (!menu) { return; }
    var toggle = page.querySelector('[aria-controls="' + menu.id + '"]');
    closeMenus(null);
    if (toggle) { toggle.focus(); }
  }
  function onChange(ev) {
    if (!page || !ev.target.hasAttribute || !ev.target.hasAttribute('data-fp-hidden')) { return; }
    hidden = ev.target.checked;
    UI.store.set(HIDDEN_KEY, hidden ? '1' : '0');
    load(cwd, '', null, 'fp-fm-hidden');
  }
  document.addEventListener('click', onClick);
  document.addEventListener('keydown', onKey);
  document.addEventListener('change', onChange);

  function focusRow(name) {
    if (!listing) { return; }
    for (var i = 0; i < listing.entries.length; i++) {
      if (listing.entries[i].name === name) {
        var b = page.querySelector('tr[data-fp-entry="' + i + '"] [data-fp-act="menu"]');
        if (b) { b.focus(); return; }
      }
    }
    focusHeading('fp-fm-list-h');
  }

  function render() {
    page.textContent = '';
    if (suspended) {
      page.appendChild(el('div', {class: 'sig-banner sig-banner--warn', role: 'note'}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('fm_suspended')})]));
    }
    if (mode === 'edit' && opened) { page.appendChild(editCard()); return; }
    if (mode === 'trash' && trashList) { page.appendChild(trashCard()); return; }
    page.appendChild(placeCard());
    if (action && !suspended) { page.appendChild(actionCard()); }
    page.appendChild(findCard());
    page.appendChild(listCard());
  }
  /* the list again, drawn in place so whatever else is open (the upload form, another form) stays as it is; note goes in
     the list's status line, error in its error line */
  function refreshList(note, error) {
    var view = page;
    var folder = cwd;
    FP.call('get', hidden ? 'filesHidden' : 'files', undefined, {name: account, path: apiPath(folder)}).then(function (r) {
      if (page !== view || cwd !== folder || mode !== 'list') { return; }
      listing = {path: folder, truncated: Boolean(r && r.truncated === true), entries: entriesOf(r && r.entries)};
      var old = page.querySelector('.fp-fm-list');
      if (!old) { return; }
      var list = listCard();
      old.parentNode.replaceChild(list, old);
      if (error) { UI.showError(list, note); } else if (note) { say(list, note); }
    }, function () { /* the form already says what happened */ });
  }
  /* where the person is when a long call starts. When it ends and they are still there, the folder is read again and
     drawn as before; when they have moved on (another folder, the editor, the trash, another form) what they have open
     stays, and the result is said aloud and in the list's own lines. */
  function here() { return {page: page, mode: mode, cwd: cwd, action: action}; }
  function stillAt(at) { return page === at.page && mode === at.mode && cwd === at.cwd && action === at.action; }
  function elsewhere(note, error) {
    if (!note) { return; }
    UI.announce(note);
    if (mode === 'list') { refreshList(note, error); }
  }
  function finished(at, note) {
    if (page !== at.page) { return; }
    if (stillAt(at)) { load(cwd, note); return; }
    elsewhere(note, false);
  }

  /* read a folder; on success it becomes the one looked at. note goes in the list's status line; focusName puts focus
     back on that entry's Actions button, focusId on that element, else the list's heading takes it */
  function load(to, note, focusName, focusId) {
    var first = listing === null;
    if (first) {
      page.textContent = '';
      page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    }
    FP.call('get', hidden ? 'filesHidden' : 'files', undefined, {name: account, path: apiPath(to)}).then(function (r) {
      r = r && typeof r === 'object' ? r : {};
      cwd = to;
      listing = {path: to, truncated: r.truncated === true, entries: entriesOf(r.entries)};
      mode = 'list';
      render();
      say(page.querySelector('.fp-fm-list'), note || '');
      if (focusId && page.querySelector('#' + focusId)) { page.querySelector('#' + focusId).focus(); } else if (focusName) { focusRow(focusName); } else if (!first) {
        focusHeading('fp-fm-list-h');
      }
    }, function (err) {
      if (first) {
        page.textContent = '';
        page.appendChild(FP.empty(t('fm_title'), tooLarge(err, to) || message(err)));
        return;
      }
      /* stay where we were, saying why the other folder didn't open */
      mode = 'list';
      render();
      showListError(tooLarge(err, to) || message(err));
      focusHeading('fp-fm-list-h');
    });
  }
  /* a folder that holds too much to list (413 too_large): its own words, since trying again gives the same answer */
  function tooLarge(err, to) { return err && err.code === 'too_large' ? t('fm_folder_too_big', {where: where(to)}) : ''; }
  function go(to) {
    action = null;
    load(to, '');
  }

  FP.view('tool:file_manager', function () {
    var tool = FP.tools.file_manager;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    account = FP.account();
    cwd = '';
    listing = null;
    action = null;
    opened = null;
    trashList = null;
    found = null;
    mode = 'list';
    suspended = false;
    hidden = UI.store.get(HIDDEN_KEY) === '1';
    page = FP.frame({title: tool.label, desc: t('fm_desc'), cls: 'fp-fm',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    /* a suspended account's files can be read but not changed: the page leaves out what would change them */
    var view = page;
    FP.summary().then(function (acc) {
      if (page !== view) { return; }
      suspended = Boolean(acc && acc.status === 'suspended');
    }, function () { /* the server says so on a change */ }).then(function () {
      if (page === view) { load('', ''); }
    });
  });
})();

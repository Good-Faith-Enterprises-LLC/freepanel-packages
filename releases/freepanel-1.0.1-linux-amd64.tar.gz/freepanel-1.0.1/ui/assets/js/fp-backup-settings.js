/* freePanel backup settings (#/tool/backup_settings), the admin panel's page for the backup schedule (docs/api.md,
   "Schedule and retention"): when the server backs up every account, how many archives of each account stay, which
   accounts are left out, a pass over every account started or stopped by hand, and how the latest pass ended, the
   copies it made to remote destinations included. A pass runs in the background, so while one does the page asks the
   server every few seconds and shows how it ended. Saving the schedule changes the schedule only: it starts nothing. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;
  var BK = FP.bk;

  var USER_RE = /^[a-z][a-z0-9]{0,15}$/;
  var TIME_RE = /^([01][0-9]|2[0-3]):[0-5][0-9]$/;
  var DAYS = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];
  /* the least and most of each count the server takes (docs/api.md) */
  var KEEP = {keep_daily: [1, 366], keep_weekly: [0, 260], keep_monthly: [0, 120]};
  var MAX_EXCLUDE = 1000;
  var POLL_MS = 3000;

  var S = null;

  var str = BK.str;
  function count(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.floor(v) : 0; }

  /* ---------- what the server says, kept to the shapes the page draws ---------- */
  function cleanSettings(r) {
    r = r && typeof r === 'object' ? r : {};
    var days = Array.isArray(r.days) ? r.days : [];
    var keep = function (k, d) { return typeof r[k] === 'number' && isFinite(r[k]) ? Math.floor(r[k]) : d; };
    return {enabled: r.enabled === true, time: TIME_RE.test(str(r.time)) ? r.time : '02:00',
      days: DAYS.filter(function (d) { return days.indexOf(d) >= 0; }),
      keep_daily: keep('keep_daily', 5), keep_weekly: keep('keep_weekly', 0), keep_monthly: keep('keep_monthly', 0),
      exclude: (Array.isArray(r.exclude) ? r.exclude : []).filter(function (u) { return USER_RE.test(str(u)); }).slice(0, MAX_EXCLUDE)};
  }
  function cleanProblems(list) {
    return (Array.isArray(list) ? list : []).slice(0, 50).map(function (e) {
      return e && typeof e === 'object' ? {username: USER_RE.test(str(e.username)) ? e.username : '', error: str(e.error).slice(0, 400),
        destination: str(e.destination).slice(0, 60)} : null;
    }).filter(Boolean);
  }
  function cleanPass(p) {
    if (!p || typeof p !== 'object') { return null; }
    return {trigger: p.trigger === 'schedule' ? 'schedule' : 'manual', started: str(p.started), total: count(p.total), done: count(p.done),
      failed: count(p.failed), current: USER_RE.test(str(p.current)) ? p.current : '', copying: str(p.copying).slice(0, 60), stopping: p.stopping === true};
  }
  function cleanLast(p) {
    if (!p || typeof p !== 'object') { return null; }
    return {trigger: p.trigger === 'schedule' ? 'schedule' : 'manual', started: str(p.started), ended: str(p.ended), total: count(p.total),
      backed: count(p.backed), failed: count(p.failed), errors: cleanProblems(p.errors), stopped: p.stopped === true, aborted: str(p.aborted).slice(0, 400),
      copied: count(p.copied), copy_failed: count(p.copy_failed), warnings: cleanProblems(p.warnings),
      destinations: (Array.isArray(p.destinations) ? p.destinations : []).slice(0, 10).map(function (d) {
        return d && typeof d === 'object' ? {name: str(d.name).slice(0, 60), copied: count(d.copied), failed: count(d.failed)} : null;
      }).filter(Boolean)};
  }
  function cleanStatus(r) {
    r = r && typeof r === 'object' ? r : {};
    return {pass: cleanPass(r.pass), last: cleanLast(r.last_pass), next: str(r.next_run), missed: str(r.missed_run),
      busy: r.running && typeof r.running === 'object' && USER_RE.test(str(r.running.username)) ? {kind: str(r.running.kind), username: r.running.username} : null};
  }

  /* ---------- the pass ---------- */
  function problemText(e) {
    var who = e.username || t('bks_server');
    return e.destination ? t('bks_problem_to', {account: who, destination: e.destination, error: e.error}) : t('bks_problem', {account: who, error: e.error});
  }
  function problemList(list, cls) {
    return el('ul', {class: 'fp-bks-list ' + cls}, list.map(function (e) { return el('li', {text: problemText(e)}); }));
  }
  function lastParts(l) {
    var w = BK.when(l.ended) || l.ended || '—';
    var out = [el('p', {'data-fp-bks-last': '', class: l.failed || l.copy_failed || l.aborted ? 'fp-bk-bad' : '', text:
      t(l.trigger === 'schedule' ? 'bks_last_schedule' : 'bks_last_manual', {when: w, backed: l.backed, total: l.total})})];
    if (l.stopped) { out.push(el('p', {class: 'fp-muted', text: t('bks_last_stopped')})); }
    if (l.aborted) { out.push(el('p', {class: 'fp-bk-bad', text: t('bks_last_aborted', {why: l.aborted})})); }
    if (l.failed) {
      out.push(el('p', {class: 'fp-bk-bad', text: t('bks_last_failed', {n: l.failed})}));
      out.push(problemList(l.errors.filter(function (e) { return !e.destination; }), 'fp-bk-bad'));
    }
    if (l.destinations.length || l.copied || l.copy_failed) {
      out.push(el('p', {class: l.copy_failed ? 'fp-bk-bad' : '', text: t('bks_last_copies', {copied: l.copied, failed: l.copy_failed})}));
      if (l.destinations.length) {
        out.push(el('ul', {class: 'fp-bks-list'}, l.destinations.map(function (d) {
          return el('li', {class: d.failed ? 'fp-bk-bad' : '', text: t('bks_last_dest', {name: d.name, copied: d.copied, failed: d.failed})});
        })));
      }
      out.push(problemList(l.errors.filter(function (e) { return e.destination; }), 'fp-bk-bad'));
    }
    if (l.warnings.length) {
      out.push(el('p', {text: t('bks_last_warnings')}));
      out.push(problemList(l.warnings, ''));
    }
    return out;
  }
  function runCard() {
    var st = S.status;
    var parts = [M.errorLine(), M.statusLine()];
    var acts = el('div', {class: 'fp-actions'});
    if (st.pass) {
      var p = st.pass;
      parts.push(el('p', {'data-fp-bks-running': '', text: t(p.trigger === 'schedule' ? 'bks_running_schedule' : 'bks_running_manual',
        {done: p.done, total: p.total, failed: p.failed})}));
      if (p.current) { parts.push(el('p', {class: 'fp-muted', text: p.copying ? t('bks_now_copying', {account: p.current, destination: p.copying}) : t('bks_now_on', {account: p.current})})); }
      if (p.stopping) {
        parts.push(el('p', {class: 'fp-muted', 'data-fp-bks-stopping': '', text: t('bks_stopping')}));
      } else {
        acts.appendChild(el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'stop', text: t('bks_stop')}));
      }
    } else {
      parts.push(el('p', {'data-fp-bks-running': '', class: 'fp-muted', text: t('bks_idle')}));
      if (st.busy) { parts.push(el('p', {class: 'fp-muted', 'data-fp-bks-busy': '', text: t('bks_busy', {kind: t('bk_kind_' + (st.busy.kind || 'backup').replace('-', '_')), account: st.busy.username})})); }
      acts.appendChild(el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'run', text: t('bks_run')}));
    }
    parts.push(acts);
    parts.push(el('p', {'data-fp-bks-next': '', class: 'fp-muted', text: S.settings.enabled ?
      (st.next ? t('bks_next', {when: BK.when(st.next) || st.next}) : t('bks_next_none')) : t('bks_off')}));
    if (st.missed) { parts.push(el('p', {'data-fp-bks-missed': '', class: 'fp-bk-bad', text: t('bks_missed', {when: BK.when(st.missed) || st.missed})})); }
    if (st.last) {
      parts.push(el('h3', {class: 'fp-h3', text: t('bks_last_title')}));
      lastParts(st.last).forEach(function (n) { parts.push(n); });
    } else {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-bks-last': '', text: t('bks_last_none')}));
    }
    return M.card('fp-bks-run-h', t('bks_run_title'), parts, 'fp-bks-run');
  }
  function drawRun() {
    var old = S.page.querySelector('.fp-bks-run');
    var fresh = runCard();
    var active = document.activeElement;
    var act = old && active && old.contains(active) ? active.getAttribute('data-fp-act') : null;
    if (old) { old.replaceWith(fresh); } else { S.page.insertBefore(fresh, S.page.firstChild); }
    if (act) {
      var again = fresh.querySelector('[data-fp-act="' + act + '"]') || fresh.querySelector('#fp-bks-run-h');
      if (again) { again.focus(); }
    }
  }

  /* while a pass runs, asks how it is every few seconds; when it ends, says how and shows the latest */
  function poll() {
    window.clearTimeout(S.timer);
    var mine = S;
    S.timer = window.setTimeout(function () {
      if (S !== mine || !document.body.contains(mine.page)) { return; }
      FP.call('get', 'backupStatus').then(function (r) {
        if (S !== mine) { return; }
        var was = mine.status.pass;
        mine.status = cleanStatus(r);
        drawRun();
        if (mine.status.pass) { poll(); return; }
        if (was && mine.watching) { M.say(mine.page.querySelector('.fp-bks-run'), t('bks_ended')); }
        mine.watching = false;
      }, function () { if (S === mine) { poll(); } });
    }, POLL_MS);
  }
  function onClick(e) {
    var target = e.target && e.target.closest ? e.target : null;
    var b = target && S && S.page && S.page.contains(target) ? target.closest('[data-fp-act]') : null;
    if (!b) { return; }
    var act = b.getAttribute('data-fp-act');
    if (act !== 'run' && act !== 'stop') { return; }
    var card = S.page.querySelector('.fp-bks-run');
    UI.showError(card, '');
    M.say(card, '');
    UI.setBusy(b, true);
    var mine = S;
    FP.call(act === 'run' ? 'post' : 'del', 'backupRun').then(function (r) {
      if (S !== mine) { return; }
      var p = cleanPass(r && r.pass);
      if (p) { mine.status.pass = p; }
      mine.watching = true;
      drawRun();
      mine.page.querySelector('#fp-bks-run-h').focus();
      M.say(mine.page.querySelector('.fp-bks-run'), t(act === 'run' ? 'bks_run_started' : 'bks_stop_asked'));
      poll();
    }, function (err) {
      if (S !== mine) { return; }
      UI.setBusy(b, false);
      UI.showError(card, err.message);
      b.focus();
    });
  }
  document.addEventListener('click', onClick);

  /* ---------- the schedule ---------- */
  function number(id, name, label, hint, value) {
    var lim = KEEP[name];
    return M.field(id, label, el('input', {class: 'sig-input fp-num-input', id: id, name: name, type: 'number', inputmode: 'numeric', min: String(lim[0]),
      max: String(lim[1]), step: '1', value: String(value)}), hint);
  }
  function formCard() {
    var s = S.settings;
    var form = el('form', {class: 'fp-form fp-mail-form fp-bks-form', novalidate: '', 'data-fp-form': 'schedule'}, [M.errorLine(), M.statusLine()]);
    form.appendChild(el('label', {class: 'fp-check', for: 'fp-bks-enabled'}, [el('input', {type: 'checkbox', id: 'fp-bks-enabled', name: 'enabled', checked: s.enabled}),
      el('span', {text: t('bks_enabled')})]));
    form.appendChild(M.field('fp-bks-time', t('bks_time'), el('input', {class: 'sig-input fp-time-input', id: 'fp-bks-time', name: 'time', type: 'text', inputmode: 'numeric',
      autocomplete: 'off', spellcheck: 'false', maxlength: '5', placeholder: 'HH:MM', value: s.time}), t('bks_time_hint')));
    form.appendChild(el('fieldset', {class: 'fp-bk-parts', id: 'fp-bks-days'}, [el('legend', {class: 'sig-label', text: t('bks_days')})].concat(DAYS.map(function (d) {
      return el('label', {class: 'fp-check', for: 'fp-bks-day-' + d}, [el('input', {type: 'checkbox', id: 'fp-bks-day-' + d, name: 'days', value: d,
        checked: s.days.indexOf(d) >= 0}), el('span', {text: t('bks_day_' + d)})]);
    })).concat([el('span', {class: 'sig-hint', text: t('bks_days_hint')})])));
    form.appendChild(el('h3', {class: 'fp-h3', text: t('bks_keep_title')}));
    form.appendChild(el('p', {class: 'fp-muted', text: t('bks_keep_desc')}));
    form.appendChild(number('fp-bks-daily', 'keep_daily', t('bks_keep_daily'), t('bks_keep_daily_hint'), s.keep_daily));
    form.appendChild(number('fp-bks-weekly', 'keep_weekly', t('bks_keep_weekly'), t('bks_keep_weekly_hint'), s.keep_weekly));
    form.appendChild(number('fp-bks-monthly', 'keep_monthly', t('bks_keep_monthly'), t('bks_keep_monthly_hint'), s.keep_monthly));
    form.appendChild(M.field('fp-bks-exclude', t('bks_exclude'), el('textarea', {class: 'sig-input', id: 'fp-bks-exclude', name: 'exclude', rows: '4',
      autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', text: s.exclude.join('\n')}), t('bks_exclude_hint')));
    form.appendChild(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bks_save')})]));
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      submit(form);
    });
    return M.card('fp-bks-form-h', t('bks_form_title'), [el('p', {class: 'fp-muted', text: t('bks_form_desc')}), form], 'fp-bks-schedule');
  }
  /* the form's values as the server takes them; null, with the field marked, when one is plainly wrong */
  function read(form) {
    var bad = function (field, message) { M.fieldError(form, UI.fieldNamed(form, field), message); return null; };
    var time = form.querySelector('[name="time"]').value.trim();
    if (!TIME_RE.test(time)) { return bad('time', t('bks_time_bad')); }
    var days = DAYS.filter(function (d) { return form.querySelector('#fp-bks-day-' + d).checked; });
    if (!days.length) { return bad('days', t('bks_days_pick')); }
    var body = {enabled: form.querySelector('[name="enabled"]').checked, time: time, days: days};
    var fields = Object.keys(KEEP);
    for (var i = 0; i < fields.length; i++) {
      var k = fields[i];
      var raw = form.querySelector('[name="' + k + '"]').value.trim();
      var n = /^[0-9]{1,4}$/.test(raw) ? parseInt(raw, 10) : -1;
      if (n < KEEP[k][0] || n > KEEP[k][1]) { return bad(k, t('bks_keep_bad', {min: KEEP[k][0], max: KEEP[k][1]})); }
      body[k] = n;
    }
    var names = [];
    var lines = form.querySelector('[name="exclude"]').value.split(/[\s,]+/);
    for (var j = 0; j < lines.length; j++) {
      var u = lines[j].trim().toLowerCase();
      if (!u) { continue; }
      if (!USER_RE.test(u)) { return bad('exclude', t('bks_exclude_bad', {name: u.slice(0, 40)})); }
      if (names.indexOf(u) < 0) { names.push(u); }
    }
    if (names.length > MAX_EXCLUDE) { return bad('exclude', t('bks_exclude_many', {n: MAX_EXCLUDE})); }
    body.exclude = names;
    return body;
  }
  function submit(form) {
    var b = M.start(form);
    if (!b) { return; }
    var body = read(form);
    if (!body) { return; }
    var mine = S;
    UI.setBusy(b, true);
    FP.call('put', 'backupSettings', body).then(function (r) {
      UI.setBusy(b, false);
      if (S !== mine) { return; }
      mine.settings = cleanSettings(r);
      /* the form shows what the server kept (names in order, repeats gone) */
      form.querySelector('[name="exclude"]').value = mine.settings.exclude.join('\n');
      M.say(form, t(mine.settings.enabled ? 'bks_saved_on' : 'bks_saved_off'));
      FP.call('get', 'backupStatus').then(function (st) {
        if (S !== mine) { return; }
        mine.status = cleanStatus(st);
        drawRun();
        if (mine.status.pass) { poll(); }
      }, function () { /* the next look at the pass shows it */ });
    }, function (err) {
      UI.setBusy(b, false);
      if (S !== mine) { return; }
      M.failed(form, err);
    });
  }

  FP.view('tool:backup_settings', function () {
    var tool = FP.tools.backup_settings;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('bks_desc'), cls: 'fp-mail fp-bk fp-bks',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    if (S) { window.clearTimeout(S.timer); }
    S = {page: body, settings: cleanSettings(null), status: cleanStatus(null), timer: 0, watching: false};
    var mine = S;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all([FP.call('get', 'backupSettings'), FP.call('get', 'backupStatus')]).then(function (r) {
      if (S !== mine) { return; }
      mine.settings = cleanSettings(r[0]);
      mine.status = cleanStatus(r[1]);
      body.textContent = '';
      body.appendChild(runCard());
      body.appendChild(formCard());
      if (mine.status.pass) { poll(); }
    }, function (err) {
      if (S !== mine) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

/* freePanel: change the password you sign in with (docs/api.md, POST /auth/password), the same page in both panels:
   Preferences > Password in the customer panel (#/tool/password), Security > My password in the admin panel
   (#/tool/my_password). The server checks the current password against the same limit as sign-ins and ends every
   other session; this one stays signed in. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var MIN = 12;
  var MAX = 1024;

  var page = null;
  function errorLine() { return el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': ''}); }
  function field(id, name, label, autocomplete, hint, reveal) {
    var input = el('input', {class: 'sig-input', id: id, name: name, type: 'password', autocomplete: autocomplete, maxlength: String(MAX),
      spellcheck: 'false', autocapitalize: 'none'});
    if (hint) { input.setAttribute('aria-describedby', id + '-hint'); }
    var control = reveal ? el('div', {class: 'fp-reveal-wrap'}, [input, el('button', {class: 'sig-ghost fp-reveal', type: 'button', 'data-overlap-ok': '',
      'data-fp-reveal': reveal, 'aria-pressed': 'false', 'aria-label': 'Show password'}, [UI.icon(FP.ui, 'ui_eye')])]) : input;
    return el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: id, text: label}), control,
      hint ? el('span', {class: 'sig-hint', id: id + '-hint', text: hint}) : null]);
  }
  function mark(form, input, message) {
    UI.showError(form, message);
    input.setAttribute('aria-invalid', 'true');
    input.focus();
  }

  function render() {
    var form = el('form', {class: 'fp-form fp-pw-form', novalidate: ''}, [errorLine(),
      el('p', {class: 'fp-ok-line', role: 'status', 'data-fp-status': ''}),
      field('fp-pw-current', 'current_password', t('pw_current'), 'current-password', '', 'fp-pw-current'),
      field('fp-pw-new', 'new_password', t('pw_new'), 'new-password', t('pw_new_hint'), 'fp-pw-new,fp-pw-again'),
      field('fp-pw-again', 'again', t('pw_again'), 'new-password', ''),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('pw_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = form.querySelector('.fp-submit');
      if (b.disabled) { return; }
      var cur = form.querySelector('#fp-pw-current');
      var next = form.querySelector('#fp-pw-new');
      var again = form.querySelector('#fp-pw-again');
      UI.showError(form, '');
      form.querySelector('[data-fp-status]').textContent = '';
      [cur, next, again].forEach(function (i) { i.removeAttribute('aria-invalid'); });
      if (!cur.value) { mark(form, cur, t('pw_need_current')); return; }
      if (next.value.length < MIN) { mark(form, next, t('weak_password')); return; }
      if (next.value === cur.value) { mark(form, next, t('pw_same')); return; }
      if (again.value !== next.value) { mark(form, again, t('passwords_differ')); return; }
      UI.setBusy(b, true);
      FP.call('post', 'password', {current_password: cur.value, new_password: next.value}).then(function () {
        UI.setBusy(b, false);
        cur.value = next.value = again.value = '';
        form.querySelector('[data-fp-status]').textContent = t('pw_changed');
        page.querySelector('#fp-pw-h').focus();
      }, function (err) {
        UI.setBusy(b, false);
        if (err.code === 'forbidden') {
          cur.value = '';
          mark(form, cur, t('pw_wrong_current'));
        } else if (err.code === 'validation_failed' && err.field === 'new_password') {
          mark(form, next, t('pw_new') + ': ' + err.message);
        } else {
          UI.showError(form, err.message);
        }
      });
    });
    page.textContent = '';
    page.appendChild(el('section', {class: 'sig-card fp-pw-card', 'aria-labelledby': 'fp-pw-h'}, [el('div', {class: 'sig-card-body'}, [
      el('h2', {class: 'fp-h2', id: 'fp-pw-h', tabindex: '-1', text: t('pw_title')}),
      el('p', {class: 'fp-muted', text: t('pw_note')}), form])]));
  }

  function view(id, realm) {
    FP.view('tool:' + id, function () {
      page = null;
      var tool = FP.tools[id];
      if (!tool || FP.realm !== realm) { FP.views['not-found']({view: 'not-found'}); return; }
      var g = FP.group(tool.group);
      page = FP.frame({title: tool.label, desc: t('pw_desc'), cls: 'fp-pw',
        crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
      render();
    });
  }
  view('password', 'user');
  view('my_password', 'admin');
})();

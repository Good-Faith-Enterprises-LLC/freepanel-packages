/* freePanel reverse DNS (docs/api.md, "Reverse DNS"): the admin panel's page (#/tool/reverse_dns) for the names the server's own addresses answer to.
   Each address shows what the world is told for it (as this server's resolvers see it), whether that name matches the server's name and leads
   back to the address (what other mail servers check), and the name this server serves for it, if any. Serving a name makes a reverse zone for
   the /24 or /64 around the address, which the world sees only when the hosting provider hands that zone to this server's name servers: the page
   says so. Admin only: the server refuses these calls to anyone else. Everything the server sends is shown as text. The page pieces come from
   FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var HOST_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var IP_RE = /^[0-9A-Fa-f:.]{2,45}$/;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  function clean(v) {
    v = v && typeof v === 'object' ? v : {};
    var seen = {};
    return {hostname: str(v.hostname, 253), canServe: v.can_serve === true,
      addresses: (Array.isArray(v.addresses) ? v.addresses : []).filter(function (a) {
        if (!a || typeof a !== 'object' || !IP_RE.test(str(a.ip, 45)) || seen[a.ip]) { return false; }
        seen[a.ip] = true;
        return true;
      }).slice(0, 64).map(function (a) {
        var s = a.served && typeof a.served === 'object' && str(a.served.hostname, 253) ? {hostname: str(a.served.hostname, 253), zone: str(a.served.zone, 253)} : null;
        return {ip: a.ip, family: a.family === 6 ? 6 : 4, iface: str(a.interface, 40), served: s,
          seen: (Array.isArray(a.seen) ? a.seen : []).filter(function (n) { return typeof n === 'string' && n; }).map(function (n) { return n.slice(0, 253); }).slice(0, 10),
          rcode: str(a.seen_rcode, 20), seenError: str(a.seen_error, 300), confirmed: a.forward_confirmed === true, matches: a.matches_hostname === true};
      })};
  }

  var R = {page: null, S: null, busy: false};

  function yesNo(ok, yes, no) { return el('span', {class: 'sig-pill ' + (ok ? 'sig-pill--ok' : 'sig-pill--warn'), text: ok ? yes : no}); }
  function fact(label, value, attr) {
    var dd = el('dd', attr || {}, Array.isArray(value) ? value : [value]);
    return el('div', {}, [el('dt', {text: label}), dd]);
  }
  function seenText(a) {
    if (a.seen.length) { return a.seen.join(', '); }
    if (a.seenError) { return t('rvd_seen_error', {error: a.seenError}); }
    return a.rcode === 'NXDOMAIN' ? t('rvd_seen_nxdomain') : t('rvd_seen_none');
  }
  function addressForm(a, i) {
    var id = 'fp-rvd-' + i;
    var input = el('input', {class: 'sig-input sig-mono', id: id + '-name', name: 'hostname', type: 'text', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', maxlength: '253',
      value: a.served ? a.served.hostname : R.S.hostname, 'aria-describedby': id + '-name-hint'});
    var form = el('form', {class: 'fp-form fp-rvd-form', novalidate: '', 'data-fp-ip': a.ip}, [M.errorLine(),
      M.field(id + '-name', t('rvd_name'), input, t('rvd_name_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: a.served ? t('rvd_change') : t('rvd_serve')}),
        a.served ? el('button', {class: 'sig-btn sig-btn--secondary fp-btn-danger-text', type: 'button', 'data-fp-act': 'rvd-stop', 'aria-label': t('rvd_stop_of', {ip: a.ip}), text: t('rvd_stop')}) : null])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || R.busy) { return; }
      var v = input.value.trim().toLowerCase().replace(/\.$/, '');
      if (!HOST_RE.test(v)) { M.fieldError(form, input, t('rvd_name_bad')); return; }
      R.busy = true;
      UI.setBusy(b, true);
      var mine = R.page;
      FP.call('put', 'reverseIp', {hostname: v}, {ip: a.ip}).then(function (r) {
        R.busy = false;
        if (R.page !== mine) { return; }
        a.served = {hostname: str(r && r.hostname, 253) || v, zone: str(r && r.zone, 253)};
        render();
        var card = R.page.querySelector('li[data-fp-ip="' + window.CSS.escape(a.ip) + '"]');
        M.say(card, t('rvd_saved', {ip: a.ip}));
        card.querySelector('.fp-rvd-title').focus();
      }, function (err) {
        R.busy = false;
        if (R.page !== mine) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return form;
  }
  function addressCard(a, i) {
    var id = 'fp-rvd-' + i;
    var facts = [
      fact(t('rvd_world'), seenText(a), {'data-fp-seen': ''}),
      fact(t('rvd_matches', {name: R.S.hostname}), a.seen.length ? yesNo(a.matches, t('rvd_yes'), t('rvd_no')) : t('rvd_na'), {'data-fp-matches': a.seen.length ? (a.matches ? 'yes' : 'no') : 'na'}),
      fact(t('rvd_confirmed'), a.seen.length ? yesNo(a.confirmed, t('rvd_yes'), t('rvd_no')) : t('rvd_na'), {'data-fp-confirmed': a.seen.length ? (a.confirmed ? 'yes' : 'no') : 'na'}),
      fact(t('rvd_served'), a.served ? a.served.hostname : t('rvd_served_none'), {'data-fp-served': a.served ? 'yes' : 'no'})];
    var parts = [M.statusLine(), el('dl', {class: 'fp-rvd-facts'}, facts)];
    if (a.served && a.served.zone) { parts.push(el('p', {class: 'fp-muted', 'data-fp-delegation': '', text: t('rvd_delegation', {zone: a.served.zone})})); }
    if (R.S.canServe) { parts.push(addressForm(a, i)); }
    return el('li', {class: 'sig-card fp-rvd-card', 'data-fp-ip': a.ip, 'aria-labelledby': id + '-h'}, [el('div', {class: 'sig-card-body'}, [
      el('h2', {class: 'fp-h2 fp-rvd-title', id: id + '-h', tabindex: '-1'}, [el('span', {class: 'sig-mono', text: a.ip}), ' ', el('span', {class: 'sig-pill', text: a.family === 6 ? 'IPv6' : 'IPv4'}),
        a.iface ? el('span', {class: 'fp-muted fp-rvd-iface', text: ' ' + t('rvd_on', {iface: a.iface})}) : null])].concat(parts))]);
  }
  function render() {
    var S = R.S;
    R.page.textContent = '';
    var intro = [el('p', {class: 'fp-muted', text: t('rvd_what')}), el('p', {class: 'fp-muted', text: t('rvd_server_name', {name: S.hostname || '?'})})];
    if (!S.canServe) { intro.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-rvd-cannot': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('rvd_cannot')})])); }
    R.page.appendChild(M.card('fp-rvd-intro-h', t('rvd_title'), intro, 'fp-rvd-intro'));
    if (!S.addresses.length) {
      R.page.appendChild(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('rvd_none')}));
      return;
    }
    R.page.appendChild(el('ul', {class: 'fp-rvd-list', 'aria-label': t('rvd_list')}, S.addresses.map(addressCard)));
  }

  document.addEventListener('click', function (e) {
    var node = e.target.closest ? e.target : null;
    var b = node && node.closest('[data-fp-act]');
    if (!b || !R.page || !R.page.contains(b) || !R.S) { return; }
    var a = b.getAttribute('data-fp-act');
    var li = b.closest('li[data-fp-ip]');
    var ip = li ? li.getAttribute('data-fp-ip') : '';
    var addr = R.S.addresses.filter(function (x) { return x.ip === ip; })[0];
    if (!addr) { return; }
    var mine = R.page;
    if (a === 'rvd-stop') {
      M.confirmIn(b.parentNode, t('rvd_stop_ask', {ip: ip, name: addr.served ? addr.served.hostname : ''}), 'rvd-stop-yes', t('rvd_stop'));
    } else if (a === 'confirm-no') {
      render();
      var back = R.page.querySelector('li[data-fp-ip="' + window.CSS.escape(ip) + '"] [data-fp-act="rvd-stop"]');
      if (back) { back.focus(); }
    } else if (a === 'rvd-stop-yes' && !R.busy) {
      R.busy = true;
      UI.setBusy(b, true);
      FP.call('del', 'reverseIp', undefined, {ip: ip}).then(function () {
        R.busy = false;
        if (R.page !== mine) { return; }
        addr.served = null;
        render();
        var card = R.page.querySelector('li[data-fp-ip="' + window.CSS.escape(ip) + '"]');
        M.say(card, t('rvd_stopped', {ip: ip}));
        card.querySelector('.fp-rvd-title').focus();
      }, function (err) {
        R.busy = false;
        if (R.page !== mine) { return; }
        if (err && err.status === 404) { addr.served = null; }
        render();
        var card2 = R.page.querySelector('li[data-fp-ip="' + window.CSS.escape(ip) + '"]');
        UI.showError(card2.querySelector('form') || card2, err.message);
        card2.querySelector('.fp-rvd-title').focus();
      });
    }
  });

  FP.view('tool:reverse_dns', function () {
    var tool = FP.tools.reverse_dns;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    R.S = null;
    R.busy = false;
    var body = FP.frame({title: tool.label, desc: t('rvd_desc'), cls: 'fp-mail fp-srv fp-rvd-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    R.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'reverse').then(function (r) {
      if (R.page !== body) { return; }
      R.S = clean(r);
      render();
    }, function (err) {
      if (R.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

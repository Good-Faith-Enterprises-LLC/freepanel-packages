/* freePanel billing messages of the Utilities group (docs/api.md, "Billing: automation" and "Billing: messages"; docs/billing/navigation-map.md,
   "Utilities"): Notices (#/tool/billing_notices), the reminders and service notices the daily run made, waiting to be sent or sent, filtered by
   kind, state and client. A notice is written out and sent by a sending round (the Message log), so this list only reads. Mass message
   (#/tool/billing_mass_mail), one message to the clients of a status, a group or with a service: counted first (a dry run), then a copy
   queued for each after a question that names how many. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;
  var M = FP.mail;

  var KINDS = ['reminder', 'overdue', 'suspended', 'unsuspended', 'terminated'];
  var NOTICE = {id: 'id', customer_id: 'id', invoice_id: 'id', service_id: 'id', kind: ['=', KINDS], status: ['=', ['queued', 'sent', 'failed']], created: 'w', sent: 'w'};
  function clean(x) { var n = B.pick(x, NOTICE); return n && n.id ? n : null; }
  var X = null;
  FP.view('tool:billing_notices', function () {
    var page = B.frame('billing_notices', 'fp-bnt');
    if (!page) { return; }
    X = {page: page, names: {}};
    var mine = X;
    var alive = function () { return X === mine && page.isConnected; };
    var L = B.lister({page: page, pre: 'fp-bnt', title: t('bnt_list_title'), findLabel: t('bnt_find'), tableCls: 'fp-bnt-table', alive: alive,
      before: function () {
        return [el('p', {class: 'fp-muted fp-row-note', text: t('bnt_what')}),
          FP.tools.billing_outbox ? el('div', {class: 'fp-bil-toolbar'}, [B.button('open-outbox', t('bnt_to_outbox'), 'sig-btn--secondary sig-btn--sm')]) : null].filter(Boolean);
      },
      blank: {kind: '', status: '', customer: ''},
      filters: [
        {name: 'kind', label: t('bnt_f_kind'), control: function (v) { return B.select('fp-bnt-f-kind', 'kind', [['', t('bil_any')]].concat(KINDS.map(function (k) { return [k, B.word('mkind', k)]; })), v); }},
        {name: 'status', label: t('bnt_f_status'), control: function (v) { return B.select('fp-bnt-f-status', 'status', [['', t('bil_any')]].concat(['queued', 'sent', 'failed'].map(function (s) { return [s, B.word('msg', s)]; })), v); }},
        {name: 'customer', control: function (v) { return B.clientPicker('fp-bnt-f-client', {name: 'customer', label: t('bnt_f_client'), placeholder: t('bil_any'), value: v, valueName: v ? X.names[v] : ''}); }}],
      load: function (f, offset, limit) {
        return B.listOf('billingNotices', {limit: String(limit), offset: String(offset), kind: f.kind, status: f.status, customer: f.customer}, 'notices', clean).then(function (r) {
          return B.namesFor(X.names, r.items.map(function (x) { return x.customer_id; })).then(function () { return r; });
        });
      },
      heads: [B.th(t('bnt_col_made')), B.th(t('bnt_col_client')), B.th(t('bnt_col_kind')), B.th(t('bnt_col_about')), B.th(t('bnt_col_status')), B.th(t('bnt_col_sent'))],
      row: function (n) {
        var about = n.invoice_id ? (FP.tools.billing_invoices ? B.button('open-invoice', t('binv_invoice_ref', {id: String(n.invoice_id)}), 'sig-btn--link fp-bil-link', {'data-fp-id': String(n.invoice_id), 'aria-label': t('bcl_open_invoice_id', {id: String(n.invoice_id)})})
          : t('binv_invoice_ref', {id: String(n.invoice_id)})) : n.service_id ? t('bnt_service_n', {id: String(n.service_id)}) : '—';
        return el('tr', {'data-fp-notice': String(n.id)}, [el('td', {class: 'fp-bil-nowrap', text: B.when(n.created) || '—'}), el('td', {class: 'fp-bil-wrap'}, [B.clientLink(X.names, n.customer_id)]),
          el('th', {scope: 'row', text: n.kind ? B.word('mkind', n.kind) : '—'}), el('td', null, [about]), el('td', null, [B.statePill('msg', n.status)]),
          el('td', {class: 'fp-bil-nowrap', text: B.when(n.sent) || '—'})]);
      },
      none: t('bnt_none'), noneMatch: t('bnt_none_match'),
      found: function (n) { return n === 1 ? t('bnt_found_1') : t('bnt_found', {n: B.num(n)}); }});
    page.addEventListener('click', function (e) {
      var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
      if (!b || b.disabled || !alive()) { return; }
      var a = b.getAttribute('data-fp-act');
      var xid = Number(b.getAttribute('data-fp-id')) || 0;
      if (a === 'open-invoice' && xid) { B.go('billing_invoices', {invoice: xid}); } else if (a === 'open-client' && xid) { B.go('billing_clients', {client: xid}); } else if (a === 'open-outbox') { window.location.hash = '#/tool/billing_outbox'; }
    });
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    L.show();
  });

  /* ---- a message to many clients: who gets it, the words, a count first (a dry run), then the messages queued after a question ---- */
  var COMMON = ['customer_name', 'customer_company', 'customer_email', 'company_name', 'company_email', 'company_website', 'account_url'];
  FP.view('tool:billing_mass_mail', function () {
    var page = B.frame('billing_mass_mail', 'fp-bmm');
    if (!page) { return; }
    var alive = function () { return page.isConnected; };
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    function draw(groups, mail, said) {
      var status = B.select('fp-bmm-status', 'status', ['active', 'inactive', 'closed'].map(function (s) { return [s, B.word('client', s)]; }), 'active');
      var group = B.select('fp-bmm-group', 'group_id', [['', t('bmm_any_group')]].concat(groups.map(function (g) { return [String(g.id), g.name]; })), '');
      var withSvc = el('input', {type: 'checkbox', id: 'fp-bmm-with_service', name: 'with_service', 'aria-describedby': 'fp-bmm-with_service-hint'});
      var subject = B.input('fp-bmm-subject', 'subject', '', {maxlength: '200', 'aria-required': 'true'});
      var body = el('textarea', {class: 'sig-input fp-bil-text', id: 'fp-bmm-body', name: 'body', rows: '8', maxlength: '10000', 'aria-required': 'true'});
      var count = B.button('count', t('bmm_count'), 'sig-btn--secondary');
      var send = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bmm_send')});
      var form = el('form', {class: 'fp-form fp-bil-crud-form fp-bmm-form', novalidate: '', 'aria-labelledby': 'fp-bmm-h'}, [M.errorLine(), M.statusLine(),
        el('fieldset', {class: 'fp-bil-set'}, [el('legend', {class: 'fp-bil-legend', text: t('bmm_who')}), el('div', {class: 'fp-bil-grid'}, [M.field('fp-bmm-status', t('bmm_status'), status, t('bmm_status_hint')),
          groups.length ? M.field('fp-bmm-group', t('bmm_group'), group) : null,
          el('div', {class: 'sig-field fp-bil-check-field'}, [el('label', {class: 'fp-bil-check', for: 'fp-bmm-with_service'}, [withSvc, el('span', {text: t('bmm_with_service')})]),
            el('span', {class: 'sig-hint', id: 'fp-bmm-with_service-hint', text: t('bmm_with_service_hint')})])].filter(Boolean))]),
        el('fieldset', {class: 'fp-bil-set'}, [el('legend', {class: 'fp-bil-legend', text: t('bmm_words')}), el('div', {class: 'fp-bil-grid'}, [M.field('fp-bmm-subject', t('bmm_subject'), subject, t('bmm_subject_hint')),
          (function () { var f = M.field('fp-bmm-body', t('bmm_body'), body, t('bmm_body_hint')); f.classList.add('fp-bil-wide'); return f; })()]),
          el('p', {class: 'fp-muted fp-row-note', 'data-fp-placeholders': ''}, [el('span', {text: t('bmm_placeholders') + ' '})].concat(COMMON.map(function (p, i) {
            return el('span', null, [el('code', {text: '{' + p + '}'}), i < COMMON.length - 1 ? el('span', {text: ' '}) : null]);
          })))]),
        el('div', {class: 'fp-actions', 'data-fp-acts': ''}, [send, count])]);
      function read() {
        var out = {subject: subject.value.trim(), body: body.value, status: status.value, with_service: withSvc.checked};
        if (group.value) { out.group_id = Number(group.value); }
        if (!out.subject) { M.fieldError(form, subject, t('bil_needed', {name: t('bmm_subject')})); return null; }
        if (!out.body.trim()) { M.fieldError(form, body, t('bil_needed', {name: t('bmm_body')})); return null; }
        return out;
      }
      function acts(nodes, focus) {
        var box = form.querySelector('[data-fp-acts]');
        box.textContent = '';
        nodes.forEach(function (n) { box.appendChild(n); });
        UI.setBusy(send, false);
        UI.setBusy(count, false);
        if (focus) { focus.focus(); }
      }
      /* a dry run: how many clients would get it */
      function dry(b, then) {
        if (!B.begin(form, b)) { return; }
        var msg = read();
        if (!msg) { return; }
        UI.setBusy(b, true);
        FP.call('post', 'billingMassMail', Object.assign({dry_run: true}, msg)).then(function (r) {
          if (!alive()) { return; }
          UI.setBusy(b, false);
          then(B.whole(r && r.customers) || 0, msg);
        }, function (err) {
          if (!alive()) { return; }
          UI.setBusy(b, false);
          B.failed(form, err);
        });
      }
      count.addEventListener('click', function () {
        dry(count, function (n) { M.say(form, n === 0 ? t('bmm_count_0') : n === 1 ? t('bmm_count_1') : t('bmm_count_n', {n: B.num(n)})); });
      });
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        dry(send, function (n, msg) {
          if (!n) { M.say(form, t('bmm_count_0')); return; }
          form.setAttribute('data-fp-asked', String(n));
          form.fpMsg = msg;
          M.confirmIn(form.querySelector('[data-fp-acts]'), n === 1 ? t('bmm_ask_1') : t('bmm_ask', {n: B.num(n)}), 'queue-yes', t('bmm_yes'));
        });
      });
      form.addEventListener('click', function (e) {
        var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
        if (!b || b.disabled || !alive()) { return; }
        var a = b.getAttribute('data-fp-act');
        if (a === 'confirm-no') {
          acts([send, count], send);
        } else if (a === 'queue-yes') {
          UI.setBusy(b, true);
          FP.call('post', 'billingMassMail', form.fpMsg).then(function (r) {
            if (!alive()) { return; }
            var q = B.whole(r && r.queued) || 0;
            draw(groups, mail, q === 1 ? t('bmm_queued_1') : t('bmm_queued', {n: B.num(q)}));
          }, function (err) {
            if (!alive()) { return; }
            acts([send, count], send);
            B.failed(form, err);
          });
        }
      });
      B.screen(page, [mail && !mail.enabled ? el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-sending-off': ''}, [UI.icon(FP.ui, 'ui_warning'), el('div', null, [
        el('span', {text: t('bmm_sending_off') + ' '}), FP.tools.billing_templates ? B.button('open-templates', t('bmm_open_templates'), 'sig-btn--link fp-bil-link') : null])]) : null,
        B.card('fp-bmm-h', t('bmm_title'), [el('p', {class: 'fp-muted', text: t('bmm_what')}), form], 'fp-bmm', 'message')], said ? '#fp-bmm-h' : null);
      if (said) { M.say(form, said); }
    }
    page.addEventListener('click', function (e) {
      var b = e.target && e.target.closest ? e.target.closest('[data-fp-act="open-templates"]') : null;
      if (b && alive()) { window.location.hash = '#/tool/billing_templates'; }
    });
    function load() {
      Promise.all([FP.call('get', 'billingGroups').then(function (r) { return B.pickAll(r && r.groups, {id: 'id', name: [60]}, 'id'); }),
        FP.call('get', 'billingMail').then(function (r) { return {enabled: Boolean(r && r.enabled === true)}; }, function () { return null; })]).then(function (r) {
        if (alive()) { draw(r[0], r[1]); }
      }, function (err) {
        if (!alive()) { return; }
        B.screen(page, [FP.empty(t('bmm_title'), err.message, B.button('reload', t('bil_try_again')))]);
        page.querySelector('[data-fp-act="reload"]').addEventListener('click', load);
      });
    }
    load();
  });
})();

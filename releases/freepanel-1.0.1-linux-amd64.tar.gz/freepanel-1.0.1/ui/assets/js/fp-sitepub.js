/* freePanel Site Publisher page (#/tool/site_publisher, docs/api.md, "Site Publisher"): in the customer panel, pick one of a site's pages, fill in a few words and
   publish it as the site's front page; change it later, or take it away. A front page the panel did not make is replaced only after a question. What is typed is
   sent as text and shown as text; what the server answers is cleaned to the shapes drawn. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var el = UI.el;
  var M = FP.mail;

  var t = UI.t;

  var P = null;
  var TEMPLATES = [];
  var ACCENTS = [];

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  function host(v) { return typeof v === 'string' && /^[a-z0-9.-]{1,253}$/i.test(v) ? v : ''; }
  function listOf(r) {
    r = r && typeof r === 'object' ? r : {};
    TEMPLATES = (Array.isArray(r.templates) ? r.templates : []).map(function (x) {
      return {id: /^[a-z-]{1,30}$/.test(x && x.id) ? x.id : '', name: str(x && x.name, 40), desc: str(x && x.description, 200)};
    }).filter(function (x) { return x.id && x.name; });
    ACCENTS = (Array.isArray(r.accents) ? r.accents : []).map(function (x) {
      return {id: /^[a-z]{1,20}$/.test(x && x.id) ? x.id : '', name: str(x && x.name, 30)};
    }).filter(function (x) { return x.id && x.name; });
    return (Array.isArray(r.sites) ? r.sites : []).map(function (s) {
      return {domain: host(s && s.domain), kind: str(s && s.kind, 20), folder: str(s && s.folder, 300)};
    }).filter(function (s) { return s.domain; });
  }
  function stateOf(r) {
    r = r && typeof r === 'object' ? r : {};
    var f = r.fields && typeof r.fields === 'object' ? r.fields : {};
    var out = {domain: host(r.domain), folder: str(r.folder, 300), state: ['empty', 'published', 'other'].indexOf(r.state) >= 0 ? r.state : 'empty', template: str(r.template, 30),
      others: (Array.isArray(r.others) ? r.others : []).map(function (x) { return str(x, 30); }).filter(function (x) { return /^index\.(html|htm|php)$/.test(x); }), warning: str(r.warning, 300),
      fields: {title: str(f.title, 80), tagline: str(f.tagline, 120), about: str(f.about, 2000), email: str(f.email, 254), phone: str(f.phone, 30), address: str(f.address, 200), accent: str(f.accent, 20)}};
    return out;
  }
  function names(list) { return list.length ? list.join(', ') : 'index.html'; }
  function tplName(id) {
    for (var i = 0; i < TEMPLATES.length; i++) { if (TEMPLATES[i].id === id) { return TEMPLATES[i].name; } }
    return id;
  }

  function radios(name, legend, items, current, describe) {
    var group = el('fieldset', {class: 'fp-spb-choice'}, [el('legend', {class: 'sig-label', text: legend})].concat(items.map(function (it, i) {
      var id = 'fp-spb-' + name + '-' + i;
      var input = el('input', {type: 'radio', id: id, name: name, value: it.id, checked: it.id === current ? true : null});
      var body = [el('span', {class: 'fp-spb-choice-name', text: it.name})];
      if (describe && it.desc) { body.push(el('span', {class: 'fp-muted fp-spb-choice-desc', text: it.desc})); }
      return el('label', {class: 'fp-check fp-spb-opt', for: id}, [input, el('span', {class: 'fp-spb-opt-text'}, body)]);
    })));
    return group;
  }
  function textInput(id, name, label, value, hint, max) {
    return M.field(id, label, el('input', {class: 'sig-input', id: id, name: name, type: 'text', value: value, maxlength: String(max), autocomplete: 'off', spellcheck: 'false'}), hint);
  }
  function areaInput(id, name, label, value, hint, rows, max) {
    return M.field(id, label, el('textarea', {class: 'sig-input fp-spb-area', id: id, name: name, rows: String(rows), maxlength: String(max), text: value, spellcheck: 'true'}), hint);
  }

  function siteCard() {
    var st = P.st;
    var f = st.fields;
    var published = st.state === 'published';
    var tplId = published && st.template ? st.template : (TEMPLATES[0] ? TEMPLATES[0].id : '');
    var accent = published && f.accent ? f.accent : (ACCENTS[0] ? ACCENTS[0].id : '');
    var form = el('form', {class: 'fp-form fp-spb-form', novalidate: ''}, [
      radios('template', t('spb_template'), TEMPLATES, tplId, true),
      radios('accent', t('spb_accent'), ACCENTS, accent, false),
      textInput('fp-spb-title', 'title', t('spb_title'), published ? f.title : '', t('spb_title_hint'), 80),
      textInput('fp-spb-tagline', 'tagline', t('spb_tagline'), published ? f.tagline : '', t('spb_tagline_hint'), 120),
      areaInput('fp-spb-about', 'about', t('spb_about'), published ? f.about : '', t('spb_about_hint'), 6, 2000),
      textInput('fp-spb-email', 'email', t('spb_email'), published ? f.email : '', t('spb_email_hint'), 254),
      textInput('fp-spb-phone', 'phone', t('spb_phone'), published ? f.phone : '', t('spb_phone_hint'), 30),
      areaInput('fp-spb-address', 'address', t('spb_address'), published ? f.address : '', t('spb_address_hint'), 3, 200),
      M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-actions fp-spb-acts'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t(published ? 'spb_update' : 'spb_publish')})]
        .concat(published ? [el('button', {class: 'sig-btn sig-btn--secondary fp-btn-danger-text', type: 'button', 'data-fp-act': 'remove', text: t('spb_remove')})] : []))]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      send(form, false);
    });
    var stateText = published ? t('spb_state_published', {template: tplName(st.template)}) : (st.state === 'other' ? t('spb_state_other', {names: names(st.others)}) :
      (st.others.length ? t('spb_state_empty_htm', {names: names(st.others)}) : t('spb_state_empty')));
    /* a front page that is not ours, and a page served before ours, are warnings the person must see: a banner, not the error line (hidden until an error) */
    var note = st.state === 'other' ? M.suspendedBanner(stateText) : el('p', {class: 'fp-muted', text: stateText});
    note.classList.add('fp-spb-note');
    note.setAttribute('data-fp-note', '');
    return M.card('fp-spb-h', P.site.domain, [
      note,
      st.warning ? M.suspendedBanner(st.warning) : null,
      el('p', {class: 'fp-spb-open'}, [el('a', {class: 'sig-link', href: 'http://' + P.site.domain + '/', target: '_blank', rel: 'noopener noreferrer', text: t('spb_open')})]),
      form], 'fp-spb');
  }

  function body(form, replace) {
    var f = function (n) { return form.querySelector('[name="' + n + '"]'); };
    var pick = function (n) { var c = form.querySelector('[name="' + n + '"]:checked'); return c ? c.value : ''; };
    return {template: pick('template'), accent: pick('accent'), title: f('title').value, tagline: f('tagline').value, about: f('about').value, email: f('email').value, phone: f('phone').value,
      address: f('address').value, replace: replace};
  }
  /* `yes` is the button of the question that was answered: Publish is gone from the row by then, so that button shows the wait */
  function send(form, replace, yes) {
    var go = yes || M.start(form);
    if (!go) { return; }
    if (yes) { UI.showError(form, ''); }
    var b = body(form, replace);
    if (!b.title.trim()) { M.fieldError(form, form.querySelector('[name="title"]'), t('spb_title_needed')); return; }
    var mine = P;
    var wasPublished = P.st.state === 'published';
    if (P.st.state === 'other' && !replace) {
      /* a page that is not the panel's: ask first, in place of the buttons */
      M.confirmIn(form.querySelector('.fp-spb-acts'), t('spb_replace_ask', {names: names(P.st.others)}), 'replace-yes', t('spb_replace_yes'));
      return;
    }
    UI.setBusy(go, true);
    FP.call('put', 'sitePubSite', b, {name: FP.account(), domain: P.site.domain}).then(function (r) {
      if (P !== mine) { return; }
      P.st = stateOf(r);
      P.say = t(wasPublished ? 'spb_updated' : 'spb_published');
      draw('#fp-spb-h');
    }, function (err) {
      if (P !== mine) { return; }
      UI.setBusy(go, false);
      var input = err && err.field ? UI.fieldNamed(form, err.field) : null;
      if (input && input.type !== 'radio') { M.fieldError(form, input, err.message); } else { M.failed(form, err); }
    });
  }
  function draw(focus) {
    P.card.textContent = '';
    P.card.appendChild(siteCard());
    if (P.say) { M.say(P.card, P.say); P.say = ''; }
    var target = focus ? P.card.querySelector(focus) : null;
    if (target) { target.focus(); }
  }
  function click(e) {
    var b = e.target && e.target.closest ? e.target.closest('.fp-spb [data-fp-act]') : null;
    if (!b || !P || !P.page.contains(b) || b.disabled) { return; }
    var a = b.getAttribute('data-fp-act');
    var mine = P;
    var form = b.closest('.fp-spb-form');
    if (a === 'remove') {
      M.confirmIn(b.closest('.fp-spb-acts'), t('spb_remove_ask'), 'remove-yes', t('spb_remove_yes'));
    } else if (a === 'confirm-no') {
      var keep = body(form, false);
      draw('');
      /* what was typed stays */
      Object.keys(keep).forEach(function (k) {
        var n = P.card.querySelector('[name="' + k + '"]');
        if (n && n.type !== 'radio' && typeof keep[k] === 'string') { n.value = keep[k]; }
      });
      var radiosBack = ['template', 'accent'];
      radiosBack.forEach(function (k) {
        var r = P.card.querySelector('[name="' + k + '"][value="' + keep[k] + '"]');
        if (r) { r.checked = true; }
      });
      var first = P.card.querySelector('.fp-submit');
      if (first) { first.focus(); }
    } else if (a === 'replace-yes') {
      send(form, true, b);
    } else if (a === 'remove-yes') {
      UI.setBusy(b, true);
      FP.call('del', 'sitePubSite', undefined, {name: FP.account(), domain: P.site.domain}).then(function (r) {
        if (P !== mine) { return; }
        P.st = stateOf(r);
        P.say = t('spb_removed');
        draw('#fp-spb-h');
      }, function (err) { if (P === mine) { UI.setBusy(b, false); UI.showError(form, err.message); } });
    }
  }
  document.addEventListener('click', click);

  function load(domain) {
    var mine = P;
    var site = P.sites.filter(function (s) { return s.domain === domain; })[0];
    P.site = site;
    P.card.textContent = '';
    P.card.appendChild(el('p', {class: 'fp-muted', text: t('spb_loading_site')}));
    /* an answer for a site that is no longer the one chosen is dropped, so it can't fill in the form of another */
    FP.call('get', 'sitePubSite', undefined, {name: FP.account(), domain: domain}).then(function (r) {
      if (P !== mine || P.site !== site) { return; }
      P.st = stateOf(r);
      draw('');
    }, function (err) {
      if (P !== mine || P.site !== site) { return; }
      P.card.textContent = '';
      P.card.appendChild(FP.empty(domain, err && err.message ? err.message : t('api_failed')));
    });
  }

  FP.view('tool:site_publisher', function () {
    P = null;
    var tool = FP.tools.site_publisher;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('site_publisher_desc'), cls: 'fp-mail fp-spb-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    if (!page) { return; }
    var card = el('div', {class: 'fp-spb-card'});
    P = {page: page, card: card, sites: [], site: null, st: null, say: ''};
    var mine = P;
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'sitePub', undefined, FP.account()).then(function (r) {
      if (P !== mine) { return; }
      P.sites = listOf(r);
      page.textContent = '';
      if (!P.sites.length) { page.appendChild(FP.empty(tool.label, t('spb_no_sites'))); return; }
      if (P.sites.length > 1) {
        var sel = el('select', {class: 'sig-select', id: 'fp-spb-site', name: 'site'}, P.sites.map(function (s) { return el('option', {value: s.domain, text: s.domain}); }));
        sel.addEventListener('change', function () { load(sel.value); });
        page.appendChild(el('div', {class: 'fp-spb-pick'}, [M.field('fp-spb-site', t('spb_site'), sel, '')]));
      }
      page.appendChild(card);
      load(P.sites[0].domain);
    }, function (err) {
      if (P !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err && err.status === 503 ? t('spb_unavailable') : (err && err.message ? err.message : t('api_failed'))));
    });
  });
})();

/* freePanel automatic certificates (#/tool/ssl_auto), the admin panel's page for free certificates (docs/api.md, "AutoSSL"):
   whether the server orders and renews a certificate for every site, the certificate authority's terms the admin agrees to
   before turning it on, where the authority sends its notices, a run over every site started by hand, and how the latest
   run ended. A run goes on in the background, so while one does the page asks the server every few seconds. The terms are
   read from the authority only when the admin ticks the box (or asks to check them again): reading them is the one time
   this page makes the server contact the authority. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;
  var BK = FP.bk;

  var POLL_MS = 3000;
  var URL_RE = /^https?:\/\/[^\s<>"]{1,2040}$/i;
  var EMAIL_RE = /^[^\s@<>(),;:"\\[\]]{1,64}@[^\s@<>(),;:"\\[\]]{1,190}$/;
  var EMAIL_MAX = 254;

  var S = null;

  var str = BK.str;
  function count(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.floor(v) : 0; }
  function link(v) { v = str(v); return URL_RE.test(v) ? v : ''; }

  /* ---------- what the server says, kept to the shapes the page draws ---------- */
  function cleanStatus(r) {
    r = r && typeof r === 'object' ? r : {};
    return {enabled: r.enabled === true, terms: link(r.terms_url), by: str(r.accepted_by).slice(0, 64), at: str(r.accepted_at),
      email: str(r.email).slice(0, EMAIL_MAX), wildcard: r.wildcard !== false, available: r.available !== false, running: r.running === true, last: str(r.last_run),
      issued: count(r.issued), failed: count(r.failed), deferred: count(r.deferred), note: str(r.note).slice(0, 400), paused: str(r.paused_until)};
  }
  function when(iso) { return BK.when(iso) || iso; }

  /* ---------- the run ---------- */
  /* a run is going from the moment one is asked for, though the server may take a moment to show it */
  function going() { return S.st.running || (S.watching && !S.seen); }
  function stateText(st) {
    if (!st.available) { return t('as_state_unavailable'); }
    if (!st.enabled) { return t('as_state_off'); }
    return going() ? t('as_running') : t('as_state_on');
  }
  function counts(st) {
    var cell = function (cls, label, n) {
      return el('div', {class: 'fp-as-count' + (cls ? ' ' + cls : '')}, [el('dt', {text: label}), el('dd', {text: String(n)})]);
    };
    return el('dl', {class: 'fp-as-counts', 'data-fp-as-counts': ''}, [cell('', t('as_issued'), st.issued), cell(st.failed ? 'fp-as-bad' : '', t('as_failed'), st.failed),
      cell('', t('as_deferred'), st.deferred)]);
  }
  function runCard() {
    var st = S.st;
    var pill = !st.available ? el('span', {class: 'sig-pill', text: t('as_pill_unavailable')}) :
      el('span', {class: 'sig-pill' + (st.enabled ? ' sig-pill--ok' : ''), text: t(st.enabled ? 'as_pill_on' : 'as_pill_off')});
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-as-state', 'data-fp-as-state': ''}, [pill, el('span', {text: stateText(st)})])];
    if (st.note) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-as-note': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: st.note})]));
    }
    if (st.paused) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-as-paused': ''}, [UI.icon(FP.ui, 'ui_warning'),
        el('span', {text: t('as_paused', {when: when(st.paused)})})]));
    }
    if (st.last) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-as-last': '', text: t('as_last', {when: when(st.last)})}));
      parts.push(counts(st));
      if (st.deferred) { parts.push(el('p', {class: 'fp-muted', 'data-fp-as-deferred': '', text: t('as_deferred_hint')})); }
    } else {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-as-last': '', text: t('as_last_none')}));
    }
    if (st.enabled && st.available) {
      parts.push(el('div', {class: 'fp-actions'}, [going() ?
        el('p', {class: 'fp-muted', 'data-fp-as-going': '', text: t('as_going')}) :
        el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'run', text: t('as_run')})]));
    }
    return M.card('fp-as-run-h', t('as_run_title'), parts, 'fp-as-run');
  }
  function drawRun() {
    var old = S.page.querySelector('.fp-as-run');
    var fresh = runCard();
    var active = document.activeElement;
    var act = old && active && old.contains(active) ? active.getAttribute('data-fp-act') : null;
    if (old) { old.replaceWith(fresh); } else { S.page.insertBefore(fresh, S.page.firstChild); }
    if (act) {
      var again = fresh.querySelector('[data-fp-act="' + act + '"]') || fresh.querySelector('#fp-as-run-h');
      if (again) { again.focus(); }
    }
  }

  /* asks how the run is every few seconds while one goes on (or is about to start); when it ends, says how */
  function poll() {
    window.clearTimeout(S.timer);
    var mine = S;
    S.timer = window.setTimeout(function () {
      if (S !== mine || !document.body.contains(mine.page)) { return; }
      FP.call('get', 'webAutossl').then(function (r) {
        if (S !== mine) { return; }
        var fresh = cleanStatus(r);
        mine.st = fresh;
        drawRun();
        if (fresh.running) { mine.seen = true; poll(); return; }
        /* a run asked for has not shown yet: look a few times more before giving up on it */
        if (mine.watching && !mine.seen && fresh.last === mine.from && mine.tries++ < 3) { poll(); return; }
        var finished = mine.seen || fresh.last !== mine.from;
        mine.watching = false;
        drawRun();
        if (finished) { M.say(mine.page.querySelector('.fp-as-run'), t('as_ended', {issued: fresh.issued, failed: fresh.failed, deferred: fresh.deferred})); }
      }, function () { if (S === mine) { poll(); } });
    }, POLL_MS);
  }
  /* a run was asked for (or is going): shows it going and looks until it has ended */
  function watch() {
    S.watching = true;
    S.seen = false;
    S.from = S.st.last;
    S.tries = 0;
    drawRun();
    poll();
  }

  /* ---------- the terms ---------- */
  function termsLink(url) {
    return el('div', {class: 'fp-as-terms-link'}, [el('span', {class: 'sig-label', text: t('as_terms_label')}), el('a', {href: url, target: '_blank', rel: 'noopener noreferrer',
      'data-fp-as-link': '', text: url}), el('span', {class: 'sig-hint', text: t('as_terms_new_tab')})]);
  }
  function termsParts() {
    var tm = S.terms;
    if (tm.state === 'loading') { return [el('p', {class: 'fp-muted', role: 'status', 'data-fp-as-reading': '', text: t('as_terms_loading')})]; }
    if (tm.state === 'failed') {
      return [el('p', {class: 'fp-bk-bad', role: 'alert', 'data-fp-as-terms-error': '', text: t('as_terms_failed', {why: tm.error})}),
        el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'terms', text: t('as_terms_retry')})])];
    }
    if (tm.state === 'ready') {
      var out = [];
      if (tm.note) { out.push(el('p', {class: 'fp-muted', 'data-fp-as-terms-note': '', text: tm.note})); }
      out.push(termsLink(tm.url));
      out.push(el('label', {class: 'fp-check', for: 'fp-as-agree'}, [el('input', {type: 'checkbox', id: 'fp-as-agree', name: 'agree', checked: tm.agreed}),
        el('span', {text: t('as_terms_agree')})]));
      return out;
    }
    var c = S.st;
    if (c.enabled && c.terms) {
      var who = c.by || t('as_someone');
      var out2 = [termsLink(c.terms), el('p', {class: 'fp-muted', 'data-fp-as-agreed': '', text: c.at ? t('as_terms_agreed', {who: who, when: when(c.at)}) : t('as_terms_agreed_nodate', {who: who})})];
      if (tm.note) { out2.push(el('p', {class: 'fp-muted', role: 'status', 'data-fp-as-terms-note': '', text: tm.note})); }
      out2.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'terms', text: t('as_terms_check')})]));
      return out2;
    }
    return [];
  }
  function drawTerms(form) {
    var box = form.querySelector('[data-fp-terms]');
    var on = form.querySelector('[name="enabled"]').checked;
    var active = document.activeElement;
    var inside = box.contains(active);
    var keep = inside ? (active.getAttribute('data-fp-act') || active.id || (active === box ? S.refocus : '')) : '';
    box.textContent = '';
    box.hidden = !on;
    if (on) { termsParts().forEach(function (n) { box.appendChild(n); }); }
    if (inside) {
      var again = keep ? box.querySelector('[data-fp-act="' + keep + '"]') || box.querySelector('#' + keep) : null;
      (again || box).focus({preventScroll: true});
    }
  }
  /* reads the authority's current terms; `note` says why when the admin asked (or the server refused the terms they had agreed to) */
  function loadTerms(form, note) {
    var mine = S;
    var active = document.activeElement;
    var box = form.querySelector('[data-fp-terms]');
    /* the button pressed to read them gets the focus back when they are shown */
    if (box.contains(active) && active !== box) { S.refocus = active.getAttribute('data-fp-act') || active.id; }
    S.terms = {state: 'loading', url: '', agreed: false, note: '', error: ''};
    drawTerms(form);
    FP.call('get', 'webAutosslTerms').then(function (r) {
      if (S !== mine) { return; }
      var url = link(r && r.terms_url);
      if (!url) { mine.terms = {state: 'failed', url: '', agreed: false, note: '', error: t('api_failed')}; drawTerms(form); return; }
      if (mine.st.enabled && url === mine.st.terms) {
        mine.terms = {state: 'idle', url: url, agreed: false, note: t('as_terms_same'), error: ''};
      } else {
        mine.terms = {state: 'ready', url: url, agreed: false, note: note || '', error: ''};
      }
      drawTerms(form);
      UI.announce(mine.terms.note || t('as_terms_ready'));
    }, function (err) {
      if (S !== mine) { return; }
      mine.terms = {state: 'failed', url: '', agreed: false, note: '', error: err.message};
      drawTerms(form);
    });
  }

  /* ---------- the settings ---------- */
  function formCard() {
    var st = S.st;
    var form = el('form', {class: 'fp-form fp-mail-form fp-as-form', novalidate: '', 'data-fp-form': 'autossl'}, [M.errorLine(), M.statusLine()]);
    if (!st.available) {
      form.appendChild(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-as-unavailable': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('as_unavailable')})]));
    }
    var box = el('input', {type: 'checkbox', id: 'fp-as-enabled', name: 'enabled', checked: st.enabled, 'aria-describedby': 'fp-as-enabled-hint'});
    if (!st.available && !st.enabled) { box.disabled = true; }
    form.appendChild(el('label', {class: 'fp-check', for: 'fp-as-enabled'}, [box, el('span', {text: t('as_enabled')})]));
    form.appendChild(el('span', {class: 'sig-hint fp-as-hint', id: 'fp-as-enabled-hint', text: t('as_enabled_hint')}));
    form.appendChild(el('div', {class: 'fp-as-terms', 'data-fp-terms': '', tabindex: '-1'}));
    form.appendChild(el('label', {class: 'fp-check', for: 'fp-as-wildcard'}, [el('input', {type: 'checkbox', id: 'fp-as-wildcard', name: 'wildcard', checked: st.wildcard,
      'aria-describedby': 'fp-as-wildcard-hint'}), el('span', {text: t('as_wildcard')})]));
    form.appendChild(el('span', {class: 'sig-hint fp-as-hint', id: 'fp-as-wildcard-hint', text: t('as_wildcard_hint')}));
    form.appendChild(M.field('fp-as-email', t('as_email'), el('input', {class: 'sig-input', id: 'fp-as-email', name: 'email', type: 'email', inputmode: 'email',
      autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', maxlength: String(EMAIL_MAX), value: st.email}), t('as_email_hint')));
    form.appendChild(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('as_save')})]));
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      submit(form);
    });
    form.addEventListener('change', function (e) {
      var target = e.target;
      if (target.name === 'agree') { S.terms.agreed = target.checked; return; }
      if (target.name !== 'enabled') { return; }
      S.terms.agreed = false;
      UI.showError(form, '');
      /* turning them on needs the terms read and agreed to, unless they are on and agreed to already */
      if (target.checked && !(S.st.enabled && S.st.terms) && (S.terms.state === 'idle' || S.terms.state === 'failed')) {
        loadTerms(form, '');
        return;
      }
      drawTerms(form);
    });
    return {card: M.card('fp-as-form-h', t('as_form_title'), [el('p', {class: 'fp-muted', text: t('as_form_desc')}), form], 'fp-as-settings'), form: form};
  }
  /* the form's values as the server takes them; null, with the field marked, when one is plainly wrong */
  function read(form) {
    var bad = function (field, message) { M.fieldError(form, UI.fieldNamed(form, field), message); return null; };
    var email = form.querySelector('[name="email"]').value.trim();
    if (email && (email.length > EMAIL_MAX || !EMAIL_RE.test(email))) { return bad('email', t('as_email_bad')); }
    var body = {enabled: form.querySelector('[name="enabled"]').checked};
    if (email) { body.email = email; }
    /* left out, the server keeps the setting, so it is sent only when the admin changed it */
    var wild = form.querySelector('[name="wildcard"]').checked;
    if (wild !== S.st.wildcard) { body.wildcard = wild; }
    if (!body.enabled) { return body; }
    var tm = S.terms;
    if (tm.state === 'loading') { return bad('enabled', t('as_terms_wait')); }
    if (tm.state === 'failed') { return bad('enabled', t('as_terms_failed', {why: tm.error})); }
    if (tm.state === 'ready') {
      if (!tm.agreed) { return bad('agree', t('as_terms_agree_needed')); }
      body.terms_url = tm.url;
    } else if (S.st.enabled && S.st.terms) {
      body.terms_url = S.st.terms;
    } else {
      return bad('enabled', t('as_terms_wait'));
    }
    return body;
  }
  function submit(form) {
    var b = M.start(form);
    if (!b) { return; }
    var body = read(form);
    if (!body) { return; }
    var mine = S;
    var agreed = S.terms.state !== 'ready';
    UI.setBusy(b, true);
    FP.call('put', 'webAutossl', body).then(function (r) {
      UI.setBusy(b, false);
      if (S !== mine) { return; }
      mine.st = cleanStatus(r);
      mine.terms = {state: 'idle', url: '', agreed: false, note: '', error: ''};
      form.querySelector('[name="email"]').value = mine.st.email;
      form.querySelector('[name="enabled"]').checked = mine.st.enabled;
      form.querySelector('[name="wildcard"]').checked = mine.st.wildcard;
      drawTerms(form);
      if (mine.st.enabled || mine.st.running) { watch(); } else { drawRun(); }
      M.say(form, t(mine.st.enabled ? 'as_saved_on' : 'as_saved_off'));
    }, function (err) {
      UI.setBusy(b, false);
      if (S !== mine) { return; }
      if (err.status === 409 && body.enabled && agreed && /terms/i.test(err.message)) {
        M.fieldError(form, null, t('as_terms_changed'));
        loadTerms(form, t('as_terms_new'));
        return;
      }
      M.failed(form, err);
    });
  }

  function onClick(e) {
    var target = e.target && e.target.closest ? e.target : null;
    var b = target && S && S.page && S.page.contains(target) ? target.closest('[data-fp-act]') : null;
    if (!b) { return; }
    var act = b.getAttribute('data-fp-act');
    var mine = S;
    if (act === 'terms') {
      var form = S.page.querySelector('.fp-as-form');
      UI.showError(form, '');
      M.say(form, '');
      loadTerms(form, t('as_terms_new'));
      return;
    }
    if (act !== 'run') { return; }
    var card = S.page.querySelector('.fp-as-run');
    UI.showError(card, '');
    M.say(card, '');
    UI.setBusy(b, true);
    FP.call('post', 'webAutosslRun').then(function (r) {
      if (S !== mine) { return; }
      mine.st = cleanStatus(r);
      watch();
      mine.page.querySelector('#fp-as-run-h').focus();
      M.say(mine.page.querySelector('.fp-as-run'), t('as_run_started'));
    }, function (err) {
      if (S !== mine) { return; }
      UI.setBusy(b, false);
      UI.showError(card, err.message);
      b.focus();
    });
  }
  document.addEventListener('click', onClick);

  FP.view('tool:ssl_auto', function () {
    var tool = FP.tools.ssl_auto;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('as_desc'), cls: 'fp-mail fp-as',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    if (S) { window.clearTimeout(S.timer); }
    S = {page: body, st: cleanStatus(null), timer: 0, watching: false, seen: false, from: '', tries: 0, refocus: '', terms: {state: 'idle', url: '', agreed: false, note: '', error: ''}};
    var mine = S;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'webAutossl').then(function (r) {
      if (S !== mine) { return; }
      mine.st = cleanStatus(r);
      body.textContent = '';
      body.appendChild(runCard());
      var f = formCard();
      body.appendChild(f.card);
      drawTerms(f.form);
      if (mine.st.running) { mine.watching = true; mine.seen = true; mine.from = mine.st.last; mine.tries = 0; poll(); }
    }, function (err) {
      if (S !== mine) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

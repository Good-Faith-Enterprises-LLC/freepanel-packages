/* freePanel server notifications (docs/api.md, "Server notifications"): the admin panel's Notification rules page
   (#/tool/server_notifications) and Failed-service alerts page (#/tool/service_alerts). The server looks at the disk that holds the accounts' homes and at the load every minute and writes
   to the server's contacts when a limit has been passed twice in a row, again after the repeat time while it lasts, and once when it is
   back under. One call reads the rules, what the server sees now, the limits passed now and the latest notices; one call replaces all
   the rules (every field is required, so a save sends the failed-service rule as the server last held it). Admin only: the server
   refuses these calls to anyone else. Everything the server sends is shown as text. The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var KINDS = ['raised', 'reminder', 'cleared', 'restarted'];
  var RULES = ['disk', 'load', 'services'];

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function num(v) { return typeof v === 'number' && isFinite(v) ? v : null; }
  function whole(v, lo, hi, d) { return typeof v === 'number' && isFinite(v) && Math.floor(v) === v && v >= lo && v <= hi ? v : d; }
  function when(v) {
    if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}T/.test(v)) { return ''; }
    var d = new Date(v);
    return isNaN(d.getTime()) ? '' : d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'});
  }
  function rulesOf(r) {
    r = r && typeof r === 'object' ? r : {};
    var d = r.disk && typeof r.disk === 'object' ? r.disk : {};
    var l = r.load && typeof r.load === 'object' ? r.load : {};
    var s = r.services && typeof r.services === 'object' ? r.services : {};
    var per = num(l.per_cpu);
    return {disk: {enabled: d.enabled === true, percent: whole(d.percent, 1, 99, 90)},
      load: {enabled: l.enabled === true, per_cpu: per !== null && per >= 0.05 && per <= 100 ? per : 2},
      services: {enabled: s.enabled === true, auto_restart: s.auto_restart === true}, repeat_hours: whole(r.repeat_hours, 0, 168, 24)};
  }
  function clean(v) {
    v = v && typeof v === 'object' ? v : {};
    var c = v.current && typeof v.current === 'object' ? v.current : {};
    var failed = Array.isArray(c.failed_services) ? c.failed_services.filter(function (u) { return typeof u === 'string' && u; }).map(function (u) { return u.slice(0, 120); }).slice(0, 200) : null;
    return {rules: rulesOf(v.rules), defaults: rulesOf(v.defaults), contacts: whole(v.contacts, 0, 1000, 0), warning: str(v.warning, 400),
      current: {path: str(c.disk_path, 200), disk: num(c.disk_used_percent), load5: num(c.load5), cpus: whole(c.cpus, 0, 100000, 0), perCpu: num(c.load_per_cpu), failed: failed},
      alerts: (Array.isArray(v.alerts) ? v.alerts : []).filter(function (a) { return a && typeof a === 'object' && RULES.indexOf(a.rule) >= 0; }).slice(0, 200).map(function (a) {
        return {rule: a.rule, unit: str(a.unit, 120), since: when(a.since), told: a.told === true, detail: str(a.detail, 400)};
      }),
      recent: (Array.isArray(v.recent) ? v.recent : []).filter(function (e) { return e && typeof e === 'object' && RULES.indexOf(e.rule) >= 0 && KINDS.indexOf(e.kind) >= 0; }).slice(0, 30).map(function (e) {
        return {at: when(e.at), rule: e.rule, unit: str(e.unit, 120), kind: e.kind, sent: whole(e.sent, 0, 1000, 0), failed: whole(e.failed, 0, 1000, 0), note: str(e.note, 300)};
      })};
  }

  var N = {page: null, S: null, busy: false, say: '', sayIn: '', refocus: '', render: null};

  /* the body of a save: every rule as the server holds it, the ones this page edits replaced by what is in the form */
  function body() {
    var r = N.S.rules;
    return {disk: {enabled: r.disk.enabled, percent: r.disk.percent}, load: {enabled: r.load.enabled, per_cpu: r.load.per_cpu},
      services: {enabled: r.services.enabled, auto_restart: r.services.auto_restart}, repeat_hours: r.repeat_hours};
  }
  function withRules(mine) {
    return Object.assign(body(), mine);
  }
  function setState(r) { N.S = clean(r); }

  /* ---- pieces both pages use ---- */
  function warningNote() {
    var S = N.S;
    if (!S.warning) { return null; }
    var parts = [UI.icon(FP.ui, 'ui_warning'), el('span', {text: S.warning + ' '})];
    if (FP.tools.server_contacts) { parts[1].appendChild(el('a', {href: '#/tool/server_contacts', text: t('ntf_to_contacts')})); }
    return el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-ntf-warning': ''}, parts);
  }
  function contactsLine() {
    var n = N.S.contacts;
    var text = n === 0 ? t('ntf_contacts_0') : t(n === 1 ? 'ntf_contacts_1' : 'ntf_contacts', {n: n});
    var line = el('p', {class: 'fp-muted', 'data-fp-ntf-contacts': ''}, [text + ' ']);
    if (FP.tools.server_contacts) { line.appendChild(el('a', {href: '#/tool/server_contacts', text: t('ntf_manage_contacts')})); }
    return line;
  }
  function pct(v) { return String(Math.round(v * 10) / 10) + '%'; }
  function fixed(v) { return (Math.round(v * 100) / 100).toString(); }
  function alertsCard(rules, id, title, none) {
    var list = N.S.alerts.filter(function (a) { return rules.indexOf(a.rule) >= 0; });
    var parts;
    if (!list.length) {
      parts = [el('p', {class: 'fp-muted', 'data-fp-alerts-none': '', text: none})];
    } else {
      parts = [el('ul', {class: 'fp-ntf-list', 'data-fp-alerts': ''}, list.map(function (a) {
        return el('li', {class: 'fp-ntf-item'}, [el('div', {class: 'fp-ntf-head'}, [el('span', {class: 'fp-ntf-what', text: a.unit || t('ntf_rule_' + a.rule)}),
          el('span', {class: 'sig-pill ' + (a.told ? 'sig-pill--ok' : 'sig-pill--warn'), text: a.told ? t('ntf_told') : t('ntf_not_told')}),
          a.since ? el('span', {class: 'fp-muted fp-ntf-when', text: t('ntf_since', {when: a.since})}) : null]),
          a.detail ? el('p', {class: 'fp-ntf-detail', text: a.detail}) : null]);
      }))];
    }
    return M.card(id, title, parts, 'fp-ntf-alerts');
  }
  function recentCard(rules, id, title, none) {
    var list = N.S.recent.filter(function (e) { return rules.indexOf(e.rule) >= 0; });
    var parts;
    if (!list.length) {
      parts = [el('p', {class: 'fp-muted', 'data-fp-recent-none': '', text: none})];
    } else {
      parts = [el('ul', {class: 'fp-ntf-list', 'data-fp-recent': ''}, list.map(function (e) {
        var sent = e.sent + e.failed === 0 ? t('ntf_sent_none') : t('ntf_sent', {n: e.sent, m: e.sent + e.failed});
        return el('li', {class: 'fp-ntf-item'}, [el('div', {class: 'fp-ntf-head'}, [el('span', {class: 'fp-ntf-what', text: (e.unit || t('ntf_rule_' + e.rule)) + ': ' + t('ntf_kind_' + e.kind)}),
          e.at ? el('span', {class: 'fp-muted fp-ntf-when', text: e.at}) : null]),
          el('p', {class: 'fp-ntf-detail', text: sent + (e.note ? ' ' + e.note : '')})]);
      }))];
    }
    return M.card(id, title, parts, 'fp-ntf-recent');
  }
  /* "Look now": one look as the background one does; the page shows what it found */
  function lookButton(card) {
    var b = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'ntf-look', text: t('ntf_look')});
    b.addEventListener('click', function () {
      if (N.busy) { return; }
      N.busy = true;
      UI.setBusy(b, true);
      var mine = N.page;
      UI.showError(card, '');
      M.say(card, '');
      FP.call('post', 'serverNotificationsCheck', {}).then(function (r) {
        N.busy = false;
        if (N.page !== mine) { return; }
        setState(r);
        N.say = t('ntf_looked');
        N.sayIn = '.fp-ntf-now';
        N.refocus = '[data-fp-act="ntf-look"]';
        N.render();
      }, function (err) {
        N.busy = false;
        if (N.page !== mine) { return; }
        UI.setBusy(b, false);
        UI.showError(card, err.message);
      });
    });
    return b;
  }

  /* ---- the rules page ---- */
  function seeNow() {
    var c = N.S.current;
    var disk = c.disk === null ? t('ntf_unreadable') : t('ntf_disk_now', {used: pct(c.disk)}) + (c.path ? ' ' + t('ntf_disk_path', {path: c.path}) : '');
    var load = c.perCpu === null ? t('ntf_unreadable') : t('ntf_load_now', {per: fixed(c.perCpu)}) + (c.load5 !== null && c.cpus ? ' ' + t('ntf_load_detail', {load: fixed(c.load5), n: c.cpus}) : '');
    var facts = el('dl', {class: 'fp-ntf-facts'}, [el('div', {}, [el('dt', {text: t('ntf_disk')}), el('dd', {'data-fp-now': 'disk', text: disk})]),
      el('div', {}, [el('dt', {text: t('ntf_load')}), el('dd', {'data-fp-now': 'load', text: load})])]);
    var card = M.card('fp-ntf-now-h', t('ntf_now_title'), [M.errorLine(), M.statusLine(), facts], 'fp-ntf-now');
    card.querySelector('.sig-card-body').appendChild(el('div', {class: 'fp-actions'}, [lookButton(card)]));
    return card;
  }
  function numberField(id, name, label, hint, value, attrs) {
    var input = el('input', Object.assign({class: 'sig-input fp-ntf-num', id: id, name: name, type: 'text', inputmode: 'decimal', autocomplete: 'off', value: String(value)}, attrs || {}));
    return M.field(id, label, input, hint);
  }
  function rulesForm() {
    var r = N.S.rules;
    var diskOn = el('input', {type: 'checkbox', id: 'fp-ntf-disk-on', name: 'disk.enabled', checked: r.disk.enabled ? true : null});
    var loadOn = el('input', {type: 'checkbox', id: 'fp-ntf-load-on', name: 'load.enabled', checked: r.load.enabled ? true : null});
    var form = el('form', {class: 'fp-form fp-ntf-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-ntf-rule'}, [el('label', {class: 'fp-check', for: 'fp-ntf-disk-on'}, [diskOn, el('span', {text: t('ntf_disk_on')})]),
        numberField('fp-ntf-disk-percent', 'disk.percent', t('ntf_disk_percent'), t('ntf_disk_percent_hint'), r.disk.percent, {maxlength: '2'})]),
      el('div', {class: 'fp-ntf-rule'}, [el('label', {class: 'fp-check', for: 'fp-ntf-load-on'}, [loadOn, el('span', {text: t('ntf_load_on')})]),
        numberField('fp-ntf-load-per', 'load.per_cpu', t('ntf_load_per'), t('ntf_load_per_hint'), r.load.per_cpu, {maxlength: '6'})]),
      numberField('fp-ntf-repeat', 'repeat_hours', t('ntf_repeat'), t('ntf_repeat_hint'), r.repeat_hours, {maxlength: '3'}),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('ntf_save')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'ntf-suggest', text: t('ntf_suggest')})])]);
    form.querySelector('[data-fp-act="ntf-suggest"]').addEventListener('click', function () {
      var d = N.S.defaults;
      form.querySelector('#fp-ntf-disk-percent').value = String(d.disk.percent);
      form.querySelector('#fp-ntf-load-per').value = String(d.load.per_cpu);
      form.querySelector('#fp-ntf-repeat').value = String(d.repeat_hours);
      M.start(form);
      M.say(form, t('ntf_suggested'));
    });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || N.busy) { return; }
      var field = function (n) { return form.querySelector('[name="' + n + '"]'); };
      var pctV = field('disk.percent').value.trim();
      if (!/^[0-9]{1,2}$/.test(pctV) || Number(pctV) < 1 || Number(pctV) > 99) { M.fieldError(form, field('disk.percent'), t('ntf_bad_percent')); return; }
      var perV = field('load.per_cpu').value.trim();
      if (!/^[0-9]{1,3}(\.[0-9]{1,2})?$/.test(perV) || Number(perV) < 0.05 || Number(perV) > 100) { M.fieldError(form, field('load.per_cpu'), t('ntf_bad_load')); return; }
      var repV = field('repeat_hours').value.trim();
      if (!/^[0-9]{1,3}$/.test(repV) || Number(repV) > 168) { M.fieldError(form, field('repeat_hours'), t('ntf_bad_repeat')); return; }
      N.busy = true;
      UI.setBusy(b, true);
      var mine = N.page;
      FP.call('put', 'serverNotifications', withRules({disk: {enabled: diskOn.checked, percent: Number(pctV)}, load: {enabled: loadOn.checked, per_cpu: Number(perV)},
        repeat_hours: Number(repV)})).then(function (r) {
        N.busy = false;
        if (N.page !== mine) { return; }
        setState(r);
        N.say = t('ntf_saved');
        N.sayIn = '.fp-ntf-rules';
        N.refocus = '#fp-ntf-disk-on';
        N.render();
      }, function (err) {
        N.busy = false;
        if (N.page !== mine) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return form;
  }
  function rulesPage() {
    var wn = warningNote();
    var nodes = [seeNow()];
    if (wn) { nodes.push(wn); }
    nodes.push(M.card('fp-ntf-rules-h', t('ntf_rules_title'), [el('p', {class: 'fp-muted', text: t('ntf_rules_what')}), contactsLine(), rulesForm(),
      el('p', {class: 'fp-muted', text: t('ntf_how')})], 'fp-ntf-rules'));
    nodes.push(alertsCard(['disk', 'load'], 'fp-ntf-alerts-h', t('ntf_alerts_title'), t('ntf_alerts_none')));
    nodes.push(recentCard(['disk', 'load'], 'fp-ntf-recent-h', t('ntf_recent_title'), t('ntf_recent_none')));
    return nodes;
  }

  /* ---- the failed-service alerts page ---- */
  function failedNow() {
    var f = N.S.current.failed;
    var parts = [M.errorLine(), M.statusLine()];
    if (f === null) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-failed-unreadable': '', text: t('sva_unreadable')}));
    } else if (!f.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-failed-none': '', text: t('sva_none_failed')}));
    } else {
      parts.push(el('ul', {class: 'fp-ntf-chips', 'data-fp-failed': '', 'aria-label': t('sva_failed_list')}, f.map(function (u) {
        return el('li', {}, [el('span', {class: 'sig-pill sig-pill--danger sig-mono', text: u})]);
      })));
    }
    parts.push(el('p', {class: 'fp-muted', text: t('sva_failed_what')}));
    var card = M.card('fp-sva-now-h', t('sva_now_title'), parts, 'fp-ntf-now');
    card.querySelector('.sig-card-body').appendChild(el('div', {class: 'fp-actions'}, [lookButton(card)]));
    return card;
  }
  function serviceForm() {
    var r = N.S.rules.services;
    var on = el('input', {type: 'checkbox', id: 'fp-sva-on', name: 'services.enabled', checked: r.enabled ? true : null});
    var auto = el('input', {type: 'checkbox', id: 'fp-sva-auto', name: 'services.auto_restart', checked: r.auto_restart ? true : null, 'aria-describedby': 'fp-sva-auto-hint',
      disabled: r.enabled ? null : true});
    var form = el('form', {class: 'fp-form fp-ntf-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'sig-field fp-ntf-rule'}, [el('label', {class: 'fp-check', for: 'fp-sva-on'}, [on, el('span', {text: t('sva_on')})]),
        el('span', {class: 'sig-hint', text: t('sva_on_hint')})]),
      el('div', {class: 'sig-field fp-ntf-rule'}, [el('label', {class: 'fp-check', for: 'fp-sva-auto'}, [auto, el('span', {text: t('sva_auto')})]),
        el('span', {class: 'sig-hint', id: 'fp-sva-auto-hint', text: t('sva_auto_hint')})]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('ntf_save')})])]);
    on.addEventListener('change', function () { auto.disabled = !on.checked; });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || N.busy) { return; }
      N.busy = true;
      UI.setBusy(b, true);
      var mine = N.page;
      FP.call('put', 'serverNotifications', withRules({services: {enabled: on.checked, auto_restart: auto.checked}})).then(function (r2) {
        N.busy = false;
        if (N.page !== mine) { return; }
        setState(r2);
        N.say = t('sva_saved');
        N.sayIn = '.fp-ntf-rules';
        N.refocus = '#fp-sva-on';
        N.render();
      }, function (err) {
        N.busy = false;
        if (N.page !== mine) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return form;
  }
  function servicesPage() {
    var wn = warningNote();
    var nodes = [failedNow()];
    if (wn) { nodes.push(wn); }
    nodes.push(M.card('fp-sva-rules-h', t('sva_rules_title'), [el('p', {class: 'fp-muted', text: t('sva_rules_what')}), contactsLine(), serviceForm(),
      el('p', {class: 'fp-muted', text: t('sva_repeat', {n: N.S.rules.repeat_hours})}), el('p', {class: 'fp-muted', text: t('sva_how')})], 'fp-ntf-rules'));
    nodes.push(alertsCard(['services'], 'fp-sva-alerts-h', t('sva_alerts_title'), t('sva_alerts_none')));
    nodes.push(recentCard(['services'], 'fp-sva-recent-h', t('sva_recent_title'), t('sva_recent_none')));
    return nodes;
  }

  /* a page of this file: reads the state, draws it with `make`, and draws it again after a save */
  function define(toolId, desc, cls, make) {
    FP.view('tool:' + toolId, function () {
      var tool = FP.tools[toolId];
      if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
      var g = FP.group(tool.group);
      N.S = null;
      N.busy = false;
      N.say = '';
      N.sayIn = '';
      N.refocus = '';
      var page = FP.frame({title: tool.label, desc: t(desc), cls: 'fp-mail fp-srv fp-ntf-page ' + cls,
        crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
      N.page = page;
      N.render = function () {
        page.textContent = '';
        make().forEach(function (n) { page.appendChild(n); });
        if (N.say) {
          var s = page.querySelector(N.sayIn + ' [data-fp-status]');
          if (s) { s.textContent = N.say; }
        }
        var f = N.refocus && page.querySelector(N.refocus);
        if (f) { f.focus(); }
        N.say = '';
        N.sayIn = '';
        N.refocus = '';
      };
      page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
      FP.call('get', 'serverNotifications').then(function (r) {
        if (N.page !== page) { return; }
        setState(r);
        N.render();
      }, function (err) {
        if (N.page !== page) { return; }
        page.textContent = '';
        page.appendChild(FP.empty(tool.label, err.message));
      });
    });
  }
  define('server_notifications', 'ntf_desc', 'fp-ntf-rules-page', rulesPage);
  define('service_alerts', 'sva_desc', 'fp-sva-page', servicesPage);
})();

/* freePanel domain proof (#/tool/domain_proof), the admin panel's queue of domains awaiting proof of control
   (docs/domain-proof.md; docs/api.md, "Proof of control for domains"): the switch for the check, how much room is left
   for names awaiting proof, and the names themselves, each of which the admin can approve. The API doesn't report the
   room: the page works it out from the list, with the bounds docs/domain-proof.md gives (a name counts its length plus
   3 bytes; 100 names and 8 KiB per account, 128 KiB per reseller's accounts, 512 KiB in all). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var DOMAIN_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var USER_RE = /^[a-z][a-z0-9_-]{0,31}$/;
  var KINDS = ['primary', 'addon', 'subdomain', 'alias'];
  var ACCOUNT_NAMES = 100;
  var ACCOUNT_BYTES = 8 << 10;
  var RESELLER_BYTES = 128 << 10;
  var SERVER_BYTES = 512 << 10;

  var page = null;
  var on = false;
  var list = [];

  function str(v) { return typeof v === 'string' ? v : ''; }
  function clean(r) {
    return (r && Array.isArray(r.domains) ? r.domains : []).filter(function (d) {
      return d && DOMAIN_RE.test(str(d.name)) && USER_RE.test(str(d.account));
    }).map(function (d) {
      return {name: d.name, account: d.account, owner: USER_RE.test(str(d.owner)) ? d.owner : '', kind: str(d.kind),
        created: str(d.created_at), checked: str(d.checked_at), note: str(d.note).slice(0, 300)};
    }).sort(function (a, b) { return a.name < b.name ? -1 : 1; });
  }
  function size(d) { return d.name.length + 3; }
  function kib(n) { return n < 1024 ? t('proof_bytes', {n: n}) : (n / 1024).toFixed(n < 10240 ? 1 : 0).replace(/\.0$/, '') + ' KiB'; }
  function when(iso) {
    var d = iso ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString(undefined, {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }

  /* one bound: how much of it is taken, as a line and a bar */
  function meterRow(label, value, frac, attrs) {
    var pct = Math.min(100, Math.max(0, frac * 100));
    var level = pct >= 95 ? ' is-danger' : pct >= 80 ? ' is-warn' : '';
    var bar = el('i');
    bar.style.width = pct.toFixed(1) + '%';
    return el('li', Object.assign({class: 'sig-row'}, attrs || {}), [el('div', {class: 'sig-row-head'}, [el('span', {class: 'sig-row-label', text: label}),
      el('span', {class: 'sig-stat-v' + level, text: value})]), el('div', {class: 'sig-meter' + level, 'aria-hidden': 'true'}, [bar])]);
  }
  /* the server, then the three fullest accounts and resellers. The list doesn't say which owners are resellers: an
     owner other than the signed-in admin is counted as one, since the admin's own customers share no owner bound */
  function fullCard() {
    var total = 0;
    var accounts = {};
    var owners = {};
    var me = FP.session.user.username;
    list.forEach(function (d) {
      var n = size(d);
      total += n;
      var a = accounts[d.account] || (accounts[d.account] = {name: d.account, names: 0, bytes: 0});
      a.names++;
      a.bytes += n;
      if (d.owner && d.owner !== me) {
        var o = owners[d.owner] || (owners[d.owner] = {name: d.owner, bytes: 0});
        o.bytes += n;
      }
    });
    function fracA(a) { return Math.max(a.names / ACCOUNT_NAMES, a.bytes / ACCOUNT_BYTES); }
    var rows = [meterRow(t('proof_full_server'), t('proof_full_bytes', {used: kib(total), limit: kib(SERVER_BYTES)}), total / SERVER_BYTES,
      {'data-fp-full': 'server'})];
    Object.keys(accounts).map(function (k) { return accounts[k]; }).sort(function (a, b) { return fracA(b) - fracA(a) || (a.name < b.name ? -1 : 1); })
      .slice(0, 3).forEach(function (a) {
        rows.push(meterRow(t('proof_full_account', {account: a.name}), t('proof_full_account_v', {n: a.names, used: kib(a.bytes), limit: kib(ACCOUNT_BYTES)}),
          fracA(a), {'data-fp-full': 'account:' + a.name}));
      });
    Object.keys(owners).map(function (k) { return owners[k]; }).sort(function (a, b) { return b.bytes - a.bytes || (a.name < b.name ? -1 : 1); })
      .slice(0, 3).forEach(function (o) {
        rows.push(meterRow(t('proof_full_reseller', {owner: o.name}), t('proof_full_bytes', {used: kib(o.bytes), limit: kib(RESELLER_BYTES)}),
          o.bytes / RESELLER_BYTES, {'data-fp-full': 'reseller:' + o.name}));
      });
    return M.card('fp-proof-full-h', t('proof_full_title'), [el('p', {class: 'fp-muted', text: t('proof_full_desc')}),
      el('ul', {class: 'sig-rows fp-proof-rows'}, rows), list.length ? null : el('p', {class: 'fp-muted', text: t('proof_full_none')})], 'fp-proof-full');
  }

  function switchCard() {
    var box = el('input', {type: 'checkbox', id: 'fp-proof-on', name: 'enabled', checked: on ? true : null, 'aria-describedby': 'fp-proof-on-hint'});
    var form = el('form', {class: 'fp-form fp-mail-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('label', {class: 'fp-check', for: 'fp-proof-on'}, [box, el('span', {text: t('proof_switch')})]),
      el('p', {class: 'sig-hint', id: 'fp-proof-on-hint', text: t('proof_switch_hint')}),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('proof_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      UI.setBusy(b, true);
      FP.call('put', 'proofSettings', {enabled: box.checked}).then(function (r) {
        on = Boolean(r && r.enabled === true);
        return load();
      }).then(function () {
        render();
        var f = page.querySelector('.fp-proof-switch');
        M.say(f, on ? t('proof_saved_on') : t('proof_saved_off'));
        f.querySelector('#fp-proof-on').focus();
      }, function (err) {
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return M.card('fp-proof-switch-h', t('proof_switch_title'), [form], 'fp-proof-switch');
  }

  function kindLabel(k) { return t(KINDS.indexOf(k) >= 0 ? 'proof_kind_' + k : 'proof_kind_other'); }
  function listCard() {
    var parts = [M.errorLine(), M.statusLine()];
    if (!list.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('proof_none')}));
    } else {
      parts.push(el('p', {class: 'fp-muted', text: list.length === 1 ? t('proof_count_1') : t('proof_count', {n: list.length})}));
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-proof-list-h'}, [
        el('table', {class: 'sig-table fp-mail-table fp-proof-table'}, [el('thead', null, [el('tr', null, [
          el('th', {scope: 'col', text: t('proof_domain')}), el('th', {scope: 'col', text: t('proof_account')}),
          el('th', {scope: 'col', text: t('proof_owner')}), el('th', {scope: 'col', text: t('proof_kind')}),
          el('th', {scope: 'col', text: t('proof_added')}), el('th', {scope: 'col', text: t('proof_checked')}),
          el('th', {scope: 'col', text: t('proof_note')}), el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]),
        el('tbody', null, list.map(function (d) {
          return el('tr', {'data-fp-domain': d.name}, [el('th', {scope: 'row', class: 'fp-mail-name', text: d.name}),
            el('td', {text: d.account}), el('td', {text: d.owner || '–'}), el('td', {text: kindLabel(d.kind)}),
            el('td', {class: 'fp-proof-when', text: when(d.created) || '–'}), el('td', {class: 'fp-proof-when', text: when(d.checked) || t('proof_never')}),
            el('td', {class: 'fp-proof-why', text: d.note || '–'}),
            el('td', {class: 'fp-mail-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'approve',
              'aria-label': t('proof_approve_of', {domain: d.name}), text: t('proof_approve')})])]);
        }))])]));
    }
    return M.card('fp-proof-list-h', t('proof_list_title'), parts, 'fp-proof-list');
  }

  function render() {
    page.textContent = '';
    page.appendChild(switchCard());
    if (!on) {
      page.appendChild(el('p', {class: 'fp-muted', 'data-fp-proof-off': '', text: t('proof_off_note')}));
      return;
    }
    page.appendChild(listCard());
    page.appendChild(fullCard());
  }
  function load() {
    return FP.call('get', 'proofPending').then(function (r) { list = clean(r); });
  }
  function focusRow(name) {
    var b = page.querySelector('tr[data-fp-domain="' + window.CSS.escape(name) + '"] [data-fp-act="approve"]');
    if (b) { b.focus(); } else { page.querySelector('#fp-proof-list-h').focus(); }
  }

  document.addEventListener('click', function (e) {
    var target = e.target.closest ? e.target : null;
    var b = target && page && page.contains(target) ? target.closest('[data-fp-act]') : null;
    if (!b) { return; }
    var a = b.getAttribute('data-fp-act');
    var tr = b.closest('tr[data-fp-domain]');
    var name = tr ? tr.getAttribute('data-fp-domain') : '';
    var d = list.filter(function (x) { return x.name === name; })[0];
    if (!d) { return; }
    if (a === 'approve') {
      M.confirmIn(tr.querySelector('.fp-mail-acts'), t('proof_approve_ask', {domain: d.name, account: d.account}), 'approve-yes', t('proof_approve'));
    } else if (a === 'confirm-no') {
      render();
      focusRow(name);
    } else if (a === 'approve-yes') {
      UI.setBusy(b, true);
      FP.call('post', 'proofApprove', undefined, {domain: name}).then(function () {
        return load().then(function () {
          render();
          M.say(page.querySelector('.fp-proof-list'), t('proof_approved', {domain: name}));
          page.querySelector('#fp-proof-list-h').focus();
        });
      }, function (err) {
        return load().catch(function () {}).then(function () {
          render();
          UI.showError(page.querySelector('.fp-proof-list'), err.message);
          focusRow(name);
        });
      });
    }
  });

  FP.view('tool:domain_proof', function () {
    var tool = FP.tools.domain_proof;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('proof_desc'), cls: 'fp-mail fp-proof-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'proofSettings').then(function (r) {
      on = Boolean(r && r.enabled === true);
      return on ? load() : (list = []);
    }).then(function () {
      if (page !== body) { return; }
      render();
    }, function (err) {
      if (page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

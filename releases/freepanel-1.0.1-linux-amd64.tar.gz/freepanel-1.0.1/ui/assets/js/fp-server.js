/* freePanel server pages of the admin panel (docs/api.md, "Server" and "Audit log"): Branding (#/tool/branding: the
   host's name, help link and logo on every panel), Service status (#/tool/service_status: whether each service we
   install is running, then the server's load, memory, disk and accounts, checked again on request) and Audit log
   (#/tool/audit_log: who changed what, newest first, with older entries fetched a page at a time). Branding and
   Service status are the server admin's alone; a reseller's audit log holds its own actions and those on its
   accounts. The page pieces come from FP.mail (fp-mail.js) and the status rows from FP.home (fp-home.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var MAX_LOGO = 256 * 1024;
  var MAX_SIDE = 1024;
  var PAGE = 100;
  var LOGO = '/api/v1/branding/logo';

  function str(v) { return typeof v === 'string' ? v : ''; }
  function frame(id, adminOnly) {
    var tool = FP.tools[id];
    if (!tool || FP.realm !== 'admin' || (adminOnly && FP.session.user.role !== 'admin')) { FP.views['not-found']({view: 'not-found'}); return null; }
    var g = FP.group(tool.group);
    return FP.frame({title: tool.label, desc: t(id + '_desc' + (FP.session.user.role === 'reseller' ? '_reseller' : '')), cls: 'fp-mail fp-srv fp-srv-' + id,
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
  }
  function when(iso) {
    var d = typeof iso === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(iso) ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'}) : '—';
  }

  /* ================= Branding ================= */
  var B = {page: null, state: null};
  /* the host's help link as the server takes it: https, or mailto with one address */
  function supportOk(u) {
    return !u || /^https:\/\/[^\s"'<>]+$/.test(u) || /^mailto:[^\s"'<>,;?&@]+@[^\s"'<>,;?&@]+$/.test(u);
  }
  function cleanBrand(v) {
    v = v && typeof v === 'object' ? v : {};
    return {name: str(v.name).slice(0, 64), support_url: supportOk(str(v.support_url)) ? str(v.support_url) : '', logo: v.logo === true};
  }
  /* this page's shell shows the change at once; other pages pick it up when they load */
  function showInShell(b) {
    var name = b.name || 'freePanel';
    UI.brand.name = name;
    var names = document.querySelectorAll('[data-fp-brand]');
    for (var i = 0; i < names.length; i++) { names[i].textContent = name; }
    var links = document.querySelectorAll('[data-fp-support]');
    for (var j = 0; j < links.length; j++) {
      if (b.support_url) { links[j].href = b.support_url; links[j].hidden = false; } else { links[j].hidden = true; }
    }
    var imgs = document.querySelectorAll('img[data-fp-logo]');
    for (var k = 0; k < imgs.length; k++) {
      if (b.logo) {
        imgs[k].alt = name;
        imgs[k].src = LOGO + '?v=' + Date.now();
        imgs[k].hidden = false;
        imgs[k].parentNode.classList.add('has-logo');
      } else {
        imgs[k].hidden = true;
        imgs[k].removeAttribute('src');
        imgs[k].parentNode.classList.remove('has-logo');
      }
    }
  }
  function bNameCard() {
    var name = el('input', {class: 'sig-input', id: 'fp-brand-name', name: 'name', type: 'text', maxlength: '64', autocomplete: 'off', value: B.state.name,
      placeholder: 'freePanel'});
    var url = el('input', {class: 'sig-input', id: 'fp-brand-url', name: 'support_url', type: 'text', inputmode: 'url', maxlength: '2048', autocomplete: 'off',
      spellcheck: 'false', autocapitalize: 'none', value: B.state.support_url, placeholder: 'https://help.example.com'});
    var form = el('form', {class: 'fp-form fp-mail-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-brand-name', t('brand_name'), name, t('brand_name_hint')),
      M.field('fp-brand-url', t('brand_url'), url, t('brand_url_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('brand_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var body = {name: name.value.trim(), support_url: url.value.trim()};
      if (Array.from(body.name).length > 64 || /[\u0000-\u001f\u007f]/.test(body.name)) { M.fieldError(form, name, t('brand_name_bad')); return; }   // eslint-disable-line no-control-regex -- printable characters only
      if (!supportOk(body.support_url)) { M.fieldError(form, url, t('brand_url_bad')); return; }
      UI.setBusy(b, true);
      FP.call('put', 'branding', body).then(function (r) {
        UI.setBusy(b, false);
        B.state = cleanBrand(r);
        name.value = B.state.name;
        url.value = B.state.support_url;
        showInShell(B.state);
        M.say(form, t('brand_saved'));
      }, function (err) {
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return M.card('fp-brand-name-h', t('brand_name_title'), [form], 'fp-brand-names');
  }
  /* the picture's size in pixels, where the browser can tell without showing it; null when it can't */
  function sides(file) {
    if (!window.createImageBitmap) { return Promise.resolve(null); }
    return window.createImageBitmap(file).then(function (bmp) {
      var s = {w: bmp.width, h: bmp.height};
      if (bmp.close) { bmp.close(); }
      return s;
    }, function () { return {bad: true}; });
  }
  function bLogoCard() {
    var file = el('input', {class: 'sig-input fp-brand-file', id: 'fp-brand-file', name: 'logo', type: 'file', accept: 'image/png,image/jpeg'});
    var parts = [M.errorLine(), M.statusLine()];
    if (B.state.logo) {
      parts.push(el('div', {class: 'fp-brand-preview'}, [el('img', {src: LOGO + '?v=' + Date.now(), alt: t('brand_logo_now'), 'data-fp-brand-preview': ''})]));
    } else {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('brand_logo_none')}));
    }
    var form = el('form', {class: 'fp-form fp-mail-form', novalidate: ''}, [
      M.field('fp-brand-file', B.state.logo ? t('brand_logo_new') : t('brand_logo_pick'), file, t('brand_logo_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('brand_logo_upload')}),
        B.state.logo ? el('span', {class: 'fp-mail-acts fp-brand-remove'}, [el('button', {class: 'sig-btn sig-btn--secondary fp-btn-danger-text', type: 'button',
          'data-fp-act': 'logo-remove', text: t('brand_logo_remove')})]) : null])]);
    var card = M.card('fp-brand-logo-h', t('brand_logo_title'), parts.concat([form]), 'fp-brand-logo');
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = form.querySelector('.fp-submit');
      if (b.disabled) { return; }
      UI.showError(card, '');
      M.say(card, '');
      file.removeAttribute('aria-invalid');
      var f = file.files && file.files[0];
      if (!f) { M.fieldError(card, file, t('brand_logo_none_picked')); return; }
      if (f.type !== 'image/png' && f.type !== 'image/jpeg') { M.fieldError(card, file, t('brand_logo_type')); return; }
      if (f.size > MAX_LOGO) { M.fieldError(card, file, t('brand_logo_big')); return; }
      UI.setBusy(b, true);
      sides(f).then(function (s) {
        if (s && (s.bad || s.w > MAX_SIDE || s.h > MAX_SIDE)) {
          UI.setBusy(b, false);
          M.fieldError(card, file, s.bad ? t('brand_logo_type') : t('brand_logo_sides', {w: s.w, h: s.h}));
          return;
        }
        FP.call('put', 'brandingLogo', f).then(function () {
          B.state.logo = true;
          bRender();
          showInShell(B.state);
          M.say(B.page.querySelector('.fp-brand-logo'), t('brand_logo_done'));
          B.page.querySelector('#fp-brand-logo-h').focus();
        }, function (err) {
          UI.setBusy(b, false);
          M.fieldError(card, file, err.message);
        });
      });
    });
    return card;
  }
  function bRender() {
    B.page.textContent = '';
    B.page.appendChild(bNameCard());
    B.page.appendChild(bLogoCard());
  }
  function bClick(b, a) {
    if (a === 'logo-remove') {
      M.confirmIn(b.parentNode, t('brand_logo_remove_ask'), 'logo-remove-yes', t('brand_logo_remove'));
    } else if (a === 'confirm-no') {
      bRender();
      B.page.querySelector('[data-fp-act="logo-remove"]').focus();
    } else if (a === 'logo-remove-yes') {
      UI.setBusy(b, true);
      FP.call('del', 'brandingLogo').then(function () {
        B.state.logo = false;
        bRender();
        showInShell(B.state);
        M.say(B.page.querySelector('.fp-brand-logo'), t('brand_logo_removed'));
        B.page.querySelector('#fp-brand-logo-h').focus();
      }, function (err) {
        bRender();
        UI.showError(B.page.querySelector('.fp-brand-logo'), err.message);
        B.page.querySelector('[data-fp-act="logo-remove"]').focus();
      });
    }
  }

  /* ================= Service status ================= */
  var S = {page: null, busy: false};
  /* systemd's ActiveState as the panel says it */
  var ACTIVE = {active: ['ok', 'svc_running'], reloading: ['ok', 'svc_reloading'], activating: ['warn', 'svc_starting'],
    deactivating: ['warn', 'svc_stopping'], inactive: ['', 'svc_stopped'], failed: ['danger', 'svc_failed']};
  var BOOT = {enabled: 'svc_boot_yes', 'enabled-runtime': 'svc_boot_yes', disabled: 'svc_boot_no', masked: 'svc_boot_blocked'};
  function svcLabel(unit) {
    var php = /^php(\d)(\d)-php-fpm$/.exec(unit);
    if (php) { return t('svc_php', {v: php[1] + '.' + php[2]}); }
    if (/^postgresql@/.test(unit)) { return t('svc_postgresql'); }
    var k = 'svc_' + unit.replace(/-/g, '_');
    return t(k) === k ? unit : t(k);
  }
  function cleanServices(r) {
    return (r && Array.isArray(r.services) ? r.services : []).filter(function (v) {
      return v && typeof v.unit === 'string' && /^[a-z0-9][a-z0-9@.-]{0,63}$/.test(v.unit);
    }).map(function (v) { return {unit: v.unit, load: str(v.load).slice(0, 32), active: str(v.active).slice(0, 32), enabled: str(v.enabled).slice(0, 32)}; });
  }
  /* a masked unit cannot start, and one whose unit file has errors cannot run as set up, whatever its ActiveState */
  function svcState(v) {
    if (v.load === 'masked') { return ['danger', 'svc_blocked']; }
    if (v.load && v.load !== 'loaded') { return ['danger', 'svc_failed']; }
    return ACTIVE[v.active];
  }
  function svcUp(v) {
    return (!v.load || v.load === 'loaded') && (v.active === 'active' || v.active === 'reloading');
  }
  function svcCard(r) {
    var head = el('div', {class: 'sig-card-head'}, [el('h2', {class: 'sig-card-title', id: 'fp-card-services', text: t('svc_title')})]);
    var card = el('section', {class: 'sig-card fp-srv-services', 'aria-labelledby': 'fp-card-services', 'data-fp-services': ''}, [head]);
    if (r.failed) {
      card.appendChild(el('div', {class: 'sig-card-body'}, [el('p', {class: 'fp-muted', 'data-fp-services-error': '', text: t('svc_unknown', {msg: r.failed})})]));
      return card;
    }
    var list = cleanServices(r);
    if (!list.length) {
      card.appendChild(el('div', {class: 'sig-card-body'}, [el('p', {class: 'fp-muted', text: t('svc_none')})]));
      return card;
    }
    var down = list.filter(function (v) { return !svcUp(v); }).length;
    var sum = el('p', {class: 'fp-srv-sum' + (down ? ' fp-srv-sum-down' : ''), 'data-fp-services-sum': '',
      text: down ? t(down === 1 ? 'svc_down_1' : 'svc_down', {n: down, total: list.length}) : t(list.length === 1 ? 'svc_all_up_1' : 'svc_all_up', {n: list.length})});
    var rows = list.map(function (v) {
      var a = svcState(v);
      return el('tr', {'data-fp-service': v.unit}, [
        el('th', {scope: 'row'}, [el('span', {class: 'fp-srv-name', text: svcLabel(v.unit)}), el('span', {class: 'sig-mono fp-muted fp-srv-unit', text: v.unit})]),
        el('td', null, [a ? el('span', {class: 'sig-pill' + (a[0] ? ' sig-pill--' + a[0] : ''), text: t(a[1])}) : el('span', {text: v.active || '\u2014'})]),
        el('td', {text: BOOT[v.enabled] ? t(BOOT[v.enabled]) : '\u2014'})]);
    });
    card.appendChild(el('div', {class: 'sig-card-body'}, [sum,
      el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-label': t('svc_list')}, [
        el('table', {class: 'sig-table fp-mail-table fp-srv-table'}, [el('thead', null, [el('tr', null, [
          el('th', {scope: 'col', text: t('svc_service')}), el('th', {scope: 'col', text: t('svc_state')}), el('th', {scope: 'col', text: t('svc_boot')})])]),
        el('tbody', null, rows)])])]));
    return card;
  }
  function sRender(r, svc) {
    var H = FP.home;
    var st = r && r.status && typeof r.status === 'object' ? r.status : {};
    var num = function (v) { return typeof v === 'number' && isFinite(v) && v >= 0; };
    var card = H.infoCard(t('status_title'), 'status');
    H.fill(card.querySelector('ul'), H.statusRows(r && r.version, st));
    /* the last minute's load against the cores: at or above 1 per core, work waits */
    var cores = num(st.cpus) && st.cpus > 0 ? st.cpus : null;
    var load = Array.isArray(st.load) && num(st.load[0]) ? st.load[0] : null;
    var busy = H.infoCard(t('status_busy_title'), 'busy');
    H.fill(busy.querySelector('ul'), [
      H.meterRow(t('status_load_per_core'), load !== null && cores ? load / cores : null, cores ? 1 : null, function (n) { return n.toFixed(2); }),
      el('li', {class: 'sig-row fp-muted fp-row-note', text: t('status_load_note')})]);
    var check = el('p', {class: 'fp-muted fp-srv-when', role: 'status', 'aria-live': 'polite', 'data-fp-status': '',
      text: t('status_checked', {when: new Date().toLocaleTimeString('en', {timeStyle: 'short'})})});
    var again = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'status-again', text: t('status_again')});
    S.page.textContent = '';
    S.page.appendChild(el('div', {class: 'fp-srv-bar'}, [again, check]));
    S.page.appendChild(svcCard(svc));
    S.page.appendChild(el('div', {class: 'fp-srv-cards'}, [card, busy]));
    S.page.appendChild(M.errorLine());
  }
  function sLoad(focus) {
    var mine = S.page;
    S.busy = true;
    var again = S.page.querySelector('[data-fp-act="status-again"]');
    if (again) { UI.setBusy(again, true); }
    /* a service list that cannot be read does not hide the rest of the page */
    var svc = FP.call('get', 'serverServices').then(function (r) { return r || {}; }, function (err) { return {failed: err.message}; });
    Promise.all([FP.call('get', 'serverStatus'), svc]).then(function (both) {
      S.busy = false;
      if (S.page !== mine) { return; }
      sRender(both[0], both[1]);
      if (focus) { S.page.querySelector('[data-fp-act="status-again"]').focus(); }
    }, function (err) {
      S.busy = false;
      if (S.page !== mine) { return; }
      if (again) {
        UI.setBusy(again, false);
        UI.showError(S.page, err.message);
        again.focus();
        return;
      }
      S.page.textContent = '';
      S.page.appendChild(FP.empty(FP.tools.service_status.label, err.message));
    });
  }

  /* the Services page (fp-services.js) names and words the services as this page does */
  FP.services = {label: svcLabel, state: svcState, up: svcUp, boot: function (v) { return BOOT[v.enabled] ? t(BOOT[v.enabled]) : ''; }};

  /* ================= Audit log ================= */
  var A = {page: null, entries: [], more: false, filter: ''};
  function cleanEntries(r) {
    return (r && Array.isArray(r.entries) ? r.entries : []).filter(function (e) {
      return e && typeof e.id === 'number' && isFinite(e.id) && e.id > 0;
    }).map(function (e) {
      return {id: e.id, at: str(e.at), actor: str(e.actor).slice(0, 64), from: str(e.remote_addr).slice(0, 64), action: str(e.action).slice(0, 64),
        target: str(e.target).slice(0, 255), result: str(e.result), detail: str(e.detail).slice(0, 500), byHost: e.by_host === true};
    });
  }
  var RESULT = {ok: ['ok', 'audit_ok'], denied: ['warn', 'audit_denied'], failed: ['danger', 'audit_failed']};
  function aRow(e) {
    var r = RESULT[e.result];
    return el('tr', {'data-fp-entry': String(e.id)}, [
      el('td', {class: 'fp-audit-when', text: when(e.at)}),
      el('th', {scope: 'row', class: 'fp-audit-who', text: who(e)}),
      el('td', {class: 'sig-mono fp-audit-action', text: e.action || '—'}),
      el('td', {class: 'fp-audit-target', text: e.target || '—'}),
      el('td', null, [r ? el('span', {class: 'sig-pill sig-pill--' + r[0], text: t(r[1])}) : el('span', {text: e.result || '—'})]),
      el('td', {class: 'sig-mono fp-audit-from', text: e.from || '—'}),
      el('td', {class: 'fp-audit-detail', text: e.detail})]);
  }
  /* a reseller is told that someone at the host acted, not who or from where */
  function who(e) { return e.byHost ? t('audit_host') : e.actor || t('audit_nobody'); }
  function hit(e, q) {
    return !q || [who(e), e.action, e.target, e.from, e.detail, t(RESULT[e.result] ? RESULT[e.result][1] : 'audit_none')].some(function (v) {
      return v.toLowerCase().indexOf(q) >= 0;
    });
  }
  function aRender() {
    A.page.textContent = '';
    if (!A.entries.length) {
      A.page.appendChild(FP.empty(t('audit_none_title'), t('audit_none')));
      return;
    }
    var filter = el('input', {class: 'sig-input', id: 'fp-audit-filter', type: 'search', autocomplete: 'off', spellcheck: 'false', maxlength: '100',
      value: A.filter, 'aria-describedby': 'fp-audit-count'});
    var count = el('p', {class: 'fp-muted', id: 'fp-audit-count', role: 'status', 'aria-live': 'polite'});
    var tbody = el('tbody', null, A.entries.map(aRow));
    var none = el('p', {class: 'fp-muted', hidden: true, text: t('audit_no_match')});
    var wrap = el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-audit-h'}, [
      el('table', {class: 'sig-table fp-mail-table fp-audit-table'}, [el('thead', null, [el('tr', null, [
        el('th', {scope: 'col', text: t('audit_when')}), el('th', {scope: 'col', text: t('audit_who')}), el('th', {scope: 'col', text: t('audit_action')}),
        el('th', {scope: 'col', text: t('audit_target')}), el('th', {scope: 'col', text: t('audit_result')}), el('th', {scope: 'col', text: t('audit_from')}),
        el('th', {scope: 'col', text: t('audit_detail')})])]), tbody])]);
    var more = A.more ? el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'audit-more', text: t('audit_more')}) :
      el('p', {class: 'fp-muted', 'data-fp-audit-end': '', text: t('audit_end')});
    function apply() {
      var q = filter.value.trim().toLowerCase();
      A.filter = filter.value;
      var shown = 0;
      A.entries.forEach(function (e, i) {
        var on = hit(e, q);
        tbody.children[i].hidden = !on;
        if (on) { shown++; }
      });
      wrap.hidden = shown === 0;
      none.hidden = shown !== 0;
      count.textContent = q ? t('audit_count_filtered', {n: shown, total: A.entries.length}) : t(A.entries.length === 1 ? 'audit_count_1' : 'audit_count', {n: A.entries.length});
    }
    filter.addEventListener('input', apply);
    filter.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && filter.value) { e.stopPropagation(); filter.value = ''; apply(); }
    });
    var card = el('section', {class: 'sig-card fp-mail-card fp-audit', 'aria-labelledby': 'fp-audit-h'}, [el('div', {class: 'sig-card-body'}, [
      el('h2', {class: 'fp-h2 sig-vh', id: 'fp-audit-h', text: FP.tools.audit_log.label}),
      el('div', {class: 'sig-field fp-zones-filter'}, [el('label', {class: 'sig-label', for: 'fp-audit-filter', text: t('audit_filter')}), filter]),
      count, M.errorLine(), wrap, none, el('div', {class: 'fp-actions fp-audit-more'}, [more])])]);
    A.page.appendChild(card);
    apply();
  }
  function aMore(b) {
    var last = A.entries[A.entries.length - 1];
    var mine = A.page;
    UI.setBusy(b, true);
    FP.call('get', 'auditBefore', undefined, {before: String(last.id)}).then(function (r) {
      if (A.page !== mine) { return; }
      var older = cleanEntries(r).filter(function (e) { return e.id < last.id; });
      var n = A.entries.length;
      A.entries = A.entries.concat(older);
      A.more = older.length >= PAGE;
      aRender();
      var next = A.page.querySelector('[data-fp-act="audit-more"]');
      var row = A.page.querySelectorAll('tr[data-fp-entry]')[n];
      UI.announce(t('audit_more_done', {n: older.length}));
      if (next) { next.focus(); } else if (row && !row.hidden) { row.querySelector('th').setAttribute('tabindex', '-1'); row.querySelector('th').focus(); } else { A.page.querySelector('#fp-audit-filter').focus(); }
    }, function (err) {
      if (A.page !== mine) { return; }
      UI.setBusy(b, false);
      UI.showError(A.page.querySelector('.fp-audit'), err.message);
      b.focus();
    });
  }

  document.addEventListener('click', function (e) {
    var target = e.target.closest ? e.target : null;
    var b = target && target.closest('[data-fp-act]');
    if (!b) { return; }
    var a = b.getAttribute('data-fp-act');
    if (B.page && B.page.contains(b)) { bClick(b, a); } else if (S.page && S.page.contains(b) && a === 'status-again' && !S.busy) { sLoad(true); } else if (A.page && A.page.contains(b) && a === 'audit-more') { aMore(b); }
  });

  function reset() { B.page = S.page = A.page = null; }
  FP.view('tool:branding', function () {
    reset();
    var body = frame('branding', true);
    if (!body) { return; }
    B.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'branding').then(function (r) {
      if (B.page !== body) { return; }
      B.state = cleanBrand(r);
      bRender();
    }, function (err) {
      if (B.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(FP.tools.branding.label, err.message));
    });
  });
  FP.view('tool:service_status', function () {
    reset();
    var body = frame('service_status', true);
    if (!body) { return; }
    S.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    sLoad(false);
  });
  FP.view('tool:audit_log', function () {
    reset();
    var body = frame('audit_log', false);
    if (!body) { return; }
    A.page = body;
    A.entries = [];
    A.filter = '';
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'audit').then(function (r) {
      if (A.page !== body) { return; }
      A.entries = cleanEntries(r);
      A.more = A.entries.length >= PAGE;
      aRender();
    }, function (err) {
      if (A.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(FP.tools.audit_log.label, err.message));
    });
  });
})();

/* freePanel shared logins and visitor countries (docs/api.md, "Metrics"): the customer panel's Shared logins (#/tool/shared_logins), which
   lists the logins that signed in to a site from many different addresses lately (what a password handed around looks like), and
   Visitor countries (#/tool/visitor_countries), a site's recent requests by country; and the administrator's Country database
   (#/tool/geoip_db), which says whether the file of address ranges the visitor countries come from was read. Login names, countries and
   file paths are shown as text, never as markup: they come from log lines and a file on the server. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var DOMAIN_RE = /^[a-z0-9]([a-z0-9.-]{0,251}[a-z0-9])?$/;
  var MAX_ROWS = 300;

  function str(v) { return typeof v === 'string' ? v : ''; }
  function num(v, hi) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.min(Math.floor(v), hi || 1e12) : 0; }
  function count(n) { return Math.round(n).toLocaleString('en'); }
  function when(iso) {
    var d = new Date(str(iso));
    return isNaN(d.getTime()) ? '' : d.toLocaleString(undefined, {year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'});
  }
  function frame(id, cls, admin) {
    var tool = FP.tools[id];
    var ok = admin ? FP.realm === 'admin' && FP.session.user.role === 'admin' : FP.realm === 'user';
    if (!tool || !ok) { FP.views['not-found']({view: 'not-found'}); return null; }
    var g = FP.group(tool.group);
    return FP.frame({title: tool.label, desc: t(id + '_desc'), cls: 'fp-mail fp-lc ' + cls,
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
  }
  function selectField(id, label, options, value) {
    var s = el('select', {class: 'sig-select', id: id, name: id}, options.map(function (o) {
      return el('option', {value: String(o[0]), selected: String(o[0]) === String(value) ? true : null, text: o[1]});
    }));
    return {select: s, field: M.field(id, label, s)};
  }
  function hoursLabel(h) { return h === 1 ? t('lc_hour') : h < 24 ? t('lc_hours', {n: String(h)}) : h === 24 ? t('lc_day') : t('lc_days', {n: String(h / 24)}); }

  /* the site picker both customer pages share: the account's sites, the last one chosen remembered */
  function loadSites(account) {
    return FP.call('get', 'domains', undefined, account).then(function (r) {
      var sites = r && Array.isArray(r.sites) ? r.sites : [];
      return sites.map(function (s) { return str(s && s.domain); }).filter(function (d) { return DOMAIN_RE.test(d); }).sort();
    });
  }
  function remembered(names) {
    var v = UI.store.get('fp.stats.site');
    return v && names.indexOf(v) >= 0 ? v : names[0];
  }

  /* ================= Shared logins ================= */
  var L = {page: null};
  function cleanLogins(r) {
    r = r && typeof r === 'object' ? r : {};
    var rows = (Array.isArray(r.logins) ? r.logins : []).slice(0, MAX_ROWS).filter(function (x) { return x && typeof x.user === 'string' && x.user; }).map(function (x) {
      return {user: x.user.slice(0, 128), addresses: num(x.addresses), hits: num(x.hits), first: when(x.first), last: when(x.last), flagged: x.flagged === true};
    });
    return {rows: rows, hours: num(r.hours, 168) || 2, addresses: num(r.addresses, 100) || 4, from: when(r.read_from), truncated: r.truncated === true};
  }
  function lRender() {
    var page = L.page;
    page.textContent = '';
    if (!L.names.length) {
      page.appendChild(FP.empty(FP.tools.shared_logins.label, t('lc_no_sites')));
      return;
    }
    var site = selectField('fp-lc-site', t('lc_site'), L.names.map(function (n) { return [n, n]; }), L.site);
    var hours = selectField('fp-lc-hours', t('lc_window'), [1, 2, 6, 24, 72, 168].map(function (h) { return [h, hoursLabel(h)]; }), L.hours);
    var bar = selectField('fp-lc-addresses', t('lc_bar'), [2, 3, 4, 6, 10].map(function (n) { return [n, t('lc_bar_n', {n: String(n)})]; }), L.addresses);
    var reload = el('button', {class: 'sig-btn sig-btn--secondary fp-submit', type: 'button', 'data-fp-act': 'reload', text: t('lc_reload')});
    var parts = [el('div', {class: 'fp-st-controls fp-lc-controls'}, [site.field, hours.field, bar.field, el('div', {class: 'fp-st-reload'}, [reload])]),
      el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': ''})];
    var flagged = L.rows.filter(function (x) { return x.flagged; }).length;
    if (!L.rows.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('lc_none', {site: L.site, window: hoursLabel(L.hours).toLowerCase()})}));
    } else {
      parts.push(el('p', {'data-fp-lc-summary': '', text: flagged ? t('lc_flagged_n', {n: String(flagged), bar: String(L.addresses)}) : t('lc_none_flagged', {bar: String(L.addresses)})}));
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-lc-list-h'}, [el('table', {class: 'sig-table fp-mail-table fp-lc-table'}, [
        el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('lc_login')}), el('th', {scope: 'col', class: 'fp-num', text: t('lc_addresses')}),
          el('th', {scope: 'col', class: 'fp-num', text: t('lc_requests')}), el('th', {scope: 'col', text: t('lc_first')}), el('th', {scope: 'col', text: t('lc_last')}),
          el('th', {scope: 'col', text: t('lc_state')})])]),
        el('tbody', null, L.rows.map(function (x) {
          return el('tr', {'data-fp-login': x.user}, [el('th', {scope: 'row', class: 'fp-lc-name'}, [el('span', {class: 'sig-mono', text: x.user})]),
            el('td', {class: 'fp-num', text: count(x.addresses)}), el('td', {class: 'fp-num', text: count(x.hits)}),
            el('td', {class: 'fp-lc-when', text: x.first || '—'}), el('td', {class: 'fp-lc-when', text: x.last || '—'}),
            el('td', null, [el('span', {class: 'sig-pill' + (x.flagged ? ' sig-pill--warn' : ''), text: t(x.flagged ? 'lc_shared' : 'lc_normal')})])]);
        }))])]));
    }
    if (L.truncated) { parts.push(el('p', {class: 'fp-muted', text: t('lc_truncated')})); }
    if (L.from) { parts.push(el('p', {class: 'fp-muted', text: t('lc_read_from', {when: L.from})})); }
    parts.push(el('p', {class: 'fp-muted', text: t('lc_note')}));
    page.appendChild(M.card('fp-lc-list-h', t('lc_title', {site: L.site}), parts, 'fp-lc-list'));
    function again(focus) { L.site = site.select.value; L.hours = Number(hours.select.value); L.addresses = Number(bar.select.value); UI.store.set('fp.stats.site', L.site); lLoad(focus); }
    site.select.addEventListener('change', function () { again('#fp-lc-site'); });
    hours.select.addEventListener('change', function () { again('#fp-lc-hours'); });
    bar.select.addEventListener('change', function () { again('#fp-lc-addresses'); });
    reload.addEventListener('click', function () { again('[data-fp-act="reload"]'); });
  }
  function lLoad(focus) {
    var mine = L.page;
    var b = mine.querySelector('[data-fp-act="reload"]');
    UI.setBusy(b, true);
    FP.call('get', 'statsLeeches', undefined, {name: L.account, domain: L.site, hours: String(L.hours), addresses: String(L.addresses)}).then(function (r) {
      if (L.page !== mine) { return; }
      var c = cleanLogins(r);
      L.rows = c.rows; L.truncated = c.truncated; L.from = c.from;
      lRender();
      UI.announce(t('lc_loaded', {site: L.site}));
      if (focus) { mine.querySelector(focus).focus(); }
    }, function (err) {
      if (L.page !== mine) { return; }
      UI.setBusy(b, false);
      UI.showError(mine.querySelector('.fp-lc-list'), err.message);
    });
  }
  FP.view('tool:shared_logins', function () {
    L.page = null;
    var body = frame('shared_logins', 'fp-lc-logins', false);
    if (!body) { return; }
    L = {page: body, account: FP.account(), rows: [], names: [], hours: 2, addresses: 4, truncated: false, from: ''};
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    loadSites(L.account).then(function (names) {
      if (L.page !== body) { return; }
      L.names = names;
      L.site = remembered(names);
      lRender();
      if (names.length) { lLoad(''); }
    }, function (err) {
      if (L.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(FP.tools.shared_logins.label, err.message));
    });
  });

  /* ================= Visitor countries ================= */
  var C = {page: null};
  var region = null;
  function countryName(code) {
    if (code === '??') { return t('lc_unknown_country'); }
    try {
      region = region || new window.Intl.DisplayNames(['en'], {type: 'region'});
      var n = region.of(code);
      return n && n !== code ? n : code;
    } catch (e) { return code; }
  }
  function cleanCountries(r) {
    r = r && typeof r === 'object' ? r : {};
    var rows = (Array.isArray(r.countries) ? r.countries : []).slice(0, MAX_ROWS).filter(function (x) { return x && /^([A-Z]{2}|\?\?)$/.test(str(x.code)); }).map(function (x) {
      return {code: x.code, hits: num(x.hits), visitors: num(x.visitors)};
    });
    return {rows: rows, hits: num(r.hits), from: when(r.read_from), truncated: r.truncated === true};
  }
  function cRender() {
    var page = C.page;
    page.textContent = '';
    if (!C.names.length) {
      page.appendChild(FP.empty(FP.tools.visitor_countries.label, t('lc_no_sites')));
      return;
    }
    var site = selectField('fp-vc-site', t('lc_site'), C.names.map(function (n) { return [n, n]; }), C.site);
    var hours = selectField('fp-vc-hours', t('lc_window'), [1, 6, 24, 72, 168].map(function (h) { return [h, hoursLabel(h)]; }), C.hours);
    var reload = el('button', {class: 'sig-btn sig-btn--secondary fp-submit', type: 'button', 'data-fp-act': 'reload', text: t('lc_reload')});
    var parts = [el('div', {class: 'fp-st-controls fp-lc-controls'}, [site.field, hours.field, el('div', {class: 'fp-st-reload'}, [reload])]),
      el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': ''})];
    if (C.unavailable) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-nodb': '', text: C.unavailable}));
      parts.push(el('p', {class: 'fp-muted', text: t('lc_nodb_ask')}));
    } else if (!C.rows.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('lc_vc_none', {site: C.site, window: hoursLabel(C.hours).toLowerCase()})}));
    } else {
      parts.push(el('p', {'data-fp-vc-summary': '', text: t('lc_vc_total', {n: count(C.hits), window: hoursLabel(C.hours).toLowerCase()})}));
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-vc-list-h'}, [el('table', {class: 'sig-table fp-mail-table fp-lc-table'}, [
        el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('lc_country')}), el('th', {scope: 'col', class: 'fp-num', text: t('lc_requests')}),
          el('th', {scope: 'col', class: 'fp-num', text: t('lc_visitors')}), el('th', {scope: 'col', class: 'fp-num', text: t('lc_share')})])]),
        el('tbody', null, C.rows.map(function (x) {
          return el('tr', {'data-fp-country': x.code}, [el('th', {scope: 'row', class: 'fp-lc-name'}, [el('span', {text: countryName(x.code)}), ' ',
            el('span', {class: 'fp-muted sig-mono', text: x.code === '??' ? '' : x.code})]),
          el('td', {class: 'fp-num', text: count(x.hits)}), el('td', {class: 'fp-num', text: count(x.visitors)}),
          el('td', {class: 'fp-num', text: C.hits ? Math.round(x.hits * 100 / C.hits) + ' %' : '—'})]);
        }))])]));
    }
    if (C.truncated) { parts.push(el('p', {class: 'fp-muted', text: t('lc_truncated')})); }
    if (C.from && !C.unavailable) { parts.push(el('p', {class: 'fp-muted', text: t('lc_read_from', {when: C.from})})); }
    page.appendChild(M.card('fp-vc-list-h', t('lc_vc_title', {site: C.site}), parts, 'fp-vc-list'));
    function again(focus) { C.site = site.select.value; C.hours = Number(hours.select.value); UI.store.set('fp.stats.site', C.site); cLoad(focus); }
    site.select.addEventListener('change', function () { again('#fp-vc-site'); });
    hours.select.addEventListener('change', function () { again('#fp-vc-hours'); });
    reload.addEventListener('click', function () { again('[data-fp-act="reload"]'); });
  }
  function cLoad(focus) {
    var mine = C.page;
    var b = mine.querySelector('[data-fp-act="reload"]');
    UI.setBusy(b, true);
    FP.call('get', 'statsCountries', undefined, {name: C.account, domain: C.site, hours: String(C.hours)}).then(function (r) {
      if (C.page !== mine) { return; }
      var c = cleanCountries(r);
      C.rows = c.rows; C.hits = c.hits; C.truncated = c.truncated; C.from = c.from; C.unavailable = '';
      cRender();
      UI.announce(t('lc_loaded', {site: C.site}));
      if (focus) { mine.querySelector(focus).focus(); }
    }, function (err) {
      if (C.page !== mine) { return; }
      if (err.status === 409) {
        C.rows = []; C.hits = 0; C.unavailable = err.message;
        cRender();
        if (focus) { mine.querySelector(focus).focus(); }
        return;
      }
      UI.setBusy(b, false);
      UI.showError(mine.querySelector('.fp-vc-list'), err.message);
    });
  }
  FP.view('tool:visitor_countries', function () {
    C.page = null;
    var body = frame('visitor_countries', 'fp-lc-countries', false);
    if (!body) { return; }
    C = {page: body, account: FP.account(), rows: [], names: [], hours: 24, hits: 0, truncated: false, from: '', unavailable: ''};
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    loadSites(C.account).then(function (names) {
      if (C.page !== body) { return; }
      C.names = names;
      C.site = remembered(names);
      cRender();
      if (names.length) { cLoad(''); }
    }, function (err) {
      if (C.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(FP.tools.visitor_countries.label, err.message));
    });
  });

  /* ================= The administrator's country database ================= */
  function gdRender(page, r) {
    var ok = r.installed === true;
    var facts = [[t('gd_state'), ok ? t('gd_installed') : t('gd_not_installed')], [t('gd_path'), str(r.path).slice(0, 300), true]];
    if (ok) {
      facts.push([t('gd_ranges'), t('gd_ranges_v', {four: count(num(r.ipv4_ranges)), six: count(num(r.ipv6_ranges))})],
        [t('gd_countries'), count(num(r.countries))], [t('gd_modified'), when(r.modified) || '—']);
    }
    var parts = [M.errorLine(), el('p', {class: 'fp-sq-state'}, [el('span', {class: 'sig-pill' + (ok ? ' sig-pill--ok' : r.error ? ' sig-pill--warn' : ''),
      text: ok ? t('gd_installed') : r.error ? t('gd_unusable') : t('gd_not_installed')})])];
    if (r.error) { parts.push(el('p', {class: 'fp-lc-bad', 'data-fp-gd-error': '', text: t('gd_why') + ' ' + str(r.error).slice(0, 400)})); }
    parts.push(el('dl', {class: 'fp-lc-facts'}, facts.reduce(function (out, f) {
      out.push(el('dt', {text: f[0]}), el('dd', {class: f[2] ? 'sig-mono' : ''}, [document.createTextNode(f[1])]));
      return out;
    }, [])));
    parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'reload', text: t('lc_reload')})]));
    page.textContent = '';
    page.appendChild(M.card('fp-gd-h', t('gd_title'), parts, 'fp-gd-card'));
    page.appendChild(M.card('fp-gd-how-h', t('gd_how_title'), [el('p', {text: t('gd_how_1')}), el('p', {class: 'fp-muted', text: t('gd_how_2')}),
      el('p', {class: 'fp-muted', text: t('gd_how_3')})], 'fp-gd-how'));
    page.querySelector('[data-fp-act="reload"]').addEventListener('click', function (e) { gdLoad(page, e.currentTarget); });
  }
  function gdLoad(page, button) {
    if (button) { UI.setBusy(button, true); }
    FP.call('get', 'webGeoip').then(function (r) {
      gdRender(page, r && typeof r === 'object' ? r : {});
      if (button) { page.querySelector('[data-fp-act="reload"]').focus(); }
    }, function (err) {
      if (button) { UI.setBusy(button, false); UI.showError(page.querySelector('.fp-gd-card'), err.message); return; }
      page.textContent = '';
      page.appendChild(FP.empty(FP.tools.geoip_db.label, err.message));
    });
  }
  FP.view('tool:geoip_db', function () {
    var body = frame('geoip_db', 'fp-gd', true);
    if (!body) { return; }
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    gdLoad(body, null);
  });
})();

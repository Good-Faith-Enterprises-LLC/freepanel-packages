/* freePanel held mail (#/tool/held_mail, docs/api.md, "Held mail"): for each mailbox, whether mail from senders who are not allowed is
   kept out of the inbox in its Held folder, how long it waits, who is allowed, and the held messages themselves, which can be released
   (also allowing the sender for good) or deleted. A held message's sender and the reasons come from the server and are shown as text.
   Without the server's filter plugin the page says held mail is not there. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var DAYS = [1, 3, 7, 14, 30, 60];
  var MAX_ALLOW = 500;
  var DOMAIN = '(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]';
  var SENDER_RE = new RegExp('^(?:[a-z0-9._%=-]{1,64})?@' + DOMAIN + '$');
  var ID_RE = /^[0-9][0-9A-Za-z._,=+-]{0,199}$/;
  var STATES = {asked: 'cr_state_asked', quiet: 'cr_state_quiet', 'new': 'cr_state_new'};

  var H = null;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 255) : ''; }
  function whole(v, max) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.min(Math.floor(v), max) : 0; }
  function senders(v) {
    var out = (Array.isArray(v) ? v : []).filter(function (e) { return typeof e === 'string' && SENDER_RE.test(e); });
    return out.filter(function (e, i) { return out.indexOf(e) === i; }).sort().slice(0, MAX_ALLOW);
  }
  function box(b) {
    var h = b.held_box && typeof b.held_box === 'object' ? b.held_box : {};
    var d = whole(h.days, 60);
    return {address: str(b.address), on: h.enabled === true, allow: senders(h.allow), days: d || 14};
  }
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var boxes = (Array.isArray(r.mailboxes) ? r.mailboxes : []).filter(function (b) {
      return b && typeof b.address === 'string' && /^[^@\s]{1,64}@[^@\s]{1,253}$/.test(b.address);
    }).map(box);
    return {on: r.filters_on !== false, boxes: boxes, suspended: r.suspended === true,
      asks: r.held_challenges === true, asksWhy: str(r.held_challenges_why, 300)};
  }
  function messages(r) {
    r = r && typeof r === 'object' ? r : {};
    var list = (Array.isArray(r.messages) ? r.messages : []).filter(function (m) { return m && typeof m.id === 'string' && ID_RE.test(m.id); }).map(function (m) {
      return {id: m.id, sender: str(m.sender, 254), size: whole(m.size, 1e12), at: str(m.held_at, 40), state: STATES[m.state] ? m.state : 'new', reason: str(m.reason, 300),
        opened: m.opened === true};
    });
    return {list: list.slice(0, 1000), more: r.incomplete === true};
  }
  function current() {
    for (var i = 0; i < H.boxes.length; i++) { if (H.boxes[i].address === H.open) { return H.boxes[i]; } }
    return H.boxes[0];
  }

  function dayLabel(d) { return t(d === 1 ? 'cr_day' : 'cr_days', {n: String(d)}); }
  function when(iso) {
    var d = new Date(iso);
    return isNaN(d.getTime()) || d.getFullYear() < 2000 ? '' : d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short', timeZone: 'UTC'});
  }
  function until(iso, days) {
    var d = new Date(iso);
    if (isNaN(d.getTime()) || d.getFullYear() < 2000) { return ''; }
    return new Date(d.getTime() + days * 86400000).toLocaleDateString('en', {dateStyle: 'medium', timeZone: 'UTC'});
  }
  function size(n) {
    if (n < 1024) { return n + ' B'; }
    var units = ['KB', 'MB', 'GB'];
    var v = n / 1024;
    var u = 0;
    while (v >= 1024 && u < units.length - 1) { v /= 1024; u++; }
    return (v < 10 ? v.toFixed(1) : String(Math.round(v))) + ' ' + units[u];
  }

  /* ---------- the box's settings ---------- */
  function settingsCard(b) {
    var on = el('input', {type: 'checkbox', id: 'fp-cr-on', name: 'enabled', checked: b.on ? true : null});
    var days = el('select', {class: 'sig-select', id: 'fp-cr-days', name: 'days'}, (DAYS.indexOf(b.days) >= 0 ? DAYS : DAYS.concat([b.days]).sort(function (a, c) { return a - c; })).map(function (d) {
      return el('option', {value: String(d), selected: d === b.days ? true : null, text: dayLabel(d)});
    }));
    var form = el('form', {class: 'fp-form fp-cr-settings', novalidate: '', 'aria-labelledby': 'fp-cr-set-h'}, [
      el('label', {class: 'fp-check', for: 'fp-cr-on'}, [on, el('span', {text: t('cr_on')})]),
      el('p', {class: 'sig-hint fp-cr-hint', text: t('cr_on_hint')}),
      M.field('fp-cr-days', t('cr_keep'), days, t('cr_keep_hint')),
      M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('cr_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var go = M.start(form);
      if (!go) { return; }
      var mine = H;
      UI.setBusy(go, true);
      FP.call('put', 'mailHeldBox', {enabled: on.checked, days: Number(days.value)}, {name: H.account, address: b.address}).then(function (r) {
        if (H !== mine) { return; }
        UI.setBusy(go, false);
        var got = clean(r).boxes.filter(function (x) { return x.address === b.address; })[0];
        if (got) { b.on = got.on; b.days = got.days; b.allow = got.allow; }
        M.say(form, t(b.on ? 'cr_saved_on' : 'cr_saved_off', {days: dayLabel(b.days)}));
        redrawHeld();
      }, function (err) {
        if (H !== mine) { return; }
        UI.setBusy(go, false);
        M.failed(form, err);
      });
    });
    return M.card('fp-cr-set-h', t('cr_set_title', {address: b.address}), [el('p', {class: 'fp-muted', text: t('cr_what')}), form,
      el('p', {class: 'fp-muted', text: t('cr_note')}),
      /* whether senders are asked to confirm is the server's: when they are not, the page says why */
      el('p', {class: 'fp-muted fp-cr-asks', 'data-fp-cr-asks': H.asks ? 'on' : 'off',
        text: H.asks ? t('cr_asks') : t(H.asksWhy ? 'cr_asks_not' : 'cr_asks_not_why_unknown', {why: H.asksWhy})})], 'fp-cr-set');
  }

  /* ---------- who is allowed ---------- */
  function normal(v) {
    var e = v.trim().toLowerCase();
    return e.indexOf('*@') === 0 ? e.slice(1) : e;
  }
  function saveAllow(b, next, said, focus, onError) {
    var mine = H;
    FP.call('put', 'mailHeldBox', {allow: next}, {name: H.account, address: b.address}).then(function (r) {
      if (H !== mine) { return; }
      var got = clean(r).boxes.filter(function (x) { return x.address === b.address; })[0];
      b.allow = got ? got.allow : next;
      var card = H.page.querySelector('.fp-cr-allow');
      var fresh = allowCard(b);
      H.page.replaceChild(fresh, card);
      M.say(fresh, said);
      (fresh.querySelector(focus) || fresh.querySelector('#fp-cr-allow-h')).focus();
    }, onError);
  }
  function allowCard(b) {
    var input = el('input', {class: 'sig-input sig-mono', id: 'fp-cr-add', name: 'sender', type: 'text', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none',
      inputmode: 'email', placeholder: t('cr_add_placeholder'), 'aria-describedby': 'fp-cr-add-hint'});
    var form = el('form', {class: 'fp-form fp-cr-add', novalidate: ''}, [
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: 'fp-cr-add', text: t('cr_add')}),
        el('div', {class: 'fp-cr-add-row'}, [input, el('button', {class: 'sig-btn sig-btn--secondary fp-submit', type: 'submit', text: t('cr_add_btn')})]),
        el('span', {class: 'sig-hint', id: 'fp-cr-add-hint', text: t('cr_add_hint')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var card = H.page.querySelector('.fp-cr-allow');
      var go = M.start(form);
      if (!go) { return; }
      UI.showError(card, '');
      var v = normal(input.value);
      if (!v) { M.fieldError(card, input, t('cr_sender_none')); return; }
      if (v.split('@')[0].indexOf('+') >= 0) { M.fieldError(card, input, t('cr_sender_tag', {sender: v.replace(/\+[^@]*@/, '@')})); return; }
      if (!SENDER_RE.test(v)) { M.fieldError(card, input, t('cr_sender_bad', {sender: v})); return; }
      if (b.allow.indexOf(v) >= 0) { M.fieldError(card, input, t('cr_sender_there', {sender: v})); return; }
      if (b.allow.length >= MAX_ALLOW) { M.fieldError(card, input, t('cr_sender_full', {n: MAX_ALLOW})); return; }
      UI.setBusy(go, true);
      saveAllow(b, b.allow.concat([v]).sort(), t('cr_added', {sender: v}), '#fp-cr-add', function (err) {
        UI.setBusy(go, false);
        M.fieldError(card, input, err.message);
      });
    });
    var items = b.allow.length ? el('ul', {class: 'fp-cr-list', 'aria-labelledby': 'fp-cr-allow-h'}, b.allow.map(function (e) {
      return el('li', {'data-fp-sender': e}, [el('span', {class: 'sig-mono fp-cr-sender', text: e}),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'cr-remove',
          'aria-label': t('cr_remove_of', {sender: e}), text: t('cr_remove')})]);
    })) : el('p', {class: 'fp-muted', 'data-fp-cr-empty': '', text: t('cr_allow_none')});
    return M.card('fp-cr-allow-h', t('cr_allow_title', {n: b.allow.length}), [el('p', {class: 'fp-muted', text: t('cr_allow_what')}), M.errorLine(), M.statusLine(), items, form], 'fp-cr-allow');
  }

  /* ---------- the held messages ---------- */
  function checks() { return Array.prototype.slice.call(H.page.querySelectorAll('.fp-cr-held input[name="pick"]')); }
  function picked() { return checks().filter(function (c) { return c.checked; }).map(function (c) { return c.value; }); }
  function updateBar() {
    var n = picked().length;
    var bar = H.page.querySelector('.fp-cr-bar');
    if (!bar) { return; }
    bar.querySelector('[data-fp-cr-count]').textContent = n ? t('cr_picked', {n: String(n)}) : t('cr_pick_some');
    Array.prototype.forEach.call(bar.querySelectorAll('button[data-fp-act]'), function (b) { b.disabled = !n; });
    var all = H.page.querySelector('input[name="pick-all"]');
    if (all) { all.checked = n > 0 && n === checks().length; }
  }
  function heldRow(m, b) {
    var pick = el('input', {type: 'checkbox', name: 'pick', value: m.id, 'aria-label': t('cr_pick_of', {sender: m.sender || t('cr_unknown_sender')})});
    pick.addEventListener('change', updateBar);
    var gone = when(m.at) ? t('cr_gone', {date: until(m.at, b.days)}) : '';
    return el('tr', {'data-fp-held': m.id, 'data-fp-state': m.state}, [
      el('td', {class: 'fp-cr-pick'}, [pick]),
      el('th', {scope: 'row', class: 'fp-cr-from'}, [
        el('span', {class: 'fp-cr-sender ' + (m.sender ? 'sig-mono' : 'fp-muted'), text: m.sender || t('cr_unknown_sender')}),
        el('span', {class: 'sig-pill' + (m.state === 'asked' ? ' sig-pill--ok' : ''), text: t(STATES[m.state])}),
        m.reason ? el('span', {class: 'fp-muted fp-cr-reason', text: m.reason}) : null,
        m.opened ? el('span', {class: 'fp-muted fp-cr-reason', text: t('cr_opened')}) : null]),
      el('td', {class: 'fp-cr-when'}, [el('span', {text: when(m.at)}), el('span', {class: 'fp-muted', text: size(m.size)}),
        gone ? el('span', {class: 'fp-muted fp-cr-gone', text: gone}) : null])]);
  }
  function heldCard(b) {
    var parts = [el('p', {class: 'fp-muted', text: t('cr_held_what')}), M.errorLine(), M.statusLine()];
    if (H.held === null) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-cr-loading': '', text: t('loading')}));
    } else if (H.heldError) {
      parts.push(el('div', {class: 'fp-alert is-shown', role: 'alert', 'data-fp-cr-failed': '', text: H.heldError}));
    } else if (!H.held.list.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-cr-none': '', text: t('cr_held_none')}));
    } else {
      var all = el('input', {type: 'checkbox', name: 'pick-all', 'aria-label': t('cr_pick_all')});
      all.addEventListener('change', function () {
        checks().forEach(function (c) { c.checked = all.checked; });
        updateBar();
      });
      parts.push(el('div', {class: 'fp-cr-bar', role: 'group', 'aria-label': t('cr_actions')}, [
        el('span', {class: 'fp-cr-count', 'data-fp-cr-count': '', role: 'status', text: t('cr_pick_some')}),
        el('button', {class: 'sig-btn sig-btn--primary sig-btn--sm', type: 'button', 'data-fp-act': 'cr-release', disabled: true, text: t('cr_release')}),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'cr-release-allow', disabled: true, text: t('cr_release_allow')}),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'cr-delete', disabled: true, text: t('cr_delete')})]));
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-cr-held-h'}, [
        el('table', {class: 'sig-table fp-mail-table fp-cr-table'}, [el('thead', null, [el('tr', null, [
          el('th', {scope: 'col', class: 'fp-cr-pick'}, [all]), el('th', {scope: 'col', text: t('cr_col_from')}), el('th', {scope: 'col', text: t('cr_col_held')})])]),
        el('tbody', null, H.held.list.map(function (m) { return heldRow(m, b); }))])]));
      if (H.held.more) { parts.push(el('p', {class: 'fp-muted', 'data-fp-cr-more': '', text: t('cr_more')})); }
    }
    parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'cr-refresh', text: t('cr_refresh')})]));
    return M.card('fp-cr-held-h', t('cr_held_title', {n: H.held ? H.held.list.length : 0}), parts, 'fp-cr-held');
  }
  function redrawHeld(focus) {
    var card = H.page.querySelector('.fp-cr-held');
    var fresh = heldCard(current());
    if (card) { H.page.replaceChild(fresh, card); } else { H.page.appendChild(fresh); }
    if (focus) { var f = fresh.querySelector(focus); if (f) { f.focus(); } }
    return fresh;
  }
  function loadHeld(said) {
    var b = current();
    var mine = H;
    var open = H.open;
    H.held = null;
    H.heldError = '';
    redrawHeld();
    FP.call('get', 'mailHeld', undefined, {name: H.account, address: b.address}).then(function (r) {
      if (H !== mine || H.open !== open) { return; }
      H.held = messages(r);
      var card = redrawHeld();
      if (said) {
        M.say(card, said);
        card.querySelector('#fp-cr-held-h').focus();
      }
    }, function (err) {
      if (H !== mine || H.open !== open) { return; }
      H.held = {list: [], more: false};
      H.heldError = err.message;
      redrawHeld();
    });
  }
  /* what became of the messages asked about: the words say how many went and how many did not */
  function outcome(res, ids, allowed) {
    var done = ids.filter(function (id) { return res && res.results && res.results[id] === 'done'; }).length;
    var left = ids.length - done;
    return {done: done, left: left, allowed: Array.isArray(allowed) ? senders(allowed) : []};
  }
  function act(kind) {
    var ids = picked();
    if (!ids.length) { return; }
    var b = current();
    var card = H.page.querySelector('.fp-cr-held');
    var mine = H;
    var open = H.open;
    var bar = card.querySelector('.fp-cr-bar');
    var buttons = Array.prototype.slice.call(bar.querySelectorAll('button'));
    UI.showError(card, '');
    M.say(card, '');
    buttons.forEach(function (x) { x.disabled = true; });
    var route = kind === 'delete' ? 'mailHeldDelete' : 'mailHeldRelease';
    var body = kind === 'delete' ? {ids: ids} : {ids: ids, allow: kind === 'release-allow'};
    FP.call('post', route, body, {name: H.account, address: b.address}).then(function (r) {
      if (H !== mine || H.open !== open) { return; }
      var o = outcome(r, ids, r && r.allowed);
      if (o.allowed.length) {
        b.allow = senders(b.allow.concat(o.allowed));
        var old = H.page.querySelector('.fp-cr-allow');
        H.page.replaceChild(allowCard(b), old);
      }
      var said = kind === 'delete' ? t('cr_deleted', {n: String(o.done)}) : t('cr_released', {n: String(o.done)});
      if (o.left) { said += ' ' + t('cr_left', {n: String(o.left)}); }
      if (o.allowed.length) { said += ' ' + t('cr_now_allowed', {n: String(o.allowed.length)}); }
      loadHeld(said);
    }, function (err) {
      if (H !== mine || H.open !== open) { return; }
      updateBar();
      UI.showError(card, err.message);
    });
  }
  function askDelete() {
    var n = picked().length;
    if (!n) { return; }
    var bar = H.page.querySelector('.fp-cr-bar');
    var yes = el('button', {class: 'sig-btn sig-btn--danger sig-btn--sm', type: 'button', 'data-fp-act': 'cr-delete-yes', text: t('cr_delete_yes')});
    var no = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'cr-delete-no', text: t('cancel')});
    var q = el('span', {class: 'fp-cr-ask', id: 'fp-cr-ask', role: 'alert', text: t('cr_delete_ask', {n: String(n)})});
    yes.setAttribute('aria-describedby', 'fp-cr-ask');
    no.setAttribute('aria-describedby', 'fp-cr-ask');
    bar.setAttribute('data-fp-asking', '');
    bar.textContent = '';
    bar.appendChild(q);
    bar.appendChild(yes);
    bar.appendChild(no);
    no.focus();
  }
  function cancelDelete() {
    var picks = picked();
    var fresh = redrawHeld();
    checks().forEach(function (c) { c.checked = picks.indexOf(c.value) >= 0; });
    updateBar();
    var b = fresh.querySelector('[data-fp-act="cr-delete"]');
    if (b) { b.focus(); }
  }

  function onClick(e) {
    var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !H || !H.page || !H.page.contains(b)) { return; }
    var a = b.getAttribute('data-fp-act');
    if (a === 'cr-remove') {
      var li = b.closest('[data-fp-sender]');
      var gone = li.getAttribute('data-fp-sender');
      var box = current();
      var card = H.page.querySelector('.fp-cr-allow');
      var next = box.allow.filter(function (x) { return x !== gone; });
      var after = next[Math.min(box.allow.indexOf(gone), next.length - 1)];
      UI.showError(card, '');
      UI.setBusy(b, true);
      saveAllow(box, next, t('cr_removed', {sender: gone}), after ? '[data-fp-sender="' + window.CSS.escape(after) + '"] [data-fp-act="cr-remove"]' : '#fp-cr-allow-h', function (err) {
        UI.setBusy(b, false);
        UI.showError(card, err.message);
        b.focus();
      });
    } else if (a === 'cr-release') { act('release'); }
    else if (a === 'cr-release-allow') { act('release-allow'); }
    else if (a === 'cr-delete') { askDelete(); }
    else if (a === 'cr-delete-yes') { act('delete'); }
    else if (a === 'cr-delete-no') { cancelDelete(); }
    else if (a === 'cr-refresh') { loadHeld(); }
  }

  function picker() {
    if (H.boxes.length < 2) { return null; }
    var sel = el('select', {class: 'sig-select', id: 'fp-cr-box', name: 'mailbox'}, H.boxes.map(function (b) {
      return el('option', {value: b.address, selected: b.address === H.open ? true : null, text: b.address});
    }));
    sel.addEventListener('change', function () {
      H.open = sel.value;
      draw();
      loadHeld();
      var f = H.page.querySelector('#fp-cr-box');
      if (f) { f.focus(); }
    });
    return el('div', {class: 'sig-field fp-cr-pick-box'}, [el('label', {class: 'sig-label', for: 'fp-cr-box', text: t('cr_mailbox')}), sel]);
  }
  function draw() {
    var page = H.page;
    page.textContent = '';
    var tool = FP.tools.held_mail;
    if (H.suspended) { page.appendChild(M.suspendedBanner(t('mail_suspended'))); }
    if (!H.on) { page.appendChild(FP.empty(tool.label, t('cr_unavailable'))); return; }
    if (!H.boxes.length) { page.appendChild(FP.empty(tool.label, t('cr_no_boxes'))); return; }
    var b = current();
    H.open = b.address;
    var pick = picker();
    if (pick) { page.appendChild(pick); }
    page.appendChild(settingsCard(b));
    page.appendChild(allowCard(b));
    page.appendChild(heldCard(b));
  }
  FP.view('tool:held_mail', function () {
    H = null;
    var tool = FP.tools.held_mail;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('held_mail_desc'), cls: 'fp-mail fp-cr-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    H = {page: page, account: FP.account(), on: true, boxes: [], open: '', held: null, heldError: '', suspended: false, asks: false, asksWhy: ''};
    var mine = H;
    page.addEventListener('click', onClick);
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'mail', undefined, H.account).then(function (r) {
      if (H !== mine) { return; }
      var c = clean(r);
      H.on = c.on; H.boxes = c.boxes; H.suspended = c.suspended; H.asks = c.asks; H.asksWhy = c.asksWhy;
      draw();
      if (H.on && H.boxes.length) { loadHeld(); }
    }, function (err) {
      if (H !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

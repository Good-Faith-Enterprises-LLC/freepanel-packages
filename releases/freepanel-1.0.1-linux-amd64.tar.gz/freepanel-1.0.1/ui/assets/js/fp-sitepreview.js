/* freePanel site preview (docs/api.md, "Preview a site before DNS points here"): the customer panel's page (#/tool/site_preview) for looking at a domain's
   site before its DNS leads to this server. It asks this server's web server as a visitor of that name would (status, redirect, the page's title,
   the certificate and how far a browser would trust it), asks the resolvers whether the name leads here yet, and gives the hosts-file lines and a
   curl command to look at the site from the customer's own computer. It changes nothing. The server limits it to 10 a minute for an account and
   shows its own words. Everything the server sends is shown as text. The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var DOMAIN_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var IP_RE = /^[0-9A-Fa-f:.]{2,45}$/;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  /* the server's words as a sentence: "the web server did not answer in time" becomes "The web server did not answer in time." */
  function said(s) { s = s.trim(); return s ? s.charAt(0).toUpperCase() + s.slice(1) + (/[.!?]$/.test(s) ? '' : '.') : s; }
  function whole(v) { return typeof v === 'number' && isFinite(v) && v >= 0 && Math.floor(v) === v ? v : null; }
  function ips(v) { return (Array.isArray(v) ? v : []).filter(function (a) { return typeof a === 'string' && IP_RE.test(a); }).slice(0, 20); }
  function when(v) {
    if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}T/.test(v)) { return ''; }
    var d = new Date(v);
    return isNaN(d.getTime()) ? '' : d.toLocaleDateString('en', {dateStyle: 'medium'});
  }
  function cert(c) {
    if (!c || typeof c !== 'object') { return null; }
    return {subject: str(c.subject, 300), issuer: str(c.issuer, 300), names: (Array.isArray(c.names) ? c.names : []).filter(function (n) { return typeof n === 'string'; }).map(function (n) { return n.slice(0, 253); }).slice(0, 20),
      notAfter: when(c.not_after), self: c.self_signed === true, covers: c.covers_domain === true, trusted: c.trusted === true};
  }
  function clean(v) {
    v = v && typeof v === 'object' ? v : {};
    var d = v.dns && typeof v.dns === 'object' ? v.dns : {};
    var h = v.https && typeof v.https === 'object' ? v.https : {};
    var p = v.http && typeof v.http === 'object' ? v.http : {};
    return {domain: str(v.domain, 253), addresses: ips(v.addresses),
      dns: {checked: d.checked === true, error: str(d.error, 300), resolves: ips(d.resolves_to), here: d.points_here === true, wwwResolves: ips(d.www_resolves_to), wwwHere: d.www_points_here === true},
      https: {reachable: h.reachable === true, status: whole(h.status), type: str(h.content_type, 100), title: str(h.title, 300), ms: whole(h.ms), error: str(h.error, 300), cert: cert(h.certificate)},
      http: {reachable: p.reachable === true, status: whole(p.status), to: str(p.redirects_to, 600), error: str(p.error, 300)},
      hosts: (Array.isArray(v.hosts_file) ? v.hosts_file : []).filter(function (l) { return typeof l === 'string' && l; }).map(function (l) { return l.slice(0, 400); }).slice(0, 4), curl: str(v.curl, 1000)};
  }
  function domainsOf(v) {
    var out = [];
    (v && Array.isArray(v.sites) ? v.sites : []).forEach(function (s) {
      [s && s.domain].concat(s && Array.isArray(s.aliases) ? s.aliases : []).forEach(function (d) {
        if (typeof d === 'string' && DOMAIN_RE.test(d) && out.indexOf(d) < 0) { out.push(d); }
      });
    });
    return out.sort();
  }

  var P = {page: null, account: '', domains: [], busy: false, out: null};

  function pill(ok, yes, no) { return el('span', {class: 'sig-pill ' + (ok ? 'sig-pill--ok' : 'sig-pill--warn'), text: ok ? yes : no}); }
  function fact(label, children, attr) { return el('div', {}, [el('dt', {text: label}), el('dd', attr || {}, Array.isArray(children) ? children : [children])]); }
  function leads(v) {
    var d = v.dns;
    if (!d.checked) { return [el('span', {class: 'fp-muted', text: d.error ? said(d.error) : t('spv_dns_unchecked')})]; }
    var out = [];
    [['spv_name_main', d.here, d.resolves], ['spv_name_www', d.wwwHere, d.wwwResolves]].forEach(function (row) {
      out.push(el('div', {class: 'fp-spv-lead', 'data-fp-leads': row[0] === 'spv_name_www' ? 'www' : 'main'}, [el('strong', {text: t(row[0], {name: v.domain})}), ' ',
        pill(row[1], t('spv_here'), t('spv_not_here')), ' ', el('span', {class: 'fp-muted sig-mono', text: row[2].length ? row[2].join(', ') : t('spv_no_address')})]));
    });
    return out;
  }
  function certFacts(c) {
    if (!c) { return [fact(t('spv_cert'), t('spv_cert_none'))]; }
    var trust = c.trusted ? t('spv_cert_trusted') : c.self ? t('spv_cert_self') : t('spv_cert_untrusted');
    var rows = [fact(t('spv_cert'), [pill(c.trusted && c.covers, t('spv_cert_ok'), trust), ' ', el('span', {text: c.covers ? t('spv_cert_covers') : t('spv_cert_not_covers')})], {'data-fp-cert': c.trusted ? 'trusted' : 'no', class: 'fp-spv-flow'})];
    if (c.names.length) { rows.push(fact(t('spv_cert_names'), el('span', {class: 'sig-mono', text: c.names.join(', ')}))); }
    if (c.issuer) { rows.push(fact(t('spv_cert_issuer'), c.issuer)); }
    if (c.notAfter) { rows.push(fact(t('spv_cert_until'), c.notAfter)); }
    return rows;
  }
  function visitor(v) {
    var h = v.https;
    var p = v.http;
    var facts = [];
    facts.push(fact(t('spv_https'), h.reachable ? [pill(h.status !== null && h.status < 400, t('spv_status', {status: h.status === null ? '?' : h.status}), t('spv_status', {status: h.status === null ? '?' : h.status})),
      h.type ? ' ' + h.type : '', h.ms !== null ? ' · ' + t('spv_ms', {ms: h.ms}) : ''] : [el('span', {class: 'fp-spv-bad', text: h.error ? said(h.error) : t('spv_unreachable')})], {'data-fp-https': h.reachable ? 'up' : 'down'}));
    if (h.reachable && h.title) { facts.push(fact(t('spv_page_title'), el('span', {'data-fp-title': '', text: h.title}))); }
    facts = facts.concat(h.reachable || h.cert ? certFacts(h.cert) : []);
    facts.push(fact(t('spv_http'), p.reachable ? [t('spv_status', {status: p.status === null ? '?' : p.status}), p.to ? ' → ' : '', p.to ? el('span', {class: 'sig-mono', 'data-fp-redirect': '', text: p.to}) : ''] :
      [el('span', {class: 'fp-spv-bad', text: p.error ? said(p.error) : t('spv_unreachable')})], {'data-fp-http': p.reachable ? 'up' : 'down'}));
    return el('dl', {class: 'fp-spv-facts'}, facts);
  }
  function snippet(label, lines, id) {
    return el('div', {class: 'fp-spv-snip'}, [el('p', {class: 'fp-spv-snip-h', id: id + '-h', text: label}), el('pre', {class: 'sig-mono fp-spv-code', id: id, tabindex: '0', 'aria-labelledby': id + '-h', text: lines.join('\n')})]);
  }
  function show(v) {
    P.out.textContent = '';
    var head = el('h2', {class: 'fp-h2 fp-spv-asked', id: 'fp-spv-asked', tabindex: '-1', 'data-fp-asked': '', text: t('spv_asked', {domain: v.domain})});
    P.out.appendChild(head);
    P.out.appendChild(M.card('fp-spv-dns-h', t('spv_dns_title'), [el('p', {class: 'fp-muted', text: t('spv_dns_what', {addresses: v.addresses.join(', ') || t('spv_no_address')})}), el('div', {'data-fp-dns': ''}, leads(v))], 'fp-spv-card'));
    P.out.appendChild(M.card('fp-spv-visitor-h', t('spv_visitor_title'), [el('p', {class: 'fp-muted', text: t('spv_visitor_what')}), visitor(v)], 'fp-spv-card'));
    var parts = [el('p', {class: 'fp-muted', text: t('spv_own_what')})];
    if (v.hosts.length) { parts.push(snippet(t('spv_hosts'), v.hosts, 'fp-spv-hosts')); }
    if (v.curl) { parts.push(snippet(t('spv_curl'), [v.curl], 'fp-spv-curl')); }
    if (v.hosts.length) { parts.push(el('p', {class: 'fp-muted', text: t('spv_own_after')})); }
    P.out.appendChild(M.card('fp-spv-own-h', t('spv_own_title'), parts, 'fp-spv-card fp-spv-own'));
    head.focus();
  }

  function form() {
    var sel = el('select', {class: 'sig-select', id: 'fp-spv-domain', name: 'domain'}, P.domains.map(function (d) { return el('option', {value: d, text: d}); }));
    var f = el('form', {class: 'fp-form fp-spv-form', novalidate: ''}, [M.errorLine(), M.field('fp-spv-domain', t('spv_domain'), sel, t('spv_domain_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('spv_check')})])]);
    f.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(f);
      if (!b || P.busy) { return; }
      var domain = sel.value;
      if (!DOMAIN_RE.test(domain)) { M.fieldError(f, sel, t('spv_pick')); return; }
      P.busy = true;
      UI.setBusy(b, true);
      var mine = P.page;
      FP.call('get', 'domainPreview', undefined, {name: P.account, domain: domain}).then(function (r) {
        P.busy = false;
        if (P.page !== mine) { return; }
        UI.setBusy(b, false);
        var v = clean(r);
        if (!v.domain) { v.domain = domain; }
        show(v);
      }, function (err) {
        P.busy = false;
        if (P.page !== mine) { return; }
        UI.setBusy(b, false);
        M.failed(f, err);
      });
    });
    return f;
  }

  FP.view('tool:site_preview', function () {
    var tool = FP.tools.site_preview;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    P.busy = false;
    P.domains = [];
    P.account = FP.account();
    var body = FP.frame({title: tool.label, desc: t('spv_desc'), cls: 'fp-mail fp-spv-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    P.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'domains', undefined, P.account).then(function (r) {
      if (P.page !== body) { return; }
      P.domains = domainsOf(r);
      body.textContent = '';
      var parts = [el('p', {class: 'fp-muted', text: t('spv_what')})];
      parts.push(P.domains.length ? form() : el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('spv_none')}));
      body.appendChild(M.card('fp-spv-ask-h', t('spv_title'), parts, 'fp-spv-ask'));
      P.out = el('div', {class: 'fp-spv-out', role: 'region', 'aria-label': t('spv_results'), 'data-fp-out': ''});
      body.appendChild(P.out);
    }, function (err) {
      if (P.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

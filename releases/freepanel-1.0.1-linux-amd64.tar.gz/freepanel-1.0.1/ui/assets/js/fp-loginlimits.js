/* freePanel sign-in limits in the admin panel (docs/api.md, "Sign-in limits"): #/tool/login_limits sets how many wrong passwords
   lock a login name and a client address, and for how long, keeps the list of addresses the address counter skips, and lists
   the names and addresses that are locked now, each with a way to unlock it. Admin only: the server refuses these calls to
   anyone else.
   Names, addresses, notes and the server's warning come from the server and are shown as text. The pieces of a page come
   from FP.mail (fp-mail.js); a change redraws the card it touches and leaves a form the admin is typing in alone. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var UNITS = [['seconds', 1], ['minutes', 60], ['hours', 3600], ['days', 86400]];
  var WINDOW = [60, 86400];
  /* the two counters: the field's prefix in the API, and how many attempts it allows (docs/api.md has the same bounds) */
  var COUNTERS = [{key: 'user', max: [3, 100], title: 'll_user_title', what: 'll_user_what'}, {key: 'ip', max: [5, 1000], title: 'll_ip_title', what: 'll_ip_what'}];
  var DEFAULTS = {user: {max: 10, window: 900}, ip: {max: 30, window: 900}};
  /* an address or a range, as the server keeps it: hex digits, dots, colons and one slash with a prefix length */
  var TARGET_RE = /^[0-9A-Fa-f:.]{2,45}(?:\/[0-9]{1,3})?$/;
  var MAX_EXEMPT = 100;
  var KINDS = {user: 'll_kind_user', address: 'll_kind_address'};

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 200) : ''; }
  function whole(v) { return typeof v === 'number' && isFinite(v) && v >= 0 && Math.floor(v) === v ? v : null; }
  /* the biggest unit that divides the length without a rest */
  function unitOf(seconds) {
    for (var i = UNITS.length - 1; i > 0; i--) { if (seconds % UNITS[i][1] === 0) { return i; } }
    return 0;
  }
  function duration(seconds) {
    var u = UNITS[unitOf(seconds)];
    var n = seconds / u[1];
    return t('lp_dur_' + u[0] + (n === 1 ? '_1' : ''), {n: n.toLocaleString('en')});
  }

  function when(iso) {
    var d = new Date(str(iso, 40));
    return isNaN(d.getTime()) ? '' : d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'});
  }
  function cleanEntry(x) {
    if (!x || !TARGET_RE.test(str(x.target, 64))) { return null; }
    return {target: x.target, note: str(x.note, 200), added: str(x.added, 40), by: str(x.by, 64)};
  }
  /* the locked list, newest lock first as the server sends it; a name is whatever was typed at a sign-in form, so it is only ever text */
  function cleanLocked(r) {
    return (r && Array.isArray(r.locked) ? r.locked : []).filter(function (x) {
      return x && KINDS[x.kind] && typeof x.name === 'string' && x.name && x.name.length <= 200 && !/[\u0000-\u001f\u007f]/.test(x.name); // eslint-disable-line no-control-regex -- control characters are not shown
    }).map(function (x) { return {kind: x.kind, name: x.name, count: whole(x.count) || 0, until: str(x.locked_until, 40)}; });
  }
  function cleanLimit(v, d) {
    v = v && typeof v === 'object' ? v : {};
    return {max: whole(v.max) || d.max, window: whole(v.window_seconds) || d.window};
  }
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var d = r.defaults && typeof r.defaults === 'object' ? r.defaults : {};
    var defaults = {user: cleanLimit(d.user, DEFAULTS.user), ip: cleanLimit(d.ip, DEFAULTS.ip)};
    return {user: cleanLimit(r.user, defaults.user), ip: cleanLimit(r.ip, defaults.ip), defaults: defaults, warning: str(r.warning, 400),
      exempt: (Array.isArray(r.exempt) ? r.exempt : []).map(cleanEntry).filter(Boolean)};
  }

  /* ---- the page's cards ---- */
  var page = null;
  var LL = null;       /* the server's reply, cleaned */
  var warning = '';    /* what the server said about the numbers when they were last saved */
  var locked = null;   /* what is locked now, or null when the list can't be had */
  var CARDS = {settings: function () { return settingsCard(); }, exempt: function () { return exemptCard(); }, locked: function () { return lockedCard(); }};
  var ORDER = ['settings', 'exempt', 'locked'];

  function banner(text, attr) {
    var b = el('div', {class: 'sig-banner sig-banner--warn', role: 'note'}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: text})]);
    b.setAttribute(attr, '');
    return b;
  }

  /* ---- the counters ---- */
  function windowField(c, seconds) {
    var id = 'fp-ll-' + c.key + '-window';
    var u = unitOf(seconds);
    var number = el('input', {class: 'sig-input fp-num-input', id: id, name: c.key + '.window_seconds', type: 'number', inputmode: 'numeric', min: '1', step: '1',
      value: String(seconds / UNITS[u][1]), 'aria-describedby': id + '-hint'});
    var select = el('select', {class: 'sig-select fp-lp-unit', id: id + '-unit', 'data-fp-unit': c.key, 'aria-label': t('lp_unit_of', {field: t('ll_window')})},
      UNITS.map(function (un, i) { return el('option', {value: String(un[1]), selected: i === u ? true : null, text: t('lp_dur_' + un[0]).replace('{n} ', '')}); }));
    return el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: id, text: t('ll_window')}),
      el('div', {class: 'fp-lp-time'}, [number, select]),
      el('span', {class: 'sig-hint', id: id + '-hint', text: t('ll_window_hint', {min: duration(WINDOW[0]), max: duration(WINDOW[1])})})]);
  }
  function counterGroup(c) {
    var id = 'fp-ll-' + c.key;
    var d = LL.defaults[c.key];
    var max = el('input', {class: 'sig-input fp-num-input', id: id + '-max', name: c.key + '.max', type: 'number', inputmode: 'numeric', min: String(c.max[0]),
      max: String(c.max[1]), step: '1', value: String(LL[c.key].max), 'aria-describedby': id + '-max-hint'});
    return el('div', {class: 'fp-ll-counter', role: 'group', 'aria-labelledby': id + '-h', 'data-fp-counter': c.key}, [
      el('h3', {class: 'fp-h3', id: id + '-h', text: t(c.title)}), el('p', {class: 'fp-muted', text: t(c.what)}),
      M.field(id + '-max', t('ll_attempts'), max, t('ll_attempts_hint', {min: c.max[0], max: c.max[1], shipped: d.max, window: duration(d.window)})),
      windowField(c, LL[c.key].window)]);
  }
  function settingsCard() {
    var form = el('form', {class: 'fp-form fp-ll-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-ll-counters'}, COUNTERS.map(counterGroup)),
      el('div', {class: 'fp-actions'}, [
        el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('ll_save')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'shipped', text: t('ll_shipped')})])]);

    /* every field is read and checked here; the server checks them again */
    function read() {
      var body = {};
      for (var i = 0; i < COUNTERS.length; i++) {
        var c = COUNTERS[i];
        var maxIn = form.querySelector('[name="' + c.key + '.max"]');
        var v = maxIn.value.trim();
        if (!/^[0-9]{1,5}$/.test(v) || Number(v) < c.max[0] || Number(v) > c.max[1]) { M.fieldError(form, maxIn, t('ll_bad_attempts', {min: c.max[0], max: c.max[1]})); return null; }
        var winIn = form.querySelector('[name="' + c.key + '.window_seconds"]');
        var n = winIn.value.trim();
        if (!/^[0-9]{1,9}$/.test(n)) { M.fieldError(form, winIn, t('ll_bad_number')); return null; }
        var seconds = Number(n) * Number(form.querySelector('[data-fp-unit="' + c.key + '"]').value);
        if (seconds < WINDOW[0] || seconds > WINDOW[1]) { M.fieldError(form, winIn, t('ll_bad_window', {min: duration(WINDOW[0]), max: duration(WINDOW[1])})); return null; }
        body[c.key] = {max: Number(v), window_seconds: seconds};
      }
      return body;
    }
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var body = read();
      if (!body) { return; }
      var mine = page;
      UI.setBusy(b, true);
      FP.call('put', 'loginLimits', body).then(function (r) {
        if (page !== mine) { return; }
        LL = clean(r);
        warning = LL.warning;
        /* a new number locks or frees names at once: the list is read again; a failed look leaves it as it was */
        return FP.call('get', 'loginLimitsLocked').then(function (x) { locked = cleanLocked(x); }, function () { return null; }).then(function () {
          if (page !== mine) { return; }
          draw(['settings', 'locked'], {say: ['settings', t('ll_saved')], focus: '#fp-ll-user-max'});
        });
      }, function (err) {
        if (page !== mine) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    /* the shipped numbers go into the fields; nothing is sent until the admin saves */
    form.querySelector('[data-fp-act="shipped"]').addEventListener('click', function () {
      M.start(form);
      COUNTERS.forEach(function (c) {
        var d = LL.defaults[c.key];
        var u = unitOf(d.window);
        form.querySelector('[name="' + c.key + '.max"]').value = String(d.max);
        form.querySelector('[name="' + c.key + '.window_seconds"]').value = String(d.window / UNITS[u][1]);
        form.querySelector('[data-fp-unit="' + c.key + '"]').value = String(UNITS[u][1]);
      });
      M.say(form, t('ll_shipped_filled'));
    });
    var parts = [el('p', {class: 'fp-muted', text: t('ll_settings_what')})];
    var low = warning || (LL.user.max < 5 ? t('ll_low') : '');
    if (low) { parts.push(banner(low, 'data-fp-ll-warning')); }
    parts.push(form);
    return M.card('fp-ll-settings-h', t('ll_settings_title'), parts, 'fp-ll-settings');
  }

  /* ---- the addresses the address counter skips ---- */
  function entryItem(e) {
    var added = when(e.added);
    return el('li', {class: 'fp-ll-item', 'data-fp-target': e.target}, [
      el('span', {class: 'sig-mono fp-ll-name', text: e.target}),
      el('span', {class: 'fp-ll-note' + (e.note ? '' : ' fp-muted'), text: e.note || t('ll_ex_no_note')}),
      el('span', {class: 'fp-muted fp-ll-meta', text: added ? t(e.by ? 'll_ex_meta' : 'll_ex_meta_anon', {when: added, by: e.by}) : ''}),
      el('div', {class: 'fp-ll-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'ex-remove',
        'aria-label': t('ll_ex_remove_of', {target: e.target}), text: t('ll_ex_remove')})])]);
  }
  function exemptForm() {
    var target = el('input', {class: 'sig-input sig-mono', id: 'fp-ll-ex-target', name: 'target', type: 'text', autocomplete: 'off', spellcheck: 'false',
      autocapitalize: 'none', maxlength: '64'});
    var note = el('input', {class: 'sig-input', id: 'fp-ll-ex-note', name: 'note', type: 'text', autocomplete: 'off', maxlength: '200'});
    var form = el('form', {class: 'fp-form fp-ll-addform', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-ll-fields'}, [M.field('fp-ll-ex-target', t('ll_ex_target'), target, t('ll_ex_target_hint')),
        M.field('fp-ll-ex-note', t('ll_ex_note'), note, t('ll_ex_note_hint'))]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('ll_ex_add')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var v = target.value.trim();
      if (!TARGET_RE.test(v)) { M.fieldError(form, target, t('ll_ex_bad_target')); return; }
      var body = {target: v};
      var n = note.value.trim();
      if (n) { body.note = n; }
      var mine = page;
      UI.setBusy(b, true);
      FP.call('post', 'loginLimitsExempt', body).then(function (r) {
        if (page !== mine) { return; }
        LL = clean(r);
        draw(['exempt'], {say: ['exempt', t('ll_ex_added', {target: v})], focus: '#fp-ll-ex-target'});
      }, function (err) {
        if (page !== mine) { return; }
        UI.setBusy(b, false);
        /* a refusal that names no field (already on the list, the list is full) is about the address */
        if (err && !err.field && err.status === 409) { M.fieldError(form, target, err.message); } else { M.failed(form, err); }
      });
    });
    return form;
  }
  function exemptCard() {
    var parts = [el('p', {class: 'fp-muted', text: t('ll_exempt_what', {max: MAX_EXEMPT})}), exemptForm()];
    if (!LL.exempt.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': 'exempt', text: t('ll_ex_none')}));
    } else {
      parts.push(el('p', {class: 'fp-muted fp-ll-count', 'data-fp-count': 'exempt', text: t(LL.exempt.length === 1 ? 'll_ex_count_1' : 'll_ex_count', {n: LL.exempt.length, max: MAX_EXEMPT})}));
      parts.push(el('ul', {class: 'fp-ll-list', 'aria-labelledby': 'fp-ll-exempt-h'}, LL.exempt.map(entryItem)));
    }
    return M.card('fp-ll-exempt-h', t('ll_exempt_title'), parts, 'fp-ll-exempt');
  }

  /* ---- what is locked now ---- */
  function lockedItem(l) {
    var until = when(l.until);
    return el('li', {class: 'fp-ll-item', 'data-fp-kind': l.kind, 'data-fp-name': l.name}, [
      el('span', {class: 'fp-ll-kind'}, [el('span', {class: 'sig-pill sig-pill--warn', text: t(KINDS[l.kind])})]),
      el('span', {class: 'sig-mono fp-ll-name', text: l.name}),
      el('span', {class: 'fp-ll-note', text: t(l.count === 1 ? 'll_lk_count_1' : 'll_lk_count', {n: l.count.toLocaleString('en')})}),
      el('span', {class: 'fp-muted fp-ll-meta', text: until ? t('ll_lk_until', {when: until}) : ''}),
      el('div', {class: 'fp-ll-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'unlock',
        'aria-label': t(l.kind === 'user' ? 'll_lk_unlock_user' : 'll_lk_unlock_address', {name: l.name}), text: t('ll_lk_unlock')})])]);
  }
  function lockedCard() {
    var parts = [el('p', {class: 'fp-muted', text: t('ll_locked_what')}), M.errorLine(), M.statusLine()];
    if (locked === null) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': 'locked-failed', text: t('ll_lk_failed')}));
    } else if (!locked.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': 'locked', text: t('ll_lk_none')}));
    } else {
      parts.push(el('ul', {class: 'fp-ll-list', 'aria-labelledby': 'fp-ll-locked-h'}, locked.map(lockedItem)));
    }
    parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'look',
      text: t(locked === null ? 'sec_try_again' : 'sec_look_again')})]));
    return M.card('fp-ll-locked-h', t('ll_locked_title'), parts, 'fp-ll-locked');
  }

  /* ---- drawing ---- */
  function build(name) {
    var node = CARDS[name]();
    node.setAttribute('data-fp-card', name);
    return node;
  }
  function drawAll() {
    page.textContent = '';
    ORDER.forEach(function (name) { page.appendChild(build(name)); });
  }
  /* redraws the cards named; opts.say is [card, text] for that card's status line, opts.focus a selector for the control that takes focus */
  function draw(names, opts) {
    opts = opts || {};
    names.forEach(function (name) {
      var old = page.querySelector('[data-fp-card="' + name + '"]');
      if (old) { old.replaceWith(build(name)); }
    });
    if (opts.say) { M.say(page.querySelector('[data-fp-card="' + opts.say[0] + '"]'), opts.say[1]); }
    var target = opts.focus ? page.querySelector(opts.focus) : null;
    if (target) { target.focus(); }
  }

  function entryOf(target) {
    for (var i = 0; i < LL.exempt.length; i++) { if (LL.exempt[i].target === target) { return LL.exempt[i]; } }
    return null;
  }
  function removeButton(target) { return 'li[data-fp-target="' + window.CSS.escape(target) + '"] [data-fp-act="ex-remove"]'; }
  function lockedBy(kind, name) {
    for (var i = 0; i < locked.length; i++) { if (locked[i].kind === kind && locked[i].name === name) { return i; } }
    return -1;
  }
  function unlockButton(l) {
    return 'li[data-fp-kind="' + l.kind + '"][data-fp-name="' + window.CSS.escape(l.name) + '"] [data-fp-act="unlock"]';
  }
  function onLocked(b, a, mine) {
    var lockedCardNode = function () { return page.querySelector('[data-fp-card="locked"]'); };
    if (a === 'look') {
      UI.setBusy(b, true);
      FP.call('get', 'loginLimitsLocked').then(function (x) {
        if (page !== mine) { return; }
        locked = cleanLocked(x);
        draw(['locked'], {say: ['locked', t('ll_lk_up_to_date')], focus: '[data-fp-card="locked"] [data-fp-act="look"]'});
      }, function (err) {
        if (page !== mine) { return; }
        UI.setBusy(b, false);
        UI.showError(lockedCardNode(), err.message);
        b.focus();
      });
      return;
    }
    var li = b.closest('li[data-fp-name]');
    var i = li ? lockedBy(li.getAttribute('data-fp-kind'), li.getAttribute('data-fp-name')) : -1;
    if (a !== 'unlock' || i < 0) { return; }
    var l = locked[i];
    var params = {};
    params[l.kind] = l.name;
    UI.setBusy(b, true);
    FP.call('del', l.kind === 'user' ? 'loginLimitsUnlockUser' : 'loginLimitsUnlockAddress', undefined, params).then(function (r) {
      if (page !== mine) { return; }
      locked = cleanLocked(r);
      var next = locked[Math.min(i, locked.length - 1)];
      draw(['locked'], {say: ['locked', t('ll_lk_unlocked', {name: l.name})], focus: next ? unlockButton(next) : '#fp-ll-locked-h'});
    }, function (err) {
      if (page !== mine) { return; }
      if (err && err.status === 404) {
        /* already empty (the window ran out, or another admin unlocked it): the row goes, and the server's words say so */
        locked = locked.filter(function (x) { return x !== l; });
        draw(['locked'], {focus: '#fp-ll-locked-h'});
      } else {
        UI.setBusy(b, false);
        b.focus();
      }
      UI.showError(lockedCardNode(), err.message);
    });
  }
  function onClick(e) {
    var node = e.target.closest ? e.target : null;
    var b = node && node.closest('[data-fp-act]');
    if (!b || !page || !page.contains(b) || !LL) { return; }
    var a = b.getAttribute('data-fp-act');
    var mine = page;
    if (b.closest('[data-fp-card="locked"]')) { onLocked(b, a, mine); return; }
    var li = b.closest('li[data-fp-target]');
    var entry = li ? entryOf(li.getAttribute('data-fp-target')) : null;
    if (a === 'ex-remove' && entry) {
      M.confirmIn(li.querySelector('.fp-ll-acts'), t('ll_ex_ask', {target: entry.target}), 'ex-yes', t('ll_ex_remove'));
    } else if (a === 'confirm-no' && entry) {
      /* the row alone is put back, so what is typed in the form above stays */
      var again = entryItem(entry);
      li.replaceWith(again);
      again.querySelector('[data-fp-act="ex-remove"]').focus();
    } else if (a === 'ex-yes' && entry) {
      var index = LL.exempt.indexOf(entry);
      UI.setBusy(b, true);
      FP.call('del', 'loginLimitsExemptEntry', undefined, {target: entry.target}).then(function (r) {
        if (page !== mine) { return; }
        LL = clean(r);
        var next = LL.exempt[Math.min(index, LL.exempt.length - 1)];
        draw(['exempt'], {say: ['exempt', t('ll_ex_removed', {target: entry.target})], focus: next ? removeButton(next.target) : '#fp-ll-ex-target'});
      }, function (err) {
        if (page !== mine) { return; }
        if (err && err.status === 404) {
          /* gone already: the row goes, and the server's words say so */
          LL.exempt = LL.exempt.filter(function (x) { return x.target !== entry.target; });
          draw(['exempt'], {focus: '#fp-ll-ex-target'});
          UI.showError(page.querySelector('[data-fp-card="exempt"]'), err.message);
          return;
        }
        var back = entryItem(entry);
        li.replaceWith(back);
        back.querySelector('[data-fp-act="ex-remove"]').focus();
        UI.showError(page.querySelector('[data-fp-card="exempt"]'), err.message);
      });
    }
  }
  document.addEventListener('click', onClick);

  FP.view('tool:login_limits', function () {
    var tool = FP.tools.login_limits;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    LL = null;
    locked = null;
    warning = '';
    var mine = FP.frame({title: tool.label, desc: t('ll_desc'), cls: 'fp-mail fp-srv fp-ll-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    page = mine;
    mine.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all([FP.call('get', 'loginLimits'), FP.call('get', 'loginLimitsLocked').then(cleanLocked, function () { return null; })]).then(function (r) {
      if (page !== mine) { return; }
      LL = clean(r[0]);
      locked = r[1];
      drawAll();
    }, function (err) {
      if (page !== mine) { return; }
      mine.textContent = '';
      mine.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

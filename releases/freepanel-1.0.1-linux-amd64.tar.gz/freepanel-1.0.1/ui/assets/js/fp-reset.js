/* freePanel: choose a new password from the emailed reset link, /reset-password?realm=admin|user#TOKEN (docs/api.md).
   The token travels in the fragment so it never reaches a server log; the page removes it from the address bar. */
(function () {
  'use strict';
  var UI = window.FPUI;
  var API = window.FPAPI;
  var params = new URLSearchParams(window.location.search);
  var token = window.location.hash.replace(/^#/, '');
  if (token && window.history && window.history.replaceState) {
    window.history.replaceState(null, '', window.location.pathname + window.location.search);
  }
  var realm = params.get('realm') === 'admin' ? 'admin' : 'user';
  var MIN = 12;

  function $(sel, scope) { return (scope || document).querySelector(sel); }
  var scope = document.getElementById('fp-step-reset');
  var form = $('form', scope);
  var first = $('#fp-new');
  var again = $('#fp-again');
  $('[data-fp-login]').href = UI.panel[realm].login;
  UI.health().then(function (h) { if (h.realm === 'admin' || h.realm === 'user') { $('[data-fp-login]').href = UI.panel[h.realm].login; } });

  function invalid(input, message) {
    input.setAttribute('aria-invalid', 'true');
    UI.showError(scope, message);
    input.focus();
  }

  if (!/^[A-Za-z0-9_\-.~%+=]{16,512}$/.test(token)) {
    UI.showError(scope, UI.t('missing_token'));
    $('.fp-submit', form).disabled = true;
  }

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var button = $('.fp-submit', form);
    if (button.disabled) { return; }
    first.removeAttribute('aria-invalid');
    again.removeAttribute('aria-invalid');
    UI.showError(scope, '');
    if (first.value.length < MIN) { invalid(first, UI.t('weak_password')); return; }
    if (again.value !== first.value) { invalid(again, UI.t('passwords_differ')); return; }
    UI.setBusy(button, true);
    API.post('reset', {token: token, new_password: first.value}).then(function () {
      first.value = '';
      again.value = '';
      scope.hidden = true;
      var done = document.getElementById('fp-step-done');
      done.hidden = false;
      $('h1', done).focus();
    }, function (err) {
      UI.setBusy(button, false);
      if (err.code === 'validation_failed' && err.field === 'new_password') { invalid(first, err.message); return; }
      if (err.status >= 400 && err.status < 500 && err.code !== 'rate_limited') {
        UI.showError(scope, UI.t('bad_token'));   /* used, expired or unknown link */
        button.disabled = true;
        return;
      }
      UI.showError(scope, err.message);
    });
  });

  UI.loadBrand();
  if (!$('.fp-submit', form).disabled) { first.focus(); }
})();

/* freePanel DNS lookup (docs/api.md, "DNS lookup"): the page every login has (#/tool/dns_lookup, in both panels) for asking a name's records. It
   asks the server's own resolvers (what this server is told) or its own name server (the zones as it serves them) and shows each answer
   with the server that gave it, its status, how long it took and the records. A name that does not exist is an answer, not an error. The
   server limits customers and resellers to 30 questions a minute and shows its own words. Everything the server sends is shown as text.
   The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var TYPES = ['A', 'AAAA', 'CNAME', 'MX', 'NS', 'TXT', 'SOA', 'SRV', 'CAA', 'PTR', 'all'];
  var SOURCES = ['resolver', 'local'];
  var NAME_RE = /^(?=.{1,253}$)[A-Za-z0-9_](?:[A-Za-z0-9_-]{0,61}[A-Za-z0-9_])?(?:\.[A-Za-z0-9_](?:[A-Za-z0-9_-]{0,61}[A-Za-z0-9_])?)+\.?$/;
  var IP4_RE = /^((25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)\.){3}(25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)$/;
  var RCODES = {NXDOMAIN: 'dlk_rc_nxdomain', SERVFAIL: 'dlk_rc_servfail', REFUSED: 'dlk_rc_refused'};

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n) : ''; }
  function whole(v, d) { return typeof v === 'number' && isFinite(v) && v >= 0 && Math.floor(v) === v ? v : d; }
  function clean(v) {
    v = v && typeof v === 'object' ? v : {};
    return {name: str(v.name, 253), source: SOURCES.indexOf(v.source) >= 0 ? v.source : 'resolver',
      results: (Array.isArray(v.results) ? v.results : []).filter(function (r) { return r && typeof r === 'object'; }).slice(0, 12).map(function (r) {
        return {type: str(r.type, 8), server: str(r.server, 80), rcode: str(r.rcode, 20), ms: whole(r.ms, null), error: str(r.error, 300),
          authoritative: r.authoritative === true, recursion: r.recursion_available === true, authentic: r.authentic === true, more: whole(r.more, 0),
          answers: (Array.isArray(r.answers) ? r.answers : []).filter(function (a) { return a && typeof a === 'object'; }).slice(0, 50).map(function (a) {
            return {name: str(a.name, 253), type: str(a.type, 8), ttl: whole(a.ttl, null), data: str(a.data, 2048)};
          })};
      })};
  }

  var L = {page: null, form: null, out: null, busy: false, last: null};

  function ttlText(s) {
    if (s === null) { return ''; }
    if (s >= 86400 && s % 86400 === 0) { return t(s === 86400 ? 'dns_ttl_day' : 'dns_ttl_days', {n: s / 86400}); }
    if (s >= 3600 && s % 3600 === 0) { return t(s === 3600 ? 'dns_ttl_hour' : 'dns_ttl_hours', {n: s / 3600}); }
    if (s >= 60 && s % 60 === 0) { return t(s === 60 ? 'dns_ttl_minute' : 'dns_ttl_minutes', {n: s / 60}); }
    return t('dns_ttl_seconds', {n: s});
  }
  function rcodeText(r) {
    if (r.error) { return t('dlk_no_answer', {error: r.error}); }
    if (r.rcode === 'NOERROR' && !r.answers.length) { return t('dlk_rc_empty'); }
    if (r.rcode === 'NOERROR') { return t(r.answers.length + r.more === 1 ? 'dlk_found_1' : 'dlk_found', {n: r.answers.length + r.more}); }
    return RCODES[r.rcode] ? t(RCODES[r.rcode]) : t('dlk_rc_other', {rcode: r.rcode || '?'});
  }
  function answerRow(a) {
    return el('li', {class: 'fp-dlk-answer'}, [el('div', {class: 'fp-dlk-head'}, [el('span', {class: 'sig-mono fp-dlk-name', text: a.name}), el('span', {class: 'sig-pill', text: a.type}),
      a.ttl !== null ? el('span', {class: 'fp-muted fp-dlk-ttl', text: t('dlk_ttl', {ttl: ttlText(a.ttl)})}) : null]), el('code', {class: 'sig-mono fp-dlk-data', text: a.data})]);
  }
  function resultCard(r, i) {
    var id = 'fp-dlk-r' + i;
    var flags = [];
    if (r.authoritative) { flags.push(el('span', {class: 'sig-pill sig-pill--ok', text: t('dlk_authoritative')})); }
    if (r.authentic) { flags.push(el('span', {class: 'sig-pill sig-pill--ok', text: t('dlk_authentic')})); }
    var meta = [r.server ? t('dlk_from', {server: r.server}) : '', r.ms !== null && !r.error ? t('dlk_ms', {ms: r.ms}) : ''].filter(Boolean).join(' · ');
    var parts = [el('p', {class: 'fp-dlk-status' + (r.error || (r.rcode && r.rcode !== 'NOERROR' && r.rcode !== 'NXDOMAIN') ? ' fp-dlk-bad' : ''), 'data-fp-rcode': r.rcode || 'none', text: rcodeText(r)})];
    if (meta) { parts.push(el('p', {class: 'fp-muted fp-dlk-meta', text: meta})); }
    if (flags.length) { parts.push(el('div', {class: 'fp-dlk-flags'}, flags)); }
    if (r.answers.length) { parts.push(el('ul', {class: 'fp-dlk-list', 'aria-labelledby': id + '-h'}, r.answers.map(answerRow))); }
    if (r.more) { parts.push(el('p', {class: 'fp-muted', 'data-fp-more': '', text: t(r.more === 1 ? 'dlk_more_1' : 'dlk_more', {n: r.more})})); }
    return M.card(id + '-h', t('dlk_result_title', {type: r.type || '?'}), parts, 'fp-dlk-result');
  }
  function showResult(v) {
    L.out.textContent = '';
    var head = el('h2', {class: 'fp-h2 fp-dlk-asked', id: 'fp-dlk-asked', tabindex: '-1', 'data-fp-asked': '', text: t(v.source === 'local' ? 'dlk_asked_local' : 'dlk_asked', {name: v.name})});
    L.out.appendChild(head);
    if (!v.results.length) { L.out.appendChild(el('p', {class: 'fp-muted', text: t('dlk_nothing')})); }
    v.results.forEach(function (r, i) { L.out.appendChild(resultCard(r, i)); });
    head.focus();
  }

  function readForm(form) {
    var name = form.querySelector('[name="name"]');
    var type = form.querySelector('[name="type"]').value;
    var source = form.querySelector('[name="source"]').value;
    var v = name.value.trim();
    if (!v) { M.fieldError(form, name, t('dlk_name_none')); return null; }
    if (type === 'PTR') {
      if (!IP4_RE.test(v) && !(v.indexOf(':') > 0 && /^[0-9A-Fa-f:.]{2,45}$/.test(v))) { M.fieldError(form, name, t('dlk_name_ptr')); return null; }
    } else if (!NAME_RE.test(v)) {
      M.fieldError(form, name, t('dlk_name_bad')); return null;
    }
    return {name: v, type: type, source: source};
  }
  function lookupForm() {
    var name = el('input', {class: 'sig-input sig-mono', id: 'fp-dlk-name', name: 'name', type: 'text', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', maxlength: '253',
      'aria-describedby': 'fp-dlk-name-hint'});
    var type = el('select', {class: 'sig-select', id: 'fp-dlk-type', name: 'type'}, TYPES.map(function (x) { return el('option', {value: x, text: x === 'all' ? t('dlk_type_all') : x}); }));
    var source = el('select', {class: 'sig-select', id: 'fp-dlk-source', name: 'source', 'aria-describedby': 'fp-dlk-source-hint'}, SOURCES.map(function (x) {
      return el('option', {value: x, text: t('dlk_source_' + x)});
    }));
    var nameHint = el('span', {class: 'sig-hint', id: 'fp-dlk-name-hint', text: t('dlk_name_hint')});
    var sourceHint = el('span', {class: 'sig-hint', id: 'fp-dlk-source-hint'});
    var form = el('form', {class: 'fp-form fp-dlk-form', novalidate: ''}, [M.errorLine(),
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: 'fp-dlk-name', text: t('dlk_name')}), name, nameHint]),
      el('div', {class: 'fp-mail-pair'}, [M.field('fp-dlk-type', t('dlk_type'), type), el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: 'fp-dlk-source', text: t('dlk_source')}), source, sourceHint])]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('dlk_ask')})])]);
    function sync() {
      nameHint.textContent = t(type.value === 'PTR' ? 'dlk_name_hint_ptr' : 'dlk_name_hint');
      sourceHint.textContent = t('dlk_source_hint_' + source.value);
    }
    type.addEventListener('change', sync);
    source.addEventListener('change', sync);
    sync();
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || L.busy) { return; }
      var q = readForm(form);
      if (!q) { return; }
      L.busy = true;
      UI.setBusy(b, true);
      var mine = L.page;
      FP.call('get', 'dnsLookup', undefined, q).then(function (r) {
        L.busy = false;
        if (L.page !== mine) { return; }
        UI.setBusy(b, false);
        L.last = clean(r);
        showResult(L.last);
      }, function (err) {
        L.busy = false;
        if (L.page !== mine) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return form;
  }

  FP.view('tool:dns_lookup', function () {
    var tool = FP.tools.dns_lookup;
    if (!tool) { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    L.busy = false;
    L.last = null;
    var body = FP.frame({title: tool.label, desc: t('dlk_desc'), cls: 'fp-mail fp-dlk-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    L.page = body;
    body.appendChild(M.card('fp-dlk-ask-h', t('dlk_title'), [el('p', {class: 'fp-muted', text: t('dlk_what')}), lookupForm()], 'fp-dlk-ask'));
    L.out = el('div', {class: 'fp-dlk-out', role: 'region', 'aria-label': t('dlk_answers'), 'data-fp-out': ''});
    body.appendChild(L.out);
  });
})();

/* freePanel account tools of the administrators' panel (docs/api.md, "Accounts", "Other logins", "Messages to many logins"): Change many accounts
   (#/tool/account_bulk: suspend, put back, change the package, ask for a new password or remove up to 50 accounts in one go, with a result for
   each), Accounts over quota (#/tool/accounts_over_quota: who uses most of their disk space), Require a new password (#/tool/account_force_password:
   tell one login to choose a new password, or take that back) and Message to customers (#/tool/message_customers: write to many logins at
   once). The administrator works on every account; a reseller on its own customers. What the server sends is drawn as text. The page pieces come
   from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var USER_RE = /^[a-z][a-z0-9]{0,15}$/;
  var DOMAIN_RE = /^(?=.{4,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/;
  var NAME_RE = /^[A-Za-z0-9][A-Za-z0-9_. -]{0,63}$/;
  var UNITS = ['KB', 'MB', 'GB', 'TB', 'PB'];

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function num(v) { return typeof v === 'number' && isFinite(v) && v >= 0 ? v : null; }
  function whole(v) { return num(v) === null ? 0 : Math.floor(v); }
  function isAdmin() { return FP.session.user.role === 'admin'; }
  function count(n) { return Number(n).toLocaleString('en'); }
  function sentence(m) { return typeof m === 'string' && m ? m.charAt(0).toUpperCase() + m.slice(1) : m; }
  function size(n) {
    if (n < 1024) { return count(n) + ' B'; }
    var u = -1;
    do { n /= 1024; u++; } while (n >= 1024 && u < UNITS.length - 1);
    return (n < 10 ? n.toFixed(1) : Math.round(n).toLocaleString('en')) + ' ' + UNITS[u];
  }
  function stamp(iso) {
    var d = typeof iso === 'string' && /^\d{4}-\d{2}-\d{2}T/.test(iso) ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'}) : '';
  }
  function frame(id) {
    var tool = FP.tools[id];
    if (!tool || FP.realm !== 'admin') { FP.views['not-found']({view: 'not-found'}); return null; }
    var g = FP.group(tool.group);
    return FP.frame({title: tool.label, desc: t(id + '_desc' + (isAdmin() ? '' : '_reseller')), cls: 'fp-mail fp-at fp-at-' + id,
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
  }
  function listFail(body, label, err) {
    body.textContent = '';
    body.appendChild(FP.empty(label, sentence(err.message)));
  }
  /* what the server said about a failed load, as a sentence to put before what the page makes of it */
  function why(err) {
    var m = sentence(err && err.message) || t('api_failed');
    return /[.!?]$/.test(m) ? m : m + '.';
  }
  function pill(kind, text) { return el('span', {class: 'sig-pill sig-pill--' + kind, text: text}); }
  function cleanAccount(a) {
    if (!a || typeof a !== 'object' || !USER_RE.test(str(a.username, 20))) { return null; }
    return {username: a.username, domain: DOMAIN_RE.test(str(a.domain, 260)) ? a.domain : '', owner: USER_RE.test(str(a.owner, 20)) ? a.owner : '',
      pkg: NAME_RE.test(str(a.package, 70)) ? a.package : '', suspended: a.status === 'suspended'};
  }
  function cleanAccounts(r) {
    return (r && Array.isArray(r.accounts) ? r.accounts : []).map(cleanAccount).filter(Boolean).sort(function (x, y) { return x.username < y.username ? -1 : 1; });
  }
  function cleanPackages(r) {
    return (r && Array.isArray(r.packages) ? r.packages : []).map(function (p) { return {name: str(p && p.name, 70), owner: str(p && p.owner, 20)}; })
      .filter(function (p) { return NAME_RE.test(p.name); });
  }
  /* a meter drawn from a ratio: the text beside it says the same, so the bar is for the eye alone */
  function meter(ratio) {
    var pct = Math.min(100, Math.max(0, ratio * 100));
    var bar = el('i');
    bar.style.width = pct.toFixed(1) + '%';
    return el('div', {class: 'sig-meter' + (ratio >= 1 ? ' is-danger' : ratio >= 0.8 ? ' is-warn' : ''), 'aria-hidden': 'true'}, [bar]);
  }

  /* ================= Change many accounts ================= */
  var MAX = 50;
  var SHOWN = 200;
  var ACTIONS = ['suspend', 'unsuspend', 'package', 'require_password_change', 'remove'];
  var K = {page: null, accounts: [], packages: [], owners: [], sel: {}, filter: '', result: null, action: 'suspend'};

  function kSelected() { return K.accounts.filter(function (a) { return K.sel[a.username]; }).map(function (a) { return a.username; }); }
  function kMatches() {
    var q = K.filter.trim().toLowerCase();
    return q ? K.accounts.filter(function (a) { return [a.username, a.domain, a.owner, a.pkg].join(' ').toLowerCase().indexOf(q) >= 0; }) : K.accounts;
  }
  function kCountText() {
    var n = kSelected().length;
    return n ? t(n === 1 ? 'bulk_selected_one' : 'bulk_selected_n', {n: count(n), max: MAX}) : t('bulk_selected_none', {max: MAX});
  }
  function kSay(text) {
    var line = K.page && K.page.querySelector('.fp-bulk-count');
    if (line) { line.textContent = text || kCountText(); }
  }
  function kRow(a) {
    var meta = [a.domain, a.pkg, isAdmin() ? a.owner : ''].filter(Boolean).join(' · ');
    var box = el('input', {type: 'checkbox', 'data-fp-bulk': a.username, checked: K.sel[a.username] ? true : null});
    return el('li', {class: 'fp-bulk-row'}, [el('label', {class: 'fp-check fp-bulk-label'}, [box,
      el('span', {class: 'fp-bulk-who'}, [el('span', {class: 'fp-bulk-name sig-mono', text: a.username}), meta ? el('span', {class: 'fp-muted fp-row-note', text: meta}) : null]),
      a.suspended ? pill('warn', t('bulk_suspended')) : null])]);
  }
  function kFillList() {
    var list = K.page.querySelector('.fp-bulk-list');
    var more = K.page.querySelector('.fp-bulk-more');
    var none = K.page.querySelector('.fp-bulk-none');
    var shown = kMatches();
    list.textContent = '';
    shown.slice(0, SHOWN).forEach(function (a) { list.appendChild(kRow(a)); });
    more.textContent = shown.length > SHOWN ? t('bulk_more', {shown: SHOWN, total: count(shown.length)}) : '';
    more.hidden = shown.length <= SHOWN;
    none.hidden = shown.length > 0;
    list.hidden = shown.length === 0;
    K.page.querySelector('[data-fp-act="bulk-all"]').textContent = t('bulk_select_shown', {n: count(Math.min(shown.length, SHOWN))});
    K.page.querySelector('[data-fp-act="bulk-all"]').disabled = shown.length === 0;
  }
  function kPickCard() {
    var filter = el('input', {class: 'sig-input', id: 'fp-bulk-filter', name: 'filter', type: 'search', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none',
      maxlength: '80', value: K.filter});
    filter.addEventListener('input', function () { K.filter = filter.value; kFillList(); });
    var list = el('ul', {class: 'fp-bulk-list', 'aria-label': t('bulk_list_label')});
    list.addEventListener('change', function (e) {
      var box = e.target;
      var name = box && box.getAttribute ? box.getAttribute('data-fp-bulk') : null;
      if (!name) { return; }
      if (box.checked && kSelected().length >= MAX) {
        box.checked = false;
        kSay(t('bulk_max', {max: MAX}));
        return;
      }
      if (box.checked) { K.sel[name] = true; } else { delete K.sel[name]; }
      kSay('');
    });
    var card = M.card('fp-bulk-pick-h', t('bulk_pick_title'), [
      M.field('fp-bulk-filter', t('bulk_filter'), filter, t('bulk_filter_hint')),
      el('div', {class: 'fp-actions fp-bulk-tools'}, [
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'bulk-all'}),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'bulk-none', text: t('bulk_clear')})]),
      el('p', {class: 'fp-bulk-count', role: 'status', 'aria-live': 'polite', text: kCountText()}),
      list, el('p', {class: 'fp-muted fp-bulk-more', hidden: true}), el('p', {class: 'fp-muted fp-bulk-none', 'data-fp-none': '', hidden: true, text: t('bulk_none_match')})], 'fp-bulk-pick');
    return card;
  }
  function kDoCard() {
    var acts = isAdmin() ? ACTIONS.slice(0, 3).concat(['owner'], ACTIONS.slice(3)) : ACTIONS;
    var action = el('select', {class: 'sig-select', id: 'fp-bulk-action', name: 'action'}, acts.map(function (a) {
      return el('option', {value: a, selected: a === K.action ? true : null, text: t('bulk_do_' + a)});
    }));
    var reason = el('input', {class: 'sig-input', id: 'fp-bulk-reason', name: 'reason', type: 'text', maxlength: '200', autocomplete: 'off'});
    var pkgs = K.packages.map(function (p) { return el('option', {value: p.name, text: isAdmin() && p.owner && p.owner !== FP.session.user.username ? p.name + ' (' + p.owner + ')' : p.name}); });
    var pkg = el('select', {class: 'sig-select', id: 'fp-bulk-package', name: 'package'}, [el('option', {value: '', text: t('bulk_package_pick')})].concat(pkgs));
    var note = el('p', {class: 'fp-muted fp-bulk-note', 'data-fp-note': ''});
    var owner = el('select', {class: 'sig-select', id: 'fp-bulk-owner', name: 'owner'}, [el('option', {value: '', text: t('bulk_owner_pick')})]
      .concat(K.owners.map(function (n) { return el('option', {value: n, text: n}); })));
    var optOwner = M.field('fp-bulk-owner', t('bulk_owner'), owner, t('bulk_owner_hint'));
    optOwner.classList.add('fp-bulk-opt');
    var optReason = M.field('fp-bulk-reason', t('bulk_reason'), reason, t('bulk_reason_hint'));
    var optPkg = M.field('fp-bulk-package', t('bulk_package'), pkg, t(isAdmin() ? 'bulk_package_hint_admin' : 'bulk_package_hint'));
    optReason.classList.add('fp-bulk-opt');
    optPkg.classList.add('fp-bulk-opt');
    var ask = el('div', {class: 'fp-bulk-ask'});
    var asked = null;   /* the names the removal question was put about; the answer applies to these and no others */
    var submit = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit'});
    var form = el('form', {class: 'fp-form fp-mail-form fp-bulk-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-bulk-action', t('bulk_action'), action), optReason, optOwner, optPkg, note, el('div', {class: 'fp-actions'}, [submit]), ask]);
    function show() {
      K.action = action.value;
      optReason.hidden = K.action !== 'suspend';
      optPkg.hidden = K.action !== 'package' && K.action !== 'owner';
      optOwner.hidden = K.action !== 'owner';
      note.textContent = t('bulk_note_' + K.action);
      note.classList.toggle('fp-warn-line', K.action === 'remove');
      ask.textContent = '';
      asked = null;
      submit.textContent = t('bulk_go_' + K.action);
    }
    action.addEventListener('change', show);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      ask.textContent = '';
      asked = null;
      var names = kSelected();
      if (!names.length) { M.fieldError(form, null, t('bulk_need_some')); return; }
      if (K.action === 'package' && !pkg.value) { M.fieldError(form, pkg, t('bulk_need_package')); return; }
      if (K.action === 'owner' && !owner.value) { M.fieldError(form, owner, t('bulk_need_owner')); return; }
      if (K.action === 'suspend' && Array.from(reason.value.trim()).length > 200) { M.fieldError(form, reason, t('bulk_reason_long')); return; }
      if (K.action === 'remove') {
        asked = names;
        M.confirmIn(ask, t(names.length === 1 ? 'bulk_remove_ask_one' : 'bulk_remove_ask_n', {n: count(names.length)}), 'bulk-confirm', t('bulk_remove_yes'));
        return;
      }
      kRun(form, b, names);
    });
    form.addEventListener('click', function (e) {
      var yes = e.target.closest ? e.target.closest('[data-fp-act="bulk-confirm"]') : null;
      var no = e.target.closest ? e.target.closest('[data-fp-act="confirm-no"]') : null;
      if (yes) {
        var b = form.querySelector('.fp-submit');
        if (b.disabled || !asked) { return; }
        ask.textContent = '';
        var sure = asked;
        asked = null;
        kRun(form, b, sure);
      } else if (no) {
        ask.textContent = '';
        asked = null;
        form.querySelector('.fp-submit').focus();
      }
    });
    var card = M.card('fp-bulk-do-h', t('bulk_do_title'), [form], 'fp-bulk-do');
    show();
    return card;
  }
  function kBody(names) {
    var body = {action: K.action, accounts: names};
    var form = K.page.querySelector('.fp-bulk-form');
    if (K.action === 'package') { body.package = form.querySelector('[name="package"]').value; }
    if (K.action === 'owner') {
      body.owner = form.querySelector('[name="owner"]').value;
      if (form.querySelector('[name="package"]').value) { body.package = form.querySelector('[name="package"]').value; }
    }
    if (K.action === 'suspend' && form.querySelector('[name="reason"]').value.trim()) { body.reason = form.querySelector('[name="reason"]').value.trim(); }
    if (K.action === 'remove') { body.confirm = true; }
    return body;
  }
  function cleanResult(r, action) {
    if (!r || typeof r !== 'object' || !Array.isArray(r.results)) { return null; }
    var rows = r.results.map(function (x) {
      if (!x || typeof x !== 'object' || !USER_RE.test(str(x.username, 20))) { return null; }
      var e = x.error && typeof x.error === 'object' ? x.error : null;
      return {username: x.username, ok: x.ok === true, code: e ? str(e.code, 40) : '', message: e ? str(e.message, 300) : '', parked: str(x.parked_at, 300)};
    }).filter(Boolean);
    return {action: action, rows: rows, done: whole(r.done), failed: whole(r.failed), total: whole(r.total) || rows.length};
  }
  function kRun(form, b, names) {
    var page = K.page;
    var body = kBody(names);
    var action = K.action;
    UI.setBusy(b, true);
    M.say(form, t('bulk_working', {n: count(names.length)}));
    FP.call('post', 'accountsBulk', body).then(function (r) {
      if (K.page !== page) { return; }
      var res = cleanResult(r, action);
      UI.setBusy(b, false);
      M.say(form, '');
      if (!res) { M.fieldError(form, null, t('api_failed')); return; }
      K.result = res;
      /* what worked is done with; what did not stays selected, so the same change can be sent again for it */
      K.sel = {};
      res.rows.forEach(function (x) { if (!x.ok) { K.sel[x.username] = true; } });
      kReload(true);
    }, function (err) {
      if (K.page !== page) { return; }
      UI.setBusy(b, false);
      M.say(form, '');
      M.failed(form, err);
    });
  }
  function kResultCard() {
    var r = K.result;
    var skipped = r.rows.filter(function (x) { return x.code === 'skipped'; });
    var summary = r.failed === 0 ? t('bulk_sum_' + r.action + (r.done === 1 ? '_one' : '_n'), {n: count(r.done)}) :
      t(r.done === 0 ? 'bulk_sum_none' : 'bulk_sum_some', {done: count(r.done), total: count(r.total), failed: count(r.failed)});
    var rows = r.rows.map(function (x) {
      var kind = x.ok ? 'ok' : x.code === 'skipped' ? 'warn' : 'danger';
      var label = x.ok ? t('bulk_ok') : x.code === 'skipped' ? t('bulk_skipped') : t('bulk_failed');
      var note = x.ok ? (x.parked ? t('bulk_parked', {path: x.parked}) : '') : sentence(x.message);
      return el('li', {class: 'fp-bulk-res', 'data-fp-result': x.username}, [el('span', {class: 'fp-bulk-name sig-mono', text: x.username}), pill(kind, label),
        note ? el('span', {class: 'fp-muted fp-bulk-why', text: note}) : null]);
    });
    var parts = [el('p', {class: 'fp-bulk-summary', role: 'status', 'data-fp-summary': '', text: summary})];
    if (skipped.length) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-skipped': ''}, [UI.icon(FP.ui, 'ui_warning'),
        el('span', {text: t(skipped.length === 1 ? 'bulk_skipped_one' : 'bulk_skipped_n', {n: count(skipped.length)})})]));
    }
    parts.push(el('ul', {class: 'fp-bulk-results', 'aria-label': t('bulk_result_label')}, rows));
    return M.card('fp-bulk-res-h', t('bulk_result_title'), parts, 'fp-bulk-result');
  }
  function kRender(focusResult) {
    var page = K.page;
    page.textContent = '';
    page.appendChild(kPickCard());
    page.appendChild(kDoCard());
    if (K.result) { page.appendChild(kResultCard()); }
    kFillList();
    if (focusResult && K.result) { page.querySelector('#fp-bulk-res-h').focus(); }
  }
  /* the accounts again, after a change: the statuses and packages show what happened */
  function kReload(focusResult) {
    var page = K.page;
    FP.call('get', 'accounts').then(function (r) {
      if (K.page !== page) { return; }
      K.accounts = cleanAccounts(r);
      Object.keys(K.sel).forEach(function (n) { if (!K.accounts.some(function (a) { return a.username === n; })) { delete K.sel[n]; } });
      kRender(focusResult);
    }, function () {
      if (K.page === page) { kRender(focusResult); }
    });
  }
  FP.view('tool:account_bulk', function () {
    K = {page: null, accounts: [], packages: [], owners: [], sel: {}, filter: '', result: null, action: 'suspend'};
    var body = frame('account_bulk');
    if (!body) { return; }
    K.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all([FP.call('get', 'accounts'), FP.call('get', 'packages').then(cleanPackages, function () { return []; }),
      isAdmin() ? FP.call('get', 'resellers').catch(function () { return null; }) : null]).then(function (r) {
      if (K.page !== body) { return; }
      K.accounts = cleanAccounts(r[0]);
      K.packages = r[1];
      K.owners = [FP.session.user.username].concat((r[2] && Array.isArray(r[2].resellers) ? r[2].resellers : []).map(function (x) { return str(x && x.username, 20); })
        .filter(function (n) { return USER_RE.test(n); }).sort());
      if (!K.accounts.length) {
        body.textContent = '';
        body.appendChild(FP.empty(t('bulk_empty_title'), t('bulk_empty_text')));
        return;
      }
      kRender(false);
    }, function (err) {
      if (K.page === body) { listFail(body, FP.tools.account_bulk.label, err); }
    });
    body.addEventListener('click', function (e) {
      var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
      var act = b ? b.getAttribute('data-fp-act') : '';
      if (act === 'bulk-all') {
        var names = kMatches().slice(0, SHOWN).map(function (a) { return a.username; });
        var room = MAX - kSelected().length;
        var added = 0;
        names.forEach(function (n) { if (!K.sel[n] && added < room) { K.sel[n] = true; added++; } });
        kFillList();
        kSay(names.filter(function (n) { return !K.sel[n]; }).length ? t('bulk_max', {max: MAX}) : '');
      } else if (act === 'bulk-none') {
        K.sel = {};
        kFillList();
        kSay('');
      }
    });
  });

  /* ================= Accounts over quota ================= */
  var Q = {page: null, threshold: 100};
  function cleanQuota(r) {
    if (!r || typeof r !== 'object' || !Array.isArray(r.accounts)) { return null; }
    return {threshold: whole(r.threshold) || 100, checked: whole(r.checked), unmeasured: whole(r.unmeasured), rows: r.accounts.map(function (a) {
      if (!a || typeof a !== 'object' || !USER_RE.test(str(a.username, 20)) || num(a.used_bytes) === null || num(a.limit_bytes) === null) { return null; }
      return {username: a.username, domain: DOMAIN_RE.test(str(a.domain, 260)) ? a.domain : '', owner: USER_RE.test(str(a.owner, 20)) ? a.owner : '',
        pkg: NAME_RE.test(str(a.package, 70)) ? a.package : '', suspended: a.status === 'suspended', used: a.used_bytes, limit: a.limit_bytes,
        percent: num(a.percent) === null ? 0 : a.percent, files: whole(a.files), partial: a.partial === true, at: stamp(a.measured_at)};
    }).filter(Boolean)};
  }
  function pctText(p) { return p > 1000 ? t('oq_over_1000') : (Math.round(p * 10) / 10).toLocaleString('en') + '%'; }
  function qRow(a) {
    var ratio = a.limit > 0 ? a.used / a.limit : 1;
    var usage = a.limit > 0 ? t(a.partial ? 'oq_use_partial' : 'oq_use', {used: size(a.used), limit: size(a.limit), pct: pctText(a.percent)}) :
      t('oq_use_zero', {used: size(a.used)});
    var meta = [a.domain, a.pkg, isAdmin() ? a.owner : ''].filter(Boolean).join(' · ');
    return el('li', {class: 'fp-oq-row', 'data-fp-account': a.username}, [
      el('div', {class: 'fp-oq-head'}, [el('span', {class: 'fp-oq-name sig-mono', text: a.username}), a.suspended ? pill('warn', t('bulk_suspended')) : null,
        a.percent >= 100 ? pill('danger', t('oq_full')) : null]),
      meta ? el('div', {class: 'fp-muted fp-row-note', text: meta}) : null,
      el('div', {class: 'fp-oq-use', text: usage}), meter(ratio),
      el('div', {class: 'fp-muted fp-row-note', text: [t('oq_files', {n: count(a.files)}), a.at ? t('oq_measured', {when: a.at}) : ''].filter(Boolean).join(' · ')}),
      a.partial ? el('div', {class: 'fp-muted fp-row-note', text: t('oq_partial')}) : null]);
  }
  function qShow(d, focusList) {
    var box = Q.page.querySelector('.fp-oq-out');
    var sum = d.rows.length ? t(d.rows.length === 1 ? 'oq_sum_one' : 'oq_sum_n', {n: count(d.rows.length), pct: count(d.threshold)}) : t('oq_sum_none', {pct: count(d.threshold)});
    var parts = [el('p', {class: 'fp-oq-summary', role: 'status', 'data-fp-summary': '', text: sum}),
      el('p', {class: 'fp-muted fp-row-note', 'data-fp-checked': '', text: t(d.checked === 1 ? 'oq_checked_one' : 'oq_checked_n', {n: count(d.checked)})})];
    if (d.unmeasured) { parts.push(el('p', {class: 'fp-warn-line', 'data-fp-unmeasured': '', text: t(d.unmeasured === 1 ? 'oq_unmeasured_one' : 'oq_unmeasured_n', {n: count(d.unmeasured)})})); }
    if (d.rows.length) { parts.push(el('ul', {class: 'fp-oq-list', 'aria-label': t('oq_list_label')}, d.rows.map(qRow))); }
    box.textContent = '';
    box.appendChild(M.card('fp-oq-res-h', t('oq_result_title'), parts, 'fp-oq-result'));
    if (focusList) { box.querySelector('#fp-oq-res-h').focus(); }
  }
  function qLoad(threshold, form, focusList) {
    var page = Q.page;
    var b = form ? form.querySelector('.fp-submit') : null;
    if (b) { UI.setBusy(b, true); }
    return FP.call('get', 'accountsOverQuota', undefined, {threshold: String(threshold)}).then(function (r) {
      if (Q.page !== page) { return; }
      if (b) { UI.setBusy(b, false); }
      var d = cleanQuota(r);
      if (!d) { if (form) { M.fieldError(form, null, t('api_failed')); } else { listFail(page, FP.tools.accounts_over_quota.label, {message: t('api_failed')}); } return; }
      Q.threshold = d.threshold;
      qShow(d, focusList);
      if (form) { M.say(form, t('oq_answered', {pct: count(d.threshold)})); }
    }, function (err) {
      if (Q.page !== page) { return; }
      if (b) { UI.setBusy(b, false); }
      if (form) { M.failed(form, err); } else { listFail(page, FP.tools.accounts_over_quota.label, err); }
    });
  }
  FP.view('tool:accounts_over_quota', function () {
    Q = {page: null, threshold: 100};
    var body = frame('accounts_over_quota');
    if (!body) { return; }
    Q.page = body;
    var input = el('input', {class: 'sig-input fp-oq-input', id: 'fp-oq-threshold', name: 'threshold', type: 'number', inputmode: 'numeric', min: '1', max: '1000', step: '1', value: '100'});
    var form = el('form', {class: 'fp-form fp-mail-form', novalidate: ''}, [M.errorLine(), M.statusLine(), M.field('fp-oq-threshold', t('oq_threshold'), input, t('oq_threshold_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('oq_show')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var v = input.value.trim();
      if (!/^[0-9]{1,4}$/.test(v) || Number(v) < 1 || Number(v) > 1000) { M.fieldError(form, input, t('oq_threshold_bad')); return; }
      qLoad(Number(v), form, true);
    });
    body.appendChild(M.card('fp-oq-form-h', t('oq_form_title'), [form], 'fp-oq-form'));
    var out = el('div', {class: 'fp-oq-out'}, [el('p', {class: 'fp-muted', text: t('loading')})]);
    body.appendChild(out);
    qLoad(100, null, false);
  });

  /* ================= Require a new password ================= */
  var W = {page: null};
  function wLogins(rs) {
    var names = [];
    cleanAccounts(rs[0]).forEach(function (a) { names.push(a.username); });
    ((rs[1] && Array.isArray(rs[1].resellers) ? rs[1].resellers : [])).forEach(function (x) {
      var n = str(x && x.username, 20);
      if (USER_RE.test(n) && names.indexOf(n) < 0) { names.push(n); }
    });
    return names.sort().slice(0, 500);
  }
  function wTell(form, login, required, b) {
    var page = W.page;
    UI.setBusy(b, true);
    FP.call('put', 'loginPasswordChange', {required: required}, login).then(function (r) {
      if (W.page !== page) { return; }
      UI.setBusy(b, false);
      var who = r && USER_RE.test(str(r.username, 20)) ? r.username : login;
      M.say(form, t(required ? 'fpw_told' : 'fpw_cleared', {name: who}));
      form.querySelector('#fp-fpw-login').focus();
    }, function (err) {
      if (W.page !== page) { return; }
      UI.setBusy(b, false);
      M.failed(form, err);
    });
  }
  FP.view('tool:account_force_password', function () {
    W = {page: null};
    var body = frame('account_force_password');
    if (!body) { return; }
    W.page = body;
    var page = body;
    var login = el('input', {class: 'sig-input sig-mono', id: 'fp-fpw-login', name: 'login', type: 'text', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none',
      maxlength: '16', list: 'fp-fpw-names'});
    var names = el('datalist', {id: 'fp-fpw-names'});
    var clear = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'fpw-clear', text: t('fpw_clear')});
    var form = el('form', {class: 'fp-form fp-mail-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-fpw-login', t('fpw_login'), login, t(isAdmin() ? 'fpw_login_hint' : 'fpw_login_hint_reseller')), names,
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('fpw_require')}), clear])]);
    function read() {
      var v = login.value.trim().toLowerCase();
      if (!USER_RE.test(v)) { M.fieldError(form, login, t('fpw_login_bad')); return ''; }
      return v;
    }
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var v = read();
      if (v) { wTell(form, v, true, b); }
    });
    clear.addEventListener('click', function () {
      var b = M.start(form);
      if (!b) { return; }
      var v = read();
      if (v) { wTell(form, v, false, clear); }
    });
    var more = [el('li', {text: t('fpw_what_1')}), el('li', {text: t('fpw_what_2')}), el('li', {text: t('fpw_what_3')}), el('li', {text: t('fpw_what_4')})];
    body.appendChild(M.card('fp-fpw-form-h', t('fpw_form_title'), [form], 'fp-fpw-form'));
    body.appendChild(M.card('fp-fpw-what-h', t('fpw_what_title'), [el('ul', {class: 'fp-at-points'}, more),
      FP.tools.account_bulk ? el('p', {class: 'fp-muted'}, [document.createTextNode(t('fpw_bulk') + ' '), el('a', {href: '#/tool/account_bulk', text: FP.tools.account_bulk.label})]) : null], 'fp-fpw-what'));
    /* the names the login can be chosen from; without them the box is still a text box, and the page says why there are none */
    function noNames(text) {
      var spot = login.closest('.sig-field');
      spot.parentNode.insertBefore(el('p', {class: 'fp-warn-line', role: 'note', 'data-fp-names-note': '', text: text}), spot.nextSibling);
    }
    var resellersFailed = null;
    Promise.all([FP.call('get', 'accounts'), isAdmin() ? FP.call('get', 'resellers').then(null, function (err) { resellersFailed = err; return null; }) : Promise.resolve(null)]).then(function (rs) {
      if (W.page !== page) { return; }
      wLogins(rs).forEach(function (n) { names.appendChild(el('option', {value: n})); });
      if (resellersFailed) { noNames(t('fpw_resellers_failed', {why: why(resellersFailed)})); }
    }, function (err) {
      if (W.page !== page) { return; }
      noNames(t('fpw_names_failed', {why: why(err)}));
    });
  });

  /* ================= Message to customers ================= */
  var AN = {page: null, timer: 0, last: null, busy: false};
  var EVERY = 2500;
  var REACH_KEYS = ['no_address', 'disabled', 'duplicate', 'withheld'];
  function cleanReach(r) {
    if (!r || typeof r !== 'object' || num(r.recipients) === null) { return null; }
    return {recipients: whole(r.recipients), no_address: whole(r.no_address), disabled: whole(r.disabled), duplicate: whole(r.duplicate), withheld: whole(r.withheld),
      audience: ['customers', 'resellers', 'all'].indexOf(r.audience) >= 0 ? r.audience : 'customers'};
  }
  function cleanRun(l) {
    if (!l || typeof l !== 'object') { return null; }
    return {by: str(l.by, 20), audience: ['customers', 'resellers', 'all'].indexOf(l.audience) >= 0 ? l.audience : 'customers', subject: str(l.subject, 160),
      started: stamp(l.started), running: l.running === true, total: whole(l.total), sent: whole(l.sent), failed: whole(l.failed), unsent: whole(l.unsent), stopped: str(l.stopped, 300)};
  }
  function reachCard(r) {
    var left = REACH_KEYS.filter(function (k) { return r[k] > 0; }).map(function (k) { return t('ann_left_' + k, {n: count(r[k])}); });
    var parts = [el('p', {class: 'fp-ann-reach-n', role: 'status', 'data-fp-reach': '', text: t(r.recipients === 1 ? 'ann_reach_one' : 'ann_reach_n', {n: count(r.recipients)})})];
    if (left.length) {
      parts.push(el('p', {class: 'fp-muted fp-ann-left-h', text: t('ann_left_title')}), el('ul', {class: 'fp-at-points', 'data-fp-left': ''}, left.map(function (x) { return el('li', {text: x}); })));
    }
    return el('div', {class: 'fp-ann-reach'}, parts);
  }
  function runCard(l, busyByOther) {
    var parts = [];
    if (!l) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': '', text: t(busyByOther ? 'ann_busy_other' : 'ann_last_none')}));
    } else {
      var line = l.running ? t('ann_running', {sent: count(l.sent), total: count(l.total), failed: count(l.failed)}) :
        t(l.stopped ? 'ann_stopped' : 'ann_done', {sent: count(l.sent), total: count(l.total)});
      parts.push(el('p', {class: 'fp-ann-subject'}, [el('b', {text: l.subject}), document.createTextNode(' · ' + t('ann_aud_' + l.audience) + (l.started ? ' · ' + l.started : ''))]));
      parts.push(el('p', {class: 'fp-ann-progress', role: 'status', 'data-fp-progress': '', text: line}));
      if (l.total > 0) { parts.push(meter((l.sent + l.failed) / l.total)); }
      if (!l.running && l.failed > 0) { parts.push(el('p', {class: 'fp-muted fp-row-note', text: t('ann_failed', {n: count(l.failed)})})); }
      if (!l.running && l.stopped) {
        parts.push(el('p', {class: 'fp-warn-line', 'data-fp-stopped': '', text: t('ann_stopped_why', {why: l.stopped, n: count(l.unsent)})}));
      }
      if (busyByOther) { parts.push(el('p', {class: 'fp-muted', text: t('ann_busy_other')})); }
    }
    return M.card('fp-ann-last-h', t('ann_last_title'), parts, 'fp-ann-last');
  }
  function aDraw() {
    var old = AN.page.querySelector('.fp-ann-last');
    var fresh = runCard(AN.last, AN.busy && !(AN.last && AN.last.running));
    if (old) { old.parentNode.replaceChild(fresh, old); } else { AN.page.appendChild(fresh); }
    var send = AN.page.querySelector('.fp-ann-form .fp-submit');
    if (send) { send.disabled = AN.busy; }
    var warn = AN.page.querySelector('.fp-ann-busy');
    if (warn) { warn.hidden = !AN.busy; }
  }
  function aPoll() {
    window.clearTimeout(AN.timer);
    var page = AN.page;
    if (!AN.busy) { return; }
    AN.timer = window.setTimeout(function () {
      FP.call('get', 'announcements').then(function (r) {
        if (AN.page !== page) { return; }
        AN.last = cleanRun(r && r.last);
        AN.busy = Boolean(r && r.busy === true);
        aDraw();
        aPoll();
      }, function () { if (AN.page === page) { aPoll(); } });
    }, EVERY);
  }
  function aForm() {
    var audience = isAdmin() ? el('select', {class: 'sig-select', id: 'fp-ann-audience', name: 'audience'}, ['customers', 'resellers', 'all'].map(function (a) {
      return el('option', {value: a, text: t('ann_aud_' + a)});
    })) : null;
    var subject = el('input', {class: 'sig-input', id: 'fp-ann-subject', name: 'subject', type: 'text', maxlength: '150', autocomplete: 'off'});
    var text = el('textarea', {class: 'sig-input fp-ann-body', id: 'fp-ann-body', name: 'body', rows: '10', maxlength: '20000'});
    var counter = el('span', {class: 'sig-hint fp-ann-counter', 'aria-live': 'off', text: t('ann_bytes', {n: 0})});
    var reach = el('div', {class: 'fp-ann-reachbox'});
    var ask = el('div', {class: 'fp-ann-ask'});
    var busy = el('div', {class: 'sig-banner sig-banner--warn fp-ann-busy', role: 'note', hidden: !AN.busy}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('ann_busy_note')})]);
    var check = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'ann-check', text: t('ann_check')});
    var form = el('form', {class: 'fp-form fp-mail-form fp-ann-form', novalidate: ''}, [M.errorLine(), M.statusLine(), busy,
      audience ? M.field('fp-ann-audience', t('ann_audience'), audience, t('ann_audience_hint')) : el('p', {class: 'fp-muted', text: t('ann_reseller_note')}),
      M.field('fp-ann-subject', t('ann_subject'), subject, t('ann_subject_hint')),
      M.field('fp-ann-body', t('ann_body'), text, t('ann_body_hint')), counter, reach,
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('ann_send'), disabled: AN.busy ? true : null}), check]), ask]);
    text.addEventListener('input', function () { counter.textContent = t('ann_bytes', {n: count(new window.TextEncoder().encode(text.value).length)}); });
    function read() {
      var s = subject.value.trim();
      var bytes = new window.TextEncoder().encode(text.value).length;
      if (!s || Array.from(s).length > 150 || /[\u0000-\u001f\u007f]/.test(s)) { M.fieldError(form, subject, t('ann_subject_bad')); return null; }   // eslint-disable-line no-control-regex -- one printable line
      if (!text.value.trim() || bytes > 20000 || /[\u0000-\u0008\u000b-\u001f\u007f]/.test(text.value)) { M.fieldError(form, text, t(bytes > 20000 ? 'ann_body_long' : 'ann_body_bad')); return null; }   // eslint-disable-line no-control-regex -- text only
      var body = {subject: s, body: text.value};
      if (audience) { body.audience = audience.value; }
      return body;
    }
    function who(r) { return t('ann_who_' + (isAdmin() ? r.audience : 'customers')); }
    function preview(then) {
      var b = M.start(form);
      if (!b) { return; }
      ask.textContent = '';
      var body = read();
      if (!body) { return; }
      var page = AN.page;
      UI.setBusy(then ? form.querySelector('.fp-submit') : check, true);
      FP.call('post', 'announcements', {audience: body.audience, subject: body.subject, body: body.body, preview: true}).then(function (r) {
        if (AN.page !== page) { return; }
        UI.setBusy(form.querySelector('.fp-submit'), false);
        UI.setBusy(check, false);
        var reached = cleanReach(r);
        if (!reached) { M.fieldError(form, null, t('api_failed')); return; }
        reach.textContent = '';
        reach.appendChild(reachCard(reached));
        if (then) { then(reached, body); } else { check.focus(); }
      }, function (err) {
        if (AN.page !== page) { return; }
        UI.setBusy(form.querySelector('.fp-submit'), false);
        UI.setBusy(check, false);
        M.failed(form, err);
      });
    }
    function send(body) {
      var page = AN.page;
      var b = form.querySelector('.fp-submit');
      UI.setBusy(b, true);
      FP.call('post', 'announcements', body).then(function () {
        if (AN.page !== page) { return; }
        UI.setBusy(b, false);
        AN.busy = true;
        AN.last = {by: FP.session.user.username, audience: body.audience || 'customers', subject: body.subject, started: '', running: true, total: 0, sent: 0, failed: 0, unsent: 0, stopped: ''};
        M.say(form, t('ann_started'));
        ask.textContent = '';
        aRefresh();
      }, function (err) {
        if (AN.page !== page) { return; }
        UI.setBusy(b, false);
        ask.textContent = '';
        M.failed(form, err);
        if (err && err.code === 'conflict') { aRefresh(); }
      });
    }
    var pending = null;
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      preview(function (r, body) {
        pending = body;
        M.confirmIn(ask, t(r.recipients === 1 ? 'ann_ask_one' : 'ann_ask_n', {n: count(r.recipients), who: who(r)}), 'ann-confirm', t('ann_ask_yes'));
      });
    });
    form.addEventListener('click', function (e) {
      var yes = e.target.closest ? e.target.closest('[data-fp-act="ann-confirm"]') : null;
      var no = e.target.closest ? e.target.closest('[data-fp-act="confirm-no"]') : null;
      var chk = e.target.closest ? e.target.closest('[data-fp-act="ann-check"]') : null;
      if (yes && pending) { send(pending); } else if (no) { ask.textContent = ''; form.querySelector('.fp-submit').focus(); } else if (chk) { preview(null); }
    });
    return M.card('fp-ann-form-h', t('ann_form_title'), [form], 'fp-ann-compose');
  }
  /* what the server says is going on, and a look at it again while a message goes out */
  function aRefresh() {
    var page = AN.page;
    return FP.call('get', 'announcements').then(function (r) {
      if (AN.page !== page) { return; }
      AN.last = cleanRun(r && r.last);
      AN.busy = Boolean(r && r.busy === true);
      aDraw();
      aPoll();
    }, function () { if (AN.page === page) { aDraw(); } });
  }
  FP.view('tool:message_customers', function () {
    window.clearTimeout(AN.timer);
    AN = {page: null, timer: 0, last: null, busy: false};
    var body = frame('message_customers');
    if (!body) { return; }
    AN.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    var page = body;
    FP.call('get', 'announcements').then(function (r) {
      if (AN.page !== page) { return; }
      AN.last = cleanRun(r && r.last);
      AN.busy = Boolean(r && r.busy === true);
      body.textContent = '';
      body.appendChild(aForm());
      body.appendChild(runCard(AN.last, AN.busy && !(AN.last && AN.last.running)));
      aPoll();
    }, function (err) {
      if (AN.page === page) { listFail(body, FP.tools.message_customers.label, err); }
    });
  });
})();

/* freePanel site monitor (docs/api.md, "Site monitor"): the customer panel's Site monitor (#/tool/site_monitor), which lists the account's sites
   with what their last uptime check found and their uptime over 30 days, and for one site its 30 days, its downs and recoveries, how it is
   checked, a check now and a quality report of its page; and the admin panel's Site status (#/tool/site_monitor_overview), every checked site on
   the server and how often sites are checked. The server makes every request itself, to the account's own sites on this server only. Everything
   it sends is shown as text, never as markup: URLs, errors and page findings come from the sites. The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var DOMAIN_RE = /^[a-z0-9]([a-z0-9.-]{0,251}[a-z0-9])?$/;
  var STATES = ['up', 'down', 'unknown', 'off'];
  var ITEMS = ['page_weight', 'requests', 'response_time', 'compression', 'caching', 'https', 'http2', 'http3', 'hsts', 'security_headers',
    'mixed_content', 'broken_links', 'robots', 'sitemap', 'certificate'];
  var GRADES = ['good', 'warn', 'bad', 'info'];
  var INTERVALS = [5, 10, 15, 30, 60];

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function num(v) { return typeof v === 'number' && isFinite(v) ? v : null; }
  function whole(v, lo, hi) { return typeof v === 'number' && isFinite(v) && Math.floor(v) === v && v >= lo && v <= hi ? v : null; }
  function when(v) {
    if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}T/.test(v)) { return ''; }
    var d = new Date(v);
    return isNaN(d.getTime()) ? '' : d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'short'});
  }
  function pct(v) { return v === null ? '—' : (Math.round(v * 100) / 100) + ' %'; }

  function cleanLast(l) {
    if (!l || typeof l !== 'object') { return null; }
    return {at: when(l.at), url: str(l.url, 500), status: whole(l.status, 0, 999) || 0, ms: whole(l.ms, 0, 1e9) || 0, up: l.up === true,
      error: str(l.error), note: str(l.note), certDays: whole(l.cert_days_left, -100000, 100000), certTrusted: typeof l.cert_trusted === 'boolean' ? l.cert_trusted : null,
      keyword: typeof l.keyword_found === 'boolean' ? l.keyword_found : null};
  }
  function cleanSite(s) {
    s = s && typeof s === 'object' ? s : {};
    return {domain: str(s.domain, 253), kind: str(s.kind, 20), scheme: s.scheme === 'https' ? 'https' : 'http', enabled: s.enabled === true, notify: s.notify === true,
      path: str(s.path, 200) || '/', keyword: str(s.keyword, 100), mode: s.keyword_mode === 'present' || s.keyword_mode === 'absent' ? s.keyword_mode : '',
      state: STATES.indexOf(s.state) >= 0 ? s.state : 'unknown', since: when(s.since), last: cleanLast(s.last), uptime: num(s.uptime_30d),
      checks: whole(s.checks_30d, 0, 1e9) || 0, avg: whole(s.avg_ms_30d, 0, 1e9) || 0};
  }
  function cleanView(v) {
    v = v && typeof v === 'object' ? v : {};
    return {enabled: v.enabled !== false, interval: whole(v.interval_minutes, 1, 1440) || 5, email: str(v.email, 254),
      sites: (Array.isArray(v.sites) ? v.sites : []).slice(0, 500).map(cleanSite).filter(function (s) { return DOMAIN_RE.test(s.domain); })};
  }
  function cleanDetail(d) {
    d = d && typeof d === 'object' ? d : {};
    return {site: cleanSite(d.site),
      days: (Array.isArray(d.days) ? d.days : []).slice(-31).map(function (x) {
        x = x && typeof x === 'object' ? x : {};
        return {date: /^\d{4}-\d{2}-\d{2}$/.test(x.date) ? x.date : '', checks: whole(x.checks, 0, 1e9) || 0, up: whole(x.up, 0, 1e9) || 0, uptime: num(x.uptime), avg: whole(x.avg_ms, 0, 1e9) || 0};
      }),
      events: (Array.isArray(d.events) ? d.events : []).slice(0, 50).filter(function (e) { return e && (e.kind === 'down' || e.kind === 'up'); }).map(function (e) {
        return {at: when(e.at), kind: e.kind, detail: str(e.detail), notice: ['sent', 'unsent', 'off', 'held'].indexOf(e.notice) >= 0 ? e.notice : ''};
      })};
  }
  function cleanReport(r) {
    r = r && typeof r === 'object' ? r : {};
    return {url: str(r.url, 500), final: str(r.final_url, 500), status: whole(r.status, 0, 999) || 0, ms: whole(r.ms, 0, 1e9) || 0, error: str(r.error), note: str(r.note),
      bytes: whole(r.page_bytes, 0, 1e13) || 0, requests: whole(r.requests, 0, 1e6) || 0, others: whole(r.other_hosts, 0, 1e6) || 0, truncated: r.truncated === true,
      items: (Array.isArray(r.items) ? r.items : []).slice(0, 40).filter(function (i) { return i && ITEMS.indexOf(i.id) >= 0 && GRADES.indexOf(i.state) >= 0; }).map(function (i) {
        return {id: i.id, state: i.state, value: str(i.value, 200), fix: str(i.fix, 600),
          list: (Array.isArray(i.list) ? i.list : []).slice(0, 20).filter(function (x) { return typeof x === 'string'; }).map(function (x) { return x.slice(0, 320); })};
      })};
  }

  function pill(state) {
    var cls = {up: 'sig-pill--ok', down: 'sig-pill--danger', off: '', unknown: ''}[state];
    return el('span', {class: 'sig-pill ' + cls, 'data-fp-smon-state': state, text: t('smon_state_' + state)});
  }
  function gradePill(g) {
    var cls = {good: 'sig-pill--ok', warn: 'sig-pill--warn', bad: 'sig-pill--danger', info: ''}[g];
    return el('span', {class: 'sig-pill ' + cls, text: t('smon_grade_' + g)});
  }
  function lastLine(l) {
    if (!l) { return t('smon_never'); }
    if (!l.status) { return l.error || t('smon_no_answer'); }
    return t('smon_answered', {status: String(l.status), ms: String(l.ms)}) + (l.up ? '' : ' · ' + l.error);
  }
  function certLine(s) {
    var l = s.last;
    if (s.scheme !== 'https') { return t('smon_cert_none'); }
    if (!l || l.certDays === null) { return '—'; }
    if (l.certDays < 0) { return t('smon_cert_expired'); }
    return t('smon_cert_days', {n: String(l.certDays)}) + (l.certTrusted === false ? ' · ' + t('smon_cert_untrusted') : '');
  }
  function frame(id, cls) {
    var tool = FP.tools[id];
    var admin = id === 'site_monitor_overview';
    var ok = admin ? FP.realm === 'admin' && FP.session.user.role === 'admin' : FP.realm === 'user';
    if (!tool || !ok) { FP.views['not-found']({view: 'not-found'}); return null; }
    var g = FP.group(tool.group);
    return FP.frame({title: tool.label, desc: t(id + '_desc'), cls: 'fp-mail fp-smon ' + cls,
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
  }

  /* ================= the customer's page ================= */
  var S = {page: null};

  function listCard() {
    var V = S.view;
    var parts = [M.errorLine()];
    if (!V.enabled) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-smon-off': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('smon_server_off')})]));
    }
    parts.push(el('p', {class: 'fp-muted', text: t('smon_how', {n: String(V.interval)})}));
    parts.push(el('p', {class: 'fp-muted', 'data-fp-smon-email': '', text: V.email ? t('smon_email', {email: V.email}) : t('smon_no_email')}));
    if (!V.sites.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('smon_no_sites')}));
      return M.card('fp-smon-list-h', t('smon_sites_title'), parts, 'fp-smon-list');
    }
    parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-smon-list-h'}, [el('table', {class: 'sig-table fp-mail-table fp-smon-table'}, [
      el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('smon_site')}), el('th', {scope: 'col', text: t('smon_state')}),
        el('th', {scope: 'col', text: t('smon_last')}), el('th', {scope: 'col', text: t('smon_cert')}), el('th', {scope: 'col', class: 'fp-num', text: t('smon_uptime')}),
        el('th', {scope: 'col', text: t('smon_actions')})])]),
      el('tbody', null, V.sites.map(function (s) {
        var open = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-smon-open': s.domain,
          'aria-label': t('smon_open_for', {site: s.domain}), text: t('smon_open')});
        open.addEventListener('click', function () { choose(s.domain, '#fp-smon-detail-h'); });
        return el('tr', {'data-fp-smon-site': s.domain, class: s.domain === S.chosen ? 'fp-smon-chosen' : ''}, [
          el('th', {scope: 'row', class: 'fp-smon-name'}, [el('span', {class: 'sig-mono', text: s.domain})]),
          el('td', null, [pill(s.state)]), el('td', {class: 'fp-smon-last', text: lastLine(s.last)}), el('td', {text: certLine(s)}),
          el('td', {class: 'fp-num', text: pct(s.uptime)}), el('td', null, [open])]);
      }))])]));
    return M.card('fp-smon-list-h', t('smon_sites_title'), parts, 'fp-smon-list');
  }

  /* the 30 days as coloured blocks, for the eye (each names its day on hover); a line of words says the same for everyone */
  function daysStrip(days) {
    return el('ol', {class: 'fp-smon-days', 'aria-hidden': 'true'}, days.map(function (d) {
      var cls = d.checks === 0 ? 'none' : d.uptime >= 99.9 ? 'full' : d.uptime >= 95 ? 'most' : 'low';
      var words = d.checks === 0 ? t('smon_day_none', {date: d.date}) : t('smon_day', {date: d.date, pct: pct(d.uptime), n: String(d.checks), ms: String(d.avg)});
      return el('li', {class: 'fp-smon-day fp-smon-day--' + cls, title: words});
    }));
  }
  function daysWords(days) {
    var seen = days.filter(function (d) { return d.checks > 0; });
    if (!seen.length) { return t('smon_days_none'); }
    var worst = seen.reduce(function (a, d) { return d.uptime < a.uptime ? d : a; }, seen[0]);
    return t('smon_days_words', {n: String(seen.length), date: worst.date, pct: pct(worst.uptime)});
  }

  function settingsForm(s) {
    var on = el('input', {type: 'checkbox', id: 'fp-smon-on', name: 'enabled', checked: s.enabled ? true : null});
    var notify = el('input', {type: 'checkbox', id: 'fp-smon-notify', name: 'notify', checked: s.notify ? true : null});
    var path = el('input', {class: 'sig-input', id: 'fp-smon-path', name: 'path', type: 'text', autocomplete: 'off', spellcheck: 'false', maxlength: '200', value: s.path});
    var word = el('input', {class: 'sig-input', id: 'fp-smon-keyword', name: 'keyword', type: 'text', autocomplete: 'off', maxlength: '100', value: s.keyword});
    var mode = el('select', {class: 'sig-select', id: 'fp-smon-mode', name: 'keyword_mode'}, [['', t('smon_mode_none')], ['present', t('smon_mode_present')], ['absent', t('smon_mode_absent')]].map(function (o) {
      return el('option', {value: o[0], selected: o[0] === s.mode ? true : null, text: o[1]});
    }));
    var form = el('form', {class: 'fp-form fp-smon-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'sig-field'}, [el('label', {class: 'fp-check', for: 'fp-smon-on'}, [on, el('span', {text: t('smon_set_on')})])]),
      el('div', {class: 'sig-field'}, [el('label', {class: 'fp-check', for: 'fp-smon-notify'}, [notify, el('span', {text: t('smon_set_notify')})]),
        el('span', {class: 'sig-hint', text: t('smon_set_notify_hint')})]),
      M.field('fp-smon-path', t('smon_set_path'), path, t('smon_set_path_hint')),
      el('div', {class: 'fp-smon-word'}, [M.field('fp-smon-mode', t('smon_set_mode'), mode), M.field('fp-smon-keyword', t('smon_set_keyword'), word, t('smon_set_keyword_hint'))]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('smon_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var p = path.value.trim();
      if (!/^\/(?!\/)[\x21-\x7e]{0,199}$/.test(p) || /[#\\]/.test(p)) { M.fieldError(form, path, t('smon_bad_path')); return; }
      var w = word.value.trim();
      if (mode.value && !w) { M.fieldError(form, word, t('smon_need_word')); return; }
      UI.setBusy(b, true);
      var mine = S.page;
      FP.call('put', 'smonSite', {enabled: on.checked, notify: notify.checked, path: p, keyword: mode.value ? w : '', keyword_mode: mode.value ? mode.value : ''},
        {name: S.account, domain: S.chosen}).then(function (d) {
        if (S.page !== mine) { return; }
        S.detail = cleanDetail(d);
        refreshRow(S.detail.site);
        render('#fp-smon-on', '.fp-smon-settings', t('smon_saved'));
      }, function (err) {
        if (S.page !== mine) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return form;
  }

  function detailCards() {
    var D = S.detail;
    var s = D.site;
    var facts = [[t('smon_state'), null, pill(s.state)], [t('smon_since'), s.since || '—'], [t('smon_last'), lastLine(s.last)],
      [t('smon_checked_at'), s.last && s.last.at ? s.last.at : '—'], [t('smon_asked'), s.last && s.last.url ? s.last.url : s.scheme + '://' + s.domain + s.path, null, true],
      [t('smon_cert'), certLine(s)], [t('smon_uptime'), pct(s.uptime) + (s.checks ? ' · ' + t('smon_checks_n', {n: String(s.checks), ms: String(s.avg)}) : '')]];
    if (s.last && s.last.keyword !== null) { facts.push([t('smon_word'), t(s.last.keyword ? 'smon_word_found' : 'smon_word_missing', {word: s.keyword})]); }
    var check = el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'sm-check', text: t('smon_check_now')});
    var report = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'sm-report', text: t('smon_report')});
    var head = M.card('fp-smon-detail-h', t('smon_detail_title', {site: s.domain}), [M.errorLine(), M.statusLine(),
      el('dl', {class: 'fp-lc-facts fp-smon-facts'}, facts.reduce(function (out, f) {
        out.push(el('dt', {text: f[0]}), el('dd', {class: f[3] ? 'sig-mono' : ''}, [f[2] || document.createTextNode(f[1])]));
        return out;
      }, [])),
      s.last && s.last.note ? el('p', {class: 'fp-muted', 'data-fp-smon-note': '', text: s.last.note}) : null,
      el('div', {class: 'fp-actions'}, [check, report])], 'fp-smon-detail');
    check.addEventListener('click', function () { act(check, 'post', 'smonCheck', head, t('smon_checked')); });
    report.addEventListener('click', function () { makeReport(report, head); });
    var cards = [head];
    if (S.report) { cards.push(reportCard()); }
    cards.push(M.card('fp-smon-days-h', t('smon_days_title'), [daysStrip(D.days), el('p', {'data-fp-smon-days': '', text: daysWords(D.days)}), el('p', {class: 'fp-muted', text: t('smon_days_key')})], 'fp-smon-history'));
    var ev = D.events.length ? el('ul', {class: 'fp-ntf-list', 'data-fp-smon-events': ''}, D.events.map(function (e) {
      return el('li', {class: 'fp-ntf-item'}, [el('div', {class: 'fp-ntf-head'}, [el('span', {class: 'fp-ntf-what', text: t('smon_event_' + e.kind)}),
        e.at ? el('span', {class: 'fp-muted fp-ntf-when', text: e.at}) : null,
        e.notice ? el('span', {class: 'sig-pill', 'data-fp-smon-notice': e.notice, text: t('smon_notice_' + e.notice)}) : null]),
        e.detail ? el('p', {class: 'fp-ntf-detail', text: e.detail}) : null]);
    })) : el('p', {class: 'fp-muted', 'data-fp-smon-events-none': '', text: t('smon_events_none')});
    cards.push(M.card('fp-smon-events-h', t('smon_events_title'), [ev], 'fp-smon-events'));
    cards.push(M.card('fp-smon-set-h', t('smon_settings_title'), [settingsForm(s)], 'fp-smon-settings'));
    return cards;
  }

  function reportCard() {
    var R = S.report;
    var parts = [];
    if (R.error) {
      parts.push(el('p', {class: 'fp-lc-bad', 'data-fp-smon-report-error': '', text: R.error}));
    }
    parts.push(el('p', {class: 'fp-muted', text: t('smon_report_of', {url: R.final || R.url, kb: String(Math.round(R.bytes / 1024)), n: String(R.requests), others: String(R.others)})}));
    if (R.note) { parts.push(el('p', {class: 'fp-muted', text: R.note})); }
    if (R.items.length) {
      parts.push(el('ul', {class: 'fp-smon-items', 'data-fp-smon-items': ''}, R.items.map(function (i) {
        var fix = i.state === 'good' ? '' : t('smon_fix_' + i.id) || i.fix;
        return el('li', {class: 'fp-smon-item', 'data-fp-smon-item': i.id}, [el('div', {class: 'fp-ntf-head'}, [el('span', {class: 'fp-ntf-what', text: t('smon_item_' + i.id)}),
          gradePill(i.state), i.value ? el('span', {class: 'fp-muted sig-mono fp-smon-value', text: i.value}) : null]),
          fix ? el('p', {class: 'fp-smon-fix', text: fix}) : null,
          i.list.length ? el('ul', {class: 'fp-smon-list-of'}, i.list.map(function (x) { return el('li', {class: 'sig-mono', text: x}); })) : null]);
      })));
    }
    if (R.truncated) { parts.push(el('p', {class: 'fp-muted', text: t('smon_report_cut')})); }
    parts.push(el('p', {class: 'fp-muted', text: t('smon_report_note')}));
    return M.card('fp-smon-report-h', t('smon_report_title'), parts, 'fp-smon-report');
  }

  function refreshRow(site) {
    S.view.sites = S.view.sites.map(function (x) { return x.domain === site.domain ? site : x; });
  }
  function act(button, method, path, card, said) {
    UI.setBusy(button, true);
    UI.showError(card, '');
    var mine = S.page;
    FP.call(method, path, {}, {name: S.account, domain: S.chosen}).then(function (d) {
      if (S.page !== mine) { return; }
      S.detail = cleanDetail(d);
      refreshRow(S.detail.site);
      render('[data-fp-act="sm-check"]', '.fp-smon-detail', said);
      UI.announce(said);
    }, function (err) {
      if (S.page !== mine) { return; }
      UI.setBusy(button, false);
      UI.showError(card, err.message);
    });
  }
  function makeReport(button, card) {
    UI.setBusy(button, true);
    UI.showError(card, '');
    M.say(card, t('smon_reporting'));
    var mine = S.page;
    FP.call('post', 'smonReport', {}, {name: S.account, domain: S.chosen}).then(function (r) {
      if (S.page !== mine) { return; }
      S.report = cleanReport(r);
      render('#fp-smon-report-h', '', '');
      UI.announce(t('smon_report_done'));
    }, function (err) {
      if (S.page !== mine) { return; }
      UI.setBusy(button, false);
      M.say(card, '');
      UI.showError(card, err.message);
    });
  }
  function render(focus, sayIn, said) {
    var page = S.page;
    page.textContent = '';
    page.appendChild(listCard());
    if (S.detail) { detailCards().forEach(function (c) { page.appendChild(c); }); }
    if (said && sayIn) {
      var st = page.querySelector(sayIn + ' [data-fp-status]');
      if (st) { st.textContent = said; }
    }
    var f = focus && page.querySelector(focus);
    if (f) { f.focus(); }
  }
  function choose(domain, focus) {
    var mine = S.page;
    S.chosen = domain;
    S.report = null;
    UI.store.set('fp.smon.site', domain);
    FP.call('get', 'smonSite', undefined, {name: S.account, domain: domain}).then(function (d) {
      if (S.page !== mine) { return; }
      S.detail = cleanDetail(d);
      refreshRow(S.detail.site);
      render(focus, '', '');
    }, function (err) {
      if (S.page !== mine) { return; }
      UI.showError(mine.querySelector('.fp-smon-list'), err.message);
    });
  }
  FP.view('tool:site_monitor', function () {
    S.page = null;
    var body = frame('site_monitor', 'fp-smon-page');
    if (!body) { return; }
    S = {page: body, account: FP.account(), view: null, detail: null, report: null, chosen: ''};
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'smon', undefined, S.account).then(function (v) {
      if (S.page !== body) { return; }
      S.view = cleanView(v);
      render('', '', '');
      var names = S.view.sites.map(function (s) { return s.domain; });
      var last = UI.store.get('fp.smon.site');
      if (names.length) { choose(last && names.indexOf(last) >= 0 ? last : names[0], ''); }
    }, function (err) {
      if (S.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(FP.tools.site_monitor.label, err.message));
    });
  });

  /* ================= the admin's overview ================= */
  function cleanOverview(o) {
    o = o && typeof o === 'object' ? o : {};
    var st = o.settings && typeof o.settings === 'object' ? o.settings : {};
    return {enabled: st.enabled !== false, interval: INTERVALS.indexOf(st.interval_minutes) >= 0 ? st.interval_minutes : 5,
      counts: {up: whole(o.up, 0, 1e7) || 0, down: whole(o.down, 0, 1e7) || 0, unknown: whole(o.unknown, 0, 1e7) || 0, off: whole(o.off, 0, 1e7) || 0},
      sites: (Array.isArray(o.sites) ? o.sites : []).slice(0, 2000).filter(function (x) { return x && DOMAIN_RE.test(str(x.domain, 253)); }).map(function (x) {
        return {user: str(x.username, 32), domain: x.domain, state: STATES.indexOf(x.state) >= 0 ? x.state : 'unknown', since: when(x.since), last: cleanLast(x.last),
          uptime: num(x.uptime_30d), suspended: x.suspended === true};
      })};
  }
  function ovRender(page, O, focus, said) {
    page.textContent = '';
    var on = el('input', {type: 'checkbox', id: 'fp-smon-ov-on', name: 'enabled', checked: O.enabled ? true : null});
    var every = el('select', {class: 'sig-select', id: 'fp-smon-ov-interval', name: 'interval_minutes'}, INTERVALS.map(function (n) {
      return el('option', {value: String(n), selected: n === O.interval ? true : null, text: t('smon_every', {n: String(n)})});
    }));
    var form = el('form', {class: 'fp-form fp-smon-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'sig-field'}, [el('label', {class: 'fp-check', for: 'fp-smon-ov-on'}, [on, el('span', {text: t('smon_ov_on')})]),
        el('span', {class: 'sig-hint', text: t('smon_ov_on_hint')})]),
      M.field('fp-smon-ov-interval', t('smon_ov_interval'), every),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('smon_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      UI.setBusy(b, true);
      FP.call('put', 'smonSettings', {enabled: on.checked, interval_minutes: Number(every.value)}).then(function (r) {
        if (!page.isConnected) { return; }
        ovRender(page, cleanOverview(r), '#fp-smon-ov-on', t('smon_saved'));
      }, function (err) {
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    var C = O.counts;
    var summary = el('p', {'data-fp-smon-ov-summary': '', text: t('smon_ov_counts', {up: String(C.up), down: String(C.down), unknown: String(C.unknown), off: String(C.off)})});
    var list = O.sites.length ? el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-smon-ov-list-h'}, [el('table', {class: 'sig-table fp-mail-table fp-smon-table'}, [
      el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('smon_site')}), el('th', {scope: 'col', text: t('smon_account')}), el('th', {scope: 'col', text: t('smon_state')}),
        el('th', {scope: 'col', text: t('smon_last')}), el('th', {scope: 'col', class: 'fp-num', text: t('smon_uptime')})])]),
      el('tbody', null, O.sites.map(function (x) {
        return el('tr', {'data-fp-smon-ov-site': x.domain}, [el('th', {scope: 'row', class: 'fp-smon-name'}, [el('span', {class: 'sig-mono', text: x.domain})]),
          el('td', null, [el('span', {class: 'sig-mono', text: x.user}), x.suspended ? el('span', {class: 'fp-muted', text: ' ' + t('smon_suspended')}) : null]),
          el('td', null, [pill(x.state), x.since ? el('div', {class: 'fp-muted fp-smon-since', text: t('smon_since_when', {when: x.since})}) : null]),
          el('td', {class: 'fp-smon-last', text: lastLine(x.last)}), el('td', {class: 'fp-num', text: pct(x.uptime)})]);
      }))])]) : el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('smon_ov_none')});
    page.appendChild(M.card('fp-smon-ov-list-h', t('smon_ov_title'), [summary, list, el('p', {class: 'fp-muted', text: t('smon_ov_note')})], 'fp-smon-ov-list'));
    page.appendChild(M.card('fp-smon-ov-set-h', t('smon_ov_settings'), [form], 'fp-smon-ov-settings'));
    if (said) { M.say(form, said); }
    var f = focus && page.querySelector(focus);
    if (f) { f.focus(); }
  }
  FP.view('tool:site_monitor_overview', function () {
    var body = frame('site_monitor_overview', 'fp-smon-ov-page');
    if (!body) { return; }
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'smonOverview').then(function (o) {
      if (!body.isConnected) { return; }
      ovRender(body, cleanOverview(o), '', '');
    }, function (err) {
      if (!body.isConnected) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(FP.tools.site_monitor_overview.label, err.message));
    });
  });
})();

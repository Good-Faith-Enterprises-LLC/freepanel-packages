/* freePanel service certificates (#/tool/ssl_services), the admin panel's page for the certificate the server's own name
   shows (docs/api.md, "Service certificates"): the server's certificate and where it came from, the free certificate
   ordered for the server's name (its switch, why it is not being ordered, the last attempt, an order asked for now), and
   each service that serves the name (the panels, the web server's default host, the database tool, webmail, mail and FTP)
   with the certificate it reads and whether it shows it now. An order takes a moment, so after one is asked for the page
   reads the state again every few seconds until it has ended. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;
  var BK = FP.bk;

  var POLL_MS = 3000;
  var POLL_TRIES = 10;
  var ID_RE = /^[a-z][a-z0-9_]{0,31}$/;
  var SOURCES = ['free', 'self-signed', 'installed'];
  var SHOWS = ['yes', 'no', 'not running', 'unchecked'];
  var DAY = 86400000;
  var SOON_DAYS = 30;

  var S = null;

  var str = BK.str;

  /* ---------- what the server says, kept to the shapes the page draws ---------- */
  function cleanInfo(c) {
    if (!c || typeof c !== 'object') { return null; }
    return {names: (Array.isArray(c.names) ? c.names : []).filter(function (n) { return typeof n === 'string' && n && n.length <= 253; }).slice(0, 20),
      issuer: str(c.issuer).slice(0, 120), source: SOURCES.indexOf(c.source) >= 0 ? c.source : '', end: str(c.not_after)};
  }
  function cleanService(s) {
    if (!s || typeof s !== 'object' || !ID_RE.test(str(s.id))) { return null; }
    return {id: s.id, label: str(s.label).slice(0, 80) || s.id, installed: s.installed === true,
      ports: (Array.isArray(s.ports) ? s.ports : []).filter(function (p) { return typeof p === 'number' && p >= 1 && p <= 65535 && Math.floor(p) === p; }).slice(0, 8),
      info: cleanInfo(s.certificate), shows: SHOWS.indexOf(s.shows) >= 0 ? s.shows : 'unchecked'};
  }
  function cleanState(r) {
    r = r && typeof r === 'object' ? r : {};
    var o = r.order && typeof r.order === 'object' ? r.order : {};
    return {host: str(r.hostname).slice(0, 253), info: cleanInfo(r.certificate), panelsError: str(r.panels_error).slice(0, 400),
      order: {name: str(o.name).slice(0, 253), enabled: o.enabled === true, ordering: o.ordering === true, reason: str(o.reason).slice(0, 400),
        last: str(o.last_attempt), error: str(o.last_error).slice(0, 400)},
      services: (Array.isArray(r.services) ? r.services : []).slice(0, 20).map(cleanService).filter(Boolean)};
  }

  /* ---------- dates ---------- */
  function day(iso) {
    var d = iso ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleDateString(undefined, {dateStyle: 'medium'}) : '';
  }
  /* the days from now to the end of a certificate: negative once it has ended */
  function daysLeft(iso) {
    var d = iso ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? Math.ceil((d.getTime() - Date.now()) / DAY) : null;
  }
  function ends(info) {
    var when = day(info.end);
    if (!when) { return t('sc_ends_unknown'); }
    var n = daysLeft(info.end);
    if (n === null) { return t('sc_ends', {when: when}); }
    if (n < 0) { return t('sc_ended', {when: when}); }
    return t(n === 1 ? 'sc_ends_in_one' : 'sc_ends_in', {when: when, n: n});
  }
  function sourcePill(info) {
    var cls = info.source === 'free' ? ' sig-pill--ok' : info.source === 'self-signed' ? ' sig-pill--warn' : '';
    return el('span', {class: 'sig-pill' + cls, text: info.source ? t('sc_source_' + info.source.replace('-', '_')) : t('sc_source_other')});
  }
  function endWarn(info) {
    var n = daysLeft(info.end);
    return n !== null && n <= SOON_DAYS;
  }

  /* ---------- the server's certificate and the free one ---------- */
  function certLines(info) {
    var rows = [['sc_names', info.names.length ? info.names.join(', ') : '—'], ['sc_issuer', info.issuer || '—']];
    var dl = el('dl', {class: 'fp-sc-facts', 'data-fp-sc-cert': ''});
    rows.forEach(function (r) { dl.appendChild(el('div', null, [el('dt', {text: t(r[0])}), el('dd', {text: r[1]})])); });
    dl.appendChild(el('div', null, [el('dt', {text: t('sc_ends_label')}), el('dd', {class: endWarn(info) ? 'fp-sc-soon' : '', 'data-fp-sc-ends': '', text: ends(info)})]));
    return dl;
  }
  function orderState(o, host) {
    if (!o.name) { return el('p', {class: 'fp-muted', 'data-fp-sc-state': '', text: t('sc_name_none', {host: host || '—'}) + (o.reason ? ' ' + o.reason : '')}); }
    var line = o.ordering ? t('sc_state_ordering') : !o.enabled ? t('sc_state_off') : o.reason || t('sc_state_idle');
    return el('p', {class: 'fp-muted', 'data-fp-sc-state': '', text: line});
  }
  function serverCard() {
    var st = S.st;
    var o = st.order;
    var parts = [M.errorLine(), M.statusLine()];
    if (st.panelsError) {
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-sc-panels': ''}, [UI.icon(FP.ui, 'ui_warning'),
        el('span', {text: t('sc_panels_error', {why: st.panelsError})})]));
    }
    parts.push(el('p', {class: 'fp-sc-host', 'data-fp-sc-host': ''}, [el('span', {class: 'sig-label', text: t('sc_host')}), el('span', {class: 'sig-mono', text: st.host || '—'})]));
    if (st.info) {
      parts.push(el('p', {class: 'fp-sc-source'}, [sourcePill(st.info)]));
      parts.push(certLines(st.info));
      if (st.info.source === 'self-signed') { parts.push(el('p', {class: 'fp-muted', 'data-fp-sc-selfsigned': '', text: t('sc_self_signed')})); }
    } else {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-sc-cert': '', text: t('sc_none')}));
    }
    parts.push(el('h3', {class: 'fp-h3', text: t('sc_free_title')}));
    parts.push(orderState(o, st.host));
    if (o.last) { parts.push(el('p', {class: 'fp-muted', 'data-fp-sc-last': '', text: t('sc_last', {when: BK.when(o.last) || o.last})})); }
    if (o.error) { parts.push(el('p', {class: 'fp-bk-bad', 'data-fp-sc-error': '', text: t('sc_last_error', {why: o.error})})); }
    var form = el('form', {class: 'fp-form fp-mail-form fp-sc-form', novalidate: '', 'data-fp-form': 'order'}, [M.errorLine(), M.statusLine(),
      el('label', {class: 'fp-check', for: 'fp-sc-enabled'}, [el('input', {type: 'checkbox', id: 'fp-sc-enabled', name: 'enabled', checked: o.enabled,
        'aria-describedby': 'fp-sc-enabled-hint'}), el('span', {text: t('sc_enabled')})]),
      el('span', {class: 'sig-hint fp-sc-hint', id: 'fp-sc-enabled-hint'}, FP.tools.ssl_auto ? [document.createTextNode(t('sc_enabled_hint') + ' ' + t('sc_enabled_link') + ' '),
        el('a', {href: '#/tool/ssl_auto', text: FP.tools.ssl_auto.label}), document.createTextNode('.')] : [document.createTextNode(t('sc_enabled_hint'))]),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary fp-submit', type: 'submit', text: t('sc_save')}),
        o.ordering ? (going() ? el('span', {class: 'fp-muted', 'data-fp-sc-going': '', text: t('sc_going')}) :
          el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'order', text: t('sc_order')})) : null])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      save(form);
    });
    parts.push(form);
    return M.card('fp-sc-server-h', t('sc_server_title'), parts, 'fp-sc-server');
  }

  /* ---------- the services ---------- */
  function showsPill(s) {
    if (!s.installed) { return el('span', {class: 'sig-pill', text: t('sc_not_installed')}); }
    var cls = s.shows === 'yes' ? ' sig-pill--ok' : s.shows === 'no' ? ' sig-pill--warn' : '';
    return el('span', {class: 'sig-pill' + cls, 'data-fp-shows': s.shows, text: t('sc_shows_' + s.shows.replace(' ', '_'))});
  }
  function serviceRow(s) {
    var certCell = !s.installed ? el('td', {class: 'fp-muted', text: '—'}) : s.info ? el('td', null, [sourcePill(s.info),
      el('span', {class: 'fp-sc-sub' + (endWarn(s.info) ? ' fp-sc-soon' : ''), text: ends(s.info)})]) : el('td', {class: 'fp-muted', text: t('sc_none_short')});
    return el('tr', {'data-fp-service': s.id}, [
      el('th', {scope: 'row', class: 'fp-sc-name'}, [document.createTextNode(s.label), s.ports.length ? el('span', {class: 'fp-sc-sub', text: t(s.ports.length === 1 ? 'sc_port' : 'sc_ports', {ports: s.ports.join(', ')})}) : null]),
      certCell, el('td', null, [showsPill(s)])]);
  }
  function servicesCard() {
    var list = S.st.services;
    var parts = [el('p', {class: 'fp-muted', text: t('sc_services_desc')})];
    if (!list.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('sc_services_none')}));
    } else {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-sc-services-h'}, [
        el('table', {class: 'sig-table fp-sc-table'}, [el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('sc_col_service')}),
          el('th', {scope: 'col', text: t('sc_col_cert')}), el('th', {scope: 'col', text: t('sc_col_shows')})])]),
        el('tbody', null, list.map(serviceRow))])]));
    }
    return M.card('fp-sc-services-h', t('sc_services_title'), parts, 'fp-sc-services');
  }

  function draw(keepFocus) {
    var active = document.activeElement;
    var oldS = S.page.querySelector('.fp-sc-server');
    var focus = keepFocus && oldS && oldS.contains(active) ? (active.getAttribute('data-fp-act') || active.id) : '';
    var fresh = serverCard();
    if (oldS) { oldS.replaceWith(fresh); } else { S.page.appendChild(fresh); }
    var oldV = S.page.querySelector('.fp-sc-services');
    var freshV = servicesCard();
    if (oldV) { oldV.replaceWith(freshV); } else { S.page.appendChild(freshV); }
    if (focus) {
      var again = fresh.querySelector('[data-fp-act="' + focus + '"]') || fresh.querySelector('#' + focus) || fresh.querySelector('#fp-sc-server-h');
      if (again) { again.focus(); }
    }
  }

  /* an order asked for goes on for a moment: the page looks every few seconds until the last attempt or the certificate has changed, or a
     half minute has passed (the server orders only when the server needs a free certificate, so an order can change nothing) */
  function going() { return Boolean(S.watch); }
  function signature(st) { return [st.order.last, st.order.error, st.info ? st.info.source + st.info.end : ''].join('|'); }
  function poll() {
    window.clearTimeout(S.timer);
    var mine = S;
    S.timer = window.setTimeout(function () {
      if (S !== mine || !document.body.contains(mine.page)) { return; }
      FP.call('get', 'svcCerts').then(function (r) {
        if (S !== mine || !mine.watch) { return; }
        var fresh = cleanState(r);
        var w = mine.watch;
        mine.st = fresh;
        w.tries += 1;
        if (signature(fresh) !== w.from || w.tries >= POLL_TRIES) {
          mine.watch = null;
          draw(true);
          M.say(mine.page.querySelector('.fp-sc-server'), signature(fresh) === w.from ? t('sc_order_unchanged') : fresh.order.error ? t('sc_order_failed', {why: fresh.order.error}) :
            t('sc_order_done', {source: fresh.info ? t('sc_source_' + fresh.info.source.replace('-', '_')).toLowerCase() : '—'}));
          return;
        }
        draw(true);
        poll();
      }, function () { if (S === mine && mine.watch && mine.watch.tries++ < POLL_TRIES) { poll(); } else if (S === mine) { mine.watch = null; draw(true); } });
    }, POLL_MS);
  }
  function save(form) {
    var b = M.start(form);
    if (!b) { return; }
    var mine = S;
    var on = form.querySelector('[name="enabled"]').checked;
    UI.setBusy(b, true);
    FP.call('put', 'svcCerts', {enabled: on}).then(function (r) {
      UI.setBusy(b, false);
      if (S !== mine) { return; }
      mine.st = cleanState(r);
      if (on && mine.st.order.ordering) { mine.watch = {from: signature(mine.st), tries: 0}; }
      draw(true);
      M.say(mine.page.querySelector('.fp-sc-form'), t(on ? 'sc_saved_on' : 'sc_saved_off'));
      if (mine.watch) { poll(); }
    }, function (err) {
      UI.setBusy(b, false);
      if (S !== mine) { return; }
      M.failed(form, err);
    });
  }
  function onClick(e) {
    var target = e.target && e.target.closest ? e.target : null;
    var b = target && S && S.page && S.page.contains(target) ? target.closest('[data-fp-act="order"]') : null;
    if (!b) { return; }
    var card = S.page.querySelector('.fp-sc-server');
    UI.showError(card, '');
    M.say(card, '');
    UI.setBusy(b, true);
    var mine = S;
    FP.call('post', 'svcCertsRenew').then(function (r) {
      if (S !== mine) { return; }
      var from = signature(mine.st);
      mine.st = cleanState(r);
      mine.watch = {from: from, tries: 0};
      draw(false);
      mine.page.querySelector('#fp-sc-server-h').focus();
      M.say(mine.page.querySelector('.fp-sc-server'), t('sc_order_asked'));
      poll();
    }, function (err) {
      if (S !== mine) { return; }
      UI.setBusy(b, false);
      UI.showError(card, err.message);
      b.focus();
    });
  }
  document.addEventListener('click', onClick);

  FP.view('tool:ssl_services', function () {
    var tool = FP.tools.ssl_services;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('sc_desc'), cls: 'fp-mail fp-sc',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    if (S) { window.clearTimeout(S.timer); }
    S = {page: body, st: cleanState(null), timer: 0, watch: null};
    var mine = S;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'svcCerts').then(function (r) {
      if (S !== mine) { return; }
      mine.st = cleanState(r);
      body.textContent = '';
      draw(false);
    }, function (err) {
      if (S !== mine) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

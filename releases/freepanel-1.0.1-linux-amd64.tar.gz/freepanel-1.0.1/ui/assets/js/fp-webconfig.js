/* freePanel web server pages, in the admin panel (docs/api.md, "PHP settings", the admin's part, and the web server's own
   values): PHP versions (#/tool/php_versions) lists the versions the server offers with what uses each, and sets the
   version new sites get and installs a version the server offers (a job it follows to its end); PHP settings (#/tool/php_config) sets, for one installed version, the values every pool of it
   starts with; Web server settings (#/tool/web_server) sets eight of Apache's own values for the whole server; Web server
   modules (#/tool/web_modules) turns the optional modules of Apache off and on. Nothing
   changes on the server until the admin saves. The server lists the settings it allows with their kind, built-in
   default and range, and says which the admin has saved; the page checks what is typed against that before it asks, and
   the server checks again. A saved change is tested and applied by the server before it answers, so the page keeps
   waiting for it. What the server sends is shown as text only. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var VERSION_RE = /^[0-9]{1,2}\.[0-9]{1,2}$/;
  var NAME_RE = /^[a-z][a-z0-9_.]{0,63}$/;
  var UNIT_RE = /^[a-z0-9_.@-]{1,64}$/;
  var KINDS = ['size', 'int', 'bool', 'choice'];
  var CHOICE_RE = /^[A-Za-z0-9_.-]{1,24}$/;
  var DIRECTIVE_RE = /^[A-Za-z][A-Za-z0-9]{0,40}$/;
  var UNIT_WORD_RE = /^[a-z ]{1,20}$/;
  var GROUPS = ['php', 'pool'];
  /* the version the settings page was last on, kept in the browser */
  var STORE_KEY = 'fp.php.version';

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function num(v) { return typeof v === 'number' && isFinite(v) ? v : 0; }
  function count(n) { return Math.round(n).toLocaleString('en'); }
  function isAdmin() { return FP.session.user.role === 'admin'; }
  function php(v) { return t('wc_php', {version: v}); }
  /* the tool's frame, or the page-not-found view for anyone it is not for */
  function frame(id, desc, cls) {
    var tool = FP.tools[id];
    if (!tool || FP.realm !== 'admin' || !isAdmin()) { FP.views['not-found']({view: 'not-found'}); return null; }
    var g = FP.group(tool.group);
    return FP.frame({title: tool.label, desc: desc, cls: 'fp-mail fp-wc ' + cls,
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
  }
  function banner(text, attr) {
    var b = el('div', {class: 'sig-banner sig-banner--warn', role: 'note'}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: text})]);
    if (attr) { b.setAttribute(attr, ''); }
    return b;
  }
  function problem(page, tool, err) {
    page.textContent = '';
    page.appendChild(FP.empty(tool.label, err.message));
  }

  /* what GET /web/php says: the versions offered, the one new sites get and whether an admin chose it */
  function cleanAdmin(r) {
    r = r && typeof r === 'object' ? r : {};
    var versions = (Array.isArray(r.versions) ? r.versions : []).filter(function (v) { return v && VERSION_RE.test(str(v.version)); }).map(function (v) {
      return {version: v.version, pkg: UNIT_RE.test(str(v.package)) ? v.package : '', service: UNIT_RE.test(str(v.service)) ? v.service : '',
        installed: v.installed === true, installable: v.installable === true, reason: str(v.reason, 400), sites: Math.round(Math.max(0, num(v.sites))), accounts: Math.round(Math.max(0, num(v.accounts))),
        customised: Math.round(Math.max(0, num(v.customised)))};
    });
    return {def: VERSION_RE.test(str(r.default)) ? r.default : '', saved: r.default_saved === true, warning: str(r.warning, 400), versions: versions};
  }
  function installed(d) { return d.versions.filter(function (v) { return v.installed; }); }

  /* ================= PHP versions ================= */
  var V = {page: null, data: null, job: null, timer: 0};
  var JOB_STATES = ['idle', 'running', 'succeeded', 'failed'];
  var POLL_MS = 3000;

  /* the latest install of a PHP version (GET /web/php/install, and the 202 of POST /web/php/{version}/install) */
  function cleanJob(r) {
    r = r && typeof r === 'object' ? r : {};
    return {state: JOB_STATES.indexOf(r.state) >= 0 ? r.state : 'idle', label: VERSION_RE.test(str(r.label)) ? r.label : '', ended: str(r.ended, 40),
      code: typeof r.exit_code === 'number' && isFinite(r.exit_code) ? Math.round(r.exit_code) : null, timedOut: r.timed_out === true,
      log: (Array.isArray(r.log) ? r.log : []).filter(function (l) { return typeof l === 'string'; }).slice(-200).map(function (l) { return l.slice(0, 400); }),
      truncated: r.log_truncated === true};
  }
  function running() { return Boolean(V.job && V.job.state === 'running'); }
  function when(iso) { return (FP.bk && FP.bk.when(iso)) || iso; }

  function defaultCard() {
    var d = V.data;
    var have = installed(d);
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-wc-now', 'data-fp-default': '',
      text: d.def ? t('wc_new_sites', {version: php(d.def)}) + ' ' + t(d.saved ? 'wc_chosen_you' : 'wc_chosen_install') : t('wc_new_sites_none')})];
    if (d.warning) { parts.push(banner(d.warning, 'data-fp-warning')); }
    if (!have.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('wc_none_installed')}));
      return M.card('fp-wc-default-h', t('wc_default_title'), parts, 'fp-wc-default');
    }
    var pick = el('select', {class: 'sig-select fp-wc-pick', id: 'fp-wc-version', name: 'version'}, have.map(function (v) {
      return el('option', {value: v.version, text: php(v.version)});
    }));
    if (have.some(function (v) { return v.version === d.def; })) { pick.value = d.def; }
    var form = el('form', {class: 'fp-form fp-wc-form', novalidate: ''}, [
      M.field('fp-wc-version', t('wc_pick_version'), pick, t('wc_pick_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('wc_use_for_new')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      setDefault(pick.value);
    });
    parts.push(form);
    return M.card('fp-wc-default-h', t('wc_default_title'), parts, 'fp-wc-default');
  }
  /* the error and status lines belong to the card, which holds the form */
  function setDefault(version) {
    var card = V.page.querySelector('.fp-wc-default');
    var b = M.start(card);
    if (!b) { return; }
    var d = V.data;
    /* a choice that was saved and is no longer installed is replaced even by the version shown, which is the install's */
    if (d.saved && !d.warning && version === d.def) {
      M.say(card, t('wc_nothing'));
      return;
    }
    UI.setBusy(b, true);
    FP.call('put', 'webPhpDefault', {version: version}).then(function (r) {
      V.data = cleanAdmin(r);
      render();
      M.say(V.page.querySelector('.fp-wc-default'), t('wc_default_saved', {version: php(version)}));
      V.page.querySelector('#fp-wc-default-h').focus();
    }, function (err) {
      UI.setBusy(b, false);
      M.failed(card, err);
    });
  }

  function statusCell(v) {
    var d = V.data;
    var pills = [el('span', {class: 'sig-pill' + (v.installed ? ' sig-pill--ok' : ''), text: t(v.installed ? 'wc_installed' : 'wc_not_installed')})];
    if (v.version === d.def) { pills.push(el('span', {class: 'sig-pill', text: t('wc_default_pill')})); }
    return el('td', null, [el('span', {class: 'fp-wc-pills'}, pills), !v.installed && !v.installable && v.reason ?
      el('span', {class: 'fp-muted fp-row-note fp-wc-reason', 'data-fp-reason': '', text: v.reason}) : null]);
  }
  function versionRow(v) {
    return el('tr', {'data-fp-version': v.version}, [
      el('th', {scope: 'row'}, [el('span', {text: php(v.version)}), v.service ? el('span', {class: 'fp-muted fp-wc-unit sig-mono', text: v.service}) : null]),
      statusCell(v),
      el('td', {class: 'fp-num', text: count(v.sites)}), el('td', {class: 'fp-num', text: count(v.accounts)}),
      el('td', {class: 'fp-num', text: v.customised ? count(v.customised) : '—'}),
      el('td', {class: 'fp-wc-acts'}, [v.installed ? el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'settings',
        'data-fp-version': v.version, 'aria-label': t('wc_settings_of', {version: php(v.version)}), text: t('wc_settings')}) : null,
      !v.installed && v.installable ? el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'install', 'data-fp-version': v.version,
        disabled: running() ? true : null, 'aria-label': t('wc_install_of', {version: php(v.version)}), text: t('wc_install')}) : null])]);
  }
  function versionsCard() {
    var d = V.data;
    var parts = [M.errorLine(), M.statusLine()];
    if (!d.versions.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('wc_no_versions')}));
    } else {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-wc-versions-h'}, [
        el('table', {class: 'sig-table fp-wc-table'}, [el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('wc_col_version')}),
          el('th', {scope: 'col', text: t('wc_col_status')}), el('th', {scope: 'col', class: 'fp-num', text: t('wc_col_sites')}),
          el('th', {scope: 'col', class: 'fp-num', text: t('wc_col_accounts')}), el('th', {scope: 'col', class: 'fp-num', text: t('wc_col_changed')}),
          el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]),
        el('tbody', null, d.versions.map(versionRow))])]));
    }
    parts.push(el('p', {class: 'fp-muted fp-wc-note', text: t('wc_install_note')}));
    return M.card('fp-wc-versions-h', t('wc_versions_title'), parts, 'fp-wc-versions');
  }
  function render() {
    V.page.textContent = '';
    V.page.appendChild(defaultCard());
    var job = jobCard();
    if (job) { V.page.appendChild(job); }
    V.page.appendChild(versionsCard());
  }

  /* ---- an install, followed until it ends ---- */
  function jobCard() {
    var j = V.job;
    if (!j || j.state === 'idle') { return null; }
    var v = j.label ? php(j.label) : t('wc_job_a_version');
    var parts = [];
    if (j.state === 'running') {
      parts.push(el('p', {class: 'fp-wc-now', 'data-fp-job-state': 'running', text: t('wc_job_running', {version: v})}));
      parts.push(el('p', {class: 'fp-muted', text: t('wc_job_running_hint')}));
    } else if (j.state === 'succeeded') {
      parts.push(el('p', {class: 'fp-wc-now', 'data-fp-job-state': 'succeeded', text: t('wc_job_done', {version: v})}));
      parts.push(el('p', {class: 'fp-muted', text: t('wc_job_done_hint') + (j.ended ? ' ' + t('wc_job_ended', {when: when(j.ended)}) : '')}));
    } else {
      var why = j.timedOut ? t('wc_job_timed_out') : (j.code === null ? t('wc_job_cut_off') : t('wc_job_code', {code: String(j.code)}));
      parts.push(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-job-state': 'failed'}, [UI.icon(FP.ui, 'ui_warning'),
        el('span', {text: t('wc_job_failed', {version: v}) + ' ' + why})]));
      if (j.ended) { parts.push(el('p', {class: 'fp-muted', text: t('wc_job_ended', {when: when(j.ended)})})); }
    }
    if (j.log.length) {
      parts.push(el('pre', {class: 'fp-wc-log sig-mono', tabindex: '0', 'data-fp-job-log': '', 'aria-label': t('wc_job_log'), text: j.log.join('\n')}));
      if (j.truncated) { parts.push(el('p', {class: 'fp-muted', text: t('wc_job_truncated')})); }
    }
    return M.card('fp-wc-job-h', t('wc_job_title'), parts, 'fp-wc-job');
  }
  /* the job card as it is now; a log being read keeps the focus, and a running log shows its end */
  function drawJob() {
    var old = V.page.querySelector('.fp-wc-job');
    var fresh = jobCard();
    var active = document.activeElement;
    var inLog = Boolean(old && active && active.hasAttribute && active.hasAttribute('data-fp-job-log') && old.contains(active));
    if (!fresh) { if (old) { old.remove(); } return; }
    if (old) { old.replaceWith(fresh); } else { V.page.insertBefore(fresh, V.page.querySelector('.fp-wc-versions')); }
    var log = fresh.querySelector('[data-fp-job-log]');
    if (log && running()) { log.scrollTop = log.scrollHeight; }
    if (inLog && log) { log.focus(); }
  }
  function follow() {
    window.clearTimeout(V.timer);
    var mine = V.page;
    V.timer = window.setTimeout(function () {
      if (V.page !== mine || !document.body.contains(mine)) { return; }
      FP.call('get', 'webPhpInstall').then(function (r) {
        if (V.page !== mine) { return; }
        V.job = cleanJob(r);
        if (running()) { drawJob(); follow(); return; }
        ended(mine);
      }, function () { if (V.page === mine) { follow(); } });
    }, POLL_MS);
  }
  /* the install has ended: the list of versions is read again, since the version is installed now, and the page says how it ended */
  function ended(mine) {
    var j = V.job;
    var done = function () {
      if (V.page !== mine) { return; }
      render();
      UI.announce(j.state === 'succeeded' ? t('wc_job_done', {version: j.label ? php(j.label) : t('wc_job_a_version')}) : t('wc_job_failed', {version: j.label ? php(j.label) : t('wc_job_a_version')}));
    };
    FP.call('get', 'webPhp').then(function (r) {
      if (V.page !== mine) { return; }
      V.data = cleanAdmin(r);
      done();
    }, done);
  }
  function install(b) {
    var version = b.getAttribute('data-fp-version');
    var card = V.page.querySelector('.fp-wc-versions');
    UI.showError(card, '');
    M.say(card, '');
    var mine = V.page;
    UI.setBusy(b, true);
    FP.call('post', 'webPhpInstallOf', undefined, {version: version}).then(function (r) {
      if (V.page !== mine) { return; }
      V.job = cleanJob(r);
      render();
      M.say(V.page.querySelector('.fp-wc-versions'), t('wc_install_started', {version: php(version)}));
      var h = V.page.querySelector('#fp-wc-job-h');
      if (h) { h.focus(); }
      if (running()) { follow(); }
    }, function (err) {
      if (V.page !== mine) { return; }
      UI.setBusy(b, false);
      UI.showError(card, err.message);
      b.focus();
    });
  }
  function onVersionsClick(e) {
    var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !V.page || !V.page.contains(b)) { return; }
    var act = b.getAttribute('data-fp-act');
    if (act === 'install') {
      install(b);
      return;
    }
    if (act !== 'settings') { return; }
    UI.store.set(STORE_KEY, b.getAttribute('data-fp-version'));
    window.location.hash = '#/tool/php_config';
  }
  FP.view('tool:php_versions', function () {
    window.clearTimeout(V.timer);
    V.page = null;
    V.job = null;
    var body = frame('php_versions', t('wc_versions_desc'), 'fp-wc-versions-page');
    if (!body) { return; }
    V.page = body;
    body.addEventListener('click', onVersionsClick);
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'webPhp').then(function (r) {
      if (V.page !== body) { return; }
      V.data = cleanAdmin(r);
      /* the latest install, if there is one: a server that cannot say leaves the page without it */
      return FP.call('get', 'webPhpInstall').then(function (j) { return cleanJob(j); }, function () { return null; });
    }).then(function (job) {
      if (V.page !== body || !V.data) { return; }
      V.job = job;
      render();
      if (running()) { follow(); }
    }, function (err) {
      if (V.page === body) { problem(body, FP.tools.php_versions, err); }
    });
  });

  /* ================= The settings form, for PHP and for Apache ================= */
  /* One form of settings drawn into a card of the page. cfg says where the settings come from (get, put) and which words
     go with them (names, descs: string-key prefixes tried in turn; words: the keys of the messages; id: the prefix of the
     element ids; groups: the kinds to show under headings, or none). */
  function cleanSettings(r) {
    r = r && typeof r === 'object' ? r : {};
    var list = (Array.isArray(r.settings) ? r.settings : []).filter(function (s) {
      return s && NAME_RE.test(str(s.name)) && KINDS.indexOf(s.kind) >= 0;
    }).map(function (s) {
      var choices = (Array.isArray(s.choices) ? s.choices : []).filter(function (c) { return typeof c === 'string' && CHOICE_RE.test(c); }).slice(0, 20);
      return {name: s.name, kind: s.kind, group: GROUPS.indexOf(s.group) >= 0 ? s.group : 'php', def: str(s.default, 40), min: Math.max(0, num(s.min)),
        max: Math.max(0, num(s.max)), step: Math.max(0, Math.round(num(s.step))), unit: UNIT_WORD_RE.test(str(s.unit)) ? s.unit : '',
        directive: DIRECTIVE_RE.test(str(s.directive)) ? s.directive : '', choices: choices, minusOne: s.minus_one === true, value: str(s.value, 40), set: s.set === true,
        note: str(s.note, 400)};
    }).filter(function (s) { return s.kind !== 'choice' || s.choices.length; });
    return {version: str(r.version), installed: r.installed !== false, settings: list};
  }
  /* bytes as PHP writes them: the largest unit that divides them */
  function showSize(n) {
    if (n >= 1073741824 && n % 1073741824 === 0) { return n / 1073741824 + 'G'; }
    if (n >= 1048576 && n % 1048576 === 0) { return n / 1048576 + 'M'; }
    if (n >= 1024 && n % 1024 === 0) { return n / 1024 + 'K'; }
    return String(n);
  }
  function showLimit(s, n) { return s.kind === 'size' ? showSize(n) : String(n); }
  /* the bytes of a size with its unit, such as 512M, or -1 when it isn't one */
  function sizeBytes(v) {
    var m = /^([1-9][0-9]{0,8})([KkMmGg])$/.exec(v);
    if (!m) { return -1; }
    return Number(m[1]) * ({k: 1024, m: 1048576, g: 1073741824}[m[2].toLowerCase()]);
  }
  function key(s) { return s.name.replace(/\./g, '_'); }
  /* the first string a prefix list has for the setting, else the fallback */
  function words(prefixes, s, fallback) {
    for (var i = 0; i < prefixes.length; i++) {
      var k = prefixes[i] + key(s);
      if (t(k) !== k) { return t(k); }
    }
    return fallback;
  }
  /* what the limits of a setting say, in words */
  function range(s) {
    var p = {min: showLimit(s, s.min), max: showLimit(s, s.max), unit: s.unit};
    var text = s.unit ? t('wc_range_unit', p) : s.minusOne ? t('phps_range_minus', p) : t('phps_range', p);
    return s.step > 1 ? text + ' ' + t('wc_step', {step: String(s.step)}) : text;
  }

  function settingsForm(cfg) {
    var F = {state: null, problem: '', loads: 0};
    function label(s) { return words(cfg.names, s, s.name); }
    function idOf(s) { return cfg.id + '-' + key(s); }

    /* what is typed for a setting, as the server takes it: the text, or null with a message on the form when it can't do */
    function read(form, s) {
      var f = UI.fieldNamed(form, s.name);
      var v = f.value.trim();
      var p = {label: label(s), min: showLimit(s, s.min), max: showLimit(s, s.max), step: String(s.step)};
      if (s.kind === 'bool' || s.kind === 'choice') { return v; }
      if (s.kind === 'size') {
        var bytes = sizeBytes(v);
        if (bytes < 0) { M.fieldError(form, f, t('wc_bad_size', p)); return null; }
        if (bytes < s.min || bytes > s.max) { M.fieldError(form, f, t('phps_out_of_range', p)); return null; }
        return v;
      }
      if (!/^-?(0|[1-9][0-9]{0,11})$/.test(v)) { M.fieldError(form, f, t('phps_bad_int', p)); return null; }
      if (!(s.minusOne && v === '-1') && (Number(v) < s.min || Number(v) > s.max)) { M.fieldError(form, f, t(s.minusOne ? 'phps_out_of_range_minus' : 'phps_out_of_range', p)); return null; }
      if (s.step > 1 && Number(v) % s.step !== 0) { M.fieldError(form, f, t('wc_bad_step', p)); return null; }
      return v;
    }
    /* an error from the server: the message, and the setting it names marked */
    function failed(form, err) {
      var name = err && typeof err.field === 'string' ? err.field.replace(/^settings\./, '') : '';
      var f = name ? UI.fieldNamed(form, name) : null;
      var l = f ? form.querySelector('label[for="' + f.id + '"]') : null;
      M.fieldError(form, f, (l ? l.firstChild.textContent.trim() + ': ' : '') + (err ? err.message : t('api_failed')));
    }

    function control(s, id) {
      var c;
      if (s.kind === 'bool' || s.kind === 'choice') {
        var options = s.kind === 'bool' ? ['On', 'Off'] : s.choices;
        c = el('select', {class: 'sig-select fp-phps-val', id: id, name: s.name, 'aria-describedby': describedBy(s, id)}, options.map(function (v) {
          return el('option', {value: v, text: v});
        }));
        c.value = options.indexOf(s.value) >= 0 ? s.value : s.def;
      } else {
        c = el('input', {class: 'sig-input sig-mono fp-phps-val', id: id, name: s.name, type: 'text', value: s.value, maxlength: '12',
          autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', 'aria-describedby': describedBy(s, id)});
        if (s.kind === 'int') { c.setAttribute('inputmode', 'numeric'); }
      }
      /* what the field shows is what it was: a select shows the default when the server sent a value it has no option for */
      c.setAttribute('data-fp-was', s.kind === 'bool' || s.kind === 'choice' ? c.value : s.value);
      return c;
    }
    /* a setting's hint, and its note when the server sends one */
    function describedBy(s, id) { return id + '-hint' + (s.note ? ' ' + id + '-note' : ''); }
    function row(s) {
      var id = idOf(s);
      var plain = s.kind === 'bool' || s.kind === 'choice';
      var hint = [words(cfg.descs, s, ''), t('phps_default', {value: s.def}) + (plain ? '' : ' ' + range(s)), s.kind === 'size' ? t('wc_size_hint') : ''].filter(Boolean).join(' ');
      var pill = s.set ? el('span', {class: 'sig-pill sig-pill--ok', text: t(cfg.words.set)}) : el('span', {class: 'sig-pill', text: t(cfg.words.builtin)});
      var reset = s.set ? el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'reset', 'data-fp-setting': s.name,
        'aria-label': t(cfg.words.resetFor, {setting: label(s)}), text: t(cfg.words.reset)}) : null;
      return el('div', {class: 'sig-field fp-phps-row', 'data-fp-setting': s.name}, [
        el('label', {class: 'sig-label', for: id}, [document.createTextNode(label(s)), el('span', {class: 'fp-phps-name sig-mono', text: s.directive || s.name})]),
        control(s, id), el('span', {class: 'sig-hint', id: id + '-hint', text: hint}),
        s.note ? el('span', {class: 'sig-hint fp-wc-rownote', id: id + '-note', 'data-fp-note': '', text: s.note}) : null,
        el('div', {class: 'fp-phps-state'}, [pill, reset])]);
    }
    function group(name, list) {
      if (!list.length) { return null; }
      return el('div', {class: 'fp-wc-group', 'data-fp-group': name}, [el('h3', {class: 'fp-h3', text: t('wc_group_' + name)}),
        el('p', {class: 'fp-muted', text: t('wc_group_' + name + '_hint')}), el('div', {class: 'fp-phps-grid'}, list.map(row))]);
    }
    function card() {
      var body = [el('h2', {class: 'fp-h2', id: cfg.id + '-form-h', tabindex: '-1', text: cfg.title()})];
      if (!F.state) {
        /* loading, or the server's word on why the settings can't be shown */
        body.push(F.problem ? M.errorLine() : el('p', {class: 'fp-muted', text: t('loading')}));
      } else {
        var s = F.state.settings;
        var parts = cfg.groups ? cfg.groups.map(function (g) { return group(g, s.filter(function (x) { return x.group === g; })); }) :
          [el('div', {class: 'fp-phps-grid'}, s.map(row))];
        var form = el('form', {class: 'fp-form fp-wc-form', novalidate: ''}, [M.errorLine(), M.statusLine()].concat(parts, [
          el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('wc_save')})])]));
        form.addEventListener('submit', function (e) {
          e.preventDefault();
          save(form);
        });
        body.push(el('p', {class: 'fp-muted', text: t(cfg.note)}), form);
      }
      var node = el('section', {class: 'sig-card fp-wc-card fp-wc-settings', 'aria-labelledby': cfg.id + '-form-h'}, [el('div', {class: 'sig-card-body'}, body)]);
      if (F.problem) { UI.showError(node, F.problem); }
      return node;
    }
    /* the settings card as it is now, with the answer to the last save or reset in its status line */
    function show(note, focus) {
      var page = cfg.page();
      var old = page.querySelector('.fp-wc-settings');
      var node = card();
      if (old) { page.replaceChild(node, old); } else { page.appendChild(node); }
      if (note) { M.say(node, note); }
      if (focus) {
        var f = typeof focus === 'string' ? UI.fieldNamed(node, focus) : node.querySelector('#' + cfg.id + '-form-h');
        if (f) { f.focus(); }
      }
      return node;
    }

    function save(form) {
      var b = M.start(form);
      if (!b) { return; }
      var body = {};
      var changed = 0;
      for (var i = 0; i < F.state.settings.length; i++) {
        var s = F.state.settings[i];
        var f = UI.fieldNamed(form, s.name);
        if (!f || f.value.trim() === f.getAttribute('data-fp-was')) { continue; }
        var v = read(form, s);
        if (v === null) { return; }
        body[s.name] = v;
        changed++;
      }
      if (!changed) {
        M.say(form, t('wc_nothing'));
        return;
      }
      UI.setBusy(b, true);
      var mine = F.loads;
      var done = cfg.saved();
      cfg.put({settings: body}).then(function (r) {
        if (mine !== F.loads) { return; }
        F.state = cleanSettings(r);
        show(done, true);
      }, function (err) {
        UI.setBusy(b, false);
        failed(form, err);
      });
    }
    /* what is typed in rows whose value is not the one the server sent, by setting name */
    function typed(form) {
      var out = {};
      F.state.settings.forEach(function (s) {
        var f = UI.fieldNamed(form, s.name);
        if (f && f.value !== f.getAttribute('data-fp-was')) { out[s.name] = f.value; }
      });
      return out;
    }
    function reset(name, b) {
      var form = cfg.page().querySelector('.fp-wc-form');
      var s = F.state.settings.filter(function (x) { return x.name === name; })[0];
      if (!form || !s) { return; }
      var keep = typed(form);
      delete keep[name];
      var put = {};
      put[name] = null;
      UI.showError(form, '');
      M.say(form, '');
      UI.setBusy(b, true);
      var mine = F.loads;
      var done = cfg.resetDone(label(s));
      cfg.put({settings: put}).then(function (r) {
        if (mine !== F.loads) { return; }
        F.state = cleanSettings(r);
        var node = show(done, name);
        Object.keys(keep).forEach(function (k) {
          var f = UI.fieldNamed(node, k);
          if (f) { f.value = keep[k]; }
        });
      }, function (err) {
        UI.setBusy(b, false);
        failed(form, err);
      });
    }
    F.onClick = function (e) {
      var page = cfg.page();
      var b = e.target.closest ? e.target.closest('[data-fp-act="reset"]') : null;
      if (!b || !page || !page.contains(b)) { return; }
      reset(b.getAttribute('data-fp-setting'), b);
    };
    F.load = function () {
      var mine = ++F.loads;
      F.state = null;
      F.problem = '';
      show('', false);
      cfg.get().then(function (r) {
        if (mine !== F.loads) { return; }
        F.state = cleanSettings(r);
        show('', false);
      }, function (err) {
        if (mine !== F.loads) { return; }
        F.problem = err.message;
        show('', false);
      });
    };
    return F;
  }

  /* ================= PHP settings ================= */
  var C = {page: null, admin: null, version: '', form: null};
  C.form = settingsForm({
    id: 'fp-wc', groups: GROUPS, names: ['wc_n_', 'phps_n_'], descs: ['wc_d_', 'phps_d_'], note: 'wc_settings_note',
    words: {set: 'wc_set_pill', builtin: 'wc_builtin_pill', reset: 'wc_reset', resetFor: 'wc_reset_for'},
    page: function () { return C.page; },
    title: function () { return t('wc_settings_title', {version: php(C.version)}); },
    get: function () { return FP.call('get', 'webPhpSettings', undefined, {version: C.version}); },
    put: function (body) { return FP.call('put', 'webPhpSettings', body, {version: C.version}); },
    saved: function () { return t('wc_saved', {version: php(C.version)}); },
    resetDone: function (setting) { return t('wc_reset_done', {setting: setting, version: php(C.version)}); }
  });

  function versionCard() {
    var have = installed(C.admin);
    var pick = el('select', {class: 'sig-select fp-wc-pick', id: 'fp-wc-which', 'aria-describedby': 'fp-wc-which-hint'}, have.map(function (v) {
      return el('option', {value: v.version, text: php(v.version)});
    }));
    pick.value = C.version;
    pick.addEventListener('change', function () {
      C.version = pick.value;
      UI.store.set(STORE_KEY, C.version);
      C.form.load();
    });
    return M.card('fp-wc-which-h', t('wc_which_title'), [el('div', {class: 'sig-field fp-wc-which'}, [
      el('label', {class: 'sig-label', for: 'fp-wc-which', text: t('wc_which')}), pick, el('span', {class: 'sig-hint', id: 'fp-wc-which-hint', text: t('wc_which_hint')})])]);
  }
  /* the version to open on: the one remembered, else the one new sites get, else the newest installed */
  function firstVersion(d) {
    var have = installed(d).map(function (v) { return v.version; });
    var want = [UI.store.get(STORE_KEY), d.def];
    for (var i = 0; i < want.length; i++) {
      if (have.indexOf(want[i]) >= 0) { return want[i]; }
    }
    return have.length ? have[have.length - 1] : '';
  }

  FP.view('tool:php_config', function () {
    C.page = null;
    C.form.loads++;
    var body = frame('php_config', t('wc_config_desc'), 'fp-wc-config-page');
    if (!body) { return; }
    C.page = body;
    body.addEventListener('click', C.form.onClick);
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'webPhp').then(function (r) {
      if (C.page !== body) { return; }
      C.admin = cleanAdmin(r);
      C.version = firstVersion(C.admin);
      body.textContent = '';
      if (!C.version) {
        body.appendChild(FP.empty(t('wc_none_title'), t('wc_none_installed')));
        return;
      }
      body.appendChild(versionCard());
      C.form.load();
    }, function (err) {
      if (C.page === body) { problem(body, FP.tools.php_config, err); }
    });
  });

  /* ================= Web server settings (Apache's values) ================= */
  var A = {page: null, form: null};
  A.form = settingsForm({
    id: 'fp-ws', groups: null, names: ['ws_n_'], descs: ['ws_d_'], note: 'ws_note',
    words: {set: 'ws_set_pill', builtin: 'ws_builtin_pill', reset: 'ws_reset', resetFor: 'ws_reset_for'},
    page: function () { return A.page; },
    title: function () { return t('ws_title'); },
    get: function () { return FP.call('get', 'webApache'); },
    put: function (body) { return FP.call('put', 'webApache', body); },
    saved: function () { return t('ws_saved'); },
    resetDone: function (setting) { return t('ws_reset_done', {setting: setting}); }
  });
  FP.view('tool:web_server', function () {
    A.page = null;
    A.form.loads++;
    var body = frame('web_server', t('ws_desc'), 'fp-ws-page');
    if (!body) { return; }
    A.page = body;
    body.addEventListener('click', A.form.onClick);
    A.form.load();
  });

  /* ================= Web server modules ================= */
  var MODULE_RE = /^[a-z][a-z0-9_]{0,63}$/;
  var MPM_RE = /^[a-z][a-z0-9_]{0,23}$/;
  var W = {page: null, data: null, also: []};

  function strings(v, re, n, max) {
    return (Array.isArray(v) ? v : []).filter(function (x) { return typeof x === 'string' && (!re || re.test(x)) && x.length <= (max || 400); }).slice(0, n);
  }
  /* what GET and PUT /web/apache/modules say: every module with whether Apache loads it, whether the files do, and whether the panel may switch it */
  function cleanModules(r) {
    r = r && typeof r === 'object' ? r : {};
    var mods = (Array.isArray(r.modules) ? r.modules : []).filter(function (m) { return m && MODULE_RE.test(str(m.name)); }).slice(0, 300).map(function (m) {
      return {name: m.name, title: str(m.title, 80) || m.name, purpose: str(m.purpose, 300), loaded: m.loaded === true, enabled: m.enabled === true,
        file: str(m.file, 200), switchable: m.switchable === true, reason: str(m.reason, 300), requiredBy: strings(m.required_by, null, 12),
        needs: strings(m.needs, MODULE_RE, 12, 64)};
    });
    return {mpm: MPM_RE.test(str(r.mpm, 24)) ? r.mpm : '', warning: str(r.warning, 400), modules: mods, also: strings(r.also, MODULE_RE, 32, 64)};
  }
  function titleOf(name) {
    var m = W.data.modules.filter(function (x) { return x.name === name; })[0];
    return m ? m.title : name;
  }
  function names(list) { return list.map(titleOf).join(', '); }
  function moduleId(m) { return 'fp-wm-' + m.name; }

  /* the state of a module: what the files say, and, while Apache has not reloaded, what it still does */
  function stateCol(m) {
    /* a module the panel does not switch is shown as Apache has it; the files' word matters only for one it does */
    if (!m.switchable) {
      return el('div', {class: 'fp-wm-state'}, [el('span', {class: 'sig-pill' + (m.loaded ? ' sig-pill--ok' : ''), text: t(m.loaded ? 'wm_loaded' : 'wm_not_loaded')})]);
    }
    var kids = [el('span', {class: 'sig-pill' + (m.enabled ? ' sig-pill--ok' : ''), text: t(m.enabled ? 'wm_on' : 'wm_off')})];
    if (m.enabled && !m.loaded) { kids.push(el('span', {class: 'fp-muted fp-row-note', 'data-fp-pending': '', text: t('wm_pending_on')})); }
    if (!m.enabled && m.loaded) { kids.push(el('span', {class: 'fp-muted fp-row-note', 'data-fp-pending': '', text: t('wm_pending_off')})); }
    return el('div', {class: 'fp-wm-state'}, kids);
  }
  function moduleRow(m) {
    var id = moduleId(m);
    var sub = [el('span', {class: 'fp-muted sig-mono fp-wm-name', text: m.name})];
    var described = [];
    if (m.purpose) {
      sub.push(el('span', {class: 'sig-hint', id: id + '-purpose', text: m.purpose}));
      described.push(id + '-purpose');
    }
    if (m.switchable && m.needs.length) {
      sub.push(el('span', {class: 'sig-hint', id: id + '-needs', 'data-fp-needs': '', text: t('wm_needs', {names: names(m.needs)})}));
      described.push(id + '-needs');
    }
    if (!m.switchable) {
      var why = m.reason || (m.requiredBy.length ? t('wm_kept') : '');
      if (why) { sub.push(el('span', {class: 'sig-hint', 'data-fp-why': '', text: why})); }
      if (m.requiredBy.length) { sub.push(el('span', {class: 'sig-hint', 'data-fp-required': '', text: t('wm_required_by', {list: m.requiredBy.join('; ')})})); }
    }
    if (m.file) { sub.push(el('span', {class: 'sig-hint fp-wm-file', text: t('wm_file', {file: m.file})})); }
    var head;
    if (m.switchable) {
      var box = el('input', {type: 'checkbox', id: id, name: m.name, checked: m.enabled, 'data-fp-was': m.enabled ? 'on' : 'off'});
      if (described.length) { box.setAttribute('aria-describedby', described.join(' ')); }
      head = el('label', {class: 'fp-check fp-wm-title', for: id}, [box, el('span', {text: m.title})]);
    } else {
      head = el('span', {class: 'fp-wm-title', text: m.title});
    }
    return el('li', {class: 'fp-wm-row' + (m.switchable ? ' fp-wm-row--switch' : ''), 'data-fp-module': m.name},
      [el('div', {class: 'fp-wm-main'}, [head, el('div', {class: 'fp-wm-sub'}, sub)]), stateCol(m)]);
  }
  function optionalCard() {
    var d = W.data;
    var opt = d.modules.filter(function (m) { return m.switchable; });
    var body = [el('p', {class: 'fp-muted', text: t('wm_note')})];
    if (d.mpm) { body.push(el('p', {class: 'fp-muted', 'data-fp-mpm': '', text: t('wm_mpm', {mpm: d.mpm})})); }
    if (d.warning) { body.push(banner(d.warning, 'data-fp-warning')); }
    if (!opt.length) {
      body.push(M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', 'data-fp-none': '', text: t('wm_none')}));
      return M.card('fp-wm-optional-h', t('wm_title'), body, 'fp-wm-optional');
    }
    var form = el('form', {class: 'fp-form fp-wm-form', novalidate: ''}, [M.errorLine(), M.statusLine(), el('ul', {class: 'fp-wm-list'}, opt.map(moduleRow)),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('wc_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      saveModules(form);
    });
    body.push(form);
    return M.card('fp-wm-optional-h', t('wm_title'), body, 'fp-wm-optional');
  }
  function fixedCard() {
    var fixed = W.data.modules.filter(function (m) { return !m.switchable; });
    if (!fixed.length) { return null; }
    return M.card('fp-wm-fixed-h', t('wm_fixed_title'), [el('p', {class: 'fp-muted', text: t('wm_fixed_note')}), el('ul', {class: 'fp-wm-list'}, fixed.map(moduleRow))], 'fp-wm-fixed');
  }
  function drawModules(note) {
    W.page.textContent = '';
    var card = optionalCard();
    W.page.appendChild(card);
    var fixed = fixedCard();
    if (fixed) { W.page.appendChild(fixed); }
    if (note) {
      M.say(card, note);
      card.querySelector('#fp-wm-optional-h').focus();
    }
  }
  /* the modules whose box was changed since they were drawn, as the server takes them */
  function changedModules(form) {
    var out = {};
    var n = 0;
    W.data.modules.forEach(function (m) {
      var f = m.switchable ? UI.fieldNamed(form, m.name) : null;
      if (f && f.checked !== (f.getAttribute('data-fp-was') === 'on')) {
        out[m.name] = f.checked;
        n++;
      }
    });
    return n ? out : null;
  }
  function saveModules(form) {
    var b = M.start(form);
    if (!b) { return; }
    var body = changedModules(form);
    if (!body) {
      M.say(form, t('wc_nothing'));
      return;
    }
    var mine = W.page;
    UI.setBusy(b, true);
    FP.call('put', 'webApacheModules', {modules: body}).then(function (r) {
      if (W.page !== mine) { return; }
      W.data = cleanModules(r);
      drawModules(t('wm_saved') + (W.data.also.length ? ' ' + t('wm_also', {names: names(W.data.also)}) : ''));
    }, function (err) {
      UI.setBusy(b, false);
      if (W.page !== mine) { return; }
      var f = err && typeof err.field === 'string' ? UI.fieldNamed(form, err.field.replace(/^modules\./, '')) : null;
      if (f) { M.fieldError(form, f, titleOf(f.name) + ': ' + err.message); } else { M.failed(form, err); }
    });
  }
  FP.view('tool:web_modules', function () {
    W.page = null;
    var body = frame('web_modules', t('wm_desc'), 'fp-wm-page');
    if (!body) { return; }
    W.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'webApacheModules').then(function (r) {
      if (W.page !== body) { return; }
      W.data = cleanModules(r);
      drawModules('');
    }, function (err) {
      if (W.page === body) { problem(body, FP.tools.web_modules, err); }
    });
  });
})();

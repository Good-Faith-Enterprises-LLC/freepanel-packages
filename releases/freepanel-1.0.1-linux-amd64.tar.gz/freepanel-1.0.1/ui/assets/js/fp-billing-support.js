/* freePanel billing support desk (docs/api.md, "Billing: support desk"; docs/billing/navigation-map.md, "Support"): three tools of the Support
   group's first tool. Tickets (#/tool/billing_tickets) lists the tickets, waiting on staff first, filtered by status (active ones at first), department,
   priority, who has it and client; a ticket opens on the same page with its conversation oldest first (staff notes marked), a reply box with
   the canned replies and files, Note instead of reply, and beside it the ticket's status, priority, department, who has it and the client's
   services. Open ticket starts one for a client. A file on a message is a download, never shown in the panel. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;
  var M = FP.mail;

  var STATUSES = ['open', 'customer_reply', 'answered', 'on_hold', 'closed'];
  var PRIOS = ['low', 'medium', 'high'];
  var FILE_RE = /^[A-Za-z0-9][A-Za-z0-9 ._()-]{0,99}$/;
  var TICKET = {id: 'id', customer_id: 'id', department_id: 'id', subject: [150], status: ['=', STATUSES], priority: ['=', PRIOS], assigned_to: [64], last_reply_by: [64],
    last_reply: 'w', closed: 'w', created: 'w'};
  function cleanTicket(x) {
    var k = B.pick(x, TICKET);
    if (!k || !k.id) { return null; }
    k.messages = (x && Array.isArray(x.messages) ? x.messages : []).map(function (m) {
      var c = B.pick(m, {id: 'id', author_kind: ['=', ['staff', 'customer', 'system']], author_name: [100], body: [20000], internal: 'b', created: 'w'});
      if (!c || !c.id) { return null; }
      c.attachments = B.pickAll(m.attachments, {id: 'id', message_id: 'id', name: [100], size: 'n'}, 'id').filter(function (a) { return FILE_RE.test(a.name); });
      return c;
    }).filter(Boolean);
    return k;
  }
  function cleanDepartments(r) { return B.pickAll(r && r.departments, {id: 'id', name: [60], description: [200], hidden: 'b', tickets: 'n'}, 'id'); }
  function cleanCanned(r) { return B.pickAll(r && r.canned, {id: 'id', title: [80], body: [20000], department_id: 'id'}, 'id'); }
  function size(n) { return n === null ? '—' : n < 1024 ? t('bsp_bytes', {n: B.num(n)}) : n < 1048576 ? t('bsp_kb', {n: (n / 1024).toFixed(1)}) : t('bsp_mb', {n: (n / 1048576).toFixed(1)}); }

  /* ================= Tickets ================= */
  var K = null;
  function deptName(did) { for (var i = 0; i < K.departments.length; i++) { if (K.departments[i].id === did) { return K.departments[i].name; } } return '—'; }
  function lister() {
    var mine = K;
    var L = B.lister({page: K.page, pre: 'fp-btk', title: t('btk_list_title'), findLabel: t('btk_find'), tableCls: 'fp-btk-table', alive: function () { return K === mine && K.page.isConnected; },
      before: function () { return [el('div', {class: 'fp-bil-toolbar'}, [B.button('new', t('btk_open'), 'sig-btn--primary')]), el('p', {class: 'fp-muted fp-row-note', text: t('btk_order')})]; },
      blank: {status: '', department: '', priority: '', assigned_to: '', customer: ''}, start: {status: 'active'},
      filters: [
        {name: 'status', label: t('btk_f_status'), control: function (v) { return B.select('fp-btk-f-status', 'status', [['', t('bil_any')], ['active', t('btk_active')]].concat(STATUSES.map(function (s) { return [s, B.word('ticket', s)]; })), v); }},
        {name: 'department', label: t('btk_f_dept'), control: function (v) { return B.select('fp-btk-f-department', 'department', [['', t('bil_any')]].concat(K.departments.map(function (d) { return [String(d.id), d.name]; })), v); }},
        {name: 'priority', label: t('btk_f_prio'), control: function (v) { return B.select('fp-btk-f-priority', 'priority', [['', t('bil_any')]].concat(PRIOS.map(function (p) { return [p, B.word('prio', p)]; })), v); }},
        {name: 'assigned_to', label: t('btk_f_assigned'), hint: t('btk_f_assigned_hint'), control: function (v) { return B.input('fp-btk-f-assigned_to', 'assigned_to', v, {maxlength: '64', spellcheck: 'false', autocapitalize: 'none'}); }},
        {name: 'customer', control: function (v) { return B.clientPicker('fp-btk-f-client', {name: 'customer', label: t('btk_f_client'), placeholder: t('bil_any'), value: v, valueName: v ? K.names[v] : ''}); }}],
      load: function (f, offset, limit) {
        return B.listOf('billingTickets', {limit: String(limit), offset: String(offset), status: f.status, department: f.department, priority: f.priority, assigned_to: f.assigned_to, customer: f.customer}, 'tickets', cleanTicket).then(function (r) {
          return B.namesFor(K.names, r.items.map(function (x) { return x.customer_id; })).then(function () { return r; });
        });
      },
      heads: [B.th(t('btk_col_subject')), B.th(t('btk_col_client')), B.th(t('btk_col_dept')), B.th(t('btk_col_status')), B.th(t('btk_col_prio')), B.th(t('btk_col_assigned')), B.th(t('btk_col_last'))],
      row: function (k) {
        return el('tr', {'data-fp-ticket': String(k.id)}, [el('th', {scope: 'row', class: 'fp-bil-name'}, [B.button('open', k.subject || '—', 'sig-btn--link fp-bil-link', {'data-fp-id': String(k.id), 'aria-label': t('bcl_open_ticket_of', {name: k.subject})})]),
          el('td', {class: 'fp-bil-wrap', text: B.nameIn(K.names, k.customer_id)}), el('td', {text: deptName(k.department_id)}), el('td', null, [B.statePill('ticket', k.status)]),
          el('td', {text: k.priority ? B.word('prio', k.priority) : '—'}), el('td', {text: k.assigned_to || t('btk_nobody')}),
          el('td', {class: 'fp-bil-nowrap', text: k.last_reply ? t('bcl_last_reply', {who: k.last_reply_by || '—', when: B.when(k.last_reply)}) : '—'})]);
      },
      none: t('btk_none'), noneMatch: t('btk_none_match'),
      found: function (n) { return n === 1 ? t('btk_found_1') : t('btk_found', {n: B.num(n)}); }});
    return L;
  }
  function showList(focus, said) { K.view = 'list'; K.k = null; return K.L.show(focus, said); }
  function openTicket(kid, opts) {
    opts = opts || {};
    var mine = K;
    var b = K.page.querySelector('[data-fp-act="open"][data-fp-id="' + kid + '"]');
    if (b) { UI.setBusy(b, true); }
    return FP.call('get', 'billingTicket', undefined, {id: String(kid)}).then(function (r) {
      var k = cleanTicket(r);
      if (!k) { throw {message: t('api_failed')}; }
      return Promise.all([k, B.namesFor(K.names, [k.customer_id]),
        B.listOf('billingServices', {limit: '20', offset: '0', customer: String(k.customer_id)}, 'services', B.cleanService).then(function (x) { return x.items; }, function () { return null; }),
        FP.call('get', 'billingCanned', undefined, {department: String(k.department_id)}).then(cleanCanned, function () { return []; })]);
    }).then(function (r) {
      if (K !== mine) { return; }
      K.view = 'ticket';
      K.k = {k: r[0], services: r[2], canned: r[3]};
      drawTicket();
      if (opts.say) { M.say(K.page.querySelector('[data-fp-card="head"]'), opts.say); }
      if (opts.sayIn) { M.say(K.page.querySelector('[data-fp-card="' + opts.sayIn[0] + '"]'), opts.sayIn[1]); }
      (K.page.querySelector(opts.focus || '#fp-btk-h') || K.page.querySelector('#fp-btk-h')).focus();
    }).catch(function (err) {
      if (K !== mine) { return; }
      if (b && b.isConnected) { UI.setBusy(b, false); K.L.error(err); b.focus(); return; }
      if (K.view === 'ticket') { UI.showError(K.page.querySelector('[data-fp-card="head"]'), err.message); return; }
      showList().then(function () { K.L.error(err); });
    });
  }
  function reopen(opts) { return openTicket(K.k.k.id, opts); }
  function drawTicket() {
    var k = K.k.k;
    B.screen(K.page, [B.back('to-list', t('btk_back')), headCard(k), el('div', {class: 'fp-btk-layout'}, [el('div', {class: 'fp-btk-main'}, [talkCard(k), replyCard(k)]),
      el('div', {class: 'fp-btk-side'}, [sideCard(k), servicesCard()])])]);
  }
  function headCard(k) {
    return el('section', {class: 'sig-card fp-bil-head fp-btk-head', 'aria-labelledby': 'fp-btk-h', 'data-fp-card': 'head'}, [el('div', {class: 'sig-card-body'}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-bil-head-row'}, [el('div', {class: 'fp-bil-head-name'}, [el('h2', {class: 'fp-h2', id: 'fp-btk-h', tabindex: '-1', text: k.subject || '—'})]), B.statePill('ticket', k.status)]),
      B.facts([[t('btk_col_client'), [B.clientLink(K.names, k.customer_id)]], [t('btk_col_dept'), deptName(k.department_id)], [t('btk_col_prio'), B.word('prio', k.priority)],
        [t('btk_opened'), B.when(k.created)], k.closed ? [t('btk_closed_on'), B.when(k.closed)] : null])])]);
  }
  function talkCard(k) {
    var list = el('ol', {class: 'fp-btk-talk'}, k.messages.map(function (m) {
      var who = m.author_kind === 'customer' ? t('btk_by_client', {name: m.author_name || '—'}) : t('btk_by_staff', {name: m.author_name || '—'});
      return el('li', {class: 'fp-btk-msg' + (m.internal ? ' is-note' : '') + (m.author_kind === 'customer' ? ' is-client' : ''), 'data-fp-message': String(m.id)}, [
        el('p', {class: 'fp-btk-msg-head'}, [el('span', {class: 'fp-btk-who', text: who}), m.internal ? B.pill(t('btk_note_mark'), 'warn') : null, el('span', {class: 'fp-muted', text: B.when(m.created)})]),
        el('p', {class: 'fp-bil-note-body', text: m.body}),
        m.attachments.length ? el('ul', {class: 'fp-btk-files', 'aria-label': t('btk_files_of')}, m.attachments.map(function (a) {
          return el('li', null, [el('a', {href: '/api/v1/billing/support/tickets/' + k.id + '/attachments/' + a.id, download: '', 'data-fp-file': String(a.id)}, [UI.icon(FP.ui, 'ui_download'),
            el('span', {text: a.name})]), el('span', {class: 'fp-muted', text: ' ' + size(a.size)})]);
        })) : null]);
    }));
    return B.card('fp-btk-talk-h', t('btk_talk'), [k.messages.length ? list : el('p', {class: 'fp-muted', text: t('btk_no_messages')})], 'fp-btk-talk-card', 'talk');
  }
  function replyCard(k) {
    var canned = K.k.canned;
    var pick = canned.length ? B.select('fp-btk-r-canned', 'canned_id', [['', t('btk_canned_none')]].concat(canned.map(function (c) { return [String(c.id), c.title]; })), '') : null;
    var body = el('textarea', {class: 'sig-input fp-bil-text', id: 'fp-btk-r-body', name: 'body', rows: '6', maxlength: '20000'});
    var note = el('input', {type: 'checkbox', id: 'fp-btk-r-internal', name: 'internal'});
    var files = el('input', {type: 'file', id: 'fp-btk-r-files', name: 'files', multiple: '', class: 'fp-btk-file-input', accept: '.pdf,.png,.jpg,.jpeg,.gif,.txt,.log,.csv,.zip'});
    var send = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('btk_send')});
    if (pick) {
      pick.addEventListener('change', function () {
        var c = canned.filter(function (x) { return String(x.id) === pick.value; })[0];
        if (c && !body.value.trim()) { body.value = c.body; }
      });
    }
    note.addEventListener('change', function () { send.textContent = t(note.checked ? 'btk_save_note' : 'btk_send'); });
    var form = el('form', {class: 'fp-form fp-btk-reply', novalidate: '', 'aria-labelledby': 'fp-btk-reply-h'}, [M.errorLine(), M.statusLine(),
      k.status === 'closed' ? el('p', {class: 'fp-muted fp-row-note', text: t('btk_closed_reply')}) : null,
      pick ? M.field('fp-btk-r-canned', t('btk_canned'), pick, t('btk_canned_hint')) : null,
      M.field('fp-btk-r-body', t('btk_body'), body, t('btk_body_hint')),
      M.field('fp-btk-r-files', t('btk_files'), files, t('btk_files_hint')),
      el('div', {class: 'sig-field'}, [el('label', {class: 'fp-bil-check', for: 'fp-btk-r-internal'}, [note, el('span', {text: t('btk_internal')})]), el('span', {class: 'sig-hint', text: t('btk_internal_hint')})]),
      el('div', {class: 'fp-actions'}, [send])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!B.begin(form, send)) { return; }
      var chosen = pick && pick.value ? Number(pick.value) : 0;
      if (!body.value.trim() && !chosen) { M.fieldError(form, body, t('btk_body_needed')); return; }
      var list = Array.prototype.slice.call(files.files || []);
      for (var i = 0; i < list.length; i++) {
        if (!FILE_RE.test(list[i].name) || !/\.(pdf|png|jpe?g|gif|txt|log|csv|zip)$/i.test(list[i].name)) { M.fieldError(form, files, t('btk_file_bad', {name: list[i].name.slice(0, 100)})); return; }
        if (list[i].size > 2 * 1048576 || !list[i].size) { M.fieldError(form, files, t('btk_file_big', {name: list[i].name.slice(0, 100)})); return; }
      }
      if (list.length > 5) { M.fieldError(form, files, t('btk_files_many')); return; }
      var payload = {internal: note.checked};
      if (body.value.trim()) { payload.body = body.value; }
      if (chosen) { payload.canned_id = chosen; }
      var mine = K;
      UI.setBusy(send, true);
      FP.call('post', 'billingTicketReplies', payload, {id: String(k.id)}).then(function (r) {
        var w = cleanTicket(r);
        var last = w && w.messages.length ? w.messages[w.messages.length - 1] : null;
        /* the files go on the message just written, one by one; one refused stops the rest and says why */
        var up = Promise.resolve();
        list.forEach(function (f) {
          up = up.then(function () {
            return FP.call('post', 'billingTicketAttach', undefined, {id: String(k.id), message: String(last ? last.id : 0), name: f.name}, {body: f, type: 'application/octet-stream'});
          });
        });
        return up.then(function () { return null; }, function (err) { return err; });
      }).then(function (upErr) {
        if (K !== mine) { return; }
        var said = t(note.checked ? 'btk_noted' : 'btk_replied');
        if (upErr) { said += ' ' + t('btk_file_refused', {why: upErr.message}); }
        reopen({sayIn: ['reply', said], focus: '#fp-btk-r-body'});
      }, function (err) {
        if (K !== mine) { return; }
        UI.setBusy(send, false);
        B.failed(form, err);
      });
    });
    return B.card('fp-btk-reply-h', t('btk_reply'), [form], 'fp-btk-reply-card', 'reply');
  }
  function sideCard(k) {
    var status = B.select('fp-btk-s-status', 'status', STATUSES.map(function (s) { return [s, B.word('ticket', s)]; }), k.status);
    var prio = B.select('fp-btk-s-priority', 'priority', PRIOS.map(function (p) { return [p, B.word('prio', p)]; }), k.priority);
    var dept = B.select('fp-btk-s-department', 'department_id', K.departments.map(function (d) { return [String(d.id), d.name]; }), String(k.department_id));
    var who = B.input('fp-btk-s-assigned', 'assigned_to', k.assigned_to, {maxlength: '64', spellcheck: 'false', autocapitalize: 'none'});
    var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bil_save_changes')});
    var mineBtn = FP.session && FP.session.user && FP.session.user.username ? B.button('take', t('btk_take'), 'sig-btn--secondary sig-btn--sm') : null;
    var form = el('form', {class: 'fp-form fp-btk-side-form', novalidate: '', 'aria-labelledby': 'fp-btk-side-h'}, [M.errorLine(), M.statusLine(),
      M.field('fp-btk-s-status', t('btk_col_status'), status), M.field('fp-btk-s-priority', t('btk_col_prio'), prio), M.field('fp-btk-s-department', t('btk_col_dept'), dept),
      M.field('fp-btk-s-assigned', t('btk_col_assigned'), who, t('btk_assigned_hint')), mineBtn ? el('div', {class: 'fp-btk-take'}, [mineBtn]) : null, el('div', {class: 'fp-actions'}, [save])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!B.begin(form, save)) { return; }
      var body = {};
      if (status.value !== k.status) { body.status = status.value; }
      if (prio.value !== k.priority) { body.priority = prio.value; }
      if (Number(dept.value) !== k.department_id) { body.department_id = Number(dept.value); }
      if (who.value.trim() !== k.assigned_to) { body.assigned_to = who.value.trim(); }
      if (!Object.keys(body).length) { M.say(form, t('bil_nothing_changed')); return; }
      var mine = K;
      UI.setBusy(save, true);
      FP.call('patch', 'billingTicket', body, {id: String(k.id)}).then(function () {
        if (K !== mine) { return; }
        reopen({sayIn: ['side', t('btk_side_saved')], focus: '#fp-btk-side-h'});
      }, function (err) {
        if (K !== mine) { return; }
        UI.setBusy(save, false);
        B.failed(form, err);
      });
    });
    return B.card('fp-btk-side-h', t('btk_side'), [form], 'fp-btk-side-card', 'side');
  }
  function servicesCard() {
    var list = K.k.services;
    var parts = list === null ? [el('p', {class: 'fp-muted', text: t('btk_services_unread')})] : !list.length ? [el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('btk_no_services')})] :
      [el('ul', {class: 'fp-btk-services'}, list.map(function (s) { return el('li', null, [el('span', {text: s.plan_name + (s.username ? ' · ' + s.username : '')}), B.statePill('svc', s.status)]); }))];
    return B.card('fp-btk-svc-h', t('btk_services'), parts, 'fp-btk-svc-card', 'services');
  }
  function showNew(cid) {
    K.view = 'new';
    K.k = null;
    var picker = B.clientPicker('fp-btk-n-client', {label: t('btk_col_client'), placeholder: t('binv_pick_client'), required: true, value: cid || '', valueName: cid ? K.names[cid] : ''});
    var dept = B.select('fp-btk-n-dept', 'department_id', K.departments.map(function (d) { return [String(d.id), d.name + (d.hidden ? ' ' + t('bcl_tk_hidden_mark') : '')]; }), K.departments.length ? String(K.departments[0].id) : '');
    var subject = B.input('fp-btk-n-subject', 'subject', '', {maxlength: '150', 'aria-required': 'true'});
    var prio = B.select('fp-btk-n-prio', 'priority', PRIOS.map(function (p) { return [p, B.word('prio', p)]; }), 'medium');
    var body = el('textarea', {class: 'sig-input fp-bil-text', id: 'fp-btk-n-body', name: 'body', rows: '6', maxlength: '20000', 'aria-required': 'true'});
    var save = el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('bcl_tk_open')});
    var form = el('form', {class: 'fp-form fp-btk-new', novalidate: '', 'aria-labelledby': 'fp-btk-new-h'}, [M.errorLine(), M.statusLine(), el('div', {class: 'fp-binv-client-pick'}, [picker.node]),
      el('div', {class: 'fp-bil-grid'}, [M.field('fp-btk-n-dept', t('bcl_tk_dept'), dept, K.departments.length ? null : t('bcl_tk_no_department')), M.field('fp-btk-n-prio', t('bcl_tk_prio'), prio)]),
      M.field('fp-btk-n-subject', t('bcl_tk_subject'), subject), M.field('fp-btk-n-body', t('bcl_tk_body'), body, t('bcl_tk_body_hint')),
      el('div', {class: 'fp-actions'}, [save, B.button('new-cancel', t('cancel'))])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!B.begin(form, save)) { return; }
      if (!picker.select.value) { M.fieldError(form, picker.select, t('binv_client_needed')); return; }
      if (!subject.value.trim()) { M.fieldError(form, subject, t('bcl_tk_subject_needed')); return; }
      if (!body.value.trim()) { M.fieldError(form, body, t('bcl_tk_body_needed')); return; }
      var mine = K;
      UI.setBusy(save, true);
      FP.call('post', 'billingTicketNew', {customer_id: Number(picker.select.value), department_id: Number(dept.value), subject: subject.value.trim(), body: body.value, priority: prio.value}).then(function (r) {
        if (K !== mine) { return; }
        var k = cleanTicket(r);
        if (!k) { throw {message: t('api_failed')}; }
        openTicket(k.id, {say: t('bcl_tk_opened', {name: k.subject})});
      }).catch(function (err) {
        if (K !== mine) { return; }
        UI.setBusy(save, false);
        B.failed(form, err);
      });
    });
    B.screen(K.page, [B.back('to-list', t('btk_back')), B.card('fp-btk-new-h', t('bcl_tk_title'), [el('p', {class: 'fp-muted', text: t('bcl_tk_what')}), form], 'fp-btk-new-card', 'new')], '#fp-btk-n-client');
  }
  function onClick(e) {
    var target = e.target && e.target.closest ? e.target : null;
    if (!target || !K || !K.page.isConnected || !K.page.contains(target)) { return; }
    var b = target.closest('[data-fp-act]');
    if (!b || b.disabled) { return; }
    var a = b.getAttribute('data-fp-act');
    var xid = Number(b.getAttribute('data-fp-id')) || 0;
    if (a === 'open' && xid) {
      openTicket(xid);
    } else if (a === 'to-list' || a === 'new-cancel') {
      var from = K.k ? K.k.k.id : 0;
      showList(from ? '[data-fp-act="open"][data-fp-id="' + from + '"]' : '#fp-btk-list-h');
    } else if (a === 'new') {
      showNew(K.L.filters.customer ? Number(K.L.filters.customer) : 0);
    } else if (a === 'open-client' && xid) {
      B.go('billing_clients', {client: xid});
    } else if (a === 'take') {
      /* the login itself, not an account: this page is the administrator's only */
      if (FP.realm !== 'admin') { return; }
      var f = K.page.querySelector('#fp-btk-s-assigned');
      f.value = B.str(FP.session.user.username, 64);
      f.focus();
    }
  }
  document.addEventListener('click', onClick);

  FP.view('tool:billing_tickets', function () {
    var page = B.frame('billing_tickets', 'fp-btk');
    if (!page) { return; }
    K = {page: page, view: 'list', names: {}, departments: [], k: null};
    var mine = K;
    var handed = B.take('billing_tickets');
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'billingDepartments').then(cleanDepartments, function () { return []; }).then(function (d) {
      if (K !== mine) { return; }
      K.departments = d;
      K.L = lister();
      if (handed && B.id(handed.ticket)) { openTicket(handed.ticket, {say: handed.said}); } else { showList(); }
    });
  });
})();

/* freePanel API shell (docs/api.md, "API shell"): a page of both panels (#/tool/api_shell) where a signed-in login tries the panel's own API as itself. The
   routes come from the server (GET /auth/api-routes): the routes of this panel that the login's role may call, so the list follows the server and never
   offers a route the login cannot reach. A request is sent through FPAPI.shell, the way the panel's own pages call the API: the same session cookie, the
   CSRF token on a write, same origin only, so the server checks it as it checks every page. Nothing new is allowed on the server.
   The page never shows the session: the cookie cannot be read by a script, the CSRF token is not shown, and a field of a JSON answer that is named like
   a secret is hidden (any other answer is shown as it came, and the page says so; a file's own contents only on a click). "Copy as curl" writes a placeholder where a token goes. A request that changes something is sent only after an on-page confirm. The
   answer is shown as text (JSON is laid out by JSON.parse and JSON.stringify): nothing in it is markup and nothing in it runs. Page pieces come from FP.mail. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var METHODS = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'];
  var PARAM_RE = /^[a-z_][a-z0-9_]{0,31}$/;
  var PATH_RE = /^\/[A-Za-z0-9_\-./{}]{0,300}$/;
  var MAX_QUERY_ROWS = 10;
  var MAX_BODY = 1 << 20;
  var SHOWN_BODY = 256 << 10;
  var PLACEHOLDER = 'YOUR_API_TOKEN';
  /* the fields of an answer that are never shown: what could sign in as someone */
  /* the routes whose answer is a file's own contents, which hold a site's passwords as often as not: shown only on a click */
  var HELD_ROUTE = /\/(files\/content|files\/download|download\/file|git\/repositories\/\{name\}\/(file|commit))$/;
  var SECRET_KEY = /^(csrf_token|token|secret|password|passphrase|private_key|secret_key|access_key|recovery_codes|signon_url|otpauth_uri)$|_(token|secret|password)$/i;

  var S = {page: null};

  function cleanRoutes(r) {
    r = r && typeof r === 'object' ? r : {};
    var seen = {};
    var routes = (Array.isArray(r.routes) ? r.routes : []).slice(0, 2000).filter(function (x) {
      if (!x || METHODS.indexOf(x.method) < 0 || typeof x.path !== 'string' || !PATH_RE.test(x.path)) { return false; }
      var k = x.method + ' ' + x.path;
      if (seen[k]) { return false; }
      seen[k] = true;
      return true;
    }).map(function (x) {
      var params = (Array.isArray(x.params) ? x.params : []).filter(function (p) { return typeof p === 'string' && PARAM_RE.test(p); }).slice(0, 8);
      return {method: x.method, path: x.path, params: params, writes: x.writes === true || x.method !== 'GET'};
    });
    return {routes: routes, base: r.base === '/api/v1' ? r.base : '/api/v1', account: typeof r.account === 'string' && /^[a-z][a-z0-9]{0,15}$/.test(r.account) ? r.account : '',
      hidden: typeof r.hidden === 'number' && r.hidden >= 0 ? Math.floor(r.hidden) : 0};
  }
  function key(r) { return r.method + ' ' + r.path; }

  /* an answer's JSON with every secret-named field hidden */
  function redact(v, depth) {
    if (depth > 40) { return v; }
    if (Array.isArray(v)) { return v.map(function (x) { return redact(x, depth + 1); }); }
    if (v && typeof v === 'object') {
      var out = {};
      Object.keys(v).forEach(function (k) { out[k] = SECRET_KEY.test(k) && v[k] !== '' && v[k] !== null ? t('ash_hidden_value') : redact(v[k], depth + 1); });
      return out;
    }
    return v;
  }
  function shellQuote(s) { return '\'' + String(s).replace(/'/g, '\'\\\'\'') + '\''; }

  /* the path to send, from the route and the fields; '' with the field to fix when one is not right */
  function build(form, route) {
    var path = route.path;
    for (var i = 0; i < route.params.length; i++) {
      var p = route.params[i];
      var f = form.querySelector('[data-fp-ash-param="' + p + '"]');
      var v = f ? f.value.trim() : '';
      if (!v) { return {error: t('ash_need_param', {name: p}), field: f}; }
      path = path.replace('{' + p + '}', encodeURIComponent(v)).replace('{' + p + '...}', v.split('/').map(encodeURIComponent).join('/'));
    }
    var q = [];
    var rows = form.querySelectorAll('[data-fp-ash-query]');
    for (var j = 0; j < rows.length; j++) {
      var k = rows[j].querySelector('[data-fp-ash-qk]');
      var val = rows[j].querySelector('[data-fp-ash-qv]');
      if (!k.value.trim() && !val.value) { continue; }
      if (!/^[A-Za-z0-9_.\-[\]]{1,64}$/.test(k.value.trim())) { return {error: t('ash_bad_query'), field: k}; }
      q.push(encodeURIComponent(k.value.trim()) + '=' + encodeURIComponent(val.value));
    }
    var body = null;
    var ta = form.querySelector('#fp-ash-body');
    if (route.writes && ta && ta.value.trim()) {
      if (ta.value.length > MAX_BODY) { return {error: t('ash_body_big'), field: ta}; }
      try { body = JSON.stringify(JSON.parse(ta.value)); } catch (e) { return {error: t('ash_bad_json', {why: String(e.message || '').slice(0, 120)}), field: ta}; }
    }
    return {path: S.data.base + path + (q.length ? '?' + q.join('&') : ''), body: body};
  }
  function curlOf(route, req) {
    var url = window.location.origin + req.path;
    var parts = ['curl', '-sS'];
    if (route.method !== 'GET') { parts.push('-X', route.method); }
    parts.push(shellQuote(url), '-H', shellQuote('Authorization: Bearer ' + PLACEHOLDER), '-H', shellQuote('Accept: application/json'));
    if (req.body !== null) { parts.push('-H', shellQuote('Content-Type: application/json'), '--data', shellQuote(req.body)); }
    return parts.join(' ');
  }

  function requestCard() {
    var D = S.data;
    var filter = el('input', {class: 'sig-input', id: 'fp-ash-filter', type: 'search', autocomplete: 'off', spellcheck: 'false', maxlength: '80', value: S.filter,
      'aria-controls': 'fp-ash-route'});
    var shown = D.routes.filter(function (r) { return !S.filter || key(r).toLowerCase().indexOf(S.filter.toLowerCase()) >= 0; });
    var pick = el('select', {class: 'sig-select fp-ash-routes', id: 'fp-ash-route', name: 'route'}, [el('option', {value: '', text: t('ash_route_choose')})].concat(shown.slice(0, 600).map(function (r) {
      return el('option', {value: key(r), selected: S.route && key(r) === key(S.route) ? true : null, text: key(r)});
    })));
    var parts = [M.errorLine(), M.statusLine(),
      el('p', {class: 'fp-muted', text: t('ash_what', {n: String(D.routes.length)}) + (D.hidden ? ' ' + t('ash_hidden_n', {n: String(D.hidden)}) : '')}),
      M.field('fp-ash-filter', t('ash_filter'), filter, t('ash_filter_hint')),
      M.field('fp-ash-route', t('ash_route'), pick, shown.length ? t('ash_route_hint', {n: String(shown.length)}) : t('ash_none_match'))];
    var r = S.route;
    if (r) {
      parts.push(el('p', {class: 'fp-ash-chosen'}, [el('span', {class: 'sig-pill' + (r.writes ? ' sig-pill--warn' : ''), 'data-fp-ash-method': r.method, text: r.method}), ' ',
        el('span', {class: 'sig-mono', text: D.base + r.path})]));
      r.params.forEach(function (p) {
        var v = S.values['p:' + p] !== undefined ? S.values['p:' + p] : p === 'username' && D.account ? D.account : '';
        parts.push(M.field('fp-ash-p-' + p, t('ash_param', {name: p}), el('input', {class: 'sig-input', id: 'fp-ash-p-' + p, 'data-fp-ash-param': p, type: 'text',
          autocomplete: 'off', spellcheck: 'false', maxlength: '300', value: v})));
      });
      var q = el('fieldset', {class: 'fp-ash-query'}, [el('legend', {class: 'sig-label', text: t('ash_query')})].concat(S.queries.map(function (row, i) {
        return el('div', {class: 'fp-ash-qrow', 'data-fp-ash-query': ''}, [
          el('input', {class: 'sig-input', type: 'text', 'data-fp-ash-qk': '', 'aria-label': t('ash_query_name', {n: String(i + 1)}), autocomplete: 'off', spellcheck: 'false', maxlength: '64', value: row[0]}),
          el('input', {class: 'sig-input', type: 'text', 'data-fp-ash-qv': '', 'aria-label': t('ash_query_value', {n: String(i + 1)}), autocomplete: 'off', spellcheck: 'false', maxlength: '300', value: row[1]})]);
      })));
      if (S.queries.length < MAX_QUERY_ROWS) {
        var more = el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'ash-more', text: t('ash_query_more')});
        q.appendChild(el('div', {class: 'fp-actions'}, [more]));
      }
      parts.push(q);
      if (r.writes) {
        parts.push(M.field('fp-ash-body', t('ash_body'), el('textarea', {class: 'sig-input sig-mono fp-ash-body', id: 'fp-ash-body', rows: '8', spellcheck: 'false',
          autocomplete: 'off'}, [document.createTextNode(S.values.body || '')]), t('ash_body_hint')));
      }
      parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('ash_send')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'ash-curl', text: t('ash_curl')})]));
      if (S.confirm) {
        parts.push(el('div', {class: 'sig-banner sig-banner--warn fp-ash-confirm', role: 'alertdialog', 'aria-labelledby': 'fp-ash-confirm-t', 'data-fp-ash-confirm': ''}, [
          UI.icon(FP.ui, 'ui_warning'),
          el('div', {}, [el('p', {id: 'fp-ash-confirm-t', text: t(r.method === 'DELETE' ? 'ash_confirm_delete' : 'ash_confirm', {method: r.method, path: S.confirm.path})}),
            el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn ' + (r.method === 'DELETE' ? 'sig-btn--danger' : 'sig-btn--primary'), type: 'button', 'data-fp-act': 'ash-yes', text: t('ash_confirm_yes')}),
              el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'ash-no', text: t('ash_confirm_no')})])])]));
      }
    } else {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-ash-pick': '', text: t('ash_pick')}));
    }
    var form = el('form', {class: 'fp-form fp-ash-form', novalidate: ''}, parts);
    wire(form, filter, pick);
    return M.card('fp-ash-req-h', t('ash_request_title'), [form], 'fp-ash-request');
  }

  function keep(form) {
    if (!S.route) { return; }
    S.route.params.forEach(function (p) {
      var f = form.querySelector('[data-fp-ash-param="' + p + '"]');
      if (f) { S.values['p:' + p] = f.value; }
    });
    var rows = form.querySelectorAll('[data-fp-ash-query]');
    S.queries = Array.prototype.map.call(rows, function (row) { return [row.querySelector('[data-fp-ash-qk]').value, row.querySelector('[data-fp-ash-qv]').value]; });
    var ta = form.querySelector('#fp-ash-body');
    if (ta) { S.values.body = ta.value; }
  }
  function wire(form, filter, pick) {
    filter.addEventListener('input', function () {
      keep(form);
      S.filter = filter.value;
      render('#fp-ash-filter');
      var f = S.page.querySelector('#fp-ash-filter');
      f.setSelectionRange(f.value.length, f.value.length);
    });
    pick.addEventListener('change', function () {
      keep(form);
      var r = S.data.routes.filter(function (x) { return key(x) === pick.value; })[0];
      if (!r) { return; }
      var kept = {body: ''};
      Object.keys(S.values).forEach(function (k) { if (k.indexOf('p:') === 0) { kept[k] = S.values[k]; } });
      S.route = r;
      S.values = kept;
      S.queries = [['', '']];
      S.confirm = null;
      render('#fp-ash-route');
    });
    var more = form.querySelector('[data-fp-act="ash-more"]');
    if (more) {
      more.addEventListener('click', function () {
        keep(form);
        S.queries.push(['', '']);
        render('');
        var keys = S.page.querySelectorAll('[data-fp-ash-qk]');
        keys[keys.length - 1].focus();
      });
    }
    var curl = form.querySelector('[data-fp-act="ash-curl"]');
    if (curl) {
      curl.addEventListener('click', function () {
        UI.showError(form, '');
        var req = build(form, S.route);
        if (req.error) { M.fieldError(form, req.field, req.error); return; }
        keep(form);
        S.curl = curlOf(S.route, req);
        render('#fp-ash-curl-h');
      });
    }
    var yes = form.querySelector('[data-fp-act="ash-yes"]');
    if (yes) {
      yes.addEventListener('click', function () {
        /* a second click (a double-click) finds the request already on its way: it sends nothing, and the form is not left busy */
        var c = S.confirm;
        if (!c || S.busy) { return; }
        S.confirm = null;
        yes.disabled = true;
        send(c);
      });
      form.querySelector('[data-fp-act="ash-no"]').addEventListener('click', function () {
        S.confirm = null;
        render('.fp-ash-form .fp-submit');
        M.say(S.page.querySelector('.fp-ash-form'), t('ash_not_sent'));
      });
    }
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (!S.route || S.busy) { return; }
      var b = M.start(form);
      if (!b) { return; }
      var req = build(form, S.route);
      if (req.error) { M.fieldError(form, req.field, req.error); return; }
      keep(form);
      if (S.route.writes) {
        S.confirm = req;
        render('[data-fp-act="ash-yes"]');
        return;
      }
      send(req);
    });
  }

  function send(req) {
    var mine = S.page;
    var route = S.route;
    S.busy = true;
    var b = mine.querySelector('.fp-ash-form .fp-submit');
    if (b) { UI.setBusy(b, true); }
    var started = Date.now();
    window.FPAPI.shell(route.method, req.path, req.body).then(function (a) {
      S.busy = false;
      if (S.page !== mine) { return; }
      S.answer = {method: route.method, path: req.path, status: a.status, statusText: a.statusText, ms: Date.now() - started, headers: a.headers, text: a.text,
        cut: a.cut === true, download: a.download, held: HELD_ROUTE.test(route.path)};
      render('#fp-ash-res-h');
      UI.announce(t('ash_answered', {status: String(a.status)}));
    }, function (err) {
      S.busy = false;
      if (S.page !== mine) { return; }
      if (b) { UI.setBusy(b, false); }
      UI.showError(mine.querySelector('.fp-ash-form'), err.message);
    });
  }

  function answerCard() {
    var A = S.answer;
    var ok = A.status >= 200 && A.status < 300;
    var body = A.text;
    var json = false;
    try {
      if (body) { body = JSON.stringify(redact(JSON.parse(body), 0), null, 2); json = true; }
    } catch (e) { body = A.text; }
    var cut = A.cut || body.length > SHOWN_BODY;
    if (body.length > SHOWN_BODY) { body = body.slice(0, SHOWN_BODY); }
    var show = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'ash-show', text: t('ash_show')});
    show.addEventListener('click', function () { A.held = false; render('[data-fp-ash-body]'); });
    var headers = A.headers.filter(function (h) { return !/^(set-cookie|cookie|authorization|x-csrf-token)$/i.test(h[0]); });
    return M.card('fp-ash-res-h', t('ash_answer_title'), [
      el('p', {class: 'fp-ash-status', 'data-fp-ash-status': String(A.status)}, [el('span', {class: 'sig-pill ' + (ok ? 'sig-pill--ok' : A.status >= 500 ? 'sig-pill--danger' : 'sig-pill--warn'),
        text: String(A.status) + (A.statusText ? ' ' + A.statusText.slice(0, 60) : '')}), ' ', el('span', {class: 'fp-muted', text: t('ash_took', {ms: String(A.ms), method: A.method, path: A.path})})]),
      el('h3', {class: 'fp-h3', text: t('ash_headers')}),
      el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-label': t('ash_headers')}, [el('table', {class: 'sig-table fp-mail-table fp-ash-headers'}, [
        el('tbody', null, headers.slice(0, 60).map(function (h) {
          return el('tr', null, [el('th', {scope: 'row', class: 'sig-mono', text: h[0].slice(0, 80)}), el('td', {class: 'sig-mono', text: h[1].slice(0, 400)})]);
        }))])]),
      el('h3', {class: 'fp-h3', text: json ? t('ash_body_json') : t('ash_body_text')}),
      A.download ? el('p', {class: 'fp-muted', 'data-fp-ash-download': '', text: A.download.bytes >= 0 ? t('ash_download', {bytes: String(A.download.bytes)})
        : t('ash_download_unknown')})
      : body && A.held ? el('div', {class: 'fp-ash-held', 'data-fp-ash-held': ''}, [el('p', {class: 'fp-muted', text: t('ash_held')}), el('div', {class: 'fp-actions'}, [show])])
      : body ? el('pre', {class: 'fp-ash-pre sig-mono', tabindex: '0', 'data-fp-ash-body': '', 'aria-label': t('ash_body_text')}, [document.createTextNode(body)])
        : el('p', {class: 'fp-muted', 'data-fp-ash-empty': '', text: t('ash_empty')}),
      cut ? el('p', {class: 'fp-muted', text: t('ash_cut')}) : null,
      json ? el('p', {class: 'fp-muted', text: t('ash_redacted')}) : body && !A.download && !A.held ? el('p', {class: 'fp-muted', 'data-fp-ash-raw': '', text: t('ash_not_json')}) : null], 'fp-ash-answer');
  }

  function curlCard() {
    var area = el('textarea', {class: 'sig-input sig-mono fp-ash-curl', id: 'fp-ash-curl', rows: '4', readonly: '', spellcheck: 'false'}, [document.createTextNode(S.curl)]);
    var copy = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'ash-copy', text: t('ash_copy')});
    var card = M.card('fp-ash-curl-h', t('ash_curl_title'), [M.statusLine(), M.field('fp-ash-curl', t('ash_curl_label'), area, t('ash_curl_hint', {token: PLACEHOLDER})),
      el('div', {class: 'fp-actions'}, [copy])], 'fp-ash-curlcard');
    copy.addEventListener('click', function () {
      var done = function () { M.say(card, t('ash_copied')); };
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(S.curl).then(done, function () { area.select(); M.say(card, t('ash_copy_by_hand')); });
      } else { area.select(); M.say(card, t('ash_copy_by_hand')); }
    });
    return card;
  }

  function render(focus) {
    var page = S.page;
    page.textContent = '';
    page.appendChild(requestCard());
    if (S.curl) { page.appendChild(curlCard()); }
    if (S.answer) { page.appendChild(answerCard()); }
    var f = focus && page.querySelector(focus);
    if (f) { f.focus(); }
  }

  FP.view('tool:api_shell', function () {
    S.page = null;
    var tool = FP.tools.api_shell;
    if (!tool) { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('api_shell_desc'), cls: 'fp-mail fp-ash',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    S = {page: body, data: null, route: null, filter: '', values: {}, queries: [['', '']], confirm: null, answer: null, curl: '', busy: false};
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'apiRoutes').then(function (r) {
      if (S.page !== body) { return; }
      S.data = cleanRoutes(r);
      render('');
    }, function (err) {
      if (S.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

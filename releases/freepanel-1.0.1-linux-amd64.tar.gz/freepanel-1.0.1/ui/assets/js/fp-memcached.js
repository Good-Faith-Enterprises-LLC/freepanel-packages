/* freePanel's Memcached page for the customer panel (#/tool/memcached, docs/api.md, "Memcached for accounts"): turn on a Memcached of the
   account's own, choose how much memory it may hold, see the socket a site connects to, and turn it off. There is no password and no port: the
   server is reachable only by what runs as the account. What the server answers is cleaned to the shapes drawn. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var el = UI.el;
  var M = FP.mail;

  var t = UI.t;

  var SIZES = [16, 32, 64, 128, 256, 512, 1024];
  var R = null;

  function num(v, hi) { return typeof v === 'number' && isFinite(v) && v >= 0 ? Math.min(Math.floor(v), hi) : 0; }
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    return {on: r.enabled === true, running: r.running === true, suspended: r.suspended === true, memory: num(r.memory_mb, 1048576), used: num(r.used_mb, 1048576),
      socket: typeof r.socket === 'string' && /^\/[A-Za-z0-9._/-]{1,200}$/.test(r.socket) ? r.socket : ''};
  }
  function size(mb) { return mb >= 1024 && mb % 1024 === 0 ? t('mcd_gb', {n: String(mb / 1024)}) : t('mcd_mb', {n: String(mb)}); }
  function pill(text, kind) { return el('span', {class: 'sig-pill' + (kind ? ' sig-pill--' + kind : ''), 'data-fp-state': '', text: text}); }
  function sizeSelect(id, current) {
    var list = SIZES.indexOf(current) >= 0 || !current ? SIZES : SIZES.concat([current]).sort(function (a, b) { return a - b; });
    var sel = el('select', {class: 'sig-select', id: id, name: 'memory_mb'}, list.map(function (n) { return el('option', {value: String(n), text: size(n)}); }));
    sel.value = String(current || 64);
    return sel;
  }
  function row(label, value) { return el('div', {class: 'fp-rd-row'}, [el('dt', {text: label}), el('dd', null, Array.isArray(value) ? value : [value])]); }

  function offCard() {
    var sel = sizeSelect('fp-mcd-mem', 64);
    var form = el('form', {class: 'fp-rd-form', novalidate: ''}, [
      M.field('fp-mcd-mem', t('mcd_memory'), sel, t('mcd_memory_hint')),
      el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': ''}),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('mcd_on')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var go = M.start(form);
      if (!go) { return; }
      var mine = R;
      UI.setBusy(go, true);
      FP.call('post', 'memcached', {memory_mb: Number(sel.value)}, FP.account()).then(function (r) {
        if (R !== mine) { return; }
        R.st = clean(r);
        R.headline = t('mcd_on_done');
        draw('#fp-mcd-h');
      }, function (err) {
        if (R !== mine) { return; }
        UI.setBusy(go, false);
        M.failed(form, err);
      });
    });
    return M.card('fp-mcd-h', t('mcd_title'), [el('p', {class: 'fp-muted', text: t('mcd_what')}), form, M.statusLine()], 'fp-rd fp-mcd');
  }
  function onCard() {
    var st = R.st;
    var state = st.suspended ? pill(t('mcd_state_suspended'), 'warn') : (st.running ? pill(t('mcd_state_running'), 'ok') : pill(t('mcd_state_stopped'), 'danger'));
    var rows = [row(t('mcd_row_state'), state), row(t('mcd_row_socket'), el('span', {class: 'sig-mono fp-rd-secret', 'data-fp-socket': '', text: st.socket})),
      row(t('mcd_row_memory'), size(st.memory))];
    if (st.running && st.used) { rows.push(row(t('mcd_row_using'), size(st.used))); }
    var sel = sizeSelect('fp-mcd-mem', st.memory);
    var change = el('form', {class: 'fp-rd-form fp-rd-change', novalidate: ''}, [
      M.field('fp-mcd-mem', t('mcd_change'), sel, t('mcd_change_note')),
      el('div', {class: 'fp-alert', role: 'alert', 'data-fp-error': ''}), M.statusLine(),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary fp-submit', type: 'submit', disabled: st.suspended ? true : null, text: t('mcd_change_save')})])]);
    change.addEventListener('submit', function (e) {
      e.preventDefault();
      var go = M.start(change);
      if (!go) { return; }
      var mine = R;
      UI.setBusy(go, true);
      FP.call('put', 'memcached', {memory_mb: Number(sel.value)}, FP.account()).then(function (r) {
        if (R !== mine) { return; }
        R.st = clean(r);
        R.headline = '';
        draw('#fp-mcd-h');
        M.say(R.page.querySelector('.fp-rd-change'), t('mcd_changed', {mb: size(R.st.memory)}));
      }, function (err) {
        if (R !== mine) { return; }
        UI.setBusy(go, false);
        M.failed(change, err);
      });
    });
    var actions = el('div', {class: 'fp-actions fp-rd-acts'}, [
      el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'copy', 'data-fp-copy': st.socket, disabled: st.socket ? null : true, text: t('mcd_copy')}),
      el('button', {class: 'sig-btn sig-btn--secondary fp-btn-danger-text', type: 'button', 'data-fp-act': 'off', text: t('mcd_off')})]);
    return M.card('fp-mcd-h', t('mcd_status'), [
      R.headline ? el('p', {class: 'fp-ok-line', role: 'status', 'data-fp-status': '', text: R.headline}) : null,
      st.suspended ? el('p', {class: 'fp-muted', text: t('mcd_suspended_note')}) : null, el('dl', {class: 'fp-rd-list'}, rows),
      el('p', {class: 'fp-muted', text: t('mcd_socket_note')}), change, M.errorLine(), actions], 'fp-rd fp-mcd');
  }
  function draw(focus) {
    var page = R.page;
    page.textContent = '';
    page.appendChild(R.st.on ? onCard() : offCard());
    var target = focus ? page.querySelector(focus) : null;
    if (target) { target.focus(); }
  }
  function click(e) {
    var b = e.target && e.target.closest ? e.target.closest('.fp-mcd [data-fp-act]') : null;
    if (!b || !R || !R.page.contains(b) || b.disabled) { return; }
    var a = b.getAttribute('data-fp-act');
    var mine = R;
    if (a === 'copy') {
      var card = b.closest('.fp-mcd');
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(b.getAttribute('data-fp-copy')).then(function () { M.say(card, t('copied')); }, function () { M.say(card, t('copy_failed')); });
      } else {
        M.say(card, t('copy_failed'));
      }
    } else if (a === 'off') {
      M.confirmIn(b.closest('.fp-rd-acts'), t('mcd_off_ask'), 'off-yes', t('mcd_off_yes'));
    } else if (a === 'confirm-no') {
      draw('[data-fp-act="off"]');
    } else if (a === 'off-yes') {
      var scope = b.closest('.fp-mcd');
      UI.setBusy(b, true);
      FP.call('del', 'memcached', undefined, FP.account()).then(function (r) {
        if (R !== mine) { return; }
        R.st = clean(r);
        R.headline = '';
        draw('#fp-mcd-h');
        M.say(R.page.querySelector('.fp-mcd'), t('mcd_off_done'));
      }, function (err) { if (R === mine) { UI.setBusy(b, false); UI.showError(scope, err.message); } });
    }
  }
  document.addEventListener('click', click);

  FP.view('tool:memcached', function () {
    R = null;
    var tool = FP.tools.memcached;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('memcached_desc'), cls: 'fp-mail fp-mcd-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    if (!page) { return; }
    R = {page: page, st: null, headline: ''};
    var mine = R;
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'memcached', undefined, FP.account()).then(function (r) {
      if (R !== mine) { return; }
      R.st = clean(r);
      draw('');
    }, function (err) {
      if (R !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err && err.status === 503 ? t('mcd_unavailable') : (err && err.message ? err.message : t('api_failed'))));
    });
  });
})();

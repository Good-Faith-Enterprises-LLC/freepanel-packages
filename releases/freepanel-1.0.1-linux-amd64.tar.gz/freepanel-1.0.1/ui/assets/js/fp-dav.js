/* freePanel calendars and contacts (docs/api.md, "Calendars and contacts"): the customer panel's three pages for each mailbox's
   calendars and address books, served over CalDAV and CardDAV. Manage (#/tool/calendars_manage) lists a mailbox's calendars and
   address books, makes one, renames one and removes one (the server keeps its entries aside); Share (#/tool/calendars_share) lets
   another mailbox of the account read one, or read and change it, and ends that; Connect (#/tool/calendars_connect) says what a phone,
   a computer or a calendar program is given: the server, the mailbox's address and its own password, and each calendar's address.
   Every page reads the account with one call and every change answers with the whole of it again. The mailbox picked is kept while
   the person moves between the three. Everything the server sends is checked and drawn as text. The page pieces come from FP.mail
   (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var ID_RE = /^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$/;
  var COLOR_RE = /^#[0-9A-Fa-f]{6}(?:[0-9A-Fa-f]{2})?$/;
  var CTRL_RE = /[\u0000-\u001f\u007f-\u009f\u2028\u2029]/;   // eslint-disable-line no-control-regex -- a name of printable characters only
  var KINDS = ['calendar', 'contacts'];
  var WHY = ['suspended', 'not_served', 'password', 'pending'];
  var VIEWS = {calendars_manage: 'manage', calendars_share: 'share', calendars_connect: 'connect'};
  /* the mailbox picked, kept across the three pages of one account */
  var picked = {account: '', box: ''};
  var D = {page: null, view: '', account: '', data: null, open: '', share: ''};

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function chars(s) { return Array.from(s).length; }
  /* a display name as the server keeps it: 1 to 64 characters of text, no control characters or line breaks */
  function nameOK(n) { return n !== '' && chars(n) <= 64 && !CTRL_RE.test(n); }
  function urlOf(v) {
    var s = str(v, 700);
    return /^https:\/\/[^\s"<>\\]+$/.test(s) ? s : '';
  }
  function cleanCol(c) {
    if (!c || typeof c !== 'object' || typeof c.id !== 'string' || !c.id || c.id.length > 255 || KINDS.indexOf(c.kind) < 0) { return null; }
    var name = str(c.name, 200).trim();
    return {id: c.id, kind: c.kind, name: nameOK(name) ? name : c.id, color: COLOR_RE.test(str(c.color, 9)) ? c.color.slice(0, 7) : '',
      items: typeof c.items === 'number' && c.items >= 0 ? Math.floor(Math.min(c.items, 100000)) : 0,
      managed: c.managed === true && ID_RE.test(c.id), url: urlOf(c.url),
      shares: (Array.isArray(c.shares) ? c.shares : []).filter(function (s) { return s && M.isAddress(s.to); })
        .map(function (s) { return {to: s.to, write: s.write === true}; }).sort(function (a, b) { return a.to < b.to ? -1 : 1; })};
  }
  function cleanIn(c) {
    if (!c || typeof c !== 'object' || !M.isAddress(c.owner) || !ID_RE.test(str(c.id, 80)) || KINDS.indexOf(c.kind) < 0) { return null; }
    var name = str(c.name, 200).trim();
    return {owner: c.owner, id: c.id, kind: c.kind, name: nameOK(name) ? name : c.id, write: c.write === true, url: urlOf(c.url)};
  }
  function clean(r) {
    if (!r || typeof r !== 'object' || !Array.isArray(r.mailboxes)) { return null; }
    var boxes = r.mailboxes.slice(0, 10000).filter(function (b) { return b && M.isAddress(b.address); }).map(function (b) {
      return {address: b.address, signIn: b.sign_in === true, why: WHY.indexOf(b.why) >= 0 ? b.why : '', url: urlOf(b.url),
        cols: (Array.isArray(b.collections) ? b.collections : []).slice(0, 200).map(cleanCol).filter(Boolean),
        incoming: (Array.isArray(b.shared_with_me) ? b.shared_with_me : []).slice(0, 500).map(cleanIn).filter(Boolean)};
    }).sort(function (a, b) { return a.address < b.address ? -1 : 1; });
    return {url: urlOf(r.url), server: /^[A-Za-z0-9.:[\]-]{1,260}$/.test(str(r.server, 270)) ? r.server : '', suspended: r.suspended === true, boxes: boxes};
  }

  function box() {
    var list = D.data.boxes;
    for (var i = 0; i < list.length; i++) { if (list[i].address === picked.box) { return list[i]; } }
    return list[0] || null;
  }
  function colOf(b, id) { return b ? b.cols.filter(function (c) { return c.id === id; })[0] : null; }
  function kindText(k) { return t(k === 'calendar' ? 'dav_kind_calendar' : 'dav_kind_contacts'); }
  function pill(kind, text) { return el('span', {class: 'sig-pill' + (kind ? ' sig-pill--' + kind : ''), text: text}); }
  function swatch(c) {
    var dot = el('span', {class: 'fp-dav-dot fp-dav-dot--' + c.kind, 'aria-hidden': 'true'});
    /* a colour a calendar program chose, checked as #RRGGBB; set through the style object, which the page's CSP allows */
    if (c.color) { dot.style.setProperty('--fp-dav-color', c.color); }
    return dot;
  }

  /* ---- shared pieces ---- */
  function frame(id) {
    var tool = FP.tools[id];
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return null; }
    var g = FP.group(tool.group);
    return FP.frame({title: tool.label, desc: t('dav_desc_' + VIEWS[id]), cls: 'fp-mail fp-dav fp-dav-' + VIEWS[id],
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
  }
  /* the mailbox picker: every page is about one mailbox at a time */
  function pickCard() {
    var b = box();
    var sel = el('select', {class: 'sig-select', id: 'fp-dav-box', name: 'mailbox', 'aria-describedby': 'fp-dav-box-hint'}, D.data.boxes.map(function (x) {
      var o = el('option', {value: x.address, text: x.address});
      if (x.address === b.address) { o.selected = true; }
      return o;
    }));
    sel.addEventListener('change', function () {
      picked.box = sel.value;
      D.open = '';
      D.share = '';
      render();
      var again = D.page.querySelector('#fp-dav-box');
      if (again) { again.focus(); }
    });
    var state = b.signIn ? el('p', {class: 'fp-dav-state', id: 'fp-dav-box-hint'}, [pill('ok', t('dav_signin_on')), el('span', {class: 'fp-muted', text: t('dav_signin_on_hint')})]) :
      el('p', {class: 'fp-dav-state', id: 'fp-dav-box-hint'}, [pill('warn', t('dav_signin_off')), el('span', {class: 'fp-muted', text: t('dav_why_' + (b.why || 'pending'))})]);
    return el('div', {class: 'sig-card fp-dav-pick'}, [el('div', {class: 'sig-card-body'}, [
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: 'fp-dav-box', text: t('dav_mailbox')}), sel]), state])]);
  }
  function noBoxes() {
    return FP.empty(t('dav_no_boxes_title'), t('dav_no_boxes'), el('a', {class: 'sig-btn sig-btn--secondary', href: '#/tool/mailboxes', text: t('dav_to_mailboxes')}));
  }
  /* an answer that replaces the page's data; null when it doesn't do */
  function settle(r) {
    var s = clean(r);
    if (!s) { return false; }
    D.data = s;
    return true;
  }

  /* ================= Manage ================= */
  function createCard() {
    var b = box();
    var form = el('form', {class: 'fp-form fp-mail-form fp-dav-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('fieldset', {class: 'fp-dav-kinds'}, [el('legend', {class: 'sig-label', text: t('dav_kind')})].concat(KINDS.map(function (k, i) {
        var id = 'fp-dav-kind-' + k;
        return el('label', {class: 'fp-check', for: id}, [el('input', {type: 'radio', id: id, name: 'kind', value: k, checked: i === 0 ? true : null}),
          el('span', {text: kindText(k)})]);
      }))),
      M.field('fp-dav-name', t('dav_name'), el('input', {class: 'sig-input', id: 'fp-dav-name', name: 'name', type: 'text', autocomplete: 'off', maxlength: '64'}), t('dav_name_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('dav_create')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var btn = M.start(form);
      if (!btn) { return; }
      var name = form.querySelector('[name="name"]');
      var v = name.value.trim();
      if (!nameOK(v)) { M.fieldError(form, name, t('dav_name_bad')); return; }
      var kind = form.querySelector('[name="kind"]:checked').value;
      UI.setBusy(btn, true);
      FP.call('post', 'davBox', {kind: kind, name: v}, {name: D.account, address: b.address}).then(function (r) {
        if (!settle(r)) { UI.setBusy(btn, false); M.fieldError(form, null, t('api_failed')); return; }
        render();
        M.say(D.page.querySelector('.fp-dav-list'), t(kind === 'calendar' ? 'dav_created_calendar' : 'dav_created_contacts', {name: v}));
        D.page.querySelector('#fp-dav-name').focus();
      }, function (err) {
        UI.setBusy(btn, false);
        M.failed(form, err);
      });
    });
    return M.card('fp-dav-create-h', t('dav_create_title'), [el('p', {class: 'fp-muted', text: t('dav_create_desc')}), form], 'fp-dav-create');
  }
  function renameRow(c) {
    var form = el('form', {class: 'fp-form fp-mail-inline', novalidate: '', 'aria-labelledby': 'fp-dav-rename-h'}, [
      el('h3', {class: 'fp-h3', id: 'fp-dav-rename-h', tabindex: '-1', text: t('dav_rename_title', {name: c.name})}), M.errorLine(),
      M.field('fp-dav-rename', t('dav_new_name'), el('input', {class: 'sig-input', id: 'fp-dav-rename', name: 'name', type: 'text', autocomplete: 'off',
        maxlength: '64', value: c.name}), t('dav_rename_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('dav_save')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'dav-close', text: t('cancel')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var btn = M.start(form);
      if (!btn) { return; }
      var name = form.querySelector('[name="name"]');
      var v = name.value.trim();
      if (!nameOK(v)) { M.fieldError(form, name, t('dav_name_bad')); return; }
      if (v === c.name) { M.fieldError(form, name, t('dav_name_same')); return; }
      UI.setBusy(btn, true);
      FP.call('patch', 'davItem', {name: v}, {name: D.account, address: box().address, id: c.id}).then(function (r) {
        if (!settle(r)) { UI.setBusy(btn, false); M.fieldError(form, null, t('api_failed')); return; }
        D.open = '';
        render();
        M.say(D.page.querySelector('.fp-dav-list'), t('dav_renamed', {name: v}));
        focusRow(c.id, 'dav-rename');
      }, function (err) {
        UI.setBusy(btn, false);
        M.failed(form, err);
      });
    });
    return el('tr', {class: 'fp-mail-formrow'}, [el('td', {colspan: '5'}, [form])]);
  }
  function colRow(c) {
    var shared = c.shares.length;
    return el('tr', {'data-fp-col': c.id}, [
      el('th', {scope: 'row', class: 'fp-dav-namecell'}, [el('span', {class: 'fp-dav-name'}, [swatch(c), el('span', {text: c.name})]),
        c.managed ? null : el('span', {class: 'fp-muted fp-row-note', text: t('dav_device_made')})]),
      el('td', null, [pill(c.kind === 'calendar' ? 'accent' : '', kindText(c.kind))]),
      el('td', {class: 'fp-dav-num', text: c.items.toLocaleString('en')}),
      el('td', null, [shared ? el('span', {text: t(shared === 1 ? 'dav_shared_one' : 'dav_shared_n', {n: shared})}) : el('span', {class: 'fp-muted', text: t('dav_not_shared')})]),
      el('td', {class: 'fp-mail-acts'}, c.managed ? [
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'dav-rename', 'aria-expanded': String(D.open === c.id),
          'aria-label': t('dav_rename_of', {name: c.name}), text: t('dav_rename')}),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'dav-remove',
          'aria-label': t('dav_remove_of', {name: c.name}), text: t('dav_remove')})] : [])]);
  }
  function listCard() {
    var b = box();
    var parts = [M.errorLine(), M.statusLine()];
    if (!b.cols.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('dav_none')}));
    } else {
      var rows = [];
      b.cols.forEach(function (c) {
        rows.push(colRow(c));
        if (D.open === c.id && c.managed) { rows.push(renameRow(c)); }
      });
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-dav-list-h'}, [
        el('table', {class: 'sig-table fp-mail-table fp-dav-table'}, [el('thead', null, [el('tr', null, [
          el('th', {scope: 'col', text: t('dav_col_name')}), el('th', {scope: 'col', text: t('dav_col_kind')}),
          el('th', {scope: 'col', text: t('dav_col_items')}), el('th', {scope: 'col', text: t('dav_col_shared')}),
          el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]),
        el('tbody', null, rows)])]));
    }
    return M.card('fp-dav-list-h', t('dav_list_title', {address: b.address}), parts, 'fp-dav-list');
  }

  /* ================= Share ================= */
  function shareable(b) { return b.cols.filter(function (c) { return c.managed; }); }
  function shareCard() {
    var b = box();
    var cols = shareable(b);
    var others = D.data.boxes.filter(function (x) { return x.address !== b.address; });
    var parts = [M.errorLine(), M.statusLine()];
    if (!others.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('dav_share_one_box')}));
      return M.card('fp-dav-share-h', t('dav_share_title'), parts, 'fp-dav-shares');
    }
    if (!cols.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('dav_share_nothing')}));
      parts.push(el('a', {class: 'sig-btn sig-btn--secondary', href: '#/tool/calendars_manage', text: t('dav_to_manage')}));
      return M.card('fp-dav-share-h', t('dav_share_title'), parts, 'fp-dav-shares');
    }
    if (!colOf(b, D.share) || !colOf(b, D.share).managed) { D.share = cols[0].id; }
    var c = colOf(b, D.share);
    var sel = el('select', {class: 'sig-select', id: 'fp-dav-col', name: 'collection'}, cols.map(function (x) {
      var o = el('option', {value: x.id, text: x.name + ' (' + kindText(x.kind) + ')'});
      if (x.id === c.id) { o.selected = true; }
      return o;
    }));
    sel.addEventListener('change', function () { D.share = sel.value; render(); D.page.querySelector('#fp-dav-col').focus(); });
    parts.push(M.field('fp-dav-col', t('dav_share_which'), sel));
    if (!c.shares.length) {
      parts.push(el('p', {class: 'fp-muted fp-dav-noshare', text: t('dav_share_none', {name: c.name})}));
    } else {
      parts.push(el('ul', {class: 'fp-dav-shares-list', 'aria-label': t('dav_share_list', {name: c.name})}, c.shares.map(function (s) {
        return el('li', {class: 'fp-dav-share', 'data-fp-to': s.to}, [
          el('span', {class: 'fp-dav-share-who'}, [el('span', {class: 'sig-mono fp-dav-addr', text: s.to}),
            pill(s.write ? 'accent' : '', t(s.write ? 'dav_access_write' : 'dav_access_read'))]),
          el('span', {class: 'fp-dav-share-acts'}, [
            el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': s.write ? 'dav-to-read' : 'dav-to-write',
              'aria-label': t(s.write ? 'dav_make_read_of' : 'dav_make_write_of', {who: s.to}), text: t(s.write ? 'dav_make_read' : 'dav_make_write')}),
            el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'dav-unshare',
              'aria-label': t('dav_unshare_of', {who: s.to}), text: t('dav_unshare')})])]);
      })));
    }
    var free = others.filter(function (x) { return !c.shares.some(function (s) { return s.to === x.address; }); });
    if (free.length) { parts.push(addShareForm(b, c, free)); }
    return M.card('fp-dav-share-h', t('dav_share_title'), parts, 'fp-dav-shares');
  }
  function addShareForm(b, c, free) {
    var form = el('form', {class: 'fp-form fp-dav-form fp-dav-addshare', novalidate: '', 'aria-labelledby': 'fp-dav-add-h'}, [
      el('h3', {class: 'fp-h3', id: 'fp-dav-add-h', tabindex: '-1', text: t('dav_share_add_title', {name: c.name})}), M.errorLine(),
      M.field('fp-dav-to', t('dav_share_with'), el('select', {class: 'sig-select', id: 'fp-dav-to', name: 'to'}, free.map(function (x) {
        return el('option', {value: x.address, text: x.address});
      })), t('dav_share_with_hint')),
      el('fieldset', {class: 'fp-dav-kinds'}, [el('legend', {class: 'sig-label', text: t('dav_access')})].concat(['read', 'write'].map(function (a, i) {
        var id = 'fp-dav-access-' + a;
        return el('div', {class: 'fp-dav-choice'}, [el('label', {class: 'fp-check', for: id}, [
          el('input', {type: 'radio', id: id, name: 'access', value: a, checked: i === 0 ? true : null, 'aria-describedby': id + '-hint'}),
          el('span', {text: t('dav_access_' + a)})]), el('span', {class: 'sig-hint', id: id + '-hint', text: t('dav_access_' + a + '_hint')})]);
      }))),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('dav_share')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var btn = M.start(form);
      if (!btn) { return; }
      var to = form.querySelector('[name="to"]').value;
      var access = form.querySelector('[name="access"]:checked').value;
      UI.setBusy(btn, true);
      FP.call('put', 'davShare', {access: access}, {name: D.account, address: b.address, id: c.id, to: to}).then(function (r) {
        if (!settle(r)) { UI.setBusy(btn, false); M.fieldError(form, null, t('api_failed')); return; }
        render();
        M.say(D.page.querySelector('.fp-dav-shares'), t(access === 'write' ? 'dav_shared_write' : 'dav_shared_read', {name: c.name, who: to}));
        D.page.querySelector('#fp-dav-share-h').focus();
      }, function (err) {
        UI.setBusy(btn, false);
        M.failed(form, err);
      });
    });
    return form;
  }
  function incomingCard(withUrls) {
    var b = box();
    var parts = [];
    if (!b.incoming.length) {
      parts.push(el('p', {class: 'fp-muted', text: t('dav_incoming_none', {address: b.address})}));
    } else {
      parts.push(el('ul', {class: 'fp-dav-urls'}, b.incoming.map(function (c, i) {
        return el('li', {class: 'fp-dav-url'}, [
          el('span', {class: 'fp-dav-url-head'}, [swatch(c), el('span', {class: 'fp-dav-url-name', text: c.name}),
            pill(c.write ? 'accent' : '', t(c.write ? 'dav_access_write' : 'dav_access_read'))]),
          el('span', {class: 'fp-muted fp-row-note', text: t('dav_incoming_from', {kind: kindText(c.kind), owner: c.owner})}),
          withUrls && c.url ? copyLine('fp-dav-in-' + i, c.url, t('dav_url_of', {name: c.name})) : null]);
      })));
    }
    return M.card('fp-dav-in-h', t('dav_incoming_title', {address: b.address}), [M.errorLine(), M.statusLine()].concat(parts), 'fp-dav-incoming');
  }

  /* ================= Connect ================= */
  function copyLine(id, value, label) {
    return el('div', {class: 'fp-dav-copy'}, [
      el('input', {class: 'sig-input sig-mono', id: id, type: 'text', readonly: '', value: value, spellcheck: 'false', 'aria-label': label}),
      el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'dav-copy', 'data-fp-for': id,
        'aria-label': t('dav_copy_of', {what: label}), text: t('dav_copy')})]);
  }
  function settingsCard() {
    var b = box();
    var rows = [
      [t('dav_set_server'), D.data.server, 'fp-dav-server'],
      [t('dav_set_user'), b.address, 'fp-dav-user'],
      [t('dav_set_url'), D.data.url, 'fp-dav-url']
    ];
    var dl = el('dl', {class: 'fp-dav-set'}, rows.reduce(function (out, r) {
      return out.concat([el('dt', {text: r[0]}), el('dd', null, [r[1] ? copyLine(r[2], r[1], r[0]) : el('span', {class: 'fp-muted', text: '—'})])]);
    }, []).concat([el('dt', {text: t('dav_set_password')}), el('dd', {text: t('dav_set_password_is')})]));
    return M.card('fp-dav-set-h', t('dav_set_title'), [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t('dav_set_desc')}), dl], 'fp-dav-settings');
  }
  function ownUrlsCard() {
    var b = box();
    var parts = [M.errorLine(), M.statusLine()];
    if (!b.cols.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('dav_urls_none')}));
    } else {
      parts.push(el('p', {class: 'fp-muted', text: t('dav_urls_desc')}));
      parts.push(el('ul', {class: 'fp-dav-urls'}, b.cols.filter(function (c) { return c.url; }).map(function (c, i) {
        return el('li', {class: 'fp-dav-url'}, [
          el('span', {class: 'fp-dav-url-head'}, [swatch(c), el('span', {class: 'fp-dav-url-name', text: c.name}), pill(c.kind === 'calendar' ? 'accent' : '', kindText(c.kind))]),
          copyLine('fp-dav-own-' + i, c.url, t('dav_url_of', {name: c.name}))]);
      })));
    }
    return M.card('fp-dav-urls-h', t('dav_urls_title'), parts, 'fp-dav-own');
  }
  function howCard() {
    return M.card('fp-dav-how-h', t('dav_how_title'), [el('dl', {class: 'fp-dav-how'}, ['apple', 'android', 'thunderbird', 'other'].reduce(function (out, k) {
      return out.concat([el('dt', {text: t('dav_how_' + k)}), el('dd', {text: t('dav_how_' + k + '_steps')})]);
    }, []))], 'fp-dav-howto');
  }

  function render() {
    var page = D.page;
    page.textContent = '';
    if (!D.data.boxes.length) { page.appendChild(noBoxes()); return; }
    if (D.data.suspended) { page.appendChild(M.suspendedBanner(t('dav_suspended'))); }
    page.appendChild(pickCard());
    if (D.view === 'manage') {
      page.appendChild(createCard());
      page.appendChild(listCard());
    } else if (D.view === 'share') {
      page.appendChild(shareCard());
      page.appendChild(incomingCard(false));
    } else {
      page.appendChild(settingsCard());
      page.appendChild(ownUrlsCard());
      page.appendChild(incomingCard(true));
      page.appendChild(howCard());
    }
  }
  function focusRow(id, act) {
    var b = D.page.querySelector('tr[data-fp-col="' + window.CSS.escape(id) + '"] [data-fp-act="' + act + '"]');
    if (b) { b.focus(); }
  }

  /* a change of a share: write or read only, or none */
  function setShare(btn, to, access) {
    var b = box();
    var c = colOf(b, D.share);
    var card = D.page.querySelector('.fp-dav-shares');
    if (!c) { return; }
    UI.showError(card, '');
    M.say(card, '');
    UI.setBusy(btn, true);
    var call = access === 'none' ? FP.call('del', 'davShare', undefined, {name: D.account, address: b.address, id: c.id, to: to}) :
      FP.call('put', 'davShare', {access: access}, {name: D.account, address: b.address, id: c.id, to: to});
    call.then(function (r) {
      if (!settle(r)) { UI.setBusy(btn, false); UI.showError(card, t('api_failed')); return; }
      render();
      M.say(D.page.querySelector('.fp-dav-shares'), t(access === 'none' ? 'dav_unshared' : access === 'write' ? 'dav_shared_write' : 'dav_shared_read', {name: c.name, who: to}));
      D.page.querySelector('#fp-dav-share-h').focus();
    }, function (err) {
      UI.setBusy(btn, false);
      UI.showError(card, err.message);
    });
  }

  document.addEventListener('click', function (e) {
    var btn = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!btn || !D.page || !D.page.contains(btn)) { return; }
    var a = btn.getAttribute('data-fp-act');
    var tr = btn.closest('tr');
    var id = tr ? tr.getAttribute('data-fp-col') : '';
    var li = btn.closest('li');
    var to = li ? li.getAttribute('data-fp-to') : '';
    if (a === 'dav-copy') {
      var input = D.page.querySelector('#' + window.CSS.escape(btn.getAttribute('data-fp-for')));
      var card = btn.closest('.sig-card');
      var done = function () { UI.showError(card, ''); M.say(card, t('dav_copied')); };
      var manual = function () { input.focus(); input.select(); M.say(card, t('dav_copy_manual')); };
      if (window.navigator.clipboard && window.navigator.clipboard.writeText) { window.navigator.clipboard.writeText(input.value).then(done, manual); } else { manual(); }
    } else if (a === 'dav-rename') {
      D.open = D.open === id ? '' : id;
      render();
      if (D.open) { D.page.querySelector('#fp-dav-rename').focus(); } else { focusRow(id, 'dav-rename'); }
    } else if (a === 'dav-close') {
      var was = D.open;
      D.open = '';
      render();
      focusRow(was, 'dav-rename');
    } else if (a === 'dav-remove') {
      var c = colOf(box(), id);
      M.confirmIn(tr.querySelector('.fp-mail-acts'), t('dav_remove_ask', {name: c ? c.name : id}), 'dav-remove-yes', t('dav_remove'));
    } else if (a === 'confirm-no') {
      render();
      focusRow(id, 'dav-remove');
    } else if (a === 'dav-remove-yes') {
      var gone = colOf(box(), id);
      var list = D.page.querySelector('.fp-dav-list');
      UI.showError(list, '');
      UI.setBusy(btn, true);
      FP.call('del', 'davItem', undefined, {name: D.account, address: box().address, id: id}).then(function (r) {
        if (!settle(r)) { render(); UI.showError(D.page.querySelector('.fp-dav-list'), t('api_failed')); return; }
        if (D.open === id) { D.open = ''; }
        render();
        M.say(D.page.querySelector('.fp-dav-list'), t('dav_removed', {name: gone ? gone.name : id}));
        D.page.querySelector('#fp-dav-list-h').focus();
      }, function (err) {
        render();
        UI.showError(D.page.querySelector('.fp-dav-list'), err.message);
        focusRow(id, 'dav-remove');
      });
    } else if (a === 'dav-to-read' || a === 'dav-to-write') {
      setShare(btn, to, a === 'dav-to-write' ? 'write' : 'read');
    } else if (a === 'dav-unshare') {
      setShare(btn, to, 'none');
    }
  });

  Object.keys(VIEWS).forEach(function (id) {
    FP.view('tool:' + id, function () {
      D.page = null;
      var body = frame(id);
      if (!body) { return; }
      var account = FP.account();
      if (picked.account !== account) { picked = {account: account, box: ''}; }
      D = {page: body, view: VIEWS[id], account: account, data: null, open: '', share: ''};
      body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
      FP.call('get', 'davList', undefined, account).then(function (r) {
        if (D.page !== body) { return; }
        body.textContent = '';
        if (!settle(r)) { body.appendChild(FP.empty(FP.tools[id].label, t('api_failed'))); return; }
        if (!box() || picked.box !== box().address) { picked.box = box() ? box().address : ''; }
        render();
      }, function (err) {
        if (D.page !== body) { return; }
        body.textContent = '';
        body.appendChild(FP.empty(FP.tools[id].label, err.message));
      });
    });
  });
})();

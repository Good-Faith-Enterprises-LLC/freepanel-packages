/* freePanel top-bar search: a combobox over every tool or function the session can use (label, group, keywords and
   description). Arrow keys move through the results, Enter opens one, Escape closes the list, "/" from anywhere on
   the page focuses the box. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var MAX = 8;
  var input = document.getElementById('fp-search');
  var list = document.getElementById('fp-search-results');
  if (!input || !list) { return; }
  var results = [];
  var active = -1;

  function score(tool, words) {
    var label = tool.label.toLowerCase();
    var hay = [label, tool.groupLabel.toLowerCase(), tool.keywords.join(' ').toLowerCase(), tool.desc.toLowerCase()];
    var total = 0;
    for (var i = 0; i < words.length; i++) {
      var w = words[i];
      if (label.indexOf(w) === 0) { total += 8; } else if (label.indexOf(' ' + w) >= 0) { total += 6; } else if (label.indexOf(w) >= 0) { total += 4; } else if (hay[2].indexOf(w) >= 0) { total += 3; } else if (hay[1].indexOf(w) >= 0) { total += 2; } else if (hay[3].indexOf(w) >= 0) { total += 1; } else { return 0; }
    }
    return total;
  }

  /* the label with the typed words marked */
  function marked(label, words) {
    var lower = label.toLowerCase();
    var spans = [];
    words.forEach(function (w) {
      var at = lower.indexOf(w);
      if (at >= 0) { spans.push([at, at + w.length]); }
    });
    spans.sort(function (a, b) { return a[0] - b[0]; });
    var out = [];
    var pos = 0;
    spans.forEach(function (s) {
      if (s[0] < pos) { return; }
      if (s[0] > pos) { out.push(document.createTextNode(label.slice(pos, s[0]))); }
      out.push(el('mark', {class: 'sig-hit', text: label.slice(s[0], s[1])}));
      pos = s[1];
    });
    if (pos < label.length) { out.push(document.createTextNode(label.slice(pos))); }
    return out;
  }

  function close() {
    list.hidden = true;
    input.setAttribute('aria-expanded', 'false');
    input.removeAttribute('aria-activedescendant');
    active = -1;
  }

  function setActive(i) {
    var items = list.querySelectorAll('[role="option"]');
    if (!items.length) { return; }
    active = (i + items.length) % items.length;
    for (var j = 0; j < items.length; j++) { items[j].setAttribute('aria-selected', String(j === active)); }
    input.setAttribute('aria-activedescendant', items[active].id);
    items[active].scrollIntoView({block: 'nearest'});
  }

  function update() {
    var q = input.value.trim().toLowerCase();
    list.textContent = '';
    results = [];
    active = -1;
    input.removeAttribute('aria-activedescendant');
    if (!q) { close(); return; }
    var words = q.split(/\s+/);
    Object.keys(FP.tools).forEach(function (id) {
      var s = score(FP.tools[id], words);
      if (s) { results.push({tool: FP.tools[id], s: s}); }
    });
    results.sort(function (a, b) { return b.s - a.s || a.tool.label.localeCompare(b.tool.label); });
    results = results.slice(0, MAX);
    if (!results.length) {
      list.appendChild(el('li', {class: 'sig-results-empty', role: 'presentation', text: t('search_none', {q: input.value.trim()})}));
    }
    results.forEach(function (r, i) {
      var opt = el('li', {class: 'sig-result', role: 'option', id: 'fp-sr-' + i, 'aria-selected': 'false', 'data-fp-i': String(i)}, [
        UI.icon(FP.sprite, r.tool.id, 'sig-ico--24'),
        el('span', {class: 'sig-result-text'}, [el('span', {class: 'sig-result-name'}, marked(r.tool.label, words)),
          el('span', {class: 'sig-result-note', text: r.tool.groupLabel})])]);
      list.appendChild(opt);
    });
    list.hidden = false;
    input.setAttribute('aria-expanded', 'true');
    UI.announce(results.length === 1 ? t('search_count_1') : results.length ? t('search_count', {n: results.length}) : t('search_none', {q: input.value.trim()}));
  }

  function open(i) {
    var r = results[i];
    if (!r) { return; }
    close();
    input.value = '';
    input.blur();
    if (r.tool.external) { window.open(r.tool.href, '_blank', 'noopener'); return; }
    if (window.location.hash === r.tool.href) { FP.route(true); } else { window.location.hash = r.tool.href; }
  }

  input.addEventListener('input', update);
  input.addEventListener('focus', function () { if (input.value.trim()) { update(); } });
  input.addEventListener('keydown', function (e) {
    if (e.key === 'ArrowDown') { e.preventDefault(); if (list.hidden) { update(); } setActive(active + 1); } else if (e.key === 'ArrowUp') { e.preventDefault(); setActive(active - 1); } else if (e.key === 'Enter') {
      e.preventDefault();
      open(active >= 0 ? active : 0);
    } else if (e.key === 'Escape') {
      if (!list.hidden) { e.stopPropagation(); close(); } else if (input.value) { input.value = ''; }
    }
  });
  input.addEventListener('blur', function () { window.setTimeout(function () { if (document.activeElement !== input) { close(); } }, 150); });
  list.addEventListener('mousedown', function (e) { e.preventDefault(); });
  list.addEventListener('click', function (e) {
    var opt = e.target.closest ? e.target.closest('[role="option"]') : null;
    if (opt) { open(parseInt(opt.getAttribute('data-fp-i'), 10)); }
  });
  document.addEventListener('keydown', function (e) {
    if (e.key !== '/' || e.ctrlKey || e.metaKey || e.altKey) { return; }
    var tag = (document.activeElement && document.activeElement.tagName) || '';
    if (/^(INPUT|TEXTAREA|SELECT)$/.test(tag) || (document.activeElement && document.activeElement.isContentEditable)) { return; }
    e.preventDefault();
    input.focus();
  });
})();

/* freePanel billing message log (#/tool/billing_outbox; docs/api.md, "Billing: messages"; docs/billing/navigation-map.md, "Message log"):
   the mail billing wrote to clients, filtered by status and client, each message opened with its text, and a sending round run now after a
   question. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var B = FP.billing;
  var M = FP.mail;

  /* ================= The message log ================= */
  var MSG = {id: 'id', customer_id: 'id', invoice_id: 'id', kind: [40], to: [254], subject: [200], body: [10000], status: ['=', ['queued', 'sent', 'failed']], attempts: 'n', error: [300],
    created: 'w', sent: 'w'};
  function cleanMsg(x) { var m = B.pick(x, MSG); return m && m.id ? m : null; }
  FP.view('tool:billing_outbox', function () {
    var page = B.frame('billing_outbox', 'fp-bob');
    if (!page) { return; }
    var names = {};
    var alive = function () { return page.isConnected; };
    var L = B.lister({page: page, pre: 'fp-bob', title: t('bob_list_title'), findLabel: t('bob_find'), tableCls: 'fp-bob-table', alive: alive,
      before: function () { return [el('div', {class: 'fp-bil-toolbar', 'data-fp-acts': ''}, [B.button('send-round', t('bob_send'), 'sig-btn--secondary')]), el('p', {class: 'fp-muted fp-row-note', text: t('bob_what')})]; },
      blank: {status: '', customer: ''},
      filters: [
        {name: 'status', label: t('bob_f_status'), control: function (v) { return B.select('fp-bob-f-status', 'status', [['', t('bil_any')]].concat(['queued', 'sent', 'failed'].map(function (s) { return [s, B.word('msg', s)]; })), v); }},
        {name: 'customer', control: function (v) { return B.clientPicker('fp-bob-f-client', {name: 'customer', label: t('bob_f_client'), placeholder: t('bil_any'), value: v, valueName: v ? names[v] : ''}); }}],
      load: function (f, offset, limit) {
        return B.listOf('billingOutbox', {limit: String(limit), offset: String(offset), status: f.status, customer: f.customer}, 'messages', cleanMsg).then(function (r) {
          return B.namesFor(names, r.items.map(function (x) { return x.customer_id; })).then(function () { return r; });
        });
      },
      heads: [B.th(t('bob_col_date')), B.th(t('bob_col_client')), B.th(t('bob_col_kind')), B.th(t('bob_col_to')), B.th(t('bob_col_subject')), B.th(t('bob_col_status'))],
      row: function (m) {
        return el('tr', {'data-fp-msg': String(m.id)}, [el('td', {class: 'fp-bil-nowrap', text: B.when(m.created) || '—'}), el('td', {class: 'fp-bil-wrap', text: B.nameIn(names, m.customer_id)}),
          el('td', {text: B.word('mkind', m.kind)}), el('td', {class: 'fp-bil-wrap fp-bil-email', text: m.to || '—'}),
          el('th', {scope: 'row', class: 'fp-bil-name'}, [B.button('open', m.subject || '—', 'sig-btn--link fp-bil-link', {'data-fp-id': String(m.id), 'aria-label': t('bob_open_of', {name: m.subject})})]),
          el('td', null, [B.statePill('msg', m.status), m.status === 'failed' && m.error ? el('span', {class: 'fp-muted fp-row-note fp-bob-why', text: m.error}) : null])]);
      },
      none: t('bob_none'), noneMatch: t('bob_none_match'),
      found: function (n) { return n === 1 ? t('bob_found_1') : t('bob_found', {n: B.num(n)}); }});
    function openMsg(mid, b) {
      UI.setBusy(b, true);
      FP.call('get', 'billingOutboxOne', undefined, {id: String(mid)}).then(function (r) {
        if (!alive()) { return; }
        var m = cleanMsg(r);
        if (!m) { throw {message: t('api_failed')}; }
        B.screen(page, [B.back('to-list', t('bob_back')), B.card('fp-bob-msg-h', m.subject || '—', [B.facts([[t('bob_col_to'), m.to], [t('bob_col_client'), B.nameIn(names, m.customer_id)],
          [t('bob_col_kind'), B.word('mkind', m.kind)], [t('bob_col_status'), [B.statePill('msg', m.status)]], [t('bob_col_date'), B.when(m.created)], [t('bob_sent'), B.when(m.sent)],
          [t('bob_attempts'), m.attempts === null ? '—' : B.num(m.attempts)], m.error ? [t('bob_error'), m.error] : null]),
          el('h3', {class: 'fp-h3 fp-brp-sub', text: t('bob_body')}), el('pre', {class: 'fp-bob-body', 'data-fp-body': '', text: m.body})], 'fp-bob-msg', 'message')], '#fp-bob-msg-h');
        page.setAttribute('data-fp-from', String(mid));
      }).catch(function (err) {
        if (!alive()) { return; }
        UI.setBusy(b, false);
        L.error(err);
        b.focus();
      });
    }
    page.addEventListener('click', function (e) {
      var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
      if (!b || b.disabled || !alive()) { return; }
      var a = b.getAttribute('data-fp-act');
      if (a === 'open') {
        openMsg(Number(b.getAttribute('data-fp-id')), b);
      } else if (a === 'to-list') {
        var from = page.getAttribute('data-fp-from');
        L.show(from ? '[data-fp-act="open"][data-fp-id="' + from + '"]' : '#fp-bob-list-h');
      } else if (a === 'send-round') {
        M.confirmIn(b.closest('[data-fp-acts]'), t('bob_send_ask'), 'send-round-yes', t('bob_send_yes'));
      } else if (a === 'send-round-yes') {
        UI.setBusy(b, true);
        FP.call('post', 'billingMessagesSend', {}).then(function (r) {
          if (!alive()) { return; }
          var n = function (k) { return B.num(B.whole(r && r[k]) || 0); };
          L.show('#fp-bob-list-h', t('bob_sent_said', {queued: n('queued'), sent: n('sent'), failed: n('failed')}));
        }, function (err) {
          if (!alive()) { return; }
          L.show('[data-fp-act="send-round"]').then(function () { L.error(err); });
        });
      } else if (a === 'confirm-no' && b.closest('[data-fp-acts]')) {
        var box = b.closest('[data-fp-acts]');
        box.textContent = '';
        var again = B.button('send-round', t('bob_send'), 'sig-btn--secondary');
        box.appendChild(again);
        again.focus();
      }
    });
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    L.show();
  });
})();

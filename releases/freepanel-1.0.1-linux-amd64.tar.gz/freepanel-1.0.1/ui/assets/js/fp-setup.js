/* freePanel first run: create the first admin login with the token the installer printed
   (https://HOST:7443/setup#TOKEN, docs/api.md). The token stays in the fragment, so it never reaches a server log,
   and the page removes it from the address bar. */
(function () {
  'use strict';
  var UI = window.FPUI;
  var API = window.FPAPI;
  var MIN = 12;
  var USER_RE = /^[a-z][a-z0-9]{0,15}$/;
  var FIELDS = {username: 'fp-setup-user', email: 'fp-setup-email', password: 'fp-new'};
  var token = window.location.hash.replace(/^#/, '');
  if (token && window.history && window.history.replaceState) {
    window.history.replaceState(null, '', window.location.pathname + window.location.search);
  }

  function $(sel, scope) { return (scope || document).querySelector(sel); }
  var scope = document.getElementById('fp-step-setup');
  var form = $('form', scope);
  var button = $('.fp-submit', form);

  function invalid(input, message) {
    input.setAttribute('aria-invalid', 'true');
    UI.showError(scope, message);
    input.focus();
  }
  function done(title, text) {
    scope.hidden = true;
    var step = document.getElementById('fp-step-done');
    if (title) { $('[data-fp-done-title]', step).textContent = title; }
    if (text) { $('[data-fp-done-text]', step).textContent = text; }
    step.hidden = false;
    $('h1', step).focus();
  }

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    if (button.disabled) { return; }
    var user = $('#fp-setup-user');
    var email = $('#fp-setup-email');
    var first = $('#fp-new');
    var again = $('#fp-again');
    [user, email, first, again].forEach(function (i) { i.removeAttribute('aria-invalid'); });
    UI.showError(scope, '');
    if (!USER_RE.test(user.value.trim())) { invalid(user, UI.t('setup_bad_username')); return; }
    if (first.value.length < MIN) { invalid(first, UI.t('weak_password')); return; }
    if (again.value !== first.value) { invalid(again, UI.t('passwords_differ')); return; }
    var body = {token: token, username: user.value.trim(), password: first.value};
    if (email.value.trim()) { body.email = email.value.trim(); }
    UI.setBusy(button, true);
    API.post('setup', body).then(function () {
      first.value = '';
      again.value = '';
      done('', '');
    }, function (err) {
      UI.setBusy(button, false);
      if (err.code === 'validation_failed' && FIELDS[err.field]) { invalid(document.getElementById(FIELDS[err.field]), err.message); return; }
      UI.showError(scope, err.message);
    });
  });

  API.get('health').then(function (h) {
    if (h.realm === 'user') {   /* setup runs on the admin port only (docs/api.md) */
      done(UI.t('setup_wrong_port_title'), UI.t('setup_wrong_port_text'));
      $('.fp-auth-links', document.getElementById('fp-step-done')).hidden = true;
      return;
    }
    if (h.setup_required === false) {
      done(UI.t('setup_done_title'), UI.t('setup_done_text'));
      return;
    }
    if (!token) {
      UI.showError(scope, UI.t('setup_missing_token'));
      button.disabled = true;
      return;
    }
    $('#fp-setup-user').focus();
  }, function (err) { UI.showError(scope, err.message); });
})();

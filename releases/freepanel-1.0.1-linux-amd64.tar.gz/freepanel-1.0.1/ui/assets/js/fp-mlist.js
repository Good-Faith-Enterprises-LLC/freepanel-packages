/* freePanel mailing lists (docs/api.md, "Mailing lists"): the customer panel's Mailing lists page (#/tool/mailing_lists).
   A list is an address on one of the account's domains; mail to it goes to every member, re-sent by the list with its
   own From address, the list's headers and the subject prefix. The page lists the account's lists, makes new ones
   (address, owners, who may post, where replies go, prefix, largest message and the first members, pasted), and opens
   one list to add or take off members in bulk, take one off, and change its settings. Members and owners are checked
   here as the server keeps them (lower case, never the list's own address) before anything is sent. Where the server
   cannot run lists (available false) the page says why and offers nothing to change. Page pieces come from FP.mail. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var DOMAIN_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var LOCAL_RE = /^[a-z0-9_-]+(\.[a-z0-9_-]+)*$/;
  /* a list's name and prefix: printable ASCII without quotes or brackets */
  var TEXT_RE = /^[A-Za-z0-9 !#$%&'*+,./:;=?@^_{|}~-]*$/;
  var POSTING = ['members', 'owners', 'anyone'];
  var REPLY = ['sender', 'list'];
  var MAX_NAME = 64;
  var MAX_PREFIX = 32;
  var MAX_MB = 50;
  var SHOWN = 50;

  function str(v) { return typeof v === 'string' ? v : ''; }
  function int(v, max) { return typeof v === 'number' && v >= 0 && v <= max ? Math.floor(v) : 0; }
  function addresses(v) {
    var out = (Array.isArray(v) ? v : []).filter(M.isAddress);
    return out.filter(function (a, i) { return out.indexOf(a) === i; });
  }
  function cleanList(l) {
    if (!l || !M.isAddress(l.address)) { return null; }
    return {address: l.address, name: TEXT_RE.test(str(l.name)) ? str(l.name).slice(0, MAX_NAME) : '', owners: addresses(l.owners).slice(0, 10),
      posting: POSTING.indexOf(l.posting) >= 0 ? l.posting : 'members', reply: REPLY.indexOf(l.reply_to) >= 0 ? l.reply_to : 'sender',
      prefix: TEXT_RE.test(str(l.prefix)) ? str(l.prefix).slice(0, MAX_PREFIX) : '', maxKB: int(l.max_kb, MAX_MB * 1024),
      count: int(l.member_count, 1e6), members: Array.isArray(l.members) ? addresses(l.members).sort() : null, served: l.served === true,
      ownerAddress: M.isAddress(l.owner_address) ? l.owner_address : '', unsubAddress: M.isAddress(l.unsubscribe_address) ? l.unsubscribe_address : ''};
  }
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var lists = (Array.isArray(r.lists) ? r.lists : []).map(cleanList).filter(Boolean).sort(function (a, b) { return a.address < b.address ? -1 : 1; });
    return {available: r.available === true, why: str(r.why).slice(0, 300), suspended: r.suspended === true, lists: lists,
      maxLists: int(r.max_lists, 1e4) || 100, maxMembers: int(r.max_members, 1e6) || 5000, maxOwners: int(r.max_owners, 100) || 10};
  }
  function namesOf(v) {
    var out = [];
    (v && Array.isArray(v.sites) ? v.sites : []).forEach(function (s) {
      [s && s.domain].concat(s && Array.isArray(s.aliases) ? s.aliases : []).forEach(function (d) {
        if (typeof d === 'string' && DOMAIN_RE.test(d) && out.indexOf(d) < 0) { out.push(d); }
      });
    });
    return out;
  }
  /* pasted addresses, one or many a line, "Name <address>" taken as the address: {ok, bad}, ok without repeats */
  function parse(text, list) {
    var ok = [];
    var bad = [];
    str(text).split(/\r?\n/).forEach(function (line) {
      var inside = line.match(/<([^<>\s]+)>/g);
      var tokens = inside ? inside.map(function (s) { return s.slice(1, -1); }) : line.split(/[\s,;]+/);
      tokens.forEach(function (s) {
        s = s.trim().replace(/^["']|["']$/g, '').toLowerCase();
        if (!s) { return; }
        if (!M.isAddress(s) || own(list, s)) { if (bad.indexOf(s) < 0) { bad.push(s); } return; }
        if (ok.indexOf(s) < 0) { ok.push(s); }
      });
    });
    return {ok: ok, bad: bad};
  }
  /* the list's own address, or one of its +word addresses */
  function own(list, a) {
    if (!list) { return false; }
    var at = list.lastIndexOf('@');
    var local = list.slice(0, at);
    var dom = list.slice(at + 1);
    var i = a.lastIndexOf('@');
    return a.slice(i + 1) === dom && (a.slice(0, i) === local || a.slice(0, i).indexOf(local + '+') === 0);
  }
  function sizeText(kb) { return kb ? t('mlist_size_mb', {n: String(Math.round(kb / 1024 * 10) / 10)}) : t('mlist_size_server'); }

  var P = {page: null, account: '', data: null, names: [], open: '', detail: null, filter: ''};

  /* ---------- the lists ---------- */
  function postingPill(p) {
    return el('span', {class: 'sig-pill' + (p === 'anyone' ? ' sig-pill--warn' : (p === 'owners' ? ' sig-pill--accent' : '')), text: t('mlist_who_' + p)});
  }
  function listsCard() {
    var d = P.data;
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted fp-mlist-intro', text: t('mlist_intro')})];
    if (!d.lists.length) {
      parts.push(el('div', {class: 'fp-mlist-empty', 'data-fp-mlist-empty': ''}, [
        el('p', {class: 'fp-mlist-empty-title', text: t('mlist_none')}),
        el('p', {class: 'fp-muted', text: d.available && P.names.length ? t('mlist_none_hint') : t('mlist_none_cannot')})]));
    } else {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-mlist-h'}, [
        el('table', {class: 'sig-table fp-mail-table fp-mlist-table'}, [el('thead', null, [el('tr', null, [
          el('th', {scope: 'col', text: t('mlist_col_list')}), el('th', {scope: 'col', text: t('mlist_col_posting')}),
          el('th', {scope: 'col', class: 'fp-mlist-num', text: t('mlist_col_members')}), el('th', {scope: 'col', text: t('mlist_col_delivery')}),
          el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]),
        el('tbody', null, d.lists.map(function (l) {
          return el('tr', {'data-fp-list': l.address, class: l.address === P.open ? 'fp-mlist-current' : null}, [
            el('th', {scope: 'row', class: 'fp-mail-name'}, [el('span', {text: l.address}),
              l.name ? el('span', {class: 'fp-muted fp-row-note', text: l.name}) : null]),
            el('td', null, [postingPill(l.posting)]),
            el('td', {class: 'fp-mlist-num', text: l.count.toLocaleString('en')}),
            el('td', null, [l.served ? el('span', {class: 'sig-pill sig-pill--ok', text: t('mlist_on')}) :
              el('span', {class: 'fp-mail-elsewhere'}, [el('span', {class: 'sig-pill sig-pill--warn', text: t('mlist_off')}),
                el('span', {class: 'fp-muted fp-row-note', text: d.suspended ? t('mlist_off_suspended') : t('mlist_off_why')})])]),
            el('td', {class: 'fp-mail-acts'}, [
              el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'mlist-open',
                'aria-label': t('mlist_manage_of', {address: l.address}), text: t('mlist_manage')}),
              el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'mlist-remove',
                'aria-label': t('mlist_remove_of', {address: l.address}), text: t('mlist_remove')})])]);
        }))])]));
    }
    return M.card('fp-mlist-h', t('mlist_title', {n: d.lists.length}), parts, 'fp-mlist-lists');
  }

  /* ---------- the settings fields, shared by the two forms ---------- */
  function radios(name, values, chosen, id) {
    return el('fieldset', {class: 'fp-mlist-set'}, [el('legend', {class: 'sig-label', text: t('mlist_' + name)})].concat(values.map(function (v) {
      var rid = id + '-' + name + '-' + v;
      var input = el('input', {type: 'radio', id: rid, name: name, value: v, 'aria-describedby': rid + '-hint'});
      if (v === chosen) { input.checked = true; }
      return el('div', {class: 'fp-mlist-choice'}, [el('label', {class: 'fp-check', for: rid}, [input, el('span', {text: t('mlist_' + name + '_' + v)})]),
        el('span', {class: 'sig-hint', id: rid + '-hint', text: t('mlist_' + name + '_' + v + '_hint')})]);
    })));
  }
  function settingsFields(id, l) {
    return [
      M.field(id + '-name', t('mlist_name'), el('input', {class: 'sig-input', id: id + '-name', name: 'name', type: 'text', maxlength: String(MAX_NAME),
        autocomplete: 'off', value: l ? l.name : ''}), t('mlist_name_hint')),
      M.field(id + '-owners', t('mlist_owners'), el('textarea', {class: 'sig-input fp-mlist-addrs', id: id + '-owners', name: 'owners', rows: '2',
        spellcheck: 'false', autocapitalize: 'none', autocomplete: 'off', text: l ? l.owners.join('\n') : ''}), t('mlist_owners_hint', {n: P.data.maxOwners})),
      radios('posting', POSTING, l ? l.posting : 'members', id),
      radios('reply_to', REPLY, l ? l.reply : 'sender', id),
      el('div', {class: 'fp-mlist-pair'}, [
        M.field(id + '-prefix', t('mlist_prefix'), el('input', {class: 'sig-input', id: id + '-prefix', name: 'prefix', type: 'text',
          maxlength: String(MAX_PREFIX), autocomplete: 'off', spellcheck: 'false', value: l ? l.prefix : ''}), t('mlist_prefix_hint')),
        M.field(id + '-size', t('mlist_size'), el('input', {class: 'sig-input fp-mlist-size', id: id + '-size', name: 'max_kb', type: 'number',
          inputmode: 'decimal', min: '0', max: String(MAX_MB), step: '0.5', value: l ? String(Math.round(l.maxKB / 1024 * 10) / 10) : '10'}), t('mlist_size_hint', {n: MAX_MB}))])];
  }
  /* the settings a form holds, or null with the field marked */
  function readSettings(form, list) {
    var f = function (n) { return form.querySelector('[name="' + n + '"]'); };
    var name = f('name').value.trim();
    if (name.length > MAX_NAME || !TEXT_RE.test(name)) { M.fieldError(form, f('name'), t('mlist_text_bad', {label: t('mlist_name'), n: MAX_NAME})); return null; }
    var owners = parse(f('owners').value, list);
    if (owners.bad.length) { M.fieldError(form, f('owners'), t(own(list, owners.bad[0]) ? 'mlist_owner_own' : 'mlist_addr_bad', {address: owners.bad[0]})); return null; }
    if (!owners.ok.length) { M.fieldError(form, f('owners'), t('mlist_owners_none')); return null; }
    if (owners.ok.length > P.data.maxOwners) { M.fieldError(form, f('owners'), t('mlist_owners_many', {n: P.data.maxOwners})); return null; }
    var prefix = f('prefix').value.trim();
    if (prefix.length > MAX_PREFIX || !TEXT_RE.test(prefix)) { M.fieldError(form, f('prefix'), t('mlist_text_bad', {label: t('mlist_prefix'), n: MAX_PREFIX})); return null; }
    var mb = f('max_kb').value.trim();
    var n = Number(mb === '' ? '0' : mb);
    if (!isFinite(n) || n < 0 || n > MAX_MB || Math.abs(n * 2 - Math.round(n * 2)) > 1e-9) { M.fieldError(form, f('max_kb'), t('mlist_size_bad', {n: MAX_MB})); return null; }
    var checked = function (n) { var c = form.querySelector('[name="' + n + '"]:checked'); return c ? c.value : ''; };
    return {name: name, owners: owners.ok, posting: checked('posting') || 'members', reply_to: checked('reply_to') || 'sender', prefix: prefix,
      max_kb: Math.round(n * 1024)};
  }

  /* ---------- a new list ---------- */
  function createCard() {
    var id = 'fp-mlist-new';
    var local = el('input', {class: 'sig-input', id: id, name: 'address', type: 'text', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none',
      maxlength: '64', 'aria-describedby': id + '-hint'});
    var pick = el('select', {class: 'sig-select', id: id + '-domain', name: 'domain', 'aria-label': t('mlist_domain')},
      P.names.map(function (d) { return el('option', {value: d, text: d}); }));
    var members = el('textarea', {class: 'sig-input fp-mlist-addrs', id: id + '-members', name: 'members', rows: '4', spellcheck: 'false',
      autocapitalize: 'none', autocomplete: 'off'});
    var form = el('form', {class: 'fp-form fp-mail-form fp-mlist-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: id, text: t('mlist_address')}),
        el('div', {class: 'fp-mail-addr'}, [local, el('span', {class: 'fp-mail-at', 'aria-hidden': 'true', text: '@'}), pick]),
        el('span', {class: 'sig-hint', id: id + '-hint', text: t('mlist_address_hint')})])]
      .concat(settingsFields(id, null))
      .concat([M.field(id + '-members', t('mlist_first_members'), members, t('mlist_paste_hint', {n: P.data.maxMembers.toLocaleString('en')})),
        el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('mlist_create')})])]));
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var v = local.value.trim().toLowerCase();
      if (!v) { M.fieldError(form, local, t('mlist_address_none')); return; }
      if (v.indexOf('@') >= 0) { M.fieldError(form, local, t('mlist_address_at')); return; }
      if (v.indexOf('+') >= 0) { M.fieldError(form, local, t('mlist_address_plus')); return; }
      if (v.length > 64 || !LOCAL_RE.test(v)) { M.fieldError(form, local, t('mlist_address_bad')); return; }
      var addr = v + '@' + pick.value;
      var taken = P.data.lists.some(function (l) { return l.address === addr; });
      if (taken) { M.fieldError(form, local, t('mlist_address_taken', {address: addr})); return; }
      var body = readSettings(form, addr);
      if (!body) { return; }
      var first = parse(members.value, addr);
      if (first.bad.length) { M.fieldError(form, members, t(own(addr, first.bad[0]) ? 'mlist_member_own' : 'mlist_addr_bad', {address: first.bad[0]})); return; }
      if (first.ok.length > P.data.maxMembers) { M.fieldError(form, members, t('mlist_members_many', {n: P.data.maxMembers.toLocaleString('en')})); return; }
      body.address = addr;
      if (first.ok.length) { body.members = first.ok; }
      UI.setBusy(b, true);
      FP.call('post', 'mailLists', body, P.account).then(function (r) {
        var made = clean(r).lists[0];
        P.open = made ? made.address : '';
        P.detail = made || null;
        return refresh(t('mlist_created', {address: addr, n: made ? made.count : 0}), '#fp-mlist-d-h');
      }, function (err) {
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return M.card('fp-mlist-new-h', t('mlist_new_title'), [form], 'fp-mlist-new');
  }

  /* ---------- one list ---------- */
  function memberItems(l) {
    var q = P.filter.trim().toLowerCase();
    var all = l.members || [];
    var hits = q ? all.filter(function (a) { return a.indexOf(q) >= 0; }) : all;
    var shown = hits.slice(0, SHOWN);
    var parts = [];
    if (!all.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-mlist-nomembers': '', text: t('mlist_members_none')}));
      return parts;
    }
    if (shown.length) {
      parts.push(el('ul', {class: 'fp-mlist-members', 'aria-labelledby': 'fp-mlist-m-h'}, shown.map(function (a) {
        return el('li', {'data-fp-member': a}, [el('span', {class: 'sig-mono fp-mlist-addr', text: a}),
          el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'mlist-member-off',
            'aria-label': t('mlist_member_off_of', {address: a}), text: t('mlist_member_off')})]);
      })));
    } else {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-mlist-nohits': '', text: t('mlist_filter_none', {q: q})}));
    }
    if (hits.length > shown.length) { parts.push(el('p', {class: 'sig-hint', text: t('mlist_shown', {n: shown.length, of: hits.length.toLocaleString('en')})})); }
    return parts;
  }
  function membersPart(l) {
    var box = el('div', {class: 'fp-mlist-memberlist', 'aria-live': 'polite'}, memberItems(l));
    var filter = (l.members || []).length > 10 ? M.field('fp-mlist-filter', t('mlist_filter'), el('input', {class: 'sig-input', id: 'fp-mlist-filter',
      name: 'filter', type: 'search', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', value: P.filter})) : null;
    if (filter) {
      filter.querySelector('input').addEventListener('input', function (e) {
        P.filter = e.target.value;
        box.textContent = '';
        memberItems(l).forEach(function (n) { box.appendChild(n); });
      });
    }
    var paste = el('textarea', {class: 'sig-input fp-mlist-addrs', id: 'fp-mlist-paste', name: 'paste', rows: '4', spellcheck: 'false',
      autocapitalize: 'none', autocomplete: 'off'});
    var off = el('button', {class: 'sig-btn sig-btn--secondary fp-mlist-takeoff', type: 'button', text: t('mlist_paste_remove')});
    var form = el('form', {class: 'fp-form fp-mlist-paste-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-mlist-paste', t('mlist_paste'), paste, t('mlist_paste_hint', {n: P.data.maxMembers.toLocaleString('en')})),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('mlist_paste_add')}), off])]);
    function send(kind) {
      var b = M.start(form);
      if (!b) { return; }
      var got = parse(paste.value, l.address);
      if (!got.ok.length && !got.bad.length) { M.fieldError(form, paste, t('mlist_paste_none')); return; }
      if (got.bad.length) { M.fieldError(form, paste, t(own(l.address, got.bad[0]) ? 'mlist_member_own' : 'mlist_addr_bad', {address: got.bad[0]})); return; }
      if (kind === 'add' && got.ok.filter(function (a) { return (l.members || []).indexOf(a) < 0; }).length + l.count > P.data.maxMembers) {
        M.fieldError(form, paste, t('mlist_members_many', {n: P.data.maxMembers.toLocaleString('en')})); return;
      }
      var body = kind === 'add' ? {add: got.ok} : {remove: got.ok};
      UI.setBusy(b, true);
      off.disabled = true;
      FP.call('post', 'mailListMembers', body, {name: P.account, address: l.address}).then(function (r) {
        var c = r && r.change ? r.change : {};
        var said = kind === 'add' ? t(int(c.already, 1e6) ? 'mlist_added' : 'mlist_added_all', {n: int(c.added, 1e6), already: int(c.already, 1e6)}) :
          t(int(c.missing, 1e6) ? 'mlist_removed' : 'mlist_removed_all', {n: int(c.removed, 1e6), missing: int(c.missing, 1e6)});
        P.detail = clean(r).lists[0] || P.detail;
        return refresh(said, '#fp-mlist-paste', '.fp-mlist-paste-form');
      }, function (err) {
        UI.setBusy(b, false);
        off.disabled = false;
        M.fieldError(form, paste, err.message);
      });
    }
    form.addEventListener('submit', function (e) { e.preventDefault(); send('add'); });
    off.addEventListener('click', function () { send('remove'); });
    return el('div', {class: 'fp-mlist-part'}, [
      el('h3', {class: 'fp-h3', id: 'fp-mlist-m-h', tabindex: '-1', text: t('mlist_members_title', {n: l.count.toLocaleString('en')})}),
      filter, box, form]);
  }
  function settingsPart(l) {
    var id = 'fp-mlist-edit';
    var form = el('form', {class: 'fp-form fp-mail-form fp-mlist-settings', novalidate: ''}, [M.errorLine(), M.statusLine()]
      .concat(settingsFields(id, l))
      .concat([el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('mlist_save')})])]));
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var body = readSettings(form, l.address);
      if (!body) { return; }
      UI.setBusy(b, true);
      FP.call('put', 'mailList', body, {name: P.account, address: l.address}).then(function (r) {
        P.detail = clean(r).lists[0] || P.detail;
        return refresh(t('mlist_saved', {address: l.address}), '#fp-mlist-s-h', '.fp-mlist-settings');
      }, function (err) {
        UI.setBusy(b, false);
        M.failed(form, err);
      });
    });
    return el('div', {class: 'fp-mlist-part'}, [el('h3', {class: 'fp-h3', id: 'fp-mlist-s-h', tabindex: '-1', text: t('mlist_settings_title')}), form]);
  }
  function detailCard(l) {
    var facts = el('dl', {class: 'fp-mail-facts fp-mlist-facts'}, [
      el('dt', {text: t('mlist_fact_post')}), el('dd', {class: 'sig-mono', text: l.posting === 'owners' ? t('mlist_fact_post_owners', {address: l.address}) : l.address}),
      el('dt', {text: t('mlist_fact_owner')}), el('dd', {class: 'sig-mono', text: l.ownerAddress}),
      el('dt', {text: t('mlist_fact_unsub')}), el('dd', {class: 'sig-mono', text: l.unsubAddress}),
      el('dt', {text: t('mlist_fact_size')}), el('dd', {text: sizeText(l.maxKB)})]);
    return M.card('fp-mlist-d-h', l.address, [M.errorLine(), M.statusLine(),
      el('div', {class: 'fp-mlist-back'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'mlist-close',
        text: t('mlist_back')})]),
      l.name ? el('p', {class: 'fp-mlist-name', text: l.name}) : null,
      facts,
      el('p', {class: 'fp-muted fp-mlist-how', text: t('mlist_how_' + l.reply)}),
      membersPart(l), settingsPart(l)], 'fp-mlist-detail');
  }

  /* ---------- drawing ---------- */
  function render() {
    var d = P.data;
    P.page.textContent = '';
    if (d.suspended) { P.page.appendChild(M.suspendedBanner(t('mlist_suspended'))); }
    if (!d.available) {
      P.page.appendChild(el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-mlist-off': ''}, [UI.icon(FP.ui, 'ui_warning'),
        el('span', {text: t('mlist_unavailable', {why: d.why || t('mlist_unavailable_unknown')})})]));
    }
    P.page.appendChild(listsCard());
    var open = P.open && P.detail && P.detail.members ? P.detail : null;
    if (open) {
      P.page.appendChild(detailCard(open));
    } else if (d.available && !d.suspended) {
      if (!P.names.length) {
        P.page.appendChild(M.card('fp-mlist-new-h', t('mlist_new_title'), [el('p', {class: 'fp-muted', 'data-fp-mlist-nodomains': '', text: t('mlist_no_domains')})], 'fp-mlist-new'));
      } else if (d.lists.length >= d.maxLists) {
        P.page.appendChild(M.card('fp-mlist-new-h', t('mlist_new_title'), [el('p', {class: 'fp-muted', text: t('mlist_full', {n: d.maxLists})})], 'fp-mlist-new'));
      } else {
        P.page.appendChild(createCard());
      }
    }
  }
  /* reads the lists (and the open one with its members) again, draws, says what changed on the card that changed */
  function refresh(said, focus, where) {
    var page = P.page;
    var calls = [FP.call('get', 'mailLists', undefined, P.account)];
    if (P.open) { calls.push(FP.call('get', 'mailList', undefined, {name: P.account, address: P.open}).then(null, function () { return null; })); }
    return Promise.all(calls).then(function (r) {
      if (P.page !== page) { return; }
      P.data = clean(r[0]);
      if (P.open) {
        var one = r[1] ? clean(r[1]).lists[0] : null;
        P.detail = one || null;
        if (!one) { P.open = ''; }
      }
      render();
      var card = (where && P.page.querySelector(where)) || P.page.querySelector(P.open ? '.fp-mlist-detail' : '.fp-mlist-lists');
      M.say(card, said);
      var f = (focus && P.page.querySelector(focus)) || P.page.querySelector('#fp-mlist-h');
      if (f) { f.focus(); }
    }, function (err) {
      if (P.page !== page) { return; }
      UI.showError(P.page.querySelector('.fp-mlist-lists'), err.message);
    });
  }
  function openList(addr, b) {
    var card = P.page.querySelector('.fp-mlist-lists');
    UI.showError(card, '');
    if (b) { UI.setBusy(b, true); }
    FP.call('get', 'mailList', undefined, {name: P.account, address: addr}).then(function (r) {
      P.open = addr;
      P.detail = clean(r).lists[0] || null;
      P.filter = '';
      render();
      var h = P.page.querySelector('#fp-mlist-d-h');
      if (h) { h.focus(); }
    }, function (err) {
      if (b) { UI.setBusy(b, false); }
      UI.showError(card, err.message);
    });
  }

  function onClick(e) {
    if (!P.page) { return; }
    var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !P.page.contains(b)) { return; }
    var a = b.getAttribute('data-fp-act');
    var tr = b.closest('tr[data-fp-list]');
    var addr = tr ? tr.getAttribute('data-fp-list') : '';
    if (a === 'mlist-open') {
      openList(addr, b);
    } else if (a === 'mlist-close') {
      var was = P.open;
      P.open = '';
      P.detail = null;
      render();
      var row = P.page.querySelector('tr[data-fp-list="' + window.CSS.escape(was) + '"] [data-fp-act="mlist-open"]');
      (row || P.page.querySelector('#fp-mlist-h')).focus();
    } else if (a === 'mlist-remove') {
      M.confirmIn(tr.querySelector('.fp-mail-acts'), t('mlist_remove_ask', {address: addr}), 'mlist-remove-yes', t('mlist_remove'));
    } else if (a === 'confirm-no' && tr) {
      render();
      var again = P.page.querySelector('tr[data-fp-list="' + window.CSS.escape(addr) + '"] [data-fp-act="mlist-remove"]');
      if (again) { again.focus(); }
    } else if (a === 'mlist-remove-yes') {
      UI.setBusy(b, true);
      FP.call('del', 'mailList', undefined, {name: P.account, address: addr}).then(function () {
        if (P.open === addr) { P.open = ''; P.detail = null; }
        return refresh(t('mlist_removed_list', {address: addr}));
      }, function (err) {
        UI.setBusy(b, false);
        UI.showError(P.page.querySelector('.fp-mlist-lists'), err.message);
      });
    } else if (a === 'mlist-member-off') {
      var who = b.closest('[data-fp-member]').getAttribute('data-fp-member');
      var list = P.detail;
      /* the focus goes to the address shown after it, or before it, or to the heading */
      var q = P.filter.trim().toLowerCase();
      var seen = list.members.filter(function (x) { return !q || x.indexOf(q) >= 0; }).slice(0, SHOWN);
      var at = seen.indexOf(who);
      var next = seen[at + 1] || seen[at - 1];
      UI.setBusy(b, true);
      FP.call('post', 'mailListMembers', {remove: [who]}, {name: P.account, address: list.address}).then(function (r) {
        P.detail = clean(r).lists[0] || P.detail;
        return refresh(t('mlist_member_gone', {address: who}),
          next ? '[data-fp-member="' + window.CSS.escape(next) + '"] [data-fp-act="mlist-member-off"]' : '#fp-mlist-m-h', '.fp-mlist-detail');
      }, function (err) {
        UI.setBusy(b, false);
        UI.showError(P.page.querySelector('.fp-mlist-detail'), err.message);
      });
    }
  }

  FP.view('tool:mailing_lists', function () {
    P.page = null;
    var body = M.frame('mailing_lists', 'fp-mlist');
    if (!body) { return; }
    P.page = body;
    P.account = FP.account();
    P.open = '';
    P.detail = null;
    P.filter = '';
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    Promise.all([FP.call('get', 'mailLists', undefined, P.account), FP.call('get', 'domains', undefined, P.account).then(namesOf, function () { return []; })]).then(function (r) {
      if (P.page !== body) { return; }
      P.data = clean(r[0]);
      P.names = r[1];
      render();
    }, function (err) {
      if (P.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(FP.tools.mailing_lists.label, err.message));
    });
  });
  document.addEventListener('click', onClick);
})();

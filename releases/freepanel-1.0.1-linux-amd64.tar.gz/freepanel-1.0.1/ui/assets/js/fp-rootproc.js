/* freePanel root access and process pages, in the admin panel (docs/api.md, "Root access" and "Processes"): Root access
   (#/tool/root_access, the server admin's alone) lists the keys that can sign in as root and the logins in the sudo group, adds and
   removes them (adding asks for the admin's own password again), and says when what is set up has no effect; Processes
   (#/tool/processes, the admin's and a reseller's own accounts') lists what runs on the server and ends a process that belongs to a
   hosting account. Nothing changes until the admin asks. What the server sends is cleaned to the shapes drawn here and shown as
   text. Page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var FP_RE = /^SHA256:[A-Za-z0-9+/]{43}$/;
  var USER_RE = /^[a-z_][a-z0-9_-]{0,31}$/;
  var LOGINS = ['yes', 'prohibit-password', 'forced-commands-only', 'no'];

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function num(v) { return typeof v === 'number' && isFinite(v) ? v : 0; }
  function arr(v) { return Array.isArray(v) ? v : []; }
  function count(n) { return Math.round(n).toLocaleString('en'); }
  function frame(id, desc, cls, roles) {
    var tool = FP.tools[id];
    if (!tool || FP.realm !== 'admin' || roles.indexOf(FP.session.user.role) < 0) { FP.views['not-found']({view: 'not-found'}); return null; }
    var g = FP.group(tool.group);
    return FP.frame({title: tool.label, desc: t(desc), cls: 'fp-mail fp-rpp ' + cls,
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
  }
  function failedPage(page, id, err) {
    page.textContent = '';
    page.appendChild(FP.empty(FP.tools[id].label, err.message));
  }
  function warn(text, attr) {
    var b = el('div', {class: 'sig-banner sig-banner--warn', role: 'note'}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: text})]);
    if (attr) { b.setAttribute(attr, ''); }
    return b;
  }

  /* ================= Root access ================= */
  var RA = null;
  function cleanLogin(l) {
    return l && typeof l === 'object' && USER_RE.test(str(l.username)) ? {name: l.username, uid: Math.round(num(l.uid)), shell: str(l.shell, 64)} : null;
  }
  function cleanAccess(r) {
    r = r && typeof r === 'object' ? r : {};
    return {keys: arr(r.keys).filter(function (k) { return k && FP_RE.test(str(k.fingerprint)); }).slice(0, 100).map(function (k) {
      return {fp: k.fingerprint, type: str(k.type, 40), bits: Math.round(num(k.bits)), comment: str(k.comment, 120), options: k.options === true};
    }), more: r.keys_more === true, login: LOGINS.indexOf(r.root_login) >= 0 ? r.root_login : '', group: USER_RE.test(str(r.sudo_group)) ? r.sudo_group : '',
    rule: r.sudo_rule === true, users: arr(r.sudo_users).map(cleanLogin).filter(Boolean).slice(0, 100), candidates: arr(r.candidates).map(cleanLogin).filter(Boolean).slice(0, 200)};
  }
  function passwordField(id) {
    return M.field(id, t('rta_password'), el('input', {class: 'sig-input', id: id, name: 'current_password', type: 'password', autocomplete: 'current-password'}), t('rta_password_hint'));
  }
  function keysCard() {
    var d = RA.data;
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t('rta_keys_intro')})];
    if (d.login === 'no') { parts.push(warn(t('rta_login_no'), 'data-fp-login-no')); }
    else if (d.login === '') { parts.push(warn(t('rta_login_unknown'), 'data-fp-login-unknown')); }
    if (!d.keys.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': 'keys', text: t('rta_keys_none')}));
    } else {
      parts.push(el('ul', {class: 'fp-rpp-list'}, d.keys.map(function (k) {
        return el('li', {class: 'fp-rpp-row', 'data-fp-key': k.fp}, [
          el('div', {class: 'fp-rpp-main'}, [el('span', {class: 'fp-rpp-title sig-mono', text: k.fp}),
            el('span', {class: 'fp-muted', text: t('rta_key_line', {type: k.type || '—', bits: k.bits || '—', comment: k.comment || t('rta_no_comment')})}),
            k.options ? el('span', {class: 'sig-badge', text: t('rta_key_options')}) : null]),
          el('span', {class: 'fp-rpp-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'key-remove',
            'aria-label': t('rta_key_remove_of', {fp: k.fp}), text: t('rta_remove')})])]);
      })));
    }
    if (d.more) { parts.push(el('p', {class: 'fp-muted', text: t('rta_keys_more')})); }
    var key = el('textarea', {class: 'sig-input sig-mono', id: 'fp-rta-key', name: 'key', rows: '3', spellcheck: 'false', autocapitalize: 'none', autocomplete: 'off', placeholder: 'ssh-ed25519 AAAA… name'});
    var form = el('form', {class: 'fp-form fp-rpp-form fp-rta-keyform', novalidate: ''}, [M.errorLine(), M.statusLine(), M.field('fp-rta-key', t('rta_key'), key, t('rta_key_hint')),
      passwordField('fp-rta-key-pw'), el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('rta_key_add')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      send(form, 'rootKeys', {key: key.value.trim(), current_password: form.querySelector('input[name="current_password"]').value}, 'rta_key_added', 'fp-rta-keys-h');
    });
    parts.push(el('h3', {class: 'fp-h3', text: t('rta_key_add_title')}), form);
    return M.card('fp-rta-keys-h', t('rta_keys_title'), parts, 'fp-rta-keys');
  }
  function sudoCard() {
    var d = RA.data;
    var parts = [M.errorLine(), M.statusLine()];
    if (!d.group) { parts.push(el('p', {class: 'fp-muted', 'data-fp-none': 'group', text: t('rta_no_group')})); return M.card('fp-rta-sudo-h', t('rta_sudo_title'), parts, 'fp-rta-sudo'); }
    parts.push(el('p', {class: 'fp-muted', text: t('rta_sudo_intro', {group: d.group})}));
    if (!d.rule) { parts.push(warn(t('rta_sudo_norule', {group: d.group}), 'data-fp-norule')); }
    if (!d.users.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': 'sudo', text: t('rta_sudo_none')}));
    } else {
      parts.push(el('ul', {class: 'fp-rpp-list'}, d.users.map(function (u) {
        return el('li', {class: 'fp-rpp-row', 'data-fp-sudo': u.name}, [
          el('div', {class: 'fp-rpp-main'}, [el('span', {class: 'fp-rpp-title', text: u.name}), el('span', {class: 'fp-muted sig-mono', text: t('rta_login_line', {uid: u.uid, shell: u.shell || '—'})})]),
          u.name === 'root' ? null : el('span', {class: 'fp-rpp-acts'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button',
            'data-fp-act': 'sudo-remove', 'aria-label': t('rta_sudo_remove_of', {name: u.name}), text: t('rta_remove')})])]);
      })));
    }
    var open = d.candidates.filter(function (c) { return !d.users.some(function (u) { return u.name === c.name; }); });
    if (!open.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': 'candidates', text: t('rta_sudo_nobody')}));
    } else {
      var pick = el('select', {class: 'sig-select', id: 'fp-rta-user', name: 'username'}, open.map(function (c) { return el('option', {value: c.name, text: c.name}); }));
      var form = el('form', {class: 'fp-form fp-rpp-form fp-rta-sudoform', novalidate: ''}, [M.errorLine(), M.statusLine(), M.field('fp-rta-user', t('rta_sudo_pick'), pick, t('rta_sudo_pick_hint')),
        passwordField('fp-rta-sudo-pw'), el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('rta_sudo_add')})])]);
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        send(form, 'rootSudo', {username: pick.value, current_password: form.querySelector('input[name="current_password"]').value}, 'rta_sudo_added', 'fp-rta-sudo-h');
      });
      parts.push(el('h3', {class: 'fp-h3', text: t('rta_sudo_add_title')}), form);
    }
    return M.card('fp-rta-sudo-h', t('rta_sudo_title'), parts, 'fp-rta-sudo');
  }
  /* root's own password: the new one twice and the admin's own; the answer says only that it changed */
  function rootPasswordCard() {
    var next = el('input', {class: 'sig-input', id: 'fp-rta-rootpw', name: 'password', type: 'password', autocomplete: 'new-password'});
    var again = el('input', {class: 'sig-input', id: 'fp-rta-rootpw2', name: 'password_again', type: 'password', autocomplete: 'new-password'});
    var form = el('form', {class: 'fp-form fp-rpp-form fp-rta-pwform', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('p', {class: 'fp-muted', text: t('rta_rootpw_intro')}),
      M.field('fp-rta-rootpw', t('rta_rootpw_new'), next, t('rta_rootpw_hint')), M.field('fp-rta-rootpw2', t('rta_rootpw_again'), again, ''),
      passwordField('fp-rta-rootpw-cur'), el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('rta_rootpw_set')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var cur = form.querySelector('input[name="current_password"]');
      if (next.value !== again.value) { M.fieldError(form, again, t('rta_rootpw_mismatch')); return; }
      if (!cur.value) { M.fieldError(form, cur, t('rta_need_password')); return; }
      var mine = RA;
      UI.setBusy(b, true);
      FP.call('put', 'rootPassword', {password: next.value, current_password: cur.value}).then(function () {
        UI.setBusy(b, false);
        next.value = again.value = cur.value = '';
        if (RA === mine) { M.say(form.closest('.sig-card'), t('rta_rootpw_done')); }
      }, function (err) {
        UI.setBusy(b, false);
        cur.value = '';
        if (RA === mine) { M.failed(form, err); }
      });
    });
    return M.card('fp-rta-pw-h', t('rta_rootpw_title'), [form], 'fp-rta-pw');
  }
  function raDraw() {
    RA.page.textContent = '';
    RA.page.appendChild(keysCard());
    RA.page.appendChild(sudoCard());
    RA.page.appendChild(rootPasswordCard());
  }
  /* a change that asks for the admin's password: the answer is the whole state again */
  function send(form, path, body, doneKey, focus) {
    var b = M.start(form);
    if (!b) { return; }
    if (!body.current_password) { M.fieldError(form, form.querySelector('input[name="current_password"]'), t('rta_need_password')); return; }
    var mine = RA;
    UI.setBusy(b, true);
    FP.call('post', path, body).then(function (r) {
      if (RA !== mine) { return; }
      mine.data = cleanAccess(r);
      raDraw();
      M.say(mine.page.querySelector('#' + focus).closest('.sig-card'), t(doneKey));
      mine.page.querySelector('#' + focus).focus();
    }, function (err) {
      UI.setBusy(b, false);
      if (RA === mine) { M.failed(form, err); form.querySelector('input[name="current_password"]').value = ''; }
    });
  }
  function raClick(e) {
    var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !RA || !RA.page.contains(b)) { return; }
    var act = b.getAttribute('data-fp-act');
    var row = b.closest('li');
    var cell = b.closest('.fp-rpp-acts');
    var mine = RA;
    if (act === 'key-remove') {
      M.confirmIn(cell, t('rta_key_remove_ask'), 'key-remove-yes', t('rta_remove'));
    } else if (act === 'sudo-remove') {
      M.confirmIn(cell, t('rta_sudo_remove_ask', {name: row.getAttribute('data-fp-sudo')}), 'sudo-remove-yes', t('rta_remove'));
    } else if (act === 'confirm-no') {
      raDraw();
    } else if (act === 'key-remove-yes' || act === 'sudo-remove-yes') {
      var isKey = act === 'key-remove-yes';
      var card = row.closest('.sig-card');
      UI.setBusy(b, true);
      FP.call('del', isKey ? 'rootKeyOf' : 'rootSudoOf', undefined, isKey ? {fingerprint: row.getAttribute('data-fp-key')} : {username: row.getAttribute('data-fp-sudo')}).then(function (r) {
        if (RA !== mine) { return; }
        mine.data = cleanAccess(r);
        raDraw();
        M.say(mine.page.querySelector(isKey ? '.fp-rta-keys' : '.fp-rta-sudo'), t(isKey ? 'rta_key_removed' : 'rta_sudo_removed'));
        mine.page.querySelector(isKey ? '#fp-rta-keys-h' : '#fp-rta-sudo-h').focus();
      }, function (err) {
        UI.setBusy(b, false);
        if (RA === mine) { UI.showError(card, err.message); }
      });
    }
  }
  FP.view('tool:root_access', function () {
    RA = null;
    var page = frame('root_access', 'rta_desc', 'fp-rta-page', ['admin']);
    if (!page) { return; }
    var mine = RA = {page: page, data: null};
    page.addEventListener('click', raClick);
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'rootAccess').then(function (r) {
      if (RA !== mine) { return; }
      mine.data = cleanAccess(r);
      raDraw();
    }, function (err) { if (RA === mine) { failedPage(page, 'root_access', err); } });
  });

  /* ================= Processes ================= */
  var PR = null;
  var STATES = {R: 'prc_s_running', S: 'prc_s_sleeping', D: 'prc_s_waiting', T: 'prc_s_stopped', Z: 'prc_s_zombie', I: 'prc_s_idle'};
  function cleanProc(p) {
    if (!p || typeof p !== 'object' || num(p.pid) < 1) { return null; }
    return {pid: Math.round(p.pid), user: str(p.user, 40), account: USER_RE.test(str(p.account)) ? p.account : '', command: str(p.command, 40), cmdline: str(p.cmdline, 512), state: str(p.state, 1),
      threads: Math.round(num(p.threads)), start: Math.round(num(p.start)), cpu: num(p.cpu_seconds), memory: num(p.memory_bytes), killable: p.killable === true, reason: str(p.reason, 200)};
  }
  function cleanProcs(r) {
    r = r && typeof r === 'object' ? r : {};
    return {list: arr(r.processes).map(cleanProc).filter(Boolean).slice(0, 2000), total: Math.round(num(r.total)), truncated: r.truncated === true};
  }
  function size(b) { return b >= 1073741824 ? (b / 1073741824).toFixed(1) + ' GiB' : Math.round(b / 1048576).toLocaleString('en') + ' MiB'; }
  function procRows() {
    var q = PR.filter.toLowerCase();
    var list = PR.data.list.filter(function (p) {
      return (!PR.mine || p.account) && (!q || (p.command + ' ' + p.cmdline + ' ' + p.user + ' ' + p.account + ' ' + p.pid).toLowerCase().indexOf(q) >= 0);
    });
    return list.sort(function (a, b) { return b.memory - a.memory || a.pid - b.pid; }).slice(0, 200);
  }
  function procRow(p) {
    var acts = p.killable ? el('span', {class: 'fp-rpp-acts'}, [
      el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'end', 'aria-label': t('prc_end_of', {pid: p.pid, name: p.command}), text: t('prc_end')}),
      el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm fp-btn-danger-text', type: 'button', 'data-fp-act': 'force', 'aria-label': t('prc_force_of', {pid: p.pid, name: p.command}), text: t('prc_force')})]) :
      el('span', {class: 'fp-muted fp-row-note', 'data-fp-reason': '', text: p.reason || t('prc_not_ours')});
    return el('tr', {'data-fp-pid': String(p.pid), 'data-fp-start': String(p.start)}, [
      el('th', {scope: 'row', class: 'sig-mono', text: String(p.pid)}),
      el('td', null, [el('span', {class: 'sig-mono', text: p.command}), p.cmdline && p.cmdline !== p.command ? el('span', {class: 'fp-muted fp-row-note fp-rpp-cmd sig-mono', text: p.cmdline}) : null]),
      el('td', {text: p.account || p.user}), el('td', {text: STATES[p.state] ? t(STATES[p.state]) : '—'}), el('td', {class: 'fp-num', text: count(p.cpu)}), el('td', {class: 'fp-num', text: size(p.memory)}),
      el('td', {class: 'fp-rpp-acts'}, [acts])]);
  }
  function prDraw() {
    var rows = procRows();
    var parts = [M.errorLine(), M.statusLine()];
    var q = el('input', {class: 'sig-input', id: 'fp-prc-q', type: 'search', name: 'q', value: PR.filter, autocomplete: 'off', spellcheck: 'false'});
    q.addEventListener('input', function () { PR.filter = q.value; prRows(); });
    var mine = el('input', {type: 'checkbox', id: 'fp-prc-mine', name: 'mine', checked: PR.mine ? true : null});
    mine.addEventListener('change', function () { PR.mine = mine.checked; prRows(); });
    parts.push(el('div', {class: 'fp-rpp-filters'}, [M.field('fp-prc-q', t('prc_filter'), q, t('prc_filter_hint')),
      el('div', {class: 'sig-field'}, [el('label', {class: 'fp-check', for: 'fp-prc-mine'}, [mine, el('span', {text: t('prc_mine')})])])]));
    parts.push(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'refresh', text: t('prc_refresh')})]));
    parts.push(el('p', {class: 'fp-muted', 'data-fp-count': '', text: ''}));
    parts.push(el('div', {class: 'fp-table-wrap fp-prc-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-prc-h'}, [
      el('table', {class: 'sig-table fp-prc-table'}, [el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('prc_col_pid')}), el('th', {scope: 'col', text: t('prc_col_process')}),
        el('th', {scope: 'col', text: t('prc_col_owner')}), el('th', {scope: 'col', text: t('prc_col_state')}), el('th', {scope: 'col', class: 'fp-num', text: t('prc_col_cpu')}),
        el('th', {scope: 'col', class: 'fp-num', text: t('prc_col_memory')}), el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]),
      el('tbody', {'data-fp-rows': ''}, rows.map(procRow))])]));
    if (PR.data.truncated) { parts.push(el('p', {class: 'fp-muted', 'data-fp-truncated': '', text: t('prc_truncated', {shown: count(PR.data.list.length), total: count(PR.data.total)})})); }
    PR.page.textContent = '';
    PR.page.appendChild(M.card('fp-prc-h', t('prc_title'), parts, 'fp-prc'));
    if (PR.killer) { PR.page.appendChild(killerCard()); }
    if (PR.plog) { PR.page.appendChild(plogCard()); }
    if (PR.tasks) { PR.page.appendChild(tasksCard()); }
    if (PR.maint) { PR.page.appendChild(maintCard()); }
    prRows(true);
  }
  /* when the panel's own maintenance jobs run (the server admin's alone) */
  function maintCard() {
    var hour = el('select', {class: 'sig-select', id: 'fp-mnt-hour', name: 'log_rotation_hour'}, Array.apply(null, Array(24)).map(function (_, h) {
      var o = el('option', {value: String(h), text: (h < 10 ? '0' : '') + h + ':00'});
      if (h === PR.maint.hour) { o.selected = true; }
      return o;
    }));
    var mins = el('input', {class: 'sig-input', id: 'fp-mnt-usage', name: 'disk_usage_minutes', type: 'number', min: '15', max: '1440', value: String(PR.maint.usage)});
    var form = el('form', {class: 'fp-form fp-mnt-form', novalidate: ''}, [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t('mnt_intro')}),
      M.field('fp-mnt-hour', t('mnt_hour'), hour, t('mnt_hour_hint')), M.field('fp-mnt-usage', t('mnt_usage'), mins, t('mnt_usage_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('mnt_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var u = parseInt(mins.value, 10);
      if (!(u >= 15 && u <= 1440)) { M.fieldError(form, mins, t('mnt_usage_hint')); return; }
      var mine = PR;
      UI.setBusy(b, true);
      FP.call('put', 'maintenance', {log_rotation_hour: parseInt(hour.value, 10), disk_usage_minutes: u}).then(function (r) {
        if (PR !== mine) { return; }
        mine.maint = cleanMaint(r);
        prDraw();
        M.say(mine.page.querySelector('.fp-mnt'), t('mnt_saved'));
        mine.page.querySelector('#fp-mnt-h').focus();
      }, function (err) {
        UI.setBusy(b, false);
        if (PR === mine) { M.failed(form, err); }
      });
    });
    return M.card('fp-mnt-h', t('mnt_title'), [form], 'fp-mnt');
  }
  function cleanMaint(r) {
    r = r && typeof r === 'object' ? r : {};
    var h = num(r.log_rotation_hour);
    var u = num(r.disk_usage_minutes);
    return {hour: h >= 0 && h <= 23 ? Math.round(h) : 3, usage: u >= 15 && u <= 1440 ? Math.round(u) : 30};
  }
  /* the panel's background jobs (the server admin's alone): running or idle, last run, how long, last error */
  function cleanTasks(r) {
    r = r && typeof r === 'object' ? r : {};
    return arr(r.tasks).slice(0, 100).map(function (x) {
      x = x && typeof x === 'object' ? x : {};
      return {label: str(x.label, 100) || str(x.id, 60), running: x.running === true, finished: str(x.finished_at, 40), ms: num(x.duration_ms), runs: num(x.runs),
        failures: num(x.failures), error: str(x.last_error, 300), errorAt: str(x.last_error_at, 40)};
    });
  }
  function tasksCard() {
    var parts = [M.errorLine(), el('p', {class: 'fp-muted', text: t('task_intro')})];
    if (!PR.tasks.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': 'tasks', text: t('task_none')}));
    } else {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-task-h'}, [el('table', {class: 'sig-table'}, [
        el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('task_col_job')}), el('th', {scope: 'col', text: t('task_col_state')}),
          el('th', {scope: 'col', text: t('task_col_last')}), el('th', {scope: 'col', class: 'fp-num', text: t('task_col_took')}),
          el('th', {scope: 'col', class: 'fp-num', text: t('task_col_runs')}), el('th', {scope: 'col', text: t('task_col_error')})])]),
        el('tbody', null, PR.tasks.map(function (x) {
          return el('tr', null, [el('th', {scope: 'row', text: x.label}), el('td', {text: t(x.running ? 'task_running' : 'task_idle')}), el('td', {text: x.finished || '—'}),
            el('td', {class: 'fp-num', text: (x.ms / 1000).toFixed(1) + ' s'}), el('td', {class: 'fp-num', text: count(x.runs) + (x.failures ? ' (' + t('task_failed', {n: count(x.failures)}) + ')' : '')}),
            el('td', {text: x.error ? x.error + ' (' + x.errorAt + ')' : '—'})]);
        }))])]));
    }
    return M.card('fp-task-h', t('task_title'), parts, 'fp-task');
  }
  /* the daily process log (the server admin's alone): what each login's processes used over a day */
  var DAY_RE = /^\d{4}-\d{2}-\d{2}$/;
  function cleanPlog(r) {
    r = r && typeof r === 'object' ? r : {};
    return {day: DAY_RE.test(str(r.day, 10)) ? r.day : '', days: arr(r.days).filter(function (d) { return DAY_RE.test(str(d, 10)); }).slice(0, 31), samples: num(r.samples),
      rows: arr(r.rows).slice(0, 500).map(function (x) {
        x = x && typeof x === 'object' ? x : {};
        return {user: str(x.user, 64), account: x.account === true, cpu: num(x.cpu_seconds), pct: num(x.cpu_percent), avg: num(x.avg_processes), max: num(x.max_processes), mem: num(x.avg_memory_bytes)};
      })};
  }
  function plogCard() {
    var L = PR.plog;
    var pick = el('select', {class: 'sig-select', id: 'fp-plog-day', name: 'day'}, (L.days.length ? L.days : [L.day]).map(function (d) {
      var o = el('option', {value: d, text: d});
      if (d === L.day) { o.selected = true; }
      return o;
    }));
    pick.addEventListener('change', function () { plogLoad(pick.value); });
    var parts = [M.errorLine(), el('p', {class: 'fp-muted', text: t('plog_intro')}), M.field('fp-plog-day', t('plog_day'), pick, t('plog_samples', {n: count(L.samples)}))];
    if (!L.rows.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': 'plog', text: t('plog_none')}));
    } else {
      parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-plog-h'}, [el('table', {class: 'sig-table'}, [
        el('thead', null, [el('tr', null, [el('th', {scope: 'col', text: t('plog_col_user')}), el('th', {scope: 'col', class: 'fp-num', text: t('plog_col_cpu')}),
          el('th', {scope: 'col', class: 'fp-num', text: t('plog_col_pct')}), el('th', {scope: 'col', class: 'fp-num', text: t('plog_col_avg')}),
          el('th', {scope: 'col', class: 'fp-num', text: t('plog_col_max')}), el('th', {scope: 'col', class: 'fp-num', text: t('plog_col_mem')})])]),
        el('tbody', null, L.rows.map(function (x) {
          return el('tr', null, [el('th', {scope: 'row', text: x.user + (x.account ? '' : ' ' + t('plog_system'))}), el('td', {class: 'fp-num', text: x.cpu.toFixed(1)}),
            el('td', {class: 'fp-num', text: x.pct.toFixed(2) + '%'}), el('td', {class: 'fp-num', text: x.avg.toFixed(1)}), el('td', {class: 'fp-num', text: count(x.max)}),
            el('td', {class: 'fp-num', text: size(x.mem)})]);
        }))])]));
    }
    return M.card('fp-plog-h', t('plog_title'), parts, 'fp-plog');
  }
  function plogLoad(day) {
    var mine = PR;
    /* no day asks for the latest one: an empty {day} would fail the call before it is sent */
    FP.call('get', day ? 'processLog' : 'processLogLatest', undefined, day ? {day: day} : undefined).then(function (x) {
      if (PR !== mine) { return; }
      var first = !mine.plog;
      mine.plog = cleanPlog(x);
      var old = mine.page.querySelector('.fp-plog');
      var card = plogCard();
      if (old) { old.replaceWith(card); } else { mine.page.appendChild(card); }
      if (!first) { card.querySelector('#fp-plog-day').focus(); }
    }, function (err) { var c = mine.page.querySelector('.fp-plog'); if (PR === mine && c) { UI.showError(c, err.message); } });
  }
  /* the background process killer (the server admin's alone): programs a hosting account runs that are ended at each pass */
  var PROG_RE = /^[A-Za-z0-9][A-Za-z0-9._+-]{0,14}$/;
  function cleanKiller(r) {
    r = r && typeof r === 'object' ? r : {};
    return {enabled: r.enabled === true, last: str(r.last_run, 40),
      programs: arr(r.programs).filter(function (p) { return p && PROG_RE.test(str(p.name, 20)); }).slice(0, 150).map(function (p) { return {name: p.name, on: p.on === true}; }),
      ended: arr(r.ended).slice(0, 20).map(function (x) { return {at: str(x && x.at, 40), account: str(x && x.account, 40), program: str(x && x.program, 20), pid: num(x && x.pid)}; })};
  }
  function killerCard() {
    var K = PR.killer;
    var on = el('input', {type: 'checkbox', id: 'fp-pk-on', name: 'enabled'});
    on.checked = K.enabled;
    var boxes = K.programs.map(function (p, i) {
      var b = el('input', {type: 'checkbox', id: 'fp-pk-p' + i, name: 'program', value: p.name});
      b.checked = p.on;
      return el('label', {class: 'fp-check', for: 'fp-pk-p' + i}, [b, el('span', {class: 'sig-mono', text: p.name})]);
    });
    var more = el('input', {class: 'sig-input', id: 'fp-pk-more', name: 'more', type: 'text', autocomplete: 'off', spellcheck: 'false'});
    var form = el('form', {class: 'fp-form fp-pk-form', novalidate: ''}, [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t('pk_intro')}),
      el('label', {class: 'fp-check', for: 'fp-pk-on'}, [on, el('span', {text: t('pk_on')})]),
      el('fieldset', {class: 'fp-fieldset'}, [el('legend', {text: t('pk_programs')})].concat(boxes)),
      M.field('fp-pk-more', t('pk_more'), more, t('pk_more_hint')),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('pk_save')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'pk-run', text: t('pk_run')})])]);
    var parts = [form];
    if (K.ended.length) {
      parts.push(el('h3', {class: 'fp-h3', text: t('pk_ended_title')}), el('ul', {class: 'fp-rpp-list'}, K.ended.map(function (x) {
        return el('li', {class: 'fp-rpp-row', text: t('pk_ended_line', {program: x.program, account: x.account, pid: String(x.pid), at: x.at})});
      })));
    }
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var progs = [].slice.call(form.querySelectorAll('input[name="program"]:checked')).map(function (x) { return x.value; });
      var extra = more.value.split(/[\s,]+/).filter(Boolean);
      for (var i = 0; i < extra.length; i++) {
        if (!PROG_RE.test(extra[i])) { M.fieldError(form, more, t('pk_more_hint')); return; }
        if (progs.indexOf(extra[i]) < 0) { progs.push(extra[i]); }
      }
      killerSend(b, 'put', 'processKiller', {enabled: on.checked, programs: progs}, t('pk_saved'), form);
    });
    return M.card('fp-pk-h', t('pk_title'), parts, 'fp-pk');
  }
  function killerSend(b, method, path, body, note, form) {
    var mine = PR;
    UI.setBusy(b, true);
    FP.call(method, path, body).then(function (r) {
      if (PR !== mine) { return; }
      mine.killer = cleanKiller(r);
      prDraw();
      M.say(mine.page.querySelector('.fp-pk'), note);
      mine.page.querySelector('#fp-pk-h').focus();
    }, function (err) {
      UI.setBusy(b, false);
      if (PR === mine) { M.failed(form, err); }
    });
  }
  /* only the rows and their count change while someone types */
  function prRows(keep) {
    var body = PR.page.querySelector('[data-fp-rows]');
    var rows = procRows();
    if (!keep) { body.textContent = ''; rows.forEach(function (p) { body.appendChild(procRow(p)); }); }
    PR.page.querySelector('[data-fp-count]').textContent = rows.length ? t('prc_showing', {shown: count(rows.length)}) : t('prc_none');
  }
  /* the list again; the card is drawn anew, so what is to be said (note) or told (a refusal that made the list be read again) is said in the new card */
  function prLoad(note, told) {
    var mine = PR;
    return FP.call('get', 'processes').then(function (r) {
      if (PR !== mine) { return; }
      mine.data = cleanProcs(r);
      prDraw();
      if (note) { M.say(mine.page.querySelector('.fp-prc'), note); }
      if (told) { UI.showError(mine.page.querySelector('.fp-prc'), told); }
    }, function (err) { if (PR === mine) { UI.showError(mine.page.querySelector('.fp-prc') || mine.page, err.message); } });
  }
  function prClick(e) {
    var b = e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !PR || !PR.page.contains(b)) { return; }
    var act = b.getAttribute('data-fp-act');
    var mine = PR;
    var card = PR.page.querySelector('.fp-prc');
    if (act === 'pk-run') {
      killerSend(b, 'post', 'processKillerRun', undefined, t('pk_ran'), b.closest('form'));
    } else if (act === 'refresh') {
      UI.setBusy(b, true);
      prLoad(t('prc_updated'));
    } else if (act === 'end' || act === 'force') {
      var tr = b.closest('tr');
      var cell = b.closest('.fp-rpp-acts');
      M.confirmIn(cell, t(act === 'end' ? 'prc_end_ask' : 'prc_force_ask', {pid: tr.getAttribute('data-fp-pid')}), act + '-yes', t(act === 'end' ? 'prc_end' : 'prc_force'));
    } else if (act === 'confirm-no') {
      prRows();
    } else if (act === 'end-yes' || act === 'force-yes') {
      var row = b.closest('tr');
      UI.setBusy(b, true);
      FP.call('post', 'processKill', {start: parseInt(row.getAttribute('data-fp-start'), 10), signal: act === 'end-yes' ? 'term' : 'kill'}, {pid: row.getAttribute('data-fp-pid')}).then(function (r) {
        var ended = r && r.ended === true;
        return prLoad(t(ended ? 'prc_ended' : 'prc_signalled', {pid: row.getAttribute('data-fp-pid')}));
      }, function (err) {
        UI.setBusy(b, false);
        if (PR !== mine) { return; }
        if (err.status === 404 || err.status === 409) { prLoad('', err.message); } else { UI.showError(card, err.message); }
      });
    }
  }
  FP.view('tool:processes', function () {
    PR = null;
    var page = frame('processes', 'prc_desc', 'fp-prc-page', ['admin', 'reseller']);
    if (!page) { return; }
    var mine = PR = {page: page, data: null, filter: '', mine: false};
    page.addEventListener('click', prClick);
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'processes').then(function (r) {
      if (PR !== mine) { return; }
      mine.data = cleanProcs(r);
      prDraw();
      if (FP.session.user.role === 'admin' && FP.realm === 'admin') {
        FP.call('get', 'processKiller').then(function (x) {
          if (PR !== mine) { return; }
          mine.killer = cleanKiller(x);
          mine.page.appendChild(killerCard());
          plogLoad('');
          FP.call('get', 'serverTasks').then(function (y) {
            if (PR !== mine) { return; }
            mine.tasks = cleanTasks(y);
            mine.page.appendChild(tasksCard());
            return FP.call('get', 'maintenance').then(function (z) {
              if (PR !== mine) { return; }
              mine.maint = cleanMaint(z);
              mine.page.appendChild(maintCard());
            });
          }, function () {});
        }, function () {});
      }
    }, function (err) { if (PR === mine) { failedPage(page, 'processes', err); } });
  });
})();

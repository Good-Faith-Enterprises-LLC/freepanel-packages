/* freePanel nginx front, in the admin panel (docs/api.md, "Web server", GET and PUT /web/nginx): the nginx front page (#/tool/nginx_front).
   With the switch on, nginx takes ports 80 and 443 and ends the visitors' TLS with the certificates the panel already keeps, and Apache moves to two
   loopback ports and reads each visitor's address from nginx. Turning it on or off restarts Apache, so the page asks first and says what happens. The
   server tests every file before it reloads anything; if a test fails it puts the files back, and if nginx starts but cannot reach Apache it turns the
   front off again and says so. The page shows what the server says and nothing it works out for itself. A site's mode, full or passthrough, is the
   admin's alone and is kept while the front is off. Everything the server sends is shown as text. The page pieces come from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var DOMAIN_RE = /^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z][a-z0-9-]{0,61}[a-z0-9]$/;
  var ACCOUNT_RE = /^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/;
  var ADDR_RE = /^[0-9A-Fa-f:.]{2,45}$/;
  var VERSION_RE = /^[0-9][0-9A-Za-z.+-]{0,23}$/;
  var MODES = ['full', 'passthrough'];
  /* more sites than this and the list gets a box to find one by name */
  var FILTER_FROM = 12;

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 400) : ''; }
  function port(v) { return typeof v === 'number' && v >= 1 && v <= 65535 && Math.floor(v) === v ? v : 0; }
  function isAdmin() { return FP.session.user.role === 'admin'; }

  /* what GET and PUT /web/nginx say, in the shapes the page draws */
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var seen = {};
    var sites = [];
    (Array.isArray(r.sites) ? r.sites : []).forEach(function (s) {
      if (!s || typeof s !== 'object' || !DOMAIN_RE.test(str(s.domain)) || MODES.indexOf(s.mode) < 0 || seen[s.domain]) { return; }
      seen[s.domain] = true;
      sites.push({domain: s.domain, account: ACCOUNT_RE.test(str(s.account, 80)) ? s.account : '', mode: s.mode, secured: s.secured === true,
        ip: ADDR_RE.test(str(s.ip, 60)) ? s.ip : '', cached: s.cached === true});
    });
    sites.sort(function (a, b) { return a.domain < b.domain ? -1 : 1; });
    return {available: r.available === true, installed: r.installed === true, reason: str(r.reason), on: r.on === true, running: r.running === true,
      guard: r.guard === true, version: VERSION_RE.test(str(r.version, 40)) ? r.version : '', httpPort: port(r.http_port), httpsPort: port(r.https_port),
      sites: sites};
  }

  var N = {page: null, data: null, busy: false};
  function pill(kind, text) { return el('span', {class: 'sig-pill' + (kind ? ' sig-pill--' + kind : ''), text: text}); }
  function banner(kind, text, attr) {
    var b = el('div', {class: 'sig-banner sig-banner--' + kind, role: 'note'}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: text})]);
    if (attr) { b.setAttribute(attr, ''); }
    return b;
  }
  function canTurnOn() { return N.data.available && N.data.installed; }

  /* ---- the switch ---- */
  function row(label, value, attr) {
    var dd = el('dd', {}, [value]);
    if (attr) { dd.setAttribute(attr, ''); }
    return [el('dt', {text: label}), dd];
  }
  function facts() {
    var d = N.data;
    var items = [];
    items = items.concat(row(t('ngx_f_state'), pill(d.on ? 'ok' : '', t(d.on ? 'ngx_on' : 'ngx_off')), 'data-fp-state'));
    items = items.concat(row(t('ngx_f_nginx'), el('span', {}, [pill(d.running ? 'ok' : '', t(d.running ? 'ngx_running' : 'ngx_stopped')),
      d.version ? el('span', {class: 'fp-muted fp-row-note', text: ' ' + t('ngx_version', {version: d.version})}) : null]), 'data-fp-running'));
    if (d.on || d.guard) {
      items = items.concat(row(t('ngx_f_guard'), pill(d.guard ? 'ok' : 'warn', t(d.guard ? 'ngx_guard_on' : 'ngx_guard_off')), 'data-fp-guard'));
    }
    if (d.on && d.httpPort && d.httpsPort) {
      items = items.concat(row(t('ngx_f_apache'), el('span', {class: 'sig-mono', text: t('ngx_apache_at', {http: d.httpPort, https: d.httpsPort})}), 'data-fp-ports'));
    }
    items = items.concat(row(t('ngx_f_ids'), el('span', {text: t('ngx_ids')}), 'data-fp-ids'));
    return el('dl', {class: 'fp-ngx-facts'}, items);
  }
  function actions() {
    var cell = el('div', {class: 'fp-ngx-acts', 'data-fp-acts': ''});
    drawActions(cell);
    return cell;
  }
  function drawActions(cell) {
    var d = N.data;
    cell.textContent = '';
    if (d.on) {
      cell.appendChild(el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'ngx-off', text: t('ngx_turn_off')}));
    } else {
      var on = el('button', {class: 'sig-btn sig-btn--primary', type: 'button', 'data-fp-act': 'ngx-on', text: t('ngx_turn_on')});
      if (!canTurnOn()) {
        on.disabled = true;
        on.setAttribute('aria-describedby', 'fp-ngx-why');
      }
      cell.appendChild(on);
    }
  }
  function switchCard() {
    var d = N.data;
    var body = [el('p', {class: 'fp-muted', text: t('ngx_intro')})];
    if (!d.available) {
      body.push(banner('warn', d.reason || t('ngx_unavailable'), 'data-fp-unavailable'));
    } else if (!d.installed && !d.on) {
      body.push(banner('warn', d.reason || t('ngx_not_installed'), 'data-fp-not-installed'));
    } else if (d.on && !d.installed) {
      body.push(banner('warn', t('ngx_gone'), 'data-fp-gone'));
    } else if (d.on && !d.running) {
      body.push(banner('warn', t('ngx_not_running'), 'data-fp-not-running'));
    }
    if (!canTurnOn() && !d.on) { body.push(el('span', {class: 'fp-ngx-why', id: 'fp-ngx-why', text: t('ngx_cannot')})); }
    body.push(facts(), M.errorLine(), M.statusLine(), actions());
    return M.card('fp-ngx-h', t('ngx_title'), body, 'fp-ngx-switch');
  }

  /* ---- the sites ---- */
  function modeSelect(s, i) {
    var sel = el('select', {class: 'sig-select', id: 'fp-ngx-mode-' + i, name: s.domain, 'aria-label': t('ngx_mode_of', {domain: s.domain}), 'data-fp-was': s.mode},
      MODES.map(function (m) { return el('option', {value: m, text: t('ngx_mode_' + m)}); }));
    sel.value = s.mode;
    return sel;
  }
  function siteItem(s, i) {
    var sub = [t('ngx_account', {account: s.account || '?'})];
    if (s.ip) { sub.push(t('ngx_ip', {ip: s.ip})); }
    return el('li', {class: 'fp-ngx-item', 'data-fp-domain': s.domain}, [
      el('div', {class: 'fp-ngx-who'}, [
        el('span', {class: 'fp-ngx-head'}, [el('span', {class: 'sig-mono fp-ngx-name', text: s.domain}),
          pill(s.secured ? 'ok' : '', t(s.secured ? 'ngx_secured' : 'ngx_plain'))]),
        el('span', {class: 'fp-muted fp-row-note', text: sub.join(' · ')})]),
      el('div', {class: 'fp-ngx-pick'}, [modeSelect(s, i)])]);
  }
  function sitesCard() {
    var d = N.data;
    var body = [];
    if (!d.sites.length) {
      body.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('ngx_no_sites')}));
      return M.card('fp-ngx-sites-h', t('ngx_sites_title'), body, 'fp-ngx-sites');
    }
    body.push(el('p', {class: 'fp-muted', text: t(d.on ? 'ngx_sites_intro_on' : 'ngx_sites_intro_off')}));
    var form = el('form', {class: 'fp-form fp-ngx-form', novalidate: ''}, [M.errorLine(), M.statusLine()]);
    if (d.sites.length > FILTER_FROM) {
      form.appendChild(M.field('fp-ngx-find', t('ngx_find'), el('input', {class: 'sig-input', id: 'fp-ngx-find', type: 'search', autocomplete: 'off', spellcheck: 'false',
        autocapitalize: 'none', maxlength: '253'}), t('ngx_find_hint')));
    }
    form.appendChild(el('ul', {class: 'fp-ngx-list', 'aria-labelledby': 'fp-ngx-sites-h'}, d.sites.map(siteItem)));
    form.appendChild(el('p', {class: 'fp-muted', 'data-fp-nomatch': '', hidden: '', text: t('ngx_nomatch')}));
    form.appendChild(el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('ngx_save_modes')})]));
    form.addEventListener('input', function (e) { if (e.target && e.target.id === 'fp-ngx-find') { find(form, e.target.value); } });
    form.addEventListener('submit', function (e) { e.preventDefault(); saveModes(form); });
    body.push(form);
    return M.card('fp-ngx-sites-h', t('ngx_sites_title'), body, 'fp-ngx-sites');
  }
  /* shows the sites whose name holds what was typed */
  function find(form, text) {
    var q = text.trim().toLowerCase();
    var shown = 0;
    Array.prototype.forEach.call(form.querySelectorAll('li.fp-ngx-item'), function (li) {
      var hit = !q || li.getAttribute('data-fp-domain').indexOf(q) >= 0;
      li.hidden = !hit;
      if (hit) { shown++; }
    });
    form.querySelector('[data-fp-nomatch]').hidden = shown > 0;
  }
  /* ---- caching, per account ---- */
  function cacheAccounts() {
    var by = {};
    N.data.sites.forEach(function (s) {
      if (!s.account) { return; }
      var a = by[s.account] || (by[s.account] = {name: s.account, cached: false, sites: 0});
      a.sites++;
      if (s.cached) { a.cached = true; }
    });
    return Object.keys(by).sort().map(function (k) { return by[k]; });
  }
  function cacheCard() {
    var list = cacheAccounts();
    var body = [el('p', {class: 'fp-muted', text: t(N.data.on ? 'ngx_cache_intro_on' : 'ngx_cache_intro_off')})];
    if (!list.length) {
      body.push(el('p', {class: 'fp-muted', text: t('ngx_no_sites')}));
      return M.card('fp-ngx-cache-h', t('ngx_cache_title'), body, 'fp-ngx-cache');
    }
    var boxes = list.map(function (a, i) {
      var id = 'fp-ngx-cache-' + i;
      var box = el('input', {type: 'checkbox', id: id, name: 'cache', value: a.name, 'data-fp-was': a.cached ? '1' : ''});
      box.checked = a.cached;
      return el('div', {class: 'sig-field fp-ngx-cacheitem', 'data-fp-account': a.name}, [el('label', {class: 'fp-check', for: id}, [box,
        el('span', {text: t('ngx_cache_of', {account: a.name, n: a.sites})})])]);
    });
    var form = el('form', {class: 'fp-form fp-ngx-cform', novalidate: ''}, [M.errorLine(), M.statusLine(),
      el('fieldset', {class: 'fp-fieldset'}, [el('legend', {text: t('ngx_cache_legend')})].concat(boxes)),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('ngx_cache_save')})])]);
    form.addEventListener('submit', function (e) { e.preventDefault(); saveCache(form); });
    body.push(form);
    return M.card('fp-ngx-cache-h', t('ngx_cache_title'), body, 'fp-ngx-cache');
  }
  function saveCache(form) {
    var b = M.start(form);
    if (!b || N.busy) { return; }
    var out = {};
    var n = 0;
    Array.prototype.forEach.call(form.querySelectorAll('input[name="cache"]'), function (x) {
      if (x.checked !== Boolean(x.getAttribute('data-fp-was'))) { out[x.value] = x.checked; n++; }
    });
    if (!n) { M.say(form, t('ngx_cache_nothing')); return; }
    var mine = N.page;
    N.busy = true;
    UI.setBusy(b, true);
    FP.call('put', 'webNginx', {cache: out}).then(function (r) {
      N.busy = false;
      if (N.page !== mine) { return; }
      done(r, '.fp-ngx-cache', t(N.data.on ? 'ngx_cache_saved_on' : 'ngx_cache_saved_off'), '#fp-ngx-cache-h');
    }, function (err) {
      N.busy = false;
      UI.setBusy(b, false);
      if (N.page !== mine) { return; }
      M.failed(form, err);
    });
  }
  function helpCard() {
    return M.card('fp-ngx-help-h', t('ngx_help_title'), [el('dl', {class: 'fp-ngx-help'}, MODES.reduce(function (out, m) {
      return out.concat([el('dt', {text: t('ngx_mode_' + m)}), el('dd', {text: t('ngx_help_' + m)})]);
    }, [])), el('p', {class: 'fp-muted', text: t('ngx_help_tls')})], 'fp-ngx-help-card');
  }

  function render() {
    N.page.textContent = '';
    N.page.appendChild(switchCard());
    N.page.appendChild(sitesCard());
    N.page.appendChild(cacheCard());
    N.page.appendChild(helpCard());
  }

  /* ---- doing things ---- */
  /* the answer of a call: draw it, and say what was done in the card that changed */
  function done(reply, card, text, focus) {
    N.data = clean(reply);
    render();
    var c = N.page.querySelector(card);
    M.say(c, text);
    N.page.querySelector(focus).focus();
  }
  /* a failed call: the page asks the server what is true now, since a change that was tried may have been undone or may not, and shows the error in
     the card it was about */
  function failedCall(err, card) {
    var mine = N.page;
    var message = err && err.message ? err.message : t('api_failed');
    var show = function () {
      var c = N.page.querySelector(card);
      if (!c) { return; }
      UI.showError(c, message);
      var line = c.querySelector('[data-fp-error]');
      if (line && line.scrollIntoView) { line.scrollIntoView({block: 'nearest'}); }
    };
    FP.call('get', 'webNginx').then(function (r) {
      if (N.page !== mine) { return; }
      N.data = clean(r);
      render();
      show();
    }, function () { if (N.page === mine) { show(); } });
  }
  function setSwitch(on, button) {
    if (N.busy) { return; }
    var mine = N.page;
    N.busy = true;
    UI.setBusy(button, true);
    N.page.setAttribute('aria-busy', 'true');
    FP.call('put', 'webNginx', {on: on}).then(function (r) {
      N.busy = false;
      if (N.page !== mine) { return; }
      mine.removeAttribute('aria-busy');
      done(r, '.fp-ngx-switch', t(on ? 'ngx_now_on' : 'ngx_now_off'), '#fp-ngx-h');
    }, function (err) {
      N.busy = false;
      if (N.page !== mine) { return; }
      mine.removeAttribute('aria-busy');
      failedCall(err, '.fp-ngx-switch');
    });
  }
  /* the sites whose mode was changed since they were drawn, as the server takes them */
  function changedModes(form) {
    var out = {};
    var n = 0;
    N.data.sites.forEach(function (s) {
      var f = UI.fieldNamed(form, s.domain);
      if (f && MODES.indexOf(f.value) >= 0 && f.value !== f.getAttribute('data-fp-was')) {
        out[s.domain] = f.value;
        n++;
      }
    });
    return n ? out : null;
  }
  function saveModes(form) {
    var b = M.start(form);
    if (!b || N.busy) { return; }
    var body = changedModes(form);
    if (!body) {
      M.say(form, t('ngx_nothing'));
      return;
    }
    var mine = N.page;
    N.busy = true;
    UI.setBusy(b, true);
    FP.call('put', 'webNginx', {sites: body}).then(function (r) {
      N.busy = false;
      if (N.page !== mine) { return; }
      done(r, '.fp-ngx-sites', t(N.data.on ? 'ngx_modes_saved_on' : 'ngx_modes_saved_off'), '#fp-ngx-sites-h');
    }, function (err) {
      N.busy = false;
      UI.setBusy(b, false);
      if (N.page !== mine) { return; }
      var f = err && typeof err.field === 'string' ? UI.fieldNamed(form, err.field.replace(/^sites\./, '')) : null;
      if (f) { M.fieldError(form, f, err.message); } else { M.failed(form, err); }
    });
  }

  document.addEventListener('click', function (e) {
    if (!N.page) { return; }
    var a = e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!a || !N.page.contains(a)) { return; }
    var act = a.getAttribute('data-fp-act');
    var cell = a.closest('[data-fp-acts]');
    if (act === 'ngx-on' || act === 'ngx-off') {
      M.confirmIn(cell, t(act === 'ngx-on' ? 'ngx_ask_on' : 'ngx_ask_off'), act + '-yes', t(act === 'ngx-on' ? 'ngx_turn_on' : 'ngx_turn_off'));
    } else if (act === 'confirm-no' && cell) {
      drawActions(cell);
      cell.querySelector('button').focus();
    } else if (act === 'ngx-on-yes' || act === 'ngx-off-yes') {
      var on = act === 'ngx-on-yes';
      var card = N.page.querySelector('.fp-ngx-switch');
      UI.showError(card, '');
      M.say(card, '');
      setSwitch(on, a);
    }
  });

  FP.view('tool:nginx_front', function () {
    N = {page: null, data: null, busy: false};
    var tool = FP.tools.nginx_front;
    if (!tool || FP.realm !== 'admin' || !isAdmin()) { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('ngx_desc'), cls: 'fp-mail fp-ngx-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    if (!body) { return; }
    N.page = body;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'webNginx').then(function (r) {
      if (N.page !== body) { return; }
      N.data = clean(r);
      render();
    }, function (err) {
      if (N.page !== body) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

/* freePanel team members (#/tool/sub_users), the customer panel's page for the logins an account's owner makes for other people
   (docs/api.md, "Team members"): the list with change, turn off or on and remove, and a form to make one with the areas of the account
   it may use. A member signs in as name@account with the password the owner sets; making or turning on a member needs two-factor on
   the owner's own login, which the page says before the server has to. Names, addresses and the catalog's words come from the server
   and are cleaned to the shapes drawn here and shown as text. Page pieces come from FP.mail (fp-mail.js), whose Generate button also
   fills the password fields here. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var API = window.FPAPI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var NAME_RE = /^[a-z][a-z0-9]{0,15}$/;
  var ID_RE = /^[a-z][a-z0-9_]{0,23}$/;
  var EMAIL_RE = /^[^\s@,;"<>]+@[^\s@,;"<>]+\.[^\s@,;"<>]+$/;
  var MAX_MEMBERS = 50;
  var MAX_PASSWORD = 1024;

  var S = null;

  function obj(v) { return v && typeof v === 'object' ? v : {}; }
  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 300) : ''; }
  function date(iso) {
    var d = iso ? new Date(iso) : null;
    return d && !isNaN(d.getTime()) ? d.toLocaleDateString(undefined, {dateStyle: 'medium'}) : '';
  }
  function pill(text, kind) { return el('span', {class: 'sig-pill' + (kind ? ' sig-pill--' + kind : ''), text: text}); }
  function loginOf(name) { return name + '@' + S.account; }

  /* ---- what the server sends, cleaned ---- */
  function cleanCatalog(a) {
    return (Array.isArray(a) ? a : []).filter(function (g) { return g && ID_RE.test(str(g.id, 30)); }).slice(0, 30).map(function (g) {
      return {id: g.id, label: str(g.label, 60) || g.id, desc: str(g.description, 300), code: g.runs_code === true};
    });
  }
  function cleanMember(m) {
    m = obj(m);
    if (!NAME_RE.test(str(m.name, 20))) { return null; }
    var seen = {};
    var grants = (Array.isArray(m.grants) ? m.grants : []).filter(function (g) {
      if (typeof g !== 'string' || !ID_RE.test(g) || seen[g]) { return false; }
      seen[g] = true;
      return true;
    }).slice(0, 30);
    return {name: m.name, email: str(m.email, 254), grants: grants, disabled: m.disabled === true, tf: m.two_factor === true, created: str(m.created_at, 40)};
  }
  function clean(r) {
    r = obj(r);
    var members = (Array.isArray(r.members) ? r.members : []).map(cleanMember).filter(Boolean).slice(0, MAX_MEMBERS);
    members.sort(function (a, b) { return a.name < b.name ? -1 : a.name > b.name ? 1 : 0; });
    var limit = typeof r.limit === 'number' && isFinite(r.limit) && r.limit >= 1 ? Math.min(Math.floor(r.limit), 100) : 10;
    return {members: members, limit: limit, catalog: cleanCatalog(r.catalog)};
  }
  function byName(n) {
    for (var i = 0; i < S.data.members.length; i++) { if (S.data.members[i].name === n) { return S.data.members[i]; } }
    return null;
  }
  function grantLabel(id) {
    for (var i = 0; i < S.data.catalog.length; i++) { if (S.data.catalog[i].id === id) { return S.data.catalog[i].label; } }
    return id;
  }
  function replaceMember(m) {
    for (var i = 0; i < S.data.members.length; i++) { if (S.data.members[i].name === m.name) { S.data.members[i] = m; return; } }
    S.data.members.push(m);
    S.data.members.sort(function (a, b) { return a.name < b.name ? -1 : a.name > b.name ? 1 : 0; });
  }

  /* ---- the list ---- */
  function grantsCell(m) {
    if (!m.grants.length) { return el('span', {class: 'fp-muted', 'data-fp-team-grants': '', text: t('team_no_access')}); }
    return el('ul', {class: 'fp-team-grants', 'data-fp-team-grants': ''}, m.grants.map(function (g) { return el('li', null, [pill(grantLabel(g), '')]); }));
  }
  function actsFor(m) {
    var login = loginOf(m.name);
    function btn(act, label, aria, cls, off) {
      return el('button', {class: 'sig-btn sig-btn--' + (cls || 'secondary') + ' sig-btn--sm', type: 'button', 'data-fp-act': act, 'aria-label': aria, text: label, disabled: off});
    }
    return [btn('edit', t('team_change'), t('team_change_of', {login: login})),
      m.disabled ? btn('on', t('team_turn_on'), t('team_turn_on_of', {login: login}), 'secondary', S.tf === false) : btn('off', t('team_turn_off'), t('team_turn_off_of', {login: login})),
      btn('remove', t('team_remove'), t('team_remove_of', {login: login}), 'danger')];
  }
  function rowFor(m) {
    var when = date(m.created);
    return el('li', {class: 'fp-team-member', 'data-fp-member': m.name}, [
      el('div', {class: 'fp-team-who'}, [el('span', {class: 'sig-mono fp-team-login', text: loginOf(m.name)}),
        el('span', {class: 'fp-team-state'}, [pill(t(m.disabled ? 'team_off' : 'team_on'), m.disabled ? 'warn' : 'ok'),
          el('span', {class: 'fp-muted fp-row-note', text: t(m.tf ? 'team_own_tf_on' : 'team_own_tf_off')})]),
        m.email ? el('span', {class: 'fp-muted fp-row-note', 'data-fp-team-email': '', text: m.email}) : null,
        when ? el('span', {class: 'fp-muted fp-row-note', text: t('team_added', {when: when})}) : null]),
      el('div', {class: 'fp-team-access'}, [el('span', {class: 'fp-team-h', text: t('team_col_access')}), grantsCell(m)]),
      el('div', {class: 'fp-actions fp-team-acts'}, actsFor(m))]);
  }
  function listCard() {
    var D = S.data;
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted fp-team-count', 'data-fp-team-count': '', text: t('team_count', {n: String(D.members.length), limit: String(D.limit)})})];
    if (!D.members.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('team_none')}));
    } else {
      parts.push(el('ul', {class: 'fp-team-members', 'aria-labelledby': 'fp-team-list-h'}, D.members.map(rowFor)));
    }
    parts.push(el('p', {class: 'fp-muted', 'data-fp-team-remove-note': '', text: t('team_remove_note')}));
    return M.card('fp-team-list-h', t('team_list_title'), parts, 'fp-team-list');
  }

  /* ---- two-factor first ---- */
  function twoFactorCard() {
    if (S.tf !== false) { return null; }
    return M.card('fp-team-tf-h', t('team_tf_title'), [M.errorLine(),
      el('div', {class: 'sig-banner sig-banner--warn', role: 'note', 'data-fp-team-tf': ''}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: t('team_tf_needed')})]),
      el('p', {class: 'fp-muted', text: t('team_tf_why')}),
      el('div', {class: 'fp-actions'}, [el('a', {class: 'sig-btn sig-btn--primary', href: '#/two-factor', text: t('team_tf_link')})])], 'fp-team-tf');
  }

  /* ---- the forms ---- */
  function grantsField(prefix, chosen) {
    var boxes = S.data.catalog.map(function (g) {
      var id = prefix + '-' + g.id;
      var box = el('input', {type: 'checkbox', id: id, name: 'grant', value: g.id, 'aria-describedby': id + '-d'});
      if (chosen.indexOf(g.id) >= 0) { box.checked = true; }
      return el('div', {class: 'fp-team-grant', 'data-fp-grant': g.id}, [el('label', {class: 'fp-check', for: id}, [box, el('span', {text: g.label})]),
        el('span', {class: 'sig-hint fp-team-grant-d', id: id + '-d'}, [el('span', {text: g.desc}), g.code ? pill(t('team_runs_code'), 'warn') : null])]);
    });
    return el('fieldset', {class: 'fp-team-set'}, [el('legend', {class: 'sig-label', text: t('team_access')}), el('p', {class: 'sig-hint', text: t('team_access_hint')})].concat(boxes));
  }
  function passwordFields(id, optional) {
    return [el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: id, text: t(optional ? 'team_new_password' : 'team_password')}),
      el('div', {class: 'fp-reveal-wrap'}, [
        el('input', {class: 'sig-input', id: id, name: 'password', type: 'password', autocomplete: 'new-password', maxlength: String(MAX_PASSWORD), 'aria-describedby': id + '-hint'}),
        el('button', {class: 'sig-ghost fp-reveal', type: 'button', 'data-overlap-ok': '', 'data-fp-reveal': id + ',' + id + '-again', 'aria-pressed': 'false',
          'aria-label': 'Show password'}, [UI.icon(FP.ui, 'ui_eye')])]),
      el('span', {class: 'sig-hint', id: id + '-hint', text: t(optional ? 'team_new_password_hint' : 'team_password_hint')})]),
    el('div', {class: 'sig-field'}, [el('label', {class: 'sig-label', for: id + '-again', text: t('team_password_again')}),
      el('input', {class: 'sig-input', id: id + '-again', name: 'again', type: 'password', autocomplete: 'new-password', maxlength: String(MAX_PASSWORD)})]),
    el('div', {class: 'fp-mail-gen'}, [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'generate', 'data-fp-for': id, text: t('team_generate')})])];
  }
  /* '' for none (an edit may leave it), null and a message on the form when it doesn't do */
  function readPassword(form, optional) {
    var pw = form.querySelector('[name="password"]');
    var again = form.querySelector('[name="again"]');
    if (optional && !pw.value && !again.value) { return ''; }
    var bytes = new window.TextEncoder().encode(pw.value).length;
    if (bytes < 12) { M.fieldError(form, pw, t('team_password_short')); return null; }
    if (bytes > MAX_PASSWORD) { M.fieldError(form, pw, t('team_password_long')); return null; }
    if (pw.value !== again.value) { M.fieldError(form, again, t('team_password_mismatch')); return null; }
    return pw.value;
  }
  /* the owner's own password, asked again before access is given: a new member, more grants for one, a new password or an address for one, or
     turning one on (docs/api.md, "Team members", current_password) */
  function currentField(id, hintKey) {
    return M.field(id, t('team_current'), el('input', {class: 'sig-input', id: id, name: 'current_password', type: 'password', autocomplete: 'current-password',
      maxlength: String(MAX_PASSWORD)}), t(hintKey));
  }
  function readCurrent(form, required, messageKey) {
    var f = form.querySelector('[name="current_password"]');
    if (!f.value) {
      if (required) { M.fieldError(form, f, t(messageKey)); return null; }
      return '';
    }
    return f.value;
  }
  /* a wrong password is 403: the field is cleared and marked; any other refusal is the server's words (a 422 on the field is marked by M.failed) */
  function failedWithCurrent(form, err) {
    var f = form.querySelector('[name="current_password"]');
    if (err && err.code === 'forbidden' && f) {
      f.value = '';
      M.fieldError(form, f, t('team_current_wrong'));
      return;
    }
    M.failed(form, err);
  }
  function readEmail(form) {
    var f = form.querySelector('[name="email"]');
    var v = f.value.trim();
    if (v && (v.length > 254 || !EMAIL_RE.test(v))) { M.fieldError(form, f, t('team_email_bad')); return null; }
    return v;
  }
  function readGrants(form) {
    var out = [];
    var boxes = form.querySelectorAll('input[name="grant"]');
    for (var i = 0; i < boxes.length; i++) { if (boxes[i].checked) { out.push(boxes[i].value); } }
    return out;
  }
  function emailField(id, value) {
    var input = el('input', {class: 'sig-input', id: id, name: 'email', type: 'email', autocomplete: 'off', maxlength: '254', spellcheck: 'false', autocapitalize: 'none'});
    input.value = value || '';
    return M.field(id, t('team_email'), input, t('team_email_hint'));
  }

  function addCard() {
    var D = S.data;
    if (S.tf === false) { return null; }
    if (D.members.length >= D.limit) {
      return M.card('fp-team-add-h', t('team_add_title'), [el('p', {class: 'fp-muted', 'data-fp-team-full': '', text: t('team_full', {limit: String(D.limit)})})], 'fp-team-add');
    }
    if (!D.catalog.length) {
      return M.card('fp-team-add-h', t('team_add_title'), [el('p', {class: 'fp-muted', text: t('team_no_catalog')})], 'fp-team-add');
    }
    var name = el('input', {class: 'sig-input', id: 'fp-team-name', name: 'name', type: 'text', autocomplete: 'off', maxlength: '16', spellcheck: 'false', autocapitalize: 'none'});
    var form = el('form', {class: 'fp-form fp-mail-form fp-team-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-team-name', t('team_name'), name, t('team_name_hint', {account: S.account})),
      emailField('fp-team-email', '')].concat(passwordFields('fp-team-pw', false), [grantsField('fp-team-g', []), currentField('fp-team-cur', 'team_current_hint_add'),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('team_add')})])]));
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var n = name.value.trim();
      if (!NAME_RE.test(n)) { M.fieldError(form, name, t('team_name_bad')); return; }
      if (byName(n)) { M.fieldError(form, name, t('team_name_taken', {login: loginOf(n)})); return; }
      var email = readEmail(form);
      if (email === null) { return; }
      var pw = readPassword(form, false);
      if (pw === null) { return; }
      var current = readCurrent(form, true, 'team_current_need_add');
      if (current === null) { return; }
      var body = {name: n, password: pw, grants: readGrants(form), current_password: current};
      if (email) { body.email = email; }
      UI.setBusy(b, true);
      FP.call('post', 'acctTeam', body, S.account).then(function (r) {
        var m = cleanMember(r) || {name: n, email: email, grants: body.grants, disabled: false, tf: false, created: ''};
        replaceMember(m);
        render();
        M.say(S.page.querySelector('.fp-team-list'), t('team_added_ok', {login: loginOf(m.name)}));
        var row = S.page.querySelector('[data-fp-member="' + window.CSS.escape(m.name) + '"] [data-fp-act]');
        (row || S.page.querySelector('#fp-team-list-h')).focus();
      }, function (err) {
        UI.setBusy(b, false);
        if (err.code === 'two_factor_required') { S.tf = false; render(); UI.showError(S.page.querySelector('.fp-team-tf'), err.message); S.page.querySelector('#fp-team-tf-h').focus(); return; }
        failedWithCurrent(form, err);
        if (!form.contains(document.activeElement)) { b.focus(); }
      });
    });
    return M.card('fp-team-add-h', t('team_add_title'), [el('p', {class: 'fp-muted', text: t('team_add_desc')}), form], 'fp-team-add');
  }

  function editCard() {
    var m = S.editing && byName(S.editing);
    if (!m) { return null; }
    var login = loginOf(m.name);
    var form = el('form', {class: 'fp-form fp-mail-form fp-team-form fp-team-edit-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      grantsField('fp-team-eg', m.grants), emailField('fp-team-eemail', m.email)].concat(passwordFields('fp-team-epw', true), [
      currentField('fp-team-ecur', 'team_current_hint_edit'),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('team_save')}),
        el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'edit-cancel', text: t('cancel')})])]));
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var email = readEmail(form);
      if (email === null) { return; }
      var pw = readPassword(form, true);
      if (pw === null) { return; }
      var grants = readGrants(form);
      var body = {};
      if (grants.slice().sort().join(',') !== m.grants.slice().sort().join(',')) { body.grants = grants; }
      if (email !== m.email) { body.email = email; }
      if (pw) { body.password = pw; }
      if (!Object.keys(body).length) { M.say(form, t('team_nothing_changed')); return; }
      /* what gives a login to whoever holds a stolen session asks for the password: more areas than the member has now, a new password, or an
         address (a reset link goes there). Taking areas away or clearing the address does not, and a password typed then is not sent */
      var more = body.grants && body.grants.some(function (g) { return m.grants.indexOf(g) < 0; });
      if (more || body.password || (body.email !== undefined && body.email !== '')) {
        var current = readCurrent(form, true, 'team_current_need_edit');
        if (current === null) { return; }
        body.current_password = current;
      }
      UI.setBusy(b, true);
      FP.call('patch', 'acctTeamMember', body, {name: S.account, member: m.name}).then(function (r) {
        var next = cleanMember(r);
        if (next) { replaceMember(next); }
        S.editing = '';
        render();
        M.say(S.page.querySelector('.fp-team-list'), t(body.password ? 'team_changed_password' : 'team_changed', {login: login}));
        var again = S.page.querySelector('[data-fp-member="' + window.CSS.escape(m.name) + '"] [data-fp-act="edit"]');
        (again || S.page.querySelector('#fp-team-list-h')).focus();
      }, function (err) {
        UI.setBusy(b, false);
        failedWithCurrent(form, err);
        if (!form.contains(document.activeElement)) { b.focus(); }
      });
    });
    return M.card('fp-team-edit-h', t('team_edit_title', {login: login}), [form], 'fp-team-edit');
  }

  /* ---- the page ---- */
  function render() {
    S.page.textContent = '';
    var tf = twoFactorCard();
    if (tf) { S.page.appendChild(tf); }
    S.page.appendChild(listCard());
    var edit = editCard();
    if (edit) { S.page.appendChild(edit); }
    var add = addCard();
    if (add) { S.page.appendChild(add); }
    S.page.appendChild(el('p', {class: 'fp-muted fp-team-sign-in', 'data-fp-team-sign-in': '', text: t('team_sign_in', {account: S.account})}));
  }
  function rowError(b, err) {
    var list = S.page.querySelector('.fp-team-list');
    UI.setBusy(b, false);
    if (err.code === 'two_factor_required') { S.tf = false; render(); UI.showError(S.page.querySelector('.fp-team-tf'), err.message); S.page.querySelector('#fp-team-tf-h').focus(); return; }
    UI.showError(list, err.message);
    b.focus();
  }
  function after(name, act, said) {
    render();
    M.say(S.page.querySelector('.fp-team-list'), said);
    var row = S.page.querySelector('[data-fp-member="' + window.CSS.escape(name) + '"]');
    var again = row && (row.querySelector('[data-fp-act="' + act + '"]') || row.querySelector('[data-fp-act]'));
    (again || S.page.querySelector('#fp-team-list-h')).focus();
  }

  /* turning a member on gives access back, so the owner's own password is asked first, in the row */
  function askOn(m, cell) {
    var login = loginOf(m.name);
    var id = 'fp-team-on-' + m.name;
    var form = el('form', {class: 'fp-form fp-team-on-form', novalidate: '', 'data-fp-on-form': m.name, 'aria-labelledby': id + '-q'}, [M.errorLine(),
      el('p', {class: 'fp-team-on-ask', id: id + '-q', text: t('team_on_ask', {login: login})}), currentField(id, 'team_current_hint_on'),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary sig-btn--sm fp-submit', type: 'submit', 'aria-label': t('team_turn_on_of', {login: login}), text: t('team_turn_on')}),
        el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'on-cancel', text: t('cancel')})])]);
    cell.textContent = '';
    cell.appendChild(form);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      var current = readCurrent(form, true, 'team_on_need');
      if (current === null) { return; }
      UI.setBusy(b, true);
      var mine = S;
      FP.call('patch', 'acctTeamMember', {disabled: false, current_password: current}, {name: S.account, member: m.name}).then(function (r) {
        if (S !== mine) { return; }
        replaceMember(cleanMember(r) || {name: m.name, email: m.email, grants: m.grants, disabled: false, tf: m.tf, created: m.created});
        after(m.name, 'off', t('team_turned_on', {login: login}));
      }, function (err) {
        if (S !== mine) { return; }
        UI.setBusy(b, false);
        if (err.code === 'two_factor_required') { S.tf = false; render(); UI.showError(S.page.querySelector('.fp-team-tf'), err.message); S.page.querySelector('#fp-team-tf-h').focus(); return; }
        failedWithCurrent(form, err);
        if (!form.contains(document.activeElement)) { b.focus(); }
      });
    });
    form.querySelector('[name="current_password"]').focus();
  }

  function onClick(e) {
    var b = e.target && e.target.closest ? e.target.closest('[data-fp-act]') : null;
    if (!b || !S || !S.page || !S.page.contains(b) || b.disabled || !S.data) { return; }
    var a = b.getAttribute('data-fp-act');
    if (a === 'generate') { return; }
    var row = b.closest('[data-fp-member]');
    var name = row ? row.getAttribute('data-fp-member') : '';
    var m = name ? byName(name) : null;
    var list = S.page.querySelector('.fp-team-list');
    if (a === 'edit-cancel') {
      var was = S.editing;
      S.editing = '';
      render();
      var back = S.page.querySelector('[data-fp-member="' + window.CSS.escape(was) + '"] [data-fp-act="edit"]');
      (back || S.page.querySelector('#fp-team-list-h')).focus();
      return;
    }
    if (!m) { return; }
    var arg = {name: S.account, member: m.name};
    var login = loginOf(m.name);
    UI.showError(list, '');
    M.say(list, '');
    if (a === 'edit') {
      S.editing = m.name;
      render();
      S.page.querySelector('#fp-team-edit-h').focus();
    } else if (a === 'on') {
      askOn(m, b.parentNode);
    } else if (a === 'on-cancel') {
      var cellOn = b.closest('.fp-team-acts');
      cellOn.textContent = '';
      actsFor(m).forEach(function (x) { cellOn.appendChild(x); });
      cellOn.querySelector('[data-fp-act="on"]').focus();
    } else if (a === 'off') {
      UI.setBusy(b, true);
      FP.call('patch', 'acctTeamMember', {disabled: true}, arg).then(function (r) {
        replaceMember(cleanMember(r) || {name: m.name, email: m.email, grants: m.grants, disabled: true, tf: m.tf, created: m.created});
        after(m.name, 'on', t('team_turned_off', {login: login}));
      }, function (err) { rowError(b, err); });
    } else if (a === 'remove') {
      M.confirmIn(b.parentNode, t('team_remove_ask', {login: login}), 'remove-yes', t('team_remove'));
    } else if (a === 'confirm-no') {
      var cell = b.parentNode;
      cell.textContent = '';
      actsFor(m).forEach(function (x) { cell.appendChild(x); });
      cell.querySelector('[data-fp-act="remove"]').focus();
    } else if (a === 'remove-yes') {
      UI.setBusy(b, true);
      FP.call('del', 'acctTeamMember', undefined, arg).then(function () {
        S.data.members = S.data.members.filter(function (x) { return x.name !== m.name; });
        if (S.editing === m.name) { S.editing = ''; }
        render();
        M.say(S.page.querySelector('.fp-team-list'), t('team_removed', {login: login}));
        S.page.querySelector('#fp-team-list-h').focus();
      }, function (err) { rowError(b, err); });
    }
  }
  document.addEventListener('click', onClick);

  FP.view('tool:sub_users', function () {
    S = null;
    var tool = FP.tools.sub_users;
    if (!tool || FP.realm !== 'user') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var page = FP.frame({title: tool.label, desc: t('team_desc'), cls: 'fp-mail fp-team',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    S = {page: page, account: FP.account(), data: null, tf: null, editing: ''};
    var mine = S;
    page.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    /* the owner's two-factor is read fresh: it may have been turned on a minute ago on the other page */
    Promise.all([FP.call('get', 'acctTeam', undefined, S.account), API.get('session').then(function (s) { return obj(obj(s).user).two_factor === true; }, function () { return null; })]).then(function (r) {
      if (S !== mine) { return; }
      S.data = clean(r[0]);
      S.tf = r[1];
      render();
    }, function (err) {
      if (S !== mine) { return; }
      page.textContent = '';
      page.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

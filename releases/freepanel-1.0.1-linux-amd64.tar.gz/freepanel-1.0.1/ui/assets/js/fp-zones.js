/* freePanel DNS zones (#/tool/dns_zones), the admin panel's list of every zone on the server (docs/api.md, "DNS zones":
   GET /dns/zones). An admin sees every zone, including one whose account is gone; a reseller sees the zones of its own
   accounts. A filter narrows the list by zone or account name. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;

  var ZONE_RE = /^[a-z0-9.-]{1,253}$/;
  var USER_RE = /^[a-z][a-z0-9]{0,15}$/;

  function clean(r) {
    return (r && Array.isArray(r.zones) ? r.zones : []).filter(function (z) {
      return z && typeof z.zone === 'string' && ZONE_RE.test(z.zone);
    }).map(function (z) {
      return {zone: z.zone, account: typeof z.account === 'string' && USER_RE.test(z.account) ? z.account : '',
        primary: z.primary === true, records: typeof z.records === 'number' && isFinite(z.records) && z.records >= 0 ? Math.floor(z.records) : null,
        created: typeof z.created === 'string' ? z.created : ''};
    });
  }
  function day(iso) {
    var d = iso ? new Date(iso) : null;
    if (!d || isNaN(d.getTime())) { return ''; }
    return d.toLocaleDateString(undefined, {year: 'numeric', month: 'short', day: 'numeric'});
  }

  function row(z) {
    return el('tr', {'data-fp-zone': z.zone}, [
      el('th', {scope: 'row', class: 'fp-zone-name', text: z.zone}),
      el('td', {text: z.account || '–'}),
      el('td', null, [el('span', {class: 'sig-pill ' + (z.primary ? 'sig-pill--accent' : ''), text: z.primary ? t('zones_kind_main') : t('zones_kind_added')})]),
      el('td', {class: 'fp-num', text: z.records === null ? '–' : String(z.records)}),
      el('td', {text: day(z.created) || '–'})]);
  }

  function render(body, zones) {
    body.textContent = '';
    if (!zones.length) {
      body.appendChild(FP.empty(t('zones_none'), t('zones_none_desc')));
      return;
    }
    var filter = el('input', {class: 'sig-input', id: 'fp-zones-filter', type: 'search', autocomplete: 'off', spellcheck: 'false',
      maxlength: '253', 'aria-describedby': 'fp-zones-count'});
    var count = el('p', {class: 'fp-muted', id: 'fp-zones-count', role: 'status', 'aria-live': 'polite'});
    var tbody = el('tbody', null, zones.map(row));
    var none = el('p', {class: 'fp-muted', 'data-fp-zones-none': '', hidden: true, text: t('zones_no_match')});
    var table = el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-h1'}, [
      el('table', {class: 'sig-table fp-zones-table'}, [el('thead', null, [el('tr', null, [
        el('th', {scope: 'col', text: t('zones_zone')}), el('th', {scope: 'col', text: t('zones_account')}),
        el('th', {scope: 'col', text: t('zones_kind')}), el('th', {scope: 'col', class: 'fp-num', text: t('zones_records')}),
        el('th', {scope: 'col', text: t('zones_created')})])]), tbody])]);
    function apply() {
      var q = filter.value.trim().toLowerCase();
      var shown = 0;
      for (var i = 0; i < tbody.children.length; i++) {
        var z = zones[i];
        var hit = !q || z.zone.indexOf(q) >= 0 || z.account.indexOf(q) >= 0;
        tbody.children[i].hidden = !hit;
        if (hit) { shown++; }
      }
      table.hidden = shown === 0;
      none.hidden = shown !== 0;
      count.textContent = q ? t('zones_count_filtered', {n: shown, total: zones.length}) : t(zones.length === 1 ? 'zones_count_1' : 'zones_count', {n: zones.length});
    }
    filter.addEventListener('input', apply);
    filter.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && filter.value) { e.stopPropagation(); filter.value = ''; apply(); }
    });
    body.appendChild(el('section', {class: 'sig-card'}, [el('div', {class: 'sig-card-body'}, [
      el('div', {class: 'sig-field fp-zones-filter'}, [el('label', {class: 'sig-label', for: 'fp-zones-filter', text: t('zones_filter')}), filter]),
      count, table, none])]));
    apply();
  }

  FP.view('tool:dns_zones', function () {
    var tool = FP.tools.dns_zones;
    if (!tool || FP.realm !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var reseller = FP.session.user.role === 'reseller';
    var body = FP.frame({title: tool.label, desc: reseller ? t('zones_desc_reseller') : t('zones_desc'), cls: 'fp-zones',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'dnsZones').then(function (r) {
      render(body, clean(r));
    }, function (err) {
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

/* freePanel shell access (#/tool/shell_access), the admin panel's page for each account's shell type and the type new
   accounts get (docs/api.md, "Shell access"): disabled, jailed or normal. Only the server's admin sets them. The
   server's reason it can't jail is shown as text. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var USER_RE = /^[a-z][a-z0-9]{0,15}$/;
  var TYPES = ['disabled', 'jailed', 'normal'];

  var X = null;

  function str(v) { return typeof v === 'string' ? v : ''; }
  function cleanSettings(r) {
    r = r && typeof r === 'object' ? r : {};
    return {jailed: r.new_accounts_jailed === true, available: r.jail_available === true, reason: str(r.jail_reason).slice(0, 300)};
  }
  function cleanAccounts(r) {
    return (r && Array.isArray(r.accounts) ? r.accounts : []).filter(function (a) { return a && USER_RE.test(str(a.username)); }).map(function (a) {
      return {username: a.username, owner: str(a.owner).slice(0, 64), pkg: str(a.package).slice(0, 64), suspended: a.status === 'suspended',
        shell: TYPES.indexOf(a.shell) >= 0 ? a.shell : ''};
    }).sort(function (a, b) { return a.username < b.username ? -1 : 1; });
  }
  function byName(u) {
    for (var i = 0; i < X.accounts.length; i++) { if (X.accounts[i].username === u) { return X.accounts[i]; } }
    return null;
  }
  function canJail() { return !X.settings || X.settings.available; }

  /* ---------- new accounts ---------- */
  function settingsCard() {
    var parts = [M.errorLine(), M.statusLine()];
    var s = X.settings;
    if (!s) {
      parts.push(el('p', {class: 'fp-sh-bad', 'data-fp-sh-settings-error': '', text: t('sh_settings_failed') + ' ' + X.settingsError}));
      return M.card('fp-sh-new-h', t('sh_new_title'), parts, 'fp-sh-new');
    }
    parts.push(el('p', {'data-fp-sh-jail': '', class: s.available ? '' : 'fp-sh-bad',
      text: s.available ? t('sh_jail_yes') : t('sh_jail_no') + ' ' + (s.reason || t('sh_jail_no_reason'))}));
    var box = el('input', {type: 'checkbox', id: 'fp-sh-newjailed', name: 'new_accounts_jailed', checked: s.jailed ? true : null,
      disabled: !s.available && !s.jailed ? true : null, 'aria-describedby': 'fp-sh-newjailed-hint'});
    var form = el('form', {class: 'fp-form fp-sh-form', novalidate: ''}, [
      el('label', {class: 'fp-check', for: 'fp-sh-newjailed'}, [box, el('span', {text: t('sh_new_jailed')})]),
      el('span', {class: 'sig-hint', id: 'fp-sh-newjailed-hint', text: t('sh_new_jailed_hint')}),
      el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('sh_save')})])]);
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var card = X.page.querySelector('.fp-sh-new');
      var b = form.querySelector('.fp-submit');
      if (b.disabled) { return; }
      UI.showError(card, '');
      M.say(card, '');
      UI.setBusy(b, true);
      FP.call('put', 'serverShell', {new_accounts_jailed: box.checked}).then(function (r) {
        X.settings = cleanSettings(r);
        render();
        var again = X.page.querySelector('.fp-sh-new .fp-submit');
        again.focus();
        M.say(X.page.querySelector('.fp-sh-new'), t(X.settings.jailed ? 'sh_saved_jailed' : 'sh_saved_normal'));
      }, function (err) {
        UI.setBusy(b, false);
        UI.showError(card, err.message);
        b.focus();
      });
    });
    parts.push(form);
    return M.card('fp-sh-new-h', t('sh_new_title'), parts, 'fp-sh-new');
  }

  /* ---------- accounts ---------- */
  function shellSelect(a) {
    return el('select', {class: 'sig-select fp-sh-pick', name: 'shell', 'aria-label': t('sh_shell_of', {account: a.username})}, TYPES.map(function (k) {
      return el('option', {value: k, text: t('sh_type_' + k), selected: a.shell === k ? true : null,
        disabled: k === 'jailed' && !canJail() && a.shell !== 'jailed' ? true : null});
    }));
  }
  function actsFor(a) {
    return [el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'save', 'aria-label': t('sh_save_of', {account: a.username}),
      text: t('sh_save')})];
  }
  function row(a) {
    return el('tr', {'data-fp-account': a.username, hidden: X.filter && a.username.indexOf(X.filter) < 0 ? true : null}, [
      el('th', {scope: 'row', class: 'fp-sh-name'}, [el('span', {class: 'sig-mono', text: a.username}),
        a.suspended ? el('span', {class: 'fp-muted fp-row-note', text: t('sh_suspended')}) : null]),
      el('td', {text: a.owner || '—'}),
      el('td', {class: 'fp-sh-pkg', text: a.pkg || '—'}),
      el('td', null, [a.shell ? shellSelect(a) : el('span', {class: 'fp-muted', text: t('sh_unknown')})]),
      el('td', {class: 'fp-mail-acts fp-sh-acts'}, a.shell ? actsFor(a) : [])]);
  }
  function accountsCard() {
    var parts = [M.errorLine(), M.statusLine(), el('p', {class: 'fp-muted', text: t('sh_types')})];
    if (!X.accounts.length) {
      parts.push(el('p', {class: 'fp-muted', 'data-fp-empty': '', text: t('sh_no_accounts')}));
      return M.card('fp-sh-list-h', t('sh_list_title'), parts, 'fp-sh-list');
    }
    var filter = el('input', {class: 'sig-input', id: 'fp-sh-filter', type: 'search', autocomplete: 'off', spellcheck: 'false', value: X.filter});
    filter.addEventListener('input', function () {
      X.filter = filter.value.trim().toLowerCase();
      var rows = X.page.querySelectorAll('tr[data-fp-account]');
      for (var i = 0; i < rows.length; i++) { rows[i].hidden = !!X.filter && rows[i].getAttribute('data-fp-account').indexOf(X.filter) < 0; }
    });
    parts.push(el('div', {class: 'sig-field fp-sh-filter'}, [el('label', {class: 'sig-label', for: 'fp-sh-filter', text: t('sh_filter')}), filter]));
    parts.push(el('div', {class: 'fp-table-wrap', tabindex: '0', role: 'region', 'aria-labelledby': 'fp-sh-list-h'}, [
      el('table', {class: 'sig-table fp-mail-table fp-sh-table'}, [el('thead', null, [el('tr', null, [
        el('th', {scope: 'col', text: t('sh_account')}), el('th', {scope: 'col', text: t('sh_owner')}), el('th', {scope: 'col', text: t('sh_package')}),
        el('th', {scope: 'col', text: t('sh_shell')}), el('th', {scope: 'col'}, [el('span', {class: 'sig-vh', text: t('mail_actions')})])])]),
      el('tbody', null, X.accounts.map(row))])]));
    parts.push(el('p', {class: 'fp-muted', text: t('sh_package_note')}));
    return M.card('fp-sh-list-h', t('sh_list_title'), parts, 'fp-sh-list');
  }

  function render() {
    X.page.textContent = '';
    X.page.appendChild(settingsCard());
    X.page.appendChild(accountsCard());
  }
  function restoreActs(tr, a) {
    var cell = tr.querySelector('.fp-sh-acts');
    cell.textContent = '';
    actsFor(a).forEach(function (x) { cell.appendChild(x); });
    return cell.querySelector('[data-fp-act="save"]');
  }
  function save(tr, a, shell, b) {
    var list = X.page.querySelector('.fp-sh-list');
    UI.setBusy(b, true);
    FP.call('put', 'accountShell', {shell: shell}, a.username).then(function (r) {
      var got = TYPES.indexOf(r && r.shell) >= 0 ? r.shell : shell;
      a.shell = got;
      var fresh = row(a);
      tr.parentNode.replaceChild(fresh, tr);
      fresh.querySelector('[data-fp-act="save"]').focus();
      M.say(list, t(a.suspended ? 'sh_saved_account_suspended' : 'sh_saved_account', {account: a.username, type: t('sh_type_' + got)}));
    }, function (err) {
      var again = restoreActs(tr, a);
      UI.showError(list, err.message);
      again.focus();
    });
  }

  function onClick(e) {
    var target = e.target.closest ? e.target : null;
    var b = target && X && X.page && X.page.contains(target) ? target.closest('[data-fp-act]') : null;
    if (!b) { return; }
    var tr = b.closest('tr[data-fp-account]');
    var a = tr && byName(tr.getAttribute('data-fp-account'));
    if (!a) { return; }
    var act = b.getAttribute('data-fp-act');
    var list = X.page.querySelector('.fp-sh-list');
    var pick = tr.querySelector('select[name="shell"]');
    if (act === 'save') {
      UI.showError(list, '');
      M.say(list, '');
      if (pick.value === a.shell) { M.say(list, t('sh_unchanged', {account: a.username, type: t('sh_type_' + a.shell)})); return; }
      if (pick.value === 'normal') {
        M.confirmIn(b.parentNode, t('sh_ask_normal', {account: a.username}), 'save-yes', t('sh_give_normal'));
        return;
      }
      save(tr, a, pick.value, b);
    } else if (act === 'save-yes') {
      save(tr, a, 'normal', b);
    } else if (act === 'confirm-no') {
      restoreActs(tr, a).focus();
    }
  }
  document.addEventListener('click', onClick);

  FP.view('tool:shell_access', function () {
    var tool = FP.tools.shell_access;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    var body = FP.frame({title: tool.label, desc: t('sh_desc'), cls: 'fp-mail fp-sh',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    X = {page: body, settings: null, settingsError: '', accounts: [], filter: ''};
    var mine = X;
    body.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    var settings = FP.call('get', 'serverShell').then(cleanSettings, function (err) { mine.settingsError = err.message; return null; });
    Promise.all([FP.call('get', 'accounts'), settings]).then(function (r) {
      if (X !== mine) { return; }
      X.accounts = cleanAccounts(r[0]);
      X.settings = r[1];
      render();
    }, function (err) {
      if (X !== mine) { return; }
      body.textContent = '';
      body.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

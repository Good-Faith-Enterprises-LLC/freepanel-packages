/* freePanel delivery log (docs/api.md, "Email", GET .../email/delivery): the customer panel's Track delivery page (#/tool/delivery_log). A customer
   looks for one message, or the newest ones, by an address, a domain, a queue ID or a Message-ID, in a window of time (up to 14 days), and sees each
   message's journey: when it came in, who it was for, and for every recipient whether it was delivered, is waiting, or came back, with the other
   server's own answer. The log shows only the account's own mail (the API leaves everything else out, and never shows a connection or a login). One
   search runs at a time and the server leaves ten seconds between an account's searches, so a refusal that says to wait is shown as the server
   words it. A search reads the mail log and can take up to twenty seconds. Everything the server sends is shown as text. The page pieces come
   from FP.mail (fp-mail.js). */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var ID_RE = /^[0-9A-Za-z]{6,32}$/;
  var Q_RE = /^[A-Za-z0-9@._%+=/!#$&'*?^{|}~:-]{3,254}$/;
  var WORD_RE = /^[a-z][a-z-]{0,19}$/;
  var DSN_RE = /^[245]\.\d{1,3}\.\d{1,3}$/;
  var STATUSES = ['queued', 'delivered', 'deferred', 'bounced', 'expired', 'partial', 'removed'];
  var KIND = {queued: '', delivered: 'ok', deferred: 'warn', bounced: 'danger', expired: 'danger', partial: 'warn', removed: ''};
  var RCPT_KIND = {sent: 'ok', delivered: 'ok', deferred: 'warn', bounced: 'danger', expired: 'danger'};
  var HOUR = 3600 * 1000;
  var DAY = 24 * HOUR;
  /* the server allows a window of 14 days and measures it to its own clock: "14 days" leaves ten minutes for the difference */
  var RANGES = [{id: '1h', ms: HOUR}, {id: '24h', ms: DAY}, {id: '3d', ms: 3 * DAY}, {id: '7d', ms: 7 * DAY}, {id: '14d', ms: 14 * DAY - 10 * 60 * 1000}];
  var LIMITS = [25, 50, 100];

  function obj(v) { return v && typeof v === 'object' && !Array.isArray(v) ? v : {}; }
  /* text from the mail log or from another server: control characters out, cut to n */
  function text(v, n) {
    if (typeof v !== 'string') { return ''; }
    var out = '';
    for (var i = 0; i < v.length && out.length <= n; i++) {
      var c = v.charCodeAt(i);
      out += c < 32 || c === 127 ? ' ' : v.charAt(i);
    }
    return out.trim().slice(0, n);
  }
  function whole(v) { return typeof v === 'number' && isFinite(v) && v >= 0 && Math.floor(v) === v ? v : null; }
  function when(v) {
    if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}T/.test(v)) { return ''; }
    var d = new Date(v);
    return isNaN(d.getTime()) || d.getFullYear() < 2000 ? '' : d.toLocaleString('en', {dateStyle: 'medium', timeStyle: 'medium'});
  }
  function size(n) {
    if (n === null) { return ''; }
    if (n < 1024) { return t('size_bytes', {n: String(n)}); }
    var units = ['KB', 'MB', 'GB'];
    var u = -1;
    do { n /= 1024; u++; } while (n >= 1024 && u < units.length - 1);
    return (n < 10 ? n.toFixed(1) : Math.round(n).toLocaleString('en')) + ' ' + units[u];
  }
  function iso(d) { return d.toISOString().replace(/\.\d{3}Z$/, 'Z'); }

  function cleanRecipient(r) {
    r = obj(r);
    var to = text(r.to, 320);
    if (!to) { return null; }
    return {to: to, orig: text(r.orig_to, 320), status: WORD_RE.test(text(r.status, 20)) ? r.status : '', relay: text(r.relay, 300),
      dsn: DSN_RE.test(text(r.dsn, 12)) ? r.dsn : '', response: text(r.response, 300), at: when(r.at), attempts: whole(r.attempts) || 0};
  }
  function cleanMessage(m) {
    m = obj(m);
    if (!ID_RE.test(text(m.id, 32))) { return null; }
    var rcpts = (Array.isArray(m.recipients) ? m.recipients : []).slice(0, 40).map(cleanRecipient).filter(Boolean);
    return {id: m.id, status: STATUSES.indexOf(m.status) >= 0 ? m.status : '', started: when(m.started), from: text(m.from, 320), size: whole(m.size),
      messageId: text(m.message_id, 300), recipients: rcpts, more: Math.min(whole(m.more_recipients) || 0, 1000000),
      bounce: ID_RE.test(text(m.bounce, 32)) ? m.bounce : '', bounceOf: ID_RE.test(text(m.bounce_of, 32)) ? m.bounce_of : '',
      notice: WORD_RE.test(text(m.notice, 20)) ? m.notice : ''};
  }
  function cleanRefusal(r) {
    r = obj(r);
    var code = whole(r.code);
    return {at: when(r.at), stage: text(r.stage, 40), code: code && code >= 200 && code <= 599 ? code : 0, dsn: DSN_RE.test(text(r.dsn, 12)) ? r.dsn : '',
      text: text(r.text, 300), from: text(r.from, 320), to: text(r.to, 320)};
  }
  function cleanResult(r) {
    r = obj(r);
    return {from: when(r.from), to: when(r.to), truncated: r.truncated === true,
      messages: (Array.isArray(r.messages) ? r.messages : []).slice(0, 100).map(cleanMessage).filter(Boolean),
      refusals: (Array.isArray(r.refusals) ? r.refusals : []).slice(0, 100).map(cleanRefusal)};
  }

  var T = {page: null, account: '', busy: false, result: null, asked: null};

  /* ---- the answer ---- */
  function pill(kind, label) { return el('span', {class: 'sig-pill' + (kind ? ' sig-pill--' + kind : ''), text: label}); }
  function rcptStatus(r) {
    if (!r.status) { return null; }
    var known = ['sent', 'delivered', 'deferred', 'bounced', 'expired'].indexOf(r.status) >= 0;
    return pill(RCPT_KIND[r.status] || '', known ? t('dlv_r_' + r.status) : r.status);
  }
  function recipient(r) {
    var meta = [r.at, r.attempts ? t(r.attempts === 1 ? 'dlv_attempt' : 'dlv_attempts', {n: r.attempts}) : '', r.relay ? t('dlv_via', {relay: r.relay}) : ''].filter(Boolean);
    var parts = [el('div', {class: 'fp-trk-rhead'}, [rcptStatus(r), el('span', {class: 'sig-mono fp-trk-to', text: r.to}),
      r.orig && r.orig !== r.to ? el('span', {class: 'fp-muted fp-row-note', text: t('dlv_was_sent_to', {address: r.orig})}) : null])];
    if (meta.length) { parts.push(el('p', {class: 'fp-muted fp-row-note fp-trk-meta', text: meta.join(' · ')})); }
    if (r.response || r.dsn) {
      parts.push(el('p', {class: 'fp-trk-resp'}, [el('span', {class: 'fp-trk-resp-k', text: t('dlv_server_said')}), el('code', {class: 'sig-mono fp-trk-code', text: [r.dsn, r.response].filter(Boolean).join(' ')}),
        r.dsn ? el('span', {class: 'fp-muted fp-row-note', text: t('dlv_dsn_' + r.dsn.charAt(0))}) : null]));
    }
    return el('li', {class: 'fp-trk-rcpt'}, parts);
  }
  function follow(id, label) {
    return el('button', {class: 'sig-btn sig-btn--secondary sig-btn--sm', type: 'button', 'data-fp-act': 'dlv-follow', 'data-fp-id': id, 'aria-label': t('dlv_follow_of', {id: id}), text: label});
  }
  function message(m) {
    var facts = [[t('dlv_id'), m.id, true]];
    if (m.messageId) { facts.push([t('dlv_message_id'), m.messageId, true]); }
    if (m.size !== null) { facts.push([t('dlv_size'), size(m.size), false]); }
    var parts = [el('div', {class: 'fp-trk-top'}, [m.status ? pill(KIND[m.status], t('dlv_s_' + m.status)) : null,
      m.notice ? pill('', t('dlv_notice')) : null, ' ', el('span', {class: 'fp-trk-when', text: m.started || t('dlv_time_unknown')})]),
    m.status ? el('p', {class: 'fp-muted fp-trk-what', text: t('dlv_what_' + m.status)}) : null,
    el('p', {class: 'fp-trk-from'}, [el('span', {class: 'fp-trk-k', text: t('dlv_from')}), ' ', el('span', {class: 'sig-mono', text: m.from || t('dlv_nobody')})]),
    el('dl', {class: 'fp-trk-facts'}, facts.reduce(function (out, f) {
      return out.concat([el('dt', {text: f[0]}), el('dd', {class: f[2] ? 'sig-mono' : null, text: f[1]})]);
    }, []))];
    if (m.recipients.length) {
      parts.push(el('p', {class: 'fp-trk-k fp-trk-rcpts-h', text: t(m.recipients.length + m.more === 1 ? 'dlv_to_1' : 'dlv_to', {n: m.recipients.length + m.more})}));
      parts.push(el('ul', {class: 'fp-trk-rcpts'}, m.recipients.map(recipient)));
      if (m.more) { parts.push(el('p', {class: 'fp-muted fp-row-note', text: t('dlv_more', {n: m.more})})); }
    }
    if (m.bounce) {
      parts.push(el('div', {class: 'fp-trk-link'}, [el('span', {text: t('dlv_bounce', {id: m.bounce})}), follow(m.bounce, t('dlv_follow'))]));
    }
    if (m.bounceOf) {
      parts.push(el('div', {class: 'fp-trk-link'}, [el('span', {text: t('dlv_bounce_of', {id: m.bounceOf})}), follow(m.bounceOf, t('dlv_follow'))]));
    }
    return el('li', {class: 'fp-trk-msg', 'data-fp-id': m.id}, parts);
  }
  function refusal(r) {
    var line = [r.code ? String(r.code) : '', r.dsn, r.text].filter(Boolean).join(' ');
    return el('li', {class: 'fp-trk-refusal'}, [
      el('div', {class: 'fp-trk-top'}, [pill('warn', r.stage || t('dlv_refused')), ' ', el('span', {class: 'fp-trk-when', text: r.at || t('dlv_time_unknown')})]),
      el('p', {class: 'fp-trk-from'}, [el('span', {class: 'fp-trk-k', text: t('dlv_from')}), ' ', el('span', {class: 'sig-mono', text: r.from || t('dlv_nobody')}), ' ',
        el('span', {class: 'fp-trk-k', text: t('dlv_for')}), ' ', el('span', {class: 'sig-mono', text: r.to || t('dlv_nobody')})]),
      line ? el('p', {class: 'fp-trk-resp'}, [el('span', {class: 'fp-trk-resp-k', text: t('dlv_server_said')}), el('code', {class: 'sig-mono fp-trk-code', text: line})]) : null]);
  }
  function resultCard() {
    var r = T.result;
    var parts = [M.statusLine()];
    var span = r.from && r.to ? t('dlv_window', {from: r.from, to: r.to}) : '';
    if (!r.messages.length) {
      parts.push(el('p', {class: 'fp-trk-sum', 'data-fp-summary': '', text: t('dlv_none')}));
      if (span) { parts.push(el('p', {class: 'fp-muted', text: span})); }
      parts.push(el('p', {class: 'fp-muted', text: t('dlv_none_why')}));
    } else {
      parts.push(el('p', {class: 'fp-trk-sum', 'data-fp-summary': '', text: t(r.messages.length === 1 ? 'dlv_found_1' : 'dlv_found', {n: r.messages.length})}));
      if (span) { parts.push(el('p', {class: 'fp-muted', text: span})); }
      parts.push(el('ol', {class: 'fp-trk-list', 'aria-labelledby': 'fp-trk-res-h'}, r.messages.map(message)));
    }
    if (r.truncated) { parts.push(el('p', {class: 'fp-warn-line', 'data-fp-truncated': '', text: t('dlv_truncated')})); }
    if (r.refusals.length) {
      parts.push(el('h3', {class: 'fp-h3', id: 'fp-trk-ref-h', text: t('dlv_refusals', {n: r.refusals.length})}));
      parts.push(el('p', {class: 'fp-muted', text: t('dlv_refusals_what')}));
      parts.push(el('ul', {class: 'fp-trk-list fp-trk-refusals', 'aria-labelledby': 'fp-trk-ref-h'}, r.refusals.map(refusal)));
    }
    return M.card('fp-trk-res-h', t('dlv_results'), parts, 'fp-trk-results');
  }
  function showResult() {
    var old = T.page.querySelector('.fp-trk-results');
    var card = resultCard();
    if (old) { old.replaceWith(card); } else { T.page.querySelector('.fp-trk-search').after(card); }
    card.querySelector('#fp-trk-res-h').focus();
  }

  /* ---- the search form ---- */
  function option(value, label) { return el('option', {value: value, text: label}); }
  function searchCard() {
    var q = el('input', {class: 'sig-input sig-mono', id: 'fp-trk-q', name: 'q', type: 'text', autocomplete: 'off', spellcheck: 'false', autocapitalize: 'none', maxlength: '254'});
    var win = el('select', {class: 'sig-select', id: 'fp-trk-window', name: 'window'}, RANGES.map(function (r) { return option(r.id, t('dlv_range_' + r.id)); }).concat([option('custom', t('dlv_range_custom'))]));
    win.value = '24h';
    var from = el('input', {class: 'sig-input', id: 'fp-trk-from', name: 'from', type: 'datetime-local'});
    var to = el('input', {class: 'sig-input', id: 'fp-trk-to', name: 'to', type: 'datetime-local'});
    var custom = el('div', {class: 'fp-trk-custom', hidden: true}, [M.field('fp-trk-from', t('dlv_from_time'), from, t('dlv_from_time_hint')), M.field('fp-trk-to', t('dlv_to_time'), to, t('dlv_to_time_hint'))]);
    var status = el('select', {class: 'sig-select', id: 'fp-trk-status', name: 'status'}, [option('', t('dlv_any_status'))].concat(STATUSES.map(function (s) { return option(s, t('dlv_s_' + s)); })));
    var limit = el('select', {class: 'sig-select', id: 'fp-trk-limit', name: 'limit'}, LIMITS.map(function (n) { return option(String(n), t('dlv_limit_n', {n: n})); }));
    limit.value = '50';
    var form = el('form', {class: 'fp-form fp-mail-form fp-trk-form', novalidate: ''}, [M.errorLine(), M.statusLine(),
      M.field('fp-trk-q', t('dlv_q'), q, t('dlv_q_hint')),
      el('div', {class: 'fp-trk-row'}, [M.field('fp-trk-window', t('dlv_window_label'), win), M.field('fp-trk-status', t('dlv_status_label'), status), M.field('fp-trk-limit', t('dlv_limit_label'), limit)]),
      custom, el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('dlv_search')})])]);
    win.addEventListener('change', function () { custom.hidden = win.value !== 'custom'; });
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b || T.busy) { return; }
      run(form, b, {q: q, win: win, from: from, to: to, status: status, limit: limit});
    });
    return M.card('fp-trk-h', t('dlv_title'), [el('p', {class: 'fp-muted', text: t('dlv_intro')}), form], 'fp-trk-search');
  }

  /* the arguments of the search from the form, or null with the mistake shown against its field */
  function read(form, f) {
    var args = {name: T.account, limit: f.limit.value};
    var qv = f.q.value.trim().replace(/^<(.*)>$/, '$1');
    if (qv) {
      if (qv.length < 3) { M.fieldError(form, f.q, t('dlv_q_short')); return null; }
      if (!Q_RE.test(qv)) { M.fieldError(form, f.q, t('dlv_q_bad')); return null; }
      args.q = qv;
    }
    var now = Date.now();
    if (f.win.value === 'custom') {
      var a = f.from.value ? new Date(f.from.value) : null;
      var z = f.to.value ? new Date(f.to.value) : null;
      if (!a || isNaN(a.getTime())) { M.fieldError(form, f.from, t('dlv_from_missing')); return null; }
      if (z && isNaN(z.getTime())) { M.fieldError(form, f.to, t('dlv_to_bad')); return null; }
      var end = z && z.getTime() < now ? z.getTime() : now;
      if (a.getTime() >= end) { M.fieldError(form, f.from, t('dlv_from_after')); return null; }
      if (end - a.getTime() > 14 * DAY - 10 * 60 * 1000) { M.fieldError(form, f.from, t('dlv_window_long')); return null; }
      args.from = iso(a);
      if (z) { args.to = iso(z); }
    } else {
      var range = RANGES.filter(function (r) { return r.id === f.win.value; })[0] || RANGES[1];
      args.from = iso(new Date(now - range.ms));
    }
    if (f.status.value) { args.status = f.status.value; }
    return args;
  }
  function run(form, b, f) {
    var args = read(form, f);
    if (!args) { return; }
    var mine = T.page;
    T.busy = true;
    UI.setBusy(b, true);
    M.say(form, t('dlv_searching'));
    FP.call('get', 'mailDelivery', undefined, args).then(function (reply) {
      T.busy = false;
      if (T.page !== mine) { return; }
      UI.setBusy(b, false);
      M.say(form, '');
      T.result = cleanResult(reply);
      showResult();
      M.say(T.page.querySelector('.fp-trk-results'), t(T.result.messages.length ? 'dlv_done' : 'dlv_done_none'));
    }, function (err) {
      T.busy = false;
      if (T.page !== mine) { return; }
      UI.setBusy(b, false);
      M.say(form, '');
      /* a mistake in the times is shown against the choice of window when that is what was used */
      if (err && (err.field === 'from' || err.field === 'to') && f.win.value !== 'custom') {
        M.fieldError(form, f.win, err.message);
      } else {
        M.failed(form, err);
      }
    });
  }

  function glossaryCard() {
    return M.card('fp-trk-gl-h', t('dlv_gl_title'), [el('dl', {class: 'fp-trk-gl'}, STATUSES.reduce(function (out, s) {
      return out.concat([el('dt', null, [pill(KIND[s], t('dlv_s_' + s))]), el('dd', {text: t('dlv_what_' + s)})]);
    }, []))], 'fp-trk-glossary');
  }

  function render() {
    T.page.textContent = '';
    T.page.appendChild(searchCard());
    T.page.appendChild(glossaryCard());
  }

  /* Follow: a bounce notice or the message it is about is found by its queue ID, with the window and status left as they are */
  document.addEventListener('click', function (e) {
    if (!T.page) { return; }
    var b = e.target.closest ? e.target.closest('[data-fp-act="dlv-follow"]') : null;
    if (!b || !T.page.contains(b) || T.busy) { return; }
    var form = T.page.querySelector('.fp-trk-form');
    form.querySelector('#fp-trk-q').value = b.getAttribute('data-fp-id');
    form.querySelector('#fp-trk-status').value = '';
    if (form.requestSubmit) { form.requestSubmit(); } else { form.dispatchEvent(new Event('submit', {cancelable: true})); }
  });

  FP.view('tool:delivery_log', function () {
    T = {page: null, account: '', busy: false, result: null};
    var body = M.frame('delivery_log', 'fp-trk-page');
    if (!body) { return; }
    T.page = body;
    T.account = FP.account();
    render();
  });
})();

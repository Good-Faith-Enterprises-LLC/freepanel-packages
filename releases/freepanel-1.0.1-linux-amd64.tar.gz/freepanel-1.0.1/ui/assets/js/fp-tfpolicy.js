/* freePanel two-factor policy in the admin panel (docs/api.md, "Two-factor policy"): #/tool/two_factor_policy lets the admin require
   two-factor sign-in of every login of a role (the server's admins, resellers, customers and their team members), shows how many
   logins of each have none yet, and says before saving what the change holds on the set-up page. Admin only: the server refuses
   these calls to anyone else. The server's own warning comes back as text. A login that is held is handled by the shell
   (FP.held, fp-shell.js), which shows only the set-up page. */
(function () {
  'use strict';
  var FP = window.FP;
  var UI = window.FPUI;
  var t = UI.t;
  var el = UI.el;
  var M = FP.mail;

  var ROLES = [{key: 'admin', label: 'tfp_admin', what: 'tfp_admin_what'}, {key: 'reseller', label: 'tfp_reseller', what: 'tfp_reseller_what'},
    {key: 'user', label: 'tfp_user', what: 'tfp_user_what'}];

  function str(v, n) { return typeof v === 'string' ? v.slice(0, n || 400) : ''; }
  function whole(v) { return typeof v === 'number' && isFinite(v) && v >= 0 && Math.floor(v) === v ? v : 0; }
  function clean(r) {
    r = r && typeof r === 'object' ? r : {};
    var w = r.without && typeof r.without === 'object' ? r.without : {};
    return {admin: r.admin === true, reseller: r.reseller === true, user: r.user === true,
      without: {admin: whole(w.admin), reseller: whole(w.reseller), user: whole(w.user)}, warning: str(r.warning)};
  }

  var page = null;
  var P = null;          /* the server's reply, cleaned */
  var warning = '';      /* what the server said when the policy was last saved */

  function withoutText(n) { return n === 0 ? t('tfp_without_0') : t(n === 1 ? 'tfp_without_1' : 'tfp_without', {n: n.toLocaleString('en')}); }

  function policyCard() {
    var boxes = {};
    var rows = ROLES.map(function (r) {
      var id = 'fp-tfp-' + r.key;
      var box = el('input', {type: 'checkbox', id: id, name: r.key, checked: P[r.key] ? true : null, 'aria-describedby': id + '-hint'});
      boxes[r.key] = box;
      var n = P.without[r.key];
      return el('div', {class: 'sig-field fp-tfp-role', 'data-fp-role': r.key}, [el('label', {class: 'fp-check', for: id}, [box, el('span', {text: t(r.label)})]),
        el('span', {class: 'sig-hint', id: id + '-hint', text: t(r.what)}),
        el('span', {class: 'sig-pill fp-tfp-count' + (n ? ' sig-pill--warn' : ' sig-pill--ok'), 'data-fp-without': r.key, text: withoutText(n)})]);
    });
    var actions = el('div', {class: 'fp-actions'}, [el('button', {class: 'sig-btn sig-btn--primary fp-submit', type: 'submit', text: t('tfp_save')}),
      el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'look', text: t('sec_look_again')})]);
    var form = el('form', {class: 'fp-form fp-tfp-form', novalidate: ''}, [M.errorLine(), M.statusLine()].concat(rows, [actions]));

    function restoreActions() {
      var now = form.querySelector('.fp-actions');
      if (now !== actions) { now.replaceWith(actions); }
    }
    function save(b) {
      var body = {admin: boxes.admin.checked, reseller: boxes.reseller.checked, user: boxes.user.checked};
      var mine = page;
      UI.setBusy(b, true);
      FP.call('put', 'twoFactorPolicy', body).then(function (r) {
        if (page !== mine) { return; }
        P = clean(r);
        warning = P.warning;
        draw({say: t('tfp_saved'), focus: '#fp-tfp-admin'});
      }, function (err) {
        if (page !== mine) { return; }
        UI.setBusy(b, false);
        M.failed(form, err);
        restoreActions();
      });
    }
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var b = M.start(form);
      if (!b) { return; }
      /* a role switched on that has logins without two-factor holds them on the set-up page: say how many, and ask first */
      var held = 0;
      var me = false;
      ROLES.forEach(function (r) {
        if (boxes[r.key].checked && !P[r.key] && P.without[r.key] > 0) {
          held += P.without[r.key];
          if (r.key === 'admin' && !FP.session.user.two_factor) { me = true; }
        }
      });
      if (!held) { save(b); return; }
      var text = t(held === 1 ? 'tfp_hold_ask_1' : 'tfp_hold_ask', {n: held.toLocaleString('en')}) + (me ? ' ' + t('tfp_hold_self') : '');
      var yes = el('button', {class: 'sig-btn sig-btn--danger', type: 'button', 'data-fp-act': 'hold-yes', text: t('tfp_hold_yes')});
      var no = el('button', {class: 'sig-btn sig-btn--secondary', type: 'button', 'data-fp-act': 'hold-no', text: t('cancel')});
      var q = el('div', {class: 'fp-actions fp-tfp-ask'}, [el('p', {class: 'fp-tfp-confirm', id: 'fp-tfp-ask', 'data-fp-hold-ask': '', text: text}), yes, no]);
      yes.setAttribute('aria-describedby', 'fp-tfp-ask');
      no.setAttribute('aria-describedby', 'fp-tfp-ask');
      yes.addEventListener('click', function () { save(yes); });
      no.addEventListener('click', function () { restoreActions(); form.querySelector('.fp-submit').focus(); });
      actions.replaceWith(q);
      no.focus();
    });
    form.querySelector('[data-fp-act="look"]').addEventListener('click', function (e) {
      var b = e.currentTarget;
      var mine = page;
      M.start(form);
      UI.setBusy(b, true);
      FP.call('get', 'twoFactorPolicy').then(function (r) {
        if (page !== mine) { return; }
        P = clean(r);
        draw({say: t('tfp_looked'), focus: '[data-fp-act="look"]'});
      }, function (err) {
        if (page !== mine) { return; }
        UI.setBusy(b, false);
        UI.showError(form, err.message);
      });
    });
    var parts = [el('p', {class: 'fp-muted', text: t('tfp_what')})];
    if (warning) {
      var note = el('div', {class: 'sig-banner sig-banner--warn', role: 'note'}, [UI.icon(FP.ui, 'ui_warning'), el('span', {text: warning})]);
      note.setAttribute('data-fp-tfp-warning', '');
      parts.push(note);
    }
    parts.push(form, el('p', {class: 'fp-muted fp-tfp-console'}, [t('tfp_console_1') + ' ', el('code', {class: 'sig-mono', text: 'freepanelctl two-factor-policy off'}), ' ' + t('tfp_console_2')]));
    return M.card('fp-tfp-h', t('tfp_title'), parts, 'fp-tfp-card');
  }

  /* redraws the card; opts.say is the text for its status line, opts.focus a selector for the control that takes focus */
  function draw(opts) {
    opts = opts || {};
    var old = page.querySelector('.fp-tfp-card');
    var card = policyCard();
    if (old) { old.replaceWith(card); } else { page.appendChild(card); }
    if (opts.say) { M.say(card, opts.say); }
    var target = opts.focus ? card.querySelector(opts.focus) : null;
    if (target) { target.focus(); }
  }

  FP.view('tool:two_factor_policy', function () {
    var tool = FP.tools.two_factor_policy;
    if (!tool || FP.realm !== 'admin' || FP.session.user.role !== 'admin') { FP.views['not-found']({view: 'not-found'}); return; }
    var g = FP.group(tool.group);
    P = null;
    warning = '';
    var mine = FP.frame({title: tool.label, desc: t('tfp_desc'), cls: 'fp-mail fp-srv fp-tfp-page',
      crumbs: [{label: t('menu_home'), href: '#/'}, {label: g.label, href: '#/group/' + g.id}, {label: tool.label}]});
    page = mine;
    mine.appendChild(el('p', {class: 'fp-muted', text: t('loading')}));
    FP.call('get', 'twoFactorPolicy').then(function (r) {
      if (page !== mine) { return; }
      P = clean(r);
      mine.textContent = '';
      draw();
    }, function (err) {
      if (page !== mine) { return; }
      mine.textContent = '';
      mine.appendChild(FP.empty(tool.label, err.message));
    });
  });
})();

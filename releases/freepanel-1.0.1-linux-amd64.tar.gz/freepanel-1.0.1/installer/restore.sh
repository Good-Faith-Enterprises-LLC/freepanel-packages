# shellcheck shell=bash
# The helpers that put back what keep.sh kept: the record at $PREINSTALL
# (described in install.sh) is read, and what freePanel changed since is moved
# to $REMOVED, under its full path, never deleted. uninstall.sh sources this
# file; test/installer sources it too, with $PREINSTALL and $REMOVED in a
# folder of its own.
: "${PREINSTALL:?}"
: "${REMOVED:?}"
# park PATH: moves PATH (a file, a link or a folder) to $REMOVED, under its full
# path, in folders only root can enter, and says so. Nothing is there to move
# when PATH is not there.
park() {
  if [ -e "$1" ] || [ -L "$1" ]; then
    (umask 077 && mkdir -p -- "$REMOVED$(dirname -- "$1")")
    mv -- "$1" "$REMOVED$1"
    printf '    parked %s\n' "$1"
  fi
}
# put_back_files: every file in state/files goes back as it was: its contents,
# its owner and its mode. A file that is as it was is left alone; one that
# changed is parked first. A file that was not there (absent) is parked, and a
# link is made again as it was (links). What the installer could not keep
# (other) is named and left as it is.
put_back_files() {
  local f meta ids rest mode src t stage
  if [ -f "$PREINSTALL/state/files" ]; then
    while IFS=$'\t' read -r f meta; do
      [ -n "$f" ] || continue
      src="$PREINSTALL/files$f"
      if [ ! -f "$src" ]; then
        printf '    no copy of %s was kept; left as it is\n' "$f"
        continue
      fi
      ids="${meta%% *}"
      rest="${meta#* }"
      mode="${rest%% *}"
      if [ -f "$f" ] && [ ! -L "$f" ] && cmp -s -- "$src" "$f" &&
        [ "$(stat -c '%u:%g %a' -- "$f")" = "$ids $mode" ]; then
        continue
      fi
      # The new file is made, with its owner and mode, in a folder only root can
      # reach, and moved into place by name once the old one is parked: nothing
      # root does by name happens in the folder of a service account (PostgreSQL's),
      # where a link left at a name like "$f.freepanel-new" would be followed.
      (umask 077 && mkdir -p -- "$REMOVED")
      stage="$(mktemp -d -- "$REMOVED/stage.XXXXXX")"
      cp -P -p -- "$src" "$stage/f"
      chown "$ids" "$stage/f"
      chmod "$mode" "$stage/f"
      park "$f"
      (umask 077 && mkdir -p -- "$(dirname -- "$f")")
      mv -T -- "$stage/f" "$f"
      rmdir -- "$stage"
      # A file that is moved keeps the label of the folder it was made in; the
      # one made in place had the label its folder gives.
      if command -v restorecon >/dev/null; then restorecon -- "$f" || true; fi
      printf '    put back %s\n' "$f"
    done <"$PREINSTALL/state/files"
  fi
  if [ -f "$PREINSTALL/absent" ]; then
    while IFS= read -r f; do
      [ -n "$f" ] || continue
      park "$f"
    done <"$PREINSTALL/absent"
  fi
  if [ -f "$PREINSTALL/links" ]; then
    while IFS=$'\t' read -r f t; do
      [ -n "$f" ] || continue
      if [ -L "$f" ] && [ "$(readlink -- "$f")" = "$t" ]; then
        continue
      fi
      park "$f"
      (umask 077 && mkdir -p -- "$(dirname -- "$f")")
      ln -s -- "$t" "$f"
      printf '    put back the link %s\n' "$f"
    done <"$PREINSTALL/links"
  fi
  if [ -f "$PREINSTALL/other" ]; then
    while IFS= read -r f; do
      [ -n "$f" ] || continue
      printf '    %s is not a plain file, so nothing of it was kept; left as it is\n' "$f"
    done <"$PREINSTALL/other"
  fi
}
# put_back_sebools: the SELinux booleans go back to the values they had. A
# boolean that was not there (absent) is left.
put_back_sebools() {
  local b v now
  [ -f "$PREINSTALL/state/sebool" ] || return 0
  command -v setsebool >/dev/null || return 0
  while IFS=$'\t' read -r b v; do
    if [ -z "$b" ] || [ "$v" = absent ]; then continue; fi
    now="$(getsebool "$b" 2>/dev/null)" || continue
    now="${now##* }"
    if [ "$now" != "$v" ]; then
      setsebool -P "$b" "$v" && printf '    SELinux boolean %s is %s again\n' "$b" "$v"
    fi
  done <"$PREINSTALL/state/sebool"
}
# put_back_units: every unit of state/units that was there before goes back to
# the state it was in: enabled or not, running or not. A unit that was not there
# (absent) is left, and so are freePanel's own, which uninstall.sh has stopped.
# A running one is restarted, to read the files put back.
put_back_units() {
  local u v enabled active now
  [ -f "$PREINSTALL/state/units" ] || return 0
  while IFS=$'\t' read -r u v; do
    if [ -z "$u" ] || [ "$v" = absent ]; then continue; fi
    case "$u" in freepanel-*) continue ;; esac
    enabled="${v%% *}"
    active="${v#* }"
    now="$(systemctl is-enabled "$u" 2>/dev/null || true)"
    case "$enabled" in
      enabled) [ "$now" = enabled ] || systemctl enable "$u" >/dev/null 2>&1 || true ;;
      disabled) [ "$now" = disabled ] || systemctl disable "$u" >/dev/null 2>&1 || true ;;
    esac
    if [ "$active" = active ]; then
      systemctl restart "$u" >/dev/null 2>&1 || printf '    %s did not start again; see systemctl status %s\n' "$u" "$u"
    elif systemctl is-active --quiet "$u" 2>/dev/null; then
      systemctl stop "$u" >/dev/null 2>&1 || true
    fi
    printf '    %s is %s and %s again\n' "$u" "$enabled" "$active"
  done <"$PREINSTALL/state/units"
}

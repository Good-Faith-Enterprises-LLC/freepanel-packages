#!/usr/bin/env bash
# Takes freePanel off this server, as root, from an unpacked release:
#   ./installer/uninstall.sh [--yes]
#
# It stops and disables freePanel's own services, then puts back what the
# installer kept before its first change (the record at
# /var/lib/freepanel-preinstall, described in install.sh):
#
#   - every system file it changed (Postfix's main.cf and master.cf,
#     dovecot.conf, Apache's, PowerDNS's, fail2ban's, ...) is put back as it
#     was, with its owner and mode; a link as it was; a file that was not
#     there is taken away;
#   - the services it set up (Apache, MariaDB, PowerDNS, Postfix, Dovecot, ...)
#     are enabled or disabled, and running or stopped, as they were;
#   - the SELinux booleans have the values they had.
#
# Whatever is replaced or taken away is moved, not deleted, to a root-only
# folder under /var/lib/freepanel-removed, and the script names each path.
# No package is removed. Homes, mailboxes, databases, the panel's own database
# and its binaries stay where they are. Not put back: group members, SELinux's
# local file and port rules, the firewall's rules; the record keeps them as
# text for whoever wants them.
#
# A server first installed before the record was kept (it says "legacy") has
# nothing to put back from: there, only Postfix's settings are taken out
# (freepanel-privd -undo-mail) and Dovecot is stopped when its settings are
# freePanel's.
set -euo pipefail

PREFIX=/usr/local/freepanel
PREINSTALL=/var/lib/freepanel-preinstall
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
REMOVED=/var/lib/freepanel-removed/$STAMP
YES=0

say() { printf '\033[1m==> %s\033[0m\n' "$*"; }
die() { printf 'uninstall: %s\n' "$*" >&2; exit 1; }

while [ $# -gt 0 ]; do
  case "$1" in
    --yes) YES=1; shift ;;
    -h|--help) sed -n '2,27p' "$0"; exit 0 ;;
    *) die "unknown option: $1" ;;
  esac
done
[ "$(id -u)" -eq 0 ] || die "run as root"
[ -d "$PREINSTALL" ] || die "no record of an install here ($PREINSTALL is missing); nothing to put back"
if [ "$YES" -ne 1 ]; then
  printf 'This stops freePanel and puts the system back as it was before freePanel. Continue? [y/N] '
  read -r answer
  case "$answer" in y|Y|yes) ;; *) die "nothing changed" ;; esac
fi

install -d -m 0700 -o root -g root /var/lib/freepanel-removed "$REMOVED"
# shellcheck source=/dev/null
. "$(dirname "${BASH_SOURCE[0]}")/restore.sh"

# The nginx front (docs/api.md, "Web server"), if it is on, is turned off first,
# before any freePanel unit is stopped: nginx stops, the drop-in that makes Apache
# need the front's guard is parked (so that stopping the guard below does not stop
# Apache), the two Apache Listen lines the front turned off are turned on as they
# were, the nginx.conf it replaced is put back from the copy the panel kept, and
# Apache is restarted onto ports 80 and 443. Only then do the units below stop,
# the guard among them: Apache is never on its loopback ports without it. This
# also runs before the kept files go back, which would otherwise be a second way
# to the same lines, and whether or not the install is a legacy one.
FRONT_MARK='# freePanel nginx front: '
FRONT_DROPIN=/etc/systemd/system/httpd.service.d/freepanel-nginx-front.conf
if grep -qs '^# Managed by freePanel\.' /etc/nginx/nginx.conf || grep -qs -F -- "$FRONT_MARK" /etc/httpd/conf/httpd.conf /etc/httpd/conf.d/ssl.conf || [ -e "$FRONT_DROPIN" ]; then
  say "Turning the nginx front off"
  systemctl disable --now --quiet nginx.service 2>/dev/null || true
  park "$FRONT_DROPIN"
  systemctl daemon-reload
  for f in /etc/httpd/conf/httpd.conf /etc/httpd/conf.d/ssl.conf; do
    if grep -qs -F -- "$FRONT_MARK" "$f"; then
      sed -i "s/^# freePanel nginx front: //" "$f"
      printf '    put back the Listen line in %s\n' "$f"
    fi
  done
  if grep -qs '^# Managed by freePanel\.' /etc/nginx/nginx.conf; then
    park /etc/nginx/nginx.conf
    if [ -f /var/lib/freepanel-privd/web/nginx/orig/nginx.conf ]; then
      install -m 0644 -o root -g root /var/lib/freepanel-privd/web/nginx/orig/nginx.conf /etc/nginx/nginx.conf
      printf '    put back /etc/nginx/nginx.conf\n'
    fi
  fi
  park /etc/nginx/conf.d/00-freepanel-front.conf
  if systemctl is-active --quiet httpd.service; then
    systemctl restart httpd.service || printf '    Apache did not restart; start it with: systemctl restart httpd\n' >&2
  fi
fi

say "Stopping freePanel's services"
# freePanel's own units, whatever the install added (the agents, the milter,
# the FTP login service, an account's apps).
mapfile -t units < <(systemctl list-unit-files 'freepanel-*' --no-legend --plain 2>/dev/null | awk '{print $1}')
for u in "${units[@]}"; do
  systemctl disable --now --quiet "$u" 2>/dev/null || systemctl stop "$u" 2>/dev/null || true
done

# Anonymous FTP: the bind mounts of accounts' folders are in Pure-FTPd's own
# mount namespace, which goes when its last process does; its anonymous
# sessions outlive the stop (KillMode=process), so they are ended. Anything
# mounted in the tree here too is unmounted, deepest first (a lazy unmount
# takes what is below too), and Pure-FTPd's links into the tree go. The
# accounts' own folders stay in their homes.
ANON_TREE=/srv/freepanel/anon-ftp
if [ -d "$ANON_TREE" ]; then
  say "Taking down anonymous FTP's folders"
  if id ftp >/dev/null 2>&1; then
    pkill -KILL -u ftp -x pure-ftpd 2>/dev/null || true
    # The cap the agent put on what anonymous uploads may hold.
    if command -v setquota >/dev/null; then
      setquota -u ftp 0 0 0 0 -a 2>/dev/null || true
    fi
  fi
  awk -v t="$ANON_TREE" '$5 == t || index($5, t "/") == 1 {print length($5) " " $5}' /proc/self/mountinfo |
    sort -rn | cut -d' ' -f2- | while IFS= read -r m; do
      umount -l -- "$m" 2>/dev/null || true
    done
  for l in /etc/pure-ftpd/* /etc/pure-ftpd/pure-ftpd/*; do
    [ -L "$l" ] || continue
    case "$(readlink -- "$l")" in "$ANON_TREE"/*) rm -f -- "$l" ;; esac
  done
fi

if [ -e "$PREINSTALL/legacy" ]; then
  say "Installed before the system files were kept: only the mail settings can be taken out"
  if command -v postconf >/dev/null && [ -x "$PREFIX/bin/freepanel-privd" ]; then
    "$PREFIX/bin/freepanel-privd" -undo-mail
  fi
  if grep -qs 'Managed by freePanel' /etc/dovecot/dovecot.conf; then
    printf '    Dovecot has freePanel'"'"'s settings and no copy of its own; stopping it\n'
    systemctl disable --now --quiet dovecot 2>/dev/null || true
  fi
else
  say "Putting back the files"
  put_back_files
  put_back_sebools
fi

# The tables and users files of the mail stack, and the units: freePanel's own,
# named after it. main.cf and dovecot.conf name none of them any more.
say "Moving freePanel's own files aside"
for f in /etc/postfix/freepanel* /etc/dovecot/freepanel-* /etc/systemd/system/freepanel-*.service; do
  park "$f"
done
if command -v restorecon >/dev/null; then
  restorecon -R /etc/postfix /etc/dovecot /etc/httpd /etc/pdns /etc/fail2ban 2>/dev/null || true
fi
systemctl daemon-reload

if [ ! -e "$PREINSTALL/legacy" ]; then
  say "Putting the services back as they were"
  put_back_units
elif command -v postconf >/dev/null; then
  systemctl try-reload-or-restart postfix 2>/dev/null || true
fi

say "freePanel is stopped. What was replaced or taken away is in $REMOVED; its data stays in /etc/freepanel, /var/lib/freepanel and the homes."

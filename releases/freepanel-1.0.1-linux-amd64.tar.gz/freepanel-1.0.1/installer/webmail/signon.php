<?php
// freePanel: signs the browser in to webmail with a sign-in the panel made
// (POST .../email/mailboxes/{address}/webmail): the mailbox's address and a
// 43-character token, which Dovecot accepts only from this server and only
// until the panel's session limit. Nothing else is accepted here, so this
// page cannot be used to try mailbox passwords. The freepanel_signon
// plugin hands the sign-in to Roundcube's own login.
declare(strict_types=1);

header('Cache-Control: no-store');

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Location: /', true, 303);
    exit;
}
require '/usr/local/freepanel/webmail/lib/ratelimit.php';
if (!freepanel_signin_allowed()) {
    freepanel_signin_refuse();
}
header('Content-Type: text/plain; charset=utf-8');
// Only the panels' own pages may post here (the installer names them), so
// another site cannot sign a visitor in to a mailbox of its choosing.
$origins = preg_split('/\s+/', (string) ($_SERVER['FREEPANEL_PANEL_ORIGINS'] ?? ''), -1, PREG_SPLIT_NO_EMPTY);
if (!in_array((string) ($_SERVER['HTTP_ORIGIN'] ?? ''), $origins, true)) {
    http_response_code(403);
    exit('Open webmail from your control panel.');
}
$address = (string) ($_POST['address'] ?? '');
$token = (string) ($_POST['token'] ?? '');
// The panel's mailbox addresses (modules/mail ParseAddress), lower case.
if (strlen($address) > 318
    || !preg_match('/^[a-z0-9_+-]+(\.[a-z0-9_+-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)+$/D', $address)
    || strlen(strstr($address, '@', true)) > 64
    || !preg_match('/^[A-Za-z0-9_-]{43}$/D', $token)) {
    http_response_code(400);
    exit('This sign-in is not valid. Open webmail from your control panel again.');
}

// Roundcube's login runs with this sign-in in place of its form's fields.
define('FREEPANEL_SIGNON_USER', $address);
define('FREEPANEL_SIGNON_PASS', $token);
unset($address, $token);
$_GET = ['_task' => 'login'];
$_POST = ['_task' => 'login', '_action' => 'login'];
$_REQUEST = $_POST;
$_COOKIE = array_intersect_key($_COOKIE, ['roundcube_sessid' => true, 'roundcube_sessauth' => true]);
// Roundcube's links and its redirect after login are to its own page.
$_SERVER['REQUEST_URI'] = '/';
$_SERVER['SCRIPT_NAME'] = $_SERVER['PHP_SELF'] = '/index.php';
$_SERVER['SCRIPT_FILENAME'] = __DIR__ . '/index.php';
header_remove('Content-Type');
require __DIR__ . '/index.php';

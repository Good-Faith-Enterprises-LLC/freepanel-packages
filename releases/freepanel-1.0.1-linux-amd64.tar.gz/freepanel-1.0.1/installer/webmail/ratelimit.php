<?php
// freePanel: limits how often one address may try to sign in to webmail
// through signon.php. The sign-ins themselves are random and end with the
// panel's sessions; this keeps the port from being used to try many of them.
declare(strict_types=1);

const FREEPANEL_SIGNIN_LIMIT = 20;    // attempts per window, per address
const FREEPANEL_SIGNIN_WINDOW = 600;  // seconds
const FREEPANEL_SIGNIN_DIR = '/var/lib/freepanel-webmail/ratelimit';

// freepanel_signin_allowed counts one attempt from this request's address
// and says whether it is within the limit. IPv6 addresses count by their
// /64, since one host usually holds a whole /64. If the count cannot be
// kept the attempt is refused.
function freepanel_signin_allowed(): bool
{
    $addr = (string) ($_SERVER['REMOTE_ADDR'] ?? '');
    $bin = @inet_pton($addr);
    if ($bin === false) {
        return false;
    }
    if (strlen($bin) === 16) {
        $bin = substr($bin, 0, 8);
    }
    $path = FREEPANEL_SIGNIN_DIR . '/' . bin2hex($bin);
    $fh = @fopen($path, 'c+');
    if ($fh === false || !flock($fh, LOCK_EX)) {
        return false;
    }
    $now = time();
    $times = [];
    foreach (explode("\n", (string) stream_get_contents($fh)) as $t) {
        if (ctype_digit($t) && (int) $t > $now - FREEPANEL_SIGNIN_WINDOW) {
            $times[] = (int) $t;
        }
    }
    $ok = count($times) < FREEPANEL_SIGNIN_LIMIT;
    if ($ok) {
        $times[] = $now;
    }
    ftruncate($fh, 0);
    rewind($fh);
    fwrite($fh, implode("\n", $times));
    fflush($fh);
    flock($fh, LOCK_UN);
    fclose($fh);
    // systemd-tmpfiles removes files a day old (the installer's rule).
    return $ok;
}

// freepanel_signin_refuse answers a request over the limit.
function freepanel_signin_refuse(): void
{
    http_response_code(429);
    header('Retry-After: ' . FREEPANEL_SIGNIN_WINDOW);
    header('Content-Type: text/plain; charset=utf-8');
    exit('Too many sign-ins from this address. Try again in a few minutes.');
}

<?php

/**
 * freePanel: completes a sign-in that signon.php checked, with the mailbox
 * address and token the panel made. Roundcube's own login form is left as
 * it is.
 *
 * It also tells the panel when the session a token opened ends: a file named
 * by the token's SHA-256 (never the token) is left in a folder only webmail's
 * pool writes, and the panel ends that sign-in within a minute, so a token
 * copied before signing out stops working.
 *
 * Copyright (c) Good Faith Enterprises LLC. All rights reserved.
 * Proprietary; see LICENSE.
 */
class freepanel_signon extends rcube_plugin
{
    /** The panel's tokens: 32 random bytes, base64url. */
    private const TOKEN = '/^[A-Za-z0-9_-]{43}$/D';

    /** Hash of the token the sign-in being made came with, if it was one. */
    private $hash = null;

    #[\Override]
    public function init()
    {
        $this->add_hook('authenticate', [$this, 'authenticate']);
        $this->add_hook('login_after', [$this, 'login_after']);
        $this->add_hook('session_destroy', [$this, 'session_destroy']);
    }

    /**
     * 'authenticate' hook handler.
     *
     * @param array $args Hook arguments
     *
     * @return array Hook arguments
     */
    public function authenticate($args)
    {
        // Defined only by signon.php, after its own checks.
        if (defined('FREEPANEL_SIGNON_USER') && defined('FREEPANEL_SIGNON_PASS')) {
            // A session the browser already has, perhaps another mailbox's,
            // ends first.
            rcmail::get_instance()->kill_session();
            $args['user'] = FREEPANEL_SIGNON_USER;
            $args['pass'] = FREEPANEL_SIGNON_PASS;
            // signon.php checked where the request came from; the browser may
            // hold no Roundcube cookie yet.
            $args['valid'] = true;
            $args['cookiecheck'] = false;
        }
        // A token typed into the login form is the same secret, so it is
        // noted the same way.
        $this->hash = self::hash_of((string) ($args['pass'] ?? ''));

        return $args;
    }

    /**
     * The hash of a token; null for anything else. Only what has a token's
     * shape is hashed: no other password ever is here.
     *
     * @param string $pass A password
     *
     * @return string|null
     */
    private static function hash_of($pass)
    {
        return preg_match(self::TOKEN, $pass) ? hash('sha256', $pass) : null;
    }

    /**
     * 'login_after' hook handler: the sign-in worked, so its session
     * remembers which token opened it.
     *
     * @param array $args Hook arguments
     *
     * @return array Hook arguments
     */
    public function login_after($args)
    {
        if ($this->hash !== null) {
            $_SESSION['freepanel_signon'] = $this->hash;
        }

        return $args;
    }

    /**
     * 'session_destroy' hook handler: signing out tells the panel which
     * sign-in it was. A session that merely lapses runs no hook, so its
     * token lasts to its own expiry.
     *
     * @param array $args Hook arguments
     *
     * @return array Hook arguments
     */
    public function session_destroy($args)
    {
        $hash = $_SESSION['freepanel_signon'] ?? null;
        $dir = (string) rcmail::get_instance()->config->get('freepanel_signouts', '');
        // The sign-in being made in this very request may use the token the
        // session being replaced was opened with (a form posted twice): that
        // one is not over.
        $next = self::hash_of(defined('FREEPANEL_SIGNON_PASS') ? (string) FREEPANEL_SIGNON_PASS : (string) ($_POST['_pass'] ?? ''));
        if ($dir !== '' && is_string($hash) && $hash !== $next && preg_match('/^[0-9a-f]{64}$/D', $hash)) {
            // Only the name matters; the panel never opens the file.
            @touch($dir . '/' . $hash);
        }

        return $args;
    }
}

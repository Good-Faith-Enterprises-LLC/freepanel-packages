<?php
// freePanel: signs the browser in to the database admin tool with a
// sign-in the panel made (POST .../mysql/signin or .../postgres/signin).
// Sign-ins are temporary database users named ACCOUNT_fpa<8 hex> with a
// 40-hex-digit password; nothing else is accepted here, so this page
// cannot be used to try other users' passwords.
declare(strict_types=1);

header('Cache-Control: no-store');
header('Content-Type: text/html; charset=utf-8');

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    readfile(__DIR__ . '/index.html');
    exit;
}
require '/usr/local/freepanel/dbadmin/lib/ratelimit.php';
if (!freepanel_signin_allowed()) {
    freepanel_signin_refuse();
}
// Only the panels' own pages may post here (the installer names them), so
// another site cannot sign a visitor in to a database of its choosing.
$origins = preg_split('/\s+/', (string) ($_SERVER['FREEPANEL_PANEL_ORIGINS'] ?? ''), -1, PREG_SPLIT_NO_EMPTY);
if (!in_array((string) ($_SERVER['HTTP_ORIGIN'] ?? ''), $origins, true)) {
    http_response_code(403);
    exit('Open the database admin tool from your control panel.');
}
$engine = (string) ($_POST['engine'] ?? '');
$user = (string) ($_POST['user'] ?? '');
$password = (string) ($_POST['password'] ?? '');
if (!preg_match('/^[a-z][a-z0-9]{0,15}_fpa[0-9a-f]{8}$/D', $user)
    || !preg_match('/^[0-9a-f]{40}$/D', $password)) {
    http_response_code(400);
    exit('This sign-in is not valid. Open the database admin tool from your control panel again.');
}

if ($engine === 'mysql') {
    // phpMyAdmin's "signon" authentication reads these from this session.
    session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'secure' => true, 'httponly' => true, 'samesite' => 'Lax']);
    session_name('FreePanelSignon');
    session_start();
    session_regenerate_id(true);
    $_SESSION['PMA_single_signon_user'] = $user;
    $_SESSION['PMA_single_signon_password'] = $password;
    session_write_close();
    header('Location: /mysql/index.php', true, 303);
    exit;
}

if ($engine === 'pgsql') {
    // Adminer signs in from its own login form's fields; the server and the
    // driver are fixed by pgsql/index.php whatever is sent.
    $h = static fn (string $s): string => htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
    header("Content-Security-Policy: default-src 'none'; form-action 'self'; script-src 'sha256-" .
        base64_encode(hash('sha256', 'document.forms[0].submit();', true)) . "'");
    echo '<!doctype html><title>Signing in</title><form method="post" action="/pgsql/index.php?pgsql=localhost&amp;username=', $h($user), '">',
        '<input type="hidden" name="auth[driver]" value="pgsql">',
        '<input type="hidden" name="auth[server]" value="localhost">',
        '<input type="hidden" name="auth[username]" value="', $h($user), '">',
        '<input type="hidden" name="auth[password]" value="', $h($password), '">',
        '<input type="hidden" name="auth[db]" value="">',
        '<noscript><button>Continue</button></noscript></form>',
        '<script>document.forms[0].submit();</script>';
    exit;
}

http_response_code(400);
exit('Unknown database engine.');

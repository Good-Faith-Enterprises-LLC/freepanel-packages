<?php
// freePanel: Adminer for PostgreSQL, limited to this server's PostgreSQL
// and to the panel's temporary sign-ins (see ../signon.php). Written for
// Adminer 6.1. Parameters are untyped: the release build drops the source's
// parameter types, and an override may not add them.
declare(strict_types=1);

require '/usr/local/freepanel/dbadmin/lib/ratelimit.php';

const FREEPANEL_SIGNIN_USER = '/^[a-z][a-z0-9]{0,15}_fpa[0-9a-f]{8}$/D';
const FREEPANEL_SIGNIN_PASSWORD = '/^[0-9a-f]{40}$/D';

// Always PostgreSQL on this server, whatever driver or server the request
// names: Adminer picks its driver from the query string, so every other
// driver's key is dropped and pgsql is set.
foreach (['server', 'sqlite', 'mssql', 'oracle', 'elastic', 'mongo', 'clickhouse', 'firebird', 'simpledb', 'imap'] as $k) {
    unset($_GET[$k]);
}
$_GET['pgsql'] = 'localhost';

// A sign-in, from signon.php or Adminer's own form: counted against the
// address's limit, and only the panel's sign-ins get as far as Adminer.
if (isset($_POST['auth'])) {
    if (!freepanel_signin_allowed()) {
        freepanel_signin_refuse();
    }
    $auth = $_POST['auth'];
    if (!is_array($auth)
        || !preg_match(FREEPANEL_SIGNIN_USER, (string) ($auth['username'] ?? ''))
        || !preg_match(FREEPANEL_SIGNIN_PASSWORD, (string) ($auth['password'] ?? ''))) {
        http_response_code(400);
        header('Content-Type: text/plain; charset=utf-8');
        exit('This sign-in is not valid. Open the database admin tool from your control panel again.');
    }
    $_POST['auth'] = [
        'driver' => 'pgsql',
        'server' => 'localhost',
        'username' => $auth['username'],
        'password' => $auth['password'],
        'db' => is_string($auth['db'] ?? null) ? $auth['db'] : '',
    ];
    unset($auth);
}

function adminer_object()
{
    class FreePanelAdminer extends Adminer\Adminer
    {
        public function name(): string
        {
            return 'Database admin';
        }

        // Always this server's PostgreSQL.
        public function credentials(): array
        {
            return ['localhost', (string) ($_GET['username'] ?? ''), Adminer\get_password()];
        }

        // signon.php's form carries no Adminer token. A form from this
        // origin is let through without one; a cross-site form never is.
        public function verifyLoginToken(): bool
        {
            return ($_SERVER['HTTP_SEC_FETCH_SITE'] ?? '') !== 'same-origin';
        }

        // No remembered sign-ins: each one lasts an hour anyway.
        public function permanentLogin($create = false): string
        {
            return '';
        }

        // Only PostgreSQL, and only the panel's sign-ins.
        public function login($login, $password)
        {
            if (Adminer\DRIVER !== 'pgsql' || !preg_match(FREEPANEL_SIGNIN_USER, (string) $login)
                || !preg_match(FREEPANEL_SIGNIN_PASSWORD, (string) $password)) {
                return 'Open the database admin tool from your control panel.';
            }
            return parent::login($login, $password);
        }

        // Instead of a login form, a pointer back to the panel.
        public function loginForm(): void
        {
            echo '<p>Open the database admin tool from your control panel.</p>', "\n";
        }

        // PostgreSQL lets any role list every database's name; show only
        // the account's own.
        public function databases($flush = true): array
        {
            $user = (string) ($_GET['username'] ?? '');
            $prefix = substr($user, 0, (int) strrpos($user, '_fpa') + 1);
            if ($prefix === '' || $prefix === '_') {
                return [];
            }
            return array_values(array_filter(parent::databases($flush),
                static fn ($db): bool => str_starts_with((string) $db, $prefix)));
        }
    }
    return new FreePanelAdminer();
}

// Adminer itself is outside the web folder (the installer's lib/adminer).
require '/usr/local/freepanel/dbadmin/lib/adminer/adminer.php';

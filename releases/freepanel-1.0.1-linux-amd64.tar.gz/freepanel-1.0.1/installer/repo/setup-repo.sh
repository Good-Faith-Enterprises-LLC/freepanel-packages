#!/bin/bash
# Points dnf at freePanel's package repository, trusting only the key with
# the pinned fingerprint, or takes the repository away from this server.
#
#   setup-repo.sh KEYFILE FINGERPRINT BASEURL
#   setup-repo.sh --withdraw FINGERPRINT
#
# KEYFILE is the public key shipped with the release, FINGERPRINT the one
# the installer pins, BASEURL the repository (https://, or file:// for a
# test). The key is refused unless it is exactly one key with that
# fingerprint. Packages and the repository metadata must both be signed by
# it (gpgcheck and repo_gpgcheck). When the shipped key differs from the one
# installed (a new or revoked signing subkey), rpm's and dnf's copies are
# replaced, so a retired subkey stops counting at once.
#
# --withdraw, for an incident: the repository file and the key are moved
# aside, and rpm and dnf stop trusting the key. Run as root.
set -euo pipefail

usage="usage: setup-repo.sh KEYFILE FINGERPRINT BASEURL | --withdraw FINGERPRINT"
[ "$(id -u)" -eq 0 ] || { echo "run as root" >&2; exit 1; }
REPO=/etc/yum.repos.d/freepanel.repo
KEY=/etc/pki/rpm-gpg/RPM-GPG-KEY-freepanel

fingerprint() {
    local f
    f=$(printf '%s' "$1" | tr 'a-f' 'A-F')
    case "$f" in
        *[!0-9A-F]*|"") echo "the fingerprint must be hex" >&2; exit 1 ;;
    esac
    [ "${#f}" -eq 40 ] || [ "${#f}" -eq 64 ] || { echo "the fingerprint must be a full fingerprint" >&2; exit 1; }
    printf '%s' "$f"
}

# untrust drops the key from rpm's database (every copy) and moves dnf's
# cached copies of the repository's keyring aside, so the next dnf run
# imports the key as shipped. rpm names a key by the last 8 hex digits of
# its key ID, which are the fingerprint's.
untrust() {
    local id stamp d
    id=$(printf '%s' "${1: -8}" | tr 'A-F' 'a-f')
    if rpm -q "gpg-pubkey-$id" >/dev/null 2>&1; then
        rpm -e --allmatches "gpg-pubkey-$id"
    fi
    stamp=$(date +%Y%m%d%H%M%S)
    for d in /var/cache/dnf/freepanel-*/pubring /var/lib/dnf/repos/freepanel-*/pubring; do
        [ -d "$d" ] || continue
        mv "$d" "$d.retired-$stamp"
    done
}

if [ "${1:-}" = --withdraw ]; then
    FPR=$(fingerprint "${2:?$usage}")
    stamp=$(date +%Y%m%d%H%M%S)
    for f in "$REPO" "$KEY"; do
        [ -e "$f" ] && mv "$f" "$f.withdrawn-$stamp"
    done
    untrust "$FPR"
    echo "freePanel's package repository is withdrawn from this server; dnf no longer uses it or trusts $FPR"
    exit 0
fi

KEYFILE=${1:?$usage}
FPR=$(fingerprint "${2:?$usage}")
URL=${3:?$usage}
case "$URL" in
    https://*|file:///*) ;;
    *) echo "the repository must be https:// (or file:// for a test)" >&2; exit 1 ;;
esac
case "$URL" in
    *[[:space:]]*|*\$*|*\\*) echo "the repository URL has characters dnf would read as syntax" >&2; exit 1 ;;
esac

# Exactly one primary key, with the pinned fingerprint. gpg looks at it in
# a folder of its own, so root's keyring is left as it is.
gh=$(mktemp -d)
trap 'rm -rf "$gh"' EXIT
keys=$(GNUPGHOME=$gh gpg --batch --with-colons --import-options show-only --import "$KEYFILE" 2>/dev/null \
    | awk -F: '$1=="pub"{p=1} $1=="fpr" && p {print $10; p=0}')
if [ "$(printf '%s\n' "$keys" | grep -c .)" -ne 1 ] || [ "$keys" != "$FPR" ]; then
    echo "$KEYFILE is not the key with fingerprint $FPR (it holds: ${keys:-nothing})" >&2
    exit 1
fi

if ! cmp -s "$KEYFILE" "$KEY" 2>/dev/null; then
    untrust "$FPR"
fi
install -D -m 0644 -o root -g root "$KEYFILE" "$KEY.tmp"
mv "$KEY.tmp" "$KEY"
umask 022
cat > "$REPO.tmp" <<REPO
# Managed by freePanel.
[freepanel]
name=freePanel
baseurl=${URL%/}/el9/\$basearch
enabled=1
gpgcheck=1
repo_gpgcheck=1
gpgkey=file://$KEY
REPO
chmod 0644 "$REPO.tmp"
mv "$REPO.tmp" "$REPO"
id=$(printf '%s' "${FPR: -8}" | tr 'A-F' 'a-f')
rpm -q "gpg-pubkey-$id" >/dev/null 2>&1 || rpmkeys --import "$KEY"
echo "dnf now uses $URL, signed by $FPR"

# shellcheck shell=bash
# The helpers that keep what the installer changes as it was before
# freePanel's first change, in the record at $PREINSTALL (described in
# install.sh, which sources this file). test/installer sources it too, with
# $PREINSTALL in a folder of its own.
: "${PREINSTALL:?}"
# listed LIST KEY: whether $PREINSTALL/LIST has a line whose first
# tab-separated field is KEY.
listed() {
  [ -f "$PREINSTALL/$1" ] && awk -F '\t' -v k="$2" '$1 == k { f = 1 } END { exit !f }' "$PREINSTALL/$1"
}
# keep_original FILE...: keeps each FILE as it is now, unless one is kept.
# Only a regular file with no link on the way to it is copied, as root's
# own; the owner and mode it had are kept in state/files. A link is listed
# in links with its target, a file that isn't there in absent, and anything
# else in other.
keep_original() {
  local f dest dir target
  [ -e "$PREINSTALL/legacy" ] && return 0
  for f in "$@"; do
    dest="$PREINSTALL/files$f"
    if [ -e "$dest" ] || listed absent "$f" || listed links "$f" || listed other "$f"; then continue; fi
    dir="$(dirname -- "$f")"
    # A link is tested first, since -f and -e follow it.
    if [ -L "$f" ]; then
      # The sentinel keeps a newline at the end of the target, which $()
      # would drop; readlink adds one of its own after it.
      target="$(readlink -- "$f"; printf x)"
      target="${target%x}"
      target="${target%$'\n'}"
      case "$target" in
        # The list is a line for each link and a tab between its fields.
        *$'\n'*|*$'\t'*) printf '%s\n' "$f" >>"$PREINSTALL/other" ;;
        *) printf '%s\t%s\n' "$f" "$target" >>"$PREINSTALL/links" ;;
      esac
    elif [ -f "$f" ]; then
      # Not through a link above it either: whoever owns that folder would
      # choose what is kept.
      if [ "$(readlink -f -- "$dir")" != "$dir" ]; then
        printf '%s\n' "$f" >>"$PREINSTALL/other"
        continue
      fi
      # The original owner and mode first, so a copy is never without them.
      keep_state files "$f" "$(stat -c '%u:%g %a %U:%G' -- "$f")"
      # Every folder it makes is root 0700, not just the last.
      (umask 077 && mkdir -p "$(dirname "$dest")")
      cp -P -p -- "$f" "$dest.new"
      chown root:root "$dest.new"
      mv "$dest.new" "$dest"
    elif [ -e "$f" ]; then
      printf '%s\n' "$f" >>"$PREINSTALL/other"
    else
      printf '%s\n' "$f" >>"$PREINSTALL/absent"
    fi
  done
}
# keep_postconf: keeps postconf -n, -M and -P, unless kept.
keep_postconf() {
  local o
  [ -e "$PREINSTALL/legacy" ] && return 0
  for o in n M P; do
    if [ ! -e "$PREINSTALL/postconf-$o" ]; then
      postconf "-$o" >"$PREINSTALL/postconf-$o.new"
      mv "$PREINSTALL/postconf-$o.new" "$PREINSTALL/postconf-$o"
    fi
  done
}
# keep_state LIST KEY VALUE: adds "KEY<tab>VALUE" to $PREINSTALL/state/LIST
# unless KEY is there.
keep_state() {
  [ -e "$PREINSTALL/legacy" ] && return 0
  (umask 077 && mkdir -p "$PREINSTALL/state")
  listed "state/$1" "$2" && return 0
  printf '%s\t%s\n' "$2" "$3" >>"$PREINSTALL/state/$1"
}
# keep_state_once NAME COMMAND...: keeps COMMAND's output as
# $PREINSTALL/state/NAME, unless kept: "absent" when COMMAND isn't
# installed, and a first line "failed" before what it said when it fails,
# so an error message is never read as the state.
keep_state_once() {
  local name="$1" dest
  shift
  [ -e "$PREINSTALL/legacy" ] && return 0
  dest="$PREINSTALL/state/$name"
  [ -e "$dest" ] && return 0
  (umask 077 && mkdir -p "$PREINSTALL/state")
  if ! command -v "$1" >/dev/null; then
    printf 'absent\n' >"$dest.new"
  elif ! "$@" >"$dest.new" 2>&1; then
    { printf 'failed\n'; cat -- "$dest.new"; } >"$dest.failed"
    mv "$dest.failed" "$dest.new"
  fi
  mv "$dest.new" "$dest"
}
# keep_units UNIT...: keeps each unit's enabled and active state, or
# absent.
keep_units() {
  local u
  for u in "$@"; do
    if [ "$(systemctl show -p LoadState --value "$u" 2>/dev/null || echo not-found)" = not-found ]; then
      keep_state units "$u" absent
    else
      keep_state units "$u" "$(systemctl is-enabled "$u" 2>/dev/null || true) $(systemctl is-active "$u" 2>/dev/null || true)"
    fi
  done
}
# keep_group GROUP: keeps GROUP's members, or absent.
keep_group() {
  local g
  if g="$(getent group "$1")"; then
    keep_state groups "$1" "members=${g##*:}"
  else
    keep_state groups "$1" absent
  fi
}
# keep_sebools BOOL...: keeps each SELinux boolean's value, or absent.
keep_sebools() {
  local b v
  for b in "$@"; do
    if command -v getsebool >/dev/null && v="$(getsebool "$b" 2>/dev/null)"; then
      keep_state sebool "$b" "${v##* }"
    else
      keep_state sebool "$b" absent
    fi
  done
}
# keep_selinux_local: keeps SELinux's local file-context and port rules.
keep_selinux_local() {
  keep_state_once selinux-fcontext-local semanage fcontext -l -C
  keep_state_once selinux-port-local semanage port -l -C
}

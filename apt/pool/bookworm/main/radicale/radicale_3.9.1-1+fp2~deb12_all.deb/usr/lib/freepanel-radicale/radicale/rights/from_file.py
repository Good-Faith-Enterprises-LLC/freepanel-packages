# This file is part of Radicale - CalDAV and CardDAV server
# Copyright © 2012-2017 Guillaume Ayoub
# Copyright © 2017-2021 Unrud <unrud@outlook.com>
# Copyright © 2024-2026 Peter Bieringer <pb@bieringer.de>
#
# This library is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Radicale.  If not, see <http://www.gnu.org/licenses/>.

"""
Rights backend based on a regex-based file whose name is specified in the
config (section "rights", key "file").

The login is matched against the "user" key, and the collection path
is matched against the "collection" key. In the "collection" regex you can use
`{user}` and get groups from the "user" regex with `{0}`, `{1}`, etc.
In consequence of the parameter substitution you have to write `{{` and `}}`
if you want to use regular curly braces in the "user" and "collection" regexes.

For example, for the "user" key, ".+" means "authenticated user" and ".*"
means "anybody" (including anonymous users).

Section names are only used for naming the rule.

Leading or ending slashes are trimmed from collection's path.

"""

import configparser
import re
from typing import Union

from radicale import config, pathutils, rights
from radicale.log import logger


class Rights(rights.BaseRights):

    _filename: str
    _rights_config: dict

    def __init__(self, configuration: config.Configuration) -> None:
        super().__init__(configuration)
        self._filename = configuration.get("rights", "file")
        self._log_rights_rule_doesnt_match_on_debug = configuration.get("logging", "rights_rule_doesnt_match_on_debug")
        rights_config_parser = configparser.ConfigParser()
        try:
            with open(self._filename, "r") as f:
                rights_config_parser.read_file(f)
            logger.debug("Read rights file")
        except Exception as e:
            raise RuntimeError("Failed to load rights file %r: %s" %
                               (self._filename, e)) from e

        # Pre-load rights (ConfigParser is slow)
        self._rights_config = {}
        for section in rights_config_parser.sections():
            try:
                user_pattern = rights_config_parser.get(section, "user", fallback="")
                collection_pattern = rights_config_parser.get(section, "collection")
                allowed_groups = rights_config_parser.get(section, "groups", fallback="").split(",")
                permission = rights_config_parser.get(section, "permissions")
                error: Union[str, None] = None
                # test for conflicting permissions
                if "d" in permission and "D" in permission:
                    error = "conflicting 'd' + 'D'"
                if "o" in permission and "O" in permission:
                    error = "conflicting 'o' + 'O'"
                if "p" in permission and "P" in permission:
                    error = "conflicting 'p' + 'P'"
                if "e" in permission and "E" in permission:
                    error = "conflicting 'e' + 'E'"
                if "m" in permission and "M" in permission:
                    error = "conflicting 'm' + 'M'"
                if "S" in permission and "M" in permission:
                    error = "conflicting 'S' + 'M'"
                if "S" in permission and "m" in permission:
                    error = "conflicting 'S' + 'm'"
                if "t" in permission and "T" in permission:
                    error = "conflicting 't' + 'T'"
                # test for server-side flag permissions
                if "u" in permission:
                    error = "unsupported 'u'"
                if "U" in permission:
                    error = "unsupported 'U'"
                if error is not None:
                    raise RuntimeError("%s permission found in section %r: %r" % (error, section, permission))
                self._rights_config[section] = {"user_pattern": user_pattern, "collection_pattern": collection_pattern,
                                                "allowed_groups": allowed_groups, "permission": permission}
            except Exception as e:
                raise RuntimeError("Error in section %r of rights file %r: "
                                   "%s" % (section, self._filename, e)) from e

    def authorization(self, user: str, user_groups: set, path: str) -> str:
        user = user or ""
        sane_path = pathutils.strip_path(path)
        # Prevent "regex injection"
        escaped_user = re.escape(user)
        if not self._log_rights_rule_doesnt_match_on_debug:
            logger.debug("logging of rules which doesn't match suppressed by config/option [logging] rights_rule_doesnt_match_on_debug")
        for section, rules in self._rights_config.items():
            group_match = None
            user_match = None
            try:
                user_pattern = rules["user_pattern"]
                collection_pattern = rules["collection_pattern"]
                allowed_groups = rules["allowed_groups"]
                logger.trace("user_groups=%r allowed_groups=%r", user_groups, allowed_groups)
                try:
                    group_match = len(user_groups.intersection(allowed_groups)) > 0
                except Exception:
                    pass
                # Use empty format() for harmonized handling of curly braces
                if user_pattern != "":
                    user_match = re.fullmatch(user_pattern.format(), user)
                user_collection_match = user_match and re.fullmatch(
                    collection_pattern.format(
                        *(re.escape(s) for s in user_match.groups()),
                        user=escaped_user), sane_path)
                group_collection_match = group_match and re.fullmatch(
                    collection_pattern.format(user=escaped_user), sane_path)
            except Exception as e:
                raise RuntimeError("Error in section %r of rights file %r: "
                                   "%s" % (section, self._filename, e)) from e
            if user_match and user_collection_match:
                permission = rules["permission"]
                logger.debug("Rule %r:%r matches %r:%r from section %r permission %r",
                             user, sane_path, user_pattern,
                             collection_pattern, section, permission)
                return permission
            if group_match and group_collection_match:
                permission = rules["permission"]
                logger.debug("Rule %r:%r matches %r:%r from section %r permission %r by group membership",
                             user, sane_path, user_pattern,
                             collection_pattern, section, permission)
                return permission
            if self._log_rights_rule_doesnt_match_on_debug:
                logger.debug("Rule %r:%r doesn't match %r:%r from section %r",
                             user, sane_path, user_pattern, collection_pattern,
                             section)
        logger.debug("Rights: %r:%r doesn't match any section", user, sane_path)
        return ""

# This file is part of Radicale - CalDAV and CardDAV server
# Copyright © 2008 Nicolas Kandel
# Copyright © 2008 Pascal Halter
# Copyright © 2008-2017 Guillaume Ayoub
# Copyright © 2017-2021 Unrud <unrud@outlook.com>
# Copyright © 2024-2026 Peter Bieringer <pb@bieringer.de>
#
# This library is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Radicale.  If not, see <http://www.gnu.org/licenses/>.

import errno
import re
import socket
from http import client

import radicale.item as radicale_item
from radicale import httputils, pathutils, storage, types, xmlutils
from radicale.app.base import ApplicationBase
from radicale.log import logger


class ApplicationPartMkcalendar(ApplicationBase):

    def do_MKCALENDAR(self, environ: types.WSGIEnviron, base_prefix: str,
                      path: str, user: str, user_groups: set, request_info: dict) -> types.WSGIResponse:
        """Manage MKCALENDAR request."""
        actor = user
        if "w" not in self._rights.authorization(user, user_groups, path):
            return httputils.NOT_ALLOWED
        try:
            xml_content = self._read_xml_request_body(environ, request_info)
        except RuntimeError as e:
            logger.warning(
                "Bad MKCALENDAR request on %r: %s", path, e, exc_info=True)
            return httputils.BAD_REQUEST
        except socket.timeout:
            logger.debug("Client timed out", exc_info=True)
            return httputils.REQUEST_TIMEOUT
        # Prepare before locking
        props_with_remove = xmlutils.props_from_request(xml_content)
        props_with_remove["tag"] = "VCALENDAR"
        try:
            props = radicale_item.check_and_sanitize_props(props_with_remove)
        except ValueError as e:
            logger.warning(
                "Bad MKCALENDAR request on %r: %s", path, e, exc_info=True)
            return httputils.BAD_REQUEST
        if self._sharing._enabled:
            # check for shared collections (all)
            collections_share_list = self._sharing.sharing_collection_list(User=user, user_groups=user_groups)
            if collections_share_list:
                for share in collections_share_list:
                    if share['PathOrToken'] == path:
                        return httputils.CONFLICT
        # TODO: use this?
        # timezone = props.get("C:calendar-timezone")
        with self._storage.acquire_lock("w", user, path=path, request="MKCALENDAR", actor=actor):
            item = next(iter(self._storage.discover(path)), None)
            if item:
                return self._webdav_error_response(
                    client.CONFLICT, "D:resource-must-be-null", request_info)
            parent_path = pathutils.parent_path(path)
            parent_item = next(iter(self._storage.discover(parent_path)), None)
            if not parent_item:
                logger.error("Failed MKCALENDAR request on %r: parent folder is not existing %r", path, parent_path)
                return httputils.CONFLICT
            if (not isinstance(parent_item, storage.BaseCollection) or
                    parent_item.tag):
                return httputils.FORBIDDEN
            try:
                self._storage.create_collection(path, props=props)
            except ValueError as e:
                # return better matching HTTP result in case errno is provided and catched
                errno_match = re.search("\\[Errno ([0-9]+)\\]", str(e))
                if errno_match:
                    logger.error(
                        "Failed MKCALENDAR request on %r: %s", path, e, exc_info=True)
                    errno_e = int(errno_match.group(1))
                    if errno_e == errno.ENOSPC:
                        return httputils.INSUFFICIENT_STORAGE
                    elif errno_e in [errno.EPERM, errno.EACCES]:
                        return httputils.FORBIDDEN
                    else:
                        return httputils.INTERNAL_SERVER_ERROR
                elif type(e) is pathutils.CollidingPathError:
                    return httputils.CONFLICT
                else:
                    logger.warning(
                        "Bad MKCALENDAR request on %r: %s", path, e, exc_info=True)
                    return httputils.BAD_REQUEST
            return client.CREATED, {}, None, xmlutils.pretty_xml(xml_content)

# This file is related to Radicale - CalDAV and CardDAV server
# for email notifications
# Copyright © 2025-2025 Nate Harris
# Copyright © 2026-2026 Peter Bieringer <pb@bieringer.de>
#
# This library is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with Radicale.  If not, see <http://www.gnu.org/licenses/>.

import enum
import hashlib
import json
import re
import smtplib
import ssl
from datetime import date, datetime, timedelta
from email.encoders import encode_base64
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import formatdate
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

import vobject

from radicale.hook import (BaseHook, HookNotificationItem,
                           HookNotificationItemTypes)
from radicale.hook.email.scheduling import (PlannedMessage, build_itip_ics,
                                            build_itip_message,
                                            check_ownership, parse_event,
                                            parse_owner_map, plan_messages,
                                            resolve_owner_identities)
from radicale.log import logger

PLUGIN_CONFIG_SCHEMA = {
    "hook": {
        "smtp_server": {
            "value": "",
            "type": str
        },
        "smtp_port": {
            "value": "",
            "type": str
        },
        "smtp_security": {
            "value": "none",
            "type": str,
        },
        "smtp_ssl_verify_mode": {
            "value": "REQUIRED",
            "type": str,
        },
        "smtp_username": {
            "value": "",
            "type": str
        },
        "smtp_password": {
            "value": "",
            "type": str
        },
        "smtp_password_file": {
            "value": "",
            "type": str
        },
        "from_email": {
            "value": "",
            "type": str
        },
        "new_or_added_to_event_template": {
            "value": """Hello $attendee_name,

You have been added as an attendee to the following calendar event.

    $event_title
    $event_start_time - $event_end_time
    $event_location

This is an automated message. Please do not reply.""",
            "type": str
        },
        "deleted_or_removed_from_event_template": {
            "value": """Hello $attendee_name,

The following event has been deleted.

    $event_title
    $event_start_time - $event_end_time
    $event_location

This is an automated message. Please do not reply.""",
            "type": str
        },
        "updated_event_template": {
            "value": """Hello $attendee_name,

The following event has been updated.

    $event_title
    $event_start_time - $event_end_time
    $event_location

This is an automated message. Please do not reply.""",
            "type": str
        },
        "mass_email": {
            "value": False,
            "type": bool,
        },
        "itip_enabled": {
            "value": False,
            "type": bool,
        },
        "itip_owner_map": {
            "value": "",
            "type": str,
        },
        "itip_organizer_is_username": {
            "value": False,
            "type": bool,
        }
    }
}

MESSAGE_TEMPLATE_VARIABLES = [
    "organizer_name",
    "from_email",
    "attendee_name",
    "event_title",
    "event_start_time",
    "event_end_time",
    "event_location",
]


class SMTP_SECURITY_TYPE_ENUM(enum.Enum):
    EMPTY = ""
    NONE = "none"
    STARTTLS = "starttls"
    TLS = "tls"

    @classmethod
    def from_string(cls, value):
        """Convert a string to the corresponding enum value."""
        for member in cls:
            if member.value == value:
                return member
        raise ValueError(f"Invalid security type: {value}. Allowed values are: {[m.value for m in cls]}")


class SMTP_SSL_VERIFY_MODE_ENUM(enum.Enum):
    EMPTY = ""
    NONE = "NONE"
    OPTIONAL = "OPTIONAL"
    REQUIRED = "REQUIRED"

    @classmethod
    def from_string(cls, value):
        """Convert a string to the corresponding enum value."""
        for member in cls:
            if member.value == value:
                return member
        raise ValueError(f"Invalid SSL verify mode: {value}. Allowed values are: {[m.value for m in cls]}")


SMTP_SECURITY_TYPES: Sequence[str] = (SMTP_SECURITY_TYPE_ENUM.NONE.value,
                                      SMTP_SECURITY_TYPE_ENUM.STARTTLS.value,
                                      SMTP_SECURITY_TYPE_ENUM.TLS.value)
SMTP_SSL_VERIFY_MODES: Sequence[str] = (SMTP_SSL_VERIFY_MODE_ENUM.NONE.value,
                                        SMTP_SSL_VERIFY_MODE_ENUM.OPTIONAL.value,
                                        SMTP_SSL_VERIFY_MODE_ENUM.REQUIRED.value)


def read_ics_event(contents: str) -> Optional['Event']:
    """
    Read the vobject item from the provided string and create an Event.
    """
    v_cal: vobject.base.Component = vobject.readOne(contents)
    cal: Calendar = Calendar(vobject_item=v_cal)
    return cal.event if cal.event else None


def ics_contents_contains_event(contents: str):
    """
    Check if the ICS contents contain an event (versus a VADDRESSBOOK, VTODO or VJOURNAL).
    :param contents: The contents of the ICS file.
    :return: True if the ICS file contains an event, False otherwise.
    """
    return read_ics_event(contents) is not None


def extract_email(value: str) -> Optional[str]:
    """Extract email address from a string."""
    if not value:
        return None
    value = value.strip().lower()
    match = re.search(r"mailto:([^;]+)", value)
    if match:
        return match.group(1)
    # Fallback to the whole value if no mailto found
    return value if "@" in value else None


def determine_added_removed_and_unaltered_attendees(original_event: 'Event',
                                                    new_event: 'Event') -> (
        Tuple)[List['Attendee'], List['Attendee'], List['Attendee']]:
    """
    Determine the added, removed and unaltered attendees between two events.
    """
    original_event_attendees = {attendee.email: attendee for attendee in original_event.attendees}
    new_event_attendees = {attendee.email: attendee for attendee in new_event.attendees}
    # Added attendees are those who are in the new event but not in the original event
    added_attendees = [new_event_attendees[email] for email in new_event_attendees if
                       email not in original_event_attendees]
    # Removed attendees are those who are in the original event but not in the new event
    removed_attendees = [original_event_attendees[email] for email in original_event_attendees if
                         email not in new_event_attendees]
    # Unaltered attendees are those who are in both events
    unaltered_attendees = [original_event_attendees[email] for email in original_event_attendees if
                           email in new_event_attendees]

    return added_attendees, removed_attendees, unaltered_attendees


def event_details_other_than_attendees_changed(original_event: 'Event',
                                               new_event: 'Event') -> bool:
    """
    Check if any details other than attendees and IDs have changed between two events.
    """

    def hash_dict(d: Dict[str, Any]) -> str:
        """
        Create a hash of the dictionary to compare contents.
        This will ignore None values and empty strings.
        """
        return hashlib.sha1(json.dumps(d).encode("utf8")).hexdigest()

    original_event_details = {
        "summary": original_event.summary,
        "description": original_event.description,
        "location": original_event.location,
        "datetime_start": original_event.datetime_start.time_string() if original_event.datetime_start else None,
        "datetime_end": original_event.datetime_end.time_string() if original_event.datetime_end else None,
        "duration": original_event.duration,
        "status": original_event.status,
        "organizer": original_event.organizer
    }
    new_event_details = {
        "summary": new_event.summary,
        "description": new_event.description,
        "location": new_event.location,
        "datetime_start": new_event.datetime_start.time_string() if new_event.datetime_start else None,
        "datetime_end": new_event.datetime_end.time_string() if new_event.datetime_end else None,
        "duration": new_event.duration,
        "status": new_event.status,
        "organizer": new_event.organizer
    }

    return hash_dict(original_event_details) != hash_dict(new_event_details)


class ContentLine:
    _key: str
    value: Any
    _params: Dict[str, Any]

    def __init__(self, key: str, value: Any, params: Optional[Dict[str, Any]] = None):
        self._key = key
        self.value = value
        self._params = params or {}

    def _get_param(self, name: str) -> List[Optional[Any]]:
        """
        Get a parameter value by name.
        :param name: The name of the parameter to retrieve.
        :return: A list of all matching parameter values, or a single-entry (None) list if the parameter does not exist.
        """
        return self._params.get(name, [None])


class VComponent:
    _vobject_item: vobject.base.Component

    def __init__(self,
                 vobject_item: vobject.base.Component,
                 component_type: str):
        """Initialize a VComponent."""
        if not isinstance(vobject_item, vobject.base.Component):
            raise ValueError("vobject_item must be a vobject.base.Component")
        if vobject_item.name != component_type:
            raise ValueError("Invalid component type: %r, expected %r" %
                             (vobject_item.name, component_type))
        self._vobject_item = vobject_item

    def _get_content_lines(self, name: str) -> List[ContentLine]:
        """Get each matching content line."""
        name = name.lower().strip()
        _content_lines = self._vobject_item.contents.get(name, None)
        if not _content_lines:
            return [ContentLine("", None)]
        if not isinstance(_content_lines, (list, tuple)):
            _content_lines = [_content_lines]
        return [ContentLine(key=name, value=cl.value, params=cl.params)
                for cl in _content_lines if isinstance(cl, vobject.base.ContentLine)] or [ContentLine("", None)]

    def _get_sub_vobjects(self, attribute_name: str, _class: type['VComponent']) -> List[Optional['VComponent']]:
        """Get sub vobject items of the specified type if they exist."""
        sub_vobjects = getattr(self._vobject_item, attribute_name, None)
        if not sub_vobjects:
            return [None]
        if not isinstance(sub_vobjects, (list, tuple)):
            sub_vobjects = [sub_vobjects]
        return ([_class(vobject_item=so) for so in sub_vobjects if  # type: ignore # TODO: Missing positional argument "component_type" in call to "VComponent"
                 isinstance(so, vobject.base.Component)]
                or [None])


class Attendee(ContentLine):
    def __init__(self, content_line: ContentLine):
        super().__init__(key=content_line._key, value=content_line.value,
                         params=content_line._params)

    @property
    def email(self) -> Optional[str]:
        """Return the email address of the attendee."""
        return extract_email(self.value)

    @property
    def role(self) -> Optional[str]:
        """Return the role of the attendee."""
        return self._get_param("ROLE")[0]

    @property
    def participation_status(self) -> Optional[str]:
        """Return the participation status of the attendee."""
        return self._get_param("PARTSTAT")[0]

    @property
    def name(self) -> Optional[str]:
        return self._get_param("CN")[0]

    @property
    def delegated_from(self) -> Optional[str]:
        """Return the email address of the attendee who delegated this attendee."""
        delegate = self._get_param("DELEGATED-FROM")[0]
        return extract_email(delegate) if delegate else None


class TimeWithTimezone(ContentLine):
    def __init__(self, content_line: ContentLine):
        """Initialize a time with timezone content line."""
        super().__init__(key=content_line._key, value=content_line.value,
                         params=content_line._params)

    @property
    def timezone_id(self) -> Optional[str]:
        """Return the timezone of the time."""
        return self._get_param("TZID")[0]

    @property
    def time(self) -> Optional[datetime]:
        """Return the time value."""
        return self.value

    def time_string(self, _format: str = "%Y-%m-%d %H:%M:%S") -> Optional[str]:
        """Return the time as a formatted string."""
        if self.time:
            return self.time.strftime(_format)
        return None


class Alarm(VComponent):
    def __init__(self,
                 vobject_item: vobject.base.Component):
        """Initialize a VALARM item."""
        super().__init__(vobject_item, "VALARM")

    @property
    def action(self) -> Optional[str]:
        """Return the action of the alarm."""
        return self._get_content_lines("ACTION")[0].value

    @property
    def description(self) -> Optional[str]:
        """Return the description of the alarm."""
        return self._get_content_lines("DESCRIPTION")[0].value

    @property
    def trigger(self) -> Optional[timedelta]:
        """Return the trigger of the alarm."""
        return self._get_content_lines("TRIGGER")[0].value

    @property
    def repeat(self) -> Optional[int]:
        """Return the repeat interval of the alarm."""
        repeat = self._get_content_lines("REPEAT")[0].value
        return int(repeat) if repeat is not None else None

    @property
    def duration(self) -> Optional[str]:
        """Return the duration of the alarm."""
        return self._get_content_lines("DURATION")[0].value


class SubTimezone(VComponent):
    def __init__(self,
                 vobject_item: vobject.base.Component,
                 component_type: str):
        """Initialize a sub VTIMEZONE item."""
        super().__init__(vobject_item, component_type)

    @property
    def datetime_start(self) -> Optional[datetime]:
        """Return the start datetime of the timezone."""
        return self._get_content_lines("DTSTART")[0].value

    @property
    def timezone_name(self) -> Optional[str]:
        """Return the timezone name."""
        return self._get_content_lines("TZNAME")[0].value

    @property
    def timezone_offset_from(self) -> Optional[str]:
        """Return the timezone offset from."""
        return self._get_content_lines("TZOFFSETFROM")[0].value

    @property
    def timezone_offset_to(self) -> Optional[str]:
        """Return the timezone offset to."""
        return self._get_content_lines("TZOFFSETTO")[0].value


class StandardTimezone(SubTimezone):
    def __init__(self,
                 vobject_item: vobject.base.Component):
        """Initialize a STANDARD item."""
        super().__init__(vobject_item, "STANDARD")


class DaylightTimezone(SubTimezone):
    def __init__(self,
                 vobject_item: vobject.base.Component):
        """Initialize a DAYLIGHT item."""
        super().__init__(vobject_item, "DAYLIGHT")


class Timezone(VComponent):
    def __init__(self,
                 vobject_item: vobject.base.Component):
        """Initialize a VTIMEZONE item."""
        super().__init__(vobject_item, "VTIMEZONE")

    @property
    def timezone_id(self) -> Optional[str]:
        """Return the timezone ID."""
        return self._get_content_lines("TZID")[0].value

    @property
    def standard(self) -> Optional[StandardTimezone]:
        """Return the STANDARD subcomponent if it exists."""
        return self._get_sub_vobjects("standard", StandardTimezone)[0]  # type: ignore # TODO: got "VComponent | None", expected "StandardTimezone | None"

    @property
    def daylight(self) -> Optional[DaylightTimezone]:
        """Return the DAYLIGHT subcomponent if it exists."""
        return self._get_sub_vobjects("daylight", DaylightTimezone)[0]  # type: ignore # TODO: got "VComponent | None", expected "DaylightTimezone | None"


class Event(VComponent):
    def __init__(self,
                 vobject_item: vobject.base.Component):
        """Initialize a VEVENT item."""
        super().__init__(vobject_item, "VEVENT")

    @property
    def datetime_stamp(self) -> Optional[str]:
        """Return the last modification datetime of the event."""
        return self._get_content_lines("DTSTAMP")[0].value

    @property
    def datetime_start(self) -> Optional[TimeWithTimezone]:
        """Return the start datetime of the event."""
        _content_line = self._get_content_lines("DTSTART")[0]
        return TimeWithTimezone(_content_line) if _content_line.value else None

    @property
    def datetime_end(self) -> Optional[TimeWithTimezone]:
        """Return the end datetime of the event. Either this or duration will be available, but not both."""
        _content_line = self._get_content_lines("DTEND")[0]
        return TimeWithTimezone(_content_line) if _content_line.value else None

    @property
    def duration(self) -> Optional[int]:
        """Return the duration of the event. Either this or datetime_end will be available, but not both."""
        return self._get_content_lines("DURATION")[0].value

    @property
    def uid(self) -> Optional[str]:
        """Return the UID of the event."""
        return self._get_content_lines("UID")[0].value

    @property
    def status(self) -> Optional[str]:
        """Return the status of the event."""
        return self._get_content_lines("STATUS")[0].value

    @property
    def summary(self) -> Optional[str]:
        """Return the summary of the event."""
        return self._get_content_lines("SUMMARY")[0].value

    @property
    def description(self) -> Optional[str]:
        """Return the description of the event."""
        return self._get_content_lines("DESCRIPTION")[0].value

    @property
    def location(self) -> Optional[str]:
        """Return the location of the event."""
        return self._get_content_lines("LOCATION")[0].value

    @property
    def organizer(self) -> Optional[str]:
        """Return the organizer of the event."""
        return self._get_content_lines("ORGANIZER")[0].value

    @property
    def alarms(self) -> List[Alarm]:
        """Return a list of VALARM items in the event."""
        return self._get_sub_vobjects("valarm", Alarm)  # type: ignore # Can be multiple # TODO: got "list[VComponent | None]", expected "list[Alarm]"

    @property
    def attendees(self) -> List[Attendee]:
        """Return a list of ATTENDEE items in the event."""
        _content_lines = self._get_content_lines("ATTENDEE")
        return [Attendee(content_line=attendee) for attendee in _content_lines if attendee.value is not None]


class Calendar(VComponent):
    def __init__(self,
                 vobject_item: vobject.base.Component):
        """Initialize a VCALENDAR item."""
        super().__init__(vobject_item, "VCALENDAR")

    @property
    def version(self) -> Optional[str]:
        """Return the version of the calendar."""
        return self._get_content_lines("VERSION")[0].value

    @property
    def product_id(self) -> Optional[str]:
        """Return the product ID of the calendar."""
        return self._get_content_lines("PRODID")[0].value

    @property
    def event(self) -> Optional[Event]:
        """Return the VEVENT item in the calendar."""
        return self._get_sub_vobjects("vevent", Event)[0]  # type: ignore # TODO: got "VComponent | None", expected "Event | None"

    # TODO: Add VTODO and VJOURNAL support if needed

    @property
    def timezone(self) -> Optional[Timezone]:
        """Return the VTIMEZONE item in the calendar."""
        return self._get_sub_vobjects("vtimezone", Timezone)[0]  # type: ignore # TODO: got "VComponent | None", expected "Timezone | None"


class EmailEvent:
    def __init__(self,
                 event: Event,
                 ics_content: str,
                 ics_file_name: str):
        self.event = event
        self.ics_content = ics_content
        self.file_name = ics_file_name


class ICSEmailAttachment:
    def __init__(self, file_content: str, file_name: str):
        self.file_content = file_content
        self.file_name = file_name

    def prepare_email_part(self) -> MIMEBase:
        # Add file as application/octet-stream
        # Email client can usually download this automatically as attachment
        part = MIMEBase("application", "octet-stream")
        part.set_payload(self.file_content)

        # Encode file in ASCII characters to send by email
        encode_base64(part)

        # Add header as key/value pair to attachment part
        part.add_header(
            "Content-Disposition",
            f"attachment; filename= {self.file_name}",
        )

        return part


class MessageTemplate:
    def __init__(self, subject: str, body: str):
        self.subject = subject
        self.body = body
        if not self._validate_template(template=subject):
            raise ValueError(
                f"Invalid subject template: {subject}. Allowed variables are: {MESSAGE_TEMPLATE_VARIABLES}")
        if not self._validate_template(template=body):
            raise ValueError(f"Invalid body template: {body}. Allowed variables are: {MESSAGE_TEMPLATE_VARIABLES}")

    def __repr__(self):
        return f'MessageTemplate(subject={self.subject}, body={self.body})'

    def __str__(self):
        return f'{self.subject}: {self.body}'

    def _validate_template(self, template: str) -> bool:
        """
        Validate the template to ensure it contains only allowed variables.
        :param template: The template string to validate.
        :return: True if the template is valid, False otherwise.
        """
        # Find all variables in the template (starting with $)
        variables = re.findall(r'\$(\w+)', template)
        # Check if all variables are in the allowed list
        for var in variables:
            if var not in MESSAGE_TEMPLATE_VARIABLES:
                logger.error(
                    f"Invalid variable '{var}' found in template. Allowed variables are: {MESSAGE_TEMPLATE_VARIABLES}")
                return False
        return True

    def _populate_template(self, template: str, context: dict) -> str:
        """
        Populate the template with the provided context.
        :param template: The template string to populate.
        :param context: A dictionary containing the context variables.
        :return: The populated template string.
        """
        for key, value in context.items():
            template = template.replace(f"${key}", str(value or ""))
        return template

    def build_message(self, event: EmailEvent, from_email: str, mass_email: bool,
                      attendee: Optional[Attendee] = None) -> str:
        """
        Build the message body using the template.
        :param event: The event to include in the message.
        :param from_email: The email address of the sender.
        :param mass_email: Whether this is a mass email to multiple attendees.
        :param attendee: The specific attendee to include in the message, if not a mass email.
        :return: The formatted message body.
        """
        attendee_name: Union[str, None]
        if mass_email:
            # If this is a mass email, we do not use individual attendee names
            attendee_name = "everyone"
        else:
            assert attendee is not None, "Attendee must be provided for non-mass emails"
            attendee_name = attendee.name if attendee else "Unknown Name"

        context = {
            "attendee_name": attendee_name,
            "from_email": from_email,
            "organizer_name": event.event.organizer or "Unknown Organizer",
            "event_title": event.event.summary or "No Title",
            "event_start_time": event.event.datetime_start.time_string() if event.event.datetime_start else "No Start Time",
            "event_end_time": event.event.datetime_end.time_string() if event.event.datetime_end else "No End Time",
            "event_location": event.event.location or "No Location Specified",
        }
        return self._populate_template(template=self.body, context=context)

    def build_subject(self, event: EmailEvent, from_email: str, mass_email: bool,
                      attendee: Optional[Attendee] = None) -> str:
        """
        Build the message subject using the template.
        :param attendee: The attendee to include in the subject.
        :param event: The event to include in the subject.
        :param from_email: The email address of the sender.
        :param mass_email: Whether this is a mass email to multiple attendees.
        :param attendee: The specific attendee to include in the message, if not a mass email.
        :return: The formatted message subject.
        """
        attendee_name: Union[str, None]
        if mass_email:
            # If this is a mass email, we do not use individual attendee names
            attendee_name = "everyone"
        else:
            assert attendee is not None, "Attendee must be provided for non-mass emails"
            attendee_name = attendee.name if attendee else "Unknown Name"

        context = {
            "attendee_name": attendee_name,
            "from_email": from_email,
            "organizer_name": event.event.organizer or "Unknown Organizer",
            "event_title": event.event.summary or "No Title",
            "event_start_time": event.event.datetime_start.time_string() if event.event.datetime_start else "No Start Time",
            "event_end_time": event.event.datetime_end.time_string() if event.event.datetime_end else "No End Time",
            "event_location": event.event.location or "No Location Specified",
        }
        return self._populate_template(template=self.subject, context=context)


class EmailConfig:
    def __init__(self,
                 host: str,
                 port: int,
                 security: str,
                 ssl_verify_mode: str,
                 username: str,
                 password: str,
                 from_email: str,
                 send_mass_emails: bool,
                 dryrun: bool,
                 new_or_added_to_event_template: MessageTemplate,
                 deleted_or_removed_from_event_template: MessageTemplate,
                 updated_event_template: MessageTemplate,
                 itip_enabled: bool = False,
                 itip_owner_map: str = "",
                 itip_organizer_is_username: bool = False):
        self.host = host
        self.port = port
        self.security = SMTP_SECURITY_TYPE_ENUM.from_string(value=security)
        self.ssl_verify_mode = SMTP_SSL_VERIFY_MODE_ENUM.from_string(value=ssl_verify_mode)
        self.username = username
        self.password = password
        self.from_email = from_email
        self.send_mass_emails = send_mass_emails
        self.dryrun = dryrun
        self.itip_enabled = itip_enabled
        self.itip_owner_map = itip_owner_map
        self.itip_organizer_is_username = itip_organizer_is_username
        self.new_or_added_to_event_template = new_or_added_to_event_template
        self.deleted_or_removed_from_event_template = deleted_or_removed_from_event_template
        self.updated_event_template = updated_event_template

    def __str__(self) -> str:
        """
        Return a string representation of the EmailConfig.
        """
        return f"EmailConfig(host={self.host}, port={self.port}, username={self.username}, " \
               f"from_email={self.from_email}, send_mass_emails={self.send_mass_emails}, dryrun={self.dryrun}, " \
               f"itip_enabled={self.itip_enabled}, " \
               f"itip_owner_map={self.itip_owner_map!r}, " \
               f"itip_organizer_is_username={self.itip_organizer_is_username})"

    def __repr__(self):
        return self.__str__()

    def validate_itip_config(self) -> None:
        """Raise on invalid iTIP configuration.

        ``mass_email`` and ``itip_enabled`` cannot both be true,
        and ``itip_enabled`` requires a non-empty
        ``itip_owner_map`` unless ``itip_organizer_is_username``
        is set. Fail at startup instead of silently falling back
        to legacy sending.
        """
        if self.itip_enabled and self.send_mass_emails:
            raise ValueError(
                "hook.mass_email and hook.itip_enabled cannot both be "
                "true: mass_email sends one grouped legacy email, "
                "itip_enabled sends one per-recipient iTIP message")
        if (self.itip_enabled and not (self.itip_owner_map or "").strip()
                and not self.itip_organizer_is_username):
            raise ValueError(
                "hook.itip_enabled requires hook.itip_owner_map or "
                "hook.itip_organizer_is_username: "
                "outbound iTIP needs an explicit actor-to-organizer-"
                "email map (or usernames that are emails), because "
                "a bare username matching by local-part could match "
                "a different domain, and Radicale has no "
                "authoritative principal-to-email mapping to fall "
                "back to")

    def send_added_email(self, attendees: List[Attendee], event: EmailEvent) -> bool:
        """
        Send a notification for created events (and/or adding attendees).
        :param attendees: The attendees to inform.
        :param event: The event being created (or the event the attendee is being added to).
        :return: True if the email was sent successfully, False otherwise.
        """
        ics_attachment = ICSEmailAttachment(file_content=event.ics_content, file_name=f"{event.file_name}")

        return self._prepare_and_send_email(template=self.new_or_added_to_event_template, attendees=attendees,
                                            event=event,
                                            ics_attachment=ics_attachment)

    def send_updated_email(self, attendees: List[Attendee], event: EmailEvent) -> bool:
        """
        Send a notification for updated events.
        :param attendees: The attendees to inform.
        :param event: The event being updated.
        :return: True if the email was sent successfully, False otherwise.
        """
        ics_attachment = ICSEmailAttachment(file_content=event.ics_content, file_name=f"{event.file_name}")

        return self._prepare_and_send_email(template=self.updated_event_template, attendees=attendees, event=event,
                                            ics_attachment=ics_attachment)

    def send_deleted_email(self, attendees: List[Attendee], event: EmailEvent) -> bool:
        """
        Send a notification for deleted events (and/or removing attendees).
        :param attendees: The attendees to inform.
        :param event: The event being deleted (or the event the attendee is being removed from).
        :return: True if the email was sent successfully, False otherwise.
        """
        return self._prepare_and_send_email(template=self.deleted_or_removed_from_event_template, attendees=attendees,
                                            event=event,
                                            ics_attachment=None)

    def send_scheduling_email(self, planned: PlannedMessage,
                              event: EmailEvent, source_ics: str,
                              sequence: Optional[int] = None) -> bool:
        """Send one planned iTIP/iMIP message to one recipient.

        ``event`` provides the title/time/location for the
        plain-text template; ``source_ics`` is the new event
        for REQUEST and the old event for CANCEL, so a removed
        attendee still gets a well-formed CANCEL. Called only
        in iTIP mode; when ``itip_enabled`` is False the hook
        uses the legacy path instead.
        """
        if planned.kind in ("created", "added"):
            template = self.new_or_added_to_event_template
        elif planned.kind in ("removed", "deleted"):
            template = self.deleted_or_removed_from_event_template
        else:
            template = self.updated_event_template
        attendee = Attendee(ContentLine(
            key="attendee", value="mailto:%s" % planned.recipient_email,
            params={"CN": [planned.recipient_name]} if planned.recipient_name else {}))
        body = template.build_message(event=event, from_email=self.from_email,
                                      mass_email=False, attendee=attendee)
        subject = template.build_subject(event=event, from_email=self.from_email,
                                         mass_email=False, attendee=attendee)
        try:
            itip_ics = build_itip_ics(source_ics, planned.method, planned.recipient_email,
                                      sequence=sequence)
        except Exception as e:
            logger.error("Failed to build iTIP message for %r: %s", planned.recipient_email, e)
            return False
        text = build_itip_message(from_email=self.from_email,
                                  to_email=planned.recipient_email,
                                  subject=subject, body_text=body,
                                  itip_ics=itip_ics, method=planned.method)
        if self.dryrun is True:
            logger.notice("Hook 'email': DRY-RUN send_scheduling_email / to_addresses=%r",
                          [planned.recipient_email])
            logger.notice("Hook 'email': DRY-RUN send_scheduling_email / subject=%r", subject)
            logger.notice("Hook 'email': DRY-RUN send_scheduling_email / method=%r", planned.method)
            return True
        return self._smtp_send(text=text, to_addresses=[planned.recipient_email])

    def _prepare_and_send_email(self, template: MessageTemplate, attendees: List[Attendee],
                                event: EmailEvent, ics_attachment: Optional[ICSEmailAttachment] = None) -> bool:
        """
        Prepare the email message(s) and send them to the attendees.
        :param template: The message template to use for the email.
        :param attendees: The list of attendees to notify.
        :param event: The event to include in the email.
        :param ics_attachment: An optional ICS attachment to include in the email.
        :return: True if the email(s) were sent successfully, False otherwise.
        """
        if self.send_mass_emails:
            # If mass emails are enabled, we send one email to all attendees
            if len(attendees) == 1:
                # only one attendee
                logger.trace("send_mass_emails=True but only 1 attendee, fallback to non-mass")
                body = template.build_message(event=event, from_email=self.from_email,
                                              mass_email=False, attendee=attendees[0])
                subject = template.build_subject(event=event, from_email=self.from_email,
                                                 mass_email=False, attendee=attendees[0])
            else:
                body = template.build_message(event=event, from_email=self.from_email,
                                              mass_email=self.send_mass_emails, attendee=None)
                subject = template.build_subject(event=event, from_email=self.from_email,
                                                 mass_email=self.send_mass_emails, attendee=None)

            return self._send_email(subject=subject, body=body, attendees=attendees, ics_attachment=ics_attachment)
        else:
            failure_encountered = False
            for attendee in attendees:
                # For individual emails, we send one email per attendee
                body = template.build_message(event=event, from_email=self.from_email,
                                              mass_email=self.send_mass_emails, attendee=attendee)
                subject = template.build_subject(event=event, from_email=self.from_email,
                                                 mass_email=self.send_mass_emails, attendee=attendee)

                if not self._send_email(subject=subject, body=body, attendees=[attendee],
                                        ics_attachment=ics_attachment):
                    failure_encountered = True

            return not failure_encountered  # Return True if all emails were sent successfully

    def _build_context(self) -> ssl.SSLContext:
        """
        Build the SSL context based on the configured security and SSL verify mode.
        :return: An SSLContext object configured for the SMTP connection.
        """
        context = ssl.create_default_context()
        if self.ssl_verify_mode == SMTP_SSL_VERIFY_MODE_ENUM.REQUIRED:
            context.check_hostname = True
            context.verify_mode = ssl.CERT_REQUIRED
        elif self.ssl_verify_mode == SMTP_SSL_VERIFY_MODE_ENUM.OPTIONAL:
            context.check_hostname = True
            context.verify_mode = ssl.CERT_OPTIONAL
        else:
            context.check_hostname = False
            context.verify_mode = ssl.CERT_NONE
        return context

    def _send_email(self,
                    subject: str,
                    body: str,
                    attendees: List[Attendee],
                    ics_attachment: Optional[ICSEmailAttachment] = None) -> bool:
        """
        Send the notification using the email service.
        :param subject: The subject of the notification.
        :param body: The body of the notification.
        :param attendees: The attendees to notify.
        :param ics_attachment: An optional ICS attachment to include in the email.
        :return: True if the email was sent successfully, False otherwise.
        """
        to_addresses = [attendee.email for attendee in attendees if attendee.email]
        if not to_addresses:
            logger.warning("No valid email addresses found in attendees. Cannot send email.")
            return False

        if self.dryrun is True:
            logger.notice("Hook 'email': DRY-RUN _send_email / to_addresses=%r", to_addresses)
            logger.notice("Hook 'email': DRY-RUN _send_email / subject=%r", subject)
            logger.notice("Hook 'email': DRY-RUN _send_email / body=%r", body)
            return True

        # Add headers
        message = MIMEMultipart("mixed")
        message["From"] = self.from_email
        message["Reply-To"] = self.from_email
        message["Subject"] = subject
        message["Date"] = formatdate(localtime=True)

        # Add body text
        message.attach(MIMEText(body, "plain"))

        # Add ICS attachment if provided
        if ics_attachment:
            ical_attachment = ics_attachment.prepare_email_part()
            message.attach(ical_attachment)

        # Convert message to text
        text = message.as_string()
        return self._smtp_send(text=text, to_addresses=to_addresses)

    def _smtp_send(self, text: str, to_addresses: List[str]) -> bool:
        """Send an already-built MIME message via the configured SMTP server."""
        try:
            if self.security == SMTP_SECURITY_TYPE_ENUM.EMPTY:
                logger.warning("SMTP security type is empty, raising ValueError.")
                raise ValueError("SMTP security type cannot be empty. Please specify a valid security type.")
            elif self.security == SMTP_SECURITY_TYPE_ENUM.NONE:
                server = smtplib.SMTP(host=self.host, port=self.port)
            elif self.security == SMTP_SECURITY_TYPE_ENUM.STARTTLS:
                context = self._build_context()
                server = smtplib.SMTP(host=self.host, port=self.port)
                server.ehlo()  # Identify self to server
                server.starttls(context=context)  # Start TLS connection
                server.ehlo()  # Identify again after starting TLS
            elif self.security == SMTP_SECURITY_TYPE_ENUM.TLS:
                context = self._build_context()
                server = smtplib.SMTP_SSL(host=self.host, port=self.port, context=context)

            if self.username and self.password:
                logger.debug("Logging in to SMTP server with username: %s", self.username)
                server.login(user=self.username, password=self.password)

            errors: Dict[str, Tuple[int, bytes]] = server.sendmail(from_addr=self.from_email, to_addrs=to_addresses,
                                                                   msg=text)
            logger.debug("Email sent successfully to %s", to_addresses)
            server.quit()
        except smtplib.SMTPException as e:
            logger.error(f"SMTP error occurred: {e}")
            return False

        if errors:
            for email, (code, error) in errors.items():
                logger.error(f"Failed to send email to {email}: {str(error)} (Code: {code})")
            return False

        return True


def _read_event(vobject_data: str) -> EmailEvent:
    """
    Read the vobject item from the provided string and create an EmailEvent.
    """
    v_cal: vobject.base.Component = vobject.readOne(vobject_data)
    cal: Calendar = Calendar(vobject_item=v_cal)
    event: Union[Event, None] = cal.event

    return EmailEvent(
        event=event,  # type: ignore # TODO: Argument "event" to "EmailEvent" has incompatible type "Event | None"; expected "Event"
        ics_content=vobject_data,
        ics_file_name="event.ics"
    )


class Hook(BaseHook):
    def __init__(self, configuration):
        super().__init__(configuration)
        smtp_password = self.configuration.get("hook", "smtp_password")
        smtp_password_file = self.configuration.get("hook", "smtp_password_file")
        if smtp_password_file:
            try:
                with open(smtp_password_file, "r", encoding="utf-8") as file:
                    smtp_password = file.read().rstrip("\n")
            except Exception as e:
                logger.error("Email hook option 'smtp_password_file' provided but not readable: %r (%r)", smtp_password_file, e)
        self.email_config = EmailConfig(
            host=self.configuration.get("hook", "smtp_server"),
            port=self.configuration.get("hook", "smtp_port"),
            security=self.configuration.get("hook", "smtp_security"),
            ssl_verify_mode=self.configuration.get("hook", "smtp_ssl_verify_mode"),
            username=self.configuration.get("hook", "smtp_username"),
            password=smtp_password,
            from_email=self.configuration.get("hook", "from_email"),
            send_mass_emails=self.configuration.get("hook", "mass_email"),
            dryrun=self.configuration.get("hook", "dryrun"),
            itip_enabled=self.configuration.get("hook", "itip_enabled"),
            itip_owner_map=self.configuration.get("hook", "itip_owner_map"),
            itip_organizer_is_username=self.configuration.get("hook", "itip_organizer_is_username"),
            new_or_added_to_event_template=MessageTemplate(
                subject="You have been added to an event",
                body=self.configuration.get("hook", "new_or_added_to_event_template")
            ),
            deleted_or_removed_from_event_template=MessageTemplate(
                subject="An event you were invited to has been deleted",
                body=self.configuration.get("hook", "deleted_or_removed_from_event_template")
            ),
            updated_event_template=MessageTemplate(
                subject="An event you are invited to has been updated",
                body=self.configuration.get("hook", "updated_event_template")
            )
        )
        self.email_config.validate_itip_config()
        # Malformed owner map fails hook load, not silently ignored.
        self.owner_map = parse_owner_map(self.email_config.itip_owner_map)
        logger.info(
            "Email hook initialized with configuration: %s",
            self.email_config
        )

    @property
    def enabled(self) -> bool:
        """Check if this hook is enabled (has a notify method)."""
        return self.email_config.host is not None

    def notify(self, notification_item) -> None:
        """
        Entrypoint for processing a single notification item.
        Overrides default notify method from BaseHook.
        Triggered by Radicale when a notifiable event occurs (e.g. item added, updated or deleted)
        """
        # Skip any non-VCALENDAR items
        if not notification_item.is_calendar_item:
            return

        if isinstance(notification_item, HookNotificationItem):
            self._process_event_and_notify(notification_item)

    def _send_planned(self, planned, email_event: EmailEvent,
                      previous_item_str, new_item_str) -> None:
        """Send a list of planned messages for one event change.

        One iTIP message per recipient. ``mass_email`` is
        incompatible with iTIP mode and is rejected at Hook
        init; this guard covers directly constructed configs.
        """
        if self.email_config.send_mass_emails:
            logger.error("mass_email is incompatible with itip_enabled, sending nothing")
            return
        for message in planned:
            cancel_sequence = None
            if message.method == "CANCEL" and previous_item_str:
                template_event = _read_event(vobject_data=previous_item_str)
                source_ics = previous_item_str
                # Ensure the cancellation supersedes both event revisions.
                # For a deleted event this reduces to old + 1.
                old_parsed = parse_event(previous_item_str)
                new_parsed = parse_event(new_item_str) if new_item_str else None
                old_seq = old_parsed.sequence if old_parsed else 0
                new_seq = new_parsed.sequence if new_parsed else 0
                cancel_sequence = max(old_seq, new_seq) + 1
            else:
                template_event = email_event
                source_ics = new_item_str
            success = self.email_config.send_scheduling_email(
                planned=message, event=template_event, source_ics=source_ics,
                sequence=cancel_sequence)
            if not success:
                logger.error("Failed to send scheduling notification (%s) to %s for event: %s",
                             message.kind, message.recipient_email, email_event.event.uid)

    def _owner_identities(self, notification_item) -> List[str]:
        """Identities the hook can use to prove organizer ownership.

        The explicit map, plus the username itself when it is an
        email address and ``itip_organizer_is_username`` is set;
        never ``from_email``, never a bare username. See
        resolve_owner_identities.

        Actor provenance: ``notification_item.actor`` is set by
        Radicale's storage layer from the authenticated user
        (app/put.py: ``actor = user``, where ``user`` is the
        result of the configured auth backend's login). It is
        not parsed from the ICS content, ORGANIZER, or ATTENDEE
        lines. A deployment whose auth backend trusts a proxy
        header (e.g. http_remote_user) must trust that proxy.
        """
        actor = getattr(notification_item, "actor", None)
        return resolve_owner_identities(
            actor, getattr(self, "owner_map", {}),
            organizer_is_username=self.email_config.itip_organizer_is_username)

    # Shared event processing. The iTIP and legacy paths share
    # notification-type parsing, event reading, and past-event
    # checking, but not their sending rules: legacy keeps its
    # unparseable-previous-event fallback to send_added, while
    # iTIP sends nothing when the previous event cannot be parsed.

    def _notification_type(self, notification_item):
        try:
            return HookNotificationItemTypes(value=notification_item.type)
        except ValueError:
            logger.warning("Unknown notification item type: %s", notification_item.type)
            return None

    def _is_past_event(self, email_event) -> bool:
        event = email_event.event
        if not event:
            return False
        end_time = event.datetime_end
        if not end_time or not end_time.time:
            return False
        event_end = end_time.time
        now: Union[datetime, date]
        if hasattr(event_end, "tzinfo"):
            now = datetime.now(event_end.tzinfo) if event_end.tzinfo else datetime.now()
        else:
            now = date.today()
        logger.trace("event_end=%r now=%r", event_end, now)
        if event_end < (now - timedelta(minutes=1)):
            logger.warning("Event end time is in the past, skipping notification for event: %s",
                           event.uid)
            return True
        return False

    def _upsert_parts(self, notification_item):
        """Return (new_str, old_str, email_event) for an UPSERT, or None to skip."""
        new_item_str = notification_item.new_content
        previous_item_str = notification_item.old_content
        if not ics_contents_contains_event(contents=new_item_str):
            logger.debug("No event found in the ICS file, skipping notification.")
            return None
        email_event = _read_event(vobject_data=new_item_str)
        if not email_event or not email_event.event:
            logger.error("Failed to read event from new content: %s", new_item_str)
            return None
        if self._is_past_event(email_event):
            return None
        return new_item_str, previous_item_str, email_event

    def _delete_parts(self, notification_item):
        """Return (deleted_str, email_event) for a DELETE, or None to skip."""
        deleted_item_str = notification_item.old_content
        if not ics_contents_contains_event(contents=deleted_item_str):
            logger.debug("No event found in the ICS file, skipping notification.")
            return None
        return deleted_item_str, _read_event(vobject_data=deleted_item_str)

    def _process_event_and_notify(self, notification_item: HookNotificationItem) -> None:
        """Dispatch one notification to the iTIP or legacy path."""
        if self.email_config.dryrun:
            logger.warning("Hook 'email': DRY-RUN received notification_item: %r", vars(notification_item))
        else:
            logger.debug("Received notification_item: %r", vars(notification_item))
        notification_type = self._notification_type(notification_item)
        if notification_type is None or notification_type == HookNotificationItemTypes.CPATCH:
            return
        if notification_type == HookNotificationItemTypes.UPSERT:
            parts = self._upsert_parts(notification_item)
            if parts is None:
                return
            if self.email_config.itip_enabled:
                self._process_itip_upsert(notification_item, *parts)
            else:
                self._process_legacy_upsert(*parts)
            return
        if notification_type == HookNotificationItemTypes.DELETE:
            parts = self._delete_parts(notification_item)
            if parts is None:
                return
            if self.email_config.itip_enabled:
                self._process_itip_delete(notification_item, *parts)
            else:
                self._process_legacy_delete(*parts)
            return

    def _process_itip_upsert(self, notification_item, new_item_str, previous_item_str, email_event) -> None:
        if not previous_item_str:
            logger.info("New event detected, sending notifications to all attendees: %s",
                        email_event.event.uid)
        owner_identities = self._owner_identities(notification_item)
        new_parsed = parse_event(new_item_str)
        if new_parsed is not None and not check_ownership(
                new_parsed.organizer_email, owner_identities):
            logger.error("Organizer %r does not match owner identities %r, "
                         "skipping scheduling messages (attendee copy?) for event: %s",
                         new_parsed.organizer_email, owner_identities,
                         email_event.event.uid)
            return
        if previous_item_str and parse_event(previous_item_str) is None:
            logger.error("Previous event content could not be parsed, "
                         "sending no scheduling messages for event: %s",
                         email_event.event.uid)
            return
        planned = plan_messages(previous_item_str, new_item_str,
                                owner_identities=owner_identities)
        self._send_planned(planned, email_event, previous_item_str, new_item_str)

    def _process_itip_delete(self, notification_item, deleted_item_str, email_event) -> None:
        self._send_planned(plan_messages(deleted_item_str, None, deleted=True,
                                         owner_identities=self._owner_identities(notification_item)),
                           email_event, deleted_item_str, deleted_item_str)

    def _process_legacy_upsert(self, new_item_str, previous_item_str, email_event) -> None:
        if not previous_item_str:
            logger.info("New event detected, sending notifications to all attendees: %s",
                        email_event.event.uid)
            email_success = self.email_config.send_added_email(
                attendees=email_event.event.attendees, event=email_event)
            if not email_success:
                logger.error("Failed to send some or all added email notifications for event: %s",
                             email_event.event.uid)
            return
        new_event = read_ics_event(contents=new_item_str)
        if new_event is None:
            return
        previous_event = read_ics_event(contents=previous_item_str)
        if not previous_event:
            # Legacy fallback, deliberately different from iTIP:
            # an unparseable previous event is treated as a new event.
            logger.warning("Previous event content could not be parsed, treating as a new event.")
            email_success = self.email_config.send_added_email(
                attendees=email_event.event.attendees, event=email_event)
            if not email_success:
                logger.error("Failed to send some or all added email notifications for event: %s",
                             email_event.event.uid)
            return
        added_attendees, removed_attendees, unaltered_attendees = determine_added_removed_and_unaltered_attendees(
            original_event=previous_event, new_event=new_event)
        if added_attendees:
            email_success = self.email_config.send_added_email(
                attendees=added_attendees, event=email_event)
            if not email_success:
                logger.error("Failed to send some or all added email notifications for event: %s",
                             email_event.event.uid)
        if removed_attendees:
            email_success = self.email_config.send_deleted_email(
                attendees=removed_attendees, event=email_event)
            if not email_success:
                logger.error("Failed to send some or all deleted email notifications for event: %s",
                             email_event.event.uid)
        if (unaltered_attendees and event_details_other_than_attendees_changed(
                original_event=previous_event, new_event=new_event)):
            email_success = self.email_config.send_updated_email(
                attendees=unaltered_attendees, event=email_event)
            if not email_success:
                logger.error("Failed to send some or all updated email notifications for event: %s",
                             email_event.event.uid)

    def _process_legacy_delete(self, deleted_item_str, email_event) -> None:
        email_success = self.email_config.send_deleted_email(
            attendees=email_event.event.attendees, event=email_event)
        if not email_success:
            logger.error("Failed to send some or all deleted email notifications for event: %s",
                         email_event.event.uid)
